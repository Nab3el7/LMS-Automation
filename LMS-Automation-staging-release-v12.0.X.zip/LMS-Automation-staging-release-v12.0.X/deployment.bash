#! /bin/bash

sleep 300
#mvn test
mvn clean test -DsuiteXmlFile=src/test/resources/testng.xml