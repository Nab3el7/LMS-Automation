This is Selenium based Java Cucumber Automation repository
