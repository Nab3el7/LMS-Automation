# Docker Selenium Grid Setup with Extended Session Timeout

## Problem
Sessions are timing out after 300 seconds (5 minutes) due to inactivity, causing test failures.

## Solution
Restart Docker container with increased session timeout.

## Updated Docker Command

Stop the current container and restart with extended session timeout:

```bash
# Stop current container
docker stop selenium-chrome

# Remove old container
docker rm selenium-chrome

# Start with extended session timeout and increased shared memory to prevent tab crashes
docker run --rm -d --platform linux/amd64 \
  --name selenium-chrome \
  -p 4444:4444 \
  -p 7900:7900 \
  --shm-size="4g" \
  -e SE_NODE_MAX_SESSIONS=16 \
  -e SE_NODE_OVERRIDE_MAX_SESSIONS=true \
  -e SE_NODE_SESSION_TIMEOUT=1800 \
  selenium/standalone-chrome
```

## Key Changes
- `SE_NODE_SESSION_TIMEOUT=1800`: Sets session timeout to 30 minutes (1800 seconds)
- This prevents "session timed out due to inactivity" errors

## Verify
```bash
# Check container is running
docker ps | grep selenium

# Check logs for session timeout configuration
docker logs selenium-chrome | grep "session-timeout"
```

You should see: `session-timeout = 1800` in the logs.
