# Selenium Grid Configuration Options

This document describes alternative ways to configure Selenium Grid URLs without hardcoding them in `Configurations.java`.

## Configuration Priority

The system uses the following priority order:
1. **Environment Variables** (highest priority)
2. **Properties Files** 
3. **Hardcoded Defaults** (lowest priority - fallback only)

## Option 1: Environment Variables (Recommended for Server)

### Single URL
```bash
export SELENIUM_GRID_URL=http://your-grid-host:4444
```

### Multiple URLs (comma-separated)
```bash
export SELENIUM_GRID_URLS=http://grid1:4444,http://grid2:4444,http://grid3:4444
```

### Kubernetes Service Discovery
```bash
export SELENIUM_GRID_SERVICE_NAME=selenium-standalone
export SELENIUM_GRID_NAMESPACE=gallopade-staging
export SELENIUM_GRID_PORT=4444
```

This will automatically build URLs:
- `http://selenium-standalone.gallopade-staging.svc.cluster.local:4444`
- `http://selenium-standalone.gallopade-staging:4444`
- `http://selenium-standalone:4444`

## Option 2: Properties File Configuration

### Single URL
Add to `application.properties` or `application-staging.properties`:
```properties
selenium.grid.url=http://your-grid-host:4444
```

### Multiple URLs (comma-separated)
```properties
selenium.grid.urls=http://grid1:4444,http://grid2:4444,http://grid3:4444
```

## Option 3: Local Grid
For local development with Selenium Grid:
```properties
selenium.grid.use.local=true
```

This uses `http://localhost:4444`

## Option 4: Use Browser Pool (Local Only)

The `BrowserPoolManager` can be used for local execution without Grid. It's automatically disabled when using Selenium Grid.

## Examples

### Example 1: Server Deployment with Environment Variable
```bash
# In your deployment script or Kubernetes config
export SELENIUM_GRID_URL=http://selenium-standalone.gallopade-staging.svc.cluster.local:4444
```

### Example 2: Multiple Grid Endpoints
```bash
export SELENIUM_GRID_URLS=http://selenium-standalone.gallopade-staging.svc.cluster.local:4444,http://selenium-standalone.gallopade-staging:4444
```

### Example 3: Properties File for Staging
In `application-staging.properties`:
```properties
selenium.grid.url=http://selenium-standalone.gallopade-staging.svc.cluster.local:4444
```

## Benefits of Using Configuration Instead of Hardcoding

1. **Environment-Specific**: Different URLs for dev/staging/prod
2. **No Code Changes**: Update configuration without redeploying code
3. **Flexibility**: Easy to switch between Grid instances
4. **Kubernetes-Friendly**: Works with service discovery
5. **Multiple Endpoints**: Support for Grid clusters

## Current Hardcoded URLs (Fallback Only)

If no configuration is provided, the system falls back to:
- `http://selenium-standalone.gallopade-staging.svc.cluster.local:4444`
- `http://selenium-standalone.gallopade-staging:4444`
- `http://selenium-standalone:4444`

**Note**: These are only used as a last resort. It's recommended to configure URLs via environment variables or properties files.

