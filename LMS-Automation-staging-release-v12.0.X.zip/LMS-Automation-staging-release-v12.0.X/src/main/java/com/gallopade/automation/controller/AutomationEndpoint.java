package com.gallopade.automation.controller;

import com.gallopade.automation.model.TestExecutionStatus;
import com.gallopade.automation.services.AutomationService;
import com.gallopade.automation.services.TestExecutionStatusService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import jakarta.servlet.http.HttpServletRequest;

import java.io.IOException;
import java.lang.management.ManagementFactory;
import java.lang.management.RuntimeMXBean;
import java.lang.management.ThreadInfo;
import java.lang.management.ThreadMXBean;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Slf4j
@RestController
@RequestMapping("/api/v1")
public class AutomationEndpoint {

    @Autowired
    private AutomationService automationService;

    @Autowired
    private TestExecutionStatusService statusService;
    
    @Autowired
    private com.gallopade.automation.services.BrowserPoolManager browserPoolManager;

    private static Map<String, String> testCaseFileMap = new HashMap<>();

//    public AutomationEndpoint() {
//        if(testCaseFileMap.isEmpty()) {
//            testCaseFileMap =  TestConstants.TestCasesPath();
//        }
//    }

    @GetMapping("/automation-report")
    public ResponseEntity<?> runAutomationScript(HttpServletRequest request) throws IOException {
        String jobId = UUID.randomUUID().toString();
        
        // Calculate estimated time before starting
        Map<String, String> testCases = automationService.getAllTeacherSideTestCases();
        int totalFeatures = testCases.size();
        long avgTimePerFeature = 150; // 2.5 minutes per feature
        long parallelFactor = 2; // threads (browser pool size)
        long estimatedTime = (totalFeatures * avgTimePerFeature) / parallelFactor;
        long buffer = (long) (estimatedTime * 0.2);
        long totalEstimatedTime = estimatedTime + buffer;
        long minutes = totalEstimatedTime / 60;
        long secs = totalEstimatedTime % 60;
        
        automationService.runTestsAsync(jobId);
        
        // Check if request is from browser (has Accept header with text/html)
        String acceptHeader = request.getHeader("Accept");
        boolean isBrowserRequest = acceptHeader != null && acceptHeader.contains("text/html");
        
        if (isBrowserRequest) {
            // Redirect browser to HTML monitoring page
            HttpHeaders headers = new HttpHeaders();
            headers.add("Location", "/test-runner.html?jobId=" + jobId);
            return new ResponseEntity<>(headers, HttpStatus.FOUND);
        }
        
        // Return JSON for API clients
        Map<String, String> response = new HashMap<>();
        response.put("jobId", jobId);
        response.put("status", "accepted");
        response.put("message", "Full test suite execution started");
        response.put("estimatedTime", String.format("%d minutes %d seconds", minutes, secs));
        response.put("totalFeatures", String.valueOf(totalFeatures));
        response.put("statusUrl", "/api/v1/test-status?jobId=" + jobId);
        response.put("monitorUrl", "/test-runner.html?jobId=" + jobId);
        response.put("reportUrl", "https://gallopadeqa.blob.core.windows.net/staging/Reports/Manual_Automation_Run_Report.html");
        
        return ResponseEntity.accepted().body(response);
    }

    @GetMapping("/specific-testcase")
    public ResponseEntity<?> runAutomationScript(
            @RequestParam(name = "featureFile", required = true) String featureFile,
            HttpServletRequest request) throws IOException {
        testCaseFileMap = automationService.getAllTeacherSideTestCases();
        if (testCaseFileMap.containsKey(featureFile)) {
            String fileName = testCaseFileMap.get(featureFile);
            String jobId = UUID.randomUUID().toString();
            automationService.runTestAsync(jobId, fileName);
            
            // Check if request is from browser (has Accept header with text/html)
            String acceptHeader = request.getHeader("Accept");
            boolean isBrowserRequest = acceptHeader != null && acceptHeader.contains("text/html");
            
            if (isBrowserRequest) {
                // Redirect browser to HTML monitoring page
                HttpHeaders headers = new HttpHeaders();
                headers.add("Location", "/test-runner.html?jobId=" + jobId + "&featureFile=" + featureFile);
                return new ResponseEntity<>(headers, HttpStatus.FOUND);
            }
            
            // Return JSON for API clients
            Map<String, String> response = new HashMap<>();
            response.put("jobId", jobId);
            response.put("status", "accepted");
            response.put("message", "Test case execution started");
            response.put("statusUrl", "/api/v1/test-status?jobId=" + jobId);
            response.put("monitorUrl", "/test-runner.html?jobId=" + jobId + "&featureFile=" + featureFile);
            
            return ResponseEntity.accepted().body(response);
        }
        
        Map<String, String> errorResponse = new HashMap<>();
        errorResponse.put("status", "error");
        errorResponse.put("message", "Invalid Feature File.");
        return ResponseEntity.badRequest().body(errorResponse);
    }

    @GetMapping("/test-status")
    public ResponseEntity<TestExecutionStatus> getTestStatus(@RequestParam(name = "jobId", required = true) String jobId) {
        TestExecutionStatus status = statusService.getStatus(jobId);
        if (status == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(status);
    }

    /**
     * Lists all TeacherSide test cases (feature files) with their names and paths.
     */
    @GetMapping(value = "/teacher-testcases", produces = org.springframework.http.MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<Map<String, String>>> listTeacherTestCases() {
        Map<String, String> cases = automationService.getAllTeacherSideTestCases();
        List<Map<String, String>> response = new ArrayList<>();

        cases.forEach((name, path) -> {
            Map<String, String> entry = new HashMap<>();
            entry.put("name", name);
            entry.put("path", path);
            response.add(entry);
        });

        return ResponseEntity.ok(response);
    }

    /**
     * HTML view of TeacherSide test cases with clickable links that execute in a new tab.
     */
    @GetMapping(value = "/teacher-testcases/html", produces = MediaType.TEXT_HTML_VALUE)
    public ResponseEntity<String> listTeacherTestCasesHtml() {
        Map<String, String> cases = automationService.getAllTeacherSideTestCases();

        StringBuilder html = new StringBuilder();
        html.append("""
                <!DOCTYPE html>
                <html lang="en">
                <head>
                    <meta charset="UTF-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1.0">
                    <title>TeacherSide Test Cases</title>
                    <style>
                        body { font-family: "Segoe UI", Tahoma, sans-serif; background: #f5f6fb; margin: 0; padding: 0; }
                        header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: #fff; padding: 18px 24px; }
                        h1 { margin: 0; font-size: 20px; }
                        .container { max-width: 1000px; margin: 24px auto; background: #fff; border-radius: 12px; box-shadow: 0 6px 18px rgba(0,0,0,0.08); padding: 20px; }
                        ul { list-style: none; padding: 0; margin: 0; }
                        li { padding: 12px 16px; border-bottom: 1px solid #eef1f7; transition: background-color 0.2s; }
                        li:hover { background-color: #f9fafb; }
                        li:last-child { border-bottom: none; }
                        a { color: #4c51bf; text-decoration: none; font-weight: 600; font-size: 16px; transition: color 0.2s; }
                        a:hover { color: #667eea; text-decoration: underline; }
                    </style>
                </head>
                <body>
                    <header><h1>TeacherSide Test Cases</h1></header>
                    <div class="container">
                        <ul>
                """);

        cases.forEach((name, path) -> {
            String encodedName = java.net.URLEncoder.encode(name, java.nio.charset.StandardCharsets.UTF_8);
            html.append("<li>");
            html.append("<a target=\"_blank\" href=\"/api/v1/specific-testcase?featureFile=").append(encodedName).append("\">").append(name).append("</a>");
            html.append("</li>");
        });

        html.append("""
                        </ul>
                    </div>
                </body>
                </html>
                """);

        return ResponseEntity.ok(html.toString());
    }

    /**
     * Get browser pool statistics
     * GET /api/v1/browser-pool-stats
     */
    @GetMapping("/browser-pool-stats")
    public ResponseEntity<Map<String, Object>> getBrowserPoolStats() {
        Map<String, Object> stats = browserPoolManager.getPoolStats();
        return ResponseEntity.ok(stats);
    }

    /**
     * Get active threads information
     * GET /api/v1/threads
     */
    @GetMapping("/threads")
    public ResponseEntity<Map<String, Object>> getActiveThreads() {
        Map<String, Object> threadInfo = new HashMap<>();
        
        // Get all threads
        ThreadMXBean threadMXBean = ManagementFactory.getThreadMXBean();
        ThreadInfo[] threadInfos = threadMXBean.dumpAllThreads(false, false);
        
        // Thread statistics
        Map<String, Object> stats = new HashMap<>();
        stats.put("totalThreads", threadMXBean.getThreadCount());
        stats.put("peakThreadCount", threadMXBean.getPeakThreadCount());
        stats.put("daemonThreads", threadMXBean.getDaemonThreadCount());
        stats.put("startedThreads", threadMXBean.getTotalStartedThreadCount());
        threadInfo.put("statistics", stats);
        
        // Group threads by state
        Map<String, Integer> threadsByState = new HashMap<>();
        Map<String, Integer> threadsByType = new HashMap<>();
        
        List<Map<String, Object>> threadDetails = new ArrayList<>();
        
        for (ThreadInfo info : threadInfos) {
            // Count by state
            String state = info.getThreadState().toString();
            threadsByState.put(state, threadsByState.getOrDefault(state, 0) + 1);
            
            // Count by type (based on thread name patterns)
            String threadName = info.getThreadName();
            String threadType = categorizeThread(threadName);
            threadsByType.put(threadType, threadsByType.getOrDefault(threadType, 0) + 1);
            
            // Thread details
            Map<String, Object> detail = new HashMap<>();
            detail.put("id", info.getThreadId());
            detail.put("name", threadName);
            detail.put("state", state);
            detail.put("type", threadType);
            // Check if thread is daemon by finding the actual Thread object
            boolean isDaemon = false;
            try {
                Thread thread = findThreadById(info.getThreadId());
                if (thread != null) {
                    isDaemon = thread.isDaemon();
                }
            } catch (Exception e) {
                // If we can't determine, default to false
            }
            detail.put("daemon", isDaemon);
            detail.put("blockedCount", info.getBlockedCount());
            detail.put("waitedCount", info.getWaitedCount());
            detail.put("cpuTime", threadMXBean.getThreadCpuTime(info.getThreadId()));
            detail.put("userTime", threadMXBean.getThreadUserTime(info.getThreadId()));
            
            // Stack trace (first few lines)
            if (info.getStackTrace().length > 0) {
                List<String> stackTrace = new ArrayList<>();
                int maxLines = Math.min(5, info.getStackTrace().length);
                for (int i = 0; i < maxLines; i++) {
                    stackTrace.add(info.getStackTrace()[i].toString());
                }
                detail.put("stackTrace", stackTrace);
            }
            
            threadDetails.add(detail);
        }
        
        threadInfo.put("threadsByState", threadsByState);
        threadInfo.put("threadsByType", threadsByType);
        threadInfo.put("threadDetails", threadDetails);
        
        // Tomcat thread pool info (if available)
        try {
            RuntimeMXBean runtimeMXBean = ManagementFactory.getRuntimeMXBean();
            Map<String, Object> jvmInfo = new HashMap<>();
            jvmInfo.put("uptime", runtimeMXBean.getUptime());
            jvmInfo.put("name", runtimeMXBean.getVmName());
            jvmInfo.put("version", runtimeMXBean.getVmVersion());
            threadInfo.put("jvmInfo", jvmInfo);
        } catch (Exception e) {
            // Ignore
        }
        
        return ResponseEntity.ok(threadInfo);
    }
    
    /**
     * Find Thread object by thread ID
     */
    private Thread findThreadById(long threadId) {
        ThreadGroup rootGroup = Thread.currentThread().getThreadGroup();
        while (rootGroup.getParent() != null) {
            rootGroup = rootGroup.getParent();
        }
        
        Thread[] threads = new Thread[rootGroup.activeCount() * 2];
        int count = rootGroup.enumerate(threads, true);
        
        for (int i = 0; i < count; i++) {
            if (threads[i] != null && threads[i].getId() == threadId) {
                return threads[i];
            }
        }
        return null;
    }
    
    /**
     * Categorize thread by name pattern
     */
    private String categorizeThread(String threadName) {
        if (threadName == null) return "Unknown";
        
        if (threadName.contains("http-nio") || threadName.contains("tomcat")) {
            return "Tomcat";
        } else if (threadName.contains("TestNG") || threadName.contains("test")) {
            return "TestNG";
        } else if (threadName.contains("pool") || threadName.contains("executor")) {
            return "ThreadPool";
        } else if (threadName.contains("selenium") || threadName.contains("chrome")) {
            return "Selenium";
        } else if (threadName.contains("main")) {
            return "Main";
        } else if (threadName.contains("GC") || threadName.contains("Finalizer")) {
            return "JVM";
        } else if (threadName.contains("Async")) {
            return "Async";
        } else {
            return "Other";
        }
    }

}