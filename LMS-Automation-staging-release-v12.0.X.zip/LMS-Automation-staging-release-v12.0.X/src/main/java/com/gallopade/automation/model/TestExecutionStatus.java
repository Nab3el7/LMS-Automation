package com.gallopade.automation.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TestExecutionStatus {
    private String jobId;
    private String featureFile;
    private Status status;
    private String message;
    private String reportUrl;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private Long executionTimeSeconds;
    private Long estimatedExecutionTimeSeconds; // Estimated time for full suite execution
    private String errorMessage;
    @Builder.Default
    private List<String> logs = new ArrayList<>();

    public enum Status {
        QUEUED("Test case queued for execution"),
        RUNNING("Test case is running"),
        GENERATING_REPORT("Generating test report"),
        UPLOADING_REPORT("Uploading report to Azure"),
        COMPLETED("Test execution completed successfully"),
        FAILED("Test execution failed");

        private final String description;

        Status(String description) {
            this.description = description;
        }

        public String getDescription() {
            return description;
        }
    }
}

