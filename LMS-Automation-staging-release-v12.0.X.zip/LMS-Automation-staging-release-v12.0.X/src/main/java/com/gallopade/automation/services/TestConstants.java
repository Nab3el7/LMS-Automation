package com.gallopade.automation.services;

import java.util.HashMap;
import java.util.Map;

public class TestConstants {
    public static Map<String, String> TestCasesPath() {
        Map<String, String> testCaseFileMap = new HashMap<>();
//        testCaseFileMap.put("AssignmentModuleAssignmentFilter", "src/test/resources/Features/TeacherSide/AssignmentsModule/AssignmentModuleDashboard/AssignmentModuleAssignmentFilter.feature");
        return testCaseFileMap;
    }
}
