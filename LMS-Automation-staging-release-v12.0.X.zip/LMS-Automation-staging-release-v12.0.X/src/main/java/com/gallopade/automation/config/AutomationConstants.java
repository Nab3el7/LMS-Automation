package com.gallopade.automation.config;

/**
 * Centralized constants for automation framework
 * Replace all magic numbers and hardcoded values with constants from this class
 */
public class AutomationConstants {
    
    // ==================== Browser Configuration ====================
    
    /**
     * Maximum number of concurrent browsers in the pool
     */
    public static final int MAX_BROWSERS = 2;
    
    /**
     * Maximum retries for dead queue items
     */
    public static final int MAX_DEAD_QUEUE_RETRIES = 1;
    
    // ==================== Selenium Grid Configuration ====================
    
    /**
     * Selenium Grid URLs to try (in order)
     */
    public static final String[] GRID_URLS = {
        "http://selenium-standalone:4444",  // Selenium 4.x Grid endpoint (same namespace)
        "http://selenium-standalone:4444/wd/hub",  // Legacy endpoint (same namespace)
        // Note: Namespace-specific URLs commented out - uncomment if needed
        // "http://selenium-standalone.gallopade-staging:4444",
        // "http://selenium-standalone.gallopade-staging:4444/wd/hub",
        // "http://selenium-standalone.gallopade-staging.svc.cluster.local:4444",
        // "http://selenium-standalone.gallopade-staging.svc.cluster.local:4444/wd/hub"
    };
    
    /**
     * Maximum retries for Grid connection
     */
    public static final int MAX_GRID_RETRIES = 2;
    
    /**
     * Delay between retry attempts (milliseconds)
     */
    public static final long RETRY_DELAY_MS = 5000;
    
    /**
     * Delay when Grid appears full (milliseconds)
     */
    public static final long GRID_FULL_RETRY_DELAY_MS = 10000;
    
    /**
     * Delay after browser quit for Grid cleanup (milliseconds)
     */
    public static final long GRID_CLEANUP_DELAY_MS = 500;
    
    // ==================== WebDriver Timeouts ====================
    
    /**
     * Implicit wait timeout (seconds)
     */
    public static final int IMPLICIT_WAIT_SECONDS = 30;
    
    /**
     * Page load timeout (seconds)
     */
    public static final int PAGE_LOAD_TIMEOUT_SECONDS = 300; // 5 minutes
    
    /**
     * Script timeout (seconds)
     */
    public static final int SCRIPT_TIMEOUT_SECONDS = 30;
    
    // ==================== Test Execution Configuration ====================
    
    /**
     * Average execution time per feature (seconds)
     */
    public static final long AVG_TIME_PER_FEATURE_SECONDS = 150; // 2.5 minutes
    
    /**
     * Parallel execution factor (number of parallel browsers)
     */
    public static final long PARALLEL_FACTOR = 2;
    
    /**
     * Buffer percentage for execution time estimation
     */
    public static final double EXECUTION_TIME_BUFFER_PERCENT = 0.2; // 20%
    
    // ==================== Wait Timeouts ====================
    
    /**
     * Default wait timeout for explicit waits (seconds)
     */
    public static final int DEFAULT_WAIT_TIMEOUT_SECONDS = 10;
    
    /**
     * Long wait timeout for slow operations (seconds)
     */
    public static final int LONG_WAIT_TIMEOUT_SECONDS = 30;
    
    /**
     * Short wait timeout for quick operations (seconds)
     */
    public static final int SHORT_WAIT_TIMEOUT_SECONDS = 5;
    
    // ==================== Grid Connectivity ====================
    
    /**
     * TCP connection timeout for Grid reachability check (milliseconds)
     */
    public static final int GRID_REACHABILITY_TIMEOUT_MS = 2000;
    
    /**
     * HTTP health check timeout (milliseconds)
     */
    public static final int GRID_HEALTH_CHECK_TIMEOUT_MS = 3000;
    
    // ==================== File Paths ====================
    
    /**
     * Default screenshot directory
     */
    public static final String SCREENSHOT_DIRECTORY = System.getProperty("user.dir") + "/Screenshot";
    
    /**
     * Default report path
     */
    public static final String DEFAULT_REPORT_PATH = "src/test/resources/Reports/Manual_Automation_Run_Report.html";
    
    // ==================== Private Constructor ====================
    
    /**
     * Private constructor to prevent instantiation
     */
    private AutomationConstants() {
        throw new UnsupportedOperationException("Constants class - cannot be instantiated");
    }
}

