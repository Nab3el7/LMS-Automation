package com.gallopade.automation.services;

import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.springframework.stereotype.Service;

import java.net.URL;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.*;

@Slf4j
@Service
public class BrowserPoolManager {
    
    private static final int MAX_BROWSERS = 2;
    private static final int MAX_DEAD_QUEUE_RETRIES = 1; // Max retries for dead queue items (1 retry)
    private final BlockingQueue<WebDriver> availableBrowsers;
    private final Set<WebDriver> activeBrowsers;
    private final BlockingQueue<BrowserInitTask> deadQueue; // Queue for failed browser initializations
    private final ExecutorService browserInitializer;
    private final Semaphore browserSemaphore;
    private volatile boolean isShutdown = false;
    
    /**
     * Represents a failed browser initialization task
     */
    private static class BrowserInitTask {
        final long timestamp;
        int retryCount;
        final String threadName;
        
        BrowserInitTask(String threadName) {
            this.timestamp = System.currentTimeMillis();
            this.retryCount = 0;
            this.threadName = threadName;
        }
        
        void incrementRetry() {
            retryCount++;
        }
        
        boolean shouldRetry() {
            return retryCount < MAX_DEAD_QUEUE_RETRIES;
        }
    }
    
    public BrowserPoolManager() {
        this.availableBrowsers = new LinkedBlockingQueue<>(MAX_BROWSERS);
        this.activeBrowsers = ConcurrentHashMap.newKeySet();
        this.deadQueue = new LinkedBlockingQueue<>();
        this.browserSemaphore = new Semaphore(MAX_BROWSERS, true);
        this.browserInitializer = Executors.newFixedThreadPool(MAX_BROWSERS);
        
        // Pre-initialize browsers in background
        initializeBrowserPool();
    }
    
    /**
     * Initialize browser pool with 10 browsers
     * Uses lazy initialization - browsers are created on-demand rather than all at startup
     */
    private void initializeBrowserPool() {
        log.info("Browser pool manager initialized. Browsers will be created on-demand (max {} concurrent)", MAX_BROWSERS);
        
        // Don't pre-initialize all browsers - create them on-demand to avoid connection issues
        // This allows the pool to work even if Selenium Grid isn't ready at startup
        log.info("Browser pool ready. Browsers will be created when tests request them.");
    }
    
    /**
     * Get an available browser from the pool
     * Blocks until a browser is available
     */
    public WebDriver acquireBrowser() throws InterruptedException {
        if (isShutdown) {
            throw new IllegalStateException("Browser pool is shutdown");
        }
        
        String threadName = Thread.currentThread().getName();
        
        // Acquire semaphore (blocks if all 10 browsers are in use)
        browserSemaphore.acquire();
        
        try {
            // Try to get an existing browser from pool
            WebDriver browser = availableBrowsers.poll(5, TimeUnit.SECONDS);
            
            if (browser != null && isBrowserValid(browser)) {
                log.debug("Acquired existing browser from pool. Available: {}", availableBrowsers.size());
                return browser;
            }
            
            // If no valid browser available, create a new one
            log.info("No available browser in pool, creating new browser for thread: {}", threadName);
            WebDriver newBrowser = createBrowser();
            
            if (newBrowser != null) {
                activeBrowsers.add(newBrowser);
                log.info("Created new browser for thread: {}. Total active: {}", threadName, activeBrowsers.size());
                return newBrowser;
            } else {
                // Browser creation failed - add to dead queue
                log.warn("Browser creation failed for thread: {}. Adding to dead queue for retry.", threadName);
                BrowserInitTask failedTask = new BrowserInitTask(threadName);
                deadQueue.offer(failedTask);
                
                // Release semaphore since we didn't get a browser
                browserSemaphore.release();
                
                // Return null - caller should handle this
                return null;
            }
            
        } catch (Exception e) {
            browserSemaphore.release(); // Release semaphore on error
            log.error("Error acquiring browser for thread {}: {}", threadName, e.getMessage(), e);
            
            // Add to dead queue for retry
            BrowserInitTask failedTask = new BrowserInitTask(threadName);
            deadQueue.offer(failedTask);
            
            throw new RuntimeException("Failed to acquire browser", e);
        }
    }
    
    /**
     * Return browser to the pool for reuse
     * Also processes dead queue when browser becomes available
     * 
     * NOTE: For Grid sessions, we should quit instead of reusing to prevent session leaks
     */
    public void releaseBrowser(WebDriver browser) {
        if (browser == null || isShutdown) {
            return;
        }
        
        try {
            // For RemoteWebDriver (Grid), always quit to free Grid session
            // Reusing Grid sessions can cause "Could not start a new session" errors
            if (browser instanceof org.openqa.selenium.remote.RemoteWebDriver) {
                String sessionId = null;
                try {
                    sessionId = ((org.openqa.selenium.remote.RemoteWebDriver) browser).getSessionId().toString();
                } catch (Exception e) {
                    // Session ID not available
                }
                
                log.info("Quitting RemoteWebDriver to free Grid session{}", 
                        sessionId != null ? " (session: " + sessionId + ")" : "");
                closeBrowser(browser);
                
                // Small delay to allow Grid to clean up the session
                try {
                    Thread.sleep(500); // 500ms delay for Grid session cleanup
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
                
                // Create replacement browser in background if needed
                createReplacementBrowser();
                processDeadQueue();
                
                browserSemaphore.release();
                return;
            }
            
            // For local ChromeDriver, can reuse
            // Clean up browser state
            browser.manage().deleteAllCookies();
            
            // Check if browser is still valid
            if (isBrowserValid(browser)) {
                // Return to pool
                if (availableBrowsers.offer(browser)) {
                    log.debug("Browser returned to pool. Available: {}", availableBrowsers.size());
                    
                    // Process dead queue when browser becomes available
                    processDeadQueue();
                } else {
                    log.warn("Pool is full, closing browser");
                    closeBrowser(browser);
                }
            } else {
                log.warn("Browser is invalid, closing instead of returning to pool");
                closeBrowser(browser);
                // Create replacement browser in background
                createReplacementBrowser();
                
                // Also process dead queue
                processDeadQueue();
            }
        } catch (Exception e) {
            log.error("Error releasing browser: {}", e.getMessage(), e);
            closeBrowser(browser);
            createReplacementBrowser();
            processDeadQueue();
        } finally {
            browserSemaphore.release();
        }
    }
    
    /**
     * Process dead queue - retry failed browser initializations when browsers are available
     */
    private void processDeadQueue() {
        if (deadQueue.isEmpty()) {
            return;
        }
        
        // Only process if we have available browser slots
        if (browserSemaphore.availablePermits() > 0 && availableBrowsers.size() < MAX_BROWSERS) {
            BrowserInitTask task = deadQueue.poll();
            if (task != null) {
                if (task.shouldRetry()) {
                    task.incrementRetry();
                    log.info("Processing dead queue item for thread: {} (retry {}/{})", 
                            task.threadName, task.retryCount, MAX_DEAD_QUEUE_RETRIES);
                    
                    // Retry browser creation in background
                    browserInitializer.submit(() -> {
                        try {
                            WebDriver browser = createBrowser();
                            if (browser != null) {
                                availableBrowsers.offer(browser);
                                activeBrowsers.add(browser);
                                log.info("Successfully created browser from dead queue for thread: {}. Available: {}", 
                                        task.threadName, availableBrowsers.size());
                            } else {
                                // Still failed, add back to dead queue if retries left
                                if (task.shouldRetry()) {
                                    deadQueue.offer(task);
                                    log.warn("Browser creation still failed for thread: {}. Will retry again later.", 
                                            task.threadName);
                                } else {
                                    log.error("Browser creation failed after {} retries for thread: {}. Giving up.", 
                                            MAX_DEAD_QUEUE_RETRIES, task.threadName);
                                }
                            }
                        } catch (Exception e) {
                            log.error("Error processing dead queue item for thread {}: {}", 
                                    task.threadName, e.getMessage(), e);
                            // Add back to queue if retries left
                            if (task.shouldRetry()) {
                                deadQueue.offer(task);
                            }
                        }
                    });
                } else {
                    log.error("Dead queue item for thread: {} exceeded max retries ({}). Discarding.", 
                            task.threadName, MAX_DEAD_QUEUE_RETRIES);
                }
            }
        }
    }
    
    /**
     * Create a new browser instance with retry logic
     */
    private WebDriver createBrowser() {
        ChromeOptions chromeOptions = getChromeOptions();
        boolean isLocal = isLocalProfile();
        
        if (isLocal) {
            try {
                log.info("Creating local ChromeDriver");
                System.setProperty("webdriver.chrome.driver", "src/test/resources/drivers/chromedriver");
                ChromeDriver driver = new ChromeDriver(chromeOptions);
                configureDriver(driver);
                return driver;
            } catch (Exception e) {
                log.error("Failed to create local ChromeDriver: {}", e.getMessage(), e);
                return null;
            }
        } else {
            // Remote WebDriver with retry logic
            return createRemoteWebDriverWithRetry(chromeOptions);
        }
    }
    
    /**
     * Create RemoteWebDriver with retry logic for Selenium 4.1
     * Supports both Selenium 4.x Grid endpoints and legacy /wd/hub endpoints
     */
    private WebDriver createRemoteWebDriverWithRetry(ChromeOptions chromeOptions) {
        // Try multiple service name formats for Kubernetes
        // Selenium 4.x supports both new Grid endpoints and legacy /wd/hub for compatibility
        String[] seleniumHubUrls = {
            "http://selenium-standalone:4444",  // Selenium 4.x Grid endpoint (same namespace)
            "http://selenium-standalone:4444/wd/hub",  // Legacy endpoint (same namespace)
            // "http://selenium-standalone.gallopade-staging:4444",  // Selenium 4.x Grid (with namespace)
            // "http://selenium-standalone.gallopade-staging:4444/wd/hub",  // Legacy (with namespace)
            // "http://selenium-standalone.gallopade-staging.svc.cluster.local:4444",  // Selenium 4.x Grid (FQDN)
            // "http://selenium-standalone.gallopade-staging.svc.cluster.local:4444/wd/hub"  // Legacy (FQDN)
        };
        
        int maxRetries = 2; // 2 retries (3 total attempts: initial + 2 retries)
        int retryDelay = 5000; // 5 seconds
        Exception lastException = null;
        String lastAttemptedUrl = seleniumHubUrls[0];
        int totalAttempts = 0;
        
        log.info("Attempting to connect to Selenium Grid (Selenium 4.1) - will try {} URL formats with {} retries each", 
                seleniumHubUrls.length, maxRetries);
        
        // Set HTTP client factory for Selenium 4.x (set once before all attempts)
        System.setProperty("webdriver.http.factory", "jdk-http-client");
        
        // Try each URL format with fallback to previous URL
        String previousUrl = null;
        for (int urlIndex = 0; urlIndex < seleniumHubUrls.length; urlIndex++) {
            String seleniumHubUrl = seleniumHubUrls[urlIndex];
            lastAttemptedUrl = seleniumHubUrl;
            
            // Quick connectivity check before attempting session creation
            if (!isGridReachable(seleniumHubUrl)) {
                log.warn("Grid not reachable at {}, trying previous URL if available...", seleniumHubUrl);
                // If previous URL exists and current URL fails, retry with previous URL
                if (previousUrl != null) {
                    log.info("Retrying with previous URL: {}", previousUrl);
                    seleniumHubUrl = previousUrl;
                } else {
                    continue; // Try next URL format
                }
            }
            
            for (int attempt = 1; attempt <= maxRetries; attempt++) {
                totalAttempts++;
                try {
                    log.info("Creating RemoteWebDriver - attempt {}/{} (total: {}) to {} (Selenium 4.1)", 
                            attempt, maxRetries, totalAttempts, seleniumHubUrl);
                    
                    // For Selenium 4.x, we set timeouts via driver.manage().timeouts() after creation
                    // Timeouts will be configured in configureDriver() method
                    
                    // Create RemoteWebDriver (Selenium 4.x API)
                    // Selenium 4.x automatically handles both new Grid and legacy endpoints
                    java.net.URL url = new URL(seleniumHubUrl);
                    
                    RemoteWebDriver driver = new RemoteWebDriver(url, chromeOptions);
                    
                    // Configure timeouts using Selenium 4.x Timeouts interface
                    configureDriver(driver);
                    
                    log.info("✅ RemoteWebDriver created successfully with session ID: {} using URL: {} (Selenium 4.1)", 
                            driver.getSessionId(), seleniumHubUrl);
                    return driver;
                    
                } catch (Exception e) {
                    lastException = e;
                    String errorDetails = extractErrorDetails(e);
                    log.warn("❌ RemoteWebDriver creation attempt {}/{} to {} failed: {} - {}", 
                            attempt, maxRetries, seleniumHubUrl, e.getClass().getSimpleName(), errorDetails);
                    
                    // Check if error is due to Grid being full (no slots available)
                    if (e.getMessage() != null && e.getMessage().contains("Could not start a new session")) {
                        log.warn("Grid session creation failed - may be due to no available slots");
                        log.warn("This can happen if previous sessions weren't properly closed");
                        log.warn("Waiting longer before retry to allow Grid to free up sessions...");
                        
                        // Wait longer if Grid is full (10 seconds instead of 5)
                        if (attempt < maxRetries) {
                            try {
                                Thread.sleep(10000); // 10 seconds for Grid to free up
                            } catch (InterruptedException ie) {
                                Thread.currentThread().interrupt();
                                log.error("Retry interrupted");
                                break;
                            }
                            continue; // Skip the normal retry delay
                        }
                    }
                    
                    // If this is the last attempt for current URL and previous URL exists, try previous URL
                    if (attempt == maxRetries && previousUrl != null && seleniumHubUrl != previousUrl) {
                        log.info("Current URL failed, retrying with previous URL: {}", previousUrl);
                        seleniumHubUrl = previousUrl;
                        attempt = 0; // Reset attempt counter to retry with previous URL
                        try {
                            Thread.sleep(retryDelay);
                        } catch (InterruptedException ie) {
                            Thread.currentThread().interrupt();
                            log.error("Retry interrupted");
                            break;
                        }
                        continue;
                    }
                    
                    if (attempt < maxRetries) {
                        log.info("Retrying in {} seconds...", retryDelay / 1000);
                        try {
                            Thread.sleep(retryDelay);
                        } catch (InterruptedException ie) {
                            Thread.currentThread().interrupt();
                            log.error("Retry interrupted");
                            break;
                        }
                    }
                }
            }
            
            // If we got here, all retries for this URL failed
            // Store current URL as previous for next iteration
            previousUrl = seleniumHubUrls[urlIndex];
            
            // Try next URL format
            if (urlIndex < seleniumHubUrls.length - 1) {
                log.warn("All {} retries failed for {}, trying next URL format...", maxRetries, seleniumHubUrls[urlIndex]);
            }
        }
        
        // All URLs and retries failed
        String errorMsg = String.format(
            "❌ Failed to create RemoteWebDriver after %d total attempts (%d retries × %d URL formats). " +
            "Last attempted URL: %s. " +
            "Please verify that selenium-standalone service is running and accessible in namespace 'gallopade-staging'. " +
            "Last error: %s",
            totalAttempts, maxRetries, seleniumHubUrls.length, lastAttemptedUrl,
            lastException != null ? lastException.getMessage() : "Unknown error"
        );
        log.error(errorMsg);
        if (lastException != null) {
            log.error("Full exception stack trace:", lastException);
        }
        
        // Log diagnostic information
        logDiagnosticInfo();
        
        return null;
    }
    
    /**
     * Extract meaningful error details from exception
     */
    private String extractErrorDetails(Exception e) {
        String message = e.getMessage();
        StringBuilder details = new StringBuilder();
        
        if (message != null) {
            // Extract host info if present
            if (message.contains("Host info:")) {
                details.append(message);
            } else if (message.contains("Could not start a new session")) {
                details.append(message);
            } else {
                details.append(message);
            }
        }
        
        // Add cause information if available
        Throwable cause = e.getCause();
        if (cause != null && cause.getMessage() != null) {
            if (details.length() > 0) details.append(" | ");
            details.append("Cause: ").append(cause.getMessage());
        }
        
        // Check for specific connection error types
        if (e instanceof java.net.ConnectException) {
            details.append(" | Connection refused - Grid may not be running");
        } else if (e instanceof java.net.SocketTimeoutException) {
            details.append(" | Connection timeout - Grid may be slow to respond");
        } else if (e instanceof org.openqa.selenium.SessionNotCreatedException) {
            details.append(" | Session creation failed - Grid may be overloaded or browser unavailable");
        }
        
        return details.length() > 0 ? details.toString() : e.getClass().getSimpleName() + ": No details";
    }
    
    /**
     * Log diagnostic information for troubleshooting
     */
    private void logDiagnosticInfo() {
        try {
            String hostname = java.net.InetAddress.getLocalHost().getHostName();
            String hostAddress = java.net.InetAddress.getLocalHost().getHostAddress();
            log.info("Diagnostic Info - Hostname: {}, IP: {}", hostname, hostAddress);
            log.info("Diagnostic Info - Pod: {}", System.getenv("HOSTNAME"));
            log.info("Diagnostic Info - Namespace: {}", System.getenv("POD_NAMESPACE"));
            
            // Try to resolve selenium-standalone DNS
            try {
                java.net.InetAddress addr = java.net.InetAddress.getByName("selenium-standalone");
                log.info("DNS Resolution - selenium-standalone resolves to: {}", addr.getHostAddress());
            } catch (Exception e) {
                log.warn("DNS Resolution - Could not resolve selenium-standalone: {}", e.getMessage());
            }
            
            // Try with namespace
            try {
                java.net.InetAddress addr = java.net.InetAddress.getByName("selenium-standalone.gallopade-staging");
                log.info("DNS Resolution - selenium-standalone.gallopade-staging resolves to: {}", addr.getHostAddress());
            } catch (Exception e) {
                log.warn("DNS Resolution - Could not resolve selenium-standalone.gallopade-staging: {}", e.getMessage());
            }
        } catch (Exception e) {
            log.warn("Could not gather diagnostic info: {}", e.getMessage());
        }
    }
    
    /**
     * Quick check if Grid endpoint is reachable (TCP connection test)
     */
    private boolean isGridReachable(String hubUrl) {
        try {
            // Extract host and port from URL
            java.net.URL url = new java.net.URL(hubUrl);
            String host = url.getHost();
            int port = url.getPort() > 0 ? url.getPort() : 4444;
            
            // Try TCP connection (quick check)
            try (java.net.Socket socket = new java.net.Socket()) {
                socket.connect(new java.net.InetSocketAddress(host, port), 2000); // 2 second timeout
                socket.close();
                log.debug("Grid endpoint {}:{} is reachable", host, port);
                return true;
            }
        } catch (java.net.ConnectException e) {
            log.debug("Grid endpoint {} not reachable: {}", hubUrl, e.getMessage());
            return false;
        } catch (java.net.SocketTimeoutException e) {
            log.debug("Grid endpoint {} connection timeout: {}", hubUrl, e.getMessage());
            return false;
        } catch (Exception e) {
            log.debug("Grid endpoint {} check failed: {}", hubUrl, e.getMessage());
            return false;
        }
    }
    
    /**
     * Check if Selenium Grid is healthy/accessible via HTTP status endpoint
     * Available for manual health checks or diagnostics
     */
    @SuppressWarnings("unused")
    private boolean checkSeleniumGridHealth(String hubUrl) {
        try {
            // For Selenium 4.x, try both /status and /wd/hub/status
            String[] statusUrls = {
                hubUrl.replace("/wd/hub", "") + "/status",  // Selenium 4.x endpoint
                hubUrl.replace("/wd/hub", "/status"),      // Legacy endpoint
                hubUrl + "/status"                          // If no /wd/hub in URL
            };
            
            for (String statusUrl : statusUrls) {
                try {
                    java.net.URL url = new java.net.URL(statusUrl);
                    java.net.HttpURLConnection connection = (java.net.HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("GET");
                    connection.setConnectTimeout(3000); // Shorter timeout for health check
                    connection.setReadTimeout(3000);
                    connection.setRequestProperty("Connection", "close");
                    
                    connection.connect();
                    
                    int responseCode = connection.getResponseCode();
                    connection.disconnect();
                    
                    if (responseCode == 200) {
                        log.info("Selenium Grid health check passed (HTTP {}) for {}", responseCode, hubUrl);
                        return true;
                    }
                } catch (Exception e) {
                    // Try next status URL format
                    continue;
                }
            }
            
            log.debug("Selenium Grid health check failed for {}", hubUrl);
            return false;
        } catch (Exception e) {
            log.debug("Selenium Grid health check failed for {}: {}", hubUrl, e.getMessage());
            return false;
        }
    }
    
    /**
     * Configure driver settings using Selenium 4.x APIs
     */
    private void configureDriver(WebDriver driver) {
        driver.manage().window().maximize();
        driver.manage().deleteAllCookies();
        
        // Selenium 4.x uses Duration API for timeouts
        driver.manage().timeouts().implicitlyWait(java.time.Duration.ofSeconds(30));
        driver.manage().timeouts().pageLoadTimeout(java.time.Duration.ofSeconds(300)); // 5 minutes for page loads
        driver.manage().timeouts().scriptTimeout(java.time.Duration.ofSeconds(30)); // Script timeout
    }
    
    /**
     * Check if browser is still valid
     */
    private boolean isBrowserValid(WebDriver browser) {
        try {
            browser.getWindowHandles();
            return true;
        } catch (Exception e) {
            return false;
        }
    }
    
    /**
     * Close browser and remove from active set
     */
    private void closeBrowser(WebDriver browser) {
        try {
            if (browser != null) {
                browser.quit();
                activeBrowsers.remove(browser);
                log.debug("Browser closed. Active browsers: {}", activeBrowsers.size());
            }
        } catch (Exception e) {
            log.error("Error closing browser: {}", e.getMessage());
            activeBrowsers.remove(browser);
        }
    }
    
    /**
     * Create replacement browser in background
     */
    private void createReplacementBrowser() {
        browserInitializer.submit(() -> {
            try {
                WebDriver browser = createBrowser();
                if (browser != null) {
                    availableBrowsers.offer(browser);
                    activeBrowsers.add(browser);
                    log.info("Replacement browser created. Available: {}", availableBrowsers.size());
                }
            } catch (Exception e) {
                log.error("Failed to create replacement browser: {}", e.getMessage(), e);
            }
        });
    }
    
    /**
     * Get Chrome options for Selenium 4.x
     */
    private ChromeOptions getChromeOptions() {
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--remote-allow-origins=*");
        options.addArguments("--headless");
        options.addArguments("--no-sandbox");
        options.addArguments("--disable-dev-shm-usage");
        
        // For Selenium 4.x, timeouts are set via driver.manage().timeouts() after driver creation
        // No need to set timeout capabilities here - they'll be configured in configureDriver()
        
        return options;
    }
    
    /**
     * Check if running in local profile
     */
    private boolean isLocalProfile() {
        try {
            java.util.Properties props = new java.util.Properties();
            java.io.InputStream stream = getClass().getClassLoader()
                    .getResourceAsStream("application.properties");
            if (stream != null) {
                props.load(stream);
                stream.close();
            }
            String profile = props.getProperty("spring.profiles.active", "local");
            return "local".equalsIgnoreCase(profile);
        } catch (Exception e) {
            return false; // Default to remote
        }
    }
    
    /**
     * Get pool statistics
     */
    public Map<String, Object> getPoolStats() {
        Map<String, Object> stats = new java.util.HashMap<>();
        stats.put("maxBrowsers", MAX_BROWSERS);
        stats.put("availableBrowsers", availableBrowsers.size());
        stats.put("activeBrowsers", activeBrowsers.size());
        stats.put("inUseBrowsers", activeBrowsers.size() - availableBrowsers.size());
        stats.put("availablePermits", browserSemaphore.availablePermits());
        stats.put("deadQueueSize", deadQueue.size());
        
        // Dead queue details
        if (!deadQueue.isEmpty()) {
            java.util.List<Map<String, Object>> deadQueueItems = new java.util.ArrayList<>();
            for (BrowserInitTask task : deadQueue) {
                Map<String, Object> item = new java.util.HashMap<>();
                item.put("threadName", task.threadName);
                item.put("retryCount", task.retryCount);
                item.put("maxRetries", MAX_DEAD_QUEUE_RETRIES);
                item.put("timestamp", task.timestamp);
                item.put("ageSeconds", (System.currentTimeMillis() - task.timestamp) / 1000);
                deadQueueItems.add(item);
            }
            stats.put("deadQueueItems", deadQueueItems);
        }
        
        return stats;
    }
    
    /**
     * Shutdown browser pool
     */
    public void shutdown() {
        isShutdown = true;
        log.info("Shutting down browser pool...");
        
        // Close all browsers
        while (!availableBrowsers.isEmpty()) {
            closeBrowser(availableBrowsers.poll());
        }
        
        // Close active browsers
        for (WebDriver browser : activeBrowsers) {
            closeBrowser(browser);
        }
        
        browserInitializer.shutdown();
        try {
            if (!browserInitializer.awaitTermination(30, TimeUnit.SECONDS)) {
                browserInitializer.shutdownNow();
            }
        } catch (InterruptedException e) {
            browserInitializer.shutdownNow();
            Thread.currentThread().interrupt();
        }
        
        log.info("Browser pool shutdown complete");
    }
}

