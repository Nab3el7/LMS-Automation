package com.gallopade.automation.services;

import com.azure.storage.blob.BlobClient;
import com.azure.storage.blob.BlobContainerClient;
import com.azure.storage.blob.BlobContainerClientBuilder;
import com.azure.storage.common.StorageSharedKeyCredential;
import com.gallopade.automation.model.TestExecutionStatus;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.Stream;

@Slf4j
@Service
public class AutomationService {

    @Autowired
    private TestExecutionStatusService statusService;

    /**
     * Calculate estimated execution time for all TeacherSide test cases
     * Based on average execution time per feature (approximately 2-3 minutes per feature)
     */
    private long calculateEstimatedExecutionTime() {
        Map<String, String> testCases = getAllTeacherSideTestCases();
        int totalFeatures = testCases.size();
        
        // Average execution time per feature: 2.5 minutes (150 seconds)
        // With parallel execution (2 browsers), divide by 2
        // Add 20% buffer for report generation and overhead
        long avgTimePerFeature = 150; // seconds
        long parallelFactor = 2; // browsers (pool size)
        long estimatedTime = (totalFeatures * avgTimePerFeature) / parallelFactor;
        long buffer = (long) (estimatedTime * 0.2); // 20% buffer
        
        return estimatedTime + buffer;
    }
    
    @Async
    public CompletableFuture<Void> runTestsAsync(String jobId) {
        return CompletableFuture.runAsync(() -> {
            try {
                // Calculate estimated execution time
                long estimatedTime = calculateEstimatedExecutionTime();
                
                // Format estimated time for display
                long minutes = estimatedTime / 60;
                long seconds = estimatedTime % 60;
                String estimatedTimeMsg = String.format("Estimated execution time: %d minutes %d seconds", minutes, seconds);
                
                // Update status with estimated time
                statusService.updateStatus(jobId, TestExecutionStatus.Status.QUEUED, 
                    "Full test suite queued for execution. " + estimatedTimeMsg);
                
                // Set estimated time in status
                TestExecutionStatus executionStatus = statusService.getStatus(jobId);
                if (executionStatus != null) {
                    executionStatus.setEstimatedExecutionTimeSeconds(estimatedTime);
                }
                
                statusService.updateStatus(jobId, TestExecutionStatus.Status.RUNNING, 
                    "Full test suite is running. " + estimatedTimeMsg);
                
                // Run tests with local profile to use Docker Selenium Grid
                // The profile is read from application.properties (spring.profiles.active=local)
                String[] command = {"mvn", "test", "-DsuiteXmlFile=src/test/resources/testng.xml"};
                
                // Use ProcessBuilder for better control and to redirect stderr to stdout
                ProcessBuilder processBuilder = new ProcessBuilder(command);
                processBuilder.redirectErrorStream(true); // Merge stderr into stdout
                Process process = processBuilder.start();
                
                // Read output in a separate thread to avoid blocking
                ExecutorService executor = Executors.newSingleThreadExecutor();
                CompletableFuture<Void> outputReader = CompletableFuture.runAsync(() -> {
                    try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
                        String line;
                        while ((line = reader.readLine()) != null) {
                            System.out.println("Script output: " + line);
                            
                            // Capture ALL logs
                            statusService.addLog(jobId, line);
                            
                            // Check for browser installation error
                            if (line.contains("BROWSER NOT INSTALLED") || 
                                line.contains("Chrome/Chromium is not installed") ||
                                line.contains("BrowserNotInstalledException")) {
                                String errorMessage = "❌ Browser Not Installed: Chrome/Chromium is not installed on this server. " +
                                                    "Please install Chrome or Chromium before running test cases. " +
                                                    "Installation: sudo apt-get install google-chrome-stable";
                                statusService.setError(jobId, errorMessage);
                                log.error("Browser installation error detected for job {}: {}", jobId, errorMessage);
                            }
                            
                            // Check for Grid slot status information and update status message
                            if (line.contains("GRID_SLOT_STATUS:")) {
                                TestExecutionStatus currentStatus = statusService.getStatus(jobId);
                                if (currentStatus != null) {
                                    // Extract slot status info
                                    String slotInfo = line.substring(line.indexOf("GRID_SLOT_STATUS:") + "GRID_SLOT_STATUS:".length()).trim();
                                    String currentMessage = currentStatus.getMessage();
                                    // Update status message to include slot info (only if RUNNING status)
                                    if (currentStatus.getStatus() == TestExecutionStatus.Status.RUNNING) {
                                        if (currentMessage != null && !currentMessage.contains("Grid Status:")) {
                                            statusService.updateStatus(jobId, currentStatus.getStatus(), 
                                                currentMessage + " | " + slotInfo);
                                        }
                                    }
                                }
                            }
                        }
                    } catch (Exception e) {
                        log.error("Error reading process output: {}", e.getMessage(), e);
                        statusService.addLog(jobId, "ERROR reading output: " + e.getMessage());
                    }
                }, executor);
                
                // Monitor for status changes in main thread
                boolean reportGenerated = false;
                boolean uploadDetected = false;
                
                // Wait for process to complete
                int exitCode = process.waitFor();
                
                // Wait for output reader to finish
                outputReader.join();
                executor.shutdown();
                
                // Check logs for status indicators
                TestExecutionStatus finalStatus = statusService.getStatus(jobId);
                if (finalStatus != null && finalStatus.getLogs() != null) {
                    for (String logLine : finalStatus.getLogs()) {
                        if (logLine.contains("Extent Report generated successfully") || logLine.contains("Report file generated successfully")) {
                            reportGenerated = true;
                        }
                        if (logLine.contains("Report uploaded successfully") || logLine.contains("Report uploaded to Azure Blob Storage: Yes")) {
                            uploadDetected = true;
                        }
                    }
                }
                
                // Wait a bit for report generation and upload if not detected
                if (!uploadDetected) {
                    if (!reportGenerated) {
                        statusService.updateStatus(jobId, TestExecutionStatus.Status.GENERATING_REPORT, "Generating test report");
                        Thread.sleep(5000); // Wait 5 seconds for report generation
                    }
                    
                    // Check if report file exists
                    String reportPath = "src/test/resources/Reports/Manual_Automation_Run_Report.html";
                    if (Files.exists(Paths.get(reportPath))) {
                        statusService.updateStatus(jobId, TestExecutionStatus.Status.UPLOADING_REPORT, "Uploading report to Azure");
                        Thread.sleep(10000); // Wait 10 seconds for Azure upload
                    }
                }
                
                // Verify Azure upload and get report URL
                String reportUrl = verifyAndGetReportUrl(jobId);
                
                // Always mark as COMPLETED - test execution finished, even if some tests failed
                // Individual test failures are shown in the report
                if (reportUrl != null) {
                    if (exitCode == 0) {
                        statusService.updateStatus(jobId, TestExecutionStatus.Status.COMPLETED, 
                            "Full test suite execution completed successfully. Report is ready for review.", reportUrl);
                    } else {
                        statusService.updateStatus(jobId, TestExecutionStatus.Status.COMPLETED, 
                            "Full test suite execution completed. Some test cases may have failed. Please review the report for details.", reportUrl);
                    }
                } else {
                    if (exitCode == 0) {
                        statusService.updateStatus(jobId, TestExecutionStatus.Status.COMPLETED, 
                            "Full test suite execution completed. Report may still be uploading.", 
                            "https://gallopadeqa.blob.core.windows.net/staging/Reports/Manual_Automation_Run_Report.html");
                    } else {
                        statusService.updateStatus(jobId, TestExecutionStatus.Status.COMPLETED, 
                            "Full test suite execution completed. Some test cases may have failed. Report may still be uploading.", 
                            "https://gallopadeqa.blob.core.windows.net/staging/Reports/Manual_Automation_Run_Report.html");
                    }
                }
                
            } catch (Exception e) {
                log.error("Job {} crashed: {}", jobId, e.getMessage(), e);
                statusService.setError(jobId, e.getMessage());
            }
        });
    }

    @Async
    public CompletableFuture<Void> runTestAsync(String jobId, String testCaseFile) {
        return CompletableFuture.runAsync(() -> {
            try {
                statusService.updateStatus(jobId, TestExecutionStatus.Status.QUEUED, "Test case queued for execution");
                statusService.setFeatureFile(jobId, testCaseFile);
                
                String format = "-DsuiteXmlFile";
                if (testCaseFile.endsWith(".feature")) {
                    format = "-Dcucumber.features";
                } else {
                    statusService.setError(jobId, "Invalid test case file format");
                    return;
                }
                
                statusService.updateStatus(jobId, TestExecutionStatus.Status.RUNNING, "Test case is running");
                
                String[] command = {"mvn", "test", format+"="+testCaseFile};
                
                // Use ProcessBuilder for better control and to redirect stderr to stdout
                ProcessBuilder processBuilder = new ProcessBuilder(command);
                processBuilder.redirectErrorStream(true); // Merge stderr into stdout
                Process process = processBuilder.start();
                
                // Read output in a separate thread to avoid blocking
                ExecutorService executor = Executors.newSingleThreadExecutor();
                CompletableFuture<Void> outputReader = CompletableFuture.runAsync(() -> {
                    try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
                        String line;
                        while ((line = reader.readLine()) != null) {
                            System.out.println("Script output: " + line);
                            
                            // Capture ALL logs
                            statusService.addLog(jobId, line);
                            
                            // Check for browser installation error
                            if (line.contains("BROWSER NOT INSTALLED") || 
                                line.contains("Chrome/Chromium is not installed") ||
                                line.contains("BrowserNotInstalledException")) {
                                String errorMessage = "❌ Browser Not Installed: Chrome/Chromium is not installed on this server. " +
                                                    "Please install Chrome or Chromium before running test cases. " +
                                                    "Installation: sudo apt-get install google-chrome-stable";
                                statusService.setError(jobId, errorMessage);
                                log.error("Browser installation error detected for job {}: {}", jobId, errorMessage);
                            }
                            
                            // Check for Grid slot status information and update status message
                            if (line.contains("GRID_SLOT_STATUS:")) {
                                TestExecutionStatus currentStatus = statusService.getStatus(jobId);
                                if (currentStatus != null) {
                                    // Extract slot status info
                                    String slotInfo = line.substring(line.indexOf("GRID_SLOT_STATUS:") + "GRID_SLOT_STATUS:".length()).trim();
                                    String currentMessage = currentStatus.getMessage();
                                    // Update status message to include slot info (only if RUNNING status)
                                    if (currentStatus.getStatus() == TestExecutionStatus.Status.RUNNING) {
                                        if (currentMessage != null && !currentMessage.contains("Grid Status:")) {
                                            statusService.updateStatus(jobId, currentStatus.getStatus(), 
                                                currentMessage + " | " + slotInfo);
                                        }
                                    }
                                }
                            }
                            
                            // Check for status change indicators (non-blocking)
                            TestExecutionStatus currentStatus = statusService.getStatus(jobId);
                            if (currentStatus != null) {
                                if ((line.contains("Extent Report generated successfully") || line.contains("Report file generated successfully")) 
                                    && currentStatus.getStatus() == TestExecutionStatus.Status.RUNNING) {
                                    statusService.updateStatus(jobId, TestExecutionStatus.Status.GENERATING_REPORT, "Generating test report");
                                } else if ((line.contains("Uploading report to Azure") || line.contains("Uploading report to Azure Blob Storage"))
                                    && currentStatus.getStatus() == TestExecutionStatus.Status.GENERATING_REPORT) {
                                    statusService.updateStatus(jobId, TestExecutionStatus.Status.UPLOADING_REPORT, "Uploading report to Azure");
                                }
                            }
                        }
                    } catch (Exception e) {
                        log.error("Error reading process output: {}", e.getMessage(), e);
                        statusService.addLog(jobId, "ERROR reading output: " + e.getMessage());
                    }
                }, executor);
                
                // Wait for process to complete
                int exitCode = process.waitFor();
                
                // Wait for output reader to finish
                outputReader.join();
                executor.shutdown();
                
                // Check for report generation and upload after process completes
                boolean uploadDetected = false;
                
                // Check logs for status indicators
                TestExecutionStatus status = statusService.getStatus(jobId);
                if (status != null && status.getLogs() != null) {
                    for (String logLine : status.getLogs()) {
                        if (logLine.contains("Report uploaded successfully") || logLine.contains("Report uploaded to Azure Blob Storage: Yes")) {
                            uploadDetected = true;
                            break;
                        }
                    }
                }
                
                // Wait a bit for report generation and upload
                if (!uploadDetected) {
                    // Check if report file exists
                    String reportPath = "src/test/resources/Reports/Manual_Automation_Run_Report.html";
                    if (Files.exists(Paths.get(reportPath))) {
                        statusService.updateStatus(jobId, TestExecutionStatus.Status.UPLOADING_REPORT, "Uploading report to Azure");
                        Thread.sleep(10000); // Wait 10 seconds for Azure upload
                    } else {
                        statusService.updateStatus(jobId, TestExecutionStatus.Status.GENERATING_REPORT, "Generating test report");
                        Thread.sleep(5000); // Wait 5 seconds for report generation
                    }
                }
                
                // Verify Azure upload and get report URL
                String reportUrl = verifyAndGetReportUrl(jobId);
                
                // Always mark as COMPLETED - test execution finished, even if some tests failed
                // Individual test failures are shown in the report
                if (reportUrl != null) {
                    if (exitCode == 0) {
                        statusService.updateStatus(jobId, TestExecutionStatus.Status.COMPLETED, 
                            "Test execution completed successfully. Report is ready for review.", reportUrl);
                    } else {
                        statusService.updateStatus(jobId, TestExecutionStatus.Status.COMPLETED, 
                            "Test execution completed. Some test cases may have failed. Please review the report for details.", reportUrl);
                    }
                } else {
                    if (exitCode == 0) {
                        statusService.updateStatus(jobId, TestExecutionStatus.Status.COMPLETED, 
                            "Test execution completed. Report may still be uploading.", 
                            "https://gallopadeqa.blob.core.windows.net/staging/Reports/Manual_Automation_Run_Report.html");
                    } else {
                        statusService.updateStatus(jobId, TestExecutionStatus.Status.COMPLETED, 
                            "Test execution completed. Some test cases may have failed. Report may still be uploading.", 
                            "https://gallopadeqa.blob.core.windows.net/staging/Reports/Manual_Automation_Run_Report.html");
                    }
                }
                
            } catch (Exception e) {
                log.error("Job {} crashed: {}", jobId, e.getMessage(), e);
                statusService.setError(jobId, e.getMessage());
            }
        });
    }
    
    private String verifyAndGetReportUrl(String jobId) {
        try {
            // Load Azure properties
            java.util.Properties properties = loadAzureProperties();
            String accountName = properties.getProperty("azure.storage.account-name");
            String accountKey = properties.getProperty("azure.storage.account-key");
            String containerName = properties.getProperty("azure.storage.container-name");
            
            if (accountName == null || accountKey == null || containerName == null) {
                return null;
            }
            
            String endpoint = String.format("https://%s.blob.core.windows.net", accountName);
            StorageSharedKeyCredential credential = new StorageSharedKeyCredential(accountName, accountKey);
            
            BlobContainerClient containerClient = new BlobContainerClientBuilder()
                    .endpoint(endpoint)
                    .credential(credential)
                    .containerName(containerName)
                    .buildClient();
            
            String blobName = "Reports/Manual_Automation_Run_Report.html";
            BlobClient blobClient = containerClient.getBlobClient(blobName);
            
            // Check if blob exists (with retry)
            for (int i = 0; i < 5; i++) {
                if (blobClient.exists()) {
                    return blobClient.getBlobUrl();
                }
                Thread.sleep(2000); // Wait 2 seconds before retry
            }
            
        } catch (Exception e) {
            log.warn("Could not verify Azure upload: {}", e.getMessage());
        }
        
        return "https://gallopadeqa.blob.core.windows.net/staging/Reports/Manual_Automation_Run_Report.html";
    }
    
    private java.util.Properties loadAzureProperties() {
        java.util.Properties properties = new java.util.Properties();
        try {
            java.io.InputStream baseStream = AutomationService.class.getClassLoader()
                    .getResourceAsStream("application.properties");
            if (baseStream != null) {
                properties.load(baseStream);
                baseStream.close();
            }
            
            String activeProfile = properties.getProperty("spring.profiles.active", "local");
            String profileFileName = "application-" + activeProfile + ".properties";
            java.io.InputStream profileStream = AutomationService.class.getClassLoader()
                    .getResourceAsStream(profileFileName);
            if (profileStream != null) {
                properties.load(profileStream);
                profileStream.close();
            }
        } catch (Exception e) {
            log.error("Error loading properties: {}", e.getMessage());
        }
        return properties;
    }

    /**
     * Get all test case paths under TeacherSide folder
     * @return Map with feature name as key and full path as value, ordered by folder structure
     */
    public Map<String, String> getAllTeacherSideTestCases() {
        Map<String, String> testCasesMap = new LinkedHashMap<>();
        String teacherSidePath = "src/test/resources/Features/TeacherSide";

        try {
            Path basePath = Paths.get(teacherSidePath);
            if (!Files.exists(basePath)) {
                log.warn("TeacherSide directory not found: {}", teacherSidePath);
                return testCasesMap;
            }

            try (Stream<Path> paths = Files.walk(basePath)) {
                paths.filter(Files::isRegularFile)
                        .filter(path -> path.toString().endsWith(".feature"))
                        .sorted() // Sort paths to maintain folder order
                        .forEach(path -> {
                            try {
                                String featureName = path.getFileName().toString().replace(".feature", "");
                                String fullPath = path.toString().replace(File.separator, "/");

                                // Use feature name as key and full path as value
                                testCasesMap.put(featureName, fullPath);
                                log.debug("Found feature: {} -> {}", featureName, fullPath);
                            } catch (Exception e) {
                                log.error("Error processing feature file: {}", path, e);
                            }
                        });
            }

            log.info("Found {} test cases under TeacherSide", testCasesMap.size());
        } catch (Exception e) {
            log.error("Error scanning TeacherSide directory: {}", e.getMessage(), e);
        }

        return testCasesMap;
    }
}