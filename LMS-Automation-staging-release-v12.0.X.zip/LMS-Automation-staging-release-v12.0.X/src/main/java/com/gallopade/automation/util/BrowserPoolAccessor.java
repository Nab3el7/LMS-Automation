package com.gallopade.automation.util;

import com.gallopade.automation.services.BrowserPoolManager;
import org.openqa.selenium.WebDriver;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

/**
 * Static accessor for BrowserPoolManager to be used from test code
 * This bridges Spring-managed services with static test code
 */
@Component
public class BrowserPoolAccessor implements ApplicationContextAware {
    
    private static ApplicationContext applicationContext;
    private static BrowserPoolManager browserPoolManager;
    private static volatile boolean initializationAttempted = false;
    
    @Override
    public void setApplicationContext(ApplicationContext context) throws BeansException {
        applicationContext = context;
        try {
            browserPoolManager = context.getBean(BrowserPoolManager.class);
            System.out.println("✅ BrowserPoolAccessor initialized - BrowserPoolManager available");
        } catch (Exception e) {
            System.err.println("⚠️ Failed to get BrowserPoolManager from ApplicationContext: " + e.getMessage());
        }
    }
    
    /**
     * Try to initialize BrowserPoolManager from ApplicationContext
     * This is called lazily when needed
     */
    private static synchronized void tryInitialize() {
        if (browserPoolManager != null || initializationAttempted) {
            return;
        }
        
        initializationAttempted = true;
        
        if (applicationContext != null) {
            try {
                browserPoolManager = applicationContext.getBean(BrowserPoolManager.class);
                System.out.println("✅ BrowserPoolManager initialized successfully");
            } catch (Exception e) {
                System.err.println("⚠️ Could not get BrowserPoolManager from ApplicationContext: " + e.getMessage());
                System.err.println("   This is normal if tests are running outside Spring context");
            }
        } else {
            System.err.println("⚠️ ApplicationContext not available - BrowserPoolManager will not be used");
            System.err.println("   Tests will fall back to direct WebDriver initialization");
        }
    }
    
    /**
     * Get browser from pool (for use in static contexts like Configurations)
     */
    public static WebDriver acquireBrowser() {
        try {
            // Try to initialize if not already done
            if (browserPoolManager == null) {
                tryInitialize();
            }
            
            if (browserPoolManager != null) {
                return browserPoolManager.acquireBrowser();
            } else {
                // This is expected when running tests outside Spring context
                // Configurations will handle the fallback
                return null;
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            System.err.println("⚠️ Interrupted while acquiring browser from pool: " + e.getMessage());
            return null;
        } catch (Exception e) {
            System.err.println("⚠️ Error acquiring browser from pool: " + e.getMessage());
            e.printStackTrace();
            return null; // Will trigger fallback in Configurations
        }
    }
    
    /**
     * Release browser back to pool
     */
    public static void releaseBrowser(WebDriver browser) {
        if (browserPoolManager == null) {
            tryInitialize();
        }
        
        if (browserPoolManager != null && browser != null) {
            try {
                browserPoolManager.releaseBrowser(browser);
            } catch (Exception e) {
                System.err.println("⚠️ Error releasing browser to pool: " + e.getMessage());
                // Don't throw - just log the error
            }
        }
    }
    
    /**
     * Check if browser pool is available
     */
    public static boolean isPoolAvailable() {
        if (browserPoolManager == null) {
            tryInitialize();
        }
        return browserPoolManager != null;
    }
}

