package com.gallopade.automation.services;

import com.gallopade.automation.model.TestExecutionStatus;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Slf4j
@Service
public class TestExecutionStatusService {

    private final Map<String, TestExecutionStatus> statusMap = new ConcurrentHashMap<>();

    public void updateStatus(String jobId, TestExecutionStatus.Status status, String message) {
        TestExecutionStatus executionStatus = statusMap.computeIfAbsent(jobId, k -> 
            TestExecutionStatus.builder()
                .jobId(jobId)
                .status(status)
                .message(message)
                .startTime(LocalDateTime.now())
                .logs(new java.util.ArrayList<>())
                .build()
        );
        
        executionStatus.setStatus(status);
        executionStatus.setMessage(message);
        
        // Ensure logs list is initialized
        if (executionStatus.getLogs() == null) {
            executionStatus.setLogs(new java.util.ArrayList<>());
        }
        
        if (status == TestExecutionStatus.Status.COMPLETED || status == TestExecutionStatus.Status.FAILED) {
            executionStatus.setEndTime(LocalDateTime.now());
            if (executionStatus.getStartTime() != null) {
                long seconds = java.time.Duration.between(executionStatus.getStartTime(), executionStatus.getEndTime()).getSeconds();
                executionStatus.setExecutionTimeSeconds(seconds);
            }
        }
        
        log.info("Status updated for job {}: {} - {}", jobId, status, message);
    }

    public void updateStatus(String jobId, TestExecutionStatus.Status status, String message, String reportUrl) {
        updateStatus(jobId, status, message);
        TestExecutionStatus executionStatus = statusMap.get(jobId);
        if (executionStatus != null) {
            executionStatus.setReportUrl(reportUrl);
        }
    }

    public void setFeatureFile(String jobId, String featureFile) {
        TestExecutionStatus executionStatus = statusMap.get(jobId);
        if (executionStatus != null) {
            executionStatus.setFeatureFile(featureFile);
        }
    }

    public void setError(String jobId, String errorMessage) {
        setError(jobId, errorMessage, "https://gallopadeqa.blob.core.windows.net/staging/Reports/Manual_Automation_Run_Report.html");
    }

    public void setError(String jobId, String errorMessage, String reportUrl) {
        TestExecutionStatus executionStatus = statusMap.get(jobId);
        if (executionStatus != null) {
            executionStatus.setStatus(TestExecutionStatus.Status.FAILED);
            executionStatus.setErrorMessage(errorMessage);
            executionStatus.setMessage("Test execution failed: " + errorMessage);
            executionStatus.setReportUrl(reportUrl);
            executionStatus.setEndTime(LocalDateTime.now());
            if (executionStatus.getStartTime() != null) {
                long seconds = java.time.Duration.between(executionStatus.getStartTime(), executionStatus.getEndTime()).getSeconds();
                executionStatus.setExecutionTimeSeconds(seconds);
            }
        }
    }

    public TestExecutionStatus getStatus(String jobId) {
        return statusMap.get(jobId);
    }

    public void removeStatus(String jobId) {
        statusMap.remove(jobId);
    }

    // Cleanup old statuses (older than 24 hours)
    public void cleanupOldStatuses() {
        LocalDateTime cutoff = LocalDateTime.now().minusHours(24);
        statusMap.entrySet().removeIf(entry -> {
            TestExecutionStatus status = entry.getValue();
            return status.getEndTime() != null && status.getEndTime().isBefore(cutoff);
        });
    }
    
    /**
     * Add a log line to the test execution status
     * Captures all logs from process output
     */
    public void addLog(String jobId, String logLine) {
        TestExecutionStatus executionStatus = statusMap.get(jobId);
        if (executionStatus != null) {
            if (executionStatus.getLogs() == null) {
                executionStatus.setLogs(new java.util.ArrayList<>());
            }
            
            // Add the log line
            executionStatus.getLogs().add(logLine);
            
            // Keep only last 2000 log entries to prevent memory issues
            if (executionStatus.getLogs().size() > 2000) {
                executionStatus.getLogs().remove(0);
            }
        }
    }
}

