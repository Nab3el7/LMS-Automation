package com.gallopade.automation.config;

import lombok.extern.slf4j.Slf4j;
import org.apache.tomcat.util.http.fileupload.MultipartStream;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.multipart.MaxUploadSizeExceededException;
import org.springframework.web.multipart.MultipartException;

import java.util.HashMap;
import java.util.Map;

@Slf4j
@ControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(MultipartStream.MalformedStreamException.class)
    public ResponseEntity<Map<String, String>> handleMultipartStreamException(MultipartStream.MalformedStreamException e) {
        log.warn("MultipartStream error (likely malformed request): {}", e.getMessage());
        
        Map<String, String> response = new HashMap<>();
        response.put("status", "error");
        response.put("message", "Request parsing error. Please check your request format.");
        response.put("error", "Malformed request stream");
        
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
    }

    @ExceptionHandler(MultipartException.class)
    public ResponseEntity<Map<String, String>> handleMultipartException(MultipartException e) {
        log.warn("Multipart error: {}", e.getMessage());
        
        Map<String, String> response = new HashMap<>();
        response.put("status", "error");
        response.put("message", "Multipart request error. This endpoint does not support file uploads.");
        response.put("error", e.getMessage());
        
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
    }

    @ExceptionHandler(MaxUploadSizeExceededException.class)
    public ResponseEntity<Map<String, String>> handleMaxUploadSizeException(MaxUploadSizeExceededException e) {
        log.warn("Max upload size exceeded: {}", e.getMessage());
        
        Map<String, String> response = new HashMap<>();
        response.put("status", "error");
        response.put("message", "Request size exceeds maximum allowed size.");
        response.put("error", e.getMessage());
        
        return ResponseEntity.status(HttpStatus.PAYLOAD_TOO_LARGE).body(response);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<Map<String, String>> handleGenericException(Exception e) {
        // Don't log HTTP parsing errors at ERROR level - these are often benign
        String errorMessage = e.getMessage();
        if (errorMessage != null && (
            errorMessage.contains("Error parsing HTTP request header") ||
            errorMessage.contains("Http11Processor") ||
            e.getClass().getName().contains("HttpParseException")
        )) {
            log.debug("HTTP parsing error (benign, likely from health check): {}", errorMessage);
            // Return success for benign parsing errors
            Map<String, String> response = new HashMap<>();
            response.put("status", "ok");
            response.put("message", "Request processed");
            return ResponseEntity.ok(response);
        }
        
        log.error("Unexpected error: {}", errorMessage, e);
        
        Map<String, String> response = new HashMap<>();
        response.put("status", "error");
        response.put("message", "An unexpected error occurred.");
        response.put("error", errorMessage);
        
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
    }
}

