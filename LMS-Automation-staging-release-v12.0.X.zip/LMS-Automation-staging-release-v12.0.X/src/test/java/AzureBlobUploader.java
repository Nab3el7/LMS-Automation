import com.azure.storage.blob.BlobClient;
import com.azure.storage.blob.BlobContainerClient;
import com.azure.storage.blob.BlobContainerClientBuilder;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class AzureBlobUploader {
    private BlobContainerClient containerClient;

    public AzureBlobUploader() {
        Properties properties = loadApplicationProperties();

        String accountName = properties.getProperty("azure.storage.account-name");
        String accountKey = properties.getProperty("azure.storage.account-key");
        String containerName = properties.getProperty("azure.storage.container-name");

        String endpoint = String.format("https://%s.blob.core.windows.net", accountName);

        containerClient = new BlobContainerClientBuilder()
                .endpoint(endpoint)
                .sasToken(accountKey)
                .containerName(containerName)
                .buildClient();
    }

    public void uploadFile(String filePath, String blobName) {
        BlobClient blobClient = containerClient.getBlobClient(blobName);
        blobClient.uploadFromFile(filePath, true);
    }

    /**
     * Loads application.properties and profile-specific properties file
     * @return Properties object with all loaded properties
     */
    private Properties loadApplicationProperties() {
        Properties properties = new Properties();
        
        try {
            // Step 1: Load base application.properties
            InputStream baseStream = AzureBlobUploader.class.getClassLoader()
                    .getResourceAsStream("application.properties");
            
            if (baseStream != null) {
                properties.load(baseStream);
                baseStream.close();
            }
            
            // Step 2: Get active profile
            String activeProfile = properties.getProperty("spring.profiles.active", "local");
            
            // Step 3: Load profile-specific properties (e.g., application-local.properties)
            String profileFileName = "application-" + activeProfile + ".properties";
            InputStream profileStream = AzureBlobUploader.class.getClassLoader()
                    .getResourceAsStream(profileFileName);
            
            if (profileStream != null) {
                Properties profileProperties = new Properties();
                profileProperties.load(profileStream);
                profileStream.close();
                
                // Merge profile-specific properties (profile overrides base)
                properties.putAll(profileProperties);
            }
            
        } catch (IOException e) {
            System.err.println("Error loading application properties: " + e.getMessage());
            e.printStackTrace();
        }
        
        return properties;
    }
}
