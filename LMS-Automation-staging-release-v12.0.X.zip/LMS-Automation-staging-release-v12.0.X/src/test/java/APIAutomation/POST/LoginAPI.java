package APIAutomation.POST;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

public class LoginAPI extends Configurations {

    public String baseUrl = Configurations.App_url;
    Helper helper;
    public WebDriverWait wait;
    WebDriver driver;
    public static String teacherAccessToken;
    public static List<String> accessTokenList;
    public static Map<String, String> accessTokenMap = new HashMap<>();


    public LoginAPI(WebDriver driver) {
        this.driver = driver;
        helper = new Helper();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    public void LoginWithCsvData() throws IOException {
        String csvFile = "src/test/resources/TestData/useraccounts.csv";
        List<CSVRecord> records;

        try (Reader reader = new FileReader(csvFile);
             CSVParser csvParser = new CSVParser(reader, CSVFormat.DEFAULT.withFirstRecordAsHeader().withIgnoreHeaderCase().withTrim())) {
            records = csvParser.getRecords();
        }

        ExecutorService executor = Executors.newFixedThreadPool(100);  // Adjust thread pool size if needed
        List<CompletableFuture<Void>> futures = new ArrayList<>();
        AtomicInteger counter = new AtomicInteger(0);

        for (int i = 0; i < 2; i++) {
            final int index = i % records.size();
            CSVRecord record = records.get(index);
            String username = record.get("username");
            System.out.println("Username: " + username);
            String password = record.get("password");
            System.out.println("Password: " + password);

            TestRunner.getTest().log(Status.INFO, "Username : " + username + " Password : " + password);

            CompletableFuture<Void> future = CompletableFuture.runAsync(() -> {
                try {
                    String accessToken = loginAPICall(username, password);
                    synchronized (accessTokenMap) {
                        accessTokenMap.put(username + "#" + counter.incrementAndGet(), accessToken);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }, executor);

            futures.add(future);
        }

        CompletableFuture.allOf(futures.toArray(new CompletableFuture[0])).join();
        executor.shutdown();

        System.out.println("Access Tokens:");
        accessTokenMap.forEach((key, value) -> System.out.println(key + ": " + value));
    }

    public String loginAPICall(String username, String password) throws IOException, NoSuchAlgorithmException, KeyManagementException {
        String apiUrl = baseUrl + "oauth20-service/oauth/token";
        String authString = "c3ByaW5nYmFua0NsaWVudDpzcHJpbmdiYW5rU2VjcmV0";
        String postData = "grant_type=password&username=" + username + "&password=" + password;
        disableCertificateValidation();

        URL url = new URL(apiUrl);
        HttpURLConnection con = (HttpURLConnection) url.openConnection();
        con.setRequestMethod("POST");
        
        // Set connection properties to prevent premature closure
        con.setConnectTimeout(30000); // 30 seconds
        con.setReadTimeout(30000); // 30 seconds
        con.setUseCaches(false);
        con.setDoInput(true);
        con.setDoOutput(true);
        
        // Set headers - ensure proper content type and length
        byte[] postDataBytes = postData.getBytes("UTF-8");
        con.setRequestProperty("Authorization", "Basic " + authString);
        con.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
        con.setRequestProperty("Content-Length", String.valueOf(postDataBytes.length));
        con.setRequestProperty("Accept", "application/json");
        con.setRequestProperty("Connection", "keep-alive");
        con.setRequestProperty("User-Agent", "Java-Automation-Client");

        // Write request body
        try (OutputStream os = con.getOutputStream()) {
            os.write(postDataBytes, 0, postDataBytes.length);
            os.flush();
        }

        // Get response
        int responseCode = con.getResponseCode();
        System.out.println("Response Code : " + responseCode);
        TestRunner.getTest().log(Status.INFO, "Response Code : " + responseCode);

        // Handle both success and error responses
        BufferedReader in;
        if (responseCode >= 200 && responseCode < 300) {
            in = new BufferedReader(new InputStreamReader(con.getInputStream(), "UTF-8"));
        } else {
            // Read error stream for debugging
            try {
                in = new BufferedReader(new InputStreamReader(con.getErrorStream(), "UTF-8"));
            } catch (Exception e) {
                in = new BufferedReader(new InputStreamReader(con.getInputStream(), "UTF-8"));
            }
        }

        String inputLine;
        StringBuilder response = new StringBuilder();

        while ((inputLine = in.readLine()) != null) {
            response.append(inputLine);
        }
        in.close();
        con.disconnect();

        if (responseCode >= 200 && responseCode < 300) {
            JSONObject jsonObject = new JSONObject(response.toString());
            return jsonObject.getString("access_token");
        } else {
            throw new IOException("API call failed with response code: " + responseCode + ", Response: " + response.toString());
        }
    }

    private void disableCertificateValidation() throws NoSuchAlgorithmException, KeyManagementException {
        TrustManager[] trustAllCerts = new TrustManager[] {
                new X509TrustManager() {
                    public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                        return null;
                    }
                    public void checkClientTrusted(X509Certificate[] certs, String authType) {
                    }
                    public void checkServerTrusted(X509Certificate[] certs, String authType) {
                    }
                }
        };

        SSLContext sslContext = SSLContext.getInstance("TLS");
        sslContext.init(null, trustAllCerts, new java.security.SecureRandom());
        HttpsURLConnection.setDefaultSSLSocketFactory(sslContext.getSocketFactory());
    }
}
