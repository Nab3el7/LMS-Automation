package APIAutomation.POST;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;
import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

public class POSTStudentsLoginAPI extends Configurations {

    public String baseUrl = Configurations.App_url;
    Helper helper;
    public WebDriverWait wait;
    WebDriver driver;
    public static Map<String, String> accessTokenMap = new HashMap<>();
    private final ExecutorService executor = Executors.newFixedThreadPool(Integer.parseInt(Configurations.Api_ThreadPool));


    public POSTStudentsLoginAPI(WebDriver driver) {
        this.driver = driver;
        helper = new Helper();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    public void LoginStudentsWithCsvData() throws IOException {
        String csvFile = "src/test/resources/TestData/stdaccounts.csv";
        List<CSVRecord> records;

        try (Reader reader = new FileReader(csvFile);
             CSVParser csvParser = new CSVParser(reader, CSVFormat.DEFAULT.withFirstRecordAsHeader().withIgnoreHeaderCase().withTrim())) {
            records = csvParser.getRecords();
        }

        List<CompletableFuture<Void>> futures = new ArrayList<>();
        AtomicInteger counter = new AtomicInteger(0);

        for (int i = 0; i < 1; i++) {
            final int index = i % records.size();
            CSVRecord record = records.get(index);
            String username = record.get("username");
            System.out.println("Username: " + username);
            String password = record.get("password");
            System.out.println("Password: " + password);

            CompletableFuture<Void> future = CompletableFuture.runAsync(() -> {
                try {
                    String accessToken = studentsLoginAPICall(username, password);
                    synchronized (accessTokenMap) {
                        accessTokenMap.put(username + "#" + counter.incrementAndGet(), accessToken);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }, executor);

            futures.add(future);
        }

        CompletableFuture.allOf(futures.toArray(new CompletableFuture[0])).join();
        executor.shutdown();

        System.out.println("Access Tokens:");
        accessTokenMap.forEach((key, value) -> System.out.println(key + ": " + value));
    }

    public String studentsLoginAPICall(String username, String password) throws IOException, NoSuchAlgorithmException, KeyManagementException {
        String apiUrl = baseUrl + "oauth20-service/oauth/token";
        String authString = "c3ByaW5nYmFua0NsaWVudDpzcHJpbmdiYW5rU2VjcmV0";
        String postData = "grant_type=password&username=" + username + "&password=" + password;
        disableCertificateValidation();

        URL url = new URL(apiUrl);
        HttpURLConnection con = (HttpURLConnection) url.openConnection();
        con.setRequestMethod("POST");
        con.setRequestProperty("Authorization", "Basic " + authString);
        con.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
        con.setRequestProperty("Accept", "application/json");
        con.setDoOutput(true);

        try (OutputStream os = con.getOutputStream()) {
            byte[] postDataBytes = postData.getBytes("UTF-8");
            os.write(postDataBytes, 0, postDataBytes.length);
            os.flush();
        }

        int responseCode = con.getResponseCode();
        System.out.println("Response Code : " + responseCode);

        BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
        String inputLine;
        StringBuilder response = new StringBuilder();

        while ((inputLine = in.readLine()) != null) {
            response.append(inputLine);
        }
        in.close();
        con.disconnect();

        JSONObject jsonObject = new JSONObject(response.toString());
        return jsonObject.getString("access_token");
    }

    private void disableCertificateValidation() throws NoSuchAlgorithmException, KeyManagementException {
        TrustManager[] trustAllCerts = new TrustManager[] {
                new X509TrustManager() {
                    public X509Certificate[] getAcceptedIssuers() {
                        return null;
                    }
                    public void checkClientTrusted(X509Certificate[] certs, String authType) {
                    }
                    public void checkServerTrusted(X509Certificate[] certs, String authType) {
                    }
                }
        };

        SSLContext sslContext = SSLContext.getInstance("TLS");
        sslContext.init(null, trustAllCerts, new java.security.SecureRandom());
        HttpsURLConnection.setDefaultSSLSocketFactory(sslContext.getSocketFactory());
    }
}
