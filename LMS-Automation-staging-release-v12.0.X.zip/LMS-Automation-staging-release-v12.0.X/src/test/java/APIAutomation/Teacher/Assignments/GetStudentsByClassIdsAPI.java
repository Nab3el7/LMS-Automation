package APIAutomation.Teacher.Assignments;

import APIAutomation.POST.LoginAPI;
import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import apiHandler.PostAPIHandler;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.security.cert.X509Certificate;
import java.time.Duration;
import java.time.Instant;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class GetStudentsByClassIdsAPI {
    Helper helper;
    WebDriverWait wait;
    PostAPIHandler postAPIHandler;
    LoginAPI loginAPI;

    private final String appURL = Configurations.App_url;
    String getStudentsByClassIdsEndPoint = "classes-query-service/api/v1/classes/StudentsByClassIds";
    private final ExecutorService executor = Executors.newFixedThreadPool(Integer.parseInt(Configurations.Api_ThreadPool));

    public GetStudentsByClassIdsAPI(WebDriver driver) {
        helper = new Helper();
        postAPIHandler = new PostAPIHandler(driver);
        loginAPI = new LoginAPI(driver);
        wait = new WebDriverWait(driver, Duration.ofSeconds(120));
    }


    public void getStudentsByClassIdsAPIConcurrently(String myCourseClassID)  {
        Collection<String> tokens = LoginAPI.accessTokenMap.values();
        CompletableFuture<?>[] allFutures = tokens.stream()
                .map(token -> CompletableFuture.runAsync(() -> getStudentsByClassIds(token, myCourseClassID), executor))
                .toArray(CompletableFuture[]::new);

        CompletableFuture.allOf(allFutures).join();
        System.out.println("All requests completed.");
    }

    private void getStudentsByClassIds(String bearerToken, String myCourseClassID) {
        String apiUrl = appURL + getStudentsByClassIdsEndPoint + "?classIds=" + myCourseClassID;

        // Create SSL context with custom TrustManager
        TrustManager[] trustAllCerts = new TrustManager[]{
                new X509TrustManager() {
                    public X509Certificate[] getAcceptedIssuers() {
                        return null;
                    }

                    public void checkClientTrusted(X509Certificate[] certs, String authType) {
                    }

                    public void checkServerTrusted(X509Certificate[] certs, String authType) {
                    }
                }
        };

        try {
            SSLContext sc = SSLContext.getInstance("TLS");
            sc.init(null, trustAllCerts, new java.security.SecureRandom());
            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

            URL url = new URL(apiUrl);
            HttpsURLConnection con = (HttpsURLConnection) url.openConnection();
            con.setRequestMethod("GET");
            con.setRequestProperty("Authorization", "Bearer " + bearerToken);
            con.setRequestProperty("timeZone", "Asia/Karachi");

            Instant start = Instant.now();
            int responseCode = con.getResponseCode();
            Instant end = Instant.now();

            Duration duration = Duration.between(start, end);
            System.out.println("Response Code: " + responseCode);
            System.out.println("Request Duration: " + duration.toMillis() + " ms");
            TestRunner.getTest().log(Status.INFO, "Response Code: " + responseCode + " Response Durations: " + duration.toMillis() + " ms");


            BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
            String inputLine;
            StringBuilder response = new StringBuilder();

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();
            con.disconnect();

            System.out.println("API Response:");
            System.out.println(response.toString());
            TestRunner.getTest().log(Status.INFO, "API response : " + response.toString());

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
