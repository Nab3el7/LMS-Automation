package APIAutomation.Teacher.Assignments.POST;

import APIAutomation.POST.LoginAPI;
import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import com.google.gson.JsonArray;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.security.cert.X509Certificate;
import java.time.Duration;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class POSTAssignmentReleaseAPI {
    Helper helper;
    WebDriverWait wait;
    LoginAPI loginAPI;

    private final String appURL = Configurations.App_url;
    String releaseAssignmentEndPoint = "gradebook-command-service/api/v1/releaseAssignment";
    private final ExecutorService executor = Executors.newFixedThreadPool(Integer.parseInt(Configurations.Api_ThreadPool));

    int contentTypeId = 4;
    String contentLinkId = "F547A1BE1C934C7E88E63F6E71997FC5";
    String status = "Active";
    String dateLastModified = "2022-01-25T19:00:00.000+00:00";
    String userLastModified = contentLinkId;  // Assuming same ID
    String categoryId = "2";
    int academicSessionsId = 1;
    int schoolYearId = 136;
    boolean studentSelfAssign = true;
    boolean randomizeQuestions = false;
    boolean randomizeAnswers = true;
    boolean releaseGradesToStudent = true;
    String studentCanReviewWorkId = "1";
    boolean allowLateSubmission = false;
    String additionalinfo = "";
    String classId = "138677924865000011";
    int vendorId = 61;
    Integer nonQuestionScore = null;  // Use Integer to allow null
    int assessmentScore = 58;
    String endDate = "2024-07-28T12:32Z";
    long endTime = 1719577920;
    String startDate = "2024-07-01T12:32Z";
    long startTime = 1719491520;
    String title = "Automated Test Auto Assignment";
    String curriculumMapDetailsId = contentLinkId;

    public POSTAssignmentReleaseAPI(WebDriver driver) {
        helper = new Helper();
        loginAPI = new LoginAPI(driver);
        wait = new WebDriverWait(driver, Duration.ofSeconds(120));
    }

    public void getAssignmentReleaseAPIConcurrently() {
        Collection<String> tokens = LoginAPI.accessTokenMap.values();
        CompletableFuture<?>[] allFutures = tokens.stream()
                .map(token -> CompletableFuture.runAsync(() -> sendReleaseAssignment(token), executor))
                .toArray(CompletableFuture[]::new);

        CompletableFuture.allOf(allFutures).join();
        System.out.println("All requests completed.");
    }

    private void sendReleaseAssignment(String bearerToken) {
        String apiUrl = appURL + releaseAssignmentEndPoint;

        // Define and populate the list within the method body
        List<Map<String, Object>> questionDetails = new ArrayList<>();
        questionDetails.add(createQuestionDetail("2d5b34b4-70a5-4a1c-aefc-1f82bc5614ba", 2, 2, "choice-interaction", 1, 1));
        questionDetails.add(createQuestionDetail("f57d03aa-9a42-408d-8d7d-a2accf247ebc", 3, 3, "choice-interaction", 2, 2));
        questionDetails.add(createQuestionDetail("011a24e3-c1c3-46ca-b5dc-dd56d75e5386", 4, 4, "inline-choice-select-interaction", 3, 3));

        TrustManager[] trustAllCerts = new TrustManager[]{
                new X509TrustManager() {
                    public X509Certificate[] getAcceptedIssuers() {
                        return null;
                    }

                    public void checkClientTrusted(X509Certificate[] certs, String authType) {
                    }

                    public void checkServerTrusted(X509Certificate[] certs, String authType) {
                    }
                }
        };

        try {
            SSLContext sc = SSLContext.getInstance("TLS");
            sc.init(null, trustAllCerts, new java.security.SecureRandom());
            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

            URL url = new URL(apiUrl);
            HttpsURLConnection con = (HttpsURLConnection) url.openConnection();
            con.setRequestMethod("POST");
            con.setRequestProperty("accept", "*/*");
            con.setRequestProperty("Authorization", "Bearer " + bearerToken);
            con.setRequestProperty("content-type", "application/json");
            con.setRequestProperty("Timezone", "Asia/Karachi");
            con.setDoOutput(true);

            JsonObject jsonObject = new JsonObject();
            jsonObject.addProperty("contentTypeId", contentTypeId);
            jsonObject.addProperty("contentLinkId", contentLinkId);
            jsonObject.addProperty("status", status);
            jsonObject.addProperty("dateLastModified", dateLastModified);
            jsonObject.addProperty("userLastModified", userLastModified);
            jsonObject.addProperty("categoryId", categoryId);
            jsonObject.addProperty("academicSessionsId", academicSessionsId);
            jsonObject.addProperty("schoolYearId", schoolYearId);
            jsonObject.addProperty("studentSelfAssign", studentSelfAssign);
            jsonObject.addProperty("randomizeQuestions", randomizeQuestions);
            jsonObject.addProperty("randomizeAnswers", randomizeAnswers);
            jsonObject.addProperty("releaseGradesToStudent", releaseGradesToStudent);
            jsonObject.addProperty("studentCanReviewWorkId", studentCanReviewWorkId);
            jsonObject.addProperty("allowLateSubmission", allowLateSubmission);
            jsonObject.addProperty("additionalinfo", additionalinfo);

            JsonArray assignToArray = new JsonArray();
            JsonObject assignToObject = new JsonObject();
            assignToObject.addProperty("classId", classId);
            assignToArray.add(assignToObject);
            jsonObject.add("assignTo", assignToArray);

            jsonObject.addProperty("vendorId", vendorId);
            jsonObject.add("nonQuestionScore", JsonNull.INSTANCE);

            JsonArray contentKeyDetailsArray = new JsonArray();
            for (Map<String, Object> qd : questionDetails) {
                JsonObject detail = createContentKeyDetail(
                        (String) qd.get("questionId"),
                        (int) qd.get("points"),
                        (int) qd.get("originalPoints"),
                        (String) qd.get("interactionType"),
                        (int) qd.get("sequence"),
                        (int) qd.get("groupNumber"));
                contentKeyDetailsArray.add(detail);
            }
            jsonObject.add("contentKeyDetails", contentKeyDetailsArray);

//            JsonArray contentKeyDetailsArray = new JsonArray();
//            contentKeyDetailsArray.add(createContentKeyDetail("2d5b34b4-70a5-4a1c-aefc-1f82bc5614ba", 2, 2, true, "choice-interaction", 1, 1));
//            jsonObject.add("contentKeyDetails", contentKeyDetailsArray);

            jsonObject.addProperty("assessmentScore", assessmentScore);
            jsonObject.addProperty("endDate", endDate);
            jsonObject.addProperty("endTime", endTime);
            jsonObject.addProperty("startDate", startDate);
            jsonObject.addProperty("startTime", startTime);
            jsonObject.addProperty("title", title);
            jsonObject.addProperty("curriculumMapDetailsId", curriculumMapDetailsId);

            String jsonInputString = jsonObject.toString();

            try (BufferedOutputStream bos = new BufferedOutputStream(con.getOutputStream())) {
                byte[] input = jsonInputString.getBytes("utf-8");
                bos.write(input, 0, input.length);
                bos.flush();
            }

            Instant start = Instant.now();
            int responseCode = con.getResponseCode();
            Instant end = Instant.now();

            Duration duration = Duration.between(start, end);
            System.out.println("Response Code: " + responseCode);
            System.out.println("Request Duration: " + duration.toMillis() + " ms");
            TestRunner.getTest().log(Status.INFO, "Response Code: " + responseCode + " Response Durations: " + duration.toMillis() + " ms");


            BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
            String inputLine;
            StringBuilder response = new StringBuilder();

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();
            con.disconnect();

            System.out.println("API Response:");
            System.out.println(response);
            TestRunner.getTest().log(Status.INFO, "API response : " + response.toString());

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private Map<String, Object> createQuestionDetail(String questionId, int points, int originalPoints, String interactionType, int sequence, int groupNumber) {
        Map<String, Object> detail = new HashMap<>();
        detail.put("questionId", questionId);
        detail.put("points", points);
        detail.put("originalPoints", originalPoints);
        detail.put("interactionType", interactionType);
        detail.put("sequence", sequence);
        detail.put("groupNumber", groupNumber);
        return detail;
    }

    private JsonObject createContentKeyDetail(String questionId, int points, int originalPoints, String interactionType, int sequence, int groupNumber) {
        JsonObject detail = new JsonObject();
        detail.addProperty("questionId", questionId);
        detail.addProperty("points", points);
        detail.addProperty("originalPoints", originalPoints);
        detail.addProperty("score", true); // Assuming 'score' is always true
        JsonArray interactionTypeDesc = new JsonArray();
        interactionTypeDesc.add(interactionType);
        detail.add("interactionTypeDesc", interactionTypeDesc);
        detail.addProperty("sequence", sequence);
        detail.addProperty("groupNumber", groupNumber);
        return detail;
    }
}
