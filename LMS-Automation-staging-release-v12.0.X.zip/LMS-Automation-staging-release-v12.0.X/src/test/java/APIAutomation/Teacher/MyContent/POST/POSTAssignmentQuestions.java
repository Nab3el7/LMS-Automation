package APIAutomation.Teacher.MyContent.POST;

import APIAutomation.POST.LoginAPI;
import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import com.google.gson.JsonArray;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.security.cert.X509Certificate;
import java.time.Duration;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class POSTAssignmentQuestions {
    Helper helper;
    WebDriverWait wait;
    LoginAPI loginAPI;

    private final String appURL = Configurations.App_url;
    String assignmentQuestionsEndPoint = "content-command-service/api/v1/content/assessmentInformation";
    private final ExecutorService executor = Executors.newFixedThreadPool(Integer.parseInt(Configurations.Api_ThreadPool));

    public POSTAssignmentQuestions(WebDriver driver) {
        helper = new Helper();
        loginAPI = new LoginAPI(driver);
        wait = new WebDriverWait(driver, Duration.ofSeconds(120));
    }

    public void getAssignmentQuestionsAPIConcurrently(String createdAssessmentID) {
        Collection<String> tokens = LoginAPI.accessTokenMap.values();
        CompletableFuture<?>[] allFutures = tokens.stream()
                .map(token -> CompletableFuture.runAsync(() -> sendAssignmentQuestions(token, createdAssessmentID), executor))
                .toArray(CompletableFuture[]::new);

        CompletableFuture.allOf(allFutures).join();
        System.out.println("All requests completed.");
    }

    private void sendAssignmentQuestions(String bearerToken, String createdAssessmentID) {
        String apiUrl = appURL + assignmentQuestionsEndPoint +"/" + createdAssessmentID + "/questions";

        // Define the assessment details as a list of maps
        List<Map<String, Object>> assessmentDetails = new ArrayList<>();
        assessmentDetails.add(createAssessmentDetail("AP_CB8BAFD1BA2F4944BC7C95DF1F8A932D", 1, "48DC60B2B7CE47BE851EF76B5970FAF5", "Type the correct vocabulary term to complete the s...", "Spelling", "2023-06-14", "Gallopade", 7, List.of("inline-choice-spelling-interaction"), new ArrayList<>(), 7));
        assessmentDetails.add(createAssessmentDetail("AP_5E884F18582B420B887514F21DF66A18", 2, "48DC60B2B7CE47BE851EF76B5970FAF5", "Find your state senator and state representative. ...", "Fill-in-the-Blank Typing", "2023-06-14", "Gallopade", 12, List.of("inline-choice-text-interaction"), List.of("93b31c22-f7db-4ff2-88a5-2a1e4f718ed6", "93b31c22-f7db-4ff2-88a5-2a1e4f718ed6"), 12));
        assessmentDetails.add(createAssessmentDetail("761f312b-74f8-4f86-ac1a-9e8fb00c9961", 3, "48DC60B2B7CE47BE851EF76B5970FAF5", "Complete the cause and effect diagram to describe ...", "Image Labeling", "2023-08-18", "Gallopade", 3, List.of("graphic-gap-match-interaction"), List.of("2921f320-a09c-439d-a15b-d2c3fc615c2e", "46ce30e6-2a5e-44ec-a2c3-e370b958db71"), 3));
        assessmentDetails.add(createAssessmentDetail("6f7d85a0-1d57-4b6a-b496-68beb473e538", 4, "48DC60B2B7CE47BE851EF76B5970FAF5", "Add each description to the correct box.", "Classification", "2023-08-18", "Gallopade", 6, List.of("match-dragdrop-interaction"), List.of("ae75962e-4872-4624-af38-51ea24ce69d6", "63fd93a3-6538-44f7-94ef-52e56585214f", "ae75962e-4872-4624-af38-51ea24ce69d6", "53b5979e-f9a0-4d17-8232-2f98a8573ec6", "63fd93a3-6538-44f7-94ef-52e56585214f", "53b5979e-f9a0-4d17-8232-2f98a8573ec6"), 6));
        assessmentDetails.add(createAssessmentDetail("AP_C0EF6CACE80449A0BC15FBAE1ADF6078", 5, "48DC60B2B7CE47BE851EF76B5970FAF5", "Write a newspaper article on an unexpected “bad” e...", "Open Response", "2023-06-14", "Gallopade", 5, List.of("extended-text-interaction"), List.of("628c19bb-6d64-4b5c-8e2d-8d66797878db", "628c19bb-6d64-4b5c-8e2d-8d66797878db"), 5));
        assessmentDetails.add(createAssessmentDetail("0dacb29f-a31e-4788-91f0-05de772ad939", 6, "48DC60B2B7CE47BE851EF76B5970FAF5", "Add the correct location to each sentence to descr...", "Fill-in-the-Blank Drag and Drop", "2023-08-18", "Gallopade", 2, List.of("gap-match-interaction"), List.of("2921f320-a09c-439d-a15b-d2c3fc615c2e", "46ce30e6-2a5e-44ec-a2c3-e370b958db71", "43d8f647-2aa0-4a17-a7ba-65c6f75dcec9"), 2));
        assessmentDetails.add(createAssessmentDetail("AP_2E71573C0B824500BBB92BFDAD234908", 7, "48DC60B2B7CE47BE851EF76B5970FAF5", "Choose the correct word or phrase to complete the...", "Fill-in-the-Blank Dropdown", "2024-06-08", "Gallopade", 1, List.of("inline-choice-select-interaction"), new ArrayList<>(), 1));
        assessmentDetails.add(createAssessmentDetail("0162cddd-0842-4e2e-86f6-6f6d4d68ee9b", 8, "48DC60B2B7CE47BE851EF76B5970FAF5", "Decide if each statement describes a person using ...", "Multiple Choice Matrix", "2023-08-18", "Gallopade", 4, List.of("match-interaction"), List.of("ae75962e-4872-4624-af38-51ea24ce69d6", "44f95543-684c-4ce7-97bd-aad90b4dee17", "55644c1d-a60b-4e59-910a-c940a8b75cc1", "23eff7b5-885d-4469-a52f-9ee913896cb8"), 4));
        assessmentDetails.add(createAssessmentDetail("AP_7E3AAE705CC34CE2B4F97B2C6F3AB719", 9, "48DC60B2B7CE47BE851EF76B5970FAF5", "Place the events in chronological order, from earl...", "Sequencing", "2023-06-14", "Gallopade", 5, List.of("order-interaction"), List.of("ee47579a-3341-4203-a5f7-18c3722aa81e", "ee47579a-3341-4203-a5f7-18c3722aa81e"), 5));
        assessmentDetails.add(createAssessmentDetail("AP_C039E83564C04834838040B3FA460510", 10, "48DC60B2B7CE47BE851EF76B5970FAF5", "What traits and characteristics did explorers need...", "Multiple Select", "2023-06-14", "Gallopade", 7, List.of("choice-interaction"), List.of("a1c7f5a4-aa7b-4c4c-a17e-e408c48a9b70", "57001040-632d-4693-a909-51870b5d803b", "57001040-632d-4693-a909-51870b5d803b", "a1c7f5a4-aa7b-4c4c-a17e-e408c48a9b70"), 7));
        assessmentDetails.add(createAssessmentDetail("AP_2267549135014475B620F35A296F9D9F", 11, "48DC60B2B7CE47BE851EF76B5970FAF5", "Choose the correct definition of innovate ....", "Multiple Choice", "2023-06-14", "Gallopade", 1, List.of("choice-interaction-single"), new ArrayList<>(), 1));

        TrustManager[] trustAllCerts = new TrustManager[]{
                new X509TrustManager() {
                    public X509Certificate[] getAcceptedIssuers() {
                        return null;
                    }

                    public void checkClientTrusted(X509Certificate[] certs, String authType) {
                    }

                    public void checkServerTrusted(X509Certificate[] certs, String authType) {
                    }
                }
        };

        try {
            SSLContext sc = SSLContext.getInstance("TLS");
            sc.init(null, trustAllCerts, new java.security.SecureRandom());
            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

            URL url = new URL(apiUrl);
            HttpsURLConnection con = (HttpsURLConnection) url.openConnection();
            con.setRequestMethod("POST");
            con.setRequestProperty("accept", "*/*");
            con.setRequestProperty("Authorization", "Bearer " + bearerToken);
            con.setRequestProperty("content-type", "application/json");
            con.setRequestProperty("Timezone", "Asia/Karachi");
            con.setDoOutput(true);

            JsonObject jsonObject = new JsonObject();
            JsonArray assessmentDetailsArray = new JsonArray();
            for (Map<String, Object> detail : assessmentDetails) {
                assessmentDetailsArray.add(createJsonObjectFromMap(detail));
            }
            jsonObject.add("assessmentDetails", assessmentDetailsArray);
            jsonObject.addProperty("totalWeight", 0);
            jsonObject.addProperty("totalPercentage", 0);
            jsonObject.addProperty("totalPoints", "53.00");
            jsonObject.addProperty("stepNumber", "4");

            String jsonInputString = jsonObject.toString();

            try (BufferedOutputStream bos = new BufferedOutputStream(con.getOutputStream())) {
                byte[] input = jsonInputString.getBytes("utf-8");
                bos.write(input, 0, input.length);
                bos.flush();
            }

            Instant start = Instant.now();
            int responseCode = con.getResponseCode();
            Instant end = Instant.now();

            Duration duration = Duration.between(start, end);
            System.out.println("Response Code: " + responseCode);
            System.out.println("Request Duration: " + duration.toMillis() + " ms");
            TestRunner.getTest().log(Status.INFO, "Response Code: " + responseCode + " Response Durations: " + duration.toMillis() + " ms");


            BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
            String inputLine;
            StringBuilder response = new StringBuilder();

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();
            con.disconnect();

            System.out.println("API Response:");
            System.out.println(response);
            TestRunner.getTest().log(Status.INFO, "API response : " + response.toString());

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private Map<String, Object> createAssessmentDetail(String id, int sequence, String courseId, String title, String type, String createdDate, String author, int quesScore, List<String> interactionType, List<String> standards, int questionWeight) {
        Map<String, Object> detail = new HashMap<>();
        detail.put("id", id);
        detail.put("sequence", sequence);
        detail.put("percentage", 0);
        detail.put("status", "Active");
        detail.put("courseId", courseId);
        detail.put("questionId", id);
        detail.put("title", title);
        detail.put("type", type);
        detail.put("createdDate", createdDate);
        detail.put("author", author);
        detail.put("quesScore", quesScore);
        detail.put("interactionType", interactionType);
        detail.put("standards", standards);
        detail.put("questionWeight", questionWeight);
        return detail;
    }

    private JsonObject createJsonObjectFromMap(Map<String, Object> map) {
        JsonObject jsonObject = new JsonObject();
        for (Map.Entry<String, Object> entry : map.entrySet()) {
            if (entry.getValue() instanceof Number) {
                jsonObject.addProperty(entry.getKey(), (Number) entry.getValue());
            } else if (entry.getValue() instanceof Boolean) {
                jsonObject.addProperty(entry.getKey(), (Boolean) entry.getValue());
            } else if (entry.getValue() instanceof String) {
                jsonObject.addProperty(entry.getKey(), (String) entry.getValue());
            } else if (entry.getValue() instanceof List) {
                JsonArray jsonArray = new JsonArray();
                for (Object item : (List<?>) entry.getValue()) {
                    if (item instanceof String) {
                        jsonArray.add((String) item);
                    } else {
                        jsonArray.add(item.toString());
                    }
                }
                jsonObject.add(entry.getKey(), jsonArray);
            }
        }
        return jsonObject;
    }
}