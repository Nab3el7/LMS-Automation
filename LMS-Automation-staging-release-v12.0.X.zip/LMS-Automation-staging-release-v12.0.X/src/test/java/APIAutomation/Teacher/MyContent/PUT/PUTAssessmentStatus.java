package APIAutomation.Teacher.MyContent.PUT;

import javax.net.ssl.*;
import java.io.*;
import java.net.URL;
import java.security.cert.X509Certificate;
import java.time.Duration;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.*;

import APIAutomation.POST.LoginAPI;
import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import com.google.gson.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

public class PUTAssessmentStatus {
    Helper helper;
    WebDriverWait wait;
    LoginAPI loginAPI;

    private final String appURL = Configurations.App_url;
    String updateStatusEndPoint = "content-command-service/api/v1/assessmentInformation/";
    private final ExecutorService executor = Executors.newFixedThreadPool(Integer.parseInt(Configurations.Api_ThreadPool));

    public PUTAssessmentStatus(WebDriver driver) {
        helper = new Helper();
        loginAPI = new LoginAPI(driver);
        wait = new WebDriverWait(driver, Duration.ofSeconds(120));
    }

    public void updateAssessmentStatusConcurrently(String createdAssessmentID) {
        Collection<String> tokens = LoginAPI.accessTokenMap.values();
        CompletableFuture<?>[] allFutures = tokens.stream()
                .map(token -> CompletableFuture.runAsync(() -> updateAssessmentStatus(token, createdAssessmentID), executor))
                .toArray(CompletableFuture[]::new);

        CompletableFuture.allOf(allFutures).join();
        System.out.println("All requests completed.");
    }

    private void updateAssessmentStatus(String bearerToken, String createdAssessmentID) {
        String apiUrl = appURL + updateStatusEndPoint + createdAssessmentID +"/updateStatus";

        List<Map<String, Object>> assessmentDetails = new ArrayList<>();
        assessmentDetails.add(createAssessmentDetail("AP_CB8BAFD1BA2F4944BC7C95DF1F8A932D", "Type the correct vocabulary term to complete the s...", List.of("inline-choice-spelling-interaction"), "Gallopade", 7, "Spelling", 1, 0));
        assessmentDetails.add(createAssessmentDetail("AP_5E884F18582B420B887514F21DF66A18", "Find your state senator and state representative. ...", List.of("inline-choice-text-interaction"), "Gallopade", 12, "FIB Typing", 2, 1));
        assessmentDetails.add(createAssessmentDetail("761f312b-74f8-4f86-ac1a-9e8fb00c9961", "Complete the cause and effect diagram to describe ...", List.of("graphic-gap-match-interaction"), "Gallopade", 3, "Label Image Drag & Drop (LIDD)", 3, 2));
        assessmentDetails.add(createAssessmentDetail("6f7d85a0-1d57-4b6a-b496-68beb473e538", "Add each description to the correct box.", List.of("match-dragdrop-interaction"), "Gallopade", 6, "Categorize", 4, 3));
        assessmentDetails.add(createAssessmentDetail("AP_C0EF6CACE80449A0BC15FBAE1ADF6078", "Write a newspaper article on an unexpected “bad” e...", List.of("extended-text-interaction"), "Gallopade", 5, "Open Response", 5, 4));
        assessmentDetails.add(createAssessmentDetail("0dacb29f-a31e-4788-91f0-05de772ad939", "Add the correct location to each sentence to descr...", List.of("gap-match-interaction"), "Gallopade", 2, "FIB Drag & Drop", 6, 5));
        assessmentDetails.add(createAssessmentDetail("AP_2E71573C0B824500BBB92BFDAD234908", "Choose the correct word or phrase to complete the...", List.of("inline-choice-select-interaction"), "Gallopade", 1, "FIB Dropdown", 7, 6));
        assessmentDetails.add(createAssessmentDetail("0162cddd-0842-4e2e-86f6-6f6d4d68ee9b", "Decide if each statement describes a person using ...", List.of("match-interaction"), "Gallopade", 4, "Matrix", 8, 7));
        assessmentDetails.add(createAssessmentDetail("AP_7E3AAE705CC34CE2B4F97B2C6F3AB719", "Place the events in chronological order, from earl...", List.of("order-interaction"), "Gallopade", 5, "Order List", 9, 8));
        assessmentDetails.add(createAssessmentDetail("AP_C039E83564C04834838040B3FA460510", "What traits and characteristics did explorers need...", List.of("choice-interaction"), "Gallopade", 7, "Multiple Choice (MCQ)", 10, 9));
        assessmentDetails.add(createAssessmentDetail("AP_2267549135014475B620F35A296F9D9F", "Choose the correct definition of innovate ....", List.of("choice-interaction-single"), "Gallopade", 1, "Single Choice (SCQ)", 11, 10));

        try {
            TrustManager[] trustAllCerts = new TrustManager[]{
                    new X509TrustManager() {
                        public X509Certificate[] getAcceptedIssuers() {
                            return null;
                        }

                        public void checkClientTrusted(X509Certificate[] certs, String authType) {
                        }

                        public void checkServerTrusted(X509Certificate[] certs, String authType) {
                        }
                    }
            };

            SSLContext sc = SSLContext.getInstance("TLS");
            sc.init(null, trustAllCerts, new java.security.SecureRandom());
            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

            URL url = new URL(apiUrl);
            HttpsURLConnection con = (HttpsURLConnection) url.openConnection();
            con.setRequestMethod("PUT");
            con.setRequestProperty("accept", "*/*");
            con.setRequestProperty("Authorization", "Bearer " + bearerToken);
            con.setRequestProperty("content-type", "application/json");
            con.setRequestProperty("Timezone", "Asia/Karachi");
            con.setDoOutput(true);

            JsonObject jsonObject = new JsonObject();
            jsonObject.addProperty("title", "Automated Api Test Assessment");
            jsonObject.addProperty("description", "");
            jsonObject.addProperty("status", "Active");
            jsonObject.addProperty("courseId", "48DC60B2B7CE47BE851EF76B5970FAF5");
            jsonObject.addProperty("courseName", "Florida 4th Grade Social Studies");
            jsonObject.addProperty("createdBy", "MariaGomez");
            jsonObject.addProperty("createdDate", "2024-06-28");
            jsonObject.addProperty("lastModifiedBy", "MariaGomez");
            jsonObject.addProperty("lastModifiedDate", "2024-06-28");
            jsonObject.addProperty("studentInstruction", "");
            jsonObject.addProperty("totalPoints", 53);
            jsonObject.addProperty("stepNumber", "4");

            JsonObject contentType = new JsonObject();
            contentType.addProperty("createdBy", "fc7b7700-bb6b-4bf9-baa7-7505aa00a009");
            contentType.addProperty("status", "Active");
            contentType.addProperty("dateLastModified", "2024-06-28T12:22:46.141+00:00");
            contentType.addProperty("id", 3);
            contentType.addProperty("title", "Automated Api Custom Assessment");
            jsonObject.add("contentType", contentType);

            JsonArray assessmentDetailsArray = new JsonArray();
            for (Map<String, Object> detail : assessmentDetails) {
                assessmentDetailsArray.add(createJsonObjectFromMap(detail));
            }
            jsonObject.add("assessmentDetails", assessmentDetailsArray);

            JsonObject contentLabel = new JsonObject();
            contentLabel.addProperty("id", "f6c49b49-3473-4f2c-8eb5-61dcd9707787");
            contentLabel.addProperty("title", "Test Assessment");
            contentLabel.addProperty("description", "Custom Assessment");
            contentLabel.addProperty("thumbnailResourceId", "https://gallopade.blob.core.windows.net/public-blob-container/public/UserFiles/custom-cardimage-assessment.png");
            jsonObject.add("contentLabel", contentLabel);

            String jsonInputString = jsonObject.toString();

            try (BufferedOutputStream bos = new BufferedOutputStream(con.getOutputStream())) {
                byte[] input = jsonInputString.getBytes("utf-8");
                bos.write(input, 0, input.length);
                bos.flush();
            }

            Instant start = Instant.now();
            int responseCode = con.getResponseCode();
            Instant end = Instant.now();

            Duration duration = Duration.between(start, end);
            System.out.println("Response Code: " + responseCode);
            System.out.println("Request Duration: " + duration.toMillis() + " ms");
            TestRunner.getTest().log(Status.INFO, "Response Code: " + responseCode + " Response Durations: " + duration.toMillis() + " ms");


            BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
            String inputLine;
            StringBuilder response = new StringBuilder();

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();
            con.disconnect();

            System.out.println("API Response:");
            System.out.println(response);
            TestRunner.getTest().log(Status.INFO, "API response : " + response.toString());

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private Map<String, Object> createAssessmentDetail(String id, String title, List<String> interactionType, String author, int questionWeight, String type, int sequence, int groupNumber) {
        Map<String, Object> detail = new HashMap<>();
        detail.put("id", id);
        detail.put("title", title);
        detail.put("interactionType", interactionType);
        Map<String, Object> contentType = new HashMap<>();
        contentType.put("status", "Active");
        contentType.put("dateLastModified", "2024-06-28T12:22:46.165+00:00");
        contentType.put("id", 2);
        contentType.put("title", "Question");
        contentType.put("description", "");
        detail.put("contentType", contentType);
        detail.put("author", author);
        detail.put("createdBy", "fc7b7700-bb6b-4bf9-baa7-7505aa00a009");
        detail.put("createdDate", "2024-06-28");
        detail.put("lastModifiedBy", "fc7b7700-bb6b-4bf9-baa7-7505aa00a009");
        detail.put("lastModifiedDate", "2024-06-28");
        detail.put("questionId", id);
        detail.put("questionWeight", questionWeight);
        detail.put("status", "Active");
        detail.put("sequence", sequence);
        detail.put("questionNumber", sequence);
        detail.put("groupNumber", groupNumber);
        detail.put("type", type);
        detail.put("parentContentId", "");
        return detail;
    }

    private JsonObject createJsonObjectFromMap(Map<String, Object> map) {
        JsonObject jsonObject = new JsonObject();
        for (Map.Entry<String, Object> entry : map.entrySet()) {
            if (entry.getValue() instanceof Number) {
                jsonObject.addProperty(entry.getKey(), (Number) entry.getValue());
            } else if (entry.getValue() instanceof Boolean) {
                jsonObject.addProperty(entry.getKey(), (Boolean) entry.getValue());
            } else if (entry.getValue() instanceof String) {
                jsonObject.addProperty(entry.getKey(), (String) entry.getValue());
            } else if (entry.getValue() instanceof List) {
                JsonArray jsonArray = new JsonArray();
                for (Object item : (List<?>) entry.getValue()) {
                    if (item instanceof String) {
                        jsonArray.add((String) item);
                    } else {
                        jsonArray.add(item.toString());
                    }
                }
                jsonObject.add(entry.getKey(), jsonArray);
            } else if (entry.getValue() instanceof Map) {
                jsonObject.add(entry.getKey(), createJsonObjectFromMap((Map<String, Object>) entry.getValue()));
            }
        }
        return jsonObject;
    }
}