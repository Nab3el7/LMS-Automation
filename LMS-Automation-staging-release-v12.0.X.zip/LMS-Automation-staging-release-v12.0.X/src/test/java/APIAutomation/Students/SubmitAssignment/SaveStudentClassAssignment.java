package APIAutomation.Students.SubmitAssignment;

import APIAutomation.POST.LoginAPI;
import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import com.google.gson.JsonObject;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.security.cert.X509Certificate;
import java.time.Duration;
import java.time.Instant;
import java.util.Collection;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class SaveStudentClassAssignment {
    Helper helper;
    WebDriverWait wait;
    LoginAPI loginAPI;

    private final String appURL = Configurations.App_url;
    String submitAssignmentEndPoint = "gradebook-command-service/api/v1/saveStudentClassAssignment/submit";
    private final ExecutorService executor = Executors.newFixedThreadPool(Integer.parseInt(Configurations.Api_ThreadPool));

    String studentClassAssignmentId = "96b043ea-2cd3-48a4-b4e4-8d3bf215e664";
    String studentComment = "Testing";
    String status = "Submitted";

    public SaveStudentClassAssignment(WebDriver driver) {
        helper = new Helper();
        loginAPI = new LoginAPI(driver);
        wait = new WebDriverWait(driver, Duration.ofSeconds(120));
    }

    public void saveStudentClassAssignmentConcurrently() {
        Collection<String> tokens = LoginAPI.accessTokenMap.values();
        CompletableFuture<?>[] allFutures = tokens.stream()
                .map(token -> CompletableFuture.runAsync(() -> saveStudentClassAssignment(token), executor))
                .toArray(CompletableFuture[]::new);

        CompletableFuture.allOf(allFutures).join();
        System.out.println("All requests completed.");
    }

    private void saveStudentClassAssignment(String bearerToken) {
        String apiUrl = appURL + submitAssignmentEndPoint;

        try {
            TrustManager[] trustAllCerts = new TrustManager[]{
                    new X509TrustManager() {
                        public X509Certificate[] getAcceptedIssuers() {
                            return null;
                        }

                        public void checkClientTrusted(X509Certificate[] certs, String authType) {
                        }

                        public void checkServerTrusted(X509Certificate[] certs, String authType) {
                        }
                    }
            };

            SSLContext sc = SSLContext.getInstance("TLS");
            sc.init(null, trustAllCerts, new java.security.SecureRandom());
            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

            URL url = new URL(apiUrl);
            HttpsURLConnection con = (HttpsURLConnection) url.openConnection();
            con.setRequestMethod("POST");
            con.setRequestProperty("accept", "application/json, text/plain, */*");
            con.setRequestProperty("Authorization", "Bearer " + bearerToken);
            con.setRequestProperty("content-type", "application/json");
            con.setRequestProperty("accept-language", "en-GB,en-US;q=0.9,en;q=0.8");
            con.setRequestProperty("Timezone", "Asia/Karachi");
            con.setRequestProperty("sec-ch-ua", "\"Google Chrome\";v=\"125\", \"Chromium\";v=\"125\", \"Not.A/Brand\";v=\"24\"");
            con.setRequestProperty("sec-ch-ua-mobile", "?0");
            con.setRequestProperty("sec-ch-ua-platform", "\"macOS\"");
            con.setRequestProperty("user-agent", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36");
            con.setDoOutput(true);

            JsonObject jsonObject = new JsonObject();
            JsonObject studentClassAssignment = new JsonObject();
            studentClassAssignment.addProperty("studentClassAssignmentId", studentClassAssignmentId);
            studentClassAssignment.addProperty("studentComment", studentComment);
            studentClassAssignment.add("studentUploadedResourceId", null);
            studentClassAssignment.addProperty("status", status);

            jsonObject.add("studentClassAssignment", studentClassAssignment);

            String jsonInputString = jsonObject.toString();

            try (BufferedOutputStream bos = new BufferedOutputStream(con.getOutputStream())) {
                byte[] input = jsonInputString.getBytes("utf-8");
                bos.write(input, 0, input.length);
                bos.flush();
            }

            Instant start = Instant.now();
            int responseCode = con.getResponseCode();
            Instant end = Instant.now();

            Duration duration = Duration.between(start, end);
            System.out.println("Response Code: " + responseCode);
            System.out.println("Request Duration: " + duration.toMillis() + " ms");
            TestRunner.getTest().log(Status.INFO, "Response Code: " + responseCode + " Response Durations: " + duration.toMillis() + " ms");


            BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
            String inputLine;
            StringBuilder response = new StringBuilder();

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();

            System.out.println("API Response:");
            System.out.println(response);
            TestRunner.getTest().log(Status.INFO, "API response : " + response.toString());

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
