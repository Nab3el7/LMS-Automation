package APIAutomation;

import APIAutomation.POST.LoginAPI;
import StepDefinitions.Configurations;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.security.cert.X509Certificate;
import java.time.Duration;
import java.time.Instant;
import java.util.concurrent.*;
import java.util.stream.IntStream;

public class TestApi {
    WebDriverWait wait;
    LoginAPI loginAPI;

    private final String appURL = Configurations.App_url;
    String getTestEndPoint = "gradebook-query-service/api/v1/hello-world";
    private final ExecutorService executor = Executors.newFixedThreadPool(500);

    public TestApi(WebDriver driver) {
        loginAPI = new LoginAPI(driver);
        wait = new WebDriverWait(driver, Duration.ofSeconds(120));
    }

    public void getTestAPIConcurrently() {
        String accessToken = "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3MTk4MTcwNjMsInVzZXJfbmFtZSI6IntcInVzZXJJZFwiOlwiZmM3Yjc3MDAtYmI2Yi00YmY5LWJhYTctNzUwNWFhMDBhMDA5XCIsXCJ1c2VyTmFtZVwiOlwiZmxhbGxncmFkZXNAZ3AuY29tXCIsXCJmaXJzdE5hbWVcIjpcIk1hcmlhXCIsXCJsYXN0TmFtZVwiOlwiR29tZXpcIixcImF2YXRhclwiOlwiaHR0cHM6Ly9nYWxsb3BhZGVpbmMuYmxvYi5jb3JlLndpbmRvd3MubmV0L3B1YmxpYy1ibG9iLWNvbnRhaW5lci9wcm9kLzJCQzZFREYwLTc0NjQtNDY5OS1CQjFFLUZBQjIxMEJBQTAwNC91c2VyLWF2YXRhci9GQzdCNzcwMC1CQjZCLTRCRjktQkFBNy03NTA1QUEwMEEwMDkvZTA1NjA5ZjMtNTMxOS00Nzg2LThkNzUtNDJjYmMwOTY5OWM4LnBuZ1wiLFwidGVuYW50XCI6e1wiaWRcIjpcIjJiYzZlZGYwLTc0NjQtNDY5OS1iYjFlLWZhYjIxMGJhYTAwNFwiLFwibmFtZVwiOlwiRmxvcmlkYSBEZW1vIERpc3RyaWN0XCJ9LFwicm9sZVwiOlt7XCJpZFwiOjMsXCJuYW1lXCI6XCJUZWFjaGVyXCIsXCJzY29wZVwiOltcIjRcIl19XSxcImV4dGVybmFsUm9sZXNcIjpbXSxcInNlc3Npb25UaW1lT3V0XCI6MTAsXCJzY2hvb2xZZWFySWRzXCI6W1wiMjJcIl0sXCJ2ZW5kb3JcIjpcIkFQUExJQ0FUSU9OX1VTRVJcIixcInZlbmRvcklkXCI6XCI2MVwiLFwib3JnSWRcIjpcIlwiLFwiY291cnNlSWRcIjpcIlwiLFwic3RhdGVOYXRpb25hbElkXCI6XCIxMFwiLFwicGFzc3dvcmRQb2xpY3lcIjp7XCJwYXNzd29yZExlbmd0aFwiOjYsXCJwYXNzd29yZE51bWVyaWNcIjpmYWxzZSxcInBhc3N3b3JkVXBwZXJDYXNlXCI6ZmFsc2V9LFwibGFuZ3VhZ2VcIjp7XCJpZFwiOlwiMTAzXCIsXCJuYW1lXCI6XCJFbmdsaXNoXCIsXCJjb2RlXCI6XCJlblwifSxcInVzZXJMYXN0TG9naW5cIjpcIjIwMjQtMDYtMjRUMDg6MTA6MzkuODE4WlwifSIsImF1dGhvcml0aWVzIjpbIkRlbGV0ZSIsIlJlYWQiLCJXcml0ZSIsIkFQUExJQ0FUSU9OX1VTRVIiLCJDb250ZW50Q29sbGVjdGlvbl9SZWFkIiwiQ29udGVudENvbGxlY3Rpb25fRWRpdCIsIlJPTEVfVGVhY2hlciIsIlVwZGF0ZSIsIkNvbnRlbnRDb2xsZWN0aW9uX1B1Ymxpc2giXSwianRpIjoiYTg1NzM0Y2MtZDA3ZC00ODE5LWJmNTEtMjUzZjRjZWNkMzQ1IiwiY2xpZW50X2lkIjoic3ByaW5nYmFua0NsaWVudCIsInNjb3BlIjpbInJlYWQiLCJ3cml0ZSJdfQ.Noo4z_VEEvv0tImED1TzUpIZBqGInnq-2ASRy6eH0lrVrcvn0cj7iLSDHq1jlNOuDcVB1ZLa6mIAeCZh8eLGqdFPlffqGumeEJdTwgEel4HPqOxUtE4oGX8USDvHQFw9ADY6xeWHNq5hSuXjJh9MTaD5H-GGOQH45veMr9ufsJZedluWVgq8t9YY7jsr6Uxpq99vyciXCyy-7I0KVK8CB9SQZy5f79MQletOo1k8J2c84tjvwCFnQcEQ7l9HH-asphOLmr3S1Wk6vDbCHgMI0F42GAuC7C5e-BsLHDO1WwuIX2S8IcijgQ840N-SgBwrNpUDWnOPahl69Xg_YvJvyQ";
        CompletableFuture<?>[] allFutures = IntStream.range(0, 80000)
                .mapToObj(i -> CompletableFuture.runAsync(() -> getTestApi(accessToken), executor))
                .toArray(CompletableFuture[]::new);

        CompletableFuture.allOf(allFutures).join();
        System.out.println("All requests completed.");
    }

    private void getTestApi(String bearerToken) {
        String apiUrl = appURL + getTestEndPoint;
        SSLContext sc = createTrustAllSslContext();

        try {
            URL url = new URL(apiUrl);
            HttpsURLConnection con = (HttpsURLConnection) url.openConnection();
            con.setSSLSocketFactory(sc.getSocketFactory());
            con.setRequestMethod("GET");
            con.setRequestProperty("Authorization", "Bearer " + bearerToken);

            Instant start = Instant.now();
            int responseCode = con.getResponseCode();
            Instant end = Instant.now();

            Duration duration = Duration.between(start, end);
            System.out.println("Response Code: " + responseCode + " in " + duration.toMillis() + " ms");
            TestRunner.getTest().log(Status.INFO, "Response Code: " + responseCode + " Response Durations: " + duration.toMillis() + " ms");


            BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
            String inputLine;
            StringBuilder response = new StringBuilder();
            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();

            System.out.println("API Response: ");
            System.out.println(response);
            TestRunner.getTest().log(Status.INFO, "API response : " + response.toString());

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private SSLContext createTrustAllSslContext() {
        try {
            SSLContext sc = SSLContext.getInstance("TLS");
            sc.init(null, new TrustManager[]{new X509TrustManager() {
                public X509Certificate[] getAcceptedIssuers() { return null; }
                public void checkClientTrusted(X509Certificate[] certs, String authType) { }
                public void checkServerTrusted(X509Certificate[] certs, String authType) { }
            }}, new java.security.SecureRandom());
            return sc;
        } catch (Exception e) {
            throw new RuntimeException("Failed to create a trust-all SSL context", e);
        }
    }
}
