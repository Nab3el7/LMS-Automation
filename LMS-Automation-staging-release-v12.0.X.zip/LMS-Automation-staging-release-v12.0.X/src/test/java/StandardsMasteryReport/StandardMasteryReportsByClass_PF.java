package StandardsMasteryReport;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Assignmment.ReleaseAssignment_PF;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import static pageFactory.Assignmment.ReleaseAssignment_PF.referenceArray;

public class StandardMasteryReportsByClass_PF {

    WebDriverWait wait;
    WebDriver driver;
    Helper helper;
    Actions actions;
    JavascriptExecutor js;

    ReleaseAssignment_PF releaseAssignment_pf;

    public static ThreadLocal<List<String>> standardsList = ThreadLocal.withInitial(ArrayList::new);
    private final String specificStudentName = "David Warner";

    @FindBy(xpath = "//div[contains(@class, 'StudentListingAndTableWrapper')]")
    WebElement studentAssignmentTable;

    public StandardMasteryReportsByClass_PF(WebDriver driver) {
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        helper = new Helper();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        actions = new Actions(driver);
        releaseAssignment_pf = new ReleaseAssignment_PF(driver);
    }

    public void VerifyAndClickOnStandardMasteryReport() throws InterruptedException {
        System.out.println("I'm Into Click on Standard Mastery Reports From Favourite Reports");
        TestRunner.getTest().log(Status.INFO,"I'm Into Click on Standard Mastery Reports From Favourite Reports");

        WebElement standard_mastery_Report= driver.findElement(By.xpath("//box[normalize-space()='Standards Mastery Report']"));

        if (standard_mastery_Report.isDisplayed()){
            standard_mastery_Report.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Standard Mastery Reports Click Successfully");
        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Standard Mastery Reports Not Found on Reports Dashboard");
        }
    }

    public void verifyRightSideStandardMasterText() throws InterruptedException {
        System.out.println("I'm Into Verify That Right Side Text is Present and Match with expected Text on Reports Screen");
        TestRunner.getTest().log(Status.INFO, "I'm Into Verify That Right Side Text is Present and Match with expected Text on Reports Screen");

        String expectedText = "Please select and apply filters on the left to view Standards Mastery Overview Report";

        try {
            WebElement element = driver.findElement(By.xpath("//div[contains(@class,'assessments-container')]//h4"));

            if (element.isDisplayed()) {
                System.out.println("Text is present on Reports Screen.");
                TestRunner.getTest().log(Status.PASS,"Text is present on Reports Screen.");

                String actualText = element.getText().replace("\n", " ").trim();
                TestRunner.getTest().log(Status.INFO,"Text From Reports Screen: " + actualText);
                System.out.println("Text From Reports Screen: " + actualText);

                if (actualText.equals(expectedText)) {
                    System.out.println("Actual Text : " + actualText + " match with Expected Text: " + expectedText);
                    TestRunner.getTest().log(Status.PASS,"Actual Text : " + actualText + " match with Expected Text: " + expectedText);
                } else {
                    System.out.println("Actual Text : " + actualText + " Not match with Expected Text: " + expectedText);
                    TestRunner.getTest().log(Status.FAIL,"Actual Text : " + actualText + " Not match with Expected Text: " + expectedText);
                }

            } else {
                System.out.println("Text is Not present on Reports Screen.");
                TestRunner.getTest().log(Status.FAIL,"Text is Not present on Reports Screen.");
            }

        } catch (NoSuchElementException e) {
            System.out.println("Text Element is not present in the DOM.");
            TestRunner.getTest().log(Status.FAIL,"Text Element is not present in the DOM.");
        }
    }


    public void checkByDefaultByClassButtonIsPressedInStandardsMastery() throws InterruptedException {
        System.out.println("I'm Into Validate that By Default By Class is Checked/Pressed in Standards Mastery Report");
        TestRunner.getTest().log(Status.INFO, "I'm Into Validate that By Default By Class is Checked/Pressed in Standards Mastery Report");

        WebElement byClassButton = driver.findElement(By.xpath("//button[@value='classView']"));

        String isByClassSelected = byClassButton.getAttribute("aria-pressed");

        if (isByClassSelected.equals("true")) {
            TestRunner.getTest().log(Status.PASS, "The 'By Class' button is pressed by default.");
            System.out.println("The 'By Class' button is pressed by default.");
        } else {
            byClassButton.click();

            Thread.sleep(500);

            isByClassSelected = byClassButton.getAttribute("aria-pressed");

            if (isByClassSelected.equals("true")) {
                TestRunner.getTest().log(Status.PASS, "The 'By Class' button was clicked and is now pressed.");
                System.out.println("The 'By Class' button was clicked and is now pressed.");
            } else {
                TestRunner.getTest().log(Status.FAIL, "The 'By Class' button could not be pressed.");
                System.out.println("The 'By Class' button could not be pressed.");
            }
        }
    }

    public void verifyStudentDataInStandardsMasteryReport() throws InterruptedException {
        System.out.println(">>> Starting: Verify Student Data Table Display On Reports");
        TestRunner.getTest().log(Status.INFO, "Starting verification of Student Data Table in Standards Mastery Report");

        try {
            WebElement assignmentTable = wait.until(ExpectedConditions.visibilityOf(studentAssignmentTable));
            TestRunner.getTest().log(Status.PASS, "Student Assignment Table is visible");

            List<WebElement> standardsContainers = assignmentTable.findElements(By.xpath(".//thead//tr//th"));
            System.out.println("Total standards: " + standardsContainers.size());
            TestRunner.getTest().log(Status.INFO, "Total standards found: " + standardsContainers.size());

            for (WebElement standard : standardsContainers) {
                String headerText = standard.getText().trim();
                standardsList.get().add(headerText);
                System.out.println("Standard Header: " + headerText);
                TestRunner.getTest().log(Status.INFO, "Standard Header: " + headerText);
            }

            WebElement searchBar = driver.findElement(By.xpath("//input[@placeholder='Search Student']"));

            if (searchBar.isDisplayed()) {
                searchBar.clear();
                searchBar.sendKeys(specificStudentName);
                Thread.sleep(2000);

                List<WebElement> listStudent = driver.findElements(By.xpath("//div[contains(@class, 'studentItem')]"));
                boolean isStudentFound = false;

                for (WebElement student : listStudent) {
                    String studentName = student.getText().trim();
                    System.out.println("Student Found: " + studentName);

                    if (studentName.equals(specificStudentName)) {
                        System.out.println(">>> Specific student '" + specificStudentName + "' found.");
                        TestRunner.getTest().log(Status.PASS, "Student '" + specificStudentName + "' found in the list");

                        try {
                            WebElement icon = student.findElement(By.tagName("img"));
                            if (icon.isDisplayed()) {
                                TestRunner.getTest().log(Status.PASS, "Icon displayed for student: " + specificStudentName);
                            } else {
                                TestRunner.getTest().log(Status.FAIL, "Icon NOT displayed for student: " + specificStudentName);
                            }
                        } catch (NoSuchElementException e) {
                            TestRunner.getTest().log(Status.FAIL, "Icon element not found for student: " + specificStudentName);
                        }

                        List<String> referenceArrayList = referenceArray.get();
                        for (String s : referenceArrayList) {
                            String referenceText = s.trim();
                            boolean matchFound = false;

                            for (String standardText : standardsList.get()) {
                                if (referenceText.equals(standardText.trim())) {
                                    System.out.println("Match found for reference: " + referenceText);
                                    TestRunner.getTest().log(Status.PASS, "Match found for reference: " + referenceText);
                                    matchFound = true;
                                    break;
                                }
                            }

                            if (!matchFound) {
                                System.out.println("Mismatch for reference: " + referenceText);
                                TestRunner.getTest().log(Status.FAIL, "Mismatch for reference: " + referenceText);
                            }
                        }

                        isStudentFound = true;
                        break;
                    }
                }

                if (!isStudentFound) {
                    TestRunner.getTest().log(Status.FAIL, "Student '" + specificStudentName + "' not found in the list.");
                    System.out.println(">>> Student '" + specificStudentName + "' not found.");
                }

            } else {
                TestRunner.getTest().log(Status.FAIL, "Search bar not displayed on the report page.");
            }

        } catch (TimeoutException e) {
            System.out.println(">>> Timeout: Assignment table not visible.");
            TestRunner.getTest().log(Status.FAIL, "Timeout while waiting for Student Assignment Table to become visible.");
        }
    }

    public void verifyStudentAndGetStandardsMasteryReport() throws InterruptedException {
        System.out.println(">>> Starting: Verify Student Data Table Display and Get Standards Mastery Report");
        TestRunner.getTest().log(Status.INFO, "Starting verification of Student Data Table and Get Standards Mastery Report");

        try {
            TestRunner.getTest().log(Status.PASS, "Student Assignment Table is visible");

            List<WebElement> listStudent = driver.findElements(By.xpath("//div[contains(@class, 'studentItem')]"));
            boolean isStudentFound = false;

            for (WebElement student : listStudent) {
                String studentName = student.getText().trim();
                System.out.println("Student Found: " + studentName);

                if (studentName.equals(specificStudentName)) {
                    System.out.println(">>> Specific student '" + specificStudentName + "' found.");
                    TestRunner.getTest().log(Status.PASS, "Student '" + specificStudentName + "' found in the list");

                    try {
                        List<WebElement> studentScores = driver.findElements(By.xpath("//div[@class = 'flex']//table//div[contains(@class, 'integersPoints')]"));
                        for (WebElement studentScore : studentScores) {
                            if (studentScore.isDisplayed()) {
                                String scoreText = studentScore.getText().trim();
                                System.out.println(">>> Full Student Score Data: " + scoreText);
                                TestRunner.getTest().log(Status.INFO, "Student score data for '" + specificStudentName + "': " + scoreText);
                            }
                        }
                    } catch (Exception e) {
                        TestRunner.getTest().log(Status.WARNING, "Could not fetch full row data for student: " + specificStudentName);
                    }

                    isStudentFound = true;
                    break;
                }
            }

            if (!isStudentFound) {
                TestRunner.getTest().log(Status.FAIL, "Student '" + specificStudentName + "' not found in the list.");
                System.out.println(">>> Student '" + specificStudentName + "' not found.");
            }
        } catch (TimeoutException e) {
            System.out.println(">>> Timeout: Assignment table not visible.");
            TestRunner.getTest().log(Status.FAIL, "Timeout while waiting for Student Assignment Table to become visible.");
        }
    }

}
