package StandardsMasteryReport;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;
import java.util.Random;

import static pageFactory.Assignmment.ReleaseAssignment_PF.referenceArray;

public class ReportDashboardFilters_PF {
    WebDriver driver;
    public WebDriverWait wait;

    String selectedDistrict;
    String selectedTeacher;

    Helper helper;

    @FindBy(xpath = "//div[div[text()='District']]//input[@type='text']") // Locate the dropdown
    WebElement dropdown_select_district;

    @FindBy(xpath = "//div[div[text()='School']]//input[@type='text']") // Locate the dropdown
    WebElement dropdown_select_school;

    @FindBy(xpath = "//div[contains(text(),'Teachers')]/following-sibling::div//div[@role='button' or @role='combobox']") // Locate the dropdown
    WebElement dropdown_select_teacher;

    @FindBy(xpath = "//div[contains(text(),'Classes')]/following-sibling::div//div[@role='button' or @role='combobox']")
    WebElement select_classes;

    @FindBy(xpath = "//button[normalize-space()='Apply Filters']")
    WebElement btn_SchoolApplyFilter;

    @FindBy(xpath = "//div[contains(@class,'StandardOverViewWidget')]")
    WebElement widget_StandardsMasteryOverview;

    @FindBy(xpath = "//div[contains(@class,'standardDropDown')]")
    WebElement dropdown_AllStandards;

    @FindBy(xpath = "//div[contains(@class,'userDropDown')]")
    WebElement dropdown_AllStudents;

    @FindBy(xpath = "//div[contains(@class, 'MuiTableCell-body') and contains(text(), 'Mary Johansen')]")
    WebElement studentRow;

    @FindBy(xpath = "//tbody//tr[contains(@class, 'MuiTableRow-root')]")
    List<WebElement> studentRows;

    public ReportDashboardFilters_PF(WebDriver driver) {
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        PageFactory.initElements(driver, this);
        helper = new Helper();
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
    }

//    public void selectReportDashboardDistrict(String selectedReportDistrict) throws InterruptedException {
//        TestRunner.getTest().log(Status.INFO, "I'm in to select reports dashboard district");
//
//        dropdown_select_district.click();
//        Thread.sleep(2000);
//        WebElement listDistricts = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//ul[@role='listbox']")));
//
//        List<WebElement> optionsDistrict = listDistricts.findElements(By.xpath(".//li"));
//
//        System.out.println("District List is: " + optionsDistrict.size());
//
//        if (optionsDistrict.isEmpty()) {
//            System.out.println("No options found in the District dropdown.");
//            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: No options found in the District dropdown.");
//        } else {
//            boolean districtFound = false;
//            for (WebElement option : optionsDistrict) {
//                String districtName = option.getText().trim();
//                if (districtName.contains(selectedReportDistrict.trim())) {
//                    option.click();
//                    districtFound = true;
//                    selectedDistrict = districtName;
//                    TestRunner.getTest().log(Status.INFO, "Selected District Name: " + selectedDistrict);
//                    System.out.println("Selected District Name: " + selectedDistrict);
//                    TestRunner.getTest().log(Status.PASS, "Testcase Passed: School district selected successfully");
//                    break;
//                }
//            }
//
//            if (!districtFound) {
//                System.out.println("District '" + selectedReportDistrict + "' not found in the dropdown.");
//                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: District '" + selectedReportDistrict + "' not found in the dropdown.");
//            }
//        }
//
//        Actions actions = new Actions(driver);
//        actions.sendKeys(Keys.ESCAPE).build().perform();
//    }

    public void selectReportDashboardDistrict() {
        try {
            System.out.println("I'm Into Select District From Dropdown");
            TestRunner.getTest().log(Status.INFO, "I'm Into Select District From Dropdown");

            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
            wait.until(ExpectedConditions.elementToBeClickable(dropdown_select_district)).click();

            WebElement listDistrict = wait.until(ExpectedConditions.presenceOfElementLocated(
                    By.xpath("//ul[@role='listbox']")
            ));

            List<WebElement> optionsDistrict = listDistrict.findElements(By.xpath(".//li"));
            Thread.sleep(1000);

            System.out.println("District List Size: " + optionsDistrict.size());

            if (optionsDistrict.isEmpty()) {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: No options found in the District dropdown");
                System.out.println("No options found in the District dropdown.");
                throw new RuntimeException("No District Value found in dropdown");
            } else {
                System.out.println("Available District Options:");
                boolean districtFound = false;

                for (WebElement district : optionsDistrict) {
                    String districtName = district.getText();
                    System.out.println(districtName);

                    if (districtName.contains("Florida Demo District") || districtName.contains("FL QA District") ) {
                        districtFound = true;
                        district.click();
                        selectedDistrict = districtName;
                        System.out.println("Selected District: " + selectedDistrict);
                        TestRunner.getTest().log(Status.INFO, "Selected District: " + selectedDistrict);
                        break;
                    }
                }

                Thread.sleep(1000);
                actions.sendKeys(Keys.ESCAPE).perform();

                if (!districtFound) {
                    TestRunner.getTest().log(Status.FAIL, "Test Case Failed: District 'Florida Demo District' not found");
                    System.out.println("District 'Florida Demo District' not found.");
                    throw new RuntimeException("District 'Florida Demo District' not found in dropdown");
                }
            }

        } catch (TimeoutException e) {
            TestRunner.getTest().log(Status.FAIL, "Timeout waiting for District dropdown: " + e.getMessage());

        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "Exception in selectDistrictForReport: " + e.getMessage());
        }
    }


    public String school_filter;

    Actions actions;

    public void selectReportDashboardSchool() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm in to select School");

        dropdown_select_school.click();

        WebElement listDistrict = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[contains(@role, 'listbox')]")));
        List<WebElement> optionsDistrict = listDistrict.findElements(By.xpath(".//li"));
        Thread.sleep(1000);

        System.out.println("School List size: " + optionsDistrict.size());

        if (optionsDistrict.isEmpty()) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: No options found in the School dropdown");
            System.out.println("No options found in the School dropdown.");
            throw new RuntimeException("No School Value found in dropdown");
        }

        boolean schoolFound = false;

        for (WebElement school : optionsDistrict) {
            String schoolName = school.getText().trim();
            System.out.println("Found school: " + schoolName);

            // Condition to select the school
            if (schoolName.contains("Florida ES") || schoolName.contains("FL Element")) {
                school.click();
                school_filter = schoolName;
                schoolFound = true;

                System.out.println("Selected School: " + school_filter);
                TestRunner.getTest().log(Status.INFO, "Selected School: " + school_filter);
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: School Filter selected successfully");
                break;
            }

        }

        Thread.sleep(1000);
        actions.sendKeys(Keys.ESCAPE).perform();

        if (!schoolFound) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: No matching school found in the dropdown");
            System.out.println("No matching school found.");
            throw new RuntimeException("No matching school found in dropdown");
        }
    }

    public void selectReportDashboardTeacher(String selectedReportTeacher) throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm in to select Teacher");

        dropdown_select_teacher.click();
        WebElement listTeachers = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//ul[@role='listbox']")));

        List<WebElement> optionsTeacher = listTeachers.findElements(By.xpath(".//li"));

        System.out.println("Teachers List is: " + optionsTeacher.size());

        if (optionsTeacher.isEmpty()) {
            System.out.println("No options found in the Teachers dropdown.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: No options found in the Teachers dropdown.");
        } else {
            boolean teacherFound = false;
            for (WebElement option : optionsTeacher) {
                String teacherName = option.getText().trim();
                if (teacherName.equalsIgnoreCase(selectedReportTeacher.trim())) {
                    option.click();
                    teacherFound = true;
                    selectedTeacher = teacherName;
                    TestRunner.getTest().log(Status.INFO, "Selected Teacher Name: " + selectedTeacher);
                    System.out.println("Selected Teacher Name: " + selectedTeacher);
                    TestRunner.getTest().log(Status.PASS, "Testcase Passed: School teacher selected successfully");
                    break;
                }
            }

            if (!teacherFound) {
                System.out.println("Teacher '" + selectedReportTeacher + "' not found in the dropdown.");
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Teacher '" + selectedReportTeacher + "' not found in the dropdown.");
            }
        }

        Actions actions = new Actions(driver);
        actions.sendKeys(Keys.ESCAPE).build().perform();
    }

    public void selectReportDashboardClasses(String selectedReportClass) throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm in to select Classes");
        select_classes.click();

        Thread.sleep(1000);
        List<WebElement> optionsClasses = driver.findElements(By.xpath("//ul[@role='listbox']//li"));

        System.out.println("Classes List is: " + optionsClasses.size());

        if (optionsClasses.isEmpty()) {
            System.out.println("No options found in the Classes dropdown.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : No options found in the Classes dropdown.");
            throw new RuntimeException("No Classes Found.");
        } else {
            System.out.println("Classes:");

            for (WebElement classes : optionsClasses) {
                System.out.println(classes.getText());
                if (classes.getText().equals(selectedReportClass)) {
                    classes.click();
                    TestRunner.getTest().log(Status.INFO, "Selected Class is: " + selectedReportClass);
                    System.out.println("Clicked on Course: " + selectedReportClass);
                    TestRunner.getTest().log(Status.PASS, "Testcase Passed   :  Classes selected successfully");
                    break;
                }
            }
        }
        Actions actions = new Actions(driver);
        actions.sendKeys(Keys.ESCAPE).build().perform();
    }

    public void applyReportDashboardFilter() {
        TestRunner.getTest().log(Status.INFO, "I'm in to select the apply filter in report dashboard");
        if (btn_SchoolApplyFilter.isEnabled()) {
            btn_SchoolApplyFilter.click();
            TestRunner.getTest().log(Status.PASS, "Testcase Passed: Filter Button is enabled and clicked successfully");
            System.out.println("Filter Button is enabled and clicked.");
        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Filter Button is disabled and cannot be clicked");
            System.out.println("Filter Button is disabled and cannot be clicked.");
        }
    }

    public void ValidateStudentStandardsMasteryOverviewDataOnReportDashboard() throws InterruptedException {
        System.out.println(">>> Starting: verification student standards mastery overview data on report dashboard");
        TestRunner.getTest().log(Status.INFO, "Starting verification student standards mastery overview data on report dashboard");

        try {
            wait.until(ExpectedConditions.visibilityOf(widget_StandardsMasteryOverview));
            TestRunner.getTest().log(Status.PASS, "Student Standards Mastery Overview Widget is visible");

            if (dropdown_AllStandards.isDisplayed()) {
                System.out.println(">>> 'All Standards' Dropdown is visible");
                Thread.sleep(1000);

                dropdown_AllStandards.click();
                Thread.sleep(2000);

                // Wait and fetch the list of visible dropdown options (adjust XPath/CSS selector as needed)
                List<WebElement> standardsOptions = driver.findElements(By.xpath("//ul//li")); // Example for MUI list items

                if (!standardsOptions.isEmpty()) {
                    Random random = new Random();
                    int randomIndex = random.nextInt(standardsOptions.size());

                    WebElement selectedOption = standardsOptions.get(randomIndex);
                    String selectedStandard = selectedOption.getText();

                    selectedOption.click();

                    System.out.println(">>> Selected 'All Standards' value: " + selectedStandard);
                    TestRunner.getTest().log(Status.PASS, "Selected 'All Standards' value: " + selectedStandard);
                } else {
                    TestRunner.getTest().log(Status.FAIL, "'All Standards' Dropdown is empty");
                    System.out.println(">>> 'All Standards' Dropdown is empty");
                }

                if (dropdown_AllStudents.isDisplayed()) {
                    System.out.println(">>> 'All Students' Dropdown is visible");

                    Thread.sleep(1000);
                    // Click to open the dropdown
                    dropdown_AllStudents.click();
                    Thread.sleep(2000);

                    // Wait and fetch dropdown options – adjust XPath based on your actual DOM
                    List<WebElement> studentsOptions = driver.findElements(By.xpath("//ul//li")); // or use a more specific XPath if needed

                    if (!studentsOptions.isEmpty()) {
                        Random random = new Random();
                        int randomIndex = random.nextInt(studentsOptions.size());

                        // Get and click a random option
                        WebElement selectedOption = studentsOptions.get(randomIndex);
                        String selectedStudent = selectedOption.getText();
                        selectedOption.click();

                        System.out.println(">>> Selected 'All Students' value: " + selectedStudent);
                        TestRunner.getTest().log(Status.PASS, "Selected 'All Students' value: " + selectedStudent);
                    } else {
                        TestRunner.getTest().log(Status.FAIL, "'All Students' Dropdown is empty");
                        System.out.println(">>> 'All Students' Dropdown is empty");
                    }
                }

                wait.until(ExpectedConditions.visibilityOfAllElements(studentRows));
                System.out.println(">>> Student rows are visible");

                for (WebElement studentRow : studentRows) {
                    String studentName = studentRow.findElement(By.xpath("//td//div[contains(@class, 'rightSide')]//h6")).getText();
                    String studentStandard = studentRow.findElements(By.xpath(".//td")).get(1).getText();  // 2nd td is standard
                    String studentScore = studentRow.findElements(By.xpath(".//td")).get(2).getText();     // 3rd td is score

                    System.out.println(">>> Student Name: " + studentName);
                    System.out.println(">>> Student Standard: " + studentStandard);
                    System.out.println(">>> Student Score: " + studentScore);

                    TestRunner.getTest().log(Status.INFO, "Student Name: " + studentName);
                    TestRunner.getTest().log(Status.INFO, "Student Standard: " + studentStandard);
                    TestRunner.getTest().log(Status.INFO, "Student Score: " + studentScore);


                    System.out.println(">>> Student Name: " + studentName);
                    System.out.println(">>> Student Standard: " + studentStandard);
                    System.out.println(">>> Student Score: " + studentScore);

                    // Log the student data
                    TestRunner.getTest().log(Status.INFO, "Student Name: " + studentName);
                    TestRunner.getTest().log(Status.INFO, "Student Standard: " + studentStandard);
                    TestRunner.getTest().log(Status.INFO, "Student Score: " + studentScore);
                }
            }
        } catch (TimeoutException e) {
            System.out.println(">>> Timeout: Student Standards Mastery Overview Widget not visible.");
            TestRunner.getTest().log(Status.FAIL, "Timeout while waiting for Student Standards Mastery Overview Widget to become visible.");
        } catch (Exception e) {
            System.out.println(">>> Error occurred: " + e.getMessage());
            TestRunner.getTest().log(Status.FAIL, "Error occurred: " + e.getMessage());
        }
    }

}
