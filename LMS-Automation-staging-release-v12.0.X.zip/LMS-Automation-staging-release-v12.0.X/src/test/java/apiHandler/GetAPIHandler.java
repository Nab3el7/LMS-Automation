package apiHandler;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.security.cert.X509Certificate;
import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class GetAPIHandler extends Configurations {
    WebDriver driver = Configurations.getDriver();
    Helper helper;
    WebDriverWait wait;

    PostAPIHandler postAPIHandler;

    public String appURL = Configurations.App_url;
    public String endPoint = "question-query-service/api/v1/questionLookup/byId/";
    String bearerToken;

    public GetAPIHandler(){
        helper = new Helper();
        postAPIHandler = new PostAPIHandler(driver);
        wait = new WebDriverWait(driver, Duration.ofSeconds(120));
    }

    public List<String> getCorrectAnswer(String questionID){
        String apiUrl = appURL + endPoint + questionID;
        bearerToken = PostAPIHandler.accessToken;
        List<String> correctKeys = new ArrayList<>();

        // Create SSL context with custom TrustManager
        TrustManager[] trustAllCerts = new TrustManager[] {
                new X509TrustManager() {
                    public X509Certificate[] getAcceptedIssuers() {
                        return null;
                    }
                    public void checkClientTrusted(X509Certificate[] certs, String authType) {
                    }
                    public void checkServerTrusted(X509Certificate[] certs, String authType) {
                    }
                }
        };

        try {
            SSLContext sc = SSLContext.getInstance("TLS");
            sc.init(null, trustAllCerts, new java.security.SecureRandom());
            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

            URL url = new URL(apiUrl);
            HttpsURLConnection con = (HttpsURLConnection) url.openConnection();
            con.setRequestMethod("GET");
            con.setRequestProperty("Authorization", "Bearer " + bearerToken);

            int responseCode = con.getResponseCode();
            System.out.println("Response Code : " + responseCode);

            BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
            String inputLine;
            StringBuilder response = new StringBuilder();

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();

            System.out.println("API Response:");
            System.out.println(response.toString());

            correctKeys = getCorrectKeys(response.toString());

//            System.out.println("Correct Keys:");
//            for (String key : correctKeys) {
//                System.out.println(key);
//            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return correctKeys;
    }

    public List<String> getCorrectAnswerResponseIdentifier(String questionID){
        String apiUrl = appURL + endPoint + questionID;
        bearerToken = PostAPIHandler.accessToken;
        List<String> correctResponse = new ArrayList<>();

        // Create SSL context with custom TrustManager
        TrustManager[] trustAllCerts = new TrustManager[] {
                new X509TrustManager() {
                    public X509Certificate[] getAcceptedIssuers() {
                        return null;
                    }
                    public void checkClientTrusted(X509Certificate[] certs, String authType) {
                    }
                    public void checkServerTrusted(X509Certificate[] certs, String authType) {
                    }
                }
        };

        try {
            SSLContext sc = SSLContext.getInstance("TLS");
            sc.init(null, trustAllCerts, new java.security.SecureRandom());
            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

            URL url = new URL(apiUrl);
            HttpsURLConnection con = (HttpsURLConnection) url.openConnection();
            con.setRequestMethod("GET");
            con.setRequestProperty("Authorization", "Bearer " + bearerToken);

            int responseCode = con.getResponseCode();
            System.out.println("Response Code Get Answer Api: " + responseCode);

            BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
            String inputLine;
            StringBuilder response = new StringBuilder();

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();

            System.out.println("API Response:");
            System.out.println(response.toString());

            JSONObject jsonResponse = new JSONObject(response.toString());
            JSONArray questionsArray = jsonResponse.getJSONArray("questions");
            if (!questionsArray.isEmpty()) {
                JSONObject question = questionsArray.getJSONObject(0);
                JSONArray correctResponseArray = question.getJSONArray("responseDeclaration")
                        .getJSONObject(0)
                        .getJSONArray("correctResponse");
                System.out.println("Correct Response Array:");
                for (int i = 0; i < correctResponseArray.length(); i++) {
                    JSONObject correctResponseObj = correctResponseArray.getJSONObject(i);
                    String choiceIdentifierStr = null;
                    int choiceIdentifierInt = -1;

                    try {
                        choiceIdentifierStr = correctResponseObj.getString("choiceIdentifier");
                    } catch (JSONException e) {
                        try {
                            choiceIdentifierInt = correctResponseObj.getInt("choiceIdentifier");
                        } catch (JSONException ex) {
                            ex.printStackTrace();
                        }
                    }
                    if (choiceIdentifierStr != null) {
//                        System.out.println("Choice Identifier (String): " + choiceIdentifierStr);
                        correctResponse.add(choiceIdentifierStr);
                    } else if (choiceIdentifierInt != -1) {
//                        System.out.println("Choice Identifier (Int): " + choiceIdentifierInt);
                        correctResponse.add(String.valueOf(choiceIdentifierInt));
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return correctResponse;
    }

    public List<String> getCorrectAnswerResponseGapIdentifier(String questionID){
        String apiUrl = appURL + endPoint + questionID;
        bearerToken = PostAPIHandler.accessToken;
        List<String> correctResponse = new ArrayList<>();

        // Create SSL context with custom TrustManager
        TrustManager[] trustAllCerts = new TrustManager[] {
                new X509TrustManager() {
                    public X509Certificate[] getAcceptedIssuers() {
                        return null;
                    }
                    public void checkClientTrusted(X509Certificate[] certs, String authType) {
                    }
                    public void checkServerTrusted(X509Certificate[] certs, String authType) {
                    }
                }
        };

        try {
            SSLContext sc = SSLContext.getInstance("TLS");
            sc.init(null, trustAllCerts, new java.security.SecureRandom());
            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

            URL url = new URL(apiUrl);
            HttpsURLConnection con = (HttpsURLConnection) url.openConnection();
            con.setRequestMethod("GET");
            con.setRequestProperty("Authorization", "Bearer " + bearerToken);

            int responseCode = con.getResponseCode();
            System.out.println("Response Code Get Answer Api: " + responseCode);

            BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
            String inputLine;
            StringBuilder response = new StringBuilder();

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();

            System.out.println("API Response:");
            System.out.println(response.toString());

            JSONObject jsonResponse = new JSONObject(response.toString());
            JSONArray questionsArray = jsonResponse.getJSONArray("questions");
            if (!questionsArray.isEmpty()) {
                JSONObject question = questionsArray.getJSONObject(0);
                JSONArray correctResponseArray = question.getJSONArray("responseDeclaration")
                        .getJSONObject(0)
                        .getJSONArray("correctResponse");
                System.out.println("Correct Response Array:");
                for (int i = 0; i < correctResponseArray.length(); i++) {
                    JSONObject correctResponseObj = correctResponseArray.getJSONObject(i);
                    String gapIdentifierStr = null;
                    int gapIdentifierInt = -1;

                    try {
                        gapIdentifierStr = correctResponseObj.getString("gapIdentifier");
                    } catch (JSONException e) {
                        try {
                            gapIdentifierInt = correctResponseObj.getInt("gapIdentifier");
                        } catch (JSONException ex) {
                            ex.printStackTrace();
                        }
                    }
                    if (gapIdentifierStr != null) {
//                        System.out.println("Choice Identifier (String): " + gapIdentifierStr);
                        correctResponse.add(gapIdentifierStr);
                    } else if (gapIdentifierInt != -1) {
//                        System.out.println("Choice Identifier (Int): " + gapIdentifierInt);
                        correctResponse.add(String.valueOf(gapIdentifierInt));
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return correctResponse;
    }

    public List<String> getCorrectAnswerResponse(String questionID){
        String apiUrl = appURL + endPoint + questionID;
        bearerToken = PostAPIHandler.accessToken;
        List<String> correctResponse = new ArrayList<>();

        // Create SSL context with custom TrustManager
        TrustManager[] trustAllCerts = new TrustManager[] {
                new X509TrustManager() {
                    public X509Certificate[] getAcceptedIssuers() {
                        return null;
                    }
                    public void checkClientTrusted(X509Certificate[] certs, String authType) {
                    }
                    public void checkServerTrusted(X509Certificate[] certs, String authType) {
                    }
                }
        };

        try {
            SSLContext sc = SSLContext.getInstance("TLS");
            sc.init(null, trustAllCerts, new java.security.SecureRandom());
            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

            URL url = new URL(apiUrl);
            HttpsURLConnection con = (HttpsURLConnection) url.openConnection();
            con.setRequestMethod("GET");
            con.setRequestProperty("Authorization", "Bearer " + bearerToken);

            int responseCode = con.getResponseCode();
            System.out.println("Response Code Get Answer Api: " + responseCode);

            BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
            String inputLine;
            StringBuilder response = new StringBuilder();

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();

            System.out.println("API Response:");
            System.out.println(response.toString());

            JSONObject jsonResponse = new JSONObject(response.toString());
            JSONArray questionsArray = jsonResponse.getJSONArray("questions");
            if (!questionsArray.isEmpty()) {
                JSONObject question = questionsArray.getJSONObject(0);
                JSONArray correctResponseArray = question.getJSONArray("responseDeclaration")
                        .getJSONObject(0)
                        .getJSONArray("correctResponse");
                System.out.println("Correct Response Array:");
                for (int i = 0; i < correctResponseArray.length(); i++) {
                    JSONObject correctResponseObj = correctResponseArray.getJSONObject(i);
                    String choiceIdentifierStr = null;
                    int choiceIdentifierInt = -1;

                    try {
                        choiceIdentifierStr = correctResponseObj.getString("choiceIdentifier");
                    } catch (JSONException e) {
                        try {
                            choiceIdentifierInt = correctResponseObj.getInt("choiceIdentifier");
                        } catch (JSONException ex) {
                            ex.printStackTrace();
                        }
                    }
                    if (choiceIdentifierStr != null) {
                        System.out.println("Choice Identifier (String): " + choiceIdentifierStr);
                        int choiceValue = correctResponseObj.getJSONArray("choiceValue").getInt(0); // Retrieve as int
                        System.out.println("Choice Identifier: " + choiceIdentifierStr + ", Choice Value: " + choiceValue);
                        correctResponse.add(String.valueOf(choiceValue));
                    } else if (choiceIdentifierInt != -1) {
                        System.out.println("Choice Identifier (Int): " + choiceIdentifierInt);
                        int choiceValue = correctResponseObj.getJSONArray("choiceValue").getInt(0); // Retrieve as int
                        System.out.println("Choice Identifier: " + choiceIdentifierStr + ", Choice Value: " + choiceValue);
                        correctResponse.add(String.valueOf(choiceValue));
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return correctResponse;
    }

    public List<String> getCorrectAnswerResponseForChoiceInteraction(String questionID){
        String apiUrl = appURL + endPoint + questionID;
        bearerToken = PostAPIHandler.accessToken;
        List<String> correctResponse = new ArrayList<>();

        // Create SSL context with custom TrustManager
        TrustManager[] trustAllCerts = new TrustManager[] {
                new X509TrustManager() {
                    public X509Certificate[] getAcceptedIssuers() {
                        return null;
                    }
                    public void checkClientTrusted(X509Certificate[] certs, String authType) {
                    }
                    public void checkServerTrusted(X509Certificate[] certs, String authType) {
                    }
                }
        };

        try {
            SSLContext sc = SSLContext.getInstance("TLS");
            sc.init(null, trustAllCerts, new java.security.SecureRandom());
            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

            URL url = new URL(apiUrl);
            HttpsURLConnection con = (HttpsURLConnection) url.openConnection();
            con.setRequestMethod("GET");
            con.setRequestProperty("Authorization", "Bearer " + bearerToken);

            int responseCode = con.getResponseCode();
            System.out.println("Response Code Get Answer Api: " + responseCode);

            BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
            String inputLine;
            StringBuilder response = new StringBuilder();

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();

            System.out.println("API Response:");
            System.out.println(response.toString());

            JSONObject jsonResponse = new JSONObject(response.toString());
            JSONArray questionsArray = jsonResponse.getJSONArray("questions");
            if (!questionsArray.isEmpty()) {
                JSONObject question = questionsArray.getJSONObject(0);
                JSONArray correctResponseArray = question.getJSONArray("responseDeclaration")
                        .getJSONObject(0)
                        .getJSONArray("correctResponse");
                System.out.println("Correct Response Array:");
                for (int i = 0; i < correctResponseArray.length(); i++) {
                    JSONObject correctResponseObj = correctResponseArray.getJSONObject(i);
                    String choiceIdentifierStr = null;
                    int choiceIdentifierInt = -1;

                    try {
                        choiceIdentifierStr = correctResponseObj.getString("choiceIdentifier");
                    } catch (JSONException e) {
                        try {
                            choiceIdentifierInt = correctResponseObj.getInt("choiceIdentifier");
                        } catch (JSONException ex) {
                            ex.printStackTrace();
                        }
                    }
                    if (choiceIdentifierStr != null) {
//                        System.out.println("Choice Identifier (String): " + choiceIdentifierStr);
                        correctResponse.add(choiceIdentifierStr);
                    } else if (choiceIdentifierInt != -1) {
//                        System.out.println("Choice Identifier (Int): " + choiceIdentifierInt);
                        correctResponse.add(String.valueOf(choiceIdentifierInt));
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return correctResponse;
    }

    public List<String> getCorrectAnswerResponseForSpellingInteraction(String questionID){
        String apiUrl = appURL + endPoint + questionID;
        bearerToken = PostAPIHandler.accessToken;
        List<String> correctResponse = new ArrayList<>();

        // Create SSL context with custom TrustManager
        TrustManager[] trustAllCerts = new TrustManager[] {
                new X509TrustManager() {
                    public X509Certificate[] getAcceptedIssuers() {
                        return null;
                    }
                    public void checkClientTrusted(X509Certificate[] certs, String authType) {
                    }
                    public void checkServerTrusted(X509Certificate[] certs, String authType) {
                    }
                }
        };

        try {
            SSLContext sc = SSLContext.getInstance("TLS");
            sc.init(null, trustAllCerts, new java.security.SecureRandom());
            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

            URL url = new URL(apiUrl);
            HttpsURLConnection con = (HttpsURLConnection) url.openConnection();
            con.setRequestMethod("GET");
            con.setRequestProperty("Authorization", "Bearer " + bearerToken);

            int responseCode = con.getResponseCode();
            System.out.println("Response Code Get Answer Api: " + responseCode);

            BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
            String inputLine;
            StringBuilder response = new StringBuilder();

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();

            System.out.println("API Response:");
            System.out.println(response.toString());

            JSONObject jsonResponse = new JSONObject(response.toString());
            JSONArray questionsArray = jsonResponse.getJSONArray("questions");
            if (!questionsArray.isEmpty()) {
                JSONObject question = questionsArray.getJSONObject(0);
                JSONArray correctResponseArray = question.getJSONArray("responseDeclaration")
                        .getJSONObject(0)
                        .getJSONArray("correctResponse");

                // Extract correct responses
                for (int i = 0; i < correctResponseArray.length(); i++) {
                    JSONObject correctResponseObj = correctResponseArray.getJSONObject(i);
                    String text = correctResponseObj.getString("text");
                    correctResponse.add(text);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return correctResponse;
    }

    private List<String> getCorrectKeys(String jsonResponse) {
        List<String> correctKeys = new ArrayList<>();
        try {
            JSONObject jsonObject = new JSONObject(jsonResponse);
            JSONArray questionsArray = jsonObject.getJSONArray("questions");
            if (!questionsArray.isEmpty()) {
                JSONObject questionObject = questionsArray.getJSONObject(0);
                JSONArray correctKeyArray = questionObject.getJSONArray("correctKey");
                for (int i = 0; i < correctKeyArray.length(); i++) {
                    correctKeys.add(correctKeyArray.getString(i));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return correctKeys;
    }

    public List<Map<String, String>> getCorrectAnswerResponseChoiceAndGapIdentifier(String questionID) {
        String apiUrl = appURL + endPoint + questionID;
        bearerToken = PostAPIHandler.accessToken;
        List<Map<String, String>> correctResponse = new ArrayList<>();

        // Create SSL context with custom TrustManager
        TrustManager[] trustAllCerts = new TrustManager[] {
                new X509TrustManager() {
                    public X509Certificate[] getAcceptedIssuers() {
                        return null;
                    }
                    public void checkClientTrusted(X509Certificate[] certs, String authType) {
                    }
                    public void checkServerTrusted(X509Certificate[] certs, String authType) {
                    }
                }
        };

        try {
            SSLContext sc = SSLContext.getInstance("TLS");
            sc.init(null, trustAllCerts, new java.security.SecureRandom());
            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

            URL url = new URL(apiUrl);
            HttpsURLConnection con = (HttpsURLConnection) url.openConnection();
            con.setRequestMethod("GET");
            con.setRequestProperty("Authorization", "Bearer " + bearerToken);

            int responseCode = con.getResponseCode();
            System.out.println("Response Code Get Answer Api: " + responseCode);

            BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
            String inputLine;
            StringBuilder response = new StringBuilder();

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();

            System.out.println("API Response:");
            System.out.println(response.toString());

            JSONObject jsonResponse = new JSONObject(response.toString());
            JSONArray questionsArray = jsonResponse.getJSONArray("questions");
            if (!questionsArray.isEmpty()) {
                JSONObject question = questionsArray.getJSONObject(0);
                JSONArray correctResponseArray = question.getJSONArray("responseDeclaration")
                        .getJSONObject(0)
                        .getJSONArray("correctResponse");
                System.out.println("Correct Response Array:");
                for (int i = 0; i < correctResponseArray.length(); i++) {
                    JSONObject correctResponseObj = correctResponseArray.getJSONObject(i);
                    String gapIdentifier = null;
                    String choiceIdentifier = null;

                    try {
                        gapIdentifier = correctResponseObj.getString("gapIdentifier");
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                    try {
                        choiceIdentifier = correctResponseObj.getString("choiceIdentifier");
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                    if (gapIdentifier != null && choiceIdentifier != null) {
                        Map<String, String> identifierMap = new HashMap<>();
                        identifierMap.put("gapIdentifier", gapIdentifier);
                        identifierMap.put("choiceIdentifier", choiceIdentifier);
                        correctResponse.add(identifierMap);
//                        System.out.println("Gap Identifier: " + gapIdentifier + ", Choice Identifier: " + choiceIdentifier);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return correctResponse;
    }

    public List<String> getCorrectAnswerSource(String questionID) {
        String apiUrl = appURL + endPoint + questionID;
        bearerToken = PostAPIHandler.accessToken;

        List<String> questionSource = new ArrayList<>();

        TrustManager[] trustAllCerts = new TrustManager[]{
                new X509TrustManager() {
                    public X509Certificate[] getAcceptedIssuers() {
                        return null;
                    }

                    public void checkClientTrusted(X509Certificate[] certs, String authType) {
                    }

                    public void checkServerTrusted(X509Certificate[] certs, String authType) {
                    }
                }
        };

        try {
            SSLContext sc = SSLContext.getInstance("TLS");
            sc.init(null, trustAllCerts, new java.security.SecureRandom());
            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

            URL url = new URL(apiUrl);
            HttpsURLConnection con = (HttpsURLConnection) url.openConnection();
            con.setRequestMethod("GET");
            con.setRequestProperty("Authorization", "Bearer " + bearerToken);

            int responseCode = con.getResponseCode();
            System.out.println("Response Code Get Answer Api: " + responseCode);

            BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
            String inputLine;
            StringBuilder response = new StringBuilder();

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();

            JSONObject jsonResponse = new JSONObject(response.toString());
            JSONArray questionsArray = jsonResponse.getJSONArray("questions");

            if (!questionsArray.isEmpty()) {
                JSONObject question = questionsArray.getJSONObject(0);
                JSONArray metaData = question.getJSONObject("itemBody").getJSONArray("metadata");

                for (int i = 0; i < metaData.length(); i++) {
                    String source = metaData.getJSONObject(i).getString("source");
                    questionSource.add(source);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return questionSource;
    }

}
