package apiHandler;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;
import java.time.Duration;

public class PostAPIHandler extends Configurations {

    public String username = Configurations.username;
    public String password = Configurations.password;
    public String appURL = Configurations.App_url;

    Helper helper;
    public WebDriverWait wait;
    WebDriver driver;

    public static String accessToken;

    public PostAPIHandler(WebDriver driver){
        this.driver = driver;
        helper = new Helper();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    public void loginAPiCall() throws IOException, NoSuchAlgorithmException, KeyManagementException {
        String apiUrl = appURL + "oauth20-service/oauth/token";
        String authString = "c3ByaW5nYmFua0NsaWVudDpzcHJpbmdiYW5rU2VjcmV0";
        String postData = "grant_type=password&username=" + username + "&password=" + password;
        disableCertificateValidation();

        URL url = new URL(apiUrl);
        HttpURLConnection con = (HttpURLConnection) url.openConnection();
        con.setRequestMethod("POST");
        
        // Set connection properties to prevent premature closure
        con.setConnectTimeout(30000); // 30 seconds
        con.setReadTimeout(30000); // 30 seconds
        con.setUseCaches(false);
        con.setDoInput(true);
        con.setDoOutput(true);
        
        // Set headers - ensure proper content type and length
        byte[] postDataBytes = postData.getBytes("UTF-8");
        con.setRequestProperty("Authorization", "Basic " + authString);
        con.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
        con.setRequestProperty("Content-Length", String.valueOf(postDataBytes.length));
        con.setRequestProperty("Accept", "application/json");
        con.setRequestProperty("Connection", "keep-alive");
        con.setRequestProperty("User-Agent", "Java-Automation-Client");

        // Write request body
        try (OutputStream os = con.getOutputStream()) {
            os.write(postDataBytes, 0, postDataBytes.length);
            os.flush();
        }

        // Get response
        int responseCode = con.getResponseCode();
        TestRunner.getTest().log(Status.INFO, "Response Code : " + responseCode);

        // Handle both success and error responses
        BufferedReader in;
        if (responseCode >= 200 && responseCode < 300) {
            in = new BufferedReader(new InputStreamReader(con.getInputStream(), "UTF-8"));
        } else {
            // Read error stream for debugging
            try {
                in = new BufferedReader(new InputStreamReader(con.getErrorStream(), "UTF-8"));
            } catch (Exception e) {
                in = new BufferedReader(new InputStreamReader(con.getInputStream(), "UTF-8"));
            }
        }

        String inputLine;
        StringBuffer response = new StringBuffer();

        while ((inputLine = in.readLine()) != null) {
            response.append(inputLine);
        }
        in.close();
        con.disconnect();

        System.out.println("Login API Response:");
        System.out.println(response.toString());

        if (responseCode >= 200 && responseCode < 300) {
            JSONObject jsonObject = new JSONObject(response.toString());
            accessToken = jsonObject.getString("access_token");
            System.out.println("Access Token:");
            System.out.println(accessToken);
            TestRunner.getTest().log(Status.PASS, "Access token retrieved successfully");
        } else {
            throw new IOException("API call failed with response code: " + responseCode + ", Response: " + response.toString());
        }
    }

    private void disableCertificateValidation() throws NoSuchAlgorithmException, KeyManagementException {
        TrustManager[] trustAllCerts = new TrustManager[] {
                new X509TrustManager() {
                    public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                        return null;
                    }
                    public void checkClientTrusted(X509Certificate[] certs, String authType) {
                    }
                    public void checkServerTrusted(X509Certificate[] certs, String authType) {
                    }
                }
        };

        // Install the all-trusting trust manager
        SSLContext sslContext = SSLContext.getInstance("TLS");
        sslContext.init(null, trustAllCerts, new java.security.SecureRandom());
        HttpsURLConnection.setDefaultSSLSocketFactory(sslContext.getSocketFactory());
    }
}
