package StepDefinitions.UserProfileSenariosSteps;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.UserProfileScenarios.AccountSetting_PF;

import java.time.Duration;

public class AccountSettingSteps {
    WebDriver driver = Configurations.getDriver();
    Helper helper;
    Actions actions;

    AccountSetting_PF accountSettingPf;

    public WebDriverWait wait;
    WebElement loader = driver.findElement(By.xpath("//span[@role='progressbar']"));

    public AccountSettingSteps(){
        helper = new Helper();
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
        actions = new Actions(driver);
        accountSettingPf = new  AccountSetting_PF(driver);
    }
    @And ("Click User Account Setting Button")
    public void SelectUserprofileButton() throws InterruptedException{
        TestRunner.startTest("Validate and Click on User Profile Button From District");
        try {

            accountSettingPf.SelectUserButton();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }
    @And("Validate and Edit User Information")
    public void User_Profile_info() throws InterruptedException{
        TestRunner.startTest( " Check and validate to Edit User Information **********");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            accountSettingPf.edit_UserProfile_info();
//            System.out.println("Test Case Passed    : Edit Information successfully");
            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed     :   Exception is found");
            Assert.fail();
        }
    }
    @And("Validate and Fill User Account Setting Information")
    public void User_Account_Setting_info() throws InterruptedException{
        TestRunner.startTest( " Check and validate to Edit User Information **********");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            accountSettingPf.User_Account_Setting_info();
//            System.out.println("Test Case Passed    : Edit Information successfully");
            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed     :   Exception is found");
            Assert.fail();
        }
    }
    @And("Validate and Click on User Update Button")
    public void update_button() throws InterruptedException {
        TestRunner.startTest( "  Validate and click Update Button  **********");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            accountSettingPf.click_User_update_btn();
            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed     :   Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }
    @And("Validate and Click on User Profile Button")
    public void AccountSetting_button() throws InterruptedException {
        TestRunner.startTest( "  Validate and click Account Setting Button  **********");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            accountSettingPf.click_Profile_btn();
//            System.out.println("Test Case Passed    : Update button clicks successfully");
            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed     :   Exception is found");
            Assert.fail();
        }
    }
//    ******************************* Negative Scenarios Step File ******************************************


@And("Validate and Negative User Information")
public void NegativeUser_Profile_info() throws InterruptedException{
    TestRunner.startTest( "  Check and validate to Negative User Information **********");
    try {
        wait.until(ExpectedConditions.invisibilityOf(loader));
        accountSettingPf.NegativeUserProfileTests();
//            System.out.println("Test Case Passed    : Edit Information successfully");
        helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
    } catch (NoSuchElementException | ElementNotInteractableException e) {
        System.out.println(e);
        System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
        TestRunner.getTest().log(Status.FAIL, "Test Case Failed     :   Exception is found");
        Assert.fail();
    }
}
    @And("Validate and Fill Negative User Account Setting Information")
    public void negativeUser_Account_Setting_info() throws InterruptedException{
        TestRunner.startTest( "  Check and validate to Negative User Information **********");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            accountSettingPf.Negative_User_Account_Setting_info();
//            System.out.println("Test Case Passed    : Edit Information successfully");
            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed     :   Exception is found");
            Assert.fail();
        }
    }
}

