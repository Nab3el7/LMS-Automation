package StepDefinitions.MassRegistration;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.MassRegistration.StudentMassRegistration_PF;

import java.time.Duration;

public class StudentMassRegistrationSteps extends Configurations{
    WebDriver driver = Configurations.getDriver();
    Helper helper;
    Actions actions;
    public WebDriverWait wait;

    WebElement loader = driver.findElement(By.xpath("//span[@role='progressbar']"));

    StudentMassRegistration_PF studentMassRegistration_pf;

    public StudentMassRegistrationSteps() {
        helper = new Helper();
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
        actions = new Actions(driver);
        studentMassRegistration_pf = new StudentMassRegistration_PF(driver);
    }

    @And("Click on Add Multiple Button")
    public void ClickOnAddMultipleButton() throws InterruptedException{
        TestRunner.startTest("Verify And Click on Add Multiple Button");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            studentMassRegistration_pf.validateClickAddMultiple();

        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found.");
            Assert.fail();
        }
    }

    @And("Validate and Check BreadCrumb on Add Multiple Accounts")
    public void ValidateAndCheckBreadCrumbOnAddMultipleAccounts() throws InterruptedException {
        TestRunner.startTest("Validate and Check BreadCrumb on Add Multiple Accounts");
        try {
            studentMassRegistration_pf.validateBreadCrumb();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found.");
            Assert.fail();
        }
    }

    @And("Validate and Check Before Add Accounts All Buttons Are Disable")
    public void ValidateAndCheckBeforeAddAccountsAllButtonsAreDisable() throws InterruptedException {
        TestRunner.startTest("Validate and Check Before Add Accounts All Buttons Are Disable");
        try {
            studentMassRegistration_pf.validateAllButtonsDisable();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Validate and Check that Text is display Before Adding Accounts")
    public void ValidateAndCheckThatTextIsDisplayBeforeAddingAccounts() throws InterruptedException {
        TestRunner.startTest("Validate and Check that Text is display Before Adding Accounts");

        try {
            studentMassRegistration_pf.validateNoAccountsMessages();

        } catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Validate and Select District From Dropdown")
    public void ValidateAndSelectDistrictFromDropdown() throws InterruptedException {
        TestRunner.startTest("Validate and Select District From Dropdown");

        try {
            studentMassRegistration_pf.selectDistrictFromDropDown();

        } catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }

    }

    @And("Validate and Select School From Dropdown")
    public void ValidateAndSelectSchoolFromDropdown() throws InterruptedException {
        TestRunner.startTest("Validate and Select School From Dropdown");

        try {
            studentMassRegistration_pf.selectSchoolFromDropdown();

        }  catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Validate default number of accounts and add accounts")
    public void validateDefaultNumberOfAccountsAndAddAccounts() throws InterruptedException {
        TestRunner.startTest("Validate default number of accounts and add accounts");

        try {
            studentMassRegistration_pf.validateNumberOfAccountsAndAdd();

        } catch (NoSuchElementException | ElementNotInteractableException ex) {
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Validate Role dropdown has options and Student preselected")
    public void validateRoleDropdownHasOptionsAndStudentPreselected() {
        TestRunner.startTest("Validate Role dropdown has options and Student preselected");

        try {
            studentMassRegistration_pf.validateRoleDropdownStudentPreselected();

        } catch (NoSuchElementException | ElementNotInteractableException ex) {
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Validate row School dropdown is preselected and has options")
    public void validateRowSchoolDropdownIsPreselectedAndHasOptions() {
        TestRunner.startTest("Validate row School dropdown is preselected and has options");

        try {
            studentMassRegistration_pf.validateRowSchoolDropdownPreselectedAndOptions();

        } catch (NoSuchElementException | ElementNotInteractableException ex) {
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Validate First Name field required validation")
    public void validateFirstNameFieldRequiredValidation() {
        TestRunner.startTest("Validate First Name field required validation");

        try {
            studentMassRegistration_pf.validateFirstNameFieldRequiredMessage();

        } catch (NoSuchElementException | ElementNotInteractableException ex) {
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Validate Validation Failed snackbar message")
    public void validateValidationFailedSnackbarMessage() {
        TestRunner.startTest("Validate Validation Failed snackbar message");

        try {
            studentMassRegistration_pf.validateValidationFailedSnackbarMessage();

        } catch (NoSuchElementException | ElementNotInteractableException ex) {
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Validate Last Name field required validation")
    public void validateLastNameFieldRequiredValidation() {
        TestRunner.startTest("Validate Last Name field required validation");

        try {
            studentMassRegistration_pf.validateLastNameFieldRequiredMessage();

        } catch (NoSuchElementException | ElementNotInteractableException ex) {
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Validate Email field required validation")
    public void validateEmailFieldRequiredValidation() {
        TestRunner.startTest("Validate Email field required validation");

        try {
            studentMassRegistration_pf.validateEmailFieldRequiredMessage();

        } catch (NoSuchElementException | ElementNotInteractableException ex) {
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Validate and Refresh Page")
    public void ValidateAndRefreshPage() throws InterruptedException {
        TestRunner.startTest("Validate and Refresh Page");

        try {
            studentMassRegistration_pf.validateRefreshPage();

        } catch (NoSuchElementException | ElementNotInteractableException ex) {
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Validate and Add Accounts Information")
    public void ValidateAndAddAccountsInformation() throws InterruptedException {
        TestRunner.startTest("Validate and Add Accounts Information");
        try {
            studentMassRegistration_pf.addAccountsInformation();

        } catch (NoSuchElementException | ElementNotInteractableException ex) {
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }
}
