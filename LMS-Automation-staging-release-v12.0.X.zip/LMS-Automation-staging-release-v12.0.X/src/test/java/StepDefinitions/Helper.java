package StepDefinitions;

import com.aventstack.extentreports.Status;
import com.azure.storage.blob.BlobClient;
import com.azure.storage.blob.BlobContainerClient;
import org.openqa.selenium.*;
import org.openqa.selenium.logging.LogEntries;
import org.openqa.selenium.logging.LogEntry;
import org.openqa.selenium.logging.LogType;
import org.openqa.selenium.logging.Logs;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.io.FileHandler;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Random;
import org.openqa.selenium.ElementNotInteractableException;

public class Helper extends Configurations {
    // Thread-safe: Use lazy initialization - get driver only when needed
    // This ensures driver is available when Helper methods are called, not during instantiation
    private WebDriver getWebDriver() {
        return Configurations.getDriver();
    }
    
    // Thread-safe: Create wait instance when needed to ensure driver is ready
    private WebDriverWait getWebDriverWait() {
        return new WebDriverWait(getWebDriver(), Duration.ofSeconds(120));
    }

    public void takeScreenshot(WebDriver driver, String threadName) {
        // Backward-compatible entry point used across the suite
        captureScreenshot(driver, threadName);
    }

    /**
     * Captures a screenshot, stores it under the global screenshot directory with a timestamped name,
     * uploads it to Azure when running in test profile, and returns the absolute file path.
     */
    public String captureScreenshot(WebDriver driver, String screenshotName) {
        if (driver == null) {
            System.err.println("Unable to capture screenshot because WebDriver is null.");
            return null;
        }

        try {
            TakesScreenshot ts = (TakesScreenshot) driver;
            File source = ts.getScreenshotAs(OutputType.FILE);

            String sanitizedName = screenshotName.replaceAll("[^a-zA-Z0-9-_]", "_");
            String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss_SSS").format(new Date());
            String fileName = sanitizedName + "_" + timestamp + ".png";

            Path screenshotDir = Paths.get(Configurations.ScreenShotDirectory);
            Files.createDirectories(screenshotDir);

            String fullPath = screenshotDir.resolve(fileName).toString();
            FileHandler.copy(source, new File(fullPath));

            if (Configurations.isTest()) {
                this.uploadScreenshotOnAzure(fileName, fullPath);
            }
            return fullPath;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    public void uploadScreenshotOnAzure(String fileName, String fullPath) {
        BlobContainerClient containerClient = TestRunner.getContainerClient();
        if (containerClient == null) {
            System.err.println("Azure container client is not initialized.");
            return;
        }

        String timestamp = new SimpleDateFormat("yyyyMMdd").format(new Date());
        String blobName = "screenshots/" + timestamp + "/" + fileName;

        BlobClient blobClient = containerClient.getBlobClient(blobName);

        try {
            blobClient.uploadFromFile(fullPath, true);
            System.out.println("Screenshot uploaded successfully to: " + blobClient.getBlobUrl());
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Failed to upload the screenshot.");
        }
    }


    /**
     * Comprehensive page load check that waits for:
     * 1. Document ready state to be complete
     * 2. All network requests to complete (API responses)
     * 3. All loading indicators to disappear
     * 4. "Loading..." text to disappear
     * 5. Page stability verification
     */
    public void waitForPageToLoad() {
        WebDriver driver = getWebDriver();
        WebDriverWait extendedWait = new WebDriverWait(driver, Duration.ofSeconds(60));
        
        try {
            // Step 1: Wait for document ready state
            extendedWait.until(webDriver -> {
                JavascriptExecutor jsExecutor = (JavascriptExecutor) webDriver;
                return jsExecutor.executeScript("return document.readyState").equals("complete");
            });
            System.out.println("Document ready state: complete");
            
            // Step 2: Wait for all loading indicators to disappear
            try {
                extendedWait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//span[@role='progressbar']")));
                System.out.println("Progress bar disappeared");
            } catch (Exception e) {
                System.out.println("Progress bar check: " + e.getMessage());
            }
            
            // Step 3: Wait for Material-UI loading backdrops to disappear
            try {
                extendedWait.until(ExpectedConditions.invisibilityOfElementLocated(By.className("MuiBackdrop-root")));
                System.out.println("Loading backdrop disappeared");
            } catch (Exception e) {
                System.out.println("Backdrop check: " + e.getMessage());
            }
            
            // Step 4: Wait for "Loading..." text to disappear
            try {
                extendedWait.until(ExpectedConditions.invisibilityOfElementLocated(
                    By.xpath("//*[contains(text(), 'Loading...') or contains(text(), 'Loading')]")));
                System.out.println("Loading text disappeared");
            } catch (Exception e) {
                System.out.println("Loading text check: " + e.getMessage());
            }
            
            // Step 5: Wait for network requests to complete
            // Use a polling approach to check if page state has stabilized
            int maxAttempts = 30; // 30 attempts with 1 second delay = 30 seconds max
            int stableCount = 0;
            int requiredStableCount = 3; // Page must be stable for 3 consecutive checks
            
            for (int attempt = 0; attempt < maxAttempts; attempt++) {
                JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
                
                try {
                    // Check if performance timing indicates page is loaded
                    Long loadEventEnd = (Long) jsExecutor.executeScript(
                        "return window.performance.timing.loadEventEnd");
                    Long navigationStart = (Long) jsExecutor.executeScript(
                        "return window.performance.timing.navigationStart");
                    
                    // If loadEventEnd is 0, page hasn't finished loading
                    if (loadEventEnd == 0 || loadEventEnd <= navigationStart) {
                        stableCount = 0;
                        Thread.sleep(1000);
                        continue;
                    }
                    
                    // Check document ready state
                    String readyState = (String) jsExecutor.executeScript("return document.readyState");
                    if (!"complete".equals(readyState)) {
                        stableCount = 0;
                        Thread.sleep(1000);
                        continue;
                    }
                    
                    // Check if there are any visible loading indicators
                    try {
                        List<WebElement> loadingElements = driver.findElements(
                            By.xpath("//span[@role='progressbar'] | //*[contains(@class, 'MuiCircularProgress')] | //*[contains(text(), 'Loading...')]"));
                        boolean hasVisibleLoading = loadingElements.stream().anyMatch(WebElement::isDisplayed);
                        if (hasVisibleLoading) {
                            stableCount = 0;
                            Thread.sleep(1000);
                            continue;
                        }
                    } catch (Exception e) {
                        // Continue if check fails
                    }
                    
                    // If we reach here, page appears stable
                    stableCount++;
                    if (stableCount >= requiredStableCount) {
                        System.out.println("Network requests completed - page is stable");
                        break;
                    }
                    
                    Thread.sleep(1000);
                } catch (Exception e) {
                    System.out.println("Network check exception: " + e.getMessage());
                    stableCount = 0;
                    Thread.sleep(1000);
                }
            }
            
            if (stableCount < requiredStableCount) {
                System.out.println("Warning: Page stability check did not complete fully, but continuing...");
            }
            
            System.out.println("Page load check completed successfully");
            
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            System.out.println("Page load check interrupted: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Page load check encountered an issue: " + e.getMessage());
            // Continue execution even if some checks fail
        }
    }

    public String selectValueFromDropdown(List<WebElement> options) {
        try {
            getWebDriverWait().until(ExpectedConditions.visibilityOfAllElements(options));
        } catch (TimeoutException e) {
            throw new IllegalArgumentException("The options list is not visible or empty within the timeout");
        }

        if (options.isEmpty()) {
            throw new IllegalArgumentException("The options list must not be empty");
        }

        Random random = new Random();
        int index = random.nextInt(options.size());
        WebElement selectedOption = options.get(index);
        String selectedValue = selectedOption.getText();
        selectedOption.click();
        if (selectedValue == null || selectedValue.isEmpty()) {
            JavascriptExecutor js = (JavascriptExecutor) getWebDriver();
            selectedValue = (String) js.executeScript("return arguments[0].textContent;", selectedOption);
        }
        if (selectedValue != null) {
            selectedValue = selectedValue.trim();
        }

        System.out.println("Selected Value is: " + selectedValue);
        TestRunner.getTest().log(Status.INFO, "Selected Value is: " + selectedValue);
        return selectedValue;
    }

    public String generateRandomText(String prefix) {
        String characters = "ABC123456789";
        StringBuilder randomTitle = new StringBuilder();
        Random random = new Random();
        int length = 3;
        randomTitle.append(prefix);
        for (int i = 0; i < length; i++) {
            randomTitle.append(characters.charAt(random.nextInt(characters.length())));
        }
        return randomTitle.toString();
    }

    public void getSystemLogs(){
        Logs logs = getWebDriver().manage().logs();
        LogEntries logEntries = logs.get(LogType.BROWSER);
        for (LogEntry entry : logEntries) {
            System.out.println(entry.getMessage());
        }
    }


    public String generateStartDateTime() {
        Calendar calendar = Calendar.getInstance();

        Random random = new Random();
        int randomDays = random.nextInt(30);
        calendar.add(Calendar.DAY_OF_MONTH, randomDays);
        Date randomStartDate = calendar.getTime();

        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm");
        return dateFormat.format(randomStartDate);
    }

    public String generateEndDateTime(String startDateTime) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm");

        try {
            Date startDate = dateFormat.parse(startDateTime);

            Calendar calendar = Calendar.getInstance();
            calendar.setTime(startDate);
            calendar.add(Calendar.MONTH, 1);

            return dateFormat.format(calendar.getTime());
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }

    public String generateLateSubDateTime(String endDateTime) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm");

        try {
            Date endDate = dateFormat.parse(endDateTime);

            Calendar calendar = Calendar.getInstance();
            calendar.setTime(endDate);
            calendar.add(Calendar.MONTH, 1);

            return dateFormat.format(calendar.getTime());
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }

    public void scrollToElement(WebDriver driver, WebElement scrollToElement) {
        JavascriptExecutor jsPostAction = (JavascriptExecutor) driver;            // object of javaScript
        jsPostAction.executeScript("arguments[0].scrollIntoView(true);", scrollToElement); // This will scroll till the element is found
    }

    public static void scrollToTop(WebDriver driver) {
        WebElement topElementOfThePage = driver.findElement(By.className("fix-header"));
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].scrollIntoView();", topElementOfThePage);
    }

    public static void scrollByCoordinates(WebDriver driver, String coordinates) {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0," + coordinates + ")", "");
    }

    public void selectReviewOption(String reviewOption) {
        try {
            WebElement reviewOptionDropdown = getWebDriver().findElement(By.xpath("//div[@id='panel2bh-content']//div[@id='demo-simple-select']"));
            reviewOptionDropdown.click();
            getWebDriverWait().until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[@role='listbox']")));
            WebElement selectedOption= getWebDriver().findElement(By.xpath("//li[normalize-space()='"+reviewOption+"']"));
            System.out.println("Selected Review Option is: " + selectedOption.getText());
            selectedOption.click();
        } catch (NoSuchElementException | ElementNotInteractableException | TimeoutException e){
            System.out.println("Review Option is not selected" + e.getMessage());
        }

    }
}
