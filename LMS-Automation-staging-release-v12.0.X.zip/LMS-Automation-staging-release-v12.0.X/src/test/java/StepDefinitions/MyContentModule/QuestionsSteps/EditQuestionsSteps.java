package StepDefinitions.MyContentModule.QuestionsSteps;

import StepDefinitions.Configurations;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import org.junit.Assert;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.MyContent.QuestionsPF.EditQuestion_PF;

import java.time.Duration;

public class EditQuestionsSteps extends Configurations {
    WebDriver driver = Configurations.getDriver();
    public WebDriverWait wait;
    EditQuestion_PF editQuestionPF;

    public EditQuestionsSteps() {
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
        editQuestionPF = new EditQuestion_PF(driver);
    }



    @And("Click On Custom Question Edit Button")
    public void ClickOnQuestionEditButton() throws InterruptedException{
        TestRunner.startTest("Check and validate to Click on Edit button in Question");
        try {
            editQuestionPF.clickQuestionEditButton();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed    :   Exception is found. Edit button in Question not found");
            Assert.fail();
        }
    }

    @And("Validate and Edit Question Information")
    public void EditQuestionInformation() throws InterruptedException{
        TestRunner.startTest("Check and validate to Edit Question Information");
        try {
            editQuestionPF.editQuestionInfo();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed    :   Exception is found. Information in question not Edit");
            Assert.fail();
        }
    }

    @And("Click on Edit Question Save Button")
    public void ClickOnSaveButton(){
        TestRunner.startTest("Check and validate to click on Edit Question Save Button");
        try {
            editQuestionPF.clickOnEditQuestionSaveButton();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed    :   Exception is found. Edit Question Save Button not found.");
            Assert.fail();
        }
    }

    @And("Check and Validate The Edited Question Information")
    public void ValidateEditedQuestionInformation() {
        TestRunner.startTest("Check and validate the Edited Question Information");
        try {
            editQuestionPF.verifyUpdatedQuestionInfo();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed    :   Exception is found. Edited Question Information not updated");
            Assert.fail();
        }
    }
}
