package StepDefinitions.MyContentModule.QuestionsSteps;

import StepDefinitions.Configurations;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;

import org.junit.Assert;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.MyContent.QuestionsPF.DeleteQuestion_PF;

import java.time.Duration;

public class DeleteQuestionsSteps extends Configurations {
    WebDriver driver = Configurations.getDriver();
    public WebDriverWait wait;

    DeleteQuestion_PF deleteQuestionPF;

    public DeleteQuestionsSteps() {
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
        deleteQuestionPF = new DeleteQuestion_PF(driver);
    }



    @And("Click On Custom Question Menu And Delete Button")
    public void ClickOnQuestionDeleteButton() throws InterruptedException{
        TestRunner.startTest("Check and validate to Click on Delete button in Question");
        try {
            deleteQuestionPF.clickQuestionMenuButton();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed    :   Exception is found. Delete button in Question not found");
            Assert.fail();
        }
    }

    @And("Verify Custom Question Prompt And Delete Question")
    public void VerifyCustomQuestionPromptAndDeleteQuestion() throws InterruptedException{
        TestRunner.startTest("Verify Custom Question Prompt And Delete Question");
        try {
            deleteQuestionPF.DeleteQuestionPrompt();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed    :   Exception is found. Delete Question Prompt not found");
            Assert.fail();
        }
    }

    @And("Verify In My Content Custom Deleted Question Not Shows")
    public void verifyDeletedQuestionNotShows() throws InterruptedException {
        TestRunner.startTest("Verify Deleted Question Not Shows");
        try {
            deleteQuestionPF.showsQuestionsIntoTable();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed    :   Exception is found. Deleted Question Also Shows in Table");
            Assert.fail();
        }
    }
}
