package StepDefinitions.MyContentModule.QuestionsSteps;

import StepDefinitions.Configurations;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import org.junit.Assert;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.MyContent.QuestionsPF.FilterQuestion_PF;

import java.time.Duration;

public class QuestionFiltersSteps extends Configurations {
    WebDriver driver = Configurations.getDriver();
    public WebDriverWait wait;

    FilterQuestion_PF questionFiltersPF;

    public QuestionFiltersSteps() {
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
        questionFiltersPF = new FilterQuestion_PF(driver);
    }


    @And("Select Course My Question Custom Filter")
    public void selectCourseMyContentCustomFilter() {
        TestRunner.startTest("I'm in to select Course My Content Filter");
        try {
            questionFiltersPF.SelectCourseForCustomFilter();
        } catch (Exception e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed    :   Exception is found. Course My Content Filter not found");
            Assert.fail();
        }
    }

    @And("Select My Question Custom Filter On Question Standards")
    public void selectMyContentFilterOnQuestionStandards() throws InterruptedException {
        TestRunner.startTest("I'm in to select My Content Filter On Question Standards");
        try {
            questionFiltersPF.applyQuestionStandardFilters();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed    :   Exception is found. Custom Filter On Question Standard not found");
            Assert.fail();
        }
    }

    @And("Select My Question Custom Filter On Question Type")
    public void selectMyContentFilterOnQuestionType() throws InterruptedException {
        TestRunner.startTest("I'm in to select My Content Filter On Question Type");
        try {
            questionFiltersPF.QuestionCustomFilter();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed    :   Exception is found. Custom Filter On Question Type not found");
            Assert.fail();
        }
    }

    @And("Click on Apply Filter Button In My Content Custom Question")
    public void clickFilterButton(){
        TestRunner.startTest("Check and Click on Apply Filter Button");
        try {
            questionFiltersPF.questionFilterApply();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed    :   Exception is found. Apply Filter Button In My Content Custom Question not found");
            Assert.fail();
        }
    }

    @And("Select My Question Custom Status Filter On Question")
    public void selectMyContentFilterOnQuestionStatus() throws InterruptedException{
        TestRunner.startTest("I'm in to select My Content Filter On Question Status");
        try {
            questionFiltersPF.filterQuestionsByStatus();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed    :   Exception is found. Custom Filter On Question Type not found");
            Assert.fail();
        }
    }

    @And("Verify In My Content Custom Questions Shows Into Table")
    public void verifyQuestionsShowsIntoTable() throws InterruptedException {
        TestRunner.startTest("Verify Questions Shows Into Table");
        try {
            questionFiltersPF.showsQuestionsIntoTable();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed    :   Exception is found. Custom Questions not Shows Into Table");
            Assert.fail();
        }
    }

    @And("Search In My Content New Custom Question By Name")
    public void searchNewQuestionByName(){
        TestRunner.startTest("Search The New Question Added");
        try {
            questionFiltersPF.searchQuestionByName();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed    :   Exception is found. New Custom Question By Name search Box not found");
            Assert.fail();
        }
    }

    @And("Verify In My Content Custom Questions by Name Shows Into Table")
    public void verifyNewQuestionByNameIntoTable(){
        TestRunner.startTest("Verify The New Question Added");
        try {
            questionFiltersPF.verifySearchedQuestionByNameIntoTable();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed    :   Exception is found. New Created Question not shown in table");
            Assert.fail();
        }
    }
}
