package StepDefinitions.MyContentModule;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import org.junit.Assert;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.MyContent.CreateAssessment_PF;
import pageFactory.MyContent.EditAssessment_PF;

import java.time.Duration;

public class CreateAssessmentSteps extends Configurations {
    WebDriver driver = Configurations.getDriver();

    CreateAssessment_PF createAssessmentPF;
    EditAssessment_PF editAssessmentPF;
    Helper helper;

    public WebDriverWait wait;
//    WebElement loader = driver.findElement(By.xpath("//span[@role='progressbar']"));

    public CreateAssessmentSteps(){
        createAssessmentPF = new CreateAssessment_PF(driver);
        editAssessmentPF = new EditAssessment_PF(driver);
        helper = new Helper();
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
    }



    @And("Check And Validate The Side Navbar And Clicked On My Content")
    public void VerifySideNavBarAndClickOnGradeBook() throws InterruptedException {
        TestRunner.startTest("Verify Side Navbar And Clicked On My Content");
        try {
            createAssessmentPF.waitUntilProgressBar();
            createAssessmentPF.SideNavBarAndClickOnMyContent();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Check And Validate The My Content Dashboard")
    public void VerifyGradeBookDashboard() throws InterruptedException {
        TestRunner.startTest("Verify the My Content dashboard");
        try {
            createAssessmentPF.waitUntilProgressBar();
            createAssessmentPF.MyContentDashboard();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  Exception is found");
            Assert.fail();
        }
    }

    @And("Check, Validate And Select The Course")
    public void SelectTheCourseInCoursesDropdown() throws InterruptedException {
        TestRunner.startTest("Select the Course in Courses Dropdown");
        try {
            createAssessmentPF.SelectCourse();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  Exception is found");
            Assert.fail();
        }
        Thread.sleep(1000);
    }

    @And("Check, Validate And Click On Add New Button For New Assessment")
    public void ClickOnAddNewButton() throws InterruptedException {
        TestRunner.startTest("Click on Add New Button for New Assessment");
        try {
            createAssessmentPF.waitUntilProgressBar();
            createAssessmentPF.AddNewButton();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed    :   Exception is found");
            Assert.fail();
        }
        Thread.sleep(1000);
    }

//    Select Item Bank(s)

    @And("Check, Validate And Click On Gallopade Questions in Select Item Banks")
    public void SelectItemBankGallopadeQuestions() throws InterruptedException {
        TestRunner.startTest("Select Item Banks Gallopade Question for Custom Assessment");
        try {
            createAssessmentPF.waitUntilProgressBar();
            createAssessmentPF.SelectItemBank();
            System.out.println("Test Case Passed    :   Gallopade Questions item bank selected successfully");
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed    :   Exception is found");
            Assert.fail();
        }
        Thread.sleep(1000);
    }

    @And("Check, Validate And Click On MyQuestions Questions in Select Item Banks")
    public void SelectItemBankMyQuestions() throws InterruptedException {
        TestRunner.startTest("Select Item Banks My Questions for Custom Assessment");
        try {
            createAssessmentPF.waitUntilProgressBar();
            createAssessmentPF.SelectMyQuestionItemBank();
            System.out.println("Test Case Passed    :   MyQuestion item bank selected successfully");
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed    :   Exception is found");
            Assert.fail();
        }
        Thread.sleep(1000);
    }

    @And("Check, Validate And Click On Next Button For New Assessment")
    public void ClickOnNextButton() throws InterruptedException {
        TestRunner.startTest("Click on Next Button for New Assessment");
        try {
            createAssessmentPF.NextButton();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

//    Assessment Information

    @And("Check, Validate And Fill The Assessment Information For New Assessment")
    public void AssessmentInformationForm() throws InterruptedException {
        TestRunner.startTest("Fill the Assessment Information for New Assessment");
        try {
            createAssessmentPF.AssessmentInformation();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

//    Select Multiple New Custom Questions

    @And("Check, Validate And Get The Questions For New Assessment")
    public void GetTotalQuestions() throws InterruptedException {
        TestRunner.startTest("Get and Select the Questions for New Assessment");
        try {
            createAssessmentPF.AddMultipleCustomQuestions();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed    :   Exception is found");
            Assert.fail();
        }
        Thread.sleep(1000);
    }

    @And("Check, Validate, Get And Select The MyQuestions For New Assessment")
    public void GetTotalMyCustomQuestions() throws InterruptedException {
        TestRunner.startTest("Get and Select the MyQuestions for New Assessment");
        try {
            createAssessmentPF.AddMultipleCustomMyQuestions();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed    :   Exception is found");
            Assert.fail();
        }
        Thread.sleep(1000);
    }

//    Finalize Question: Delete/Order/Weight

    @And("Check, Validate And Set Sequence, Weight And % For All Questions For New Assessment")
    public void EnterSequenceWeightAndPercentageForAllQuestions() throws InterruptedException {
        TestRunner.startTest("Set Sequence, Weight and Percentage for All Questions");
        try {
            createAssessmentPF.setSequenceWeightPercentageRepeatedly();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed    :   Exception is found");
            Assert.fail();
        }
        Thread.sleep(1000);
    }

    @And("Check, Validate And Get The Finalize Questions For New Assessment")
    public void GetTotalFinalizeQuestions() throws InterruptedException {
       TestRunner.startTest( "**********  Get total finalize questions for New Assessment **********");
        try {
            createAssessmentPF.listFinalizeQuestions();
            System.out.println("Test Case Passed    :   Finalize Questions list found successfully");
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed    :   Exception is found");
            Assert.fail();
        }
        Thread.sleep(3000);
    }

    @And("Check, Validate And Click On Save Button For New Assessment")
    public void ClickOnSaveButton() throws InterruptedException {
        TestRunner.startTest("Click on Save Button for New Assessment");
        try {
            createAssessmentPF.SaveNewAssessment();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed    :   Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

//    Search Custom Assignment

    @And("Validate And Select The Course For Search Custom Assessment")
    public void SelectTheCourseInCoursesDropdownForSearch() throws InterruptedException {
        TestRunner.startTest("Select the Course in Courses Dropdown for New Assessment Search");
        try {
            createAssessmentPF.SelectCourseSearchForCustomAssessment();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed    :   Exception is found");
            Assert.fail();
        }
        Thread.sleep(1000);
    }

    @And("Check, Validate And Apply Custom Student Book Filter Search For New Assessment")
    public void ClickAndApplyCustomAssessmentFilter() throws InterruptedException {
        TestRunner.startTest("Apply Custom Student Book Filter Search for New Assessment");
        try {
            createAssessmentPF.ClickAndApplyCustomAssessment();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed    :   Exception is found");
            Assert.fail();
        }
        Thread.sleep(1000);
    }

    @And("Validate And Enter Assessment Name Search For New Assessment")
    public void EnterNameAndSearchAssessment() throws InterruptedException {
        TestRunner.startTest("Search New Custom Assessment By Name");
        try {
            createAssessmentPF.ClickAndEnterNameForSearchAssessment();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed    :   Exception is found");
            Assert.fail();
        }
        Thread.sleep(1000);
    }

    @And("Validate And Get Custom Student Book Assessments and Assign New Assessment")
    public void GetAndProcessAssignCustomAssessment() throws InterruptedException {
        TestRunner.startTest("Get New Custom Assessment and Assign");
        try {
            createAssessmentPF.ClickOnAssignAndProcessToAssignAssessment();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed    :   Exception is found");
            Assert.fail();
        }
        Thread.sleep(1000);
    }

    @And("Validate And Get Custom Student Book Assessments and Assign New Assessment In Group")
    public void GetAndProcessAssignCustomAssessmentInGroup() throws InterruptedException {
        TestRunner.startTest("Get New Custom Assessment and Assign in Group");
        try {
            createAssessmentPF.ClickOnAssignAndProcessToAssignAssessmentInGroup();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed    :   Exception is found");
            Assert.fail();
        }
        Thread.sleep(1000);
    }

//    Edit Custom Assessment

    @And("Click On Custom Assessment Edit Button")
    public void ClickOnClassEditButton() throws InterruptedException{
       TestRunner.startTest("Check and validate to Click on Edit button in Custom Assessment");
        try {
            editAssessmentPF.clickAssessmentEditButton();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed   :  Exception is found");
            Assert.fail();
        }
    }

    @And("Click on Next Button In Edit Custom Assessment")
    public void ClickOnNextButtonInEditCustomAssessment() throws InterruptedException {
       TestRunner.startTest("Click On Next Button In Edit Custom Assessment");
        try {
            editAssessmentPF.clickOnNextButtonInEditAssessment();
        }  catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed  :   Exception is found");
            Assert.fail();
        }

        Thread.sleep(5000);
    }

    @And("Validate and Click on My Question Type In Edit Custom Assessment")
    public void ValidateAndClickOnMyQuestionTypeInEditCustomAssessment() throws InterruptedException {
       TestRunner.startTest("Validate and Click on My Question Type In Edit Custom Assessment");
        try {
            editAssessmentPF.selectCustomQuestionInEditAssessment();
        }  catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed  :   Exception is found");
            Assert.fail();
        }
    }

    @And("Verify Question Table Shows in Edit Custom Assessment")
    public void ValidateQuestionTableInCustomAssessment() throws InterruptedException {
        System.out.println("Check and validate the table shows in Edit Custom Assessment");
        try {
            editAssessmentPF.showsQuestionsIntoTable();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed  :   Exception is found");
            Assert.fail();
        }
    }

    @And("Verify Search Custom Question By Keyword in Edit Custom Assessment")
    public void ValidateSearchCustomQuestionInCustomEditAssessment() throws InterruptedException {
        System.out.println("Check and validate the search custom question in Edit Custom Assessment");
        try {
            editAssessmentPF.searchQuestionByName();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed  :   Exception is found");
            Assert.fail();
        }
    }

    @And("Verify In Custom Questions by Name Shows Into Table in Edit Custom Assessment")
    public void verifyNewQuestionByNameIntoTable(){
       TestRunner.startTest("Verify The New Question Added");
        try {
            editAssessmentPF.verifySearchedQuestionByNameIntoTable();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed  :   Exception is found. New Created Question not shown in table");
            Assert.fail();
        }
    }

    @And("Verify And Select Custom Questions in Edit Custom Assessment")
    public void verifyCustomQuestionInEditCustomAssessment() {
       TestRunner.startTest("Verify The New Custom Question Added in Edit Assessment");
        try {
            editAssessmentPF.selectNewCustomQuestion();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed  :   Exception is found. New Created Question not shown in table");
            Assert.fail();
        }
    }

//    Negative scenarios

    @And("Verify And Select Custom Questions with Empty Title Custom Assessment")
    public void verifyCustomQuestionWithEmptyTitleCustomAssessment() throws InterruptedException{
       TestRunner.startTest("Verify The New Custom Question with Empty Title Custom Assessment");
        try {
            createAssessmentPF.testEmptyAssessmentTitle();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed  :   Exception is found");
            Assert.fail();
        }
    }

    @And("Verify And Select Custom Questions with Empty Course Custom Assessment")
    public void VerifyCustomQuestionsWithEmptyCourseCustomAssessment() throws InterruptedException{
        TestRunner.startTest("Verify The New Custom Question with Empty Course Custom Assessment");
        try {
            createAssessmentPF.testEmptyAssessmentCourse();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed  :   Exception is found");
            Assert.fail();
        }
    }

    @And("Verify And Select Custom Questions with Empty Description Custom Assessment")
    public void verifyCustomQuestionWithEmptyDescriptionCustomAssessment() throws InterruptedException{
       TestRunner.startTest("Verify The New Custom Question with Empty Description Custom Assessment");
        try {
            createAssessmentPF.testEmptyDescription();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed  :   Exception is found");
            Assert.fail();
        }
    }

    @And("Verify And Select Custom Questions with Invalid Type Custom Assessment")
    public void verifyCustomQuestionWithInvalidTypeCustomAssessment() throws InterruptedException{
       TestRunner.startTest("Verify The New Custom Question with Invalid Type Custom Assessment");
        try {
            createAssessmentPF.testInvalidAssessmentType();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed  :   Exception is found");
            Assert.fail();
        }
    }

    @And("Verify And Select Custom Questions with No Question Selected Custom Assessment")
    public void verifyCustomQuestionWithNoQuestionSelectedCustomAssessment() throws InterruptedException{
       TestRunner.startTest("Verify The New Custom Question with No Question Selected Custom Assessment");
        try {
            createAssessmentPF.testNoQuestionsSelected();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed  :   Exception is found");
            Assert.fail();
        }
    }

    @And("Verify And Select Custom Questions with Invalid Weight Distribution Custom Assessment")
    public void verifyCustomQuestionWithInvalidWeightDistributionCustomAssessment() throws InterruptedException{
       TestRunner.startTest("Verify The New Custom Question with Invalid Weight Distribution Custom Assessment");
        try {
            createAssessmentPF.testInvalidWeightDistribution();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed  :   Exception is found");
            Assert.fail();
        }
    }

    @And("Verify And Select Custom Questions with Incorrect Status Selection Custom Assessment")
    public void verifyCustomQuestionWithIncorrectStatusSelectionCustomAssessment() throws InterruptedException{
       TestRunner.startTest("Verify The New Custom Question with Incorrect Status Selection Custom Assessment");
        try {
            createAssessmentPF.testIncorrectStatusSelection();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed  :   Exception is found");
            Assert.fail();
        }
    }

    @And("Click on StepII from Navbar Custom Assessment")
    public void GoTOStepIIAssessmentInformation() throws InterruptedException{
        TestRunner.startTest("Click on StepII  Assessment Information from Step III Select New Questions");
        try {
            createAssessmentPF.ClickStepIIAssessmentInformation();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed  :   Exception is found");
            Assert.fail();
        }
    }

    @And("Validate Information is Retained On StepII Assessment Information")
    public void ValidateInformationIsRetainedOnStepIIAssessmentInformation() throws InterruptedException{
        TestRunner.startTest("Validate Information is Retained On StepII Assessment Information");
        try {
            createAssessmentPF.ValidateInfoRetainedOnStepII();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed  :   Exception is found");
            Assert.fail();
        }
    }

    @And("Get Total Questions Selected on StepIII")
    public void GetTotalQuestionsSelectedOnStepIII() throws InterruptedException{
        TestRunner.startTest("Get Total Questions Selected on StepIII");
        try {
            createAssessmentPF.SelectedQuestionOnStepIII();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed  :   Exception is found");
            Assert.fail();
        }
    }

    @And("Validate total Selected Questions Retained On Step III")
    public void ValidateTotalSelectedQuestionsRetainedOnStepIII() throws InterruptedException{
        TestRunner.startTest("Validate total Selected Questions Retained On Step III");
        try {
            createAssessmentPF.ValidateTotalSelectedQuestionRetained();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed  :   Exception is found");
            Assert.fail();
        }
    }

    @And("Click on StepIII Select New Questions From NavBar")
    public void ClickOnStepIIISelectNewQuestionsFromNavBar() throws InterruptedException{
        TestRunner.startTest("Click on StepIII Select New Questions From NavBar");
        try {
            createAssessmentPF.ClickStepIIISelectNewQuestions();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed  :   Exception is found");
            Assert.fail();
        }
    }

    @And("Check, Validate And Select Assignment Status on Summary")
    public void CheckValidateAndSelectAssignmentStatusOnSummary() throws InterruptedException{
        TestRunner.startTest("Check, Validate And Select Assignment Status on Summary");
        try {
            createAssessmentPF.SelectStatusForAssignment();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed  :   Exception is found");
            Assert.fail();
        }
    }

    @And("Verify, Check Custom Assessment Status is Retained on Summary")
    public void VerifyCheckCustomAssessmentStatusIsRetainedOnSummary() throws InterruptedException{
        TestRunner.startTest("Verify, Check Custom Assessment Status is Retained on Summary");
        try {
            createAssessmentPF.IsAssessmentStatusRetainedOnSummary();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed  :   Exception is found");
            Assert.fail();
        }
    }

    @And("Click on StepIV Finalize Questions From NavBar")
    public void ClickOnStepIVFinalizeQuestionsFromNavBar() throws InterruptedException{
        TestRunner.startTest("Click on StepIV Finalize Questions From NavBar");
        try {
            createAssessmentPF.ClickStepIVFinalizeQuestions();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed  :   Exception is found");
            Assert.fail();
        }
    }

    @And("Click On Save Button For New Assessment Summary")
    public void ClickOnSaveButtonForNewAssessmentSummary() throws InterruptedException{
        TestRunner.startTest("Click On Save Button For New Assessment Summary");
        try {
            createAssessmentPF.NewAssessmentSummarySaveBtn();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed  :   Exception is found");
            Assert.fail();
        }
    }

}
