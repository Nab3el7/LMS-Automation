package StepDefinitions.MyContentModule;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import org.junit.Assert;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Assignmment.AssignmentStatusReview_PF;
import pageFactory.MyContent.AssignAssessment_PF;

import java.time.Duration;

public class AssignAssessmentSteps extends Configurations {
    WebDriver driver = Configurations.getDriver();

    AssignAssessment_PF assignAssessmentPF;
    Helper helper;
    public WebDriverWait wait;
    


    public AssignAssessmentSteps(){
        assignAssessmentPF = new AssignAssessment_PF(driver);
        helper = new Helper();
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
    }

    @And("Check, Validate, Assign And Fill Information For All Assessments Individually")
    public void ProcessOfAllAssignAssessments() throws InterruptedException{
        TestRunner.startTest( " Get All Assignments and click on New Assign Assignment **********");
        try {
            assignAssessmentPF.ProcessAssignAssessments();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed:   :   Assignment Release Successfully  **********");
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed:    :   Exception is found  **********" + e);
            Assert.fail();
        }
        Thread.sleep(3000);
    }

    @And("Check, Validate And Fill Assignment Information For All Assessments Individually")
    public void EnterAssignmentInformationOfNewAssignAssessments() throws InterruptedException {
        TestRunner.startTest( " Fill the Assignment Information Of New Assignment  **********");
        try {
            assignAssessmentPF.ClickOnAssignButton();
            System.out.println("Test Case Passed    :   Assignment information filled successfully  **********");
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            System.out.println("**********  Test Case Failed    :   Exception is found  **********");
            Assert.fail();
        }
        Thread.sleep(1000);
    }

    @And("Check, Validate, Fill Show Additional Settings Information For All Assessments Individually")
    public void EnterAssignmentAdditionalSettingsInformationOfNewAssignAssessments() throws InterruptedException{
        TestRunner.startTest( " Fill the Assignment Additional Settings Information Of New Assignment  **********");
        try {
            assignAssessmentPF.ProcessAssignAssessments();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed:   :   Assignment additional settings information filled successfully  **********");
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed:    :   Exception is found  **********" + e);
            Assert.fail();
        }
        Thread.sleep(3000);
    }

    @And("Check, Validate, And Fill Scoring Options Information For All Assessments Individually")
    public void EnterAssignmentScoringOptionsInformationOfNewAssignAssessments() throws InterruptedException{
        TestRunner.startTest( " Fill the Assignment Scoring Options Information Of New Assignment  **********");
        try {
            assignAssessmentPF.ProcessAssignAssessments();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed:   :   Assignment scoring options information filled successfully  **********");
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed:    :   Exception is found  **********" + e);
            Assert.fail();
        }
        Thread.sleep(3000);
    }
}
