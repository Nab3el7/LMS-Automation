package StepDefinitions.MyContentModule.AssessmentsSteps;

import StepDefinitions.Configurations;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import org.junit.Assert;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.MyContent.AssessmentsPF.Assessments_PF;
import pageFactory.MyContent.CreateAssessment_PF;

import java.time.Duration;

public class AssessmentsSteps extends Configurations {
    WebDriver driver = Configurations.getDriver();
    public WebDriverWait wait;
    Assessments_PF assessmentsPF;
    CreateAssessment_PF createAssessmentPF;

    public AssessmentsSteps() {
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
        assessmentsPF = new Assessments_PF(driver);
        createAssessmentPF = new CreateAssessment_PF(driver);
    }

    @And("Verify In My Content Assessments Shows Into Table")
    public void verifyQuestionsShowsIntoTable() throws InterruptedException {
        TestRunner.startTest("Verify Assessment Shows Into Table");
        try {
            assessmentsPF.showsAssessmentIntoTable();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed    :   Exception is found. Custom Questions not Shows Into Table");
            Assert.fail();
        }
    }

    @And("Select Custom Assessment Status Filter On Assessment")
    public void selectMyContentFilterOnAssessmentStatus() {
        TestRunner.startTest("I'm in to select My Content Filter On Assessment Status");
        try {
            assessmentsPF.filterAssessmentByStatus();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed    :   Exception is found. Custom Filter On Question Type not found");
            Assert.fail();
        }
    }

    @And("Verify Custom Assessment Status")
    public void selectMyContentVerifyAssessmentStatus() throws InterruptedException {
        TestRunner.startTest("I'm in to select My Content Assessment Status");
        try {
            createAssessmentPF.verifyAssessmentStatus();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed    :   Exception is found. Custom Filter On Question Type not found");
            Assert.fail();
        }
    }
}
