package StepDefinitions.MyContentModule.AssessmentsSteps;

import StepDefinitions.Configurations;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import org.junit.Assert;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Assignmment.CorrectAnswerExecutor_PF;
import pageFactory.MyContent.AssessmentsPF.CombineAssessments_PF;

import java.time.Duration;

public class CombineAssessmentsSteps extends Configurations {
    WebDriver driver = Configurations.getDriver();

    public WebDriverWait wait;
    CombineAssessments_PF combineAssessmentsPF;

    public CombineAssessmentsSteps() {
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
        combineAssessmentsPF = new CombineAssessments_PF(driver);
    }

    @And("Check, Validate And Click On Combine Assessment Button")
    public void clickOnCombineAssessmentButton(){
        System.out.println("Check click on Combine Assessment button");
        TestRunner.startTest("Click On Combine Assessment Button");
        try {
            combineAssessmentsPF.clickOnCombineAssessmentButton();
        } catch (Exception e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed    :   Exception is found. Course My Content Filter not found");
            Assert.fail();
        }
    }

    @And("Check, Validate and Select The Assessments Into Assessments Table")
    public void selectAssessmentsIntoAssessmentsTable() throws InterruptedException {
        System.out.println("Select the Assessments into assessments table");
        TestRunner.startTest("Select The Assessments Into Assessments Table");
        try {
            combineAssessmentsPF.combineAssessmentsIntoTable();
        } catch (Exception e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed    :   Exception is found. Course My Content Filter not found");
            Assert.fail();
        }
    }

    @And("Check, Validate and Save The Combine Assessments")
    public void saveCombineAssessment() throws InterruptedException {
        System.out.println("Save the Combine Assessments");
        TestRunner.startTest("Save the Combine Assessments");
        try {
            combineAssessmentsPF.enterCombineAssessmentName();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("Check, Validate Total Questions Of Combine Assessment And Enter Weights & Percentages")
    public void validateTotalQuestionsOfCombineAssessmentAndEnterWeightsAndPercentages() throws InterruptedException {
        System.out.println("Validate Total Questions Of Combine Assessment And Enter Weights And Percentages");
        TestRunner.startTest("Validate Total Questions Of Combine Assessment And Enter Weights And Percentages");
        try {
            combineAssessmentsPF.validateCombinedAssessmentQuestionAndEnterWeightPercentage();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("Validate And Enter Combined Assessment Name Search For New Assessment")
    public void EnterNameForSearchCombinedAssessment() throws InterruptedException {
        TestRunner.startTest("Search New Custom Combined Assessment By Name");
        try {
            combineAssessmentsPF.searchCombinedAssessment();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed    :   Exception is found");
            Assert.fail();
        }
        Thread.sleep(1000);
    }

    @And("Validate And Get Combined Assessments and Assign New Assessment")
    public void GetAndProcessAssignCombineAssessment() throws InterruptedException {
        TestRunner.startTest("Get New Custom Combined Assessment and Assign");
        try {
            combineAssessmentsPF.clickAssignTheCombineAssessment();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed    :   Exception is found");
            Assert.fail();
        }
        Thread.sleep(1000);
    }

    @And("Validate And Verify The Total Combined Assessment Question With Student Attempted Assignment")
    public void verifyCombineAssessmentQuestionFromStudentSide() throws InterruptedException {
        TestRunner.startTest("Get New Custom Combined Assessment and Assign");
        try {
            combineAssessmentsPF.verifyCombinedAssessmentTotalQuestionStudentSide();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed    :   Exception is found");
            Assert.fail();
        }
        Thread.sleep(1000);
    }

    @And("Validate And Verify The Total Combined Assessment Question With Gradebook Assignment")
    public void verifyCombineAssessmentQuestionFromGradebook() throws InterruptedException {
        TestRunner.startTest("Get New Custom Combined Assessment And Verify Question With Gradebook Assignment");
        try {
            String assignmentNameForCorrect = CorrectAnswerExecutor_PF.assignmentNameForCorrect.get();
            System.out.println("Want to open combine assessment to verify total questions: " + assignmentNameForCorrect);
            TestRunner.getTest().log(Status.INFO, "Want to open combine assessment to verify total questions: " + assignmentNameForCorrect);
            combineAssessmentsPF.verifyQuestionsAndSearchCombineAssessmentInGradebook(assignmentNameForCorrect);
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed    :   Exception is found");
            Assert.fail();
        }
        Thread.sleep(1000);
    }


}
