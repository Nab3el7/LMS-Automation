package StepDefinitions.MyContentModule.Resources;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.NotificationsModule.NotificationsByTeacherRoleLifeCycleSteps;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.MyContent.Resources.*;

import java.time.Duration;

//import static StepDefinitions.Configurations.driver;

public class ResourceTypeURLSteps extends Configurations {
    WebDriver driver = Configurations.getDriver();

    ResourceTypeURL_PF resourceTypeURLPf;
    ResourcesFilterURL_PF resourcesFilterPf;
    CopyResourceURL_PF copyResourceURLPf;
    EditResourceURL_PF editResourceURLPf;
    AssignResource_PF assignResourcePf;
    PerviewResourceURL_PF perviewResourceURLPf;

    DeleteResourceURL_PF deleteResourceURLPf;
    Helper helper;


    public WebDriverWait wait;
    WebElement loader = driver.findElement(By.xpath("//span[@role='progressbar']"));


    public ResourceTypeURLSteps(){
        resourceTypeURLPf= new ResourceTypeURL_PF(driver);
        resourcesFilterPf = new ResourcesFilterURL_PF(driver);
        copyResourceURLPf = new CopyResourceURL_PF(driver);
        editResourceURLPf = new EditResourceURL_PF(driver);
        assignResourcePf = new AssignResource_PF(driver);
        deleteResourceURLPf = new DeleteResourceURL_PF(driver);
        helper = new Helper();
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
    }


    @And("click on Resources")
    public void Resources_dashboard() throws InterruptedException{
        TestRunner.startTest("Click on Resources");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            resourceTypeURLPf.click_Resources();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  Exception is found. Resources Button not Found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Validate Resources Dashboard")
    public void Resource_Dashboard() throws InterruptedException{
        TestRunner.startTest("Validate Resources Dashboard ");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            resourceTypeURLPf.resources_dashboard();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  Exception is found. Resources Dashboard not visible ");
            Assert.fail();
        }
        Thread.sleep(2000);
    }


    @And("Select Class in Resources Dashboard")
    public void select_Class() throws InterruptedException{
        TestRunner.startTest("Select Class ");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            resourceTypeURLPf.selected_Course();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  Exception is found. No Class found.");
            Assert.fail();
        }
        Thread.sleep(2000);
    }
    @And("Validate and click on Add New Button")
    public void click_btn() throws InterruptedException{
        TestRunner.startTest("Validate and click on Add New Button ");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            resourceTypeURLPf.click_Add_new_btn();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  Exception is found. Add new Button not found in Resources.");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Validate and fill Resource Information step-1")
    public void Resource_Information() throws InterruptedException{
        TestRunner.startTest("Validate and fill Resource Information Step-I");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            resourceTypeURLPf.resource_Information();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  Exception is found. Step-I not load.");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Validate and Click On next Button For Resources")
    public void btn_next_click() throws InterruptedException {
        TestRunner.startTest("Validate and Click On next Button For Resources step-I");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            resourceTypeURLPf.click_next_btn();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : Exception is found. Next Button is not found in Step-I.");
            Assert.fail();
        }
    }

    @And("Validate Toast Message in Resources")
    public void ValidateToastMessageResources() throws InterruptedException{
        TestRunner.startTest("Validate and Click Next Button");
        try {
            resourceTypeURLPf.validateToastMessage();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : Exception is found. Toast Message not found.");
            Assert.fail();
        }
    }

    @And("Validate and fill Resource Information step-II")
    public void Resource_Info_step_II() throws InterruptedException{
        TestRunner.startTest("Validate and fill Resource Type Step-II");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            resourceTypeURLPf.ResourceType();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : Exception is found. Step-II is not Load.");
            Assert.fail();
        }
    }

    @And("Check and validate steps save button")
    public void stepIISaveButton() throws InterruptedException{
        TestRunner.startTest("Validate step-II Save Button");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            resourceTypeURLPf.click_save();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : Exception is found. Step-II save button not found/Visible.");
            Assert.fail();
        }

    }

    @And("Check and Validate Next button on step-II")
    public void NextButtonStepII()throws InterruptedException{
        TestRunner.startTest("Check and Validate Next button on step-II");
        try {
            Thread.sleep(2000);
            wait.until(ExpectedConditions.invisibilityOf(loader));
            resourceTypeURLPf.click_next_step_2();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : Exception is found. Step-II Next button is Disable.");
            Assert.fail();
        }
    }

    //

    @And("select course again")
    public void validate_course() throws InterruptedException{
        TestRunner.startTest("Validate and click Course selection On Dashboard");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            resourcesFilterPf.Course_selection_Dashboard();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  Exception is found. Courses dropdown not found.");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Validate My Resources Left Panel")
    public void validate_filters() throws InterruptedException {
        TestRunner.startTest("Validate My Resources Left Panel");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            resourcesFilterPf.left_panel_resources_section();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  Exception is found. Left Panel not found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Apply filterButton in Resources")
    public void apply_all_filter() {
        TestRunner.startTest("Check and Validates Filter in left Panel");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            resourcesFilterPf.apply_filter_btn();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  Exception is found. Apply filterButton in Resources Not Found");
            Assert.fail();
        }
    }

    @And("Verify Resource Shows Into Table")
    public void VerifyResourceShowsIntoTable() throws InterruptedException{
        TestRunner.startTest("Verify Resource Shows Into Table");
        try {
            resourcesFilterPf.showsResourceIntoTable();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  Exception is found. Resources not Shown in Table");

            Assert.fail();
        }
    }

    @And("Search New Resource")
    public void SearchNewResource() throws InterruptedException{
        TestRunner.startTest("Search The New Resource Added");
        try {
            resourcesFilterPf.searchResourceByTitle();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  Exception is found. Search Box not found and searching is not working");
            Assert.fail();
        }
    }

    @And("Verify The New Resource by Title")
    public void VerifyTheNewResourceByTitle() throws InterruptedException
    {
        TestRunner.startTest("Verify The New Resource Exists or not");
        try {
            resourcesFilterPf.verifySearchedResourceByTitleIntoTable();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  Exception is found. New Added resource not exists in Table");
            Assert.fail();
        }
    }

    // copy resource
    @And("Click On Resource Copy Button")
    public void ClickOnResourceCopyButton() throws InterruptedException{
        TestRunner.startTest("Check and validate to Click on Copy button in Resources");
        try {
            copyResourceURLPf.clickCopyButton();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : Exception is found. Copy Button not Found.");
            Assert.fail();
        }
    }
    @And("Add Title for  Resource in Copy Resource Modal")
    public void AddTitleForResourceInCopyResourceModal() throws InterruptedException{
        TestRunner.startTest("Add Title for Copy Resource in Copy Resource Modal");
        try {
            copyResourceURLPf.CopyResourceModalBox();
            Thread.sleep(2000);
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }


    @And("Validate and Copy Resource Information")
    public void CopyResourceInformation() throws InterruptedException{
        TestRunner.startTest("Check and validate to Copy Resource Information");
        try {
            copyResourceURLPf.copyResourceInfo();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : Exception is found. Resource Information not Edit");
            Assert.fail();
        }
    }

    @And("Click on Copy Save Button of Resource to save new Information")
    public void ClickCopySaveButtonResource() throws InterruptedException{
        TestRunner.startTest("Click On Save Button to save New Title ");
        try {
            copyResourceURLPf.clickOnSave();
        }catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : Save Button not found and new information not save");
            Assert.fail();
        }

    }
    @And("Search New Resource With Updated Copy Title")
    public void SearchNewResourceByUpdatedCopyTitle() throws InterruptedException{
        TestRunner.startTest("Search The New Resource By Updated Title");
        try {
            copyResourceURLPf.searchResourceByUpdatedCopyTitle();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : Exception is found. Search Box not found and searching is not working");
            Assert.fail();
        }
    }
    @And("Check and Validate The Copy Resource Information")
    public void ValidateCopyClassInformation() throws InterruptedException {
        TestRunner.startTest("Check and validate the Copy Resource Information");
        try {
            copyResourceURLPf.verifyUpdatedResourceCopyTitle();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : Exception is found. Copy Information of Resource not found");

            Assert.fail();
        }
    }



    // edit resource
    @And("Click On Resource Edit Button")
    public void ClickOnResourceEditButton() throws InterruptedException{
        TestRunner.startTest("Check and validate to Click on Edit button in Resources");
        try {
            editResourceURLPf.clickEditButton();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : Exception is found. Edit Button not Found.");
            Assert.fail();
        }
    }

    @And("Validate and Edit Resource Information")
    public void EditResourceInformation() throws InterruptedException{
        TestRunner.startTest("Check and validate to Edit Resource Information");
        try {
            editResourceURLPf.editResourceInfo();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : Exception is found. Resource Information not Edit");
            Assert.fail();
        }
    }

    @And("Click on Save Button of Resource to save new Information")
    public void ClickSaveButtonResource() throws InterruptedException{
        TestRunner.startTest("Click On Save Button to save New Title ");
        try {
            editResourceURLPf.clickOnSave();
        }catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : Save Button not found and new information not save");
            Assert.fail();
        }

    }

    @And("Search New Resource With Updated Title")
    public void SearchNewResourceByUpdatedTitle() throws InterruptedException{
        TestRunner.startTest("Search The New Resource By Updated Title");
        try {
            editResourceURLPf.searchResourceByUpdatedTitle();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : Exception is found. Search Box not found and searching is not working");
            Assert.fail();
        }
    }

    @And("Check and Validate The Edited Resource Information")
    public void ValidateEditClassInformation() throws InterruptedException {
        TestRunner.startTest("Check and validate the Edited Resource Information");
        try {
            editResourceURLPf.verifyUpdatedResourceTitle();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : Exception is found. Edit Information of Resource not found");

            Assert.fail();
        }
    }

    // Assign Resource

    @And("Validate And Get Custom Resource and Assign New Resource")
    public void GetAndProcessAssignCustomResource() throws InterruptedException {
        TestRunner.startTest("Get New Custom Resource and Assign");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            assignResourcePf.ClickOnAssignAndProcessToAssignResource();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed    :   Exception is found");
            Assert.fail();
        }
        Thread.sleep(1000);
    }

    // Delete Resource URL

    @And("Search the Resource for delete")
    public void SearchResourceForDelete() throws InterruptedException{
        TestRunner.startTest("Check, validate and Search the Resource That want to be Delete");
        try {
            deleteResourceURLPf.searchResourceForDelete();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  Exception is found. Resource That You Want to delete not found");
            Assert.fail();
        }
    }

    @And("Click On Resource Delete Button")
    public void ClickOnResourceDeleteButton() throws InterruptedException{
        TestRunner.startTest("Check, validate and click on Delete Button");
        try {
            deleteResourceURLPf.Delete_btn_url();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  Exception is found. Delete Button not found.");
            Assert.fail();
        }
    }

    @And("Verify Delete Resource Window")
    public void VerifyDeleteResourceWindow() throws InterruptedException{
        TestRunner.startTest("Check, validate Delete Resource Window and Apply Delete Operation ");
        try {
            deleteResourceURLPf.DeleteResourceWindow();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : Exception is found. Delete Resource Window not appear.");
            Assert.fail();
        }
    }

    @And("Click Yes button to delete Resource")
    public void ClickYesButtonToDeleteResource() throws InterruptedException{
        TestRunner.startTest("Check, validate Delete Resource By Click on Yes Button ");
        try {
            deleteResourceURLPf.clickYesToDelete();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  Exception is found. Yes Button not found");
            Assert.fail();
        }
    }

    @And("Verify Toast Message for Delete Resource")
    public void VerifyToastMessageForDeleteResource(){
        TestRunner.startTest("Check and validate Delete Toast Message");
        try {
            deleteResourceURLPf.verifySuccessMessage();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : Exception is found. Toast Message not found for Delete");
            Assert.fail();
        }
    }

}