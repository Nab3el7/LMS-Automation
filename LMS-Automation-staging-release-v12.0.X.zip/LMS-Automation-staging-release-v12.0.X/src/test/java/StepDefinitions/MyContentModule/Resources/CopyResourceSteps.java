//package StepDefinitions.MyContentModule.Resources;
//
//
//
//import StepDefinitions.Configurations;
//import StepDefinitions.Helper;
//import StepDefinitions.TestRunner;
//import com.aventstack.extentreports.Status;
//import io.cucumber.java.en.And;
//import org.junit.Assert;
//import org.openqa.selenium.ElementNotVisibleException;
//import org.openqa.selenium.NoSuchElementException;
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.support.ui.WebDriverWait;
//import pageFactory.MyContent.QuestionsPF.CreateQuestion_PF;
//import pageFactory.MyContent.QuestionsPF.CustomQuestionsTypes_PF;
//
//import java.time.Duration;
//
//public class CopyResourceSteps extends Configurations {
//    WebDriver driver = Configurations.getDriver();
//    CreateQuestion_PF createQuestionPF;
//    Helper helper;                      //Create object of Helper class
//    public WebDriverWait wait;
//
//    CustomQuestionsTypes_PF customQuestionsTypesPF;
//
//    public CopyResourceSteps() {
//        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
//        helper = new Helper();
//        createQuestionPF = new CreateQuestion_PF(driver);
//        customQuestionsTypesPF = new CustomQuestionsTypes_PF(driver);
//    }
//
//
//
//    @And("Check, Validate And Click On Question Tab And Validate Question Dashboard")
//    public void ClickOnMyContentQuestionTabButton(){
//        TestRunner.startTest( "Check and validate to Click on Question Tab");
//        try {
//            createQuestionPF.clickOnQuestionTab();
//        } catch (NoSuchElementException | ElementNotVisibleException e) {
//            System.out.println(e.getMessage());
//            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
//            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
//            Assert.fail();
//        }
//    }
//
//    @And("Check, Validate And Click On Add New Question Button And Validate New Question Dashboard")
//    public void ClickOnMyContentQuestionAddNewQuestionButton(){
//        TestRunner.startTest("Check and validate to Click on Add New Question Button And Validate New Question Dashboard");
//        try {
//            createQuestionPF.clickOnAddQuestionButton();
//        } catch (NoSuchElementException | ElementNotVisibleException e) {
//            System.out.println(e.getMessage());
//            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
//            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found. Add New Question Button not found ");
//            Assert.fail();
//        }
//    }
//
//    @And("Enter the New Question Title")
//    public void EnterTheNewQuestionTitle(){
//        TestRunner.startTest("Check and validate to Enter the New Question Title");
//        try {
//            createQuestionPF.EnterQuestionTitle();
//        } catch (NoSuchElementException | ElementNotVisibleException e) {
//            System.out.println(e.getMessage());
//            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
//            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found. New Question Title not enter");
//            Assert.fail();
//        }
//    }
//
//    @And("Enter the New Question Points")
//    public void EnterTheNewQuestionPoints(){
//        TestRunner.startTest("Check and validate to Enter the New Question Points");
//        try {
//            createQuestionPF.EnterQuestionPoints();
//        } catch (NoSuchElementException | ElementNotVisibleException e) {
//            System.out.println(e.getMessage());
//            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
//            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found. New Question Points not enter");
//            Assert.fail();
//        }
//    }
//
//    @And("Select the New Question Status")
//    public void EnterTheNewQuestionStatus() throws InterruptedException {
//        TestRunner.startTest("Check and validate to Enter the New Question Status");
//        try {
//            createQuestionPF.SelectQuestionStatus();
//        } catch (NoSuchElementException | ElementNotVisibleException e) {
//            System.out.println(e.getMessage());
//            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
//            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found. New Question Status not set ");
//            Assert.fail();
//        }
//    }
//
//    @And("Select the New Question Course")
//    public void EnterTheNewQuestionCourse() throws InterruptedException{
//        TestRunner.startTest("Check and validate to Enter the New Question Course");
//        try {
//            createQuestionPF.SelectQuestionCourse();
//        } catch (NoSuchElementException | ElementNotVisibleException e) {
//            System.out.println(e.getMessage());
//            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
//            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found. New Question Course not select");
//            Assert.fail();
//        }
//    }
//
//    @And("Select the New Question Checkbox Student Hint")
//    public void EnterTheNewQuestionCheckboxStudentHint(){
//        TestRunner.startTest("Check and validate to Select the New Question Checkbox Student Hint");
//        try {
//            createQuestionPF.SelectQuestionStudentHint();
//        } catch (NoSuchElementException | ElementNotVisibleException e) {
//            System.out.println(e.getMessage());
//            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
//            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found. Checkbox Student Hint not found");
//            Assert.fail();
//        }
//    }
//
//    @And("Enter the New Question Display Student Hint")
//    public void EnterTheNewQuestionDisplayStudentHint() throws InterruptedException{
//        TestRunner.startTest("Check and validate to Select the New Question Display Student Hint");
//        try {
//            createQuestionPF.EnterQuestionHint();
//        } catch (NoSuchElementException | ElementNotVisibleException e) {
//            System.out.println(e.getMessage());
//            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
//            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found. Display Student Hint not found.");
//            Assert.fail();
//        }
//    }
//
////    @And("Click on New Question Next Button")
////    public void ClickOnNextButton(){
////        TestRunner.startTest("Check and validate to click on New Question Next Button");
////        try {
////            createQuestionPF.clickOnNewQuestionNextButton();
////        } catch (NoSuchElementException | ElementNotVisibleException e) {
////            System.out.println(e.getMessage());
////            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
////            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found. New Question Next Button not found");
////            Assert.fail();
////        }
////    }
//
//    @And("Select the New Custom Question Type")
//    public void EnterTheNewCustomQuestionType() throws InterruptedException {
//        TestRunner.startTest("Check and validate to Enter the New Question Type");
//        try {
//            createQuestionPF.SelectNewCustomQuestionType();
//        } catch (NoSuchElementException | ElementNotVisibleException e) {
//            System.out.println(e.getMessage());
//            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
//            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found. New Question Type not select");
//            Assert.fail();
//        }
//    }
//
//    @And("Select the New Question Type Multiple Choice")
//    public void EnterTheNewQuestionTypeMultipleChoice() throws InterruptedException {
//        TestRunner.startTest("Check and validate to Enter the New Question Type Multiple Choice");
//        try {
//            createQuestionPF.SelectNewQuestionTypeMultipleChoice();
//        } catch (NoSuchElementException | ElementNotVisibleException e) {
//            System.out.println(e.getMessage());
//            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
//            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found. Type Multiple Choice not found");
//            Assert.fail();
//        }
//    }
//
//    @And("Enter the New Question Type Multiple Choice Question And Answers")
//    public void EnterTheNewQuestionTypeMultipleChoiceQuestionAndAnswers() throws InterruptedException {
//        TestRunner.startTest("Check and validate to Enter the New Question Type Multiple Choice Question And Answers");
//        try {
//            customQuestionsTypesPF.EnterNewQuestionTypeMultipleChoiceQuestion();
//        } catch (NoSuchElementException | ElementNotVisibleException e) {
//            System.out.println(e.getMessage());
//            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
//            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found. Multiple Choice Question And Answers not found");
//            Assert.fail();
//        }
//    }
//
//    @And("Enter the New Question Type Multiple Select Question And Answers")
//    public void EnterTheNewQuestionTypeMultipleSelectQuestionAndAnswers() throws InterruptedException {
//        TestRunner.startTest("Check and validate to Enter the New Question Type Multiple Select Question And Answers");
//        try {
//            customQuestionsTypesPF.EnterNewQuestionTypeMultipleSelectQuestion();
//        } catch (NoSuchElementException | ElementNotVisibleException e) {
//            System.out.println(e.getMessage());
//            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
//            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found. Type Multiple Select not found");
//            Assert.fail();
//        }
//    }
//
//    @And("Enter the New Question Type Sequence Question And Answers")
//    public void EnterTheNewQuestionTypeSequenceQuestionAndAnswers() throws InterruptedException {
//        TestRunner.startTest("Check and validate to Enter the New Question Type Sequence Question And Answers");
//        try {
//            customQuestionsTypesPF.EnterNewQuestionTypeSequenceQuestion();
//        } catch (NoSuchElementException | ElementNotVisibleException e) {
//            System.out.println(e.getMessage());
//            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
//            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found. Type Sequence Question And Answers not found");
//            Assert.fail();
//        }
//    }
//
//    @And("Enter the New Question Type Open Response Question And Answers")
//    public void EnterTheNewQuestionTypeOpenResponseQuestionAndAnswers() throws InterruptedException {
//        TestRunner.startTest("Check and validate to Enter the New Question Type Open Response Question And Answers");
//        try {
//            customQuestionsTypesPF.EnterNewQuestionTypeOpenResponseQuestion();
//        } catch (NoSuchElementException | ElementNotVisibleException e) {
//            System.out.println(e.getMessage());
//            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
//            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found. Type Open Response Question And Answers not found.");
//            Assert.fail();
//        }
//    }
//
//    @And("Enter the New Question Type Spelling Question And Answers")
//    public void EnterTheNewQuestionTypeSpellingQuestionAndAnswers() throws InterruptedException {
//        TestRunner.startTest("Check and validate to Enter the New Question Type Spelling Question And Answers");
//        try {
//            customQuestionsTypesPF.EnterNewQuestionTypeSpellingQuestion();
//        } catch (NoSuchElementException | ElementNotVisibleException e) {
//            System.out.println(e.getMessage());
//            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
//            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found. Type Spelling Question And Answers not found. ");
//            Assert.fail();
//        }
//    }
//
//    @And("Enter the New Question Type Drawing Question And Answers")
//    public void EnterTheNewQuestionTypeDrawingQuestionAndAnswers() throws InterruptedException {
//        TestRunner.startTest("Check and validate to Enter the New Question Type Drawing Question And Answers");
//        try {
//            customQuestionsTypesPF.EnterNewQuestionTypeDrawingQuestion();
//        } catch (NoSuchElementException | ElementNotVisibleException e) {
//            System.out.println(e.getMessage());
//            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
//            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found. Type Drawing Question And Answers not found");
//            Assert.fail();
//        }
//    }
//
//    @And("Click, Validate and Select the New Question Standards")
//    public void SelectTheNewQuestionStandards() throws InterruptedException {
//        TestRunner.startTest("Click and Validate to Select the New Question Standards");
//        try {
//            createQuestionPF.StandardSelection();
//        } catch (NoSuchElementException | ElementNotVisibleException e) {
//            System.out.println(e.getMessage());
//            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
//            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found. New Question Standards not found");
//            Assert.fail();
//        }
//    }
//
//    @And("Click on New Question Save Standard and Units Button")
//    public void ClickOnSaveStandardAndUnitsButton(){
//        TestRunner.startTest("Check and validate to click on New Question Save Standard and Units Button");
//        try {
//            createQuestionPF.SaveStandardAndUnits();
//        } catch (NoSuchElementException | ElementNotVisibleException e) {
//            System.out.println(e.getMessage());
//            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
//            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found. New Question Save Standard and Units Button not found.");
//            Assert.fail();
//        }
//    }
//
//    @And("Click, Validate and Select the New Question UnitsAndChapters")
//    public void SelectTheNewQuestionUnitsAndChapters() throws InterruptedException {
//        TestRunner.startTest("Click and Validate to Select the New Question UnitsAndChapters");
//        try {
//            createQuestionPF.UnitsAndChapterSelection();
//        } catch (NoSuchElementException | ElementNotVisibleException e) {
//            System.out.println(e.getMessage());
//            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
//            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found. New Question UnitsAndChapters not found");
//            Assert.fail();
//        }
//    }
//
//    @And("Enter the New Question Topics Keyword")
//    public void EnterTheNewQuestionTopicsKeyword() {
//        TestRunner.startTest("Check and validate to Enter the New Question Topics Keyword");
//        System.out.println("I'm in to add new topics");
//        try {
//            createQuestionPF.AddTopicsKeywords();
//        } catch (NoSuchElementException | ElementNotVisibleException e) {
//            System.out.println(e.getMessage());
//            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
//            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found. New Question Topics Keyword not enter ");
//            Assert.fail();
//        }
//    }
//
//    @And("Click on New Question Save Button")
//    public void ClickOnSaveButton(){
//        TestRunner.startTest("Check and validate to click on New Question Save Button");
//        System.out.println("I'm in to save new question");
//        try {
//            createQuestionPF.clickOnNewQuestionSaveButton();
//        } catch (NoSuchElementException | ElementNotVisibleException e) {
//            System.out.println(e.getMessage());
//            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
//            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found. New Question Save Button not found");
//            Assert.fail();
//        }
//    }
//
//    @And("Verify New Question Toast Message")
//    public void VerifyNewQuestionToastMessage() {
//        TestRunner.startTest( "Check and validate Toast Message");
//        try {
//            createQuestionPF.verifySuccessMessage();
//        } catch (NoSuchElementException | ElementNotVisibleException e) {
//            System.out.println(e.getMessage());
//            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
//            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
//            Assert.fail();
//        }
//    }
//
//    @And("Verify And Want To Create Custom Questions with Missing Required Fields")
//    public void WantToCreateQuestionWithMissingRequiredFields() throws InterruptedException {
//        TestRunner.startTest("Verify and Validate to Create Custom Questions with Missing Required Fields");
//        try {
//            createQuestionPF.testMissingRequiredFields();
//        } catch (NoSuchElementException | ElementNotVisibleException e) {
//            System.out.println(e.getMessage());
//            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
//            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
//            Assert.fail();
//        }
//    }
//
//    @And("Verify And Want To Create Custom Questions with Invalid Points")
//    public void WantToCreateQuestionWithInvalidPoints() throws InterruptedException{
//        TestRunner.startTest("Verify and Validate to Create Custom Questions with Invalid Points Input");
//        try {
//            createQuestionPF.testInvalidPointsInput();
//        } catch (NoSuchElementException | ElementNotVisibleException e) {
//            System.out.println(e.getMessage());
//            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
//            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
//            Assert.fail();
//        }
//    }
//
//    @And("Verify And Want To Create Custom Questions with Negative Points")
//    public void WantToCreateQuestionWithNegativePoints() throws InterruptedException{
//        TestRunner.startTest("Verify and Validate to Create Custom Questions with Negative Points Input");
//        try {
//            createQuestionPF.testNegativePointsInput();
//        } catch (NoSuchElementException | ElementNotVisibleException e) {
//            System.out.println(e.getMessage());
//            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
//            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
//            Assert.fail();
//        }
//    }
//
//    @And("Verify And Want To Create Custom Questions with Invalid File Upload For Question Drawing Type")
//    public void WantToCreateQuestionWithInvalidFileUploadForDrawingTypeQuestion() throws InterruptedException{
//        TestRunner.startTest("Verify and Validate to Create Custom Questions with Invalid File Upload For Question Drawing Type");
//        try {
//            createQuestionPF.testInvalidFileUploadForDrawingQuestion();
//        } catch (NoSuchElementException | ElementNotVisibleException e) {
//            System.out.println(e.getMessage());
//            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
//            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
//            Assert.fail();
//        }
//    }
//
//    @And("Enter Title And Try To Click On Navigation Step-II")
//    public void EnterTitleAndTryToClickOnNavigationStep_II() throws InterruptedException{
//        TestRunner.startTest("Enter Title And Try To Click On Navigation Step-II");
//        try {
//            createQuestionPF.ClickOnNavigationStepII();
//        } catch (NoSuchElementException | ElementNotVisibleException e) {
//            System.out.println(e.getMessage());
//            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
//            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
//            Assert.fail();
//        }
//    }
//
//    @And("Check Validate On Missing Fields and Click On Next Button")
//    public void CheckValidateOnMissingFieldsAndClickOnNextButton() throws InterruptedException{
//        TestRunner.startTest("Verify and Validate to Create Custom Questions with Missing Required Fields");
//        try {
//            createQuestionPF.testMissingFieldsAndClickOnNextButton();
//        } catch (NoSuchElementException | ElementNotVisibleException e) {
//            System.out.println(e.getMessage());
//            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
//            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
//            Assert.fail();
//        }
//    }
//
//    @And("Click on StepIII Without Selecting any Question Type")
//    public void ClickOnStepIIIWithoutSelectingAnyQuestionType() throws InterruptedException{
//        TestRunner.startTest("Click on StepIII Without Selecting any Question Type");
//        try {
//            createQuestionPF.ClickStepIIIWithoutSelectingAnyQuestionType();
//        } catch (NoSuchElementException | ElementNotVisibleException e) {
//            System.out.println(e.getMessage());
//            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
//            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
//            Assert.fail();
//        }
//    }
//
//
//    @And("Get Empty Field Message on Step III for standards")
//    public void GetEmptyFieldMessageOnStepIIIForStandards() throws InterruptedException{
//        TestRunner.startTest("Get Empty Field Message on Step III for standards");
//        try {
//            createQuestionPF.EmptyFiledMessageStepIII();
//        } catch (NoSuchElementException | ElementNotVisibleException e) {
//            System.out.println(e.getMessage());
//            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
//            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
//            Assert.fail();
//        }
//    }
//
//    @And("WithOut Select Standard CLick On Save Validate Message")
//    public void WithOutSelectStandardCLickOnSaveButton() throws InterruptedException{
//        TestRunner.startTest("WithOut Select Standard CLick On Save Validate Message");
//        try {
//            createQuestionPF.WithOutStandardClickSaveShowRequiredMessage();
//        } catch (NoSuchElementException | ElementNotVisibleException e) {
//            System.out.println(e.getMessage());
//            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
//            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
//            Assert.fail();
//        }
//    }
//
//    @And("WithOut Select Standard CLick On Save and Exit button")
//    public void WithOutSelectStandardCLickOnSaveAndExitButton() throws InterruptedException{
//        TestRunner.startTest("WithOut Select Standard CLick On Save and Exit button");
//        try {
//            createQuestionPF.WithOutStandardClickSaveAndExitShowRequiredMessage();
//        } catch (NoSuchElementException | ElementNotVisibleException e) {
//            System.out.println(e.getMessage());
//            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
//            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
//            Assert.fail();
//        }
//    }
//
//    @And("Move to StepI Question Information")
//    public void MoveToStepIQuestionInformation() throws InterruptedException{
//        TestRunner.startTest("Move to StepI Question Information");
//        try {
//            createQuestionPF.clickOnStepIFromNavBar();
//        } catch (NoSuchElementException | ElementNotVisibleException e) {
//            System.out.println(e.getMessage());
//            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
//            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
//            Assert.fail();
//        }
//    }
//
//    @And("Click On StepI To Validate That Previous Information Is Save At StepI")
//    public void ClickOnStepIToValidateThatPreviousInformationIsSaveAtStepI() throws InterruptedException{
//        TestRunner.startTest("Click On StepI To Validate That Previous Information Is Save At StepI");
//        try {
//            createQuestionPF.ValidateInformationIsSaveOnStepI();
//        } catch (NoSuchElementException | ElementNotVisibleException e) {
//            System.out.println(e.getMessage());
//            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
//            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
//            Assert.fail();
//        }
//        Thread.sleep(3000);
//    }
//
////    @And("CLick On NextButton on StepI")
////    public void CLickOnNextButtonOnStepI() throws InterruptedException{
////        TestRunner.startTest("CLick On NextButton on StepI");
////        try {
////            createQuestionPF.StepNextButton();
////        } catch (NoSuchElementException | ElementNotVisibleException e) {
////            System.out.println(e.getMessage());
////            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
////            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
////            Assert.fail();
////        }
////    }
////
////    @And("Validate that Information Is also Save On StepII")
////    public void ValidateThatInformationIsAlsoSaveOnStepII() throws InterruptedException{
////        TestRunner.startTest("Validate that Information Is also Save On StepII");
////        try {
////            createQuestionPF.ValidateInformationIsRetainedOnStepII();
////        } catch (NoSuchElementException | ElementNotVisibleException e) {
////            System.out.println(e.getMessage());
////            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
////            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
////            Assert.fail();
////        }
////        Thread.sleep(3000);
////    }
////
////    @And("Click Step-II Question Type from Step-III from Nav bar")
////    public void ClickStepIIQuestionTypeFromNavbar() throws InterruptedException{
////        TestRunner.startTest("Click Step-II Question Type from Nav bar");
////        try {
////            createQuestionPF.ClickOnNavigationStepIIFromStepIII();
////        } catch (NoSuchElementException | ElementNotVisibleException e) {
////            System.out.println(e.getMessage());
////            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
////            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
////            Assert.fail();
////        }
////    }
////
////    @And("Check, Validate Information is Retained on StepIII when we move from stepII to StepIII")
////    public void CheckValidateInformationIsRetainedOnStepIIIWhenWeMoveFromStepIIToStepIII() throws InterruptedException{
////        TestRunner.startTest("Check, Validate Information is Retained on StepIII when we move from stepII to StepIII");
////        try {
////            createQuestionPF.ValidateInformationIsRetainedOnStepIII();
////        } catch (NoSuchElementException | ElementNotVisibleException e) {
////            System.out.println(e.getMessage());
////            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
////            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
////            Assert.fail();
////        }
////    }
////
////    @And("Click on StepIII from StepI NavBar")
////    public void ClickOnStepIIIFromStepINavBar() throws InterruptedException{
////        TestRunner.startTest("Click on StepIII from StepI NavBa");
////        try {
////            createQuestionPF.ClickStepIIIFromNavBarStepI();
////        } catch (NoSuchElementException | ElementNotVisibleException e) {
////            System.out.println(e.getMessage());
////            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
////            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
////            Assert.fail();
////        }
////    }
////
////    // copy Question
////
////    @And("Select Class from dropdown")
////    public void SelectClassFromDropdown() throws InterruptedException{
////        TestRunner.startTest("Select Class From Dropdown");
////        try {
////            createQuestionPF.selectClassForQuestion();
////        } catch (NoSuchElementException | ElementNotVisibleException e) {
////            System.out.println(e.getMessage());
////            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
////            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
////            Assert.fail();
////        }
////    }
////
////    @And("Select Multiple Choice Question Type From GalloPade Tab")
////    public void SelectMultipleChoiceQuestionTypeFromGalloPadeTab() throws InterruptedException{
////        TestRunner.startTest("Select Multiple Choice Question Type From GalloPade Tab");
////        try {
////            createQuestionPF.SelectQuestionTypeGallopade();
////        } catch (NoSuchElementException | ElementNotVisibleException e) {
////            System.out.println(e.getMessage());
////            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
////            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
////            Assert.fail();
////        }
////    }
////
////    @And("Select specific Question that you want to preview")
////    public void SelectSpecificQuestionThatYouWantToPreview() throws InterruptedException{
////        TestRunner.startTest("Select specific Question that you want to preview");
////        try {
////            createQuestionPF.SelectSpecificQuestionAndPreviewThatQuestion();
////        } catch (NoSuchElementException | ElementNotVisibleException e) {
////            System.out.println(e.getMessage());
////            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
////            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
////            Assert.fail();
////        }
////    }
////
////    @And("Select Preview Option From Dropdown")
////    public void SelectPreviewOptionFromDropdown() throws InterruptedException{
////        TestRunner.startTest("Select Preview Option From Dropdown");
////        try {
////            createQuestionPF.selectPreviewOptionInTable();
////        } catch (NoSuchElementException | ElementNotVisibleException e) {
////            System.out.println(e.getMessage());
////            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
////            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
////            Assert.fail();
////        }
////    }
////
////    @And("Get The data of that Question that you are previewing")
////    public void GetDataOfThatSpecificQuestion() throws InterruptedException{
////        TestRunner.startTest("Get The data of that Question that you are previewing");
////        try {
////            createQuestionPF.GetDataOfThatQuestion();
////            Thread.sleep(2000);
////            createQuestionPF.ClickOnCrossButton();
////        } catch (NoSuchElementException | ElementNotVisibleException e) {
////            System.out.println(e.getMessage());
////            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
////            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
////            Assert.fail();
////        }
////    }
////
////    @And("Refresh the page")
////    public void RefreshPage() throws InterruptedException{
////        TestRunner.startTest("Refresh the page");
////        try {
////            createQuestionPF.PageRefresh();
////            Thread.sleep(2000);
////        } catch (NoSuchElementException | ElementNotVisibleException e) {
////            System.out.println(e.getMessage());
////            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
////            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
////            Assert.fail();
////        }
////    }
////
////    @And("Select Copy Option For the question that you want to copy")
////    public void SelectCopyOptionForTheQuestionThatYouWantToCopy() throws InterruptedException{
////        TestRunner.startTest("Select Copy Option For the question that you want to copy");
////        try {
////            createQuestionPF.ClickOnCopyOptionForQuestion();
////            Thread.sleep(2000);
////        } catch (NoSuchElementException | ElementNotVisibleException e) {
////            System.out.println(e.getMessage());
////            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
////            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
////            Assert.fail();
////        }
////    }
////
////    @And("Add Title for Copy Question in Copy Question Modal")
////    public void AddTitleForCopyQuestionInCopyQuestionModal() throws InterruptedException{
////        TestRunner.startTest("Add Title for Copy Question in Copy Question Modal");
////        try {
////            createQuestionPF.CopyResourcenModalBox();
////            Thread.sleep(2000);
////        } catch (NoSuchElementException | ElementNotVisibleException e) {
////            System.out.println(e.getMessage());
////            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
////            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
////            Assert.fail();
////        }
////    }
////
////    @And("Verify Image is also Copy when we Copy Question on StepII")
////    public void VerifyImageIsAlsoCopyWhenWeCopyQuestionOnStepII() throws InterruptedException{
////        TestRunner.startTest("Verify Image is also Copy when we Copy Question on StepII");
////        try {
////            createQuestionPF.VerifyCopyQuestionImageIsPresent();
////            Thread.sleep(2000);
////        } catch (NoSuchElementException | ElementNotVisibleException e) {
////            System.out.println(e.getMessage());
////            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
////            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
////            Assert.fail();
////        }
////    }
////
////    @And("Select Multiple Choice Question Type From Questions tab")
////    public void SelectMultipleChoiceQuestionTypeFromQuestionsTab() throws InterruptedException{
////        TestRunner.startTest("Select Multiple Choice Question Type From Questions tab");
////        try {
////            createQuestionPF.SelectQuestionTypeFromQuestionFiltersForCopyQuestion();
////            Thread.sleep(2000);
////        } catch (NoSuchElementException | ElementNotVisibleException e) {
////            System.out.println(e.getMessage());
////            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
////            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
////            Assert.fail();
////        }
////    }
////
////    @And("Search In My Content New Copy Question By Name")
////    public void SearchCopyQuestionByName() throws InterruptedException{
////        TestRunner.startTest("Search In My Content New Copy Question By Name");
////        try {
////            createQuestionPF.SearchCopyQuestionByName();
////            Thread.sleep(2000);
////        } catch (NoSuchElementException | ElementNotVisibleException e) {
////            System.out.println(e.getMessage());
////            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
////            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
////            Assert.fail();
////        }
////    }
////
////    @And("Verify In My Content Copy Custom Questions by Name Shows Into Table")
////    public void VerifyInMyContentCopyCustomQuestionsByNameShowsIntoTable() throws InterruptedException{
////        TestRunner.startTest("Verify In My Content Copy Custom Questions by Name Shows Into Table");
////        try {
////            createQuestionPF.verifySearchedCopyQuestionByNameIntoTable();
////            Thread.sleep(2000);
////        } catch (NoSuchElementException | ElementNotVisibleException e) {
////            System.out.println(e.getMessage());
////            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
////            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
////            Assert.fail();
////        }
////    }
//
//}
