package StepDefinitions.MyContentModule.Resources;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.MyContent.Resources.ResourcesPreDefinedStatus_PF;

import java.time.Duration;

public class ResourcesPreDefinedStatusSteps {

    WebDriver driver = Configurations.getDriver();
    Helper helper;
    Actions actions;

    ResourcesPreDefinedStatus_PF resourcesPreDefinedStatus_pf;

    public WebDriverWait wait;
    WebElement loader = driver.findElement(By.xpath("//span[@role='progressbar']"));


    public ResourcesPreDefinedStatusSteps(){
        helper = new Helper();
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
        actions = new Actions(driver);
        resourcesPreDefinedStatus_pf = new ResourcesPreDefinedStatus_PF(driver);

    }

    @And("Verify In My Content Resources Shows Into Table")
    public void verifyQuestionsShowsIntoTable() throws InterruptedException {
        TestRunner.startTest("Verify Resources Shows Into Table");
        try {
            resourcesPreDefinedStatus_pf.showsResourcesIntoTable();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed    :   Exception is found. Resources not Shows Into Table");
            Assert.fail();
        }
    }

    @And("Select Resources Status Filter On Resources")
    public void SelectResourcesStatusFilterOnResources() throws InterruptedException{
        TestRunner.startTest("Select Resources Status Filter On Resources");
        try {
            resourcesPreDefinedStatus_pf.filterResourcesByStatus();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed    :   Exception is found. Custom Filter On Question Type not found");
            Assert.fail();
        }

    }
}
