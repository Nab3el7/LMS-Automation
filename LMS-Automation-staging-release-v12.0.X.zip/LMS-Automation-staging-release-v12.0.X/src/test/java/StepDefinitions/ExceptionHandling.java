package StepDefinitions;

public class ExceptionHandling {
    public static ExceptionHandling exception = new ExceptionHandling();

    public static ExceptionHandling getInstance() {
        return exception;
    }


    public void printException(Exception e) {

        String exceptionName = e.getClass().getCanonicalName();             // getting exception name

        /* In this if else condition i'll check which exception is through and print that print the exception message */
        if (exceptionName.contains("NoSuchElementException")) {
            System.out.println("No such element found : : Exception found");                    // print which exception is found
            System.out.println(e);                                          // print the whole exception as well so that I can get more data
        } else if (exceptionName.contains("ElementNotVisibleException")) {
            System.out.println("Element Not Visible Exception : Exception found");                    // print which exception is found
            System.out.println(e);                                          // print the whole exception as well so that I can get more data
        } else if (exceptionName.contains("ElementNotSelectableException")) {
            System.out.println("Element Not Selectable Exception : Exception found");                    // print which exception is found
            System.out.println(e);                                          // print the whole exception as well so that I can get more data
        } else if (exceptionName.contains("ElementNotInteractableException")) {
            System.out.println("Element Not Interactable Exception : Exception found");                    // print which exception is found
            System.out.println(e);                                          // print the whole exception as well so that I can get more data
        } else if (exceptionName.contains("TimeoutException")) {
            System.out.println("Element Not find out while explicit wait : Exception found");                    // print which exception is found
            System.out.println(e);                                          // print the whole exception as well so that I can get more data
        } else {
            System.out.println("No exception found");
            System.out.println(e);
        }
    }
}
