package StepDefinitions.UserUsageReport;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.asserts.SoftAssert;
import pageFactory.Gradebook.AssignmentVerification_PF;
import pageFactory.IndividualAssignmentReport.IndividualAssignmentReport_PF;
import pageFactory.StudentProgressReport.StudentProgressReport_PF;
import pageFactory.UserUsageReport.UserUsageReport_PF;

import java.time.Duration;

public class UserUsageReportSteps {

    WebDriver driver = Configurations.getDriver();
    Helper helper;
    Actions actions;

    UserUsageReport_PF userUsageReport_pf;
    SoftAssert softAssert = new SoftAssert();

    public WebDriverWait wait;
    WebElement loader = driver.findElement(By.xpath("//span[@role='progressbar']"));


    public UserUsageReportSteps(){
        helper = new Helper();
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
        actions = new Actions(driver);
        userUsageReport_pf = new UserUsageReport_PF(driver, softAssert);

    }

    @And("Validate and Click on User Usage Report From Favorite Reports")
    public void ValidateAndClickOnUserUsageReportFromFavoriteReports() throws InterruptedException {
        TestRunner.startTest("Validate and Click on User Usage Report From Favorite Reports");
        try {
            userUsageReport_pf.VerifyAndClickOnUserUsageReport();

        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            softAssert.fail();
        }

    }

    @And("Validate and Check Breadcrumb on User Usage Report")
    public void ValidateAndCheckBreadcrumbOnUserUsageReport() throws InterruptedException {
        TestRunner.startTest("Validate and Check Breadcrumb on User Usage Report");

        try {
            userUsageReport_pf.verifyBreadcrumbOnUserUsageReport();

        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            softAssert.fail();
        }
    }

    @And("Validate Metrics Text and Presence of Print Button On Right Side Usage Report")
    public void ValidateMetricsTextAndPresenceOfPrintButtonOnRightSideUsageReport() throws InterruptedException{
        TestRunner.startTest("Validate Metrics Text and Presence of Print Button On Right Side Usage Report");

        try {
            userUsageReport_pf.verifyMetricsTextAndPrintButtonPresence();

        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            softAssert.fail();
        }
    }

    @And("Validate High Level Stats and Its Four Cards")
    public void ValidateHighLevelStatsAndItsFourCards() throws InterruptedException {
        TestRunner.startTest("Validate High Level Stats and Its Four Cards");

        try {
            userUsageReport_pf.verifyHighLevelStatsCards();

        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            softAssert.fail();
        }
    }
    @And("Validate Usage Table and Its Data Rows")
    public void ValidateUsageTableAndItsDataRows() throws InterruptedException {
        TestRunner.startTest("Validate Usage Table and Its Data Rows");

        try {
            userUsageReport_pf.verifyUsageTableData();

        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            softAssert.fail();
        }
    }
    @And("Validate Individual Users I Icon Info Dialog Content")
    public void ValidateIndividualUsersInfoDialogContent() throws InterruptedException {
        TestRunner.startTest("Validate Individual Users I Icon Info Dialog Content");
        try {
            userUsageReport_pf.verifyIndividualUsersInfoDialog();

        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            softAssert.fail();
        }
    }

    @And("Validate Total Logins I Icon Info Dialog Content")
    public void ValidateTotalLoginsIIconInfoDialogContent() throws InterruptedException {
        TestRunner.startTest("Validate Total Logins I Icon Info Dialog Content");

        try {
            userUsageReport_pf.verifyTotalLoginInfoDialog();

        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            softAssert.fail();
        }
    }

    @And("Validate and Select All Classes From Select Class Dropdown From Filters")
    public void ValidateAndSelectAllClassesFromSelectClassDropdownFromFilters() throws InterruptedException {
        TestRunner.startTest("Validate and Select All Classes From Select Class Dropdown From Filters");

        try {
            userUsageReport_pf.selectAllClassesFromClassDropdown();

        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            softAssert.fail();
        }
    }

    @And("Validate and Select Teacher Checkbox From Course Views")
    public void ValidateAndSelectTeacherSelfCheckboxFromCourseViews() throws InterruptedException {
        TestRunner.startTest("Validate and Select Teacher(Self) Checkbox From Course Views");

        try {
            userUsageReport_pf.selectTeacherCheckBoxFromCoursesViews();

        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            softAssert.fail();
        }
    }

    @And("Validate and Click On Run Report Option")
    public void ValidateAndClickOnRunReportOption() throws InterruptedException {
        TestRunner.startTest("Validate and Click On Run Report Option ");

        try {
            userUsageReport_pf.clickRunReportButton();

        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            softAssert.fail();
        }
    }

    @And("Validate Data is Populated on Right side After Filter Apply")
    public void ValidateDataIsPopulatedOnRightSideAfterFilterApply() throws InterruptedException {
        TestRunner.startTest("Validate Data is Populated on Right side After Filter Apply");

        try {
            userUsageReport_pf.verifyDataPopulation();

        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            softAssert.fail();
        }
    }

    @And("Validate and Select Specific Class From Select Class Dropdown")
    public void ValidateAndSelectSpecificClassFromSelectClassDropdown() throws InterruptedException {
        TestRunner.startTest("Validate and Select Specific Class From Select Class Dropdown");

        try {
            userUsageReport_pf.selectSpecificClassFromClassDropdown();

        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            softAssert.fail();
        }
    }

    @And("Validate And Select All Students From Select Student Dropdown")
    public void ValidateAndSelectAllStudentFromSelectStudentDropdown() throws InterruptedException {
        TestRunner.startTest("Validate And Select All Students From Select Student Dropdown");

        try {
            userUsageReport_pf.selectAllStudentsFromStudentDropdown();

        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            softAssert.fail();
        }
    }

    @And("Validate and Select Specific Student From Select Student Dropdown")
    public void ValidateAndSelectSpecificStudentFromSelectStudentDropdown() throws InterruptedException {
        TestRunner.startTest("Validate and Select Specific Student From Select Student Dropdown");

        try {
            userUsageReport_pf.selectSpecificStudentFromStudentDropdown();

        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            softAssert.fail();
        }
    }

    @And("Validate And Select Logins Individual Users Using All Individual User, Teacher and Student Checkbox")
    public void ValidateAndSelectLoginsIndividualUsersUsingAllIndividualUserTeacherAndStudentCheckbox() throws InterruptedException {
        TestRunner.startTest("Validate And Select Logins Individual Users Using All Individual User, Teacher and Student Checkbox");
        try {
            userUsageReport_pf.SelectLoginsIndividualUsersCheckbox();

        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            softAssert.fail();
        }
    }

    @And("Validate and Select Total Logins Using All Logins, Teacher Self, and Students Checkbox")
    public void ValidateAndSelectTotalLoginsUsingAllLoginsTeacherSelfAndStudentsCheckbox() throws InterruptedException {
        TestRunner.startTest("Validate and Select Total Logins Using All Logins, Teacher Self, and Students Checkbox");

        try {
            userUsageReport_pf.SelectTotalLoginsCheckbox();


        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            softAssert.fail();
        }
    }

    @And("Validate and Select Assignments Using Cumulative Checkboxes")
    public void ValidateAndSelectAssignmentsUsingCumulativeCheckboxes() throws InterruptedException {
        TestRunner.startTest("Validate and Select Assignments Using Cumulative Checkboxes");

        try {
            userUsageReport_pf.SelectAssignmentsCheckbox();


        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            softAssert.fail();
        }

    }

    @And("Validate and Select Specific Student From User Usage Report")
    public void ValidateAndSelectSpecificStudentFromUserUsageReport() throws InterruptedException {
        TestRunner.startTest("Validate and Select Specific Student From User Usage Report");

        try {
            userUsageReport_pf.selectSpecificStudent();

        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            softAssert.fail();
        }
    }

    @And("Validate and Check Total Login with All Logins, Students and Teachers checkbox without course view checkbox")
    public void ValidateAndCheckTotalLoginWithAllLoginsStudentsAndTeachersCheckboxWithoutCourseViewCheckbox() throws InterruptedException {
        TestRunner.startTest("Validate and Check Total Login with All Logins, Students and Teachers checkbox without course view checkbox");

        try {
            userUsageReport_pf.SelectTotalLoginsCheckboxWithoutCoursesViewCheckbox();


        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            softAssert.fail();
        }
    }

    @And("Validate and Clear Select Student From Select Student Dropdown")
    public void ValidateAndClearSelectStudentFromSelectStudentDropdown() throws InterruptedException {
        TestRunner.startTest("Validate and Clear Select Student From Select Student Dropdown");

        try {
            userUsageReport_pf.clearSelectStudentDropdown();


        }  catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            softAssert.fail();
        }
    }

    @And("Validate and Check Logins: Individual Users with All Individual Users, Students and Teachers checkbox without course view checkbox")
    public void ValidateAndCheckLoginsIndividualUsersWithAllIndividualUsersStudentsAndTeachersCheckboxWithoutCourseViewCheckbox() throws InterruptedException{
        TestRunner.startTest("Validate and Check Logins: Individual Users with All Individual Users, Students and Teachers checkbox without course view checkbox");

        try {
            userUsageReport_pf.checkLoginsIndividualUsersWithoutCourseView();

            softAssert.assertAll();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            softAssert.fail();
        }
    }

    @And("Validate Export Functionality for both Excel and CSV formats")
    public void ValidateExportFunctionalityForBothExcelAndCSVFormats() throws InterruptedException {
        TestRunner.startTest("Validate Export Functionality for both Excel and CSV formats");

        try {
            userUsageReport_pf.validateExportFunctionalityWithMultipleFormats();

        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            softAssert.fail();
        }
    }

    @And("Validate and Click Print Option on User Report")
    public void ValidateAndClickPrintOptionOnUserReport() throws InterruptedException {
        TestRunner.startTest("Validate and Click Print Option on User Report");

        try {
            userUsageReport_pf.printUsageReport();

        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            softAssert.fail();
        }
        Thread.sleep(2000);
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.print = function(){};");
        driver.navigate().refresh();

    }

}

