package StepDefinitions.GradebookModule;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.MyContentModule.AssignAssessmentSteps;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import io.cucumber.java.sl.In;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Gradebook.ManualGrading_PF;

import java.time.Duration;
import java.util.List;
import java.util.Random;

public class ManualGradingSteps extends Configurations {
    // Lazy initialization - get driver only when needed
    private WebDriver driver;
    private WebDriverWait wait;
    private WebElement loader;

    ManualGrading_PF manualGradingPF;
    Helper helper;

    // Lazy getters - initialize only when accessed
    private WebDriver getWebDriver() {
        if (driver == null) {
            driver = Configurations.getDriver();
        }
        return driver;
    }

    private WebDriverWait getWebDriverWait() {
        if (wait == null) {
            wait = new WebDriverWait(getWebDriver(), Duration.ofSeconds(60));
        }
        return wait;
    }

    private WebElement getLoader() {
        if (loader == null) {
            loader = getWebDriver().findElement(By.xpath("//span[@role='progressbar']"));
        }
        return loader;
    }

    public ManualGradingSteps(){
        // Helper doesn't need driver immediately - it uses lazy initialization
        helper = new Helper();
        // Page objects will be initialized when driver is first accessed
    }

    // Initialize page objects when driver is first used
    private void ensurePageObjectsInitialized() {
        if (manualGradingPF == null) {
            manualGradingPF = new ManualGrading_PF(getWebDriver());
        }
    }

    @And("Verify Side Navbar And Clicked on GradeBook")
    public void VerifySideNavBarAndClickOnGradeBook() throws InterruptedException {
        ensurePageObjectsInitialized();
        TestRunner.startTest("Verify Side Navbar And Clicked on GradeBook");
        try {
            getWebDriverWait().until(ExpectedConditions.invisibilityOf(getLoader()));
            manualGradingPF.SideNavBarAndClickOnGradeBook();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
            Assert.fail();
        }

    }

    @And("Verify GradeBook Dashboard")
    public void VerifyGradeBookDashboard() throws InterruptedException {
        ensurePageObjectsInitialized();
        TestRunner.startTest("Verify the GradeBook dashboard");
        try {
            getWebDriverWait().until(ExpectedConditions.invisibilityOf(getLoader()));
            manualGradingPF.GradeBookDashboard();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("Verify GradeBook Students List")
    public void VerifyGradeBookStudentsList() throws InterruptedException {
        ensurePageObjectsInitialized();
        TestRunner.startTest("Verify the get GradeBook students list and print");
        try {
            manualGradingPF.printStudentNames();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("Verify And Get Student Assignment Table")
    public void VerifyStudentsAssignmentTable() throws InterruptedException {
        ensurePageObjectsInitialized();
        TestRunner.startTest("Verify the get students assignment table and print");

        try {
            getWebDriverWait().until(ExpectedConditions.invisibilityOf(getLoader()));
            manualGradingPF.clickCollapseButtons();
            System.out.println("Test Case Passed    :   GradeBook students assignment table shows successfully");
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("Verify And Select Student Assignment Into Table")
    public void SelectStudentsAssignmentIntoTable() throws InterruptedException {
        ensurePageObjectsInitialized();
        TestRunner.startTest("Select the student assignment into table and print ");
        try {
            getWebDriverWait().until(ExpectedConditions.invisibilityOf(getLoader()));
            manualGradingPF.selectRandomQuiz();
            System.out.println("Test Case Passed    :   GradeBook students assignment table shows successfully");
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
            Assert.fail();
        }
        Thread.sleep(3000);
    }

//    Manual Grading on Summary Tab

    @And("Click On Summary Tab In GradeBook Assignment")
    public void ClickOnSummaryTabGradeBookAssignment() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Click on Summary tab in GradeBook assignment ");
        try {
            getWebDriverWait().until(ExpectedConditions.invisibilityOf(getLoader()));
            manualGradingPF.ClickOnSummaryTab();
            System.out.println("Test Case Passed    :   Click on Summary Tab successfully");
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
            Assert.fail();
        }
        Thread.sleep(3000);
    }

    @And("Enter The Score And Select The CheckBox")
    public void AssignmentSummaryScoreAndCheckBox() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Enter score into inputs and select the checkbox ");
        try {
            getWebDriverWait().until(ExpectedConditions.invisibilityOf(getLoader()));
            manualGradingPF.EnterSummaryScoreAndSelectTheCheckBox();
            System.out.println("Test Case Passed    :   Summary score and select the checkbox successfully");
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
            Assert.fail();
        }
        Thread.sleep(1000);
    }
    @And("Get And Validate The Assignment Summary")
    public void clickOnStudentCheckBox() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Get and validate the assignment summary ");
        try {
            manualGradingPF.AssignmentScoresSummary();
            System.out.println("Test Case Passed    :   Get and validate the assignment summary successfully");
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
            Assert.fail();
        }
        Thread.sleep(1000);
    }

//    Manual Grading on Grading Tab

    @And("Click On Grading Tab In GradeBook Assignment")
    public void ClickOnGradingTabGradeBookAssignment() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Click on Grading tab in GradeBook assignment ");
        try {
            getWebDriverWait().until(ExpectedConditions.invisibilityOf(getLoader()));
            manualGradingPF.ClickOnGradingTab();
            System.out.println("Test Case Passed    :   Click on Grading Tab successfully");
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }
    @And("Verify The Grading All Submitted Questions Scored Or Not")
    public void VerifyGradingText() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Get and validate the all submitted questions have been scored or not ");
        try {
            manualGradingPF.VerifyGradingScreen();
            System.out.println("Test Case Passed    :   Get Grading text successfully");
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("Uncheck The Grading CheckBox In Summary Tab")
    public void UncheckTheGradingCheckBox() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Click on grading checkbox to unselect");

        try {
            getWebDriverWait().until(ExpectedConditions.invisibilityOf(getLoader()));
            manualGradingPF.AssignmentSummaryCheckBoxOnSummaryTab();
            System.out.println("Test Case Passed    :   Grading checkbox unselect successfully");
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("Update The Student Points And Add Comments")
    public void UpdateStudentPointsAndComments() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Click on the student points and add comments");

        try {
            getWebDriverWait().until(ExpectedConditions.invisibilityOf(getLoader()));
            manualGradingPF.updateStudentPointsAndComments();
            System.out.println("Test Case Passed    :   Update the student points and comments successfully");
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }


//    Manual Grading on Selected Student Tab

    @And("Click On Selected Student Tab In GradeBook Assignment")
    public void ClickOnSelectedStudentTabGradeBookAssignment() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Click on Selected Student tab in GradeBook assignment ");

        try {
            getWebDriverWait().until(ExpectedConditions.invisibilityOf(getLoader()));
            manualGradingPF.ClickOnSelectedStudentTab();
            System.out.println("Test Case Passed    :   Click on Selected Student Tab successfully");
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("Uncheck The Mark As Graded CheckBox In Selected Student Tab")
    public void UncheckTheMarkAsGradedCheckBox() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Click on mark as graded checkbox to unselect");
        try {
            manualGradingPF.CLickOnMarkAsGraded();
            System.out.println("Test Case Passed    :   Mark As Graded checkbox unselect successfully");
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

}