package StepDefinitions.GradebookModule;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Gradebook.GradeBookStudent_PF;


import java.time.Duration;

//import static StepDefinitions.Configurations.driver;

public class GradeBookStudentSteps extends Configurations {
    WebDriver driver = Configurations.getDriver();
    Helper helper;
    GradeBookStudent_PF gradeBookStudent_pf;

    Actions actions;

    public WebDriverWait wait;
    WebElement loader = driver.findElement(By.xpath("//span[@role='progressbar']"));


    public GradeBookStudentSteps(){
        helper = new Helper();
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
        actions = new Actions(driver);
        gradeBookStudent_pf = new GradeBookStudent_PF(driver);
    }

    @And("Verify GradeBook Students List and search Student")
    public void VerifyGradeBookStudentsListSearchStudent() throws InterruptedException{
        TestRunner.startTest( "Verify GradeBook Students List and search Student ");
        try {
            gradeBookStudent_pf.GetStudentListAndClickIcon();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Student not found in List ");
            Assert.fail();
        }

    }

    @And("Verify GradeBook Student and search Student and Click on I icon")
    public void VerifyGradeBookStudentSearchStudent() throws InterruptedException{
        TestRunner.startTest( "Verify GradeBook Student and search Student and Click on I icon");
        try {
            gradeBookStudent_pf.GetStudentFromGradeBookAndClickIcon();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Student not found in List ");
            Assert.fail();
        }
    }


    @And("Verify Student Information Dialogue box")
    public void ClickIcon() throws InterruptedException{
        TestRunner.startTest( "Verify Student Information Dialogue box");
        try {
            gradeBookStudent_pf.StudentInfoDialogueBox();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed :  Student Information Dialogue box not found");
            Assert.fail();
        }
    }

    @And("Enter the Student Password in Dialogue Box")
    public void PasswordInDialogueBox() throws InterruptedException{
        TestRunner.startTest( "Enter the Student Password in Dialogue Box");
        try {
            gradeBookStudent_pf.EnterPassword();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed :  Password Field not Found ");
            Assert.fail();
        }
    }

    @And("Enter Confirm Password in Dialogue Box")
    public void ConfirmPasswordDialogueBox() throws InterruptedException{
        TestRunner.startTest( "Enter Confirm Password in Dialogue Box ");
        try {
            gradeBookStudent_pf.EnterConfirmPassword();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed :  Confirm Password Field not Found ");
            Assert.fail();
        }
    }

    @And("Check and Validate Update button on Student Information Dialogue Box")
    public void updateButtonOnStdDialogueBox() throws InterruptedException{
        TestRunner.startTest( "Check and Validate Update button on Student Information Dialogue Box");
        try {
            gradeBookStudent_pf.updateBtnStdDialogueBox();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Update Button not Found");
            Assert.fail();
        }
    }
    @And("Check and Validate After Edit Student Update button on Student Information Dialogue Box")
    public void Edit_updateButtonOnStdDialogueBox() throws InterruptedException{
        TestRunner.startTest( "Check and Validate Update button on Student Information Dialogue Box");
        try {
            gradeBookStudent_pf.GetStudentListAndClickIcon();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Update Button not Found");
            Assert.fail();
        }
    }

    @And("Click and Validate View Full Details Button")
    public void ValidateViewFullDetailsButton() throws InterruptedException{
        TestRunner.startTest( "Click and Validate View Full Details Button");
        try {
            gradeBookStudent_pf.ViewFullDetailButton();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : View Full Detail Button not found");
            Assert.fail();
        }
    }

    @And("Edit Select Grade")
    public void EditSelectGrade() throws InterruptedException{
        TestRunner.startTest( "Edit Select Grade");
        try {
            gradeBookStudent_pf.EditGrdaesOption();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Edit Select Grade");
            Assert.fail();
        }
    }

    @And("Check and Validate Update button on Profile Screen")
    public void ValidateUpdateButton() throws InterruptedException{
        TestRunner.startTest( "Check and Validate Update button on Profile Screen");
        try {
            gradeBookStudent_pf.ClickUpdateButton();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Update Button is not Display");
            Assert.fail();
        }
    }

    @And("Click on Cancel button on Profile Screen")
    public void ValidateCancelButton() throws InterruptedException{
        TestRunner.startTest( "Click on Cancel button on Profile Screen");
        try {
            gradeBookStudent_pf.CancelButtonCLicked();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Cancel Button not found");
            Assert.fail();
        }
        actions.sendKeys(Keys.ESCAPE).build().perform();
    }

    @And("Verify that student Grade Change on student Information Modal after editing")
    public void VerificationOfEditedInformation() throws InterruptedException{
        TestRunner.startTest( "Verify that student Grade Change on student Information Modal after editing");
        try {
            gradeBookStudent_pf.VerifyEditInfo();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Grade not change at student Information Modal in GradeBook ");
            Assert.fail();
        }
        actions.sendKeys(Keys.ESCAPE).build().perform();
    }
}
