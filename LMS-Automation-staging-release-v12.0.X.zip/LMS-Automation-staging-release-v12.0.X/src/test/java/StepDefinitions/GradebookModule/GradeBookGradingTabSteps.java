package StepDefinitions.GradebookModule;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Assignmment.CorrectAnswerExecutor_PF;
import pageFactory.Gradebook.GradeBookGradingTab_PF;
import pageFactory.Gradebook.SelectedStudent_PF;

import java.time.Duration;

//import static StepDefinitions.Configurations.driver;

public class GradeBookGradingTabSteps extends Configurations {
    WebDriver driver = Configurations.getDriver();
    Helper helper;
    Actions actions;
    public WebDriverWait wait;

    WebElement loader = driver.findElement(By.xpath("//span[@role='progressbar']"));

    SelectedStudent_PF selectedStudent_pf;
    GradeBookGradingTab_PF  gradeBookGradingTab_pf;

    public GradeBookGradingTabSteps() {
        helper = new Helper();
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
        actions = new Actions(driver);
        selectedStudent_pf = new SelectedStudent_PF(driver);
        gradeBookGradingTab_pf = new GradeBookGradingTab_PF(driver);
    }
    @And("Click And verify Grading Tab In GradeBook")
    public void ClickAndVerifyGradingTabInGradeBook() throws InterruptedException{
        TestRunner.startTest("Click And verify Grading Tab In GradeBook");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            gradeBookGradingTab_pf.clickGradingTab();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found. Grading Tab not clicked.");
            Assert.fail();
        }
        Thread.sleep(3000);
    }

    @And("Check, Verify and Open Assignment From Summary Button GradeBook")
    public void CheckVerifyAndOpenAssignmentFromSummaryButtonGradeBook() throws InterruptedException{
        TestRunner.startTest("Check, Verify and Open Assignment From Summary Button GradeBook");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            String assignmentNameForCorrect = CorrectAnswerExecutor_PF.assignmentNameForCorrect.get();
            System.out.println("Want to open attempted assignment: " + assignmentNameForCorrect);
            TestRunner.getTest().log(Status.INFO, "Want to open attempted assignment: " + assignmentNameForCorrect);
            gradeBookGradingTab_pf.searchAssignmentNamesForSummary(assignmentNameForCorrect);
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found.");
            Assert.fail();
        }
        Thread.sleep(3000);
    }

    @And("Verify And Add New Student Point for VQ")
    public void VerifyAndAddNewStudentPointForVQ() throws InterruptedException{
        TestRunner.startTest("Verify And Add New Student Point for VQ");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            gradeBookGradingTab_pf.VerifyWeightAddStdPoints();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found.");
            Assert.fail();
        }
        Thread.sleep(3000);
    }

    @And("Verify, Check that Overall Score Are In selected Student tab And From Student Side Are Same")
    public void VerifyCheckThatOverallScoreAreInSelectedStudentTabAndFromStudentSideAreSame() throws InterruptedException{
        TestRunner.startTest("Verify, Check that Overall Score Are In selected Student tab And From Student Side Are Same");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            gradeBookGradingTab_pf.VerifyOverAllScore();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found.");
            Assert.fail();
        }
//        Thread.sleep(3000);
    }
}
