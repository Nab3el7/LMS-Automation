package StepDefinitions.GradebookModule;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import io.cucumber.java.en.And;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Gradebook.GradingUpdateAssignment_PF;

import java.time.Duration;

public class GradingUpdateAssignmentSteps extends Configurations {
    WebDriver driver = Configurations.getDriver();

    GradingUpdateAssignment_PF gradingUpdateAssignmentPF;
    public WebDriverWait wait;
    Helper helper;
    WebElement loader = driver.findElement(By.xpath("//span[@role='progressbar']"));

    public GradingUpdateAssignmentSteps(){
        gradingUpdateAssignmentPF = new GradingUpdateAssignment_PF(driver);
        helper = new Helper();
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
    }


    @And("Go to URL")
    public void GoToURL() throws InterruptedException{
        Thread.sleep(3000);
        gradingUpdateAssignmentPF.gotoURL();
    }

    @And("Click to Edit Student")
    public void ClickTOEditStudent() throws InterruptedException{
        Thread.sleep(3000);
        gradingUpdateAssignmentPF.EditStudent();
    }

    @And("Click to Edit Assignment")
    public void ClickTOEditAssignment() throws InterruptedException{
        Thread.sleep(3000);
        gradingUpdateAssignmentPF.ApplyDateOnAssignment();
    }

    @And("Get Edited Assignment Name")
    public void GetEditedAssignmentName() throws InterruptedException{
        Thread.sleep(3000);
        gradingUpdateAssignmentPF.getAssignmentName();
    }

    @And("Search Assignment Name")
    public void SearchAssignmentName() throws InterruptedException{
        Thread.sleep(3000);
        gradingUpdateAssignmentPF.searchAssignmentIntoPanel();
    }

    @And("Go to View URL")
    public void GoToViewURL() throws InterruptedException{
        Thread.sleep(2000);
        gradingUpdateAssignmentPF.gotoViewURL();
    }

    @And("Search Assignment By Date Time Into Teacher Panel")
    public void SearchAssignmentByDateTime() throws InterruptedException{
        Thread.sleep(3000);
        gradingUpdateAssignmentPF.verifyAssignmentViewIntoTeacher();
    }
}
