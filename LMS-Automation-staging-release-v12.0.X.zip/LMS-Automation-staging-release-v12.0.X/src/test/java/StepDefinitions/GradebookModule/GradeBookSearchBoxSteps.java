package StepDefinitions.GradebookModule;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Assignmment.CorrectAnswerExecutor_PF;
import pageFactory.Gradebook.GradeBookSearchBox_PF;
import pageFactory.Gradebook.GradeBookStudent_PF;

import java.time.Duration;

import static pageFactory.Assignmment.InCorrectAnswerExecutor_PF.AssignmentNameForInCorrect;

public class GradeBookSearchBoxSteps extends Configurations{
    WebDriver driver = Configurations.getDriver();

    Helper helper;
    GradeBookStudent_PF gradeBookStudent_pf;
    GradeBookSearchBox_PF gradeBookSearchBox_pf;

    Actions actions;

    public WebDriverWait wait;
    WebElement loader = driver.findElement(By.xpath("//span[@role='progressbar']"));

    public static String AssignmentNameforSearch = "Automation-Assessment-Correct";


    public GradeBookSearchBoxSteps(){
        helper = new Helper();
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
        actions = new Actions(driver);
        gradeBookStudent_pf = new GradeBookStudent_PF(driver);
        gradeBookSearchBox_pf = new GradeBookSearchBox_PF(driver);
    }
    

    @And("Check and Verify Search Assessment in Search Box on GradeBook")
    public void SearchBoxGradeBook() throws InterruptedException{
            TestRunner.startTest("  Check and Verify Search Assessment in Search Box on GradeBook**********");
            try {
                Thread.sleep(5000);
                String assignmentNameForCorrect = CorrectAnswerExecutor_PF.assignmentNameForCorrect.get();
                System.out.println("Want to search assignment: " + assignmentNameForCorrect);
                TestRunner.getTest().log(Status.INFO, "Want to search assignment: " + assignmentNameForCorrect);
                gradeBookSearchBox_pf.SearchAssessmentByKeyword(assignmentNameForCorrect);
            } catch (NoSuchElementException | ElementNotInteractableException e) {
                System.out.println(e);
                System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
                TestRunner.getTest().log(Status.FAIL, "  Test Case Failed    :   Search Box not display **********");
                Assert.fail();
            }
            Thread.sleep(3000);
    }

    @And("Check, Verify and Open assignment that Attempted for Searching")
    public void check_and_verify_AttemptedCorrect_assignment_is_present() throws InterruptedException {
        TestRunner.startTest("  Select Assignment  **********");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            gradeBookSearchBox_pf.searchAssignmentNames(AssignmentNameforSearch);
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "   :   Assignment not search and found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Check and Verify Search Assessment in Search Box on GradeBook for Incorrect")
    public void SearchBoxGradeBookForIncorrect() throws InterruptedException{
        TestRunner.startTest("  Check and Verify Search Assessment in Search Box on GradeBook for Incorrect **********");
        try {
            Thread.sleep(5000);
            gradeBookSearchBox_pf.SearchAssessmentByKeyword(AssignmentNameForInCorrect);
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "  Test Case Failed    :   Search Box not display for Incorrect **********");
            Assert.fail();
        }
        Thread.sleep(3000);
    }

}
