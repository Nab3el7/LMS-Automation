package StepDefinitions.GradebookModule;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.MyContentModule.AssignAssessmentSteps;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Gradebook.GradingUnSubmitAssignment_PF;

import java.time.Duration;

public class GradingUnSubmitAssignmentSteps extends Configurations {
    WebDriver driver = Configurations.getDriver();

    GradingUnSubmitAssignment_PF gradingUnSubmitAssignmentPF;
    public WebDriverWait wait;
    Helper helper;
    

    WebElement loader = driver.findElement(By.xpath("//span[@role='progressbar']"));

    public GradingUnSubmitAssignmentSteps(){
        gradingUnSubmitAssignmentPF = new GradingUnSubmitAssignment_PF(driver);
        helper = new Helper();
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
    }

    @And("Verify And Select Student Assignment For UnSubmit Into Table")
    public void SelectStudentsAssignmentIntoTable() throws InterruptedException {
        TestRunner.startTest(" Select the student assignment for unsubmit into table and print **********");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            gradingUnSubmitAssignmentPF.selectQuizForUnSubmit();
            TestRunner.getTest().log(Status.FAIL, "Test Case Passed    :   UnSubmit students assignment table clicked successfully");
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            TestRunner.getTest().log(Status.FAIL, "Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
            Assert.fail();
        }
        helper.takeScreenshot(driver , Thread.currentThread().getStackTrace()[1].getMethodName());
    }

    @And("Verify UnSubmit Prompt Is Displayed")
    public void VerifyUnSubmitPrompt() throws InterruptedException {
        TestRunner.startTest(" Verify unSubmit prompt is displayed or not  **********");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            gradingUnSubmitAssignmentPF.verifyPrompt();
            TestRunner.getTest().log(Status.FAIL, "Test Case Passed    :   UnSubmit prompt displayed successfully");
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            TestRunner.getTest().log(Status.FAIL, "Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
            Assert.fail();
        }
        Thread.sleep(3000);
        helper.takeScreenshot(driver , Thread.currentThread().getStackTrace()[1].getMethodName());
    }

    @And("Verify And Get UnSubmit Assignment Name")
    public void VerifyUnSubmitAssignmentName() throws InterruptedException {
        TestRunner.startTest(" Verify and get unsubmit assignment name  **********");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            gradingUnSubmitAssignmentPF.getAssignmentName();
            TestRunner.getTest().log(Status.FAIL, "Test Case Passed    :   UnSubmit assignment displayed successfully");
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            TestRunner.getTest().log(Status.FAIL, "Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
            Assert.fail();
        }
        Thread.sleep(3000);
        helper.takeScreenshot(driver , Thread.currentThread().getStackTrace()[1].getMethodName());
    }

    @And("UnSubmit The Assignment Of A Particular Student")
    public void VerifyUnSubmitAssignmentOfParticularStudent() throws InterruptedException {
        TestRunner.startTest(" Verify unSubmit of a particular student  **********");
        try {
            gradingUnSubmitAssignmentPF.UnSubmitAssignmentForParticularStudent();
            TestRunner.getTest().log(Status.FAIL, "Test Case Passed    :   UnSubmit assignment of a particular student successfully");
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            TestRunner.getTest().log(Status.FAIL, "Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
            Assert.fail();
        }
        Thread.sleep(3000);
        helper.takeScreenshot(driver , Thread.currentThread().getStackTrace()[1].getMethodName());
    }

    @And("UnSubmit The Assignment Of All Students")
    public void VerifyUnSubmitAssignmentOfAllStudents() throws InterruptedException {
        TestRunner.startTest(" Verify unSubmit of a all students  **********");
        try {
            gradingUnSubmitAssignmentPF.UnSubmitAssignmentForAllStudent();
            TestRunner.getTest().log(Status.FAIL, "Test Case Passed    :   UnSubmit assignment of all students successfully");
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            TestRunner.getTest().log(Status.FAIL, "Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
            Assert.fail();
        }
        Thread.sleep(1000);
        helper.takeScreenshot(driver , Thread.currentThread().getStackTrace()[1].getMethodName());
    }

    @And("Search the UnSubmit Assignment Into Student Panel")
    public void VerifyUnSubmitAssignmentIntoStudentPanel() throws InterruptedException {
        TestRunner.startTest(" Search the unSubmit assignment into student panel  **********");
        try {
            gradingUnSubmitAssignmentPF.searchUnSubmittedAssignmentIntoStudentPanel();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            TestRunner.getTest().log(Status.FAIL, "Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
        helper.takeScreenshot(driver , Thread.currentThread().getStackTrace()[1].getMethodName());
    }
}
