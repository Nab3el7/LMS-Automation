package StepDefinitions.GradebookModule;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Assignmment.CorrectAnswerExecutor_PF;
import pageFactory.Gradebook.AssignmentScoreVerification_PF;
import pageFactory.Gradebook.AssignmentVerification_PF;
import pageFactory.Gradebook.ManualGrading_PF;

import java.time.Duration;

import static pageFactory.Assignmment.InCorrectAnswerExecutor_PF.AssignmentNameForInCorrect;

public class AssignmentVerificationSteps extends Configurations {
    WebDriver driver = Configurations.getDriver();
    AssignmentVerification_PF Assign_verify_PF;
    AssignmentScoreVerification_PF assignmentScoreVerification_Pf;
    ManualGrading_PF manualGrading_pf;
    Helper helper;

    public WebDriverWait wait;

    WebElement loader = driver.findElement(By.xpath("//span[@role='progressbar']"));
//    public static String AssignmentNameOfCorrectAnswer = Configurations.getDotEnv().get("SITE_ASSIGNMENT_NAME_FOR_CORRECT_ANSWER");
//    public static String AssignmentNameOfInCorrectAnswer = Configurations.getDotEnv().get("SITE_ASSIGNMENT_NAME_FOR_INCORRECT_ANSWER");


    public AssignmentVerificationSteps() {
        Assign_verify_PF = new AssignmentVerification_PF(driver);
        assignmentScoreVerification_Pf = new AssignmentScoreVerification_PF(driver);
        manualGrading_pf = new ManualGrading_PF(driver);
        helper = new Helper();

        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
    }
    @Given("Click on class from list")
    public void click_on_class_from_list() throws InterruptedException {
        TestRunner.startTest("Select Class");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            Assign_verify_PF.Select_Class();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed    :  Exception is found");
            Assert.fail();
        }

    }
    @Given("Validate and Click all Collapsed Buttons")
    public void click_and_verify_collapse_button()throws InterruptedException {
        TestRunner.startTest("Select Class ");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            Assign_verify_PF.CollapseButton();

        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  Exception is found");
            Assert.fail();
        }
    }
    @Given("Check, Verify and Open assignment that Attempted with Correct Answers")
    public void check_and_verify_AttemptedCorrect_assignment_is_present() throws InterruptedException {
        TestRunner.startTest("Check, Verify and Open assignment that Attempted with Correct Answers And Verify Gradings");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            String assignmentNameForCorrect = CorrectAnswerExecutor_PF.assignmentNameForCorrect.get();
            System.out.println("Want to open attempted assignment: " + assignmentNameForCorrect);
            TestRunner.getTest().log(Status.INFO, "Want to open attempted assignment: " + assignmentNameForCorrect);
            Assign_verify_PF.searchAssignmentNames(assignmentNameForCorrect);
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @Given("Check, Verify and Open Specific assignment that Attempted with Correct Answers")
    public void checkAndVerifyOpenSpecificAssignmentFromGradeBook() throws InterruptedException {
        TestRunner.startTest("Check, Verify and Open Specific Assignment that Attempted with Correct Answers");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            String assignmentNameForCorrect = CorrectAnswerExecutor_PF.assignmentNameForCorrect.get();
            System.out.println("Want to open attempted assignment: " + assignmentNameForCorrect);
            TestRunner.getTest().log(Status.INFO, "Want to open attempted assignment: " + assignmentNameForCorrect);
            Assign_verify_PF.searchAndOpenSpecificAssignment(assignmentNameForCorrect);
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @Given("Check, Verify and Open assignment that Attempted with Correct Answers With Updated UI")
    public void check_and_verify_AttemptedCorrect_assignment_is_present_updated_ui() throws InterruptedException {
        TestRunner.startTest("Check, Verify and Open assignment that Attempted with Correct Answers And Verify Gradings Updated UI");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            String assignmentNameForCorrect = CorrectAnswerExecutor_PF.assignmentNameForCorrect.get();
            System.out.println("Want to open attempted assignment: " + assignmentNameForCorrect);
            TestRunner.getTest().log(Status.INFO, "Want to open attempted assignment: " + assignmentNameForCorrect);
            Assign_verify_PF.searchAssignmentNamesUpdatedUI(assignmentNameForCorrect);
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @Given("Check, Validate and Click On Preview Tab Activity")
    public void ValidateAndClickOnPreviewActivity() throws InterruptedException {
        TestRunner.startTest("Check, Validate and Click And Open Preview Tab Activity");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            manualGrading_pf.ClickOnPreviewTabActivity();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Check, Validate and Click On Grade By Student Tab Activity")
    public void ValidateAndClickOnGradeByStudentActivity() throws InterruptedException {
        TestRunner.startTest("Check, Validate and Click And Open Grade By Student Tab Activity");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            manualGrading_pf.ClickOnGradeByStudentTabActivity();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Check, Validate and Click On Summary Tab Activity")
    public void ValidateAndClickOnSummaryTabActivity() throws InterruptedException {
        TestRunner.startTest("Check, Validate and Click And Open Summary Tab Activity");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            manualGrading_pf.ClickOnSummaryTab();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @Given("Check, Verify and Open assignment that Attempted with InCorrect Answers")
    public void check_and_verify_AttemptedInCorrect_assignment_is_present() throws InterruptedException {
        TestRunner.startTest(" Select Assignment ");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            Assign_verify_PF.searchAssignmentNames(AssignmentNameForInCorrect);
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @Given("Check, Verify and Click Student Score View Option Points or Percentage")
    public void VerifyStudentScoreIntoPoints(){
        TestRunner.startTest("  Assignment Score Summary View into Points");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            assignmentScoreVerification_Pf.ClickOnScoreViewIntoPoints();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  Exception is found");
            Assert.fail();
        }

    }

    @Given("Check, Verify and Validate Student Score of Attempted Assignment")
    public void Verify_Student_score() throws InterruptedException{
        TestRunner.startTest("Validate and Get Student Score of Attempted Assignment");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            assignmentScoreVerification_Pf.PrintAndVerifyStudentScoreWithAssignmentScore();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  Exception is found");
            Assert.fail();
        }

    }

    @And("Check, Verify and Validate Student Highest Score of Attempted Assignment")
    public void VerifyStudentHighestScore() throws InterruptedException{
        TestRunner.startTest("Verify and Validate Student Highest Score of Attempted Assignment");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            assignmentScoreVerification_Pf.AssignmentScoresSummaryForVerification();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  Exception is found");
            Assert.fail();
        }

    }


    @Given("Check, Verify and Click on Edit Assignment option")
    public void CheckVerifyAndClickOnEditAssignmentOption() throws InterruptedException {
        TestRunner.startTest("Check, Verify and Click on Edit Assignment option");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            String assignmentNameForCorrect = CorrectAnswerExecutor_PF.assignmentNameForCorrect.get();
            System.out.println("Want to Edit assignment: " + assignmentNameForCorrect);
            TestRunner.getTest().log(Status.INFO, "Want to Edit assignment: " + assignmentNameForCorrect);
            Assign_verify_PF.searchAssignmentNameForEdit(assignmentNameForCorrect);
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Check, Validate and Click on Question Mark Icon")
    public void CheckValidateAndClickOnQuestionMarkIcon() throws InterruptedException {
        TestRunner.startTest("Check, Validate and Click on Question Mark Icon");
        try {
            manualGrading_pf.ClickOnQuestionMarkIcon();
        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Verify Prompt Is Displayed on Grade By Student")
    public void VerifyGradingPromptIsDisplayedOnGradeByStudent() throws InterruptedException{
        TestRunner.startTest("Verify Grading Prompt Is Displayed on Grade By Student");
        try {
            manualGrading_pf.verifyGradingPrompt();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Check, Validate and Click on Continue to Assignment Grading Button")
    public void CheckValidateAndClickOnContinueToAssignmentGradingButton() throws InterruptedException {
        TestRunner.startTest("Check, Validate and Click on Continue to Assignment Grading Button");
        try {
            manualGrading_pf.verifyAndClickContinueToAssignmentGradingButton();
        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Check, Validate and Click on i Icon")
    public void CheckValidateAndClickOnIIcon() throws InterruptedException {
        TestRunner.startTest("Check, Validate and Click on i Icon");
        try {
            manualGrading_pf.clickIIconBtn();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Check, Validate Instruction on i Icon")
    public void CheckValidateInstructionOnIIcon() throws InterruptedException {
        TestRunner.startTest("Check, Validate Instruction on i Icon");
        try {
            manualGrading_pf.checkInstructionOnResourceDescriptionAndInstructionalStrategies();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Check, Validate Print Button for Assignment on Grade By Student")
    public void CheckValidatePrintButtonForAssignmentOnGradeByStudent() throws InterruptedException {
        TestRunner.startTest("Check, Validate Print Button for Assignment on Grade By Student");
        try {
            manualGrading_pf.clickOnPrintIcon();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Check, Validate Standard Icon on Grade By Student")
    public void CheckValidateStandardIconOnGradeByStudent() throws InterruptedException {
        TestRunner.startTest("Check, Validate Standard Icon on Grade By Student");
        try {
            manualGrading_pf.clickOnStandardIcon();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Check, Validate and get Standard information on Grade By Student")
    public void CheckValidateAndGetStandardInformationOnGradeByStudent() throws InterruptedException {
        TestRunner.startTest("Check, Validate and get Standard information on Grade By Student");
        try {
            manualGrading_pf.getStandardsFromGradeByStudent();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Check, Verify standard Match On Grade By Student")
    public void CheckVerifyStandardMatchOnGradeByStudent() throws InterruptedException{
        TestRunner.startTest("Check, Verify standard Match On Grade By Student");

        try {
            manualGrading_pf.validateStandardMatch();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Validate Assignment Name Match on Grade By Student")
    public void ValidateAssignmentNameMatchOnGradeByStudent() throws InterruptedException {
        TestRunner.startTest("Validate Assignment Name Match on Grade By Student");

        try {
            manualGrading_pf.assignmentNameVerification();
        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);

    }

    @And("Check, Verify and Get Assignment Start and Due Date on Grade By Student")
    public void CheckVerifyAndGetAssignmentStartAndDueDateOnGradeByStudent() throws InterruptedException {
        TestRunner.startTest("Check, Verify and Get Assignment Start and Due Date on Grade By Student");
        try {
            manualGrading_pf.getStartAndDueDateOnGradeByStudent();
        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Check, Validate and Click on Arrow DropDown Icon On Grade By Student")
    public void CheckValidateAndClickOnArrowDropDownIconOnGradeByStudent() throws InterruptedException {
        TestRunner.startTest("Check, Validate and Click on Arrow DropDown Icon On Grade By Student");
        try {
            manualGrading_pf.clickOnArrowDropDownIcon();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Validate And Click on Add Assignment Comment Option On Grade By Student")
    public void ValidateAndClickOnAddAssignmentCommentOptionOnGradeByStudent() throws InterruptedException {
        TestRunner.startTest("Validate And Click on Add Assignment Comment Option On Grade By Student");
        try {
            manualGrading_pf.clickOnAddAssignmentCommentOption();

        } catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Check, Validate and Comment in Assignment Comment Area and Save Comment")
    public void CheckValidateAndCommentInAssignmentCommentAreaAndSaveComment() throws InterruptedException {
        TestRunner.startTest("Check, Validate and Comment in Assignment Comment Area and Save Comment");
        try {
            manualGrading_pf.AddCommentAndClickSave();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Validate, Verify Teacher Comment From Grade By Student Match On Student Side")
    public void ValidateVerifyTeacherCommentFromGradeByStudentMatchOnStudentSide() throws InterruptedException {
        TestRunner.startTest("Validate, Verify Teacher Comment From Grade By Student Match On Student Side");
        try {
            manualGrading_pf.VerificationOfTeacherCommentFromGradeByStudentOnStudentSide();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }
}
