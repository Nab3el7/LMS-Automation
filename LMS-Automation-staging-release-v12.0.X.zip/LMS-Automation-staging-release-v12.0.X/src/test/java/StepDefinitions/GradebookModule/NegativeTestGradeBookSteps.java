package StepDefinitions.GradebookModule;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.bs.A;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en_scouse.An;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Classes.AddClass_PF;
import pageFactory.Gradebook.GradeBookSearchBox_PF;
import pageFactory.Gradebook.GradeBookStudent_PF;
import pageFactory.Gradebook.NegativeTestGradeBook_PF;
import pageFactory.StudentsModule.AddNewStudent_PF;

import java.time.Duration;


public class NegativeTestGradeBookSteps extends Configurations {
    WebDriver driver = Configurations.getDriver();
    Helper helper;
    GradeBookStudent_PF gradeBookStudent_pf;
    GradeBookSearchBox_PF gradeBookSearchBox_pf;

    NegativeTestGradeBook_PF negativeTestGradeBook_pf;
    AddNewStudent_PF addNewStudentPf;
    AddClass_PF addClassPf;
    Actions actions;

    public WebDriverWait wait;
    WebElement loader = driver.findElement(By.xpath("//span[@role='progressbar']"));

    public static String AssignmentNameforSearch = "AAAAAAAAAAAAAAAAAAAAA!!!!11111111222222%%%%%%*****";
    public static String AssignmentInOtherClass = "MB::20/6:: Checkpoint 01";

    public static String AssignmentNameWithCorrectName = "AttemptAssignmentCorrect_Fri Nov 08 17:56:07 PKT 2024";

    

    public NegativeTestGradeBookSteps(){
        helper = new Helper();
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
        actions = new Actions(driver);
        gradeBookStudent_pf = new GradeBookStudent_PF(driver);
        gradeBookSearchBox_pf = new GradeBookSearchBox_PF(driver);
        addNewStudentPf = new AddNewStudent_PF(driver);
        addClassPf= new AddClass_PF(driver);
        negativeTestGradeBook_pf= new NegativeTestGradeBook_PF(driver);
    }

    @And("Search the assignment With incorrect Title")
    public void SearchAssignmentWithIncorrectTitle() throws InterruptedException{
        TestRunner.startTest( "Search the assignment With incorrect Title ");
            try {
//
                negativeTestGradeBook_pf.SearchAssessmentByIncorrectTitle(AssignmentNameforSearch);
            } catch (NoSuchElementException | ElementNotInteractableException e) {
                System.out.println(e);
                System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  Search Box not found **********");
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Search Box not found ");
                Assert.fail();
            }
    }

    @And("Verify assignment found in Table or not")
    public void VerifyAssignmentFoundInTable() throws InterruptedException{
        TestRunner.startTest( "Verify assignment found in Table or not ");
        try {

            negativeTestGradeBook_pf.verifyAssignmentPresentInTable();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Assignment also find with incorrect Title ");
            Assert.fail();
        }

    }

    @And("Search the assignment That is in other Class but not in the Selected Class")
    public void SearchAssignmentThatIsInOtherClass() throws InterruptedException{
        TestRunner.startTest( "Search the assignment That is in other Class but not in the Selected Class ");
        try {
            negativeTestGradeBook_pf.SearchAssessmentByIncorrectTitle(AssignmentInOtherClass);
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :  Assignment Also found in this class.");
            Assert.fail();
        }
    }


    @And("Search Student in search box")
    public void SearchStudentInSearchBox() throws InterruptedException{
        TestRunner.startTest( " Search Student in search box  ");

        try {
            negativeTestGradeBook_pf.GetStudentListAndHandleNotFoundScenario();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :  Student Also found in this class.");
            Assert.fail();
        }
    }

    @And("Click And Validate on Apply Filter Button")
    public void ApplyButton() throws InterruptedException{
        TestRunner.startTest( " Click And Validate on Apply Filter Button");
        try {
//            Thread.sleep(5000);
            negativeTestGradeBook_pf.ApplyFilterButton();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Apply filter button not found.");
            Assert.fail();
        }
//        Thread.sleep(3000);
    }

    @And("Clear search box")
    public void ClearSearchBox() throws InterruptedException{
        TestRunner.startTest("Clear search box");
        try {
//            Thread.sleep(5000);
            negativeTestGradeBook_pf.ClearSearchBox();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : Clearing not perform **********");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Search Box Clearing not perform ");

            Assert.fail();
        }
//        Thread.sleep(3000);
    }

    @And("Check , validate Email , Password field empty and update button Disable")
    public void CheckValidateEmailAndPasswordFieldEmptyAndUpdateButtonDisable()throws InterruptedException{
        TestRunner.startTest("Check , validate Email , Password field empty and update button Disable");
        try {
            negativeTestGradeBook_pf.EmptyEmailStdModal();
            negativeTestGradeBook_pf.updateButtonStd();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : both fields are empty but Update button is Enabled. ");
            Assert.fail();
        }
    }


    @And("Check and Validate empty Password Filed and Filled Email")
    public void CheckValidateEmptyPasswordFiledAndFilledEmail() throws InterruptedException{
        TestRunner.startTest("Check and Validate empty Password Filed and Filled Email");
        try {
            negativeTestGradeBook_pf.EnterEmailForStd();
            negativeTestGradeBook_pf.UpdateButtonForFilledEmail();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :Update Button not found ");
            Assert.fail();
        }
    }

    @And("I enter a password with less than 7 characters")
    public void enter_short_password() {
        TestRunner.startTest("Enter Short Password");
        try {
            WebElement passwordField = driver.findElement(By.xpath("//input[@name='stdPassword']"));

            passwordField.clear();
            passwordField.sendKeys("abc123");  // Password with only 6 characters

            WebElement errorMessage = driver.findElement(By.xpath("//p[@id='stdPassword-helper-text']"));
            Assert.assertTrue(errorMessage.isDisplayed());
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Message not show for Confirm Password");
            Assert.fail();
        }

    }

    @Then("I should see an error message for the password length")
    public void verify_error_message_for_short_password() {
        WebElement errorMessage = driver.findElement(By.xpath("//p[@id='stdPassword-helper-text']")); // Change the locator as per your HTML structure
        String expectedMessage = "Password must be at least 7 characters long"; // Expected error message
        Assert.assertEquals(expectedMessage, errorMessage.getText());
    }

    @And("Filled Password and empty Confirm Password")
    public void  FilledPasswordAndEmptyConfirmPassword() throws InterruptedException{
        TestRunner.startTest("Filled Password and empty Confirm Password");

        try {
            addClassPf.EnterClassNewStdPassword();
            negativeTestGradeBook_pf.VerifyConfirmPasswordRequiredMessage();
            negativeTestGradeBook_pf.updateButtonStd();


        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Message not show for Confirm Password");
            Assert.fail();
        }
    }

    @And("Check, Validate, Fill Information With Mismatch Password")
    public void testingPasswordMismatch() throws InterruptedException{
        TestRunner.startTest("Check, Validate, Fill Information with Mismatch Password for Student");
        try {
            addClassPf.EnterClassNewStdPassword();

            negativeTestGradeBook_pf.enterConfirmPasswordMisMatch();
            Thread.sleep(3000);
            WebElement passwordError = driver.findElement(By.xpath("//p[@id='stdConfirmPassword-helper-text']"));
            assert passwordError.isDisplayed();

        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("Validate Enter confirm Password and Empty Password filed")
    public void ValidateEnterConfirmPasswordAndEmptyPasswordFiled() throws InterruptedException{
        TestRunner.startTest("Validate Enter confirm Password and Empty Password filed ");

        try {

            negativeTestGradeBook_pf.clearPasswordField();
            addClassPf.EnterClassNewStdConfirmPassword();
            negativeTestGradeBook_pf.updateButtonStd();

        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");

            Assert.fail();
        }
        actions.sendKeys(Keys.ESCAPE).build().perform();

    }

    @And("Check, Validate, Fill Information With Invalid Email Format for Student In gradeBook")
    public void testInvalidEmailFormat() throws InterruptedException {
        TestRunner.startTest( " Check, Validate, Fill Information with Invalid Email Format for Student In GradeBook ");
        try {


            negativeTestGradeBook_pf.EnterInvalidEmailAddress();

            // Check for validation message on email field
            WebElement emailError = driver.findElement(By.xpath("//p[contains(text(),'Invalid email format')]"));
            assert emailError.isDisplayed();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
            Assert.fail();
        }
        actions.sendKeys(Keys.ESCAPE).build().perform();
    }

    @And("Verify Search Assessment in Search Box on GradeBook")
    public void serchAssignment() throws InterruptedException{
        TestRunner.startTest( "Search Assignment with correct Title");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            negativeTestGradeBook_pf.SearchAssessment(AssignmentNameWithCorrectName);

        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
            Assert.fail();
        }
        Thread.sleep(3000);
    }


    @Given("Verify assignment that Attempted with Correct Name")
    public void check_and_verify_AttemptedInCorrect_assignment_is_present() throws InterruptedException {
        TestRunner.startTest("Select Assignment");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            negativeTestGradeBook_pf.searchAssignmentNames(AssignmentNameWithCorrectName);
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
            Assert.fail();
        }

    }

    @And("Verify Grading message if Grading not found Grading Tab")
    public void GradingTabMessage() throws InterruptedException{
        TestRunner.startTest("Verify Grading message if Grading not found Grading Tab");
        try {

            WebElement gradingMessage = driver.findElement(By.xpath("//div[@class='boxListNotFount']//span[contains(@class, 'subtitle')]"));
            assert gradingMessage.isDisplayed();

        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found. No Grading message found");
            Assert.fail();
        }
    }


}
