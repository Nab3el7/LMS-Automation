package StepDefinitions.GradebookModule;

import StepDefinitions.AssignmentModule.AssignmentsModuleAssignNewSteps;
import StepDefinitions.Configurations;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Gradebook.GradingAssignNewAssignment_PF;

import java.time.Duration;

public class GradingAssignNewAssignmentSteps extends Configurations {
    WebDriver driver = Configurations.getDriver();
    public WebDriverWait wait;

    GradingAssignNewAssignment_PF gradingAssignNewAssignmentPF;

    WebElement loader = driver.findElement(By.xpath("//span[@role='progressbar']"));



    public GradingAssignNewAssignmentSteps() {
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
        gradingAssignNewAssignmentPF = new GradingAssignNewAssignment_PF(driver);
    }

    @And("Check, Validate And Click On Assign New Button In Gradebook")
    public void ClickOnGradebookAssignNewButton(){
        TestRunner.startTest("Check and verify GradeBook Module Dashboard Assign New Button");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            gradingAssignNewAssignmentPF.ClickOnAssignNewAssignmentButton();
        }
        catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found. GradeBook Module Dashboard Assign New Button not Found");
            Assert.fail();
        }
    }

    @And("Check, Validate And Select New Assignment Step-I In Gradebook")
    public void SelectAssignment(){
        TestRunner.startTest("Check and verify Select Assignment Step-1");

        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            gradingAssignNewAssignmentPF.SelectAssignmentInShowAllTab();
        }
        catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found Assignment not select on step-1");

            Assert.fail();
        }
    }

    @And("Check, Validate And Click On Next Button For New Assignment In Gradebook")
    public void clickOnNextButton() throws InterruptedException{
        TestRunner.startTest("Click on Next Button for New Assessment");
        try {
            gradingAssignNewAssignmentPF.ClickOnNextButton();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found NextButton is not Visible/Enable");

            Assert.fail();
        }
        Thread.sleep(2000);
    }
}
