package StepDefinitions.GradebookModule;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Gradebook.GradeBookInactiveStudent_PF;
import pageFactory.Gradebook.GradeBookSummary_PF;

import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import org.junit.Assert;
import org.openqa.selenium.support.ui.ExpectedConditions;


import java.time.Duration;

//import static StepDefinitions.Configurations.driver;

public class GradeBookStudentInactiveSteps extends Configurations {
    WebDriver driver = Configurations.getDriver();

    Helper helper;

    public WebDriverWait wait;
    WebElement loader = driver.findElement(By.xpath("//span[@role='progressbar']"));


    Actions actions;
    GradeBookSummary_PF gradeBookSummary_pf;

    GradeBookInactiveStudent_PF gradeBookInactiveStudent_pf;

    public GradeBookStudentInactiveSteps(){
        helper = new Helper();
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
        actions = new Actions(driver);
        gradeBookSummary_pf = new GradeBookSummary_PF(driver);
        gradeBookInactiveStudent_pf = new GradeBookInactiveStudent_PF(driver);
    }

    @And("Search Class By Keyword for new Student")
    public void SearchClassByKeywordForNewStudent() throws InterruptedException{
        TestRunner.startTest( "Search Class By Keyword For New Student");
        try {
            gradeBookInactiveStudent_pf.searchClassByNameFOrNewStudent();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("Click on Next Button From Class Step-I")
    public void ClickOnNextButtonFromClassStepI() throws InterruptedException{
        TestRunner.startTest( "Click on Next Button From Class Step-I");
        try {
            gradeBookInactiveStudent_pf.ClickOnNextBtnForStdInactive();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("Click on SaveNext Button From Class Step-II")
    public void ClickOnSaveNextButtonFromClassStepII() throws InterruptedException{
        TestRunner.startTest( "Click on SaveNext Button From Class Step-II");
        try {
            gradeBookInactiveStudent_pf.ClickOnSaveNextBtnForStdInactiveStepII();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("Check, Verify that Student is present in Student List")
    public void CheckVerifyThatStudentIsPresentInStudentList() throws InterruptedException{
        TestRunner.startTest( "Check, Verify that Student is present in Student List");
        try {
            gradeBookInactiveStudent_pf.VerifyThatStudentIsPresentInStudentList();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("Verify that Inactive Student is Not Present In Active Student List")
    public void VerifyThatInactiveStudentIsNotPresentInActiveStudentList() throws InterruptedException{
        TestRunner.startTest( "Verify that Inactive Student is Not Present In Active Student List");
        try {
            gradeBookInactiveStudent_pf.VerifyThatStudentIsNotPresentActiveStudentListGradeBook();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("Verify That Inactive Student is Present in GradeBook InActive Student List")
    public void VerifyThatInactiveStudentIsPresentInGradeBookInActiveStudentList() throws InterruptedException{
        TestRunner.startTest( "Verify That Inactive Student is Present in GradeBook InActive Student List");
        try {
            gradeBookInactiveStudent_pf.VerifyStudentISPresentInInactiveStudentListGradeBook();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("Search that Inactive Student In Search bar GradeBook")
    public void SearchThatInactiveStudentInSearchBarGradeBook() throws InterruptedException{
        TestRunner.startTest( "Search that Inactive Student In Search bar GradeBook");
        try {
            gradeBookInactiveStudent_pf.SearchInactiveStudentGradeBook();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }
}
