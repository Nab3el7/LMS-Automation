package StepDefinitions.GradebookModule;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Assignmment.CorrectAnswerExecutor_PF;
import pageFactory.Classes.AddClass_PF;
import pageFactory.Gradebook.*;
import pageFactory.StudentsModule.AddNewStudent_PF;

import java.time.Duration;

import static pageFactory.Assignmment.ReleaseAssignment_PF.assignmentTypeFromAssignment;
import static pageFactory.MyContent.AssignAssessment_PF.*;

public class GradeBookViewSteps extends Configurations {
    // Lazy initialization - get driver only when needed
    private WebDriver driver;
    private WebDriverWait wait;
    private WebElement loader;
    private Actions actions;

    Helper helper;
    GradeBookStudent_PF gradeBookStudent_pf;
    GradeBookSearchBox_PF gradeBookSearchBox_pf;
    NegativeTestGradeBook_PF negativeTestGradeBook_pf;
    AddNewStudent_PF addNewStudentPf;
    AddClass_PF addClassPf;
    PositiveTestCaseGradeBook_PF positiveTestCaseGradeBook_pf;
    ManualGrading_PF manualGrading_pf;
    GradeBookView_PF gradeBookView_pf;

    // Lazy getters - initialize only when accessed
    private WebDriver getWebDriver() {
        if (driver == null) {
            driver = Configurations.getDriver();
        }
        return driver;
    }

    private WebDriverWait getWebDriverWait() {
        if (wait == null) {
            wait = new WebDriverWait(getWebDriver(), Duration.ofSeconds(60));
        }
        return wait;
    }

    private WebElement getLoader() {
        if (loader == null) {
            loader = getWebDriver().findElement(By.xpath("//span[@role='progressbar']"));
        }
        return loader;
    }

    private Actions getActions() {
        if (actions == null) {
            actions = new Actions(getWebDriver());
        }
        return actions;
    }

    public GradeBookViewSteps(){
        // Helper doesn't need driver immediately - it uses lazy initialization
        helper = new Helper();
        // Page objects will be initialized when driver is first accessed
    }

    // Initialize page objects when driver is first used
    private void ensurePageObjectsInitialized() {
        if (gradeBookStudent_pf == null) {
            gradeBookStudent_pf = new GradeBookStudent_PF(getWebDriver());
            gradeBookSearchBox_pf = new GradeBookSearchBox_PF(getWebDriver());
            addNewStudentPf = new AddNewStudent_PF(getWebDriver());
            addClassPf = new AddClass_PF(getWebDriver());
            negativeTestGradeBook_pf = new NegativeTestGradeBook_PF(getWebDriver());
            positiveTestCaseGradeBook_pf = new PositiveTestCaseGradeBook_PF(getWebDriver());
            manualGrading_pf = new ManualGrading_PF(getWebDriver());
            gradeBookView_pf = new GradeBookView_PF(getWebDriver());
        }
    }

    @Given("Check, Validate and Open Assignment that you want to View")
    public void check_and_verify_AttemptedCorrect_assignment_is_present() throws InterruptedException {
        ensurePageObjectsInitialized();
        ensurePageObjectsInitialized();
        TestRunner.startTest(" Select Assignment That you want to View ");
        try {
            getWebDriverWait().until(ExpectedConditions.invisibilityOf(getLoader()));
            String assignmentNameForCorrect = CorrectAnswerExecutor_PF.assignmentNameForCorrect.get();
            System.out.println("Want to open assignment for view: " + assignmentNameForCorrect);
            TestRunner.getTest().log(Status.INFO, "Want to open assignment for view: " + assignmentNameForCorrect);
            gradeBookView_pf.searchAssignmentNamesForView(assignmentNameForCorrect);
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  Exception is found");
            Assert.fail();
        }
//        Thread.sleep(2000);
    }

    @And("Teacher Add Assignment Comments On Assignment")
    public void TeacherAddAssignmentCommentsOnAssignment() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Teacher Add Assignment Comments On Assignment ");
        try {
            getWebDriverWait().until(ExpectedConditions.invisibilityOf(getLoader()));
            gradeBookView_pf.TeacherAddAssignmentComments();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  Exception is found. Add Assignment Comments not found.");
            Assert.fail();
        }
    }

    @And("Click and Verify Submit Comment button")
    public void VerifySubmitCommentButton() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest(" Click and Verify Submit Comment button ");
        try {
            getWebDriverWait().until(ExpectedConditions.invisibilityOf(getLoader()));
            gradeBookView_pf.SubmitButtonComments();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  Exception is found. Add Assignment Comments not found.");
            Assert.fail();
        }
    }

    @And("Verify Teacher Comments Show on Student side")
    public void VerifyTeacherCommentsShowOnStudentSide() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest(" Verify Teacher Comments Show on Student side ");
        try {
            getWebDriverWait().until(ExpectedConditions.invisibilityOf(getLoader()));
            gradeBookView_pf.VerificationOfTeacherCommentOnStudentSide();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  Exception is found. Comments not found.");
            Assert.fail();
        }
//        Thread.sleep(2000);
    }

    // GradeBook Filter

    @And("Select Category from DropDown option")
    public void SelectCategoryFromDropDownOption() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest(" Select Category from DropDown option ");
        try {
            getWebDriverWait().until(ExpectedConditions.invisibilityOf(getLoader()));
            gradeBookView_pf.SelectCategoryFromGradeBook(CategoryFromAssignment);
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  Exception is found.");
            Assert.fail();
        }
//        Thread.sleep(2000);
    }

    @And("Select Assignment Type From DropDown Option")
    public void SelectAssignmentTypeFromDropDownOption() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest(" Select Assignment Type From DropDown Option ");
        try {
            getWebDriverWait().until(ExpectedConditions.invisibilityOf(getLoader()));
            gradeBookView_pf.SelectAssignmentTypeFromGradeBook(assignmentTypeFromAssignment);
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  Exception is found.");
            Assert.fail();
        }
//        Thread.sleep(2000);
    }

    @And("Click and set Start date")
    public void ClickAndSetStartDate() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest(" Click and set Start date");
        try {
            getWebDriverWait().until(ExpectedConditions.invisibilityOf(getLoader()));
            gradeBookView_pf.SelectStartDate(startDateTime);
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  Exception is found.");
            Assert.fail();
        }
//        Thread.sleep(2000);
    }

    @And("Click and set End Date")
    public void ClickAndSetEndDate() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest(" Click and set End Date");
        try {
            getWebDriverWait().until(ExpectedConditions.invisibilityOf(getLoader()));
            gradeBookView_pf.SelectEndDate(endDateTime);
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  Exception is found.");
            Assert.fail();
        }
//        Thread.sleep(2000);
    }

    @And("Verify , Check Assignment is found after Filters Applied")
    public void VerifyCheckAssignmentIsFoundAfterFiltersApplied() throws InterruptedException{

        ensurePageObjectsInitialized();
        TestRunner.startTest(" Verify , Check Assignment is found after Filters Applied");
        try {
            getWebDriverWait().until(ExpectedConditions.invisibilityOf(getLoader()));
            String assignmentNameForCorrect = CorrectAnswerExecutor_PF.assignmentNameForCorrect.get();
            System.out.println("Want to search assignment after filters: " + assignmentNameForCorrect);
            TestRunner.getTest().log(Status.INFO, "Want to search assignment after filters: " + assignmentNameForCorrect);
            gradeBookView_pf.AssignmentSearchAfterFilters(assignmentNameForCorrect);
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  Exception is found.");
            Assert.fail();
        }
//        Thread.sleep(2000);
    }

    @And("Validate and Get Custom Assessment and Assign that Assessment")
    public void ValidateAndGetCustomAssessmentAndAssignThatAssessment() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Validate and Get Custom Assessment and Assign that Assessment");
        try {
            gradeBookView_pf.ClickOnAssignAndProcessToAssignCustomAssessmentForFIlterVerifications();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed    :   Exception is found");
            Assert.fail();
        }
        Thread.sleep(1000);
    }

    // For Custom Assessment

    @And("Add Comments for Each Question")
    public void AddCommentsForEachQuestion() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Add Comments for Each Question");
        try {
            gradeBookView_pf.ProcessToAddCommentsOnEachQuestion();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed    :   Exception is found");
            Assert.fail();
        }
        Thread.sleep(1000);
    }

    @And("Check , Verify Teacher Comment On student Side in close tab")
    public void CheckVerifyTeacherCommentOnStudentSideInCloseTab() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Check , Verify Teacher Comment On student Side in close tab");
        try {
            gradeBookView_pf.VerifyCommentsOnStudentSide();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed    :   Exception is found");
            Assert.fail();
        }
        Thread.sleep(1000);
    }


}
