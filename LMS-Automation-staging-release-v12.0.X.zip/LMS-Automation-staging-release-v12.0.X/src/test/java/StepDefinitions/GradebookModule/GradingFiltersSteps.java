package StepDefinitions.GradebookModule;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.MyContentModule.AssignAssessmentSteps;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Gradebook.GradingFilters_PF;
import pageFactory.Gradebook.ManualGrading_PF;

import java.time.Duration;

public class GradingFiltersSteps extends Configurations {
    // Lazy initialization - get driver only when needed
    private WebDriver driver;
    private WebDriverWait wait;
    private WebElement loader;
    private Actions actions;

    ManualGrading_PF manualGradingPF;
    GradingFilters_PF gradingFilterPF;
    Helper helper;

    // Lazy getters - initialize only when accessed
    private WebDriver getWebDriver() {
        if (driver == null) {
            driver = Configurations.getDriver();
        }
        return driver;
    }

    private WebDriverWait getWebDriverWait() {
        if (wait == null) {
            wait = new WebDriverWait(getWebDriver(), Duration.ofSeconds(60));
        }
        return wait;
    }

    private WebElement getLoader() {
        if (loader == null) {
            loader = getWebDriver().findElement(By.xpath("//span[@role='progressbar']"));
        }
        return loader;
    }

    private Actions getActions() {
        if (actions == null) {
            actions = new Actions(getWebDriver());
        }
        return actions;
    }

    public GradingFiltersSteps() {
        // Helper doesn't need driver immediately - it uses lazy initialization
        helper = new Helper();
        // Page objects will be initialized when driver is first accessed
    }

    // Initialize page objects when driver is first used
    private void ensurePageObjectsInitialized() {
        if (manualGradingPF == null) {
            manualGradingPF = new ManualGrading_PF(getWebDriver());
            gradingFilterPF = new GradingFilters_PF(getWebDriver());
        }
    }

    @And("Click on Show All Filters")
    public void ClickToShowAllFilters() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Click on GradeBook Show All Filters");

        try {
            gradingFilterPF.clickOnShowFilter();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("Click on Select District Dropdown And Select Value")
    public void DropDownSelectDistrict() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest( " Click on GradeBook Filter Select District Dropdown  **********");
        try {
            gradingFilterPF.ClickOnDropDownSelectDistrict();
            System.out.println("Test Case Passed    :   DropDown select district clicked successfully");
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :   Exception is found");
            Assert.fail();
        }
    }

    @And("Click on Select School Dropdown And Select Value")
    public void DropDownSelectSchool() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest( " Click on GradeBook Filter Select School Dropdown  **********");
        try {
            gradingFilterPF.ClickOnDropDownSelectSchool();
            System.out.println("Test Case Passed    :   DropDown select school clicked successfully");
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :   Exception is found");
            Assert.fail();
        }
    }

    @And("Click on Select Teacher Dropdown And Select Value")
    public void DropDownSelectTeacher() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest( " Click on GradeBook Filter Select Teacher Dropdown  **********");
        try {
            gradingFilterPF.ClickOnDropDownSelectTeacher();
            System.out.println("Test Case Passed    :   DropDown select teacher clicked successfully");
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :   Exception is found");
            Assert.fail();
        }
    }

    @And("Click on Classes Toggle Button")
    public void ToggleButtonClasses() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest( " Click on GradeBook Filter Classes Toggle Button  **********");
        try {
            gradingFilterPF.ClickOnClassesToggleButton();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :   Exception is found");
            Assert.fail();
        }
    }

    @And("Click on Students Toggle Button")
    public void ToggleButtonStudents() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Click on GradeBook Filter Students Toggle Button ");

        try {
            gradingFilterPF.ClickOnStudentsToggleButton();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");

            Assert.fail();
        }
    }

    @And("Click on Apply Date Range Filter")
    public void AddOnApplyDateFilter() throws InterruptedException{
        Thread.sleep(2000);
        ensurePageObjectsInitialized();
        TestRunner.startTest("Click on GradeBook Filter Apply Date Range");
        try {
            gradingFilterPF.ClickOnApplyDateFilter();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");

            Assert.fail();
        }
    }

    @And("Click on Select And Send Start Date")
    public void SelectStartDate() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Click on GradeBook Filter Start Date ");
        try {
            gradingFilterPF.ClickOnStartDateFilter();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("Click on Select And Send End Date")
    public void SelectEndDate() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Click on GradeBook Filter End Date ");
        try {
            gradingFilterPF.ClickOnEndDateFilter();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("Click on Apply Filter Button")
    public void ButtonApplyFilter() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Click on GradeBook Filter Apply Button  ");
        try {
            gradingFilterPF.ClickOnApplyFilterButton();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }


//        Sort by Date, %, Points, and Print Button

    @And("Click on Class Dropdown And Select Value")
    public void ClickClassDropdownAndSelectValue() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest( " Click on GradeBook Class Dropdown And Select Value **********");
        try {
            gradingFilterPF.ClickClassDropDownAndValue();
            System.out.println("Test Case Passed    :   DropDown class clicked successfully");
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :   Exception is found");
            Assert.fail();
        }
    }

    @And("Click on SortBy Dropdown And Select Value")
    public void ClickSortByDropdownAndSelectValue() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest( " Click on GradeBook SortBy Dropdown And Select Value **********");
        try {
            gradingFilterPF.ClickSortByDropDownAndValue();
            System.out.println("Test Case Passed    :   DropDown sort by clicked successfully");
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :   Exception is found");
            Assert.fail();
        }
    }

    @And("Click Due Date")
    public void Duedate() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest( "Click on Due Date********");
        Thread.sleep(3000);
        gradingFilterPF.Duedate();
    }

    @And("Click Points")
    public void Points() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest( "Click on Points**********");
        Thread.sleep(3000);
        gradingFilterPF.Points();
    }

    @And("Click on CheckBox")
    public void Checkbox() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest( "Click the Check Box*********");
        Thread.sleep(3000);
        gradingFilterPF.Checkbox();
    }

    @And("Click on Print Button")
    public void Printbtn() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Click the Print Button");
        try {
            Thread.sleep(4000);
            gradingFilterPF.Printbtn();
        }catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("Print Loading")
    public void Printloading() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Loading Print waiting");
        try {
            Thread.sleep(3000);
            gradingFilterPF.Printloading();
        }catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
            Assert.fail();
        }
        getActions().sendKeys(Keys.ESCAPE).build().perform();
    }


}
