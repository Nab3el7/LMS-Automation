package StepDefinitions.GradebookModule;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Assignmment.CorrectAnswerExecutor_PF;
import pageFactory.Classes.AddClass_PF;
import pageFactory.Gradebook.*;
import pageFactory.StudentsModule.AddNewStudent_PF;

import java.time.Duration;

import static pageFactory.Assignmment.AssignmentModuleAssignNew_PF.AssignmentName;

public class PositiveTestCaseGradeBookSteps extends Configurations {
    // Lazy initialization - get driver only when needed
    private WebDriver driver;
    private WebDriverWait wait;
    private WebElement loader;
    private Actions actions;

    Helper helper;
    GradeBookStudent_PF gradeBookStudent_pf;
    GradeBookSearchBox_PF gradeBookSearchBox_pf;
    NegativeTestGradeBook_PF negativeTestGradeBook_pf;
    AddNewStudent_PF addNewStudentPf;
    AddClass_PF addClassPf;
    PositiveTestCaseGradeBook_PF positiveTestCaseGradeBook_pf;
    ManualGrading_PF manualGrading_pf;

    // Lazy getters - initialize only when accessed
    private WebDriver getWebDriver() {
        if (driver == null) {
            driver = Configurations.getDriver();
        }
        return driver;
    }

    private WebDriverWait getWebDriverWait() {
        if (wait == null) {
            wait = new WebDriverWait(getWebDriver(), Duration.ofSeconds(60));
        }
        return wait;
    }

    private WebElement getLoader() {
        if (loader == null) {
            loader = getWebDriver().findElement(By.xpath("//span[@role='progressbar']"));
        }
        return loader;
    }

    private Actions getActions() {
        if (actions == null) {
            actions = new Actions(getWebDriver());
        }
        return actions;
    }

    public PositiveTestCaseGradeBookSteps(){
        // Helper doesn't need driver immediately - it uses lazy initialization
        helper = new Helper();
        // Page objects will be initialized when driver is first accessed
    }

    // Initialize page objects when driver is first used
    private void ensurePageObjectsInitialized() {
        if (gradeBookStudent_pf == null) {
            gradeBookStudent_pf = new GradeBookStudent_PF(getWebDriver());
            gradeBookSearchBox_pf = new GradeBookSearchBox_PF(getWebDriver());
            addNewStudentPf = new AddNewStudent_PF(getWebDriver());
            addClassPf = new AddClass_PF(getWebDriver());
            negativeTestGradeBook_pf = new NegativeTestGradeBook_PF(getWebDriver());
            positiveTestCaseGradeBook_pf = new PositiveTestCaseGradeBook_PF(getWebDriver());
            manualGrading_pf = new ManualGrading_PF(getWebDriver());
        }
    }

    @And("Verify GradeBook Students List and search Student and check I icon present or not")
    public void VerifyGradeBookStudentsList() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Verify GradeBook Students List and search Student and check I icon present or not");
        try {
            getWebDriverWait().until(ExpectedConditions.invisibilityOf(getLoader()));

            positiveTestCaseGradeBook_pf.GetStudentListAndIconPresent();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
            Assert.fail();
        }

    }

    @And("Verify Collapse Check Box GradeBook")
    public void CollapseCheckBoxPresent() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Verify Collapse Check Box GradeBook");

        try {
            getWebDriverWait().until(ExpectedConditions.invisibilityOf(getLoader()));

            positiveTestCaseGradeBook_pf.ClickOnCollapseCheckBox();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("Click on export Button")
    public void ExportButton()throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Verify and Click on export Button");
        try {
            getWebDriverWait().until(ExpectedConditions.invisibilityOf(getLoader()));
            positiveTestCaseGradeBook_pf.selectValueFromDropDownExport();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :  Exception is found. Export Button not found");
            Assert.fail();
        }
    }

    @And("Check and validate refresh button")
    public void CheckValidateRefreshButton() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Check and validate refresh button ");
        try {
            getWebDriverWait().until(ExpectedConditions.invisibilityOf(getLoader()));
            positiveTestCaseGradeBook_pf.ClickAndValidateRefreshButton();
            manualGrading_pf.GradeBookDashboard();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :  Exception is found. Refresh Button not found");
            Assert.fail();
        }
    }

    @And("Validate I Icon on GradeBook")
    public void ValidateIIconOnGradeBook() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Validate I Icon on GradeBook ");

        try {
            getWebDriverWait().until(ExpectedConditions.invisibilityOf(getLoader()));

            positiveTestCaseGradeBook_pf.ClickIIconGradeBook();
            manualGrading_pf.GradeBookDashboard();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found. I icon not found.");
            Assert.fail();
        }
    }

    @And("click on % and Verify that Value shows in percent")
    public void VerifyPercentView() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("click on % and Verify that Value shows in percent ");
        try {
            getWebDriverWait().until(ExpectedConditions.invisibilityOf(getLoader()));

            positiveTestCaseGradeBook_pf.VerifyViewPercentOption();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :  Exception is found. View % option not found");
            Assert.fail();
        }
    }

    @And("Click on point and verify that row of Total Possible Points show")
    public void PointsViewVerify() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Click on point and verify that row of Total Possible Points show");

        try {
            getWebDriverWait().until(ExpectedConditions.invisibilityOf(getLoader()));

            positiveTestCaseGradeBook_pf.VerifyViewPointsOption();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found. View points option not found.");
            Assert.fail();
        }
    }

    @And("click on sort by option and select option")
    public void SortByDropDown() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("click on sort by option and select option");

        try {
            getWebDriverWait().until(ExpectedConditions.invisibilityOf(getLoader()));

            positiveTestCaseGradeBook_pf.SortByStartDate();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found. Sort By  option not found.");
            Assert.fail();
        }
    }

    // search newly created assessment Before Student Attempt
    @And("Search newly created Assignment by Using Search Box")
    public void SearchNewlyCreatedAssignmentByUsingSearchBox() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Search newly created Assignment by Using Search Box");

        try {
            getWebDriverWait().until(ExpectedConditions.invisibilityOf(getLoader()));

            positiveTestCaseGradeBook_pf.SearchNewCreatedAssignment(AssignmentName);
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found. Sort By  option not found.");
            Assert.fail();
        }
    }

    @And("Verify Search Assignment Is Present On DashBoard Or Not")
    public void VerifySearchAssignmentIsPresentOnDashBoardOrNot() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Verify Search Assignment Is Present On DashBoard Or Not");

        try {
            getWebDriverWait().until(ExpectedConditions.invisibilityOf(getLoader()));

            positiveTestCaseGradeBook_pf.VerifyNewlyCreatedAssignmentOnGradeBookDashBoard(AssignmentName);
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found. Sort By  option not found.");
            Assert.fail();
        }
    }
    @And("Click On Unit, Assignment And Open Specific Assignment Type Vocabulary Quiz For Preview")
    public void SelectUnitAndAssignSpecificAssignmentTypeVQForCorrectAnswers() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Click On Unit, Assignment And Open Specific Assignment Type Vocabulary Quiz For Preview");
        try {
            getWebDriverWait().until(ExpectedConditions.invisibilityOf(getLoader()));
            positiveTestCaseGradeBook_pf.OpenAssignmentTypeVQForPreview();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
//        Thread.sleep(3000);
    }

    @And("Check, Verify and Open assignment For Preview")
    public void CheckVerifyAndOpenAssignmentForPreview() throws InterruptedException {
        ensurePageObjectsInitialized();
        TestRunner.startTest("Check, Verify and Open assignment For Preview From GradeBook");
        try {
            getWebDriverWait().until(ExpectedConditions.invisibilityOf(getLoader()));
            String assignmentNameForCorrect = CorrectAnswerExecutor_PF.assignmentNameForCorrect.get();
            System.out.println("Want to open assignment to preview: " + assignmentNameForCorrect);
            TestRunner.getTest().log(Status.INFO, "Want to open assignment to preview: " + assignmentNameForCorrect);
            positiveTestCaseGradeBook_pf.OpenAssignmentTypeVQForPreviewFromGradeBook(assignmentNameForCorrect);
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
        Thread.sleep(1000);
    }

    @And("Get All Questions From Preview GradeBook")
    public void GetAllQuestionsFromPreviewGradeBook() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Get All Questions From Preview GradeBook");
        try {
            getWebDriverWait().until(ExpectedConditions.invisibilityOf(getLoader()));
            positiveTestCaseGradeBook_pf.VerifyGradeBookPreviewQuestions();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
        Thread.sleep(3000);
    }

    @And("Validate and Verify That Questions From Open Assignment and Preview match")
    public void ValidateQuestionAreMatching() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Validate and Verify That Questions From Open Assignment and Preview match");
        try {
            getWebDriverWait().until(ExpectedConditions.invisibilityOf(getLoader()));
            positiveTestCaseGradeBook_pf.VerificationOfPreview();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
        Thread.sleep(3000);
    }

    @And("Validate, Check that Questions Are same as they are in Open Assignment")
    public void ValidateThatQuestionsAreSameAsTheyAreInOpenAssignment() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Validate, Check that Questions Are same as they are in Open Assignment");
        try {
            positiveTestCaseGradeBook_pf.VerificationOfPreviewAtStudentSide();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
        Thread.sleep(3000);

    }

    @And("Click On Unit, Assignment And Open Specific Assignment Type ET For Preview")
    public void SelectUnitAndAssignSpecificAssignmentTypeETForCorrectAnswers() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Click On Unit, Assignment And Open Specific Assignment Type ET For Preview");
        try {
            getWebDriverWait().until(ExpectedConditions.invisibilityOf(getLoader()));
            positiveTestCaseGradeBook_pf.OpenAssignmentTypeETForPreview();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
        Thread.sleep(3000);
    }

    @And("Click On Unit, Assignment And Open Specific Assignment Type VB For Preview")
    public void SelectUnitAndAssignSpecificAssignmentTypeVBForCorrectAnswers() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Click On Unit, Assignment And Open Specific Assignment Type Vocabulary Builder For Preview");
        try {
            getWebDriverWait().until(ExpectedConditions.invisibilityOf(getLoader()));
            positiveTestCaseGradeBook_pf.OpenAssignmentTypeVBForPreview();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
        Thread.sleep(3000);
    }

    @And("Click On Unit, Assignment And Open Specific Assignment Type DSB For Preview")
    public void SelectUnitAndAssignSpecificAssignmentTypeDSBForCorrectAnswers() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Click On Unit, Assignment And Open Specific Assignment Type Digital Student Book For Preview");
        try {
            getWebDriverWait().until(ExpectedConditions.invisibilityOf(getLoader()));
            positiveTestCaseGradeBook_pf.OpenAssignmentTypeDSBForPreview();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
        Thread.sleep(3000);
    }
}
