package StepDefinitions.GradebookModule;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Gradebook.GradeBookSummary_PF;

import java.time.Duration;

//import static StepDefinitions.Configurations.driver;

public class GradeBookSummarySteps extends Configurations {
    // Lazy initialization - get driver only when needed
    private WebDriver driver;
    private WebDriverWait wait;
    private WebElement loader;
    private Actions actions;

    Helper helper;
    GradeBookSummary_PF gradeBookSummary_pf;

    // Lazy getters - initialize only when accessed
    private WebDriver getWebDriver() {
        if (driver == null) {
            driver = Configurations.getDriver();
        }
        return driver;
    }

    private WebDriverWait getWebDriverWait() {
        if (wait == null) {
            wait = new WebDriverWait(getWebDriver(), Duration.ofSeconds(60));
        }
        return wait;
    }

    private WebElement getLoader() {
        if (loader == null) {
            loader = getWebDriver().findElement(By.xpath("//span[@role='progressbar']"));
        }
        return loader;
    }

    private Actions getActions() {
        if (actions == null) {
            actions = new Actions(getWebDriver());
        }
        return actions;
    }

    public GradeBookSummarySteps(){
        // Helper doesn't need driver immediately - it uses lazy initialization
        helper = new Helper();
        // Page objects will be initialized when driver is first accessed
    }

    // Initialize page objects when driver is first used
    private void ensurePageObjectsInitialized() {
        if (gradeBookSummary_pf == null) {
            gradeBookSummary_pf = new GradeBookSummary_PF(getWebDriver());
        }
    }

    @And("Verify and Change Status to Started for student")
    public void TeacherChangeStatusStartedStudent() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("On Summary Tab Teacher Change Status of Student From Submitted/Graded to Started");
        try {
            getWebDriverWait().until(ExpectedConditions.invisibilityOf(getLoader()));
            gradeBookSummary_pf.ChangeStudentStatus();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found. Status Not Change.");
            Assert.fail();
        }
    }

    @And("Check And Verify Un-Submit Assessment Dialogue Box")
    public void UnSubmitAssessmentDialogueBox() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Check And Verify Un-Submit Assessment Dialogue Box");
        try {
            getWebDriverWait().until(ExpectedConditions.invisibilityOf(getLoader()));

            gradeBookSummary_pf.UnsubmittedDialogueBox();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found. Dialogue Window not found");
            Assert.fail();
        }
    }

    @And("Click And verify Save Button on Dialogue Box")
    public void SaveButtonDialogueBox() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Click And verify Save Button on Dialogue Box");
        try {
            getWebDriverWait().until(ExpectedConditions.invisibilityOf(getLoader()));

            gradeBookSummary_pf.ClickSaveBtn();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found. Save Button not found on Dialogue Box.");
            Assert.fail();
        }
        Thread.sleep(3000);
    }

    @And("Click on closed tab, And verify Assessment is found or not")
    public void CloseTabVerification() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Verify That the change Status Assessment is not found in Closed Tab");
        try {
            getWebDriverWait().until(ExpectedConditions.invisibilityOf(getLoader()));
            gradeBookSummary_pf.VerifyStatusChangeAssessmentInToCloseTab();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found. Assessment found in Closed tab.");
            Assert.fail();
        }

    }

    @And("Check And verify Bulk Status Option in GradeBook Summary tab")
    public void StatusBulkGradeBook() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Now Teacher want to Change  status of assessment for All students");
        try {
            getWebDriverWait().until(ExpectedConditions.invisibilityOf(getLoader()));
            gradeBookSummary_pf.BulkStatusChangeToGradeAll();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found. Status not change to Submit-All");
            Assert.fail();
        }
    }

    @And("Verify Bulk Status Changed in GradeBook Summary tab")
    public void StatusChangedInBulkGradeBook() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Verify bulk status changed in gradeBook summary tab");
        try {
            getWebDriverWait().until(ExpectedConditions.invisibilityOf(getLoader()));
            gradeBookSummary_pf.verifyBulkStatusChangedToGradeAll();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found. Status not change to Submit-All");
            Assert.fail();
        }
    }

    @And("Check and verify Submit Assessment Dialogue Box")
    public void SubmitAssessmentDialogueBox() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Check And Verify Submit Assessment Dialogue Box");
        try {
            getWebDriverWait().until(ExpectedConditions.invisibilityOf(getLoader()));

            gradeBookSummary_pf.SubmittedAssessmentDialogueBox();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found. Dialogue Window not found");
            Assert.fail();
        }
    }
    @And("Check And verify that Bulk Status Submit Assessment is not found in Open tab")
    public void BulkAssessmentNotFoundInOpenTab() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Check And verify that Bulk Status Submit Assessment is not found in Open tab");
        try {
            getWebDriverWait().until(ExpectedConditions.invisibilityOf(getLoader()));

            gradeBookSummary_pf.VerifyBulkStatusChangeAssessmentInToOpenTab();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found. Assessment found in Closed tab.");
            Assert.fail();
        }
    }

    @And("Check And verify that Status Started Assessment is found in Open tab")
    public void StartedStatusAssessmentFoundInOpenTab() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Check And verify that Started Status Assessment is found in Open tab");
        try {
            getWebDriverWait().until(ExpectedConditions.invisibilityOf(getLoader()));
            gradeBookSummary_pf.VerifyStartedStatusChangeAssessmentInToOpenTab();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found. Assessment found in Closed tab.");
            Assert.fail();
        }
    }


    @And("Verify if the assessment is found in the closed tab After bulk Status Change to Submit-All")
    public void ClosedTabVerificationAfterBulkStatusUpdate() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Verify That the change Status Assessment is found in Closed Tab");
        try {
            getWebDriverWait().until(ExpectedConditions.invisibilityOf(getLoader()));

            gradeBookSummary_pf.VerifyBulkStatusChangeAssessmentInToCloseTab();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found. Assessment Not found in Closed tab.");
            Assert.fail();
        }
    }

}
