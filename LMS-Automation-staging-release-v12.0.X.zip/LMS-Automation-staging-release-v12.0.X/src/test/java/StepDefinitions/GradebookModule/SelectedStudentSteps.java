package StepDefinitions.GradebookModule;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import io.cucumber.java.mk_latn.No;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Classes.AddClass_PF;
import pageFactory.Gradebook.*;
import pageFactory.StudentsModule.AddNewStudent_PF;

import java.time.Duration;

//import static StepDefinitions.Configurations.driver;

public class SelectedStudentSteps extends Configurations {
    // Lazy initialization - get driver only when needed
    private WebDriver driver;
    private WebDriverWait wait;
    private WebElement loader;
    private Actions actions;

    Helper helper;
    SelectedStudent_PF selectedStudent_pf;

    // Lazy getters - initialize only when accessed
    private WebDriver getWebDriver() {
        if (driver == null) {
            driver = Configurations.getDriver();
        }
        return driver;
    }

    private WebDriverWait getWebDriverWait() {
        if (wait == null) {
            wait = new WebDriverWait(getWebDriver(), Duration.ofSeconds(60));
        }
        return wait;
    }

    private WebElement getLoader() {
        if (loader == null) {
            loader = getWebDriver().findElement(By.xpath("//span[@role='progressbar']"));
        }
        return loader;
    }

    private Actions getActions() {
        if (actions == null) {
            actions = new Actions(getWebDriver());
        }
        return actions;
    }

    public SelectedStudentSteps() {
        // Helper doesn't need driver immediately - it uses lazy initialization
        helper = new Helper();
        // Page objects will be initialized when driver is first accessed
    }

    // Initialize page objects when driver is first used
    private void ensurePageObjectsInitialized() {
        if (selectedStudent_pf == null) {
            selectedStudent_pf = new SelectedStudent_PF(getWebDriver());
        }
    }

    @And("Verify And Click on Selected Student Tab")
    public void VerifyAndClickSelectedStudentTab() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Verify And Click on Selected Student Tab");
        try {
            getWebDriverWait().until(ExpectedConditions.invisibilityOf(getLoader()));
            selectedStudent_pf.clickSelectedStudent();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found. Select Student Tab not clicked.");
            Assert.fail();
        }
        Thread.sleep(3000);
    }

    @And("Verify and UnCheck Mark as graded checkbox")
    public void UncheckMarkAsGradedCheckbox() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Verify and UnCheck Mark as graded checkbox");
        try {
            getWebDriverWait().until(ExpectedConditions.invisibilityOf(getLoader()));
            selectedStudent_pf.MarkAsGradedCheckbox();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found. checkBox not found.");
            Assert.fail();
        }
        Thread.sleep(3000);
    }

    @And("Check And add New Student Points")
    public void CheckAndAddNewStudentPoints() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Verify pagination and Add New Student Points");
        try {
            getWebDriverWait().until(ExpectedConditions.invisibilityOf(getLoader()));
            selectedStudent_pf.StudentPoints();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found. checkBox not found.");
            Assert.fail();
        }
        Thread.sleep(3000);
    }

    @And("Check And add New Student Points And Comments In Vertical View")
    public void CheckAndAddNewStudentPointsAndCommentsInVerticalView() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Verify pagination and Add New Student Points and Comments in Vertical View");
        try {
            getWebDriverWait().until(ExpectedConditions.invisibilityOf(getLoader()));
            selectedStudent_pf.StudentPointsAndCommentsInVerticalView();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found. checkBox not found.");
            Assert.fail();
        }
        Thread.sleep(3000);
    }

    @And("Check And Validate The Show Correct Answers In Each Question")
    public void ValidateTheShowCorrectAnswersInEachQuestion() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Check and Validate the Show Correct Answers in Each Question");
        try {
            getWebDriverWait().until(ExpectedConditions.invisibilityOf(getLoader()));
            selectedStudent_pf.checkShowsCorrectAnswersOfQuestion();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found. checkBox not found.");
            Assert.fail();
        }
        Thread.sleep(3000);
    }

    @And("Check And Validate The Show Correct Answers In Each Question In Pagination")
    public void ValidateTheShowCorrectAnswersInEachQuestionInPagination() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Check and Validate the Show Correct Answers in Each Question in Pagination");
        try {
            getWebDriverWait().until(ExpectedConditions.invisibilityOf(getLoader()));
            selectedStudent_pf.checkShowsCorrectAnswersOfQuestionInPagination();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found. checkBox not found.");
            Assert.fail();
        }
        Thread.sleep(3000);
    }

    @And("Check And Validate The Grades Updated and Show Correct Answers Of Each Question")
    public void ValidateTheGradesUpdatedAndShowCorrectAnswersOfEachQuestion() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Check and Validate the Grades Updated and Show Correct Answers of Each Question");
        try {
            getWebDriverWait().until(ExpectedConditions.invisibilityOf(getLoader()));
            selectedStudent_pf.updateGradesOfEachQuestionAndShowsCorrectAnswers();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found. checkBox not found.");
            Assert.fail();
        }
        Thread.sleep(3000);
    }

    @And("Check And Validate The Show Assignment Notes In Each Assignment")
    public void ValidateTheShowAssignmentNotesInEachAssignment() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Check and Validate the Show Assignment Notes in Each Assignment");
        try {
            getWebDriverWait().until(ExpectedConditions.invisibilityOf(getLoader()));
            selectedStudent_pf.checkShowsAssignmentNotesOfQuestion();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found. checkBox not found.");
            Assert.fail();
        }
        Thread.sleep(3000);
    }

    @And("Check, Validate And Compare Assignment Notes Both Student And Teacher")
    public void ValidateAndCompareAssignmentNotes() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Check, Validate And Compare Assignment Notes Both Student And Teacher");
        try {
            getWebDriverWait().until(ExpectedConditions.invisibilityOf(getLoader()));
            selectedStudent_pf.ValidateStudentAndTeacherNotes();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found. checkBox not found.");
            Assert.fail();
        }
        Thread.sleep(3000);
    }

    @And("Check And Validate The Copy Text In Each Assignment")
    public void ValidateTheCopyTextInEachAssignment() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Check and Validate the Copy text in Each Assignment");
        try {
            getWebDriverWait().until(ExpectedConditions.invisibilityOf(getLoader()));
            selectedStudent_pf.checkCopyTextOfAssignment();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found. checkBox not found.");
            Assert.fail();
        }
        Thread.sleep(3000);
    }

    @And("Check And Validate The Read Aloud In Each Assignment")
    public void ValidateTheReadAloudInEachAssignment() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Check and Validate the Read Aloud in Each Assignment");
        try {
            getWebDriverWait().until(ExpectedConditions.invisibilityOf(getLoader()));
            selectedStudent_pf.checkReadAloudOfAssignment();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found. checkBox not found.");
            Assert.fail();
        }
        Thread.sleep(3000);
    }

    @And("Check And Validate The Font Size In Each Assignment")
    public void ValidateTheFontSizeInEachAssignment() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Check and Validate the Font Size in Each Assignment");
        try {
            getWebDriverWait().until(ExpectedConditions.invisibilityOf(getLoader()));
            selectedStudent_pf.checkFontSizeOfAssignment();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found. checkBox not found.");
            Assert.fail();
        }
        Thread.sleep(3000);
    }

    @And("Verify and click on Mark as graded Checkbox")
    public void ClickMarkAsGradedCheckBox() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Verify and click on Mark as graded Checkbox");
        try {
            getWebDriverWait().until(ExpectedConditions.invisibilityOf(getLoader()));
            selectedStudent_pf.ClickMarkAsGraded();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found. checkBox not found.");
            Assert.fail();
        }
    }


    @And("Check , Verify Student points in close tab")
    public void CheckVerifyStudentPointsCloseTab() throws InterruptedException{
            ensurePageObjectsInitialized();
        TestRunner.startTest("Check , Verify Student points in close tab");
            try {

                selectedStudent_pf.VerifyStudentPoints();
            } catch (NoSuchElementException | ElementNotInteractableException e) {
                System.out.println(e);
                System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
                Assert.fail();
            }
    }


    // Update Final Score

    @And("Verify and UnCheck Mark as graded checkbox on Summary Tab")
    public void VerifyUnCheckMarkAsGradedCheckboxOnSummaryTab() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Verify and UnCheck Mark as graded checkbox on Summary Tab");
        try {

            selectedStudent_pf.UnCheckMarkAsGradedCheckBox();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found.");
            Assert.fail();
        }
    }

    @And("Check Verify and Update Final Scores")
    public void CheckVerifyUpdateFinalScores() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Check Verify and Update Final Scores");
        try {

            selectedStudent_pf.updateFinalScores();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found.");
            Assert.fail();
        }
    }

    @And("Verify Bulk Score Changed in GradeBook Summary tab")
    public void ScoreChangedInBulkGradeBook() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Verify bulk score changed in gradeBook summary tab");
        try {
            getWebDriverWait().until(ExpectedConditions.invisibilityOf(getLoader()));
            selectedStudent_pf.verifyBulkScoresChangedToGradeAllStudents();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found.");
            Assert.fail();
        }
    }

    @And("Click On Apply Button in Final Scores")
    public void ClickOnApplyButtonFinalScores() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Click On Apply Button in Final Scores");
        try {

            selectedStudent_pf.ClickOnApplyButton();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found.");
            Assert.fail();
        }
    }

    @And("Verify Update Score Dialogue Box")
    public void VerifyUpdateScoreDialogueBox() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Verify Update Score Dialogue Box");
        try {

            selectedStudent_pf.UpdateScoreDialogueBox();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found.");
            Assert.fail();
        }
    }

    @And("Verify, Click on Save Button Update Score Dialogue Box")
    public void VerifyClickSaveButtonUpdateScoreDialogueBox() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Verify, Click on Save Button Update Score Dialogue Box");
        try {

            selectedStudent_pf.ClickSaveBtnFinalScore();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found.");
            Assert.fail();
        }
    }

    @And("Click and check Mark As graded CheckBox")
    public void ClickAndCheckMarkAsGradedCheckBox() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Click and check Mark As graded CheckBox");
        try {

            selectedStudent_pf.CheckBoxMarkAsGraded();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found.");
            Assert.fail();
        }
    }

    @And("Verify And Check new Final Score Updated At Student Side or not")
    public void VerifyAndCheckNewFinalScoreUpdatedAtStudentSideOrNot() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Verify And Check new Final Score Updated At Student Side or not");
        try {

            selectedStudent_pf.VerifyFinalScoresAtStudentSide();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found.");
            Assert.fail();
        }
    }


    // final scores for specific Student

    @And("Verify and Get Student Who's status is submitted")
    public void VerifyGetStudentStatusIsSubmitted() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Verify and Get Student Who's status is submitted");
        try {

            selectedStudent_pf.GetStudentWithSubmittedStatus();

        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found.");
            Assert.fail();
        }
        Thread.sleep(3000);
    }

    @And("Verify Scores Update in Assignment Summary or not")
    public void VerifyScoresUpdateInAssignmentSummaryOrNot() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Verify Scores Update in Assignment Summary or not");
        try {

            Thread.sleep(3000);
            selectedStudent_pf.ScoresUpdateInAssignmentSummary();

        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found.");
            Assert.fail();
        }

    }

    @And("Verify that New Scores for specific Student match at Student Side")
    public void SpecificStudentScoreMatchAtStudentSide() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Verify that New Scores for specific Student match at Student Side");
        try {

            Thread.sleep(3000);
            selectedStudent_pf.VerifyScoresWithNewScores();

        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found.");
            Assert.fail();
        }
    }

    // Verify Question Sequence In Summary Tab

    @And("Verify Question Sequence In Summary Tab")
    public void VerifyQuestionSequenceInSummaryTab() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Verify Question Sequence In Summary Tab");
        try {

//            Thread.sleep(3000);
            selectedStudent_pf.QuestionSequenceVerification();

        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found.");
            Assert.fail();
        }
    }

    @And("Verify Start and End Date Present")
    public void VerifyStartEndDatePresent() throws InterruptedException {
        ensurePageObjectsInitialized();
        TestRunner.startTest("Verify Start and End Date Present");
        try {

//            Thread.sleep(3000);
            selectedStudent_pf.StartAndEndDatePresent();

        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found.");
            Assert.fail();

        }
    }

    @And("Validate Standard Icon Presence on Summary Tab")
    public void ValidateStandardIconPresenceOnSummaryTab() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Validate Standard Icon Presence on Summary Tab");
        try {

//            Thread.sleep(3000);
            selectedStudent_pf.StandardIconSummaryTab();

        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found.");
            Assert.fail();

        }
    }

    @And("Verify Assignment Name Present on Summary Tab")
    public void VerifyAssignmentNamePresentAndMatchOnSummaryTab() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Verify Assignment Name Present on Summary Tab");
        try {

//            Thread.sleep(3000);
            selectedStudent_pf.AssignmentPresenceOnSummaryTab();

        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found.");
            Assert.fail();

        }
    }


    @And("Check, Validate And Click on Points Button")
    public void CheckValidateAndClickOnPointsButton() throws InterruptedException {
        ensurePageObjectsInitialized();
        TestRunner.startTest("Check, Validate And Click on Points Button");
        try {
            selectedStudent_pf.clickOnPointsButton();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Check, Validate And Get Student Points And Status")
    public void CheckValidateAndGetStudentPointsAndStatus() throws InterruptedException {
        ensurePageObjectsInitialized();
        TestRunner.startTest("Check, Validate And Get Student Points And Status");

        try {
            selectedStudent_pf.getStudentPointAndStatus();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Check Validate and Get Overall Pts From Grade By Student")
    public void CheckValidateAndGetOverallPtsFromGradeByStudent() throws InterruptedException {
        ensurePageObjectsInitialized();
        TestRunner.startTest("Check Validate and Get Overall Pts From Grade By Student");

        try {
            selectedStudent_pf.getPtsOverallFromGradeByStudent();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Check, Validate and Get Status From Grade By Student")
    public void CheckValidateAndGetStatusFromGradeByStudent() throws InterruptedException {
        ensurePageObjectsInitialized();
        TestRunner.startTest("Check, Validate and Get Status From Grade By Student");

        try {
            selectedStudent_pf.getStatusFromGradeByStudent();

        } catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Check, Validate and Get Student Name From Grade By Student")
    public void CheckValidateAndGetStudentNameFromGradeByStudent() throws InterruptedException {
        ensurePageObjectsInitialized();
        TestRunner.startTest("Check, Validate and Get Student Name From Grade By Student");

        try {
            selectedStudent_pf.getStudentNameFromGradeByStudent();

        } catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Check, Validate and Add Comments on Each Question")
    public void CheckValidateAndAddCommentsOnEachQuestion() throws InterruptedException {
        ensurePageObjectsInitialized();
        TestRunner.startTest("Check, Validate and Add Comments on Each Question");

        try {
            selectedStudent_pf.addCommentOnEachQuestion();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Check, Verify Teacher Comments on Each Question From Student Side")
    public void CheckVerifyTeacherCommentsOnEachQuestionFromStudentSide() throws InterruptedException {
        ensurePageObjectsInitialized();
        TestRunner.startTest("Check, Verify Teacher Comments on Each Question From Student Side");

        try {

            selectedStudent_pf.verifyTeachersCommentsOnStudentSide();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }



    @And("Check And add New Student Points And Comments In Vertical View In Grade By Student Tab")
    public void CheckAndAddNewStudentPointsAndCommentsInVerticalViewInGradeByStudentTab() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Verify pagination and Add New Student Points and Comments in Vertical View In Grade By Student Tab");
        try {
            getWebDriverWait().until(ExpectedConditions.invisibilityOf(getLoader()));
            selectedStudent_pf.StudentPointsAndCommentsInVerticalView();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found. checkBox not found.");
            Assert.fail();
        }
        Thread.sleep(3000);
    }

    @And("Check, Validate that Only Ungraded Toggle is Already Selected")
    public void CheckValidateThatOnlyUngradedToggleIsAlreadySelected() throws InterruptedException {
        ensurePageObjectsInitialized();
        TestRunner.startTest("Check, Validate that Only Ungraded Toggle is Already Selected");

        try {
            selectedStudent_pf.VerifyOnlyUngradedToggle();
        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found.");
            Assert.fail();
        }
        Thread.sleep(3000);
    }

    @And("Check, Validate that Ungraded Toggle Label is Display")
    public void CheckValidateThatUngradedToggleLabelIsDisplay() throws InterruptedException {
        ensurePageObjectsInitialized();
        TestRunner.startTest("Check, Validate that Ungraded Toggle Label is Display");

        try {
            selectedStudent_pf.VerifyOnlyUnGradedLabelIsDisplay();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found.");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Check, Validate that in Dropdown None Found is Display")
    public void CheckValidateThatInDropdownNoneFoundIsDisplay() throws InterruptedException {
        ensurePageObjectsInitialized();
        TestRunner.startTest("Check, Validate that in Dropdown None Found is Display");
        try {
            selectedStudent_pf.verifyDropdownOption();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found.");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Check, Validate that Status is Disable")
    public void CheckValidateThatStatusIsDisable() throws InterruptedException {
        ensurePageObjectsInitialized();
        TestRunner.startTest("Check, Validate that Status is Disable");
        try {
            selectedStudent_pf.verifyStatusIsDisable();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found.");
            Assert.fail();
        }

    }

//    Grade By Questions

    @And("Check, Validate and Click on Grade By Questions Activity")
    public void CheckValidateAndClickOnGradeByQuestionsActivity() throws InterruptedException {
        ensurePageObjectsInitialized();
        TestRunner.startTest("Check, Validate and Click on Grade By Questions Activity");

        try {
            selectedStudent_pf.clickGradeByQuestionsTab();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found.");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Check, Validate and Get Questions Table on Grade By Questions")
    public void CheckValidateAndGetQuestionsTableOnGradeByQuestions() throws InterruptedException {
        ensurePageObjectsInitialized();
        TestRunner.startTest("Check, Validate and Get Questions Table on Grade By Questions");

        try {
            selectedStudent_pf.getQuestionsTable();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Check, Validate and get Standard information on Grade By Questions")
    public void CheckValidateAndGetStandardInformationOnGradeByQuestions() throws InterruptedException {
        ensurePageObjectsInitialized();
        TestRunner.startTest("Check, Validate and get Standard information on Grade By Questions");

        try {
            selectedStudent_pf.getStandardsFromGradeByQuestions();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Check, Verify standard Match On Grade By Questions")
    public void CheckVerifyStandardMatchOnGradeByStudent() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Check, Verify standard Match On Grade By Questions");

        try {
            selectedStudent_pf.validateStandardMatchOnGradeByQuestions();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Check Validate And Click on Edit All Grade Button on Grade By Questions")
    public void CheckValidateAndClickOnEditAllGradeButtonOnGradeByQuestions() throws InterruptedException {
        ensurePageObjectsInitialized();
        TestRunner.startTest("Check Validate And Click on Edit All Grade Button on Grade By Questions");

        try {
            selectedStudent_pf.editAllGradesFunctionality();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Check, Verify Edit all Grades % value Also update in Close Tab")
    public void CheckVerifyEditAllGradesAlsoUpdateInCloseTab() throws InterruptedException {
        ensurePageObjectsInitialized();
        TestRunner.startTest("Check, Verify Edit all Grades % value Also update in Close Tab");
        try {
            selectedStudent_pf.verifyPercentageAlsoUpdate();
        } catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Check, Validate and Click on Points on Grade By Questions")
    public void CheckValidateAndClickOnPointsOnGradeByQuestions() throws InterruptedException {
        ensurePageObjectsInitialized();
        TestRunner.startTest("Check, Validate and Click on Points on Grade By Questions");

        try {
            selectedStudent_pf.clickPointsOption();

        } catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Check, Validate and Click on Edit All Grades in Points")
    public void CheckValidateAndClickOnEditAllGradesInPoints() throws InterruptedException {
        ensurePageObjectsInitialized();
        TestRunner.startTest("Check, Validate and Click on Edit All Grades in Points");

        try {
            selectedStudent_pf.editAllGradesFunctionalityInPoints();

        } catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Check, Validate New Student Points After Edit All Grades")
    public void CheckValidateNewStudentPointsAfterEditAllGrades() throws InterruptedException {
        ensurePageObjectsInitialized();
        TestRunner.startTest("Check, Validate New Student Points After Edit All Grades");

        try {
            selectedStudent_pf.VerifyNewStudentPointsAfterEditAll();

        } catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Check, Verify that After Edit All Grades New Points Update For Each Question")
    public void CheckVerifyThatAfterEditAllGradesNewPointsUpdateForEachQuestion() throws InterruptedException {
        ensurePageObjectsInitialized();
        TestRunner.startTest("Check, Verify that After Edit All Grades New Points Update For Each Question");

        try {
            selectedStudent_pf.validateNewPointsUpdateForEachQuestion();

        } catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Check, Validate Get Points and Click on Each Question on Grade By Questions")
    public void CheckValidateGetPointsAndClickOnEachQuestionOnGradeByQuestions() throws InterruptedException {
        ensurePageObjectsInitialized();
        TestRunner.startTest("Check, Validate Get Points and Click on Each Question on Grade By Questions");

        try {
            selectedStudent_pf.getPointsAndVerifyEachQuestionOnGradeByQuestions();

        } catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Check, Validate And Click on Standards Correlation")
    public void CheckValidateAndClickOnStandardsCorrelation() throws InterruptedException {
        ensurePageObjectsInitialized();
        TestRunner.startTest("Check, Validate And Click on Standards Correlation");

        try {
            selectedStudent_pf.validateAndClickStandardsCorrelation();

        } catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Check, Verify Standards Correlation Prompt Display")
    public void CheckVerifyStandardsCorrelationPromptDisplay() throws InterruptedException {
        ensurePageObjectsInitialized();
        TestRunner.startTest("Check, Verify Standards Correlation Prompt Display");

        try {
            selectedStudent_pf.validateStandardsCorrelationPrompt();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
        Thread.sleep(1000);
    }

    @And("Check, Verify Standards Dropdown on Prompt")
    public void CheckVerifyStandardsDropdownOnPrompt() throws InterruptedException {
        ensurePageObjectsInitialized();
        TestRunner.startTest("Check, Verify Standards Dropdown on Prompt");

        try {
            selectedStudent_pf.standardsDropdown();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
        Thread.sleep(1000);
    }

    @And("Check, Verify Standards View Is Already Clicked")
    public void CheckVerifyStandardsViewIsAlreadyChecked() throws InterruptedException {
        ensurePageObjectsInitialized();
        TestRunner.startTest("Check, Verify Standards View Is Already Clicked");

        try {
            selectedStudent_pf.validateStandardsViewClicked();

        } catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
        Thread.sleep(1000);
    }

    @And("Check, Validate Get All Standards From Standards View")
    public void CheckValidateGetAllStandardsFromStandardsView() throws InterruptedException {
        ensurePageObjectsInitialized();
        TestRunner.startTest("Check, Validate Get All Standards From Standards View");

        try {
            selectedStudent_pf.getAllStandardsFromStandardsView();
            Thread.sleep(500);
            selectedStudent_pf.closeDialogueBox();

        } catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
        Thread.sleep(1000);
    }

    @And("Check, Verify And Click on Course View")
    public void CheckVerifyAndClickOnCourseView() throws InterruptedException {
        ensurePageObjectsInitialized();
        TestRunner.startTest("Check, Verify And Click on Course View");

        try {
            selectedStudent_pf.clickCoursesView();

        } catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
        Thread.sleep(1000);
    }

    @And("Check, Verify And Get All Courses View List From Standards Correlation")
    public void CheckVerifyAndGetAllCoursesViewListFromStandardsCorrelation() throws InterruptedException {
        ensurePageObjectsInitialized();
        TestRunner.startTest("Check, verify And Get All Courses View List From Standards Correlation");

        try {
            selectedStudent_pf.getCoursesViewList();
            selectedStudent_pf.closeDialogueBox();
        } catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }

    }

    @And("Check, Validate and get Standard information on Summary")
    public void CheckValidateAndGetStandardInformationOnSummary() throws InterruptedException {
        ensurePageObjectsInitialized();
        TestRunner.startTest("Check, Validate and get Standard information on Grade By Questions");

        try {
            selectedStudent_pf.getStandardsFromSummary();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Check, Verify standard Match On Summary")
    public void CheckVerifyStandardMatchOnSummary() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Check, Verify standard Match On Grade By Questions");

        try {
            selectedStudent_pf.validateStandardMatchOnSummary();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Check, Validate and Click on Print on Summary")
    public void CheckValidateAndClickOnPrintOnSummary() throws InterruptedException {
        ensurePageObjectsInitialized();
        TestRunner.startTest("Check, Validate and Click on Print on Summary");

        try {
            selectedStudent_pf.printOnSummary();

        } catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Check, Validate Student List on Summary Screen")
    public void CheckValidateStudentListOnSummaryScreen() throws InterruptedException {
        ensurePageObjectsInitialized();
        TestRunner.startTest("Check, Validate Student List on Summary Screen");

        try {
            selectedStudent_pf.validateStudentListOnSummary();

        } catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
        Thread.sleep(1000);
    }

    @And("Check, Validate and Verify Question List on GradeBy Questions")
    public void CheckValidateAndVerifyQuestionListOnGradeByQuestions() throws InterruptedException {
        ensurePageObjectsInitialized();
        TestRunner.startTest("Check, Validate and Verify Question List on GradeBy Questions");

        try {
            selectedStudent_pf.verifyQuestionListDisplay();

        } catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
        Thread.sleep(1000);

    }


 }
