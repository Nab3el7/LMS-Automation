
package StepDefinitions.GradebookModule;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Assignmment.CorrectAnswerExecutor_PF;
import pageFactory.Gradebook.GradingDeleteAssignment_PF;

import java.awt.*;
import java.time.Duration;


public class GradingDeleteAssignmentSteps extends Configurations {
    WebDriver driver = Configurations.getDriver();

    GradingDeleteAssignment_PF gradingDeleteAssignmentPf;
    public WebDriverWait wait;
    Helper helper;

    WebElement loader = driver.findElement(By.xpath("//span[@role='progressbar']"));

    public GradingDeleteAssignmentSteps(){
        gradingDeleteAssignmentPf = new GradingDeleteAssignment_PF(driver);
        helper = new Helper();
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
    }

    @And("Verify And Select Student Assignment For Delete Into Table")
    public void SelectStudentsAssignmentIntoTable() throws InterruptedException {
        TestRunner.startTest( " Select the student assignment for Delete into table and print **********");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            gradingDeleteAssignmentPf.selectQuizForDelete();
            System.out.println("Test Case Passed    :   Delete students assignment table clicked successfully");
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println();
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
            Assert.fail();
        }
        helper.takeScreenshot(driver , Thread.currentThread().getStackTrace()[1].getMethodName());
    }

    @And("Verify Delete Prompt Is Displayed")
    public void VerifyDeletePrompt() throws InterruptedException {
        TestRunner.startTest("Verify Delete prompt is displayed or not");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            gradingDeleteAssignmentPf.verifyPrompt();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println();
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  Exception is found");
            Assert.fail();
        }
        Thread.sleep(3000);
        helper.takeScreenshot(driver , Thread.currentThread().getStackTrace()[1].getMethodName());
    }

    @And("Verify And Get Delete Assignment Name")
    public void VerifyDeleteAssignmentName() throws InterruptedException {
        TestRunner.startTest( " Verify and get Delete assignment name  **********");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            gradingDeleteAssignmentPf.getAssignmentName();
            System.out.println("Test Case Passed    :   Delete assignment displayed successfully");
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println();
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
            Assert.fail();
        }
        Thread.sleep(3000);
        helper.takeScreenshot(driver , Thread.currentThread().getStackTrace()[1].getMethodName());
    }

    @And("Delete The Assignment Of A Particular Student")
    public void VerifyDeleteAssignmentOfParticularStudent() throws InterruptedException {
        TestRunner.startTest( " Verify Delete of a particular student  **********");
        try {
            gradingDeleteAssignmentPf.DeleteAssignmentForParticularStudent();
            System.out.println("Test Case Passed    :   Delete assignment of a particular student successfully");
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println();
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
            Assert.fail();
        }
        Thread.sleep(3000);
        helper.takeScreenshot(driver , Thread.currentThread().getStackTrace()[1].getMethodName());
    }

    @And("Delete The Assignment Of All Students")
    public void VerifyDeleteAssignmentOfAllStudents() throws InterruptedException {
        TestRunner.startTest( " Verify Delete of a all students  **********");
        try {
            gradingDeleteAssignmentPf.DeleteAssignmentForAllStudent();
            System.out.println("Test Case Passed    :   Delete assignment of all students successfully");
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println();
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
            Assert.fail();
        }
        Thread.sleep(1000);
        helper.takeScreenshot(driver , Thread.currentThread().getStackTrace()[1].getMethodName());
    }

    @And("Search the Delete Assignment Into Student Panel")
    public void VerifyDeletedAssignmentIntoStudentPanel() throws InterruptedException {
        TestRunner.startTest( " Search the Delete assignment into student panel  **********");
        try {
            gradingDeleteAssignmentPf.searchDeletedAssignmentIntoStudentPanel();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println();
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
        helper.takeScreenshot(driver , Thread.currentThread().getStackTrace()[1].getMethodName());
    }



    // Deletion for specific student
    @Given("Check, Verify and Open assignment that Attempted with Correct Answers and you want to delete")
    public void check_and_verify_AttemptedCorrect_assignment_is_present() throws InterruptedException {
        TestRunner.startTest(" Check, Verify and Open assignment that Attempted with Correct Answers and you want to delete");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            String assignmentNameForCorrect = CorrectAnswerExecutor_PF.assignmentNameForCorrect.get();
            System.out.println("Want to search, open and delete assignment: " + assignmentNameForCorrect);
            TestRunner.getTest().log(Status.INFO, "Want to search, open and delete assignment: " + assignmentNameForCorrect);
            gradingDeleteAssignmentPf.searchAssignmentNames(assignmentNameForCorrect);
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }


    @And("Validate, Check Delete Assignment Name on Delete Assignment Dialogue Box")
    public void ValidateCheckDeleteAssignmentNameOnDeleteAssignmentDialogueBox() throws InterruptedException{
        TestRunner.startTest("Validate, Check Delete Assignment Name on Delete Assignment Dialogue Box");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            gradingDeleteAssignmentPf.VerifyAssignmentName();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Delete Assignment For Particular Student")
    public void DeleteAssignmentForParticularStudent() throws InterruptedException{
        TestRunner.startTest("Delete Assignment For Particular Student");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            gradingDeleteAssignmentPf.DeleteAssignmentForSpecificStudent();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Click On Yes Option of delete Assignment")
    public void ClickOnYesOptionOfDeleteAssignment() throws InterruptedException{
        TestRunner.startTest("Click On Yes Option of delete Assignment");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            gradingDeleteAssignmentPf.DeleteAssignmentYesButton();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  Exception is found");
            Assert.fail();
        }
    }

    @And("Check and Search Assignment name in Search Box")
    public void CheckSearchAssignmentNameInSearchBox() throws InterruptedException{
        TestRunner.startTest("Check and Search Assignment name in Search Box");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            String assignmentNameForCorrect = CorrectAnswerExecutor_PF.assignmentNameForCorrect.get();
            System.out.println("Want to assignment in search box: " + assignmentNameForCorrect);
            TestRunner.getTest().log(Status.INFO, "Want to assignment in search box: " + assignmentNameForCorrect);
            gradingDeleteAssignmentPf.searchAssignmentThatIsDeleted(assignmentNameForCorrect);
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    // delete assessment before student attempt
    @And("Click On Tab, Verify that Assessment is Present in Open tab")
    public void ClickOnTabVerifyThatAssessmentIsPresentInOpenTab() throws InterruptedException{
        TestRunner.startTest("Click On Tab, Verify that Assessment is Present in Open tab");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            gradingDeleteAssignmentPf.NewAssignmentInOpenTab();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Click On Tab, Start And Resume Specific Assignment With Correct Answers")
    public void ClickOnTabStartAndResumeSpecificAssignmentWithCorrectAnswers() throws InterruptedException , AWTException {
        TestRunner.startTest("Click On Tab, Start And Resume Specific Assignment With Correct Answers");
        try {

            gradingDeleteAssignmentPf.SelectAssignmentForCorrectAnswersAndResume();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    // Assignment Delete for All students

    @And("Delete Assignment For All Students")
    public void DeleteAssignmentForAllStudents() throws InterruptedException{
        TestRunner.startTest("Delete Assignment For All Students");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            gradingDeleteAssignmentPf.AssignmentDeleteForAllStudents();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }


    // UnSubmit Assignment
    @And("Check, Verify and Open assignment that Attempted with Correct Answers and you want to UnSubmit")
    public void CheckVerifyAndOpenAssignmentThatAttemptedWithCorrectAnswersAndYouWantToUnSubmit() throws InterruptedException{
        TestRunner.startTest("Check, Verify and Open assignment that Attempted with Correct Answers and you want to UnSubmit");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            String assignmentNameForCorrect = CorrectAnswerExecutor_PF.assignmentNameForCorrect.get();
            System.out.println("Want to open assignment to unSubmit: " + assignmentNameForCorrect);
            TestRunner.getTest().log(Status.INFO, "Want to open assignment to unSubmit: " + assignmentNameForCorrect);
            gradingDeleteAssignmentPf.SearchAssignmentForUnSubmit(assignmentNameForCorrect);
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Verify UnSubmit Prompt Is Displayed in GradeBook")
    public void VerifyUnSubmitPromptIsDisplayed() throws InterruptedException{
        TestRunner.startTest("Verify UnSubmit Prompt Is Displayed");

        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            gradingDeleteAssignmentPf.verifyPrompt();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println();
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  Exception is found");
            Assert.fail();
        }
        Thread.sleep(3000);
        helper.takeScreenshot(driver , Thread.currentThread().getStackTrace()[1].getMethodName());

    }

    @And("Validate, Check UnSubmit Assignment Name on UnSubmit Assignment Dialogue Box")
    public void ValidateCheckDeleteAssignmentNameOnUnSubmitAssignmentDialogueBox() throws InterruptedException{
        TestRunner.startTest("Validate, Check Delete Assignment Name on UnSubmit Assignment Dialogue Box");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            gradingDeleteAssignmentPf.VerifyAssignmentNameForUnSubmit();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("UnSubmit Assignment For All Students")
    public void UnSubmitAssignmentForAllStudents() throws InterruptedException{
        TestRunner.startTest("UnSubmit Assignment For All Students");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            gradingDeleteAssignmentPf.AssignmentUnSubmitForAllStudents();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("UnSubmit Assignment For Specific Student")
    public void UnSubmitAssignmentForSpecificStudent() throws InterruptedException{
        TestRunner.startTest("UnSubmit Assignment For Specific Student");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            gradingDeleteAssignmentPf.AssignmentUnSubmitForSpecificStudent();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }
}
