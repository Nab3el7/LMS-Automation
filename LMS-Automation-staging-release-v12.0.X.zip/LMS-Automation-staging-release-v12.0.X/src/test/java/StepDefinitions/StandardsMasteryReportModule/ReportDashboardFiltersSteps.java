package StepDefinitions.StandardsMasteryReportModule;

import StandardsMasteryReport.ReportDashboardFilters_PF;
import StepDefinitions.Configurations;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class ReportDashboardFiltersSteps extends Configurations {
    WebDriver driver = Configurations.getDriver();

    public WebDriverWait wait;

    ReportDashboardFilters_PF reportDashboardFiltersPF;

    @FindBy(xpath = "//span[@role='progressbar']")
    WebElement loader;

    public static ThreadLocal<String> selectedReportDistrict = ThreadLocal.withInitial(() -> "FLDOE District");
    public static ThreadLocal<String> selectedReportSchool = ThreadLocal.withInitial(() -> "Florida ES");
    public static ThreadLocal<String> selectedReportTeacher = ThreadLocal.withInitial(() -> "Harry Potter");
    public static ThreadLocal<String> selectedReportClass = ThreadLocal.withInitial(() -> "FL Grade 5");

    public ReportDashboardFiltersSteps() {
        reportDashboardFiltersPF = new ReportDashboardFilters_PF(driver);
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
    }

    @And("Select Reports Dashboard District Filters")
    public void selectReportsDashboardDistrict() {
        TestRunner.startTest( "Select Reports Dashboard District Filters");
        try {
            reportDashboardFiltersPF.selectReportDashboardDistrict();
        } catch (Exception e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
            Assert.fail();
        }
    }

    @And("Select Reports Dashboard School Filters")
    public void selectReportsDashboardSchool() {
        TestRunner.startTest( " Select Reports Dashboard School Filters");
        try {
            reportDashboardFiltersPF.selectReportDashboardSchool();
        } catch (Exception e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("Select Reports Dashboard Teacher Filters")
    public void selectReportsDashboardTeacher() {
        TestRunner.startTest( "Select Reports Dashboard Teacher Filters");
        try {
            reportDashboardFiltersPF.selectReportDashboardTeacher(selectedReportTeacher.get());
        } catch (Exception e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("Select Reports Dashboard Classes Filters")
    public void selectReportsDashboardClasses() {
        TestRunner.startTest( "Select Reports Dashboard Classes Filters");
        try {
            reportDashboardFiltersPF.selectReportDashboardClasses(selectedReportClass.get());
        } catch (Exception e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("Click on Apply Report Dashboard Filter Button")
    public void clickReportsDashboardFiltersButton(){
        TestRunner.startTest( "Click on Apply Report Dashboard Filter Button");
        try {
            reportDashboardFiltersPF.applyReportDashboardFilter();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("Validate Student Standards Mastery Overview Data On Report Dashboard")
    public void ValidateStudentStandardsMasteryOverviewOnReportDashboard() throws InterruptedException {
        TestRunner.startTest("Validate Student Standards Mastery Overview Data On Report Dashboard");
        try {
//            wait.until(ExpectedConditions.invisibilityOf(loader));
            reportDashboardFiltersPF.ValidateStudentStandardsMasteryOverviewDataOnReportDashboard();
        } catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

}
