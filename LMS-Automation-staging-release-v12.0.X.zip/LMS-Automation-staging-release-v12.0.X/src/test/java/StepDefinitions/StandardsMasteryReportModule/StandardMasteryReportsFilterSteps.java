package StepDefinitions.StandardsMasteryReportModule;

import StandardsMasteryReport.StandardMasteryReportsByClass_PF;
import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Assignmment.CorrectAnswerExecutor_PF;

import java.time.Duration;

public class StandardMasteryReportsFilterSteps {

    WebDriver driver = Configurations.getDriver();
    Helper helper;
    Actions actions;

    StandardMasteryReportsByClass_PF standardMasteryReportsByClass_pf;

    public WebDriverWait wait;
    WebElement loader = driver.findElement(By.xpath("//span[@role='progressbar']"));

    public StandardMasteryReportsFilterSteps(){
        helper = new Helper();
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
        actions = new Actions(driver);
        standardMasteryReportsByClass_pf = new StandardMasteryReportsByClass_PF(driver);
    }

    @And("Validate and Click on Standards Mastery Reports From Favorite Reports")
    public void ValidateAndClickOnStandardsMasteryReportsFromFavoriteReports() throws InterruptedException {
        TestRunner.startTest("Validate and Click on Standards Mastery Reports From Favorite Reports");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            standardMasteryReportsByClass_pf.VerifyAndClickOnStandardMasteryReport();
        } catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Validate and Check Right Text on Standards Mastery Run Report Screen")
    public void ValidateAndCheckRightTextOnRunReportScreen() throws InterruptedException{
        TestRunner.startTest("Validate and Check Right Text on Run Report Screen");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            standardMasteryReportsByClass_pf.verifyRightSideStandardMasterText();
        } catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Validate and Check By Default By Class is Selected in Standards Mastery Report")
    public void ValidateAndCheckByDefaultByClassIsSelectedInStandardsMastery() throws InterruptedException {
        TestRunner.startTest("Validate and Check By Default By Class is Selected in Standards Mastery Report");
        try {
            standardMasteryReportsByClass_pf.checkByDefaultByClassButtonIsPressedInStandardsMastery();
        } catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line  number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Validate Student Data Table Display in Standards Mastery Report")
    public void ValidateAssignmentTableDisplayInRightSide() throws InterruptedException {
        TestRunner.startTest("Validate Student Data Table Display in Standards Mastery Report");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            standardMasteryReportsByClass_pf.verifyStudentDataInStandardsMasteryReport();
        } catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Validate Student Data Table Display And Get Standards Mastery Report")
    public void ValidateAssignmentTableDisplayAndGetMasteryReport() throws InterruptedException {
        TestRunner.startTest("Validate Student Data Table Display and Get Standards Mastery Report");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            standardMasteryReportsByClass_pf.verifyStudentAndGetStandardsMasteryReport();
        } catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }
}
