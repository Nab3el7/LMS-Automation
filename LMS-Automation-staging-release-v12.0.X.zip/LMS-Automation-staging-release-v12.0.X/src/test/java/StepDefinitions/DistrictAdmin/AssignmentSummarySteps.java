package StepDefinitions.DistrictAdmin;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.DistrictAdmin.AssignmentSummaryPage_PF;
import pageFactory.Login_PF;

import java.time.Duration;

public class AssignmentSummarySteps extends Configurations {
    WebDriver driver = Configurations.getDriver();
    AssignmentSummaryPage_PF assignmentSummaryPagePf;
    Helper helper;
    WebDriverWait wait;
    WebElement loader = driver.findElement(By.xpath("//span[@role='progressbar']"));

    public AssignmentSummarySteps() {
        assignmentSummaryPagePf = new AssignmentSummaryPage_PF(driver);
        helper = new Helper();
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
    }
    @And("Click On My Assignment Tabs On Assignment Summary")
    public void SelectMyAssignmentTabs() throws InterruptedException {
        TestRunner.startTest(" Assignment Summary Dashboard");
        try {
            assignmentSummaryPagePf.selectAssignmentTabs();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }

    }

    @And("Select District From Assignment Summary")
    public void SelectDistrictFromStaffSelectionPrompt() throws InterruptedException{
        TestRunner.startTest( "Select District From Staff Selection Prompt");
        try {

            assignmentSummaryPagePf.SelectDistrictFromDropdown();
        }catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found.");
            Assert.fail();
        }
        Thread.sleep(2000);
    }
    @And("Select School for Assignment Summery")
    public void SelectSchool() throws InterruptedException{
        TestRunner.startTest( "Select School From Staff Selection Prompt");
        try {

            assignmentSummaryPagePf.SelectSchoolFromDropDown();
        }catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found.");
            Assert.fail();
        }
        Thread.sleep(2000);
    }
    @And("Select Staff From Dropdown for Assignment Summary")
    public void SelectRoleFromDropdown() throws InterruptedException{
        TestRunner.startTest( "Select Role From Dropdown");
        try {

            assignmentSummaryPagePf.validateAndSelectStaffFromDropdown();
        }catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found.");
            Assert.fail();
        }
        Thread.sleep(2000);
    }
    @And("Click on Icon Button")
    public void click_Icon_button(){
        TestRunner.startTest( " Verify Click on Icon Button ");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            assignmentSummaryPagePf.AssignmentIcon_Button();
//            System.out.println("Test Case Passed    :   Add New Button Click successfully");
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
            Assert.fail();
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
}

