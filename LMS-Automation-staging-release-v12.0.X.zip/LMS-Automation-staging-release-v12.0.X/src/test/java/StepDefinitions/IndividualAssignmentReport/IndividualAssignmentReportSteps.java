package StepDefinitions.IndividualAssignmentReport;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Assignmment.CorrectAnswerExecutor_PF;
import pageFactory.Gradebook.AssignmentVerification_PF;
import pageFactory.IndividualAssignmentReport.IndividualAssignmentReport_PF;
import pageFactory.StudentProgressReport.StudentProgressReport_PF;

import java.time.Duration;

public class IndividualAssignmentReportSteps {

    WebDriver driver = Configurations.getDriver();
    Helper helper;
    Actions actions;

    StudentProgressReport_PF studentProgressReport_pf;
    IndividualAssignmentReport_PF individualAssignmentReport_pf;
    AssignmentVerification_PF Assign_verify_PF;

    public WebDriverWait wait;
    WebElement loader = driver.findElement(By.xpath("//span[@role='progressbar']"));


    public IndividualAssignmentReportSteps(){
        helper = new Helper();
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
        actions = new Actions(driver);
        Assign_verify_PF = new AssignmentVerification_PF(driver);
        individualAssignmentReport_pf = new IndividualAssignmentReport_PF(driver);

    }

    @And("Check, Verify and Open Specific assignment For Individual Assignment Report")
    public void checkAndVerifyOpenSpecificAssignmentFromGradeBook() throws InterruptedException {
        TestRunner.startTest("Check, Verify and Open Specific assignment For Individual Assignment Report");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            String assignmentNameForCorrect =CorrectAnswerExecutor_PF.assignmentNameForCorrect.get();
            System.out.println("Want to open attempted assignment: " + assignmentNameForCorrect);
            TestRunner.getTest().log(Status.INFO, "Want to open attempted assignment: " + assignmentNameForCorrect);
            individualAssignmentReport_pf.searchAndOpenSpecificAssignmentForIndividualAssignmentReport(assignmentNameForCorrect);
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Validate and Check Breadcrumb on Individual Assignment Report")
    public void ValidateAndCheckBreadcrumbOnIndividualAssignmentReport() throws InterruptedException {
        TestRunner.startTest("Validate and Check Breadcrumb on Individual Assignment Report");

        try {
            individualAssignmentReport_pf.verifyBreadcrumbOnIndividualAssignmentReport();

        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Validate and Check Report Generated Present On Individual Assignment Report")
    public void ValidateAndCheckReportGeneratedPresentOnIndividualAssignmentReport() throws InterruptedException {
        TestRunner.startTest("Validate and Check Report Generated Present On Individual Assignment Report");

        try {
            individualAssignmentReport_pf.verifyReportGeneratedTime();

        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Validate and Check View Gradebook Button Present on Individual Assignment Report")
    public void ValidateAndCheckViewGradebookButtonPresentOnIndividualAssignmentReport() throws InterruptedException {
        TestRunner.startTest("Validate and Check View Gradebook Button Present on Individual Assignment Report");

        try {

            individualAssignmentReport_pf.viewGradebookButtonOnIndividualAssignmentReport();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Validate and Check Student Information is present and Visible on Individual Assignment Report")
    public void ValidateAndCheckStudentInformationIsPresentAndVisible() throws InterruptedException {
        TestRunner.startTest("Validate and Check Student Information is present and Visible on Individual Assignment Report");
        try {
            individualAssignmentReport_pf.validateStudentDataOnIndividualAssignmentReport();

        } catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found.");
        }
    }

    @And("Validate and Check Assignment Information is present and Visible on Individual Assignment Report")
    public void ValidateAndCheckAssignmentInformationIsPresentAndVisibleOnIndividualAssignmentReport() throws InterruptedException {
        TestRunner.startTest("Validate and Check Assignment Information is present and Visible on Individual Assignment Report");

        try {
            individualAssignmentReport_pf.validateAssignmentInformationOnIndividualAssignmentReport();

        } catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found.");
        }
    }

    @And("Validate and Click Standard Icon On Individual Assignment Report")
    public void ValidateAndClickStandardIconOnIndividualAssignmentReport() throws InterruptedException {
        TestRunner.startTest("Validate and Click Standard Icon On Individual Assignment Report");

        try {
            individualAssignmentReport_pf.clickStandardIconOnIndividualAssignmentReport();

        } catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found.");
        }
    }

    @And("Verify Prompt Is Displayed On Individual Assignment Report")
    public void VerifyPromptIsDisplayedOnIndividualAssignmentReport() throws InterruptedException {
        TestRunner.startTest("Verify Prompt Is Displayed On Individual Assignment Report");

        try {
            individualAssignmentReport_pf.verifyStandardsPromptOnIndividualAssignmentReport();

        } catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found.");
        }
    }

    @And("Check, Validate and get Standard information On Individual Assignment Report")
    public void CheckValidateAndGetStandardInformationOnIndividualAssignmentReport() throws InterruptedException {
        TestRunner.startTest("Check, Validate and get Standard information On Individual Assignment Report");

        try {
            individualAssignmentReport_pf.getStandardsFromIndividualAssignmentReport();

        } catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found.");
        }
    }

    @And("Check, Verify standard Match On Individual Assignment Report")
    public void CheckVerifyStandardMatchOnIndividualAssignmentReport() throws InterruptedException {
        TestRunner.startTest("Check, Verify standard Match On Individual Assignment Report");
        try {
            individualAssignmentReport_pf.validateStandardMatchOnIndividualAssignmentReport();

        } catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found.");
        }
    }

    @And("Check, and Click on View Assignment Notes Button On Individual Assignment Report")
    public void CheckAndClickOnViewAssignmentNotesButtonOnIndividualAssignmentReport() throws InterruptedException {
        TestRunner.startTest("Check, and Click on View Assignment Notes Button On Individual Assignment Report");

        try {
            individualAssignmentReport_pf.VerifyViewAssignmentNotesButtonOnIndividualAssignmentReport();

        } catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found.");
        }
    }

    @And("Verify Assignment Notes Prompt Display")
    public void VerifyAssignmentNotesPromptDisplay() throws InterruptedException {
        TestRunner.startTest("Verify Assignment Notes Prompt Display");

        try {
            individualAssignmentReport_pf.ValidateAssignmentNotesPrompt();

        } catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found.");
        }
    }

    @And("Validate and Get Assignment Notes From Individual Assignment Report")
    public void ValidateAndGetAssignmentNotesFromIndividualAssignmentReport() throws InterruptedException {
        TestRunner.startTest("Validate and Get Assignment Notes From Individual Assignment Report");

        try {
            individualAssignmentReport_pf.GetAssignmentNotesFromIndividualAssignmentReport();

        } catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found.");
        }
    }

    @And("Check, Validate And Compare Assignment Notes Both Student And Teacher From Individual Assignment Report")
    public void CheckValidateAndCompareAssignmentNotesBothStudentAndTeacherFromIndividualAssignmentReport() throws InterruptedException {
        TestRunner.startTest("Check, Validate And Compare Assignment Notes Both Student And Teacher From Individual Assignment Report");

        try {
            individualAssignmentReport_pf.ValidateStudentAndTeacherNotesFromIndividualAssignmentReport();

        }  catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found.");
        }
    }

    @And("Check, Validate Class Dropdown On Individual Assignment Report")
    public void CheckValidateClassDropdownOnIndividualAssignmentReport() throws InterruptedException {
        TestRunner.startTest("Check, Validate Class Dropdown On Individual Assignment Report");

        try {
            individualAssignmentReport_pf.validateClassDropdown();
        } catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found.");
        }
    }

    @And("Check, Validate Student Dropdown On Individual Assignment Report")
    public void CheckValidateStudentDropdownOnIndividualAssignmentReport() throws InterruptedException {
        TestRunner.startTest("Check, Validate Student Dropdown On Individual Assignment Report");

        try {
            individualAssignmentReport_pf.validateUserDropdown();

        } catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found.");
        }
    }

    @And("Check, Validate Assignment Dropdown On Individual Assignment Report")
    public void CheckValidateAssignmentDropdownOnIndividualAssignmentReport() throws InterruptedException {
        TestRunner.startTest("Check, Validate Assignment Dropdown On Individual Assignment Report");

        try {
            individualAssignmentReport_pf.validateAssignmentDropdown();

        } catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found.");
        }
    }


    @And("Check, Validate FINAL SCORE Match On Individual Assignment Report")
    public void CheckValidateFINALSCOREMatchOnIndividualAssignmentReport() throws InterruptedException {
        TestRunner.startTest("Check, Validate FINAL SCORE Match On Individual Assignment Report");

        try {
            individualAssignmentReport_pf.finalScoreOnIndividualAssignmentReport();

        } catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found.");
            Assert.fail();
        }
    }

    @And("Check, Validate FINAL POINTS Match On Individual Assignment Report")
    public void CheckValidateFINALPOINTSMatchOnIndividualAssignmentReport() throws InterruptedException {
        TestRunner.startTest("Check, Validate FINAL POINTS Match On Individual Assignment Report");

        try {
            individualAssignmentReport_pf.finalPointsOnIndividualAssignmentReport();

        } catch (NoSuchElementException | ElementNotInteractableException ex){
        System.out.println(ex);
        System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
        TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found.");
        Assert.fail();
        }
    }

    @And("Check, Validate QUESTIONS CORRECT Match On Individual Assignment Report")
    public void CheckValidateQUESTIONSCORRECTMatchOnIndividualAssignmentReport() throws InterruptedException {
        TestRunner.startTest("Check, Validate QUESTIONS CORRECT Match On Individual Assignment Report");

        try {

            individualAssignmentReport_pf.questionCorrectOnIndividualAssignment();

        } catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found.");
            Assert.fail();
        }

    }

    @And("Check, Validate STATUS On Individual Assignment Report")
    public void CheckValidateSTATUSOnIndividualAssignmentReport() throws InterruptedException {
        TestRunner.startTest("Check, Validate STATUS On Individual Assignment Report");

        try {

            individualAssignmentReport_pf.statusOfAssignmentOnIndividualReport();

        } catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found.");
            Assert.fail();
        }
    }

    @And("Check, Validate Assignment Summary On Individual Assignment Report")
    public void CheckValidateAssignmentSummaryOnIndividualAssignmentReport() throws InterruptedException {
        TestRunner.startTest("Check, Validate Assignment Summary On Individual Assignment Report");

        try {
            individualAssignmentReport_pf.verifyAssignmentSummaryOnIndividualAssignmentReport();

        } catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found.");
            Assert.fail();
        }
    }

    @And("Check, Click on Standards in Assignment Summary Table")
    public void CheckClickOnStandardsInAssignmentSummaryTable() throws InterruptedException {
        TestRunner.startTest("Check, Click on Standards in Assignment Summary Table");

        try {
            individualAssignmentReport_pf.clickStandardsInAssignmentSummaryTable();

        } catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found.");
            Assert.fail();
        }
    }

    @And("Validate Print option and Print Single Student option")
    public void ValidatePrintOptionAndPrintSingleStudentOption() throws InterruptedException {
        TestRunner.startTest("Validate Print option and Print Single Student option");
        try {
            individualAssignmentReport_pf.verifyPrintButtonAndOptions();
        } catch (NoSuchElementException | ElementNotInteractableException ex) {
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found.");
            Assert.fail();
        }
    }

    @And("Validate Print By Group option")
    public void ValidatePrintByGroupOption() throws InterruptedException {
        TestRunner.startTest("Validate Print By Group option");

        try {
            individualAssignmentReport_pf.verifyPrintByGroupOption();

        }  catch (NoSuchElementException | ElementNotInteractableException ex) {
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found.");
            Assert.fail();
        }
    }

    @And("Check, Validate Standards Tab On Individual Assignment Report")
    public void CheckValidateStandardsTabOnIndividualAssignmentReport() throws InterruptedException {
        TestRunner.startTest("Check, Validate Standards Tab On Individual Assignment Report");

        try {
            individualAssignmentReport_pf.verifyClickOnStandardsTab();

        } catch (NoSuchElementException | ElementNotInteractableException ex) {
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found.");
            Assert.fail();
        }
    }

    @And("Check, Validate and Get Heading From Standards Tab")
    public void CheckValidateAndGetHeadingFromStandardsTab() throws InterruptedException {
        TestRunner.startTest("Check, Validate and Get Heading From Standards Tab");

        try {
            individualAssignmentReport_pf.verifyHeadingFromStandardsTab();

        } catch (NoSuchElementException | ElementNotInteractableException ex) {
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found.");
            Assert.fail();
        }
    }

    @And("Check, Validate Card Content under Standards Tab")
    public void CheckValidateCardContentUnderStandardsTab() throws InterruptedException {
        TestRunner.startTest("Check, Validate Card Content under Standards Tab");

        try {
            individualAssignmentReport_pf.verifyCardContent();

        } catch (NoSuchElementException | ElementNotInteractableException ex) {
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found.");
            Assert.fail();
        }
    }

    @And("Check, Validate Accessed Times under Standards Tab")
    public void CheckValidateAccessedTimesUnderStandardsTab() throws InterruptedException {
        TestRunner.startTest("Check, Validate Accessed Times under Standards Tab");

        try {
            individualAssignmentReport_pf.verifyAccessedTimesStandardsTab();

        } catch (NoSuchElementException | ElementNotInteractableException ex) {
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found.");
            Assert.fail();
        }
    }
}
