package StepDefinitions.StudentProgressReport;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.StudentProgressReport.StudentProgressReport_PF;

import java.time.Duration;

public class StudentProgressReportSteps {

    WebDriver driver = Configurations.getDriver();
    Helper helper;
    Actions actions;

    StudentProgressReport_PF studentProgressReport_pf;

    public WebDriverWait wait;
    WebElement loader = driver.findElement(By.xpath("//span[@role='progressbar']"));


    public StudentProgressReportSteps(){
        helper = new Helper();
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
        actions = new Actions(driver);
        studentProgressReport_pf = new StudentProgressReport_PF(driver);

    }

    @And("Verify GradeBook Students List and search Student For Student Progress Report")
    public void VerifyGradeBookStudentsListSearchStudent() throws InterruptedException{
        TestRunner.startTest( "Verify GradeBook Students List and search Student For Student Progress Report");
        try {
            studentProgressReport_pf.GetStudentListAndClickIconForStudentProgressReport();

        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Student not found in List ");
            Assert.fail();
        }

    }

    @And("Validate and Select Report From DropDown on Student Information Dialogue Box")
    public void ValidateAndSelectReportFromDropDownOnStudentInformationDialogueBox() throws InterruptedException {
        TestRunner.startTest("Validate and Select Report From DropDown on Student Information Dialogue Box");

        try {
            studentProgressReport_pf.selectReportFromDropDown();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Select Report Dropdown not found on Student Information Dialogue box");
        }
    }

    @And("Validate and Check Breadcrumb on Student Progress Report")
    public void ValidateAndCheckBreadcrumbOnStudentProgressReport() throws InterruptedException {
        TestRunner.startTest("Validate and Check Breadcrumb on Student Progress Report");

        try {
            studentProgressReport_pf.verifyBreadcrumbOnStudentProgressReport();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: BreadCrumb on student progress report not match");
        }
    }

    @And("Validate and Check Student Information is Present and Visible")
    public void ValidateAndCheckStudentInformationIsPresentAndVisible() throws InterruptedException {
        TestRunner.startTest("Validate and Check Student Information is Present and Visible");
        try {
            studentProgressReport_pf.validateStudentDataOnStudentProgressReport();

        } catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found.");
        }
    }

    @And("Validate and Check View GradeBook link is present")
    public void ValidateAndCheckViewGradeBookLinkIsPresent() throws InterruptedException {
        TestRunner.startTest("Validate and Check View GradeBook link is present");
        try {
            studentProgressReport_pf.verifyViewGradeBookLink();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found.");
        }
    }

    @And("Select Assignment Status filter {string}")
    public void SelectAssignmentStatusFilter(String statusOption) throws InterruptedException {
        TestRunner.startTest("Select Assignment Status filter: " + statusOption);
        try {
            studentProgressReport_pf.selectAssignmentStatusFromDropdown(statusOption);
        } catch (Exception ex) {
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception while selecting Assignment Status filter - " + ex.getMessage());
            Assert.fail("Failed to select Assignment Status filter: " + statusOption);
        }
    }

    @And("Verify status labels match filter {string} with expected statuses {string}")
    public void VerifyStatusLabelsMatchFilter(String filterOption, String expectedStatuses) throws InterruptedException {
        TestRunner.startTest("Verify status labels match filter: " + filterOption);
        try {
            // Parse expected statuses (comma-separated string)
            String[] expectedStatusArray = expectedStatuses.split(",");
            for (int i = 0; i < expectedStatusArray.length; i++) {
                expectedStatusArray[i] = expectedStatusArray[i].trim();
            }
            
            studentProgressReport_pf.verifyStatusLabelsMatchFilter(filterOption, expectedStatusArray);
        } catch (Exception ex) {
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception while verifying status labels - " + ex.getMessage());
            Assert.fail("Failed to verify status labels for filter: " + filterOption);
        }
    }

    @And("Verify Assignment Status filter functionality")
    public void VerifyAssignmentStatusFilterFunctionality() throws InterruptedException {
        TestRunner.startTest("Verify Assignment Status filter functionality");
        try {
            studentProgressReport_pf.verifyAssignmentStatusFilter();
        } catch (Exception ex) {
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception while verifying Assignment Status filter - " + ex.getMessage());
            Assert.fail("Failed to verify Assignment Status filter functionality");
        }
    }

    @And("Get and display all assignments from all categories")
    public void GetAndDisplayAllAssignmentsFromAllCategories() throws InterruptedException {
        TestRunner.startTest("Get and display all assignments from all categories");
        try {
            studentProgressReport_pf.displayAllAssignmentsFromAllCategories();
        } catch (Exception ex) {
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception while retrieving assignments - " + ex.getMessage());
            Assert.fail("Failed to retrieve assignments from categories");
        }
    }

    @And("Verify total assignments count is greater than {int}")
    public void VerifyTotalAssignmentsCountIsGreaterThan(int expectedCount) throws InterruptedException {
        TestRunner.startTest("Verify total assignments count is greater than " + expectedCount);
        try {
            java.util.List<pageFactory.StudentProgressReport.StudentProgressReport_PF.Assignment> assignments = 
                studentProgressReport_pf.getAllAssignmentsFromAllCategories();
            
            int actualCount = assignments.size();
            System.out.println("Total assignments found: " + actualCount);
            
            if (actualCount > expectedCount) {
                System.out.println("✅ Test Passed: Total assignments (" + actualCount + ") is greater than " + expectedCount);
                TestRunner.getTest().log(Status.PASS, "Total assignments (" + actualCount + ") is greater than " + expectedCount);
            } else {
                System.out.println("❌ Test Failed: Total assignments (" + actualCount + ") is not greater than " + expectedCount);
                TestRunner.getTest().log(Status.FAIL, "Total assignments (" + actualCount + ") is not greater than " + expectedCount);
                Assert.fail("Total assignments (" + actualCount + ") is not greater than " + expectedCount);
            }
        } catch (Exception ex) {
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception while verifying assignments count - " + ex.getMessage());
            Assert.fail("Failed to verify assignments count");
        }
    }

    @And("Verify Display Class Average checkbox functionality")
    public void VerifyDisplayClassAverageCheckboxFunctionality() {
        TestRunner.startTest("Verify Display Class Average checkbox functionality");
        try {
            studentProgressReport_pf.verifyDisplayClassAverageCheckboxFunctionality();
        } catch (Exception ex) {
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception while verifying Display Class Average checkbox - " + ex.getMessage());
            Assert.fail("Failed to verify Display Class Average checkbox functionality");
        }
    }
    
    @And("Get and store Assignments Submitted count")
    public void GetAndStoreAssignmentsSubmittedCount() {
        TestRunner.startTest("Get and store Assignments Submitted count");
        try {
            studentProgressReport_pf.getAndStoreAssignmentsSubmittedCount();
        } catch (Exception ex) {
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception while getting Assignments Submitted count - " + ex.getMessage());
            Assert.fail("Failed to get Assignments Submitted count");
        }
    }
    
    @And("Get and compare Assignments Submitted count after submission")
    public void GetAndCompareAssignmentsSubmittedCountAfterSubmission() {
        TestRunner.startTest("Get and compare Assignments Submitted count after submission");
        try {
            studentProgressReport_pf.getAndCompareAssignmentsSubmittedCount();
        } catch (Exception ex) {
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception while comparing Assignments Submitted count - " + ex.getMessage());
            Assert.fail("Failed to compare Assignments Submitted count");
        }
    }

    @And("Find and get complete details of submitted assignment")
    public void FindAndGetCompleteDetailsOfSubmittedAssignment() {

        TestRunner.startTest("Find and get complete details of submitted assignment");
        try {
            studentProgressReport_pf.findAndGetAssignmentDetails();
        } catch (Exception ex) {
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception while comparing Assignments Submitted count - " + ex.getMessage());
            Assert.fail("Failed to Find and get complete details of submitted assignment");
        }
    }

    @And("Click on Standards tab")
    public void ClickOnStandardsTab() throws InterruptedException {
        TestRunner.startTest("Click on Standards tab");
        try {
            studentProgressReport_pf.clickOnStandardsTab();
        } catch (Exception ex) {
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception while clicking on Standards tab - " + ex.getMessage());
            Assert.fail("Failed to click on Standards tab");
        }
    }

    @And("Verify breadcrumb on Standards tab")
    public void VerifyBreadcrumbOnStandardsTab() throws InterruptedException {
        TestRunner.startTest("Verify breadcrumb on Standards tab");
        try {
            studentProgressReport_pf.verifyBreadcrumbOnStandardsTab();
        } catch (Exception ex) {
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception while verifying breadcrumb on Standards tab - " + ex.getMessage());
            Assert.fail("Failed to verify breadcrumb on Standards tab");
        }
    }

    @And("Verify text on right side of Standards tab")
    public void VerifyTextOnRightSideOfStandardsTab() throws InterruptedException {
        TestRunner.startTest("Verify text on right side of Standards tab");
        try {
            studentProgressReport_pf.verifyTextOnRightSideOfStandardsTab();
        } catch (Exception ex) {
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception while verifying text on right side of Standards tab - " + ex.getMessage());
            Assert.fail("Failed to verify text on right side of Standards tab");
        }
    }

    @And("Validate and expand all Standards headings to get data and unexpand them")
    public void ValidateAndExpandAllStandardsHeadingsToGetDataAndUnexpandThem() throws InterruptedException {
        TestRunner.startTest("Validate and expand all Standards headings to get data and unexpand them");
        try {
            studentProgressReport_pf.validateAndExpandAllStandardsHeadings();
        } catch (Exception ex) {
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception while validating and expanding Standards headings - " + ex.getMessage());
            Assert.fail("Failed to validate and expand Standards headings");
        }
    }

    @And("Click on sub-headings and compare assignment names from Assessed Times dialog")
    public void ClickOnSubHeadingsAndCompareAssignmentNamesFromAssessedTimesDialog() throws InterruptedException {
        TestRunner.startTest("Click on sub-headings and compare assignment names from Assessed Times dialog");
        try {
            // Get assignment name from CorrectAnswerExecutor_PF
            String assignmentName = "";
            try {
                assignmentName = pageFactory.Assignmment.CorrectAnswerExecutor_PF.assignmentNameForCorrect.get();
            } catch (Exception e) {
                System.out.println("⚠️ Could not get assignment name from CorrectAnswerExecutor_PF");
                TestRunner.getTest().log(Status.WARNING, "Could not get assignment name from CorrectAnswerExecutor_PF");
            }
            
            studentProgressReport_pf.clickSubHeadingsAndCompareAssignmentNames(assignmentName);
        } catch (Exception ex) {
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception while clicking sub-headings and comparing assignment names - " + ex.getMessage());
            Assert.fail("Failed to click sub-headings and compare assignment names");
        }
    }

}

