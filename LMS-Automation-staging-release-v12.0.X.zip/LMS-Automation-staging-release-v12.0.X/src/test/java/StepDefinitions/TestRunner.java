package StepDefinitions;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.azure.storage.blob.BlobClient;
import com.azure.storage.blob.BlobContainerClient;
import com.azure.storage.blob.BlobContainerClientBuilder;
import com.azure.storage.common.StorageSharedKeyCredential;
import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Date;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

@CucumberOptions(
        features = "src/test/resources/Features/TeacherSide",
        glue = {"StepDefinitions"},
        plugin = {
                "pretty",
                "json:src/test/resources/Reports/report.json",
                "html:src/test/resources/Reports/index.html"
        },
        monochrome = true
)

@Slf4j
public class TestRunner extends AbstractTestNGCucumberTests {
    @Getter
    private static BlobContainerClient containerClient;
    private static ExtentReports extent;
    private static final ThreadLocal<ExtentTest> test = ThreadLocal.withInitial(() -> null);
    private static final ThreadLocal<ExtentTest> scenarioTest = ThreadLocal.withInitial(() -> null); // Parent test for each scenario
    private static final ThreadLocal<Long> testStartTime = new ThreadLocal<>();
    private static final ThreadLocal<String> currentTestName = new ThreadLocal<>();

    private static String reportPath;
    
    // Synchronization for thread-safe one-time initialization
    private static final Object extentLock = new Object();
    private static volatile boolean extentInitialized = false;
    
    // Execution timing
    private static long executionStartTime;
    private static Date executionStartDate;
    
    // Test execution statistics (thread-safe)
    private static final java.util.concurrent.atomic.AtomicInteger totalScenarios = new java.util.concurrent.atomic.AtomicInteger(0);
    private static final java.util.concurrent.atomic.AtomicInteger executedScenarios = new java.util.concurrent.atomic.AtomicInteger(0);
    private static final java.util.concurrent.atomic.AtomicInteger passedScenarios = new java.util.concurrent.atomic.AtomicInteger(0);
    private static final java.util.concurrent.atomic.AtomicInteger failedScenarios = new java.util.concurrent.atomic.AtomicInteger(0);
    private static final java.util.concurrent.atomic.AtomicInteger skippedScenarios = new java.util.concurrent.atomic.AtomicInteger(0);

    @Override
    @DataProvider(parallel = true)
    public Object[][] scenarios() {
        return super.scenarios();
    }

    @BeforeClass
    public void setupExtentReports() {
        // Thread-safe one-time initialization using double-checked locking
        if (!extentInitialized) {
            synchronized (extentLock) {
                if (!extentInitialized) {
                    // Record execution start time
                    executionStartTime = System.currentTimeMillis();
                    executionStartDate = new Date();
                    
                    // Print comprehensive start logs
                    System.out.println("\n");
                    System.out.println("=================================================================================");
                    System.out.println("                    AUTOMATION TEST EXECUTION STARTED");
                    System.out.println("=================================================================================");
                    System.out.println("Start Time: " + executionStartDate);
                    System.out.println("Environment: Staging");
                    System.out.println("Application URL: https://staging.gallopade.com");
                    System.out.println("Test Framework: Cucumber + TestNG");
                    System.out.println("Parallel Execution: Enabled");
                    System.out.println("Thread Count: 4 (max concurrent feature files)");
                    System.out.println("Max Concurrent Browsers: 4");
                    System.out.println("Features Location: src/test/resources/Features/TeacherSide");
                    System.out.println("=================================================================================");
                    System.out.println("\n");
                    
                    reportPath = "src/test/resources/Reports/Manual_Automation_Run_Report.html";

                    ExtentSparkReporter sparkReporter = new ExtentSparkReporter(reportPath);
                    sparkReporter.config().setReportName("Automation Test Results");
                    sparkReporter.config().setDocumentTitle("Test Report");
                    sparkReporter.config().setTheme(com.aventstack.extentreports.reporter.configuration.Theme.DARK);

                    extent = new ExtentReports();
                    extent.attachReporter(sparkReporter);
                    extent.setSystemInfo("Environment", "Staging");
                    extent.setSystemInfo("URL", "https://staging.gallopade.com");
                    extent.setSystemInfo("Tester", "Gallopade Automation Team");
                    extent.setSystemInfo("Start Date", executionStartDate.toString());
                    extentInitialized = true;
                    System.out.println("[AUTOMATION] Extent Report initialized successfully.");
                    System.out.println("[AUTOMATION] Ready to execute test scenarios...\n");
                }
            }
        }
    }

    @AfterClass
    public void tearDown() {
        // Thread-safe cleanup - only flush once when all tests complete
        synchronized (extentLock) {
            if (extent != null && extentInitialized) {
                long executionEndTime = System.currentTimeMillis();
                Date executionEndDate = new Date();
                long totalExecutionTime = executionEndTime - executionStartTime;
                long totalSeconds = totalExecutionTime / 1000;
                long minutes = totalSeconds / 60;
                long seconds = totalSeconds % 60;
                
                System.out.println("\n");
                System.out.println("=================================================================================");
                System.out.println("                    AUTOMATION TEST EXECUTION COMPLETED");
                System.out.println("=================================================================================");
                System.out.println("End Time: " + executionEndDate);
                System.out.println("Total Execution Time: " + minutes + " minutes " + seconds + " seconds (" + totalExecutionTime + " ms)");
                System.out.println("Start Time: " + executionStartDate);
                System.out.println("Duration: " + String.format("%.2f", totalExecutionTime / 1000.0) + " seconds");
                System.out.println("=================================================================================");
                System.out.println("\n");
                
                System.out.println("[AUTOMATION] Generating Extent Report...");
                try {
                    extent.flush();
                    System.out.println("[AUTOMATION] Extent Report generated successfully.");
                } catch (OutOfMemoryError e) {
                    System.err.println("⚠️ OutOfMemoryError during report generation: " + e.getMessage());
                    System.err.println("   Attempting cleanup and retry...");
                    // Clear ExtentReports to free memory
                    extent = null;
                    // Suggest garbage collection
                    System.gc();
                    try {
                        Thread.sleep(2000); // Wait for GC
                    } catch (InterruptedException ie) {
                        Thread.currentThread().interrupt();
                    }
                    throw new RuntimeException("OutOfMemoryError during report generation. Consider increasing heap size with -Xmx2048m or more.", e);
                }
                
                System.out.println("[AUTOMATION] Waiting for report file to be created...");
                waitForFile(reportPath);
                
                System.out.println("[AUTOMATION] Uploading report to Azure Blob Storage...");
                uploadReportToAzure();
                
                System.out.println("[AUTOMATION] Closing WebDriver instances...");
                try {
                    Configurations.cleanupAllDrivers();
                } catch (Exception e) {
                    System.err.println("⚠️ Error during WebDriver cleanup: " + e.getMessage());
                }
                
                // Clean up ThreadLocal variables to free memory
                System.out.println("[AUTOMATION] Cleaning up ThreadLocal variables...");
                try {
                    test.remove();
                    scenarioTest.remove();
                    testStartTime.remove();
                    currentTestName.remove();
                    System.out.println("[AUTOMATION] ThreadLocal variables cleaned up");
                } catch (Exception e) {
                    System.err.println("⚠️ Error cleaning up ThreadLocal variables: " + e.getMessage());
                }
                
                // Clear ExtentReports reference to help GC
                System.out.println("[AUTOMATION] Releasing ExtentReports reference...");
                extent = null;
                
                // Suggest garbage collection after cleanup
                System.out.println("[AUTOMATION] Requesting garbage collection...");
                System.gc();
                try {
                    Thread.sleep(1000); // Give GC time to work
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                }
                
                // Calculate execution statistics
                int total = totalScenarios.get();
                int executed = executedScenarios.get();
                int passed = passedScenarios.get();
                int failed = failedScenarios.get();
                int skipped = skippedScenarios.get();
                int notExecuted = total - executed;
                double passRate = executed > 0 ? (double) passed / executed * 100 : 0.0;
                
                System.out.println("\n");
                System.out.println("=================================================================================");
                System.out.println("                    EXECUTION SUMMARY");
                System.out.println("=================================================================================");
                System.out.println("Status: COMPLETED");
                System.out.println("Report Location: " + reportPath);
                System.out.println("Total Execution Time: " + minutes + " min " + seconds + " sec");
                System.out.println("Report uploaded to Azure Blob Storage: Yes");
                System.out.println("=================================================================================");
                System.out.println("\n");
                System.out.println("=================================================================================");
                System.out.println("                    TEST EXECUTION STATISTICS");
                System.out.println("=================================================================================");
                System.out.println("Total Test Cases:        " + total);
                System.out.println("Executed:                " + executed + " (" + String.format("%.1f", executed > 0 ? (double) executed / total * 100 : 0) + "%)");
                System.out.println("  ✅ Passed:             " + passed + " (" + String.format("%.1f", passRate) + "%)");
                System.out.println("  ❌ Failed:             " + failed + " (" + String.format("%.1f", executed > 0 ? (double) failed / executed * 100 : 0) + "%)");
                System.out.println("  ⏭️  Skipped:            " + skipped);
                System.out.println("  ⏸️  Not Executed:       " + notExecuted);
                System.out.println("=================================================================================");
                System.out.println("Pass Rate:               " + String.format("%.2f", passRate) + "%");
                System.out.println("Failure Rate:            " + String.format("%.2f", executed > 0 ? (double) failed / executed * 100 : 0) + "%");
                System.out.println("Execution Rate:          " + String.format("%.2f", total > 0 ? (double) executed / total * 100 : 0) + "%");
                System.out.println("=================================================================================");
                System.out.println("\n");
                
                extentInitialized = false;  // Reset for potential re-runs
            }
        }
    }

    /**
     * Starts a scenario test - creates the parent ExtentTest for a Cucumber scenario
     * This should be called once per scenario in @Before hook
     */
    public static void startScenarioTest(String scenarioName, String featureName) {
        // Clean up any existing test for this thread
        ExtentTest existingTest = scenarioTest.get();
        if (existingTest != null) {
            // End any previous scenario test that wasn't properly closed
            endScenarioTest(false);
        }
        
        // Create parent test for the scenario
        ExtentTest parentTest = extent.createTest(scenarioName);
        scenarioTest.set(parentTest);
        
        // Set as current test so getTest() returns the scenario test
        test.set(parentTest);
        
        // Record scenario start time
        long startTime = System.currentTimeMillis();
        Date startDate = new Date();
        testStartTime.set(startTime);
        currentTestName.set(scenarioName);
        
        // Log scenario start
        System.out.println("\n");
        System.out.println("────────────────────────────────────────────────────────────────────────────────────────────");
        System.out.println("[SCENARIO] ▶ START: " + scenarioName);
        System.out.println("[SCENARIO] Feature: " + featureName);
        System.out.println("[SCENARIO] Thread: " + Thread.currentThread().getName());
        System.out.println("[SCENARIO] Start Time: " + startDate);
        System.out.println("────────────────────────────────────────────────────────────────────────────────────────────");
        
        // Log to ExtentReport
        parentTest.info("Scenario Started at: " + startDate);
        parentTest.info("Feature: " + featureName);
        parentTest.info("Thread: " + Thread.currentThread().getName());
    }
    
    /**
     * Ends the scenario test - should be called in @After hook
     */
    public static void endScenarioTest(boolean failed) {
        ExtentTest scenarioTestInstance = scenarioTest.get();
        Long startTime = testStartTime.get();
        String testName = currentTestName.get();
        
        // Update execution statistics (thread-safe)
        executedScenarios.incrementAndGet();
        if (failed) {
            failedScenarios.incrementAndGet();
        } else {
            passedScenarios.incrementAndGet();
        }
        
        // Log current statistics
        int total = totalScenarios.get();
        int executed = executedScenarios.get();
        int passed = passedScenarios.get();
        int failedCount = failedScenarios.get();
        System.out.println("📊 Progress: " + executed + "/" + total + " executed | " + 
                          passed + " passed | " + failedCount + " failed");
        
        if (scenarioTestInstance != null && startTime != null && testName != null) {
            long endTime = System.currentTimeMillis();
            Date endDate = new Date();
            long executionTime = endTime - startTime;
            long seconds = executionTime / 1000;
            long milliseconds = executionTime % 1000;
            
            // Log scenario end
            System.out.println("────────────────────────────────────────────────────────────────────────────────────────────");
            System.out.println("[SCENARIO] ◀ END: " + testName);
            System.out.println("[SCENARIO] Status: " + (failed ? "❌ FAILED" : "✅ PASSED"));
            System.out.println("[SCENARIO] End Time: " + endDate);
            System.out.println("[SCENARIO] Execution Time: " + seconds + "." + String.format("%03d", milliseconds) + " seconds");
            System.out.println("────────────────────────────────────────────────────────────────────────────────────────────");
            System.out.println();
            
            // Log to ExtentReport
            scenarioTestInstance.info("Scenario Ended at: " + endDate);
            scenarioTestInstance.info("Execution Time: " + seconds + "." + String.format("%03d", milliseconds) + " seconds");
            
            if (failed) {
                scenarioTestInstance.fail("Scenario failed");
            } else {
                scenarioTestInstance.pass("Scenario passed");
            }
        }
        
        // Clean up ThreadLocal
        scenarioTest.remove();
        test.remove();
        testStartTime.remove();
        currentTestName.remove();
    }
    
    /**
     * Starts a child test node within the current scenario
     * This is used by step definitions that call startTest() for sub-tests
     */
    public static void startTest(String testName) {
        ExtentTest parentTest = scenarioTest.get();
        
        if (parentTest == null) {
            // If no scenario test exists, create a standalone test
            // This handles cases where startTest() is called outside of a scenario context
            ExtentTest extentTest = extent.createTest(testName);
            test.set(extentTest);
            scenarioTest.set(extentTest); // Set as scenario test too
            
            long startTime = System.currentTimeMillis();
            Date startDate = new Date();
            testStartTime.set(startTime);
            currentTestName.set(testName);
            
            extentTest.info("Test Case Started at: " + startDate);
            return;
        }
        
        // Create a child node under the scenario test
        ExtentTest childTest = parentTest.createNode(testName);
        test.set(childTest);
        
        // Record test case start time
        long startTime = System.currentTimeMillis();
        Date startDate = new Date();
        testStartTime.set(startTime);
        currentTestName.set(testName);
        
        // Log test case start
        System.out.println("\n");
        System.out.println("────────────────────────────────────────────────────────────────────────────────────────────");
        System.out.println("[TEST CASE] ▶ START: " + testName);
        System.out.println("[TEST CASE] Thread: " + Thread.currentThread().getName());
        System.out.println("[TEST CASE] Start Time: " + startDate);
        System.out.println("────────────────────────────────────────────────────────────────────────────────────────────");
        
        // Log to ExtentReport
        childTest.info("Test Case Started at: " + startDate);
    }

    /**
     * Ends a child test node (not the scenario test)
     * This is used by step definitions that call endTest() for sub-tests
     */
    public static void endTest() {
        ExtentTest currentTest = test.get();
        ExtentTest scenarioTestInstance = scenarioTest.get();
        
        // Only end if this is a child test, not the scenario test
        if (currentTest != null && currentTest != scenarioTestInstance) {
            Long startTime = testStartTime.get();
            String testName = currentTestName.get();
            
            if (startTime != null && testName != null) {
                long endTime = System.currentTimeMillis();
                Date endDate = new Date();
                long executionTime = endTime - startTime;
                long seconds = executionTime / 1000;
                long milliseconds = executionTime % 1000;
                
                System.out.println("────────────────────────────────────────────────────────────────────────────────────────────");
                System.out.println("[TEST CASE] ◀ END: " + testName);
                System.out.println("[TEST CASE] End Time: " + endDate);
                System.out.println("[TEST CASE] Execution Time: " + seconds + "." + String.format("%03d", milliseconds) + " seconds (" + executionTime + " ms)");
                System.out.println("────────────────────────────────────────────────────────────────────────────────────────────");
                System.out.println();
                
                // Log to ExtentReport
                currentTest.info("Test Case Ended at: " + endDate);
                currentTest.info("Execution Time: " + seconds + "." + String.format("%03d", milliseconds) + " seconds");
            }
            
            // Reset current test to scenario test (parent)
            test.set(scenarioTestInstance);
            
            // Clean up ThreadLocal for child test
            testStartTime.remove();
            currentTestName.remove();
        }
    }

    /**
     * Gets the current ExtentTest instance for this thread
     * Returns the scenario test if available, otherwise returns the current test node
     */
    public static ExtentTest getTest() {
        ExtentTest currentTest = test.get();
        if (currentTest == null) {
            // If no test is set, try to get the scenario test
            currentTest = scenarioTest.get();
        }
        return currentTest;
    }
    
    /**
     * Gets the scenario test (parent test) for this thread
     */
    public static ExtentTest getScenarioTest() {
        return scenarioTest.get();
    }
    
    /**
     * Get current test execution statistics
     * @return Map containing test statistics
     */
    public static java.util.Map<String, Object> getExecutionStatistics() {
        java.util.Map<String, Object> stats = new java.util.HashMap<>();
        int total = totalScenarios.get();
        int executed = executedScenarios.get();
        int passed = passedScenarios.get();
        int failed = failedScenarios.get();
        int skipped = skippedScenarios.get();
        
        stats.put("total", total);
        stats.put("executed", executed);
        stats.put("passed", passed);
        stats.put("failed", failed);
        stats.put("skipped", skipped);
        stats.put("notExecuted", total - executed);
        stats.put("passRate", executed > 0 ? (double) passed / executed * 100 : 0.0);
        stats.put("failureRate", executed > 0 ? (double) failed / executed * 100 : 0.0);
        stats.put("executionRate", total > 0 ? (double) executed / total * 100 : 0.0);
        
        return stats;
    }

    /**
     * Loads application.properties and profile-specific properties file
     * @return Properties object with all loaded properties
     */
    private static Properties loadApplicationProperties() {
        Properties properties = new Properties();
        
        try {
            // Step 1: Load base application.properties
            InputStream baseStream = TestRunner.class.getClassLoader()
                    .getResourceAsStream("application.properties");
            
            if (baseStream != null) {
                properties.load(baseStream);
                baseStream.close();
            }
            
            // Step 2: Get active profile
            String activeProfile = properties.getProperty("spring.profiles.active", "local");
            
            // Step 3: Load profile-specific properties (e.g., application-local.properties)
            String profileFileName = "application-" + activeProfile + ".properties";
            InputStream profileStream = TestRunner.class.getClassLoader()
                    .getResourceAsStream(profileFileName);
            
            if (profileStream != null) {
                Properties profileProperties = new Properties();
                profileProperties.load(profileStream);
                profileStream.close();
                
                // Merge profile-specific properties (profile overrides base)
                properties.putAll(profileProperties);
                log.info("Loaded profile-specific properties from: " + profileFileName);
            } else {
                log.warn("Profile-specific file not found: " + profileFileName + ", using base properties only");
            }
            
        } catch (IOException e) {
            log.error("Error loading application properties: " + e.getMessage());
        }
        
        return properties;
    }

    public static void waitForFile(String reportPath) {
        int retryCount = 0;
        int maxRetries = 5;
        int waitTimeSeconds = 2;

        while (retryCount < maxRetries) {
            if (Files.exists(Paths.get(reportPath))) {
                System.out.println("Report file generated successfully.");
                return;
            }

            retryCount++;
            System.out.println("Waiting for the report file to be generated...");
            try {
                TimeUnit.SECONDS.sleep(waitTimeSeconds);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }

        System.err.println("Report file could not be generated within the wait time.");
    }

    public static void uploadReportToAzure() {
        System.out.println("Uploading report to Azure Blob Storage.");
        Properties properties = loadApplicationProperties();
        
        if (properties.isEmpty()) {
            System.err.println("No properties loaded. Cannot upload report to Azure.");
            return;
        }

        String accountName = properties.getProperty("azure.storage.account-name");
        String accountKey = properties.getProperty("azure.storage.account-key");
        String containerName = properties.getProperty("azure.storage.container-name");

        if (accountName == null || accountKey == null || containerName == null) {
            System.err.println("Azure storage account details are missing in the config file.");
            return;
        }

        String endpoint = String.format("https://%s.blob.core.windows.net", accountName);
        StorageSharedKeyCredential credential = new StorageSharedKeyCredential(accountName, accountKey);

        containerClient = new BlobContainerClientBuilder()
                .endpoint(endpoint)
                .credential(credential)
                .containerName(containerName)
                .buildClient();

        String blobName = "Reports/Manual_Automation_Run_Report.html";
        BlobClient blobClient = containerClient.getBlobClient(blobName);

        try {
            blobClient.uploadFromFile(reportPath, true);
            System.out.println("Report uploaded successfully.");
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Failed to upload the report.");
        }
    }
}