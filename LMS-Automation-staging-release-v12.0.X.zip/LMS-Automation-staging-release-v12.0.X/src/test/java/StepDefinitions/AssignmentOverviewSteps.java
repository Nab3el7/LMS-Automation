package StepDefinitions;

import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.AssignmentOverview_PF;
import pageFactory.Assignmment.AssignmentStatusReview_PF;
import pageFactory.Assignmment.CorrectAnswerExecutor_PF;
import pageFactory.Assignmment.InCorrectAnswerExecutor_PF;
import pageFactory.Assignmment.StudentExecutor_PF;
import pageFactory.Gradebook.AssignmentScoreVerification_PF;

import java.awt.*;
import java.time.Duration;

//import static StepDefinitions.Configurations.driver;

public class AssignmentOverviewSteps extends Configurations {
    // Lazy initialization - get driver only when needed
    private WebDriver driver;
    private WebDriverWait wait;
    private WebElement loader;

    StudentExecutor_PF studentExecutorPF;
    CorrectAnswerExecutor_PF correctAnswerExecutorPF;
    InCorrectAnswerExecutor_PF inCorrectAnswerExecutorPF;
    AssignmentOverview_PF assignmentOverviewPf;
    Helper helper;

    // Lazy getters - initialize only when accessed
    private WebDriver getWebDriver() {
        if (driver == null) {
            driver = Configurations.getDriver();
        }
        return driver;
    }

    private WebDriverWait getWebDriverWait() {
        if (wait == null) {
            wait = new WebDriverWait(getWebDriver(), Duration.ofSeconds(60));
        }
        return wait;
    }

    private WebElement getLoader() {
        if (loader == null) {
            loader = getWebDriver().findElement(By.xpath("//span[@role='progressbar']"));
        }
        return loader;
    }

    public AssignmentOverviewSteps(){
        // Helper doesn't need driver immediately - it uses lazy initialization
        helper = new Helper();
        // Page objects will be initialized when driver is first accessed
    }

    // Initialize page objects when driver is first used
    private void ensurePageObjectsInitialized() {
        if (studentExecutorPF == null) {
            studentExecutorPF = new StudentExecutor_PF(getWebDriver());
            correctAnswerExecutorPF = new CorrectAnswerExecutor_PF(getWebDriver());
            inCorrectAnswerExecutorPF = new InCorrectAnswerExecutor_PF(getWebDriver());
            assignmentOverviewPf = new AssignmentOverview_PF(getWebDriver());
        }
    }

    @And("Click On Unit, Assignment And Assign Specific Assignment Type Expert Track")
    public void SelectUnitAndAssignSpecificAssignmentTypeETForCorrectAnswers() throws InterruptedException{
        TestRunner.startTest("Click On Unit, Assign Specific Assignment Type Expert Track");
        ensurePageObjectsInitialized();
        try {
            getWebDriverWait().until(ExpectedConditions.invisibilityOf(getLoader()));
            assignmentOverviewPf.ReleaseAssignmentTypeETForOverview();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
        Thread.sleep(3000);
    }

    @And("Click On Unit, Assignment And Assign Specific Assignment Type Vocabulary Builder")
    public void SelectUnitAndAssignSpecificAssignmentTypeVBForCorrectAnswers() throws InterruptedException{
        TestRunner.startTest("Click On Unit, Assign Specific Assignment Type Vocabulary Builder");
        try {
            getWebDriverWait().until(ExpectedConditions.invisibilityOf(getLoader()));
            assignmentOverviewPf.ReleaseAssignmentTypeVBForOverview();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
        Thread.sleep(3000);
    }

    @And("Click On Unit, Assignment And Assign Specific Assignment Type Vocabulary Quiz")
    public void SelectUnitAndAssignSpecificAssignmentTypeVQForCorrectAnswers() throws InterruptedException{
        TestRunner.startTest("Click On Unit, Assign Specific Assignment Type Vocabulary Builder");
        try {
            getWebDriverWait().until(ExpectedConditions.invisibilityOf(getLoader()));
            assignmentOverviewPf.ReleaseAssignmentTypeVQForOverview();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
        Thread.sleep(3000);
    }

    @And("Click On Unit, Assignment And Assign Specific Assignment Type Digital Student Book")
    public void SelectUnitAndAssignSpecificAssignmentTypeDSBForCorrectAnswers() throws InterruptedException{
        TestRunner.startTest("Click On Unit, Assign Specific Assignment Type Digital Student Book");
        try {
            getWebDriverWait().until(ExpectedConditions.invisibilityOf(getLoader()));
            assignmentOverviewPf.ReleaseAssignmentTypeDSBForOverview();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
        Thread.sleep(3000);
    }

    @And("Click On Tab, Start And Submit Specific Assignment With Correct Answers and overview")
    public void SelectTabAndStartSpecificAssignmentForOverview() throws InterruptedException, AWTException {
        TestRunner.startTest("Click on Open Tab and Start Specific Assignment");
        ensurePageObjectsInitialized();
        try {
            assignmentOverviewPf.SelectAssignmentForCorrectAnswers();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }
    

}
