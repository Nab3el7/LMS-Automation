package StepDefinitions.Dashboard;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import io.cucumber.java.mk_latn.No;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Assignmment.ReleaseAssignment_PF;
import pageFactory.Dashboard.TeacherDashboard_PF;

import java.awt.*;
import java.time.Duration;

import static pageFactory.Dashboard.TeacherDashboard_PF.currentValueForAssignmentsDue;
import static pageFactory.MyContent.AssignAssessment_PF.endDateTime;
import static pageFactory.MyContent.AssignAssessment_PF.startDateTime;

public class TeacherDashboardSteps extends Configurations {
    WebDriver driver = Configurations.getDriver();
    Helper helper;
    TeacherDashboard_PF teacherDashboardPf;
    public WebDriverWait wait;
//    WebElement loader = driver.findElement(By.xpath("(//span[@role='progressbar'])[1]"));

    public TeacherDashboardSteps() {
        teacherDashboardPf = new TeacherDashboard_PF(driver);
        helper = new Helper();
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
    }

    @And("Verify Teacher dashboard")
    public void Verifyteacherdashboard() throws InterruptedException {
        TestRunner.startTest("Click on Teacher Dashboard");
        try {
//            wait.until(ExpectedConditions.invisibilityOf(loader));
            teacherDashboardPf.verifyTeacherdashboard();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found Teacher Dashboard not found");
            Assert.fail();
        }
    }

    @And("Verify Show All Classes Dropdown")
    public void VerifyShowAllClasses() throws InterruptedException {
        TestRunner.startTest("Click on Show All Classes Drop Down");
        try {
//            wait.until(ExpectedConditions.invisibilityOf(loader));
            teacherDashboardPf.ShowAllClasses();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found All Classes Drop Down not found");
            Assert.fail();

        }
    }

    @And("Select the All Class and Get All Courses And Click On Course")
    public void SelectAllClassAndAllCourses() throws InterruptedException {
        TestRunner.startTest("  Select the Class and Get All Courses And Click On Courses **********");
        try {
            teacherDashboardPf.selectAllClassAndCourse();
            Thread.sleep(500);
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed     :   Exception is found");
            Assert.fail();
        }
    }

    @And("Go Back To Dashboard")
    public void GoBackToDashboard() throws InterruptedException {
        TestRunner.startTest("Go Back To Dashboard");
        try {
            teacherDashboardPf.goToDashboardAgain();

        }catch (NoSuchElementException | ElementNotInteractableException ex) {
            System.out.println(ex.getMessage());
            System.out.println("Exception line number:  " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Click On Need Grading Tabs On Teacher Dashboard")
    public void SelectNeedGradingWight() throws InterruptedException {
        TestRunner.startTest("Teacher Need Grading Dashboard");
        try {
            teacherDashboardPf.selectNeedGrading();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }

    }

    @And("Click On Tab And Edit Assignment On Need Grading Wight")
    public void SelectTabAndEditAssignment() throws InterruptedException, AWTException {
        TestRunner.startTest(" Click on Edit button **********");
        try {
            teacherDashboardPf.selectAssignmentIntoNeedGrading();
            TestRunner.getTest().log(Status.PASS, " Test Case Passed :     :    Question Attempted Successfully  **********");
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed :    :   Exception is found  **********" + e);
            Assert.fail();
        }
    }

    @And("Click On Usage Statistics On Teacher Dashboard")
    public void SelectUsageStatisticsWight() throws InterruptedException {
        TestRunner.startTest("Click On Usage Statistics On Teacher Dashboard");
        try {
            teacherDashboardPf.selectUsageStatistics();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }

    }

    @And("Click On Tab User Usage On Usage Statistics Widget")
    public void SelectTab_User_Usage() throws InterruptedException, AWTException {
        TestRunner.startTest("Click On Tab User Usage On Usage Statistics Widget");
        try {
            teacherDashboardPf.selectUsage_Statistics_Count();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed :    :   Exception is found  **********" + e);
            Assert.fail();
        }

        Actions actions = new Actions(driver);
        actions.sendKeys(Keys.ESCAPE).perform();
    }

    @And("Select the All Class and Check Student Performance")
    public void SelectAllClassAndCheckStudentPerformance() throws InterruptedException {
        TestRunner.startTest("  Select the Class and Check Student Performance **********");
        try {
            teacherDashboardPf.selectAllClassAndStudentPerformance();
            Thread.sleep(500);
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed     :   Exception is found");
            Assert.fail();
        }
    }

    @And("Click On My Student Wight On Teacher Dashboard")
    public void SelectMyStudentWight() throws InterruptedException {
        TestRunner.startTest("Click On My Student Wight On Teacher Dashboard");
        try {
            teacherDashboardPf.selectMyStudent();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }

    }

    @And("Click On Student List On My Student Wight")
    public void SelectStdent_List() throws InterruptedException, AWTException {
        TestRunner.startTest(" Click on Edit button **********");
        try {
            teacherDashboardPf.selectMyStudentList();
            TestRunner.getTest().log(Status.PASS, " Test Case Passed :     :    Question Attempted Successfully  **********");
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed :    :   Exception is found  **********" + e);
            Assert.fail();
        }
    }

    @And("Click On Calander Wight On Teacher Dashboard")
    public void SelectCalanderdateWight() throws InterruptedException {
        TestRunner.startTest("Teacher Need Grading Dashboard");
        try {
            teacherDashboardPf.SelectCalanderdate();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }

    }

    @And("Validate and Click on View All On My Students Widget")
    public void ValidateAndClickOnViewAllOnMyStudentWidget() throws InterruptedException {
        TestRunner.startTest("Validate and Click on View All On My Student Widget");
        try {
            teacherDashboardPf.verifyViewAllButtonStudentsWidget();
        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }


    @And("Validate and Check Recent Activity")
    public void ValidateAndCheckRecentActivity() throws InterruptedException {
        TestRunner.startTest("Validate and Check Recent Activity");
        try {
            teacherDashboardPf.getRecentActivities();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Validate and Click on View All on Recent Activity")
    public void ValidateAndClickOnViewAllOnRecentActivity() throws InterruptedException {
        TestRunner.startTest("Validate and Click on View All on Recent Activity");
        try {
            teacherDashboardPf.ViewAllRecentActivity();
        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Get Data From User Accounts Usage")
    public void GetDataFromUserAccountsUsage() throws InterruptedException {
        TestRunner.startTest("Get Data From User Accounts Usage");
        try{
            teacherDashboardPf.getAccountUsageInformation();
        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Validate and Check Needs Grading Widget")
    public void ValidateAndCheckNeedsGradingWidget() throws InterruptedException{
        TestRunner.startTest("Validate and Check Needs Grading Widget");

        try {

            teacherDashboardPf.validateNeedsGradingWidget();
        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Validate and Click on This Week From Needs Grading")
    public void ValidateAndClickOnThisWeekFromNeedsGrading() throws InterruptedException{
        TestRunner.startTest("Validate and Click on This Week From Needs Grading");
        try {

            teacherDashboardPf.clickThisWeekTab();
        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Validate And Select Assignment From Needs Grading")
    public void ValidateAndSelectAssignmentFromNeedsGrading() throws InterruptedException {
        TestRunner.startTest("Validate And Select Assignment From Needs Grading");
        try {

            teacherDashboardPf.verifyAndSelectAssignment();
        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Validate Needs Grading In Grading Tab")
    public void ValidateNeedsGradingInGradingTab() throws InterruptedException {
        TestRunner.startTest("Validate Needs Grading In Grading Tab");

        try {
            teacherDashboardPf.viewGradingTab();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Validate and Match Assignment Name on Grading Tab")
    public void ValidateAndMatchAssignmentNameOnGradingTab() throws InterruptedException {
        TestRunner.startTest("Validate and Match Assignment Name on Grading Tab");
        try {
            teacherDashboardPf.verifyAssignmentNameOnGradingTab();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Validate and Click on View All on Needs Grading")
    public void ValidateAndClickOnViewAllOnNeedsGrading() throws InterruptedException{
        TestRunner.startTest("Validate and Click on View All on Needs Grading");
        try {

            teacherDashboardPf.viewAllNeedsGrading();
        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }
    WebElement loader = driver.findElement(By.xpath("//span[@role='progressbar']"));

    ReleaseAssignment_PF releaseAssignment_pf;

    @And("Click On Unit, Assignment And Assign Specific Assignment Type Vocabulary Quiz For Assignments Due")
    public void SelectUnitAndAssignSpecificAssignmentTypeVQForCorrectAnswers() throws InterruptedException{
        TestRunner.startTest("Assign Assignment Type Vocabulary Quiz For Correct Answer");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            teacherDashboardPf.ReleaseAssignmentTypeVQForAssignmentsDue();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
        Thread.sleep(3000);
    }

    @And("Select Date From Assignments Due Widget")
    public void SelectDateFromAssignmentsDueWidget() throws InterruptedException {
        TestRunner.startTest("Select Date From Assignments Due Widget");

        try {

            teacherDashboardPf.selectDateFromAssignmentsDue(currentValueForAssignmentsDue);
        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Validate and Check Assignment is Present in Assignments Due")
    public void ValidateAndCheckAssignmentIsPresentInAssignmentsDue() throws InterruptedException {
        TestRunner.startTest("Validate and Check Assignment is Present in Assignments Due");
        try {

            teacherDashboardPf.verifyAssignmentPresent();
        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Validate Assignment Name Match on Summary")
    public void ValidateAssignmentNameMatchOnSummary() throws InterruptedException {
        TestRunner.startTest("Validate Assignment Name Match on Summary");
        try {

            teacherDashboardPf.AssignmentNameOnSummary();
        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Validate BreadCrumb on Summary")
    public void ValidateBreadCrumbOnSummary() throws InterruptedException {
        TestRunner.startTest("Validate BreadCrumb on Summary");
        try {
            teacherDashboardPf.verifySummaryBreadCrumb();
        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }


    @And("Validate and Check View All In Assignments Due")
    public void ValidateAndCheckViewAllInAssignmentsDue() throws InterruptedException{
        TestRunner.startTest("Validate and Check View All In Assignments Due");

        try {
            teacherDashboardPf.viewAllAssignmentsDue();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }
}
