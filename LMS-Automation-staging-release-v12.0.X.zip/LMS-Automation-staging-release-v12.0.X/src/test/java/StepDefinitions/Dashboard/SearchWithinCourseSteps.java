package StepDefinitions.Dashboard;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Dashboard.SearchWithinCourse_PF;
import pageFactory.Gradebook.SelectedStudent_PF;

import java.time.Duration;

public class SearchWithinCourseSteps {

    WebDriver driver = Configurations.getDriver();
    Helper helper;
    Actions actions;
    public WebDriverWait wait;
    SearchWithinCourse_PF searchWithinCourse_pf;

    WebElement loader = driver.findElement(By.xpath("//span[@role='progressbar']"));

    SelectedStudent_PF selectedStudent_pf;

    public SearchWithinCourseSteps() {
        helper = new Helper();
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
        actions = new Actions(driver);
        selectedStudent_pf = new SelectedStudent_PF(driver);
        searchWithinCourse_pf = new SearchWithinCourse_PF(driver);
    }

    @And("Click On Unit, Assignment, and Get Assignment Name")
    public void ClickOnUnitAssignmentAndGetAssignmentName() throws InterruptedException {
        TestRunner.startTest("Click On Unit, Assignment, and Get Assignment Name");
        try {
            searchWithinCourse_pf.GetAssignmentTypeName();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Search Name of Assignment In Search Box")
    public void SearchNameOfAssignmentInSearchBox() throws InterruptedException {
        TestRunner.startTest("Search Name of Assignment In Search Box");
        try {
            searchWithinCourse_pf.searchAssignmentName();
        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Validate and Click on Assignment From Left Panel")
    public void ValidateAndClickOnAssignmentFromLeftPanel() throws InterruptedException {
        TestRunner.startTest("Validate and Click on Assignment From Left Panel");
        try {
            searchWithinCourse_pf.getAssignmentNameFromPanelAndPerformClick();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Validate and Click on Assign Button")
    public void ValidateAndClickOnAssignButton() throws InterruptedException {
        TestRunner.startTest("Validate and Click on Assign Button");
        try {
            searchWithinCourse_pf.verifyAssignButton();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Validate and Assign Assignment")
    public void ValidateAndAssignAssignment() throws InterruptedException {
        TestRunner.startTest("Validate and Assign Assignment");
        try {

            searchWithinCourse_pf.assignAssignment();
        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }
}
