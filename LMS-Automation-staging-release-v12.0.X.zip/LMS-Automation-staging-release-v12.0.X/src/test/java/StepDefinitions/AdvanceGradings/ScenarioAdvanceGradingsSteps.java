package StepDefinitions.AdvanceGradings;

import StepDefinitions.Configurations;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Assignmment.ReleaseAssignment_PF;
import pageFactory.Assignmment.ScenarioAdvanceGradings_PF;
import pageFactory.Gradebook.ManualGrading_PF;

import java.time.Duration;

public class ScenarioAdvanceGradingsSteps extends Configurations {
    WebDriver driver = Configurations.getDriver();
    public WebDriverWait wait;
    WebElement loader = driver.findElement(By.xpath("//span[@role='progressbar']"));

    ReleaseAssignment_PF releaseAssignment_pf;
    ScenarioAdvanceGradings_PF scenarioAdvanceGradings_PF;
    ManualGrading_PF manualGrading_PF;

    public ScenarioAdvanceGradingsSteps() {
        wait = new WebDriverWait(driver, Duration.ofSeconds(120));
        releaseAssignment_pf = new ReleaseAssignment_PF(driver);
        scenarioAdvanceGradings_PF = new ScenarioAdvanceGradings_PF(driver);
    }

    @And("Verify Scenario Advance Grading Main Grade Toggle Button Type DSB")
    public void scenarioAdvancedGradingMainGradeToggleButtonTypeDSB() throws InterruptedException{
        TestRunner.startTest("Scenario Advanced Grading Main Grading Option Type DSB");
        try {

            scenarioAdvanceGradings_PF.releaseAssignmentDSBScenarioGradeMainToggleButton();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Verify Scenario Advance Grading Main Grade Toggle Button Type ET")
    public void scenarioAdvancedGradingMainGradeToggleButtonTypeET() throws InterruptedException{
        TestRunner.startTest("Scenario Advanced Grading Main Grading Option Type ET");
        try {

            scenarioAdvanceGradings_PF.releaseAssignmentETScenarioGradeMainToggleButton();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Verify Scenario Advance Grading Main Grade Toggle Button Type VB")
    public void scenarioAdvancedGradingMainGradeToggleButtonTypeVB() throws InterruptedException{
        TestRunner.startTest("Scenario Advanced Grading Main Grading Option Type VB");
        try {

            scenarioAdvanceGradings_PF.releaseAssignmentVBScenarioGradeMainToggleButton();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Verify Scenario Advance Grading Main Grade Toggle Button Type VQ")
    public void scenarioAdvancedGradingMainGradeToggleButtonTypeVQ() throws InterruptedException{
        TestRunner.startTest("Scenario Advanced Grading Main Grading Option Type VQ");
        try {

            scenarioAdvanceGradings_PF.releaseAssignmentVQScenarioGradeMainToggleButton();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Verify Scenario Advance Grading Particular Question Grade Toggle Button Type DSB")
    public void scenarioAdvancedGradingParticularQuestionGradeToggleButtonTypeDSB() throws InterruptedException{
        TestRunner.startTest("Scenario Advanced Grading Particular Question Grading Option Type DSB");
        try {

            scenarioAdvanceGradings_PF.releaseAssignmentDSBScenarioParticularQuestionGradeToggleButton();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Verify Scenario Advance Grading Particular Question Grade Toggle Button Type ET")
    public void scenarioAdvancedGradingParticularQuestionGradeToggleButtonTypeET() throws InterruptedException{
        TestRunner.startTest("Scenario Advanced Grading Particular Question Grading Option Type ET");
        try {

            scenarioAdvanceGradings_PF.releaseAssignmentETScenarioParticularQuestionGradeToggleButton();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Verify Scenario Advance Grading Particular Question Grade Toggle Button Type VB")
    public void scenarioAdvancedGradingParticularQuestionGradeToggleButtonTypeVB() throws InterruptedException{
        TestRunner.startTest("Scenario Advanced Grading Particular Question Grading Option Type VB");
        try {

            scenarioAdvanceGradings_PF.releaseAssignmentVBScenarioParticularQuestionGradeToggleButton();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Verify Scenario Advance Grading Particular Question Grade Toggle Button Type VQ")
    public void scenarioAdvancedGradingParticularQuestionGradeToggleButtonTypeVQ() throws InterruptedException{
        TestRunner.startTest("Scenario Advanced Grading Particular Question Grading Option Type VQ");
        try {

            scenarioAdvanceGradings_PF.releaseAssignmentVQScenarioParticularQuestionGradeToggleButton();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Verify Scenario Advance Grading Distributed Weight Evenly Type DSB")
    public void scenarioAdvancedGradingDistributedWeightEvenlyTypeDSB() throws InterruptedException{
        TestRunner.startTest("Scenario Advanced Grading Distributed Weight Evenly Type DSB");
        try {

            scenarioAdvanceGradings_PF.releaseAssignmentDSBScenarioDistributeWeightEvenly();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Verify Scenario Advance Grading Distributed Weight Evenly Type ET")
    public void scenarioAdvancedGradingDistributedWeightEvenlyTypeET() throws InterruptedException{
        TestRunner.startTest("Scenario Advanced Grading Distributed Weight Evenly Type ET");
        try {

            scenarioAdvanceGradings_PF.releaseAssignmentETScenarioDistributeWeightEvenly();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Verify Scenario Advance Grading Distributed Weight Evenly Type VB")
    public void scenarioAdvancedGradingDistributedWeightEvenlyTypeVB() throws InterruptedException{
        TestRunner.startTest("Scenario Advanced Grading Distributed Weight Evenly Type VB");
        try {

            scenarioAdvanceGradings_PF.releaseAssignmentVBScenarioDistributeWeightEvenly();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Verify Scenario Advance Grading Distributed Weight Evenly Type VQ")
    public void scenarioAdvancedGradingDistributedWeightEvenlyTypeVQ() throws InterruptedException{
        TestRunner.startTest("Scenario Advanced Grading Distributed Weight Evenly Type VQ");
        try {

            scenarioAdvanceGradings_PF.releaseAssignmentVQScenarioDistributeWeightEvenly();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Verify Scenario Advance Grading UI Behavior")
    public void scenarioAdvancedGradingUIBehavior() throws InterruptedException{
        TestRunner.startTest("Scenario Advanced Grading UI Behavior");
        try {

            scenarioAdvanceGradings_PF.releaseAssignmentScenarioAdvanceGradingsUIBehavior();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Verify Scenario Advance Grading All Question Grade Toggle Button")
    public void scenarioAdvancedGradingAllQuestionGradeToggleButton() throws InterruptedException{
        TestRunner.startTest("Scenario Advanced Grading All Question Grading");
        try {

            scenarioAdvanceGradings_PF.releaseAssignmentScenarioAllQuestionGradeToggleButton();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Verify Advanced Grading All Scenario In Close Tab")
    public void AdvancedGradingInCloseTab() throws InterruptedException{
        TestRunner.startTest("In Close Tab Verify Advanced Grading Option");
        try {
            scenarioAdvanceGradings_PF.verifyAdvancedGradingScenarios();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Verify Total Advanced Grading In Close Tab")
    public void VerifyAdvancedGradingInCloseTab() throws InterruptedException{
        TestRunner.startTest("In Close Tab Verify Total Advanced Grading");
        try {
            scenarioAdvanceGradings_PF.verifyTotalGradings();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Check, Validate Advanced Grading PointsWeights In Selected Student Tab")
    public void CheckValidateAdvancedGradingPointsWeightsInSelectedStudentTab() throws InterruptedException{
        TestRunner.startTest("Check, Validate Advanced Grading Points/Weights In Selected Student Tab");
        try {
            scenarioAdvanceGradings_PF.ValidateAdvancedGradingPointsWeightsInSelectedStudentTab();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Get And Validate The Assignment Summary Score")
    public void clickOnStudentCheckBox() throws InterruptedException{
        TestRunner.startTest("Get and validate the assignment summary score");
        try {
            manualGrading_PF.AssignmentScoresSummary();
            System.out.println("Test Case Passed    :   Get and validate the assignment summary successfully");
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
            Assert.fail();
        }
        Thread.sleep(1000);
    }
}
