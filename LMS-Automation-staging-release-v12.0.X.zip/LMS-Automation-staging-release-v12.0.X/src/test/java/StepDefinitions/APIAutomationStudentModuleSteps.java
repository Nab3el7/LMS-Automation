package StepDefinitions;

import APIAutomation.POST.POSTStudentsLoginAPI;
import APIAutomation.Students.StudentSideDashboard.*;
import APIAutomation.Students.StudentSideDashboard.POST.POSTMarkAllAsReadAPI;
import APIAutomation.Students.StudentSideDashboard.POST.POSTReadStatusAPI;
import APIAutomation.Students.StudentSideDashboard.POST.POSTStudentSideSaveUserUsageAPI;
import APIAutomation.POST.LoginAPI;
import APIAutomation.Students.SubmitAssignment.SaveStudentClassAssignment;
import io.cucumber.java.en.And;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

//import static StepDefinitions.Configurations.driver;

public class APIAutomationStudentModuleSteps extends Configurations{
    WebDriver driver = Configurations.getDriver();
    Helper helper;
    LoginAPI loginAPI;
    POSTStudentsLoginAPI postStudentsLoginAPI;

    String myCourseClassID= "-1";
    String page = "1";
    String size = "20";
    DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    String calendarStartDate = LocalDate.now().format(dateFormatter);
    String calendarEndDate = LocalDate.now().format(dateFormatter);

    // For StudentSide API'S
    GetUserDashboardStudentSideAPI getUserDashboardStudentSideAPI;
    GetStudentDueAssignmentAPI getStudentDueAssignmentAPI;
    GetStudentCoursesAPI getStudentCoursesAPI;
    GetNewPageAPI getNewPageAPI;
    POSTReadStatusAPI postReadStatusAPI;
    POSTMarkAllAsReadAPI postMarkAllAsReadAPI;
    POSTStudentSideSaveUserUsageAPI postStudentSideSaveUserUsageAPI;
    StudentSideUserProfileAPI studentSideUserProfileAPI;
    GetStudentAssignmentsFilterCountsAPI getStudentAssignmentsFilterCountsAPI;
    GetStudentSideUserModuleAPI getStudentSideUserModuleAPI;
    SaveStudentClassAssignment saveStudentClassAssignment;

    public APIAutomationStudentModuleSteps() {
        helper = new Helper();
        loginAPI = new LoginAPI(driver);
        postStudentsLoginAPI = new POSTStudentsLoginAPI(driver);

        getUserDashboardStudentSideAPI = new GetUserDashboardStudentSideAPI(driver);
        getStudentDueAssignmentAPI = new GetStudentDueAssignmentAPI(driver);
        getStudentCoursesAPI = new GetStudentCoursesAPI(driver);
        getNewPageAPI = new GetNewPageAPI(driver);
        postReadStatusAPI = new POSTReadStatusAPI(driver);
        postMarkAllAsReadAPI = new POSTMarkAllAsReadAPI(driver);
        postStudentSideSaveUserUsageAPI = new POSTStudentSideSaveUserUsageAPI(driver);
        studentSideUserProfileAPI = new StudentSideUserProfileAPI(driver);
        getStudentAssignmentsFilterCountsAPI = new GetStudentAssignmentsFilterCountsAPI(driver);
        getStudentSideUserModuleAPI = new GetStudentSideUserModuleAPI(driver);
        saveStudentClassAssignment = new SaveStudentClassAssignment(driver);
    }


    @And("POST Students Login API")
    public void TeacherLoginForAccessToken() {
        System.out.println("I'm in to call the students login api");
        try {
            postStudentsLoginAPI.LoginStudentsWithCsvData();
            System.out.println("Test Case Passed    :   Teacher is login through api successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            System.out.println("Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    // Student side  Dashboard Module API

    @And("Get Student-Side getUserDashboard API")
    public void get_studentSide_getUserDashboard_API(){
        System.out.println("I'm in to call StudentSide Get UserDashboard API");
        try {
            getUserDashboardStudentSideAPI.getUserDashboardStudentSideAPIConcurrently();
            System.out.println("Test Case Passed    :   API run successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            System.out.println("Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }


    @And("Get Student-Side StudentDueAssignment API")
    public void Get_StudentSide_StudentDueAssignment_API(){
        System.out.println("I'm in to call StudentSide Get StudentDueAssignment API");
        try {
            getStudentDueAssignmentAPI.getStudentDueAssignmentAPIConcurrently();
            System.out.println("Test Case Passed    :   API run successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            System.out.println("Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("Get Student-Side StudentCourses API")
    public void get_Student_Side_StudentCourses_API(){
        System.out.println("I'm in to call StudentSide Get StudentCourses API");
        try {
            getStudentCoursesAPI.getStudentCoursesAPIConcurrently();
            System.out.println("Test Case Passed    :   API run successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            System.out.println("Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }


    @And("Get Student-Side announcements getNewPage API")
    public void get_Student_Side_announcements_getNewPage_API(){
        System.out.println("I'm in to call StudentSide Get announcements getNewPage API");
        try {
            getNewPageAPI.getNewPageAPIConcurrently(page,size);
            System.out.println("Test Case Passed    :   API run successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            System.out.println("Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("POST Student-Side ReadStatus API")
    public void POST_Student_Side_ReadStatus_API(){
        System.out.println("I'm in to call StudentSide POST announcements ReadStatus API");
        try {
            postReadStatusAPI.getReadStatusAPIConcurrently();
            System.out.println("Test Case Passed    :   API run successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            System.out.println("Test Case Failed    :   Exception is found");
            Assert.fail();
        }

    }

    @And("POST Student-Side MarkAllAsRead API")
    public void POST_Student_Side_MarkAllAsRead_API(){
        System.out.println("I'm in to call StudentSide POST announcements MarkAllAsRead API");
        try {
            postMarkAllAsReadAPI.getMarkAllAsReadAPIConcurrently();
            System.out.println("Test Case Passed    :   API run successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            System.out.println("Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("POST Student-Side SaveUserUsage API")
    public void POST_Student_Side_SaveUserUsage_API(){
        System.out.println("I'm in to call StudentSide POST  SaveUserUsage API");
        try {
            postStudentSideSaveUserUsageAPI.getStudentSideSaveUserUsageAPIConcurrently();
            System.out.println("Test Case Passed    :   API run successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            System.out.println("Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("Get Student-Side getUserProfile API")
    public void Get_Student_Side_getUserProfile_API(){
        System.out.println("I'm in to call StudentSide GET  getUserProfile API");
        try {
            studentSideUserProfileAPI.getStudentSideUserProfileAPIConcurrently();
            System.out.println("Test Case Passed    :   API run successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            System.out.println("Test Case Failed    :   Exception is found");
            Assert.fail();
        }

    }

    @And("Get Student-Side getStudentAssignmentsFilterCounts API")
    public void Get_Student_Side_getStudentAssignmentsFilterCounts_API(){
        System.out.println("I'm in to call StudentSide GET  getStudentAssignmentsFilterCounts API");
        try {
            getStudentAssignmentsFilterCountsAPI.getStudentSideAssignmentsFilterCountsAPIConcurrently(calendarStartDate,calendarEndDate,myCourseClassID);
            System.out.println("Test Case Passed    :   API run successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            System.out.println("Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("Get Student-Side UserModule API")
    public void Get_Student_Side_UserModule_API(){
        System.out.println("I'm in to call StudentSide GET  UserModule API");
        try {
            getStudentSideUserModuleAPI.getStudentSideUserModuleAPIConcurrently();
            System.out.println("Test Case Passed    :   API run successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            System.out.println("Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("POST Student-Side SubmitAssignment API")
    public void POSTStudentSubmitAssignmentAPI(){
        System.out.println("I'm in to call StudentSide saveStudentClassAssignment/submit API");
        try {
            saveStudentClassAssignment.saveStudentClassAssignmentConcurrently();
            System.out.println("Test Case Passed    :   API run successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            System.out.println("Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

}
