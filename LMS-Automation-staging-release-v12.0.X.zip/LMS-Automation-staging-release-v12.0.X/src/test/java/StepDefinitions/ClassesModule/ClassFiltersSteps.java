package StepDefinitions.ClassesModule;

import StepDefinitions.AssignmentReviewSteps;
import StepDefinitions.Configurations;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import org.junit.Assert;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Classes.AddClass_PF;
import pageFactory.Classes.ClassFilters_PF;

import java.time.Duration;

public class ClassFiltersSteps extends Configurations {
    WebDriver driver = Configurations.getDriver();

    ClassFilters_PF classFiltersPF;

    public WebDriverWait wait;

    AddClass_PF addClassPF;



    public ClassFiltersSteps() {
        classFiltersPF = new ClassFilters_PF(driver);
        addClassPF = new AddClass_PF(driver);
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
    }

    @And("Select School District For School Filters")
    public void selectSchoolDistrict() {
        TestRunner.startTest( " I'm in to select school district");
        try {
            classFiltersPF.selectSchoolDistrict();
        } catch (Exception e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
            Assert.fail();
        }
    }

    @And("Select School For School Filters")
    public void selectSchool() {
        TestRunner.startTest( " I'm in to select school");
        try {
            String schoolName = addClassPF.getSelectedSchool();
            System.out.println("School name is: " + schoolName);
            classFiltersPF.selectSchool(schoolName);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("Select School Teacher For School Filters")
    public void selectSchoolTeacher() {
        TestRunner.startTest( "I'm in to select school teacher");
        try {
            classFiltersPF.selectSchoolTeacher();
        } catch (Exception e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("Click on Apply Filter Button In Class")
    public void clickFilterButton() throws InterruptedException{
        TestRunner.startTest( "Check and Click on Apply Filter Button");
        try {
            classFiltersPF.applySchoolFilter();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("Verify Classes Shows Into Table")
    public void verifyClassesShowsIntoTable() throws InterruptedException {
        TestRunner.startTest( "Verify Classes Shows Into Table");
        try {
            classFiltersPF.showsClassesIntoTable();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("Search New Class By Keyword")
    public void searchNewClassByKeyword(){
        TestRunner.startTest( "Search The New Class Added");
        try {
            classFiltersPF.searchClassByName();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("Verify The New Class by Keyword")
    public void verifyNewClassByKeyword(){
        TestRunner.startTest( "Verify The New Class Added");
        try {
            classFiltersPF.verifySearchedClassByNameIntoTable();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }
}
