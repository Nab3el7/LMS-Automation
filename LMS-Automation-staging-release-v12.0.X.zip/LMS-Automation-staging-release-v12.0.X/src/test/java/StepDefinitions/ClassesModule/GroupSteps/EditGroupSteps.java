package StepDefinitions.ClassesModule.GroupSteps;

import StepDefinitions.Configurations;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Classes.Group.EditGroup_PF;

import java.time.Duration;

public class EditGroupSteps extends Configurations {
    WebDriver driver = Configurations.getDriver();
    public WebDriverWait wait;
    EditGroup_PF editGroupPf;

    WebElement loader = driver.findElement(By.xpath("//span[@role='progressbar']"));

    public EditGroupSteps() {
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
        editGroupPf = new EditGroup_PF(driver);
    }


    @And("Click On Class Edit Group Button")
    public void ClickOnClassEditGroupButton() throws InterruptedException{
        TestRunner.startTest( " Check and validate to Click on Edit Group in Class");
        try {
            editGroupPf.clickEditGroupButton();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
            Assert.fail();
        }
    }

    @And("Validate and Edit Group Class Information")
    public void EditGroupClassInformation() throws InterruptedException{
        TestRunner.startTest( "Check and validate to Edit Group Class Information");
        try {
            editGroupPf.editGroupClassInfo();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
            Assert.fail();
        }
    }

    @And("Validate and Edit Class Information To Add New Student in Group for Edit")
    public void SelectStudentGradesForEditStudent() throws InterruptedException{
        TestRunner.startTest( "Validate and Edit Class Information To Add New Student in Group for Edit");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            editGroupPf.SelectNewStudentForEditInGroup();
        }  catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
            Assert.fail();
        }
    }

    @And("Click on Group Save Button")
    public void ClickOnGroupSaveNextButton(){
        TestRunner.startTest( "Click On Group Save/Next Button");
        try {
            editGroupPf.clickOnGroupSaveButton();
        }  catch (NoSuchElementException | ElementNotInteractableException | InterruptedException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
            Assert.fail();
        }
    }

    @And("Validate and Edit Group Class Information InActive")
    public void EditGroupClassInformationInActive() throws InterruptedException{
        TestRunner.startTest( "Check and validate to Edit Group Class Information InActive");
        try {
            editGroupPf.editGroupClassInfoInActive();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
            Assert.fail();
        }
    }

    @And("Validate InActive Group Should Not Visible")
    public void validateInActiveGroupNotVisible() throws InterruptedException{
        TestRunner.startTest( "Check and validate to InActive Group Should not visible");
        try {
            editGroupPf.validateInActiveGroup();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
            Assert.fail();
        }
    }

    @And("Verify And Select Group In GradeBook Groups List")
    public void VerifyAndSelectGroupInGradeBookGroupsList() throws InterruptedException{
        TestRunner.startTest( "Verify And Select Group In GradeBook Group List");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            editGroupPf.searchAndSelectGroupInGradeBook();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Student not found in List ");
            Assert.fail();
        }
    }

    @And("Verify And Select Specific Group In GradeBook Groups List")
    public void VerifyAndSelectSpecificGroupInGradeBookGroupsList() throws InterruptedException{
        TestRunner.startTest( "Verify And Select Specific Group In GradeBook Group List");
        try {
            editGroupPf.searchAndSelectSpecificGroupInGradeBook();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Student not found in List ");
            Assert.fail();
        }
    }
}
