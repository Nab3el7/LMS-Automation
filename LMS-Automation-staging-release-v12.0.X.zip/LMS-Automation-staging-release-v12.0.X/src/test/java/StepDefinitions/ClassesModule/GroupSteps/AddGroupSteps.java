package StepDefinitions.ClassesModule.GroupSteps;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Classes.Group.AddGroup_PF;

import java.time.Duration;

public class AddGroupSteps extends Configurations {
    WebDriver driver = Configurations.getDriver();

    AddGroup_PF addGroupPF;
    Helper helper;
    public WebDriverWait wait;

    WebElement loader = driver.findElement(By.xpath("//span[@role='progressbar']"));


    public AddGroupSteps() {
        addGroupPF = new AddGroup_PF(driver);
        helper = new Helper();
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
    }

    @And("Click on Add Group Button")
    public void ClickOnAddGroupButton(){
        TestRunner.startTest( " Click On Add Class Button");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            addGroupPF.clickOnAddGroup();
        }catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
            Assert.fail();
        }

    }

    @And("Enter the New Group Name")
    public void EnterNewGroupName(){
        TestRunner.startTest( "Enter New Group Name");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            addGroupPF.EnterNewGroupName();
        }catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
            Assert.fail();
        }
    }

    @And("Select the New Group Class")
    public void SelectNewGroupClass(){
        TestRunner.startTest( "Select New Group Class From DropDown");
        try {
            addGroupPF.SelectNewGroupClass();
            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
        }  catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
            Assert.fail();
        }
    }

    @And("Enter the New Group Description")
    public void EnterNewGroupDescription(){
        TestRunner.startTest( "Enter Group Description");
        try {
            addGroupPF.EnterNewGroupDescription();
        }  catch (NoSuchElementException | ElementNotInteractableException | InterruptedException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
            Assert.fail();
        }

    }

    @And("Click on Group SaveNext Button")
    public void ClickOnGroupSaveNextButton() throws InterruptedException{
        TestRunner.startTest( "Click On Group Save/Next Button");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            addGroupPF.clickOnGroupSaveNextButton();
        }  catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
            Assert.fail();
        }
    }

    @And("Get the All Students And Select Students in Selected Class")
    public void GetAndSelectStudentsInNewGroup(){
        TestRunner.startTest( "Get the All Students And Select Students in Selected Class");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            addGroupPF.GetTableAllStudentsAndSelect();
        }  catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
            Assert.fail();
        }
    }

    @And("Search And Select Student in New Group")
    public void SearchAndSelectStudentInNewGroup(){
        TestRunner.startTest( "Search And Select Student in New Group");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            addGroupPF.searchAndSelectStudentInNewGroup();
        }  catch (NoSuchElementException | ElementNotInteractableException | InterruptedException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
            Assert.fail();
        }
    }

    @And("Search And Select InActive Student in New Group")
    public void SearchAndSelectInActiveStudentInNewGroup(){
        TestRunner.startTest( "Search And Select InActive Student in New Group");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            addGroupPF.searchAndSelectInActiveStudentInNewGroup();
        }  catch (NoSuchElementException | ElementNotInteractableException | InterruptedException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
            Assert.fail();
        }
    }

    @And("Get And Verify Group Summary")
    public void GetAndVerifyGroupSummary(){
        TestRunner.startTest( "Get And Verify Group Summary");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            addGroupPF.verifyGroupAndStudentInformation();
        }  catch (NoSuchElementException | ElementNotInteractableException | InterruptedException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
            Assert.fail();
        }
    }

    @And("Click on Group Exit Button")
    public void ClickGroupExitButton() throws InterruptedException{
        TestRunner.startTest( "Click On Group Exit Button");
        try {
            addGroupPF.clickOnGroupExitButton();
        }  catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
            Assert.fail();
        }
    }

    @And("Search Class By Keyword For Group")
    public void searchNewClassByKeyword(){
        TestRunner.startTest( "Search The Class Where Group Added");
        try {
            addGroupPF.searchClassByNameForGroup();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("Verify Group Class Shows Into Table")
    public void verifyGroupClassShowsIntoTable() throws InterruptedException {
        TestRunner.startTest( "Verify Group Class Shows Into Table");
        try {
            addGroupPF.showsGroupClassIntoTable();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }
}
