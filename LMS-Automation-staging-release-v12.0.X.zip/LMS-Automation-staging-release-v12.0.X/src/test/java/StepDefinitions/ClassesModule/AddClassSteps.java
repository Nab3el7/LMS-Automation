package StepDefinitions.ClassesModule;

import StepDefinitions.AssignmentReviewSteps;
import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Classes.AddClass_PF;

import java.time.Duration;


public class AddClassSteps extends Configurations {
    WebDriver driver = Configurations.getDriver();

    AddClass_PF addClassPF;
    Helper helper;                      //Create object of Helper class
    public WebDriverWait wait;

    WebElement loader = driver.findElement(By.xpath("//span[@role='progressbar']"));


    public AddClassSteps() {
        addClassPF = new AddClass_PF(driver);
        helper = new Helper();
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
    }

    @And("Check And Validate The Side Navbar And Clicked On Class")
    public void VerifySideNavBarAndClickOnClass() {
        TestRunner.startTest( " I'm in to verify Teacher Class Module link");
        try {
            addClassPF.SideNavBarAndClickOnClass();
        } catch (Exception e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
            Assert.fail();
        }
    }

    @And("Check And Validate The Class Dashboard")
    public void VerifyGradeBookDashboard() {
        TestRunner.startTest( "Verify the Class dashboard all elements");
        try {
            addClassPF.ClassDashboard();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
            Assert.fail();
        }
    }

    @And("Click on Add Class Button")
    public void ClickOnAddClassButton(){
        TestRunner.startTest( " Click On Add Class Button");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            addClassPF.clickOnAddClass();
        }catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
            Assert.fail();
        }

    }

    @And("Enter the Class Name")
    public void AddSchoolName(){
        TestRunner.startTest( "  Enter Class Name ");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            addClassPF.EnterClassName();
        }catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
            Assert.fail();
        }
    }

    @And("Select the School Name")
    public void SelectSchoolName() throws InterruptedException{
        TestRunner.startTest( "  Select School Name ");
        try {
            addClassPF.SelectSchoolName();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
            Assert.fail();
        }
    }

    @And("Select the School Status")
    public void SelectSchoolStatus()throws InterruptedException{
        TestRunner.startTest( "  Select School Status Dropdown");
        try {
            addClassPF.SelectSchoolStatus();
        } catch (NoSuchElementException | ElementNotInteractableException | InterruptedException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
            Assert.fail();
        }
    }

    @And("Select the School Courses")
    public void SelectSchoolCourses() throws InterruptedException{
        TestRunner.startTest( "  Select School Courses Dropdown ");
        try {
            addClassPF.SelectCourses();
            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
        }  catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
            Assert.fail();
        }
    }

    @And("Enter the Course Period Name")
    public void AddCoursePeriodName()throws InterruptedException{
        TestRunner.startTest( "  Enter Period Name ");
        try {
            addClassPF.EnterCoursePeriodName();
        }  catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
            Assert.fail();
        }

    }

    @And("Select the School Course Content")
    public void SelectSchoolCoursesContent()throws InterruptedException{
        TestRunner.startTest( "  Select School Courses Content Dropdown ");
        try {
            addClassPF.SelectCourseContent();
        }  catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
            Assert.fail();
        }
    }

    @And("Click on Ad Co-Teacher Button")
    public void ClickOnAddCoTeacherButton(){
        TestRunner.startTest( "  Click On Add Co Teacher Button");
        try {
            addClassPF.clickOnAdCoTeacher();
        }  catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
            Assert.fail();
        }
    }

    @And("Click on Next Button")
    public void ClickOnNextButton(){
        TestRunner.startTest( "  Click On Next Button ");
        try {
           addClassPF.clickOnNextButton();
        }  catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
            Assert.fail();
        }
    }

    @And("Select the Grade Into Dropdown")
    public void SelectStudentGrades()throws InterruptedException{
        TestRunner.startTest( "  Select Student All Grades Dropdown");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            addClassPF.SelectStudentAllGrades();
        }  catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
            Assert.fail();
        }
    }

    @And("Get the All Students Records in Selected Grade")
    public void GetAllStudentsInGrade(){
        TestRunner.startTest( "  Get All Students Records in Table ");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            addClassPF.GetTableAllStudents();
        }  catch (NoSuchElementException | ElementNotInteractableException | InterruptedException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
            Assert.fail();
        }
    }

    @And("Click On Add New Student in Class of Selected Grade")
    public void AddNewStudentInClass(){
        TestRunner.startTest( "  Add New Student in New Class Creation ");
        try {
            addClassPF.clickOnAddNewStudent();
        }  catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
            Assert.fail();
        }
    }

    @And("Enter the New Student First Name")
    public void AddNewStudentFName(){
        TestRunner.startTest( "  Enter the New Student First Name");
        try {
            addClassPF.EnterClassNewStdFName();
        }  catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
            Assert.fail();
        }
    }

    @And("Enter the New Student Middle Name")
    public void AddNewStudentMName(){
        TestRunner.startTest( "  Enter the New Student Middle Name ");
        try {
            addClassPF.EnterClassNewStdMName();
        }  catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
            Assert.fail();
        }
    }

    @And("Enter the New Student Last Name")
    public void AddNewStudentLName(){
        TestRunner.startTest( "  Enter the New Student Last Name ");
        try {
            addClassPF.EnterClassNewStdLName();
        }  catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
            Assert.fail();
        }
    }

    @And("Enter the New Student Email")
    public void AddNewStudentEmail(){
        TestRunner.startTest( "  Enter the New Student Email ");
        try {
            addClassPF.EnterClassNewStdEmail();
        }  catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
            Assert.fail();
        }
    }

    @And("Enter the New Student Password")
    public void AddNewStudentPassword(){
        TestRunner.startTest( "  Enter the New Student Password");
        try {
            addClassPF.EnterClassNewStdPassword();
        }  catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
            Assert.fail();
        }
    }

    @And("Enter the New Student Confirm Password")
    public void AddNewStudentConfirmPassword(){
        TestRunner.startTest( "  Enter the New Student Confirm Password");
        try {
            addClassPF.EnterClassNewStdConfirmPassword();
        }  catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
            Assert.fail();
        }
    }
    @And("Select the New Student Grade")
    public void SelectNewStudentGrade() throws InterruptedException{
        TestRunner.startTest( "  Select the New Student Grade");
        try {
            addClassPF.SelectClassNewStdGrade();
        }  catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
            Assert.fail();
        }
    }

    @And("Select the New Student Avatar")
    public void SelectNewStudentAvatar(){
        TestRunner.startTest( "  Select the New Student Avatar");
        try {
            addClassPF.EnterClassNewStdAvatar();
        }  catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
            Assert.fail();
        }
    }

    @And("Click on the New Student Save Button")
    public void ClickOnNewStudentSaveButton(){
        TestRunner.startTest( "  Click on the New Student Save Button");
        try {
            addClassPF.SaveClassNewStd();
        }  catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
            Assert.fail();
        }
        Actions actions = new Actions(driver);
        actions.sendKeys(Keys.ESCAPE).perform();
    }

    @And("Click on SaveNext Button")
    public void ClickOnSaveNextButton(){
        TestRunner.startTest( "  Click On Save/Next Button");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            addClassPF.clickOnSaveNextButton();
        }  catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
            Assert.fail();
        }
    }

    @And("Get Summary of Class and Student Info")
    public void GetSummaryOfClassAndStudentInfo(){
        TestRunner.startTest( "  Get Class Info");
        try {
            addClassPF.GetTableClassInfo();

            TestRunner.startTest( "  Get Students Info");
            addClassPF.GetTableStudentInfo();
        }  catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
            Assert.fail();
        }
    }

    @And("Click on Save Button")
    public void ClickSaveButton() throws InterruptedException{
        TestRunner.startTest( "  Click On Save Button");
        try {
            addClassPF.clickOnSave();
//            Thread.sleep(5000);
        }  catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
            Assert.fail();
        }
    }
}
