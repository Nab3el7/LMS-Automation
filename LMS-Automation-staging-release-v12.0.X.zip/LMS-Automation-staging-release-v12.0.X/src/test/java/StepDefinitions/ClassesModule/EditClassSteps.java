package StepDefinitions.ClassesModule;

import StepDefinitions.Configurations;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Classes.EditClass_PF;

import java.time.Duration;

public class EditClassSteps extends Configurations {
    WebDriver driver = Configurations.getDriver();
    public WebDriverWait wait;
    EditClass_PF editClassPF;

    WebElement loader = driver.findElement(By.xpath("//span[@role='progressbar']"));

    public EditClassSteps() {
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
        editClassPF = new EditClass_PF(driver);
    }


    @And("Click On Class Edit Button")
    public void ClickOnClassEditButton() throws InterruptedException{
        TestRunner.startTest( " Check and validate to Click on Edit button in Class");
        try {
            editClassPF.clickEditButton();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
            Assert.fail();
        }
    }

    @And("Validate and Edit Class Information")
    public void EditClassInformation() throws InterruptedException{
        TestRunner.startTest( "Check and validate to Edit Class Information");
        try {
            editClassPF.editClassInfo();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
            Assert.fail();
        }
    }

    @And("Select the Grade Into Dropdown For Edit Student")
    public void SelectStudentGradesForEditStudent() throws InterruptedException{
        TestRunner.startTest( " Select Student All Grades Dropdown ");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            editClassPF.SelectNewStudentGradeForEdit();
        }  catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
            Assert.fail();
        }
    }

    @And("Validate and Edit Class Information To Add New Student")
    public void EditClassSearchStudent() throws InterruptedException{
        TestRunner.startTest( "Check and validate to Edit Class Information to search for Student");
        try {
            editClassPF.editClassInfoSearchStudentByKeyword();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
            Assert.fail();
        }
    }

    @And("Check and Validate The Edited Class Information")
    public void ValidateEditClassInformation() {
        TestRunner.startTest( "Check and validate the Edited Class Information");
        try {
            editClassPF.verifyUpdatedClassPeriod();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
            Assert.fail();
        }
    }

    @And("Check and Validate The Side Navbar And Click on Dashboard")
    public void ValidateSideNavbarAndClickOnDashboard() throws InterruptedException{
        TestRunner.startTest( "Check and validate the side Navbar And Click on Dashboard");
        try {
            editClassPF.SideNavBarAndClickOnDashboard();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
            Assert.fail();
        }
    }

    @And("Check and Validate The My Courses And Settings Button")
    public void ValidateMyCoursesGridAndClickOnSettingsButton() {
        TestRunner.startTest( "Check and validate the my courses and settings button");
        try {
            editClassPF.clickOnMyCourseSetting();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
            Assert.fail();
        }
    }

    @And("Check, Validate Add New Courses in My Courses Grid")
    public void ValidateEditClassAndAddNewCourses() throws InterruptedException {
        TestRunner.startTest( "Check and validate the Edit Class And Add New Courses");
        try {
            editClassPF.clickOnDropdownCourses();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
            Assert.fail();
        }
    }

    @And("Check, Validate And Click On Next Button For Add New Courses In Class")
    public void clickOnNextButton() throws InterruptedException{
        TestRunner.startTest( "Click on Next Button for Add New Courses In Class");
        try {
            editClassPF.clickOnMyCourseNextButton();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Check, Validate Add New Courses in Class")
    public void ValidateAddNewCoursesInClass() throws InterruptedException {
        TestRunner.startTest( "Check and validate add new courses in Class");
        try {
            editClassPF.clickOnListManagedCourses();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
            Assert.fail();
        }
    }
}
