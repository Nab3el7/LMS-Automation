package StepDefinitions.AssignmentModuleStudentSide;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Assignmment.AssignmentModule.AssignmentModuleEdit_PF;
import pageFactory.Assignmment.AssignmentModuleAssignNew_PF;
import pageFactory.Assignmment.AssignmentModuleStudentSide.AssignmentsModuleStudentSideFilters_PF;
import pageFactory.Classes.AddClass_PF;

import java.time.Duration;

public class AssignmentsModuleStudentSideFiltersSteps {
    WebDriver driver = Configurations.getDriver();
    Helper helper;
    Actions actions;

    AssignmentsModuleStudentSideFilters_PF assignmentsModuleStudentSideFilters_pf;

    public WebDriverWait wait;
    WebElement loader = driver.findElement(By.xpath("//span[@role='progressbar']"));


    public AssignmentsModuleStudentSideFiltersSteps(){
        helper = new Helper();
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
        actions = new Actions(driver);
        assignmentsModuleStudentSideFilters_pf = new AssignmentsModuleStudentSideFilters_PF(driver);
    }

    @And("Get Open And Close Tab Count")
    public void GetOpenAndCloseTabCount() throws InterruptedException{
        TestRunner.startTest("Get Open And Close Tab Assignment Count");
        try {
//            Thread.sleep(3000);
            assignmentsModuleStudentSideFilters_pf.GetAssignmentsCountFromDashboard();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }

    @And("Validate and Click On Student Assignments Module")
    public void ValidateAndClickOnStudentAssignmentsModule() throws InterruptedException{
        TestRunner.startTest("Validate and Click On Student Assignments Module");
        try {
//            Thread.sleep(3000);
            assignmentsModuleStudentSideFilters_pf.ValidateClickStudentAssignmentsModule();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }

    @And("Check, Validate By Default Week Is Selected")
    public void CheckValidateByDefaultWeekIsSelected() throws InterruptedException{
        TestRunner.startTest("Check, Validate By Default Week Is Selected");
        try {
//            Thread.sleep(3000);
            assignmentsModuleStudentSideFilters_pf.ValidateByDefaultWeekButtonIsPressed();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }

    @And("Select Show All Classes From DropDown")
    public void SelectShowAllClassesFromDropDown() throws InterruptedException{
        TestRunner.startTest("Select Show All Classes From DropDown");
        try {
//            Thread.sleep(3000);
            assignmentsModuleStudentSideFilters_pf.SelectShowAllClasses();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }

    @And("Click On All Time")
    public void ClickOnAllTime() throws InterruptedException{
        TestRunner.startTest("Click On All Time");
        try {
            Thread.sleep(3000);
            assignmentsModuleStudentSideFilters_pf.ValidateAndClickAllTime();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }

    @And("Validate, Click on All CheckBox")
    public void ClickOnAllCheckBox() throws InterruptedException{
        TestRunner.startTest("Click On All Time");
        try {
            Thread.sleep(3000);
            assignmentsModuleStudentSideFilters_pf.CLickAllCheckBox();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }

    @And("Click on All, And Scroll the Assignment List")
    public void ClickOnAllAndScrollTheAssignmentList() throws InterruptedException{
        TestRunner.startTest("Click on All, And Scroll the Assignment List");
        try {
            Thread.sleep(3000);
            assignmentsModuleStudentSideFilters_pf.verifyAssignmentsCountMatchesInAssignmentModule();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }

    @And("Validate and Uncheck All CheckBox")
    public void ValidateAndUncheckAllCheckBox() throws InterruptedException{
        TestRunner.startTest("Validate and Uncheck All CheckBox");
        try {
            Thread.sleep(3000);
            assignmentsModuleStudentSideFilters_pf.UncheckAllCheckBox();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }

    @And("Validate and Click on Open CheckBox")
    public void ValidateAndClickOnOpenCheckBox() throws InterruptedException{
        TestRunner.startTest("Validate and Click on Open CheckBox");
        try {
            Thread.sleep(3000);
            assignmentsModuleStudentSideFilters_pf.ClickOpenCheckbox();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }


    @And("Validate And UnCheck Open CheckBox")
    public void ValidateAndCheckOpenCheckBox() throws InterruptedException{
        TestRunner.startTest("Validate And Uncheck Open CheckBox");
        try {
            Thread.sleep(3000);
            assignmentsModuleStudentSideFilters_pf.UncheckOpenCheckBox();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }

    @And("Validate And Click On Closed Checkbox")
    public void ValidateAndClickOnClosedCheckbox() throws InterruptedException{
        TestRunner.startTest("Validate And Click On Closed Checkbox");
        try {
            Thread.sleep(3000);
            assignmentsModuleStudentSideFilters_pf.ClickClosedCheckbox();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }


    @And("Validate and UnCheck Closed Filter")
    public void ValidateAndUnCheckClosedFilter() throws InterruptedException{
        TestRunner.startTest("Validate and UnCheck Closed Filter");
        try {
            Thread.sleep(3000);
            assignmentsModuleStudentSideFilters_pf.UncheckClosedCheckbox();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }

    @And("Validate and Click on Graded checkbox")
    public void ValidateAndClickOnGradedCheckbox() throws InterruptedException{
        TestRunner.startTest("Validate and Click on Graded checkbox");
        try {
            Thread.sleep(3000);
            assignmentsModuleStudentSideFilters_pf.ClickGradedCheckbox();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }


    @And("Validate and Uncheck Graded Filter")
    public void ValidateAndUncheckGradedFilter() throws InterruptedException{
        TestRunner.startTest("Validate and Uncheck Graded Filter");
        try {
            Thread.sleep(3000);
            assignmentsModuleStudentSideFilters_pf.UncheckGradedCheckbox();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }

    @And("Validate And Click On Future Checkbox")
    public void ValidateAndClickOnFutureCheckbox() throws InterruptedException{
        TestRunner.startTest("Validate And Click On Future Checkbox");
        try {
            Thread.sleep(3000);
            assignmentsModuleStudentSideFilters_pf.ValidateClickFutureCheckBox();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }

    @And("Validate and Uncheck Future Filter")
    public void ValidateAndUncheckFutureFilter() throws InterruptedException {
        TestRunner.startTest("Validate and Uncheck Future Filter");

        try {
            Thread.sleep(3000);
            assignmentsModuleStudentSideFilters_pf.UncheckFutureCheckbox();
        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Select Classes From DropDown")
    public void SelectShowClassesFromDropDown() throws InterruptedException {
        TestRunner.startTest("Select Classes From DropDown");
        try {
            assignmentsModuleStudentSideFilters_pf.SelectClasses();
        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL," Test Case Failed: Exception is found");
            Assert.fail();
        }
    }
}
