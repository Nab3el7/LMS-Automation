package StepDefinitions.AssignmentModuleStudentSide;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Assignmment.AssignmentModuleStudentSide.AssignmentsModuleStudentSideFilters_PF;
import pageFactory.Assignmment.AssignmentModuleStudentSide.StudentSideAssignmentModuleFiltersOnDate_PF;
import org.openqa.selenium.ElementNotInteractableException;

import java.time.Duration;

import static pageFactory.Assignmment.AssignmentModuleStudentSide.StudentSideAssignmentModuleFiltersOnDate_PF.DueDateAssignmentModule;
import static pageFactory.Assignmment.AssignmentModuleStudentSide.StudentSideAssignmentModuleFiltersOnDate_PF.StartDateAssignmentModule;
import static pageFactory.MyContent.AssignAssessment_PF.startDateTime;

public class StudentSideAssignmentModuleFiltersOnDateSteps {

    WebDriver driver = Configurations.getDriver();
    Helper helper;
    Actions actions;

    StudentSideAssignmentModuleFiltersOnDate_PF studentSideAssignmentModuleFiltersOnDate_pf;
    AssignmentsModuleStudentSideFilters_PF assignmentsModuleStudentSideFilters_pf;

    public WebDriverWait wait;
    WebElement loader = driver.findElement(By.xpath("//span[@role='progressbar']"));


    public StudentSideAssignmentModuleFiltersOnDateSteps(){
        helper = new Helper();
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
        actions = new Actions(driver);
        studentSideAssignmentModuleFiltersOnDate_pf = new StudentSideAssignmentModuleFiltersOnDate_PF(driver);
        assignmentsModuleStudentSideFilters_pf = new AssignmentsModuleStudentSideFilters_PF(driver);
    }

    @And("Get All Assignment Count From Dashboard")
    public void GetAllAssignmentCountFromDashboard() throws InterruptedException{
        TestRunner.startTest("Get All Assignment Count From Dashboard");
        try {
            Thread.sleep(3000);
            studentSideAssignmentModuleFiltersOnDate_pf.GetAssignmentsFromDashboard();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }

    @And("Validate All Time, And Scroll the Assignment List")
    public void ClickOnAllAndScrollTheAssignmentList() throws InterruptedException{
        TestRunner.startTest("Validate All Time, And Scroll the Assignment List");
        try {
            Thread.sleep(3000);
            studentSideAssignmentModuleFiltersOnDate_pf.validateAssignmentsCountMatchesAllTimeAssignment();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }

    @And("Click On Today Button Assignment Module")
    public void ClickOnTodayButtonAssignmentModule() throws InterruptedException{
        TestRunner.startTest("Click On Today Button Assignment Module");
        try {
            Thread.sleep(3000);
            studentSideAssignmentModuleFiltersOnDate_pf.ValidateClickTodayButton();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }

    @And("Validate All Assignments In Today have Today's Due Date")
    public void ValidateAllAssignmentsInToDayHaveTodayDueDate() throws InterruptedException{
        TestRunner.startTest("Validate All Assignments In Today have Today's Due Date");
        try {
            Thread.sleep(3000);
            studentSideAssignmentModuleFiltersOnDate_pf.ValidateTodayAssignmentDueDate();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }

    @And("Click on Week Button Assignment Module")
    public void ClickOnWeekButtonAssignmentModule() throws InterruptedException{
        TestRunner.startTest("Click on Week Button Assignment Module");
        try {
            Thread.sleep(3000);
            studentSideAssignmentModuleFiltersOnDate_pf.ValidateAndClickWeekButton();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }

    @And("Validate, Check All Assignment Are in Current Week Date in Week Filter")
    public void ValidateCheckAllAssignmentAreInCurrentWeekDateInWeekFilter() throws InterruptedException{
        TestRunner.startTest("Validate, Check All Assignment Are in Current Week Date in Week Filter");
        try {
            Thread.sleep(3000);
            studentSideAssignmentModuleFiltersOnDate_pf.AllAssignmentAreInCurrentWeekDate();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }

    @And("Click on Month Button Assignment Module")
    public void ClickOnMonthButtonAssignmentModule() throws InterruptedException{
        TestRunner.startTest("Click on Month Button Assignment Module");
        try {
            Thread.sleep(3000);
            studentSideAssignmentModuleFiltersOnDate_pf.ValidateAndClickMonthButton();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }

    @And("Check, Validate All Assignment Are in Current Month Date")
    public void CheckValidateAllAssignmentMonthDate() throws InterruptedException{
        TestRunner.startTest("Check, Validate All Assignment Are in Current Month Date");
        try {
            Thread.sleep(3000);
            studentSideAssignmentModuleFiltersOnDate_pf.AllAssignmentAreInCurrentMonthDate();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }

//    Sort By Due Date Descending order Filter

    @And("Click on Sort Due Date By Descending order")
    public void ClickOnSortDueDateByDescendingOrder() throws InterruptedException{
        TestRunner.startTest("Click on Sort Due Date By Descending order");
        try {
            Thread.sleep(3000);
            studentSideAssignmentModuleFiltersOnDate_pf.ClickOnSortByDueDateDescendingOrder();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }

    @And("Verify that All Assignment Due Date is in Descending order")
    public void VerifyThatAllAssignmentDueDateIsInDescendingOrder() throws InterruptedException{
        TestRunner.startTest("Verify that All Assignment Due Date is in Descending order");
        try {
            Thread.sleep(3000);
            studentSideAssignmentModuleFiltersOnDate_pf.ValidateAllAssignmentsAreInDescendingOrder();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }
//    for select custom date range

    @And("Click On Unit, Assignment And Assign Specific Assignment Type Expert Track For Assignment Module")
    public void SelectUnitAndAssignSpecificAssignmentTypeETForCorrectAnswers() throws InterruptedException {
        TestRunner.startTest("Assign Assignment Type Expert Track For Correct Answer");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            studentSideAssignmentModuleFiltersOnDate_pf.AssignAssignmentForAssignmentModuleStudentSide();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
        Thread.sleep(3000);
    }

    @And("Click and set Start date In Assignment Module")
    public void ClickAndSetStartDate() throws InterruptedException{
        TestRunner.startTest(" Click and set Start date");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            studentSideAssignmentModuleFiltersOnDate_pf.SelectStartDateOnAssignmentModule(StartDateAssignmentModule);
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  Exception is found.");
            Assert.fail();
        }
//        Thread.sleep(2000);
    }

    @And("Click and set Due date In Assignment Module")
    public void ClickAndSetDueDate() throws InterruptedException{
        TestRunner.startTest(" Click and set Due date In Assignment Module");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            studentSideAssignmentModuleFiltersOnDate_pf.SelectEndDateOnAssignmentModule(DueDateAssignmentModule);
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  Exception is found.");
            Assert.fail();
        }
//        Thread.sleep(2000);
    }

    @And("Check, Validate that Assignment is Present Under Given Date Range")
    public void CheckValidateThatAssignmentIsPresentUnderGivenDateRange() throws InterruptedException{
        TestRunner.startTest("Check, Validate that Assignment is Present Under Given Date Range");
        try {
            Thread.sleep(3000);
            studentSideAssignmentModuleFiltersOnDate_pf.ValidateAssignmentAfterCustomDateRangeFilter();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }


    @And("Validate Open CheckBox Is Checked By Default")
    public void ValidateOpenCheckBoxIsCheckedByDefault() throws InterruptedException {
        TestRunner.startTest("Validate Open CheckBox Is Checked By Default");
        try {

            studentSideAssignmentModuleFiltersOnDate_pf.validateOpenCheckBoxIsChecked();
        }catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }
}
