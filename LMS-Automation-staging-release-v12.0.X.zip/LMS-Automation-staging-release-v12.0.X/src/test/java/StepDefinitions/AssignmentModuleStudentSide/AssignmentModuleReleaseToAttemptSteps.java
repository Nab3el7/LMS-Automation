package StepDefinitions.AssignmentModuleStudentSide;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Assignmment.AssignmentModuleStudentSide.AssignmentModuleReleaseToAttempt_PF;
import pageFactory.Assignmment.AssignmentModuleStudentSide.AssignmentsModuleStudentSideFilters_PF;
import pageFactory.Assignmment.AssignmentModuleStudentSide.StudentSideAssignmentModuleFiltersOnDate_PF;
import pageFactory.Assignmment.CorrectAnswerExecutor_PF;

import java.awt.*;
import java.time.Duration;

public class AssignmentModuleReleaseToAttemptSteps {

    AssignmentModuleReleaseToAttempt_PF assignmentModuleReleaseToAttempt_pf;

    WebDriver driver = Configurations.getDriver();
    Helper helper;
    Actions actions;

    StudentSideAssignmentModuleFiltersOnDate_PF studentSideAssignmentModuleFiltersOnDate_pf;
    AssignmentsModuleStudentSideFilters_PF assignmentsModuleStudentSideFilters_pf;
    CorrectAnswerExecutor_PF correctAnswerExecutor_pf;

    public WebDriverWait wait;
    WebElement loader = driver.findElement(By.xpath("//span[@role='progressbar']"));


    public AssignmentModuleReleaseToAttemptSteps(){
        helper = new Helper();
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
        actions = new Actions(driver);
        studentSideAssignmentModuleFiltersOnDate_pf = new StudentSideAssignmentModuleFiltersOnDate_PF(driver);
        assignmentsModuleStudentSideFilters_pf = new AssignmentsModuleStudentSideFilters_PF(driver);
        correctAnswerExecutor_pf = new CorrectAnswerExecutor_PF(driver);
        assignmentModuleReleaseToAttempt_pf = new AssignmentModuleReleaseToAttempt_PF(driver);
    }

    @And("Search Assignment by Using Search Box On Assignment Module")
    public void GetAllAssignmentCountFromDashboard() throws InterruptedException{
        TestRunner.startTest("Search Assignment by Using Search Box On Assignment Module");
        try {
            Thread.sleep(3000);
            assignmentModuleReleaseToAttempt_pf.searchAssignmentByKeyWordInAssignmentModule();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }

    @And("Click On Start And Submit Specific Assignment With Correct Answers in Assignment Module")
    public void SelectTabAndStartSpecificAssignment() throws InterruptedException, AWTException {
        TestRunner.startTest("Click On Start And Submit Specific Assignment With Correct Answers in Assignment Module");
        try {
            assignmentModuleReleaseToAttempt_pf.SelectAssignmentForCorrectAnswersInAssignmentModule();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Validate That Submitted Assignment Is Not Open Filter")
    public void ValidateThatSubmittedAssignmentIsNotUnderInOpenAndCloseFilter() throws InterruptedException{
        TestRunner.startTest("Validate That Submitted Assignment Is Not Under In Open Filter");
        try {
            Thread.sleep(3000);
            assignmentModuleReleaseToAttempt_pf.SubmittedAssignmentIsNotUnderInOpenFilter();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }

    }

    @And("Click On Open filter CheckBox")
    public void ClickOnOpenFilterCheckBox() throws InterruptedException{
        TestRunner.startTest("Validate and Click on Open CheckBox");
        try {
            Thread.sleep(3000);
            assignmentModuleReleaseToAttempt_pf.ValidateOpenFilterCheckbox();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }

    @And("Click On Closed Filter Checkbox")
    public void ClickOnClosedFilterCheckbox() throws InterruptedException{
        TestRunner.startTest("Click On Closed Filter Checkbox");
        try {
            Thread.sleep(3000);
            assignmentModuleReleaseToAttempt_pf.ValidateClosedFilterCheckbox();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }

    @And("Validate That Submitted Assignment Is Not Closed Filter")
    public void ValidateThatSubmittedAssignmentIsNotClosedFilter() throws InterruptedException{
        TestRunner.startTest("Validate That Submitted Assignment Is Not Closed Filter");
        try {
            Thread.sleep(3000);
            assignmentModuleReleaseToAttempt_pf.SubmittedAssignmentIsNotUnderInClosedFilter();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Click on Graded Filter checkbox")
    public void ClickOnGradedFilterCheckbox() throws InterruptedException{
        TestRunner.startTest("Click on Graded Filter checkbox");
        try {
            Thread.sleep(3000);
            assignmentModuleReleaseToAttempt_pf.ValidateGradedFilterCheckbox();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }

    @And("Validate That Graded Assignment Is Found In Graded Filter")
    public void ValidateThatGradedAssignmentIsFoundInGradedFilter() throws InterruptedException{
        TestRunner.startTest("Validate That Graded Assignment Is In Graded Filter");
        try {
            Thread.sleep(3000);
            assignmentModuleReleaseToAttempt_pf.GradedAssignmentIsUnderInGradedFilter();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }



    @And("Validate and Review Attempt Assignment In Assignment Module")
    public void ValidateAndReviewAttemptAssignmentInAssignmentModule() throws InterruptedException{
        TestRunner.startTest("Validate and Review Attempt Assignment In Assignment Module");
        try {
            Thread.sleep(3000);
            assignmentModuleReleaseToAttempt_pf.ReviewAttemptedCorrectAnswersAssignmentInAssignmentModule();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }

    }

    @And("Uncheck Open CheckBox")
    public void UncheckOpenCheckBox() throws InterruptedException {
        TestRunner.startTest("Uncheck Open CheckBox");
        try {
            assignmentModuleReleaseToAttempt_pf.UncheckOpenCheckBoxAssignmentModule();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found.");
            Assert.fail();
        }
    }
}
