package StepDefinitions;

import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Assignmment.AssessmentReview.*;
import pageFactory.Assignmment.TeacherAssignment_PF;

import java.awt.*;
import java.time.Duration;

//import static StepDefinitions.Configurations.driver;


public class AssignmentReviewSteps extends Configurations{
    WebDriver driver = Configurations.getDriver();

    ReviewNotAvailable_PF reviewNotAvailablePF;
    ReviewSubmission_PF reviewSubmissionPF;
    ReviewGradedSubmission_PF reviewGradedSubmission_PF;
    ReviewGradedSubmissionWithCorrectAnswers_PF reviewGradedSubmissionWithCorrectAnswers_PF;
    public WebDriverWait wait;

    public AssignmentReviewSteps() {
        reviewNotAvailablePF = new ReviewNotAvailable_PF(driver);
        reviewSubmissionPF = new ReviewSubmission_PF(driver);
        reviewGradedSubmission_PF = new ReviewGradedSubmission_PF(driver);
        reviewGradedSubmissionWithCorrectAnswers_PF = new ReviewGradedSubmissionWithCorrectAnswers_PF(driver);
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
    }


    @And("Click On End Of Year, Assign Assignment For Review Not Available")
    public void SelectUnitAndReleaseAssignmentForReviewNotAvailable() throws InterruptedException {
        TestRunner.startTest("  Click on End Of Year and Assign Assignment for Review Not Available **********");
        try {
            reviewNotAvailablePF.ReleaseAssignmentForNoReviewVerification();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed :    :   Exception is found  **********" + e);
            Assert.fail();
        }
    }

    @And("Click On Tab, Start And Submit Assignment and Verify Assignment No Review Available")
    public void SelectTabAndStartSpecificAssignment() throws InterruptedException, AWTException {
        TestRunner.startTest("  Click on Tab, Start And Submit Assignment and Verify Assignment No Review Available **********");
        try {
            reviewNotAvailablePF.SelectAssignmentForNoReview();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed :    ::     Exception is found  **********" + e);
            Assert.fail();
        }
    }

    @And("Click On Closed Tab, Search Assignment And Verify Review Not Available")
    public void SelectClosedTabSearchAssignmentAndVerifyReviewNotAvailable() throws InterruptedException {
        TestRunner.startTest("  Click on closed tab, search assignment and verify review not available  **********");
        try {
            reviewNotAvailablePF.VerifyNoReviewButtonInClosedAssignment();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed :    ::    Exception is found  **********" + e);
            Assert.fail();
        }
    }

    @And("Click On End Of Year, Assign Assignment For Review Submission")
    public void SelectUnitAndReleaseAssignmentForReviewSubmission() throws InterruptedException {
        TestRunner.startTest("  Click on End Of Year and Assign Assignment for Review Submission **********");
        try {
            reviewSubmissionPF.ReleaseAssignmentForReviewSubmissionVerification();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed :    ::   Exception is found  **********" + e);
            Assert.fail();
        }
    }

    @And("Click On Tab, Start And Submit Assignment and Verify Assignment Review Submission")
    public void SelectTabAndStartSpecificAssignmentForReviewSubmission() throws InterruptedException, AWTException {
        TestRunner.startTest("  Click on Tab, Start And Submit Assignment and Verify Assignment for Review Submission **********");
        try {
            reviewSubmissionPF.SelectAssignmentForReviewSubmission();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed :    : Exception is found  **********" + e);
            Assert.fail();
        }
    }

    @And("Click On Closed Tab, Search Assignment And Verify Review Submission")
    public void SelectClosedTabSearchAssignmentAndVerifyReviewSubmission() throws InterruptedException {
        TestRunner.startTest("  Click on Closed Tab, Search Assignment and Verify Review Submission  **********");
        try {
            reviewSubmissionPF.ClosedAssignmentReviewSubmission();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed :    :    Exception is found  **********" + e);
            Assert.fail();
        }
    }

    @And("Click On End Of Year, Assign Assignment For Review Graded Submission")
    public void SelectUnitAndReleaseAssignmentForReviewGradedSubmission() throws InterruptedException {
        TestRunner.startTest("  Click on End Of Year and Assign Assignment for Review Graded Submission **********");
        try {
            reviewGradedSubmission_PF.ReleaseAssignmentForReviewGradedSubmissionVerification();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed :    :    Exception is found  **********" + e);
            Assert.fail();
        }
    }

    @And("Click On Tab, Start And Submit Assignment and Verify Assignment Review Graded Submission")
    public void SelectTabAndStartSpecificAssignmentForReviewGradedSubmission() throws InterruptedException, AWTException {
        TestRunner.startTest("  Click on Tab, Start And Submit Assignment and Verify Assignment for Review Graded Submission **********");
        try {
            reviewGradedSubmission_PF.SelectAssignmentForReviewGradedSubmission();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.startTest("Test Case Failed    :   Exception is found  **********" + e);
            Assert.fail();
        }
    }

    @And("Click On Closed Tab, Search Assignment And Verify Review Graded Submission")
    public void SelectClosedTabSearchAssignmentAndVerifyReviewGradedSubmission() throws InterruptedException {
        TestRunner.startTest("  Click on Closed Tab, Search Assignment and Verify Review Graded Submission  **********");
        try {
            reviewGradedSubmission_PF.ClosedAssignmentReviewGradedSubmission();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.startTest(" Test Case Failed    :   Exception is found  **********" + e);
            Assert.fail();
        }
    }

    @And("Click On End Of Year, Assign Assignment For Review Graded Submission With Correct Answers")
    public void SelectUnitAndReleaseAssignmentForReviewGradedSubmissionWithCorrectAnswers() throws InterruptedException {
        TestRunner.startTest("  Click on End Of Year and Assign Assignment for Review Graded Submission With Correct Answers  **********");
        try {
            reviewGradedSubmissionWithCorrectAnswers_PF.ReleaseAssignmentForReviewGradedSubmissionWithCorrectAnswersVerification();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed :    :     Exception is found  **********" + e);
            Assert.fail();
        }
    }

    @And("Click On Tab, Start And Submit Assignment and Verify Assignment Review Graded Submission With Correct Answers")
    public void SelectTabAndStartSpecificAssignmentForReviewGradedSubmissionWithCorrectAnswers() throws InterruptedException, AWTException {
        TestRunner.startTest("  Click on Tab, Start And Submit Assignment and Verify Assignment for Review Graded Submission With Correct Answers  **********");
        try {
            reviewGradedSubmissionWithCorrectAnswers_PF.SelectAssignmentForReviewGradedSubmissionWithCorrectAnswers();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed :    :  Exception is found  **********" + e);
            Assert.fail();
        }
    }

    @And("Click On Closed Tab, Search Assignment And Verify Review Graded Submission With Correct Answers")
    public void SelectClosedTabSearchAssignmentAndVerifyReviewGradedSubmissionWithCorrectAnswers() throws InterruptedException {
        TestRunner.startTest("  Click on Closed Tab, Search Assignment and Verify Review Graded Submission With Correct Answers  **********");
        try {
            reviewGradedSubmissionWithCorrectAnswers_PF.ClosedAssignmentReviewGradedSubmissionWithCorrectAnswers();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed :     :   Exception is found  **********" + e);
            Assert.fail();
        }
    }


}