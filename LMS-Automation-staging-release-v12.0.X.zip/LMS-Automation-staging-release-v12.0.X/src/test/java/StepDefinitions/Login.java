package StepDefinitions;

import apiHandler.PostAPIHandler;
import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Login_PF;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.time.Duration;
import java.util.ArrayList;

import static pageFactory.GalSystemScenarios.GalSystemEditExistingStudent_PF.updatedEmailStudent;
import static pageFactory.GalSystemScenarios.GalSystemEditExistingStudent_PF.updatedPasswordStudent;
import static pageFactory.GalSystemScenarios.SearchExistingStaff_PF.updatedEmailTeacher;
import static pageFactory.GalSystemScenarios.SearchExistingStaff_PF.updatedPasswordStaff;
import static pageFactory.StudentsModule.ReadNewStdInfo_PF.UpdatedPasswordValue;
import static pageFactory.StudentsModule.ReadNewStdInfo_PF.updatedEmail;

public class Login extends Configurations{
	// Lazy initialization - get driver only when needed, not during class instantiation
	private WebDriver driver;
	private WebDriverWait wait;

	public String username = Configurations.username;
	public String password = Configurations.password;

	public String StdEmail = Configurations.std_Email;
	public String StdPassword = Configurations.std_Password;
	public static String newStaffEmail= "qa4.fl@gp.com";
	public static String newStaffPassword = "Fltester22";

	public static String otherStaffEmail="automationqa@gmail.com";
	public static String otherStaffPassword= "fltester22";

	public static String NewStdEmail="ben@gallopade.com";
	public static String NewStudentPassword= "fltester22";

	public String districtUsername = "fldistrictadmin@gp.com";
	public String districtPassword = "fltester22";

	public String galSystemUsername = "galsystemadmin@gp.com";
	public String galSystemPassword = "fltester22";

	Login_PF loginPF;
	Helper helper;
	PostAPIHandler postAPIHandler;

	Boolean Title;

	// Lazy getter methods - initialize only when accessed
	// Note: Using different names to avoid conflict with Configurations.getDriver()
	private WebDriver getWebDriver() {
		if (driver == null) {
			driver = Configurations.getDriver();
		}
		return driver;
	}

	private WebDriverWait getWebDriverWait() {
		if (wait == null) {
			wait = new WebDriverWait(getWebDriver(), Duration.ofSeconds(60));
		}
		return wait;
	}

	// Ensure page objects are initialized before use
	private void ensurePageObjectsInitialized() {
		if (loginPF == null) {
			loginPF = new Login_PF(getWebDriver());
			postAPIHandler = new PostAPIHandler(getWebDriver());
		}
	}

	public Login(){
		// Initialize helper - doesn't need driver immediately
		helper = new Helper();
		// Initialize page objects lazily - will be set when driver is first accessed
	}

	@Given("Browser is open")
	public void Setup() {
		TestRunner.startTest("User opens the browser and open the page");
		// Initialize page objects when driver is first accessed
		if (loginPF == null) {
			loginPF = new Login_PF(getWebDriver());
			postAPIHandler = new PostAPIHandler(getWebDriver());
		}
		getWebDriver().get(Configurations.App_url);
		System.out.println("Inside Step- user is on login Page");
		helper.waitForPageToLoad();
		TestRunner.getTest().log(Status.PASS, "Browser is opened");
	}


	@And("user is on login with invalid password credentials")
	public void loginWithWrongPassword() throws Exception {
		TestRunner.startTest("Login with Invalid Password");
		ensurePageObjectsInitialized();
		loginPF.enterUsername(username);
		loginPF.enterPassword("DummyPassword");
		loginPF.clickOnLogin();
		loginPF.verifyInValidLogin("Bad credentials", "WrongPassword");
		TestRunner.getTest().log(Status.FAIL, "Login with invalid password failed");
	}
	
	@And("user is on login with invalid email credentials")
	public void loginWithWrongEmail() throws Exception {
		ensurePageObjectsInitialized();
		loginPF.enterUsername("dummyemail@gmail.com");
		loginPF.enterPassword(password);
		loginPF.clickOnLogin();
		loginPF.verifyInValidLogin("Bad credentials", "WrongEmail");
    }
	
	@And("user is on login with empty credentials")
	public void loginWithEmptyEmailPassword() throws Exception {
		ensurePageObjectsInitialized();
		loginPF.enterUsername("");
		loginPF.enterPassword("");
		loginPF.clickOnLogin();
		loginPF.verifyInValidLogin("Bad credentials", "WrongEmail");
    }

	@And("user is on login with valid credentials")
	public void LoginWithValidCredentials() throws InterruptedException {
		TestRunner.startTest("Teacher Login with valid credentials");
		login("Teacher", username, password);
	}

	@And("GalSystem Admin is on login with valid credentials")
	public void GalSystemAdminLoginWithValidCredentials() throws InterruptedException {
		TestRunner.startTest("GalSystem Admin is Login with valid credentials");
		login("GalSystemAdmin", galSystemUsername, galSystemPassword);
	}

	@And("District Admin is on login with valid credentials")
	public void DistrictAdminIsOnLoginWithValidCredentials() throws InterruptedException {
		TestRunner.startTest("District Admin is on login with valid credentials");
		login("District Admin", districtUsername, districtPassword);
	}

	@And("user is on login with valid credentials for new teacher")
	public void LoginWithValidCredentialsForNewTeacher() throws InterruptedException {
		TestRunner.startTest("Teacher Login with valid credentials for new teacher");
		login("Teacher", newStaffEmail, newStaffPassword);
	}

	@And("Other Staff is Login with valid credentials")
	public void LoginOtherStaffWithValidCredentials() throws InterruptedException{
		TestRunner.startTest("Teacher Login with valid credentials for new teacher");
		login("Teacher", otherStaffEmail, otherStaffPassword);
	}

	@And("Student Is On Login With Valid Credentials")
	public void StudentLoginWithValidCredentials() throws InterruptedException {
		TestRunner.startTest("Student Login with valid credentials");
		login("Student", StdEmail, StdPassword);
	}

	@And("Student Is On Login With Valid Credentials On New Tab")
	public void UserIsOnLoginWithValidCredentialsForNewStudent() throws InterruptedException {
		TestRunner.startTest("Student is on login with valid credentials on new tab");

		((JavascriptExecutor) getWebDriver()).executeScript("window.open();");

		ArrayList<String> tabs = new ArrayList<>(getWebDriver().getWindowHandles());
		getWebDriver().switchTo().window(tabs.get(tabs.size() - 1));
		TestRunner.getTest().log(Status.INFO, "Switched to new browser tab for Student login");

		getWebDriver().get(Configurations.App_url);

		login("Student", NewStdEmail, NewStudentPassword);

		TestRunner.getTest().log(Status.PASS, "New Student logged in successfully on new tab");
	}

	@And("user is on login with valid credential after edit information")
	public void UserIsOnLoginWithValidCredentialAfterEditInformation() throws InterruptedException{
		TestRunner.startTest("user is on login with valid credential after edit information");
		login("Student", updatedEmail, "Fltester@22");
	}

	@And("Teacher is on login with valid credential after edit information From GalSystem")
	public void TeacherIsOnLoginWithValidCredentialAfterEditInformationFromGalSystem() throws InterruptedException{
		TestRunner.startTest("Teacher is on login with valid credential after edit information From GalSystem");
		login("Teacher", updatedEmailTeacher, updatedPasswordStaff);
	}

	@And("Student is on login with valid credentials after edit information From GalSystem")
	public void StudentIsOnLoginWithValidCredentialAfterEditInformationFromGalSystem() throws InterruptedException{
		TestRunner.startTest("Student is on login with valid credential after edit information From GalSystem");
		login("Student", updatedEmailStudent, updatedPasswordStudent);
	}

	public void login(String userType, String email, String password) throws InterruptedException {
		ensurePageObjectsInitialized();
		loginPF.enterUsername(email);
		loginPF.enterPassword(password);
		System.out.println("Login with user type " + userType + " and email " + email + " and password " + password);
		TestRunner.getTest().log(Status.INFO,"Login with user type " + userType + " and email " + email + " and password " + password);
		loginPF.clickOnLogin();

		System.out.println("Inside Step - " + userType + " enters");

		// Wait for loader to be invisible
		WebElement loader = getWebDriver().findElement(By.xpath("//span[@role='progressbar']"));
		getWebDriverWait().until(ExpectedConditions.invisibilityOf(loader));

		// Verify User is on Home Page
		String actualTitle = "Gallopade: Educational Products, Social Studies Curriculum, Reading, Common Core";
		String expectedTitle = getWebDriver().getTitle();
		System.out.println(expectedTitle);

		if ("Student".equals(userType)) {
			getWebDriverWait().until(ExpectedConditions.invisibilityOf(loader));
			loginPF.verifyStudentDashboard(actualTitle, "RightCredentials");
		} else {
			loginPF.verifyValidLogin(actualTitle, "RightCredentials");
		}

		System.out.println("Verified " + userType + " landed correctly - navigated to dashboard");
		Thread.sleep(3000);
	}

	@And("Teacher is Logged out")
	public void logoutTeacher() throws InterruptedException{
		TestRunner.startTest("Teacher Log Out");
		ensurePageObjectsInitialized();
		Thread.sleep(1000);
		System.out.println("Teacher logout");
		loginPF.clickOnTeacherLogout();
		Thread.sleep(2000);
	}

	@And("District Admin is Logged out")
	public void logoutDistrict() throws InterruptedException{
		TestRunner.startTest("District Admin Log Out");
		ensurePageObjectsInitialized();
		Thread.sleep(1000);
		System.out.println("District Admin logout");
		loginPF.clickOnDistrictAdminLogout();
		Thread.sleep(2000);
	}

	@And("Validate The Student Is Logged Out")
	public void VerifyStudentLogout() throws InterruptedException{
		TestRunner.startTest("Student Logout");
		ensurePageObjectsInitialized();
		Thread.sleep(1000);
		try {
			loginPF.clickOnStudentLogout();
			TestRunner.getTest().log(Status.PASS, "Test Case Passed    :   Student is logout successfully");
		} catch (NoSuchElementException | ElementNotInteractableException e) {
			System.out.println(e);
			System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
			TestRunner.getTest().log(Status.FAIL,"Test Case Failed    :   Exception is found");
			Assert.fail();
		}
		Thread.sleep(3000);
	}

	@And("Validate The New Student Is Logged Out With Tab Closed")
	public void VerifyNewStudentLogoutWithTabClosed() throws InterruptedException{
		TestRunner.startTest("Student Logout With Tab Closed");
		ensurePageObjectsInitialized();
		Thread.sleep(1000);
		try {
			loginPF.clickOnStudentLogout();
			TestRunner.getTest().log(Status.PASS, "Test Case Passed    :   Student is logout successfully");

			getWebDriver().close();
			TestRunner.getTest().log(Status.INFO, "Closed the Student tab after logout");

			ArrayList<String> tabs = new ArrayList<>(getWebDriver().getWindowHandles());
			getWebDriver().switchTo().window(tabs.get(0));
			TestRunner.getTest().log(Status.INFO, "Switched back to parent tab");
		} catch (NoSuchElementException | ElementNotInteractableException e) {
			System.out.println(e);
			System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
			TestRunner.getTest().log(Status.FAIL,"Test Case Failed    :   Exception is found");
			Assert.fail();
		}
		Thread.sleep(3000);
	}

	@And("Get Access Token Through Teacher Login API")
	public void TeacherLoginForAccessToken() throws InterruptedException, IOException, NoSuchAlgorithmException, KeyManagementException {
		TestRunner.startTest("Get Teacher Login Access Token");
		ensurePageObjectsInitialized();
		Thread.sleep(500);
		try {
			postAPIHandler.loginAPiCall();
			TestRunner.getTest().log(Status.PASS, "Test Case Passed    :   Teacher is login through api successfully");
		} catch (Exception e) {
			System.out.println(e);
			System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
			TestRunner.getTest().log(Status.FAIL,"Test Case Failed    :   Exception is found");
			Assert.fail();
		}

	}
	
	@Then("Close the browser")
	public void tearDown() throws InterruptedException{		//Browser closing
		TestRunner.startTest("Close the browser");
		ensurePageObjectsInitialized();
		Thread.sleep(2000);
//		loginPF.closeBrowser();
    }

}
