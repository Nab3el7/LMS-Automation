package StepDefinitions.ReleaseAssignment;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Assignmment.CorrectAnswerExecutor_PF;
import pageFactory.Assignmment.NegativeTestCasesAssignmentRelease_PF;

import java.time.Duration;

//import static StepDefinitions.Configurations.driver;

public class NegativeTestCasesAssignmentReleaseSteps extends Configurations {
    WebDriver driver = Configurations.getDriver();
    Helper helper;
    NegativeTestCasesAssignmentRelease_PF negativeTestCasesAssignmentRelease_pf;
    CorrectAnswerExecutor_PF correctAnswerExecutor_pf;

    public WebDriverWait wait;
    WebElement loader = driver.findElement(By.xpath("//span[@role='progressbar']"));


    public NegativeTestCasesAssignmentReleaseSteps(){
        helper = new Helper();
        correctAnswerExecutor_pf = new CorrectAnswerExecutor_PF(driver);
        negativeTestCasesAssignmentRelease_pf = new NegativeTestCasesAssignmentRelease_PF(driver);
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
    }
    

    @And("Click on Unit and Specific Assignment")
    public void ClickUnitSelectAssignment() throws InterruptedException{
        TestRunner.startTest("**********  Click On Unit  **********");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            negativeTestCasesAssignmentRelease_pf.SelectUnitAndAssignment();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Unit not found  **********");
            Assert.fail();
        }
        Thread.sleep(3000);
    }

    @And("validate and Select Assignment")
    public void validateAndSelectAssignment() throws InterruptedException{
        TestRunner.startTest("**********  Select Assignment  **********");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            negativeTestCasesAssignmentRelease_pf.SelectAssignment();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Assignment Assign Button not found  **********");
            Assert.fail();
        }
        Thread.sleep(3000);
    }


    @And("Check and validate Assignment Dialogue Box")
    public void AssignmentDialogueBox() throws InterruptedException{
        TestRunner.startTest("**********  Check and validate Assignment Dialogue Box  **********");
        try {
            negativeTestCasesAssignmentRelease_pf.AssignmentDialogueBox();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found. Assignment Dialogue Box not appear **********");
            Assert.fail();
        }
        Thread.sleep(3000);
    }

    @And("Setting Assignment Title field empty")
    public void SettingAssignmentTitleFieldEmpty()throws InterruptedException{
        TestRunner.startTest("**********  Setting Assignment Title field empty **********");
        try {
            negativeTestCasesAssignmentRelease_pf.BlankAssignmentTitle();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found. data enter in field **********");
            Assert.fail();
        }
        Thread.sleep(3000);
    }

    @And("Click and Validate on Assign Button")
    public void ClickValidateAssignButton() throws InterruptedException{
        TestRunner.startTest("**********  Click and Validate on Assign Button **********");
        try {
            negativeTestCasesAssignmentRelease_pf.AssignButton();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found. Assign button not found **********");
            Assert.fail();
        }
        Thread.sleep(3000);
    }

    @And("Setting Assign To Field Empty")
    public void SettingAssignToFieldEmpty() throws InterruptedException{
        TestRunner.startTest("**********  Setting Assign To Field Empty**********");
        try {
            negativeTestCasesAssignmentRelease_pf.AssignToField();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found. Assign To Field Selected. **********");
            Assert.fail();
        }
        Thread.sleep(3000);
    }

    @And("Select Class")
    public void SelectionClass() throws InterruptedException{
        TestRunner.startTest("**********  Select Class **********");
        try {
            correctAnswerExecutor_pf.selectSpecificClasses();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found.Class not visible **********");
            Assert.fail();
        }
        Thread.sleep(3000);
    }
    @And("Select Open to any Student Toggle")
    public void SelectOpenToAnyStudentToggle() throws InterruptedException{
        TestRunner.startTest("**********  Select Open to any Student Toggle to Turn off **********");
        try {
            negativeTestCasesAssignmentRelease_pf.ToggleButton();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found. Toggle button is not Turn off. **********");
            Assert.fail();
        }
        Thread.sleep(3000);
    }

    @And("Setting Select Students Field empty")
    public void SettingSelectStudentsFieldEmpty() throws InterruptedException{
        TestRunner.startTest("**********  Setting Select Students Field empty **********");
        try {
            negativeTestCasesAssignmentRelease_pf.SelectStudentFiled();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found. Student Selected. **********");
            Assert.fail();
        }
        Thread.sleep(3000);
    }


}
