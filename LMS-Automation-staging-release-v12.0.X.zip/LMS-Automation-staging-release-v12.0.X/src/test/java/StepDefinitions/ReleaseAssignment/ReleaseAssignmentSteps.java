package StepDefinitions.ReleaseAssignment;

import StepDefinitions.Configurations;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Assignmment.AdvancedGrading_PF;
import pageFactory.Assignmment.CorrectAnswerExecutor_PF;
import pageFactory.Assignmment.ReleaseAssignment_PF;
import org.openqa.selenium.ElementNotInteractableException;

import java.time.Duration;

public class ReleaseAssignmentSteps extends Configurations {
    WebDriver driver = Configurations.getDriver();

    public WebDriverWait wait;
    WebElement loader = driver.findElement(By.xpath("//span[@role='progressbar']"));

    ReleaseAssignment_PF releaseAssignment_pf;
    AdvancedGrading_PF advancedGrading_pf;
    CorrectAnswerExecutor_PF correctAnswerExecutor_pf;

    public ReleaseAssignmentSteps() {
        wait = new WebDriverWait(driver, Duration.ofSeconds(120));
        releaseAssignment_pf = new ReleaseAssignment_PF(driver);
        advancedGrading_pf = new AdvancedGrading_PF(driver);
        correctAnswerExecutor_pf = new CorrectAnswerExecutor_PF(driver);
    }

    @And("Click On Unit, Assignment And Assign Specific Assignment Type Expert Track For Correct Answer")
    public void SelectUnitAndAssignSpecificAssignmentTypeETForCorrectAnswers() throws InterruptedException{
        TestRunner.startTest("Assign Assignment Type Expert Track For Correct Answer");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            releaseAssignment_pf.ReleaseAssignmentTypeETForCorrectAnswer();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
        Thread.sleep(3000);
    }

    @And("Click on Unit, Assignment and Assign Specific Assignment For Individual Assignment Report")
    public void ClickOnUnitAssignmentAndAssignSpecificAssignmentForIndividualAssignmentReport() throws InterruptedException {
        TestRunner.startTest("Click on Unit, Assignment and Assign Specific Assignment For Individual Assignment Report");

        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            releaseAssignment_pf.ReleaseAssignmentForIndividualAssignmentReport();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
        Thread.sleep(3000);
    }

    @And("Click On Unit, Assignment And Assign Specific Group Assignment Type Expert Track For Correct Answer")
    public void SelectUnitAndAssignSpecificGroupAssignmentTypeETForCorrectAnswers() throws InterruptedException{
        TestRunner.startTest("Assign Group Assignment Type Expert Track For Correct Answer");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            releaseAssignment_pf.ReleaseGroupAssignmentTypeETForCorrectAnswer();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
        Thread.sleep(3000);
    }

    @And("Click On Unit, Assignment And Assign Specific Assignment Type Expert Track For InCorrect Answer")
    public void SelectUnitAndAssignSpecificAssignmentTypeETForInCorrectAnswers() throws InterruptedException{
        TestRunner.startTest("Assign Assignment Type Expert Track For InCorrect Answer");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            releaseAssignment_pf.ReleaseAssignmentTypeETForInCorrectAnswer();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
        Thread.sleep(3000);
    }

    @And("Click On Unit, Assignment And Assign Specific Assignment Type Vocabulary Builder For Correct Answer")
    public void SelectUnitAndAssignSpecificAssignmentTypeVBForCorrectAnswers() throws InterruptedException{
        TestRunner.startTest("Assign Assignment Type Vocabulary Builder For Correct Answer");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            releaseAssignment_pf.ReleaseAssignmentTypeVBForCorrectAnswer();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
        Thread.sleep(3000);
    }

    @And("Click On Unit, Assignment And Assign Specific Assignment Type Vocabulary Builder For InCorrect Answer")
    public void SelectUnitAndAssignSpecificAssignmentTypeVBForInCorrectAnswers() throws InterruptedException{
        TestRunner.startTest("Assign Assignment Type Vocabulary Builder For InCorrect Answer");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            releaseAssignment_pf.ReleaseAssignmentTypeVBForInCorrectAnswer();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
        Thread.sleep(3000);
    }

    @And("Click On Unit, Assignment And Assign Specific Assignment Type Vocabulary Quiz For Correct Answer")
    public void SelectUnitAndAssignSpecificAssignmentTypeVQForCorrectAnswers() throws InterruptedException{
        TestRunner.startTest("Assign Assignment Type Vocabulary Quiz For Correct Answer");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            releaseAssignment_pf.ReleaseAssignmentTypeVQForCorrectAnswer();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
        Thread.sleep(3000);
    }

    @And("Click On Unit, Assignment And Assign Specific Assignment Type Vocabulary Quiz For InCorrect Answer")
    public void SelectUnitAndAssignSpecificAssignmentTypeVQForInCorrectAnswers() throws InterruptedException{
        TestRunner.startTest("Assign Assignment Type Vocabulary Quiz For InCorrect Answer");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            releaseAssignment_pf.ReleaseAssignmentTypeVQForInCorrectAnswer();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
        Thread.sleep(3000);
    }

    @And("Click On Unit, Assignment And Assign Specific Assignment Type Digital Student Book For Correct Answer")
    public void SelectUnitAndAssignSpecificAssignmentTypeDSBForCorrectAnswers() throws InterruptedException{
        TestRunner.startTest("Assign Assignment Type Digital Student Book For Correct Answer");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            releaseAssignment_pf.ReleaseAssignmentTypeDSBForCorrectAnswer();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
        Thread.sleep(3000);
    }

    @And("Click On Closed Tab, Review Correct Answers Attempted Assignment for advanced Grading")
    public void SelectClosedTabAndReviewAttemptedCorrectAnswersAssignmentForAdvancedGrading() throws InterruptedException{
        TestRunner.startTest("Click on Closed Tab and Review Specific Assignment for Correct Answers");
        try {
            advancedGrading_pf.ReviewAttemptedCorrectAnswersAssignmentIntoClosedTab();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("verify Advanced Grading in close tab")
    public void AdvancedGradingInCloseTab() throws InterruptedException{
        TestRunner.startTest("In Close Tab Verify Advanced Grading Option");
        try {

            advancedGrading_pf.VerifyAdvancedGradingInAssignment();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Click On Unit, Assignment And Assign Specific Assignment Type Digital Student Book For InCorrect Answer")
    public void SelectUnitAndAssignSpecificAssignmentTypeDSBForInCorrectAnswers() throws InterruptedException{
        TestRunner.startTest("Assign Assignment Type Digital Student Book For InCorrect Answer");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            releaseAssignment_pf.ReleaseAssignmentTypeDSBForInCorrectAnswer();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
        Thread.sleep(3000);
    }

    @And("Click On Unit, Assignment And Assign Specific Assignment Type Vocabulary Quiz From District Admin")
    public void SelectUnitAndAssignSpecificAssignmentTypeVQFromDistrictAdmin() throws InterruptedException{
        TestRunner.startTest("Assign Assignment Type Vocabulary Quiz For Correct Answer");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            releaseAssignment_pf.ReleaseAssignmentTypeVQFromDistrict();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
        Thread.sleep(3000);
    }
}