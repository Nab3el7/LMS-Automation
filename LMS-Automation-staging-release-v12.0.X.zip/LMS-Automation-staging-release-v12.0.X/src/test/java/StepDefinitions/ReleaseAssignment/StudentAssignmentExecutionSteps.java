package StepDefinitions.ReleaseAssignment;

import StepDefinitions.AssignmentReviewSteps;
import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.bs.A;
import io.cucumber.java.en.And;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Assignmment.*;
import pageFactory.Gradebook.AssignmentScoreVerification_PF;
import pageFactory.Login_PF;

import java.awt.*;
import java.time.Duration;

public class StudentAssignmentExecutionSteps extends Configurations {
    // Lazy initialization - get driver only when needed
    private WebDriver driver;
    private WebDriverWait wait;
    private WebElement loader;

    StudentExecutor_PF studentExecutorPF;
    CorrectAnswerExecutor_PF correctAnswerExecutorPF;
    AnnotationAnswerExecutor_PF annotationAnswerExecutorPF;
    AssignmentScoreVerification_PF assignmentScoreVerificationPF;
    InCorrectAnswerExecutor_PF inCorrectAnswerExecutorPF;
    AssignmentStatusReview_PF assignmentStatusReviewPF;
    Login_PF loginPF;
    Helper helper;

    // Lazy getters - initialize only when accessed
    private WebDriver getWebDriver() {
        if (driver == null) {
            driver = Configurations.getDriver();
        }
        return driver;
    }

    private WebDriverWait getWebDriverWait() {
        if (wait == null) {
            wait = new WebDriverWait(getWebDriver(), Duration.ofSeconds(60));
        }
        return wait;
    }

    private WebElement getLoader() {
        if (loader == null) {
            loader = getWebDriver().findElement(By.xpath("//span[@role='progressbar']"));
        }
        return loader;
    }

    public StudentAssignmentExecutionSteps(){
        // Helper doesn't need driver immediately - it uses lazy initialization
        helper = new Helper();
        // Page objects will be initialized when driver is first accessed
    }

    // Initialize page objects when driver is first used
    private void ensurePageObjectsInitialized() {
        if (studentExecutorPF == null) {
            studentExecutorPF = new StudentExecutor_PF(getWebDriver());
            correctAnswerExecutorPF = new CorrectAnswerExecutor_PF(getWebDriver());
            annotationAnswerExecutorPF = new AnnotationAnswerExecutor_PF(getWebDriver());
            inCorrectAnswerExecutorPF = new InCorrectAnswerExecutor_PF(getWebDriver());
            assignmentScoreVerificationPF = new AssignmentScoreVerification_PF(getWebDriver());
            assignmentStatusReviewPF = new AssignmentStatusReview_PF(getWebDriver());
            loginPF = new Login_PF(getWebDriver());
        }
    }

    @And("Close Important Announcement")
    public void Check_ImportantAnnouncementDialog() throws InterruptedException {
        ensurePageObjectsInitialized();
        studentExecutorPF.dialogBox_ImpAnnouncement();
    }

    @And("Click On My Assignment Tabs On Student Dashboard")
    public void SelectMyAssignmentTabs() throws InterruptedException {
        ensurePageObjectsInitialized();
        TestRunner.startTest("Student Assignment Executions Dashboard");
        ensurePageObjectsInitialized();
        try {
            studentExecutorPF.selectAssignmentTabs();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }

    }

    @And("Search Assignment Into My Assignment Grid On Student Dashboard For Status Verification")
    public void SearchAssignmentIntoTabs() throws InterruptedException {
        ensurePageObjectsInitialized();
        TestRunner.startTest( "Student Assignment Executions");
        ensurePageObjectsInitialized();
        try {
            assignmentStatusReviewPF.searchAssignmentInAllTabs();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed :   :   Exception is found" + e);
            Assert.fail();
        }
    }

    @And("Click On Tab And Start Assignment On Student Dashboard")
    public void SelectTabAndStartAssignment() throws InterruptedException, AWTException {
        ensurePageObjectsInitialized();
        TestRunner.startTest( " Click on Open Tab and Start Assignment **********");
        ensurePageObjectsInitialized();
        try {
            studentExecutorPF.selectAssignmentIntoPanel();
            TestRunner.getTest().log(Status.PASS, " Test Case Passed :     :    Question Attempted Successfully  **********");
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed :    :   Exception is found  **********" + e);
            Assert.fail();
        }
    }

    @And("Click On Tab, Start And Submit Specific Assignment With Correct Answers")
    public void SelectTabAndStartSpecificAssignment() throws InterruptedException, AWTException {
        ensurePageObjectsInitialized();
        TestRunner.startTest("Start Specific Assignment for Correct Answers");
        try {
            correctAnswerExecutorPF.SelectAssignmentForCorrectAnswers();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Click On Open Tab, Start And Submit Specific Assignment With Correct Answers With All Annotations")
    public void SelectOpenTabAndStartSpecificAssignmentForAnnotation() throws InterruptedException, AWTException {
        ensurePageObjectsInitialized();
        TestRunner.startTest("Click On Open Tab, Start And Submit Specific Assignment With Correct Answers With All Annotations");
        try {
            annotationAnswerExecutorPF.SelectAssignmentForAnnotationCorrectAnswers();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Verify Applied Annotations In Closed Assignment")
    public void VerifyAnnotationsInCloseAssignment() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("In Close Assignment Verify Applied Annotations");
        try {

            annotationAnswerExecutorPF.validateAnnotationInClosedAssignment();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Click on Tab, And Scroll the Assignment List")
    public void SelectSpecificAssignmentThroughScrolling() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Click on Tab, And Scroll the Assignment List");
        try {
//            correctAnswerExecutorPF.verifyAssignmentFoundThroughScrolling();
            correctAnswerExecutorPF.verifyAssignmentsCountMatchesOpenTab();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Check And Validate The Annotate Text In Each Assignment")
    public void ValidateTheAnnotateTextInEachAssignment() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Check and Validate the Annotate Text in Each Assignment");
        try {
            getWebDriverWait().until(ExpectedConditions.invisibilityOf(getLoader()));
            annotationAnswerExecutorPF.checkAnnotateTextOfAssignment();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found. checkBox not found.");
            Assert.fail();
        }
        Thread.sleep(3000);
    }

    @And("Check And Validate The Highlighter In Each Assignment")
    public void ValidateTheHighlighterInEachAssignment() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Check and Validate the Highlighter in Each Assignment");
        try {
            getWebDriverWait().until(ExpectedConditions.invisibilityOf(getLoader()));
            annotationAnswerExecutorPF.checkHighlighterOfAssignment();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found. checkBox not found.");
            Assert.fail();
        }
        Thread.sleep(3000);
    }

    @And("Get All Assignment Names After Scrolling the Assignment List and Match Count with Open tab")
    public void GetAllAssignmentNamesAfterScrollingTheAssignmentList() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Get All Assignment Names After Scrolling the Assignment List and Match Count with Open tab");
        try {
            correctAnswerExecutorPF.GetAllAssignmentAfterScrollingAndMatchCountWithOpenTab();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Click On Tab, Start And Submit Specific Assignment After Scrolling")
    public void ClickOnTabStartAndSubmitSpecificAssignmentAfterScrolling() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Click On Tab, Start And Submit Specific Assignment After Scrolling");
        try {
            correctAnswerExecutorPF.StartAssignmentAfterScrolling();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Click On Tab, Start And Submit Specific Assignment With InCorrect Answers")
    public void SelectTabAndStartSpecificAssignmentWithInCorrectAnswers() throws InterruptedException, AWTException {
        ensurePageObjectsInitialized();
        TestRunner.startTest("Start Specific Assignment for Incorrect Answers");
        try {
            inCorrectAnswerExecutorPF.SelectAssignmentForInCorrectAnswers();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Get All Questions and Click on Next Question Button")
    public void GetAllQuestionsAndClickNextQuestion() throws InterruptedException, AWTException {
        ensurePageObjectsInitialized();
        TestRunner.startTest( " Get all Questions and click on Next Question button **********");
        studentExecutorPF.get_TotalQuestions();
        helper.takeScreenshot(getWebDriver() , Thread.currentThread().getStackTrace()[1].getMethodName() );
        Thread.sleep(2000);
    }

    @And("Click on Submit as Save Button and Submit the Assignment")
    public void SelectSubmitAssignment() throws InterruptedException {
        ensurePageObjectsInitialized();
        TestRunner.startTest( " Click on submit as save button and submit the assignment **********");
        studentExecutorPF.AssignmentSubmitAsCompleted();
        Thread.sleep(2000);
    }

    @And("Click On Tab, Start And Submit Assignments With Correct Answers")
    public void SelectTabAndStartAssignmentsWithCorrectAnswer() throws InterruptedException, AWTException {
        ensurePageObjectsInitialized();
        TestRunner.startTest( " Click on Open Tab and Start Assignment with Correct Answers**********");
        try {
            correctAnswerExecutorPF.SelectAttemptAndSubmitAssignmentIntoOpenTab();
            TestRunner.getTest().log(Status.PASS, " Test Case Passed :     :   Questions Attempted with Correct Answers Successfully  **********");
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed :    :   Exception is found  **********" + e);
            Assert.fail();
        }
    }

    @And("Click On Closed Tab, Review Correct Answers Attempted Assignment")
    public void SelectClosedTabAndReviewAttemptedCorrectAnswersAssignment() throws InterruptedException {
        ensurePageObjectsInitialized();
        TestRunner.startTest("Click on Closed Tab and Review Specific Assignment for Correct Answers");
        try {
            assignmentScoreVerificationPF.ReviewAttemptedCorrectAnswersAssignmentIntoClosedTab();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Click On Closed Tab, Review InCorrect Answers Attempted Assignment")
    public void SelectClosedTabAndReviewSpecificAssignment() throws InterruptedException {
        ensurePageObjectsInitialized();
        TestRunner.startTest("Click on Closed Tab and Review Specific Assignment for InCorrect Answers");
        try {
            assignmentScoreVerificationPF.ReviewAttemptedInCorrectAnswersAssignmentIntoClosedTab();
            TestRunner.getTest().log(Status.PASS, " Test Case Passed :     ::   Assignment Reviewed Successfully  **********");
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed :    ::   Exception is found  **********" + e);
            Assert.fail();
        }
    }

}