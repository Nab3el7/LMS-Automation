package StepDefinitions.ReleaseAssignment;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.MyContentModule.CreateAssessmentSteps;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.bs.A;
import io.cucumber.java.en.And;
import io.cucumber.java.sl.In;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Assignmment.AssignmentStatusReview_PF;
import pageFactory.Assignmment.CorrectAnswerExecutor_PF;
import pageFactory.Assignmment.InCorrectAnswerExecutor_PF;
import pageFactory.Assignmment.TeacherAssignment_PF;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.time.Duration;


public class AssignmentExecutionSteps extends Configurations {
    // Lazy initialization - get driver only when needed
    private WebDriver driver;
    private WebDriverWait wait;
    private WebElement loader;

    TeacherAssignment_PF teacherAssignmentPF;
    CorrectAnswerExecutor_PF correctAnswerExecutorPF;
    InCorrectAnswerExecutor_PF inCorrectAnswerExecutorPF;
    AssignmentStatusReview_PF assignmentStatusReviewPF;
    Helper helper;

    // Lazy getters - initialize only when accessed
    // Note: Using different names to avoid conflict with Configurations.getDriver()
    private WebDriver getWebDriver() {
        if (driver == null) {
            driver = Configurations.getDriver();
        }
        return driver;
    }

    private WebDriverWait getWebDriverWait() {
        if (wait == null) {
            wait = new WebDriverWait(getWebDriver(), Duration.ofSeconds(60));
        }
        return wait;
    }

    private WebElement getLoader() {
        if (loader == null) {
            loader = getWebDriver().findElement(By.xpath("//span[@role='progressbar']"));
        }
        return loader;
    }

    public AssignmentExecutionSteps(){
        // Helper doesn't need driver immediately - it uses lazy initialization
        helper = new Helper();
        // Page objects will be initialized when driver is first accessed
    }

    // Initialize page objects when driver is first used
    private void ensurePageObjectsInitialized() {
        if (teacherAssignmentPF == null) {
            teacherAssignmentPF = new TeacherAssignment_PF(getWebDriver());
            correctAnswerExecutorPF = new CorrectAnswerExecutor_PF(getWebDriver());
            inCorrectAnswerExecutorPF = new InCorrectAnswerExecutor_PF(getWebDriver());
            assignmentStatusReviewPF = new AssignmentStatusReview_PF(getWebDriver());
        }
    }
    

    @And("Click on Select Class")
    public void SelectClass() throws InterruptedException {
        ensurePageObjectsInitialized();
        TestRunner.startTest("  * * * * *  Teacher Release Assignment  **********");
        ensurePageObjectsInitialized();
        try {
            teacherAssignmentPF.SelectClass();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("Get All Courses And Click On Course")
    public void SelectCourse() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Get All Courses And Click On Course");
        ensurePageObjectsInitialized();
        try {
            teacherAssignmentPF.SelectCourse();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Select the Class and Get All Courses And Click On Course")
    public void SelectClassAndCourses() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("  Select the Class and Get All Courses And Click On Courses **********");
        ensurePageObjectsInitialized();
        try {
            teacherAssignmentPF.selectClassAndCourse();
            Thread.sleep(3000);
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed     :   Exception is found");
            Assert.fail();
        }
    }

    @And("Get All Units And Click on Specific Unit Of Assignment")
    public void SelectUnit(){
        ensurePageObjectsInitialized();
        TestRunner.startTest("  Get All Units and Click on the specific Unit **********");
        ensurePageObjectsInitialized();
        try {
            getWebDriverWait().until(ExpectedConditions.invisibilityOf(getLoader()));
            teacherAssignmentPF.SelectSpecificUnit();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found");
            Assert.fail();
        }

    }

    @And("Get All Assignments And Click to Specific Assign Button Of Assignment")
    public void SelectAssignmentsToAssign() throws InterruptedException, IOException, NoSuchAlgorithmException, KeyManagementException {
        ensurePageObjectsInitialized();
        TestRunner.startTest("  Get All Assignments And Click to Assign Button **********");
        ensurePageObjectsInitialized();
        try {
            teacherAssignmentPF.SelectSpecificAssignments();
            Thread.sleep(5000);
//        teacherAssignmentPF.OpenAssignedAssignment();
//        Thread.sleep(5000);
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed   :   Exception is found");
            Assert.fail();
        }
    }

    @And("Get All Units Assignments And Click on Unit and Assignments")
    public void ProcessAllUnitsAndAssignments() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest(" Get All Units Assignments And Click on Unit and Assignments **********");
        ensurePageObjectsInitialized();
        try {
            teacherAssignmentPF.processAllUnitsAndAssignments();
            TestRunner.getTest().log(Status.PASS, "   :   Assignment Release Successfully  **********");
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed   :   Exception is found  **********" + e);
            Assert.fail();
        }
        Thread.sleep(3000);
    }

    @And("Click On Unit, Assignment And Assign Specific Assignment For Correct Answers")
    public void SelectUnitAndAssignSpecificAssignmentForCorrectAnswers() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Click On Unit, Assignment And Assign Specific Assignment For Correct Answers");
        ensurePageObjectsInitialized();
        try {
            getWebDriverWait().until(ExpectedConditions.invisibilityOf(getLoader()));
            correctAnswerExecutorPF.ReleaseSpecificAssignmentForCorrectAnswers();
            TestRunner.getTest().log(Status.PASS,"  Test Case Passed    :   Specific Assignment Release For Correct Answers Successfully  **********");
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
        Thread.sleep(3000);
    }

    @And("Click On Unit, Assignment And Assign Specific Assignment For InCorrect Answers")
    public void SelectUnitAndAssignSpecificAssignmentForInCorrectAnswers() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Click On Unit, Assignment And Assign Specific Assignment For InCorrect Answers");
        ensurePageObjectsInitialized();
        try {
            inCorrectAnswerExecutorPF.ReleaseSpecificAssignmentForInCorrectAnswers();
            TestRunner.getTest().log(Status.PASS,"  Test Case Passed    :   Specific Assignment Release For InCorrect Answers Successfully  **********");
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
        Thread.sleep(3000);
    }

    @And("Check, Validate And Get All Units Assignments And Click on Unit and Assignments For Verify Assignment Status")
    public void ProcessAllUnitsAndAssignmentsForVerifyStatus() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("  Get All Units Assignments And Click on Unit and Assignments");
        ensurePageObjectsInitialized();
        try {
            assignmentStatusReviewPF.processAllUnitsAndAssignmentsForStatusVerification();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            ensurePageObjectsInitialized();
        TestRunner.startTest(" Test Case Failed    :   Exception is found" + e);
            Assert.fail();
        }
        Thread.sleep(3000);
    }

    @And("Check, Validate Get Unit And Release Assignment For Verify Assignment Future Status")
    public void ProcessAssignmentsForVerifyFutureStatus() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("Get Unit And Release Assignment For Future Status");
        ensurePageObjectsInitialized();
        try {
            assignmentStatusReviewPF.processReleasedAssignmentFutureStatus();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            ensurePageObjectsInitialized();
        TestRunner.startTest(" Test Case Failed    :   Exception is found" + e);
            Assert.fail();
        }
        Thread.sleep(3000);
    }

    @And("Enter The New Assignment Title Of Assignment")
    public void AddAssignmentTitle(){
        ensurePageObjectsInitialized();
        TestRunner.startTest("  Enter the New Assignment Title **********");
        ensurePageObjectsInitialized();
        try {
            teacherAssignmentPF.EnterAssignmentTitle();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found     ");
            Assert.fail();
        }
    }

    @And("Select The Assign To Class Of Assignment")
    public void SelectAssignTo() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("  Select the Assign To Class **********");
        try {
            teacherAssignmentPF.select_AssignTo();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :  Exception is found");
            Assert.fail();
        }
    }

    @And("Select The Toggle Open To Any Student Of Assignment")
    public void ToggleOpenToAnyStudent(){
        ensurePageObjectsInitialized();
        TestRunner.startTest("  Turn off the Toggle to Select the Student **********");
        try {
            teacherAssignmentPF.OpenToAnyStudentToggle();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed   :   Exception is found");
            Assert.fail();
        }
    }

    @And("Select The Students To Assign Of Assignment")
    public void SelectStudentsToAssign() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("  Select the Student to Students Dropdown **********");
        try {
            teacherAssignmentPF.select_Student();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :    Exception is found");
            Assert.fail();
        }
    }

    @And("Select The Start Date & Time Of Assignment")
    public void SelectStartDateTimeOfAssignment(){
        ensurePageObjectsInitialized();
        TestRunner.startTest("  Select the Start Date & Time of assignment in Calendar  **********");
        try {
            teacherAssignmentPF.setStartDateAndTime();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :     Exception is found");
            Assert.fail();
        }
    }

    @And("Select The End Date & Time Of Assignment")
    public void SelectEndDateTimeOfAssignment(){
        ensurePageObjectsInitialized();
        TestRunner.startTest("  Select the End Date & Time of assignment in Calendar  **********");
        try {
            teacherAssignmentPF.setEndDateAndTime();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :      Exception is found");
            Assert.fail();
        }
    }

    @And("Click On Allow Late Submission Of Assignment")
    public void SelectAllowLateSubmissionOfAssignment(){
        ensurePageObjectsInitialized();
        TestRunner.startTest("  Check the checkbox to Allow the Late Submission of Assignment  **********");
        try {
            teacherAssignmentPF.checkBoxLateSub();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed   :    Exception is found");
            Assert.fail();
        }
    }

    @And("Select The Late Submission Date & Time Of Assignment")
    public void SelectLateSubmissionDateTimeOfAssignment(){
        ensurePageObjectsInitialized();
        TestRunner.startTest("  Select the Late Submission Date & Time of assignment in Calendar  **********");
        try {
            teacherAssignmentPF.setLateSubDateAndTime();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found ");
            Assert.fail();
        }
    }

    @And("Select The Category Of Assignment")
    public void SelectCategoryOfAssignment() throws InterruptedException {
        ensurePageObjectsInitialized();
        TestRunner.startTest("  Select the Category of Assignment into Dropdown  **********");
        try {
            teacherAssignmentPF.select_category();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found  ");
            Assert.fail();
        }
    }

    @And("Click on Show Additional Settings Of Assignment")
    public void ClickShowAdditionalOfAssignment(){
        ensurePageObjectsInitialized();
        TestRunner.startTest("  Click on show Additional Settings panel of Assignment  **********");
        try {
            teacherAssignmentPF.select_ShowAdditionalSettings();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found   ");
            Assert.fail();
        }
    }

    @And("Select The Randomize Answer Choices Of Assignment")
    public void SelectRandomizeAnswerOfAssignment(){
        ensurePageObjectsInitialized();
        TestRunner.startTest("  Select the Randomize Answer Choices checkbox of Assignment  **********");
        try {
            teacherAssignmentPF.checkBox_RandomizeAnswerChoices();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found    ");
            Assert.fail();
        }
    }

    @And("Select The Display Grades To Student Of Assignment")
    public void SelectDisplayGradesToStudentOfAssignment(){
        ensurePageObjectsInitialized();
        TestRunner.startTest("  Select the Display Grades To Student checkbox of Assignment  **********");
        try {
            teacherAssignmentPF.checkBox_DisplayGradesToStudent();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed  :   Exception is found");
            Assert.fail();
        }
    }

    @And("Select The Review Options Of Assignment")
    public void SelectReviewOptionsOfAssignment() throws InterruptedException{
        ensurePageObjectsInitialized();
        TestRunner.startTest("  Select the Review Options dropdown of Assignment  **********");
        try {
            teacherAssignmentPF.dropDown_ReviewOptions();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    ::   Exception is found");
            Assert.fail();
        }
    }

    @And("Enter The Additional Instructions Of Assignment")
    public void SelectAdditionalInstructionsOfAssignment(){
        ensurePageObjectsInitialized();
        TestRunner.startTest("  Enter the Additional Instructions text area of Assignment  **********");
        try {
            teacherAssignmentPF.txtArea_AdditionalInstructions();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found.");
            Assert.fail();
        }
    }

    @And("Click The Assign Of Assignment")
    public void ClickAssignButtonOfAssignment(){
        ensurePageObjectsInitialized();
        TestRunner.startTest("  Click the Assign of Assignment  **********");
        try {
            teacherAssignmentPF.AssignAssignmentButton();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found. ");
            Assert.fail();
        }
    }

    @And("Verify The Popup Of Assignment Assigned And Close")
    public void VerifyPopupOfAssignmentAssignedAndClose(){
        ensurePageObjectsInitialized();
        TestRunner.startTest("  Verify the Popup of Assignment Assigned and close it **********");
        try {
            teacherAssignmentPF.VerifyDialogBox();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found...");
            Assert.fail();
        }
    }

}
