package StepDefinitions;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import io.cucumber.java.After;
import io.cucumber.java.AfterStep;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import java.util.Base64;

/**
 * Hooks for Cucumber scenarios - handles driver initialization and cleanup,
 * and captures screenshots ONLY for failed scenarios to reduce memory usage and report size.
 */
public class Hooks extends Configurations {

    private final Helper helper = new Helper();
    
    /**
     * Before each scenario - ensures driver is in a clean, valid state
     * and creates a thread-specific ExtentTest instance for the scenario
     */
    @Before
    public void beforeScenario(Scenario scenario) {
        System.out.println("Starting scenario: " + scenario.getName() + " on thread: " + Thread.currentThread().getName());
        
        // Small delay to prevent resource contention when multiple tests start simultaneously
        // This helps prevent tab crashes from resource exhaustion
        try {
            Thread.sleep(100); // 100ms delay to stagger test starts
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        
        // Clean up any stale driver without forcing initialization
        // Driver will be initialized lazily when first accessed via getDriver()
        Configurations.validateAndCleanStaleDriver();
        
        // Create ONE ExtentTest instance per scenario (thread-specific)
        // This ensures all logs within this scenario go to the correct test case
        String scenarioName = scenario.getName();
        String featureName = extractFeatureName(scenario.getId()); // Extract feature name from scenario ID
        
        // Create parent test for the scenario
        TestRunner.startScenarioTest(scenarioName, featureName);
    }

    /**
     * Extracts the feature name from a Cucumber scenario ID.
     * Handles both old format (with semicolon) and modern URI format.
     * 
     * @param scenarioId The scenario ID (e.g., "classpath:features/login.feature:4" or "feature;scenario")
     * @return The feature name (e.g., "login" from "login.feature")
     */
    private String extractFeatureName(String scenarioId) {
        if (scenarioId == null || scenarioId.isEmpty()) {
            return "Unknown Feature";
        }
        
        // Handle modern Cucumber-JVM URI format: "classpath:features/path/to/feature.feature:line"
        if (scenarioId.contains(":")) {
            // Extract the part before the last colon (which is the line number)
            String uriPart = scenarioId.substring(0, scenarioId.lastIndexOf(':'));
            
            // Extract filename from path (after last slash or backslash)
            String fileName;
            int lastSlash = Math.max(uriPart.lastIndexOf('/'), uriPart.lastIndexOf('\\'));
            if (lastSlash >= 0) {
                fileName = uriPart.substring(lastSlash + 1);
            } else {
                // No path separator, use the part after the colon (if any)
                int firstColon = uriPart.indexOf(':');
                fileName = firstColon >= 0 ? uriPart.substring(firstColon + 1) : uriPart;
            }
            
            // Remove .feature extension if present
            if (fileName.endsWith(".feature")) {
                fileName = fileName.substring(0, fileName.length() - ".feature".length());
            }
            
            return fileName.isEmpty() ? "Unknown Feature" : fileName;
        }
        
        // Handle legacy format with semicolon: "feature;scenario"
        if (scenarioId.contains(";")) {
            return scenarioId.split(";")[0];
        }
        
        // Fallback: return the ID as-is if no recognized format
        return scenarioId;
    }

    /**
     * After each step - DISABLED to only capture screenshots for failed test cases
     * Screenshots are now only captured in @After hook (addScreenshotOnFailure) when scenario fails
     * This reduces memory usage and report size by avoiding screenshots for all test cases
     */
    @AfterStep
    public void captureScreenshotAfterStep(Scenario scenario) {
        // Screenshots are only captured for failed scenarios in the @After hook
        // This method is intentionally left empty to prevent screenshots for all test cases
        // Screenshots for failed scenarios are handled by addScreenshotOnFailure() method
    }

    @After
    public void addScreenshotOnFailure(Scenario scenario) {
        WebDriver driver = null;
        boolean driverWasValid = false;
        
        // Handle screenshot for failed scenarios
        if (scenario.isFailed()) {
            try {
                driver = Configurations.getDriver();
                if (driver != null) {
                    driverWasValid = Configurations.isDriverValid(driver);
                }
            } catch (Exception e) {
                System.err.println("Could not fetch WebDriver for screenshot: " + e.getMessage());
            }

            if (driver != null && driverWasValid) {
                // Persist screenshot to disk (and Azure when enabled)
                String screenshotPath = helper.captureScreenshot(driver, scenario.getName());

                // Get screenshot as bytes for embedding
                byte[] screenshotBytes = null;
                try {
                    screenshotBytes = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
                } catch (Exception e) {
                    System.err.println("Unable to capture screenshot bytes: " + e.getMessage());
                }

                // Attach inline to Cucumber report
                if (screenshotBytes != null) {
                    try {
                        scenario.attach(screenshotBytes, "image/png", scenario.getName());
                    } catch (Exception e) {
                        System.err.println("Unable to attach screenshot to Cucumber report: " + e.getMessage());
                    }
                }

                // Attach to Extent report if available
                // Use base64 encoding to embed screenshot directly in HTML report
                try {
                    // Always use the scenario test (parent test) for screenshots
                    ExtentTest extentTest = TestRunner.getScenarioTest();
                    if (extentTest == null) {
                        // Fallback: try to get current test
                        extentTest = TestRunner.getTest();
                        if (extentTest == null) {
                            // Last resort: create a test if none exists
                            System.err.println("Warning: No ExtentTest found for scenario, creating one");
                            TestRunner.startScenarioTest(scenario.getName(), "Unknown Feature");
                            extentTest = TestRunner.getScenarioTest();
                        }
                    }

                    if (extentTest != null) {
                        extentTest.log(Status.FAIL, "Scenario failed: " + scenario.getName());
                        
                        // Use base64 encoding for embedded screenshot in HTML report
                        if (screenshotBytes != null) {
                            String base64Screenshot = Base64.getEncoder().encodeToString(screenshotBytes);
                            extentTest.fail(MediaEntityBuilder.createScreenCaptureFromBase64String(base64Screenshot, scenario.getName()).build());
                        } else if (screenshotPath != null) {
                            // Fallback to path if bytes not available
                            extentTest.fail(MediaEntityBuilder.createScreenCaptureFromPath(screenshotPath).build());
                        }
                    }
                } catch (Exception e) {
                    System.err.println("Unable to attach screenshot to Extent report: " + e.getMessage());
                    e.printStackTrace();
                }
            } else {
                System.out.println("⚠️ Could not capture screenshot - driver is null or invalid (tab may have crashed)");
            }
        }
        
        // End the scenario test to ensure proper cleanup
        TestRunner.endScenarioTest(scenario.isFailed());
        
        // CRITICAL: ALWAYS close browser and release Grid slot after EVERY test case
        // This ensures Grid slots are always freed for the next test, regardless of pass/fail
        String threadName = Thread.currentThread().getName();
        System.out.println("========================================");
        System.out.println("Test case completed");
        System.out.println("Thread: " + threadName);
        System.out.println("Scenario: " + scenario.getName());
        System.out.println("Status: " + (scenario.isFailed() ? "FAILED" : "PASSED"));
        System.out.println("Releasing Grid slot for next test case...");
        System.out.println("========================================");
        
        // ALWAYS close browser and release semaphore - ensures Grid slot is freed
        // This guarantees the next test case can execute immediately
        try {
            Configurations.closeDriver(); // This will close browser, clear ThreadLocal, and release semaphore
            System.out.println("✅ Grid slot released - next test case can now start");
        } catch (Exception e) {
            System.err.println("❌ Error during browser cleanup: " + e.getMessage());
            // Ensure semaphore is released even if cleanup fails
            try {
                // Force release semaphore as fallback
                Configurations.forceReleaseSemaphore();
            } catch (Exception cleanupEx) {
                System.err.println("❌ Error in fallback semaphore release: " + cleanupEx.getMessage());
            }
        }
    }
}

