package StepDefinitions.NotificationsModule;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.MyContent.CreateAssessment_PF;
import pageFactory.NotificationModule.AnnouncementStudentSide_PF;
import pageFactory.NotificationModule.CreateNotificationByTeacher_PF;

import java.time.Duration;

//import static StepDefinitions.Configurations.driver;

public class AnnouncementStudentSideSteps extends Configurations {
    WebDriver driver = Configurations.getDriver();

    Helper helper;
    CreateAssessment_PF createAssessmentPF;
    CreateNotificationByTeacher_PF createNotificationByTeacher_pf;
    AnnouncementStudentSide_PF  announcementStudentSide_pf;

    public WebDriverWait wait;
    WebElement loader = driver.findElement(By.xpath("//span[@role='progressbar']"));


    public AnnouncementStudentSideSteps(){
        helper = new Helper();
        createAssessmentPF = new CreateAssessment_PF(driver);
        createNotificationByTeacher_pf = new CreateNotificationByTeacher_PF(driver);
        announcementStudentSide_pf = new AnnouncementStudentSide_PF(driver);
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
    }


    @And("Check and Validate Notification button on Student Dashboard")
    public void NotificationButtonValidation() throws InterruptedException{
        TestRunner.startTest(" Check And Validate Notification Button is Displayed and Enabled in Student Dashboard");
        try {

            announcementStudentSide_pf.NotificationButtonStudentSide();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found. Notification Button is not Displayed and Enabled in Student Dashboard.");
            Assert.fail();
        }
    }

    @And("Validate Inbox Button for New Announcement")
    public void ValidateInboxButtonNewAnnouncement() throws InterruptedException{
        TestRunner.startTest("Validate Inbox Button for New Announcement At Student Side ");
        try {

            announcementStudentSide_pf.InboxButtonValidation();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found. Inbox button is not found in Left Panel..");
            Assert.fail();
        }
    }

    @And("Get All Announcement From Inbox Tab")
    public void GetAllAnnouncementFromInboxTab() throws InterruptedException{
        TestRunner.startTest("Get All Announcement From Inbox Tab ");
        try {

            announcementStudentSide_pf.GetAllAnnouncementInInboxTab();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found. Inbox Tab is found no data");

            Assert.fail();
        }
    }

    @And("Get All Details of That Announcement for Inbox")
    public void GetAllDetailsAnnouncementInbox() throws InterruptedException{
        TestRunner.startTest("Get All Details of That Announcement In Inbox ");
        try {

            announcementStudentSide_pf.GetAllDetailsInRightPanelForInbox();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found. Details not found");
            Assert.fail();
        }

    }

    @And("Validate and Click on Read Announcement Button")
    public void ClickReadAnnouncementButton() throws InterruptedException{
        TestRunner.startTest("Validate and Click on Read Announcement Button ");
        try {

            announcementStudentSide_pf.ReadAnnouncementButton();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed :  Exception is found. Read Button not found");
            Assert.fail();
        }
    }

    @And("Verify Toast Message for Read Announcement")
    public void VerifyToastMessageReadAnnouncement()throws InterruptedException{
        TestRunner.startTest("Verify Toast Message for Read Announcement");
        try {

            announcementStudentSide_pf.VerifyToastMessage();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found. Toast Message not found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Verify That Announcement is not Present in Inbox")
    public void VerifyThatAnnouncementNotPresentInbox()throws InterruptedException{
        TestRunner.startTest("Verify That Announcement is not Present in Inbox");
        try {

            Thread.sleep(2000);
            announcementStudentSide_pf.VerifyInboxSection();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found. Read Announcement Also found in Inbox");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Validate and Click on Read Announcement Tab")
    public void ReadAnnouncementTab() throws InterruptedException{
        TestRunner.startTest("Validate and Click on Read Announcement Tab");
        try {

            announcementStudentSide_pf.ReadTabAnnouncement();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found. Read Tab Not found.");

            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Verify That Announcement is Present in Read After Read operation")
    public void VerifyThatAnnouncementPresentInReadAfterReadOperation() throws InterruptedException{
        TestRunner.startTest("Verify That Announcement is Present in Read After Read operation");
        try {

            announcementStudentSide_pf.VerifyReadSectionAfterReadingAnnouncement();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found. Announcement not found in Read");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Validate and Click Archive Announcement Button")
    public void ValidateArchiveAnnouncementButton() throws InterruptedException{
        TestRunner.startTest("Validate and Click Archive Announcement Button");
        try {

            announcementStudentSide_pf.ClickArchiveButton();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found. Archive button not found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Validate and Click on Archive Announcement Tab")
    public void ClickArchiveAnnouncementTab()throws InterruptedException{
        TestRunner.startTest("Validate and Click on Archive Announcement Tab");
        try {

            announcementStudentSide_pf.ArchiveTabAnnouncement();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed :  Exception is found. Archive tab not found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Check and Validate Delete Button")
    public void ValidateDeleteButton() throws InterruptedException{
        TestRunner.startTest("Check and Validate Delete Button");
        try {

            announcementStudentSide_pf.ClickDeleteButton();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed :  Exception is found. Delete Button not found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Verify Deleting Announcement window")
    public void VerifyDeletingAnnouncementWindow() throws InterruptedException{
        TestRunner.startTest("Verify Deleting Announcement Window");
        try {

            announcementStudentSide_pf.VerifyDeletingAnnouncementWindow();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found. Deleting Announcement window not found");
            Assert.fail();
        }
    }

    @And("Verify Announcement Delete from All Tabs")
    public void VerifyAnnouncementDeleteFromAllTabs() throws InterruptedException{
        TestRunner.startTest("Verify Announcement Delete from All Tabs");
        try {

            announcementStudentSide_pf.VerifyDeletedAnnouncementInAllTabs();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found. Deleting Announcement Still found");

            Assert.fail();
        }
    }
}
