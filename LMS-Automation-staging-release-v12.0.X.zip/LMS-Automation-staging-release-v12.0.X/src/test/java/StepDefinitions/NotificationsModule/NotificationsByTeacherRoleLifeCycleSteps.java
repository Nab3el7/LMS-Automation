package StepDefinitions.NotificationsModule;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.MyContentModule.CreateAssessmentSteps;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.MyContent.CreateAssessment_PF;
import pageFactory.NotificationModule.CreateNotificationByTeacher_PF;

import java.time.Duration;

//import static StepDefinitions.Configurations.driver;

public class NotificationsByTeacherRoleLifeCycleSteps extends Configurations {
    WebDriver driver = Configurations.getDriver();
    Helper helper;
    CreateAssessment_PF createAssessmentPF;
    CreateNotificationByTeacher_PF createNotificationByTeacher_pf;

    public WebDriverWait wait;
    WebElement loader = driver.findElement(By.xpath("//span[@role='progressbar']"));


    public NotificationsByTeacherRoleLifeCycleSteps(){
        helper = new Helper();
        createAssessmentPF = new CreateAssessment_PF(driver);
        createNotificationByTeacher_pf = new CreateNotificationByTeacher_PF(driver);
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
    }


    @And("Check and validate Staff Dashboard")
    public void ValidateStaffDashboard() throws InterruptedException{
        TestRunner.startTest("Teacher Dashboard");
        try {

            createAssessmentPF.waitUntilProgressBar();
            createNotificationByTeacher_pf.teacherDashboard();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found. Teacher Dashboard not load");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Check And Validate The Side Navbar and Progress Bar")
    public void CheckAndValidateTheSideNavbarAndProgressBar() throws InterruptedException{
        TestRunner.startTest("Check And Validate The Side Navbar ");
        try {

            createNotificationByTeacher_pf.SideNavBar();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found. Side Nav Bar is not Loading");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Check and Validate Notification button on Teacher Dashboard")
    public void NotificationButtonValidation() throws InterruptedException{
        TestRunner.startTest("Check And Validate Notification Button is Displayed and Enabled ");
        try {

            createNotificationByTeacher_pf.NotificationButton();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found. Notification Button is not Displayed and Enabled");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Check and Validate Notification Dialogue Box")
    public void NotificationDialogueBox() throws InterruptedException{
        TestRunner.startTest("Check And Validate Notification Dialogue Box Open");
        try {

            createNotificationByTeacher_pf.NotificationDialogueBox();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found. Exception is found. Notification Dialogue Box Open not Open");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Verify and Click on Add Outlined Icon for creation of New Notification")
    public void ClickAddOutlinedIcon() throws InterruptedException{
        TestRunner.startTest("Check And Validate Add Outlined Icon for creation of New Notification");
        try {

            createNotificationByTeacher_pf.clickOnPlusIcon();
            Thread.sleep(2000);
            createNotificationByTeacher_pf.validateNotificationDashboard();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found. Add Outlined Icon for creation of New Notification is not Displayed.");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Enter Announcement Title for Announcement")
    public void EnterAnnouncementTitle() throws InterruptedException{
        TestRunner.startTest("Enter Announcement Title ");
        try {

            Thread.sleep(2000);
            createNotificationByTeacher_pf.EnterAnnouncementTitle();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found. Announcement Title field not display.");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Select Type for Announcement")
    public void SelectType() throws InterruptedException{
        TestRunner.startTest(" Select Type  ");
        try {

            Thread.sleep(2000);
            createNotificationByTeacher_pf.selectType();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found. Type not Selected.");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Select Status for Announcement")
    public void SelectStatusForAnnouncement() throws InterruptedException {
        TestRunner.startTest(" Status for Announcement  ");
        try {

            Thread.sleep(2000);
            createNotificationByTeacher_pf.selectStatusForAnnouncement();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found. Status  not Selected");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Select The End Date & Time Of Announcement")
    public void EndDateAndTime() throws InterruptedException{
        TestRunner.startTest("Select The End Date & Time Of Announcement ");
        try {

            Thread.sleep(2000);
            createNotificationByTeacher_pf.setStartDateAndTime();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found. End Date Not Selected.");
            Assert.fail();
        }
        Thread.sleep(2000);

    }

    @And("Select Urgency For Announcement")
    public void selectUrgencyForAnnouncement() throws InterruptedException{
        TestRunner.startTest(" Urgency for Announcement ");
        try {

            Thread.sleep(2000);
            createNotificationByTeacher_pf.selectUrgencyForAnnouncement();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found. Urgency not Selected.");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Clicked on Auto-Display CheckBox")
    public void AutoDisplayCheckBox() throws InterruptedException{
        TestRunner.startTest(" Clicked on Auto-Display CheckBox ");
        try {

            Thread.sleep(2000);
            createNotificationByTeacher_pf.selectAutoDDisplayCheckBox();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found. Auto-Display CheckBox not Clicked.");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Enter Announcement Statement")
    public void EnterAnnouncementStatement() throws InterruptedException{
        TestRunner.startTest(" Enter Announcement Statement ");
        try {

            Thread.sleep(2000);
            createNotificationByTeacher_pf.AnnouncementStatement();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed :  Exception is found. Announcement Statement Area is not Display.");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Click on Next Button in Announcement")
    public void ClickNextButtonAnnouncement() throws InterruptedException{
        TestRunner.startTest(" Click on Next Button in Announcement ");
        try {

            Thread.sleep(2000);
            createNotificationByTeacher_pf.NextButtonAnnouncement();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed :  Exception is found. Announcement Next button is not Display");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Select Class in Announcement")
    public void SelectClassInAnnouncement() throws InterruptedException{
        TestRunner.startTest(" Select Class in Announcement ");
        try {

            createNotificationByTeacher_pf.selected_Class();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed :  Exception is found. Classes Dropdown not found.");
            Assert.fail();
        }
    }

    @And("Select Roles in Distribution Details")
    public void SelectRolesDistributionDetails() throws InterruptedException{
        TestRunner.startTest(" Select Roles in Distribution Details ");
        try {
            createNotificationByTeacher_pf.Select_Roles();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed :  Exception is found. Role not found.");
            Assert.fail();
        }
    }

    @And("Validate and Get Summary of Announcement")
    public void GetSummaryOfAnnouncement() throws InterruptedException{
        TestRunner.startTest(" Validate and Get Summary of Announcement ");
        try {
            Thread.sleep(2000);
            createNotificationByTeacher_pf.getAnnouncementSummary();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found. Summary not Displayed.");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Click on Send Button on Announcement")
    public void SendButton() throws InterruptedException{
        TestRunner.startTest(" Click on Send Button on Announcement ");
        try {
            createNotificationByTeacher_pf.ClickSendButton();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found. Send Button not Enabled.");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Verify Sending Announcement Dialogue")
    public void VerifySendingAnnouncementDialogue() throws InterruptedException{
        TestRunner.startTest(" Verify Sending Announcement Dialogue ");
        try {

            createNotificationByTeacher_pf.ValidateSendingAnnouncementDialogueBox();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found. Announcement Dialogue box not appear.");
            Assert.fail();
        }
    }

    @And("Verify New Announcement Toast Message")
    public void VerifyNewAnnouncementToastMessage() throws InterruptedException{
        TestRunner.startTest(" Verify New Announcement Toast Message ");
        try {
            createNotificationByTeacher_pf.ValidateToastMessage();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found. Announcement Toast Message box not appear.");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Verify Important Announcement Dialogue Box with Information That Teacher set")
    public void dialogBox_ImpAnnouncementVerify() throws InterruptedException {
        TestRunner.startTest(" Verify Important Announcement Dialogue Box with Information That Teacher set");
        try {
            createNotificationByTeacher_pf.ValidateImportantAnnouncementDialogueBox();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found. Announcement Dialogue Box not appear.");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

}
