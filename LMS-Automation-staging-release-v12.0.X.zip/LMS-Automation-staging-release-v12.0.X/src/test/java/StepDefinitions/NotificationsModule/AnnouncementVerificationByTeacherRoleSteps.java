package StepDefinitions.NotificationsModule;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.MyContent.CreateAssessment_PF;
import pageFactory.NotificationModule.AnnouncementVerificationByTeacherRole_PF;
import pageFactory.NotificationModule.CreateNotificationByTeacher_PF;

import java.time.Duration;

//import static StepDefinitions.Configurations.driver;

public class AnnouncementVerificationByTeacherRoleSteps extends Configurations {
    WebDriver driver = Configurations.getDriver();
    Helper helper;
    CreateAssessment_PF createAssessmentPF;
    CreateNotificationByTeacher_PF createNotificationByTeacher_pf;
    AnnouncementVerificationByTeacherRole_PF announcementVerificationByTeacherRole_pf;

    public WebDriverWait wait;
    WebElement loader = driver.findElement(By.xpath("//span[@role='progressbar']"));


    public AnnouncementVerificationByTeacherRoleSteps(){
        helper = new Helper();
        createAssessmentPF = new CreateAssessment_PF(driver);
        createNotificationByTeacher_pf = new CreateNotificationByTeacher_PF(driver);
        announcementVerificationByTeacherRole_pf = new AnnouncementVerificationByTeacherRole_PF(driver);
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
    }


    @And("Click On User Dashboard")
    public void ValidateStaffDashboard() throws InterruptedException{
        TestRunner.startTest("Click On User Dashboard ");
        try {

            createAssessmentPF.waitUntilProgressBar();
            announcementVerificationByTeacherRole_pf.ClickUserDashboard();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed  : Exception is found. User Dashboard not Clicked");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Check and Validate View All Button In Announcement")
    public void VerifyViewAllButton() throws InterruptedException{
        TestRunner.startTest("Check and Validate View All Button In Announcement");
        try {

            createAssessmentPF.waitUntilProgressBar();
            announcementVerificationByTeacherRole_pf.ClickViewAllButton();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found. View All Button is not Enable/Display");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Verify Announcement Left panel Display")
    public void VerifyAnnouncementLeftPanelDisplay() throws InterruptedException{
        TestRunner.startTest("Verify Announcement Left panel Display ");
        try {

            announcementVerificationByTeacherRole_pf.verifyLeftPanel();
            Thread.sleep(2000);
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found. Left Panel Not Display");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Click and Validate Sent Button")
    public void ClickAndValidateSentButton() throws InterruptedException{
        TestRunner.startTest("Click and Validate Sent Button ");
        try {

            announcementVerificationByTeacherRole_pf.validateSentButton();
            Thread.sleep(2000);
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found. Sent button is not found in Left Panel");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Get All Announcement From Sent Tab")
    public void GetAllAnnouncementFromSentTab() throws InterruptedException{
        TestRunner.startTest(" Get All Announcement From Sent Tab ");
        try {

            announcementVerificationByTeacherRole_pf.GetAllAnnouncementInSentTab();
            Thread.sleep(2000);
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed :  Exception is found. Sent Tab is found no data");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Get All Details of That Announcement")
    public void GetAllDetailsOfThatAnnouncement()throws InterruptedException{
        TestRunner.startTest(" Get All Details of That Announcement ");
        try {

            announcementVerificationByTeacherRole_pf.GetAllDetailsInRightPanel();
            Thread.sleep(2000);
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found. Details not found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }
}
