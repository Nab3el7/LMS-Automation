package StepDefinitions.ItemAnalysisReports;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Assignmment.CorrectAnswerExecutor_PF;
import pageFactory.ItemAnalysisReports.ItemAnalysisReportsFilter_PF;

import java.time.Duration;

import static pageFactory.MyContent.AssignAssessment_PF.CategoryFromAssignment;

public class ItemAnalysisReportsFilterSteps {

    WebDriver driver = Configurations.getDriver();
    Helper helper;
    Actions actions;

    ItemAnalysisReportsFilter_PF itemAnalysisReportsFilter_pf;

    public WebDriverWait wait;
    WebElement loader = driver.findElement(By.xpath("//span[@role='progressbar']"));


    public ItemAnalysisReportsFilterSteps(){
        helper = new Helper();
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
        actions = new Actions(driver);
        itemAnalysisReportsFilter_pf = new ItemAnalysisReportsFilter_PF(driver);

    }

    @And("Verify Side Navbar and Clicked on Reports Module")
    public void VerifySideNavbarAndClickedOnReportsModule() throws InterruptedException {
        TestRunner.startTest("Verify Side Navbar and Clicked on Reports Module");
        try {
            itemAnalysisReportsFilter_pf.SideNavBarAndClickOnReportsModule();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception found");
            Assert.fail();
        }
    }

    @And("Validate and Click on Item Analysis Reports From Favorite Reports")
    public void ValidateAndClickOnItemAnalysisReportsFromFavoriteReports() throws InterruptedException {
        TestRunner.startTest("Validate and Click on Item Analysis Reports From Favorite Reports");
        try {
            itemAnalysisReportsFilter_pf.VerifyAndClickOnItemAnalysisReport();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Validate and Check Right Text on Run Report Screen")
    public void ValidateAndCheckRightTextOnRunReportScreen() throws InterruptedException{
        TestRunner.startTest("Validate and Check Right Text on Run Report Screen");
        try {
            itemAnalysisReportsFilter_pf.verifyLeftSideText();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Validate and Check By Default By Class is Selected")
    public void ValidateAndCheckByDefaultByClassIsSelected() throws InterruptedException {
        TestRunner.startTest("Validate and Check By Default By Class is Selected");
        try {
            itemAnalysisReportsFilter_pf.ValidateByDefaultByClassButtonIsPressed();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line  number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Select School Year From School Year Dropdown")
    public void SelectSchoolYearFromSchoolYearDropdown() throws InterruptedException {
        TestRunner.startTest("Select School Year From School Year Dropdown");
        try {
            itemAnalysisReportsFilter_pf.selectSchoolYearForReport();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Select District For Report")
    public void SelectDistrictForReport() throws InterruptedException {
        TestRunner.startTest("Select District For Report");
        try {
            itemAnalysisReportsFilter_pf.selectDistrictForReport();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Select School For Report")
    public void SelectSchoolForReport() throws InterruptedException {
        TestRunner.startTest("Select School For Report");
        try {

            itemAnalysisReportsFilter_pf.selectSchoolForReport();
        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed :  Exception is found");
            Assert.fail();
        }
    }

    @And("Select Teacher For Report")
    public void SelectTeacherForReport() throws InterruptedException {
        TestRunner.startTest("Select Teacher For Report");
        try {

            itemAnalysisReportsFilter_pf.selectTeacherForReport();
        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed :  Exception is found");
            Assert.fail();
        }
    }


    @And("Select Categories from DropDown option")
    public void SelectCategoriesFromDropDownOption() throws InterruptedException{
        TestRunner.startTest(" Select Categories from DropDown option ");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            itemAnalysisReportsFilter_pf.SelectCategoryFromReports(CategoryFromAssignment);
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  Exception is found.");
            Assert.fail();
        }
//        Thread.sleep(2000);
    }

    @And("Validate Assignment Table Display in Right Side")
    public void ValidateAssignmentTableDisplayInRightSide() throws InterruptedException {
        TestRunner.startTest("Validate Assignment Table Display in Right Side");
        try {
            itemAnalysisReportsFilter_pf.verifyDataInRightSideReport();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

//    search Assignment
    @And("Validate and Click on Assignment Title Checkbox")
    public void ValidateAndClickOnAssignmentTitleCheckbox() throws InterruptedException {
        TestRunner.startTest( "Validate and Click on Assignment Title Checkbox");
        try {
            itemAnalysisReportsFilter_pf.verifyAndClickAssignmentTitleCheckbox();
        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Search Assignment By Title In Search Box")
    public void SearchAssignmentByTitleInSearchBox() throws InterruptedException {
        TestRunner.startTest("Search Assignment By Title In Search Box");
        try {
            itemAnalysisReportsFilter_pf.searchAssignmentByTitleForReport();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed :  Exception is found");
            Assert.fail();
        }
    }

    @And("Verify Search Assignment On Reports found in Table")
    public void VerifySearchAssignmentOnReportFoundInTable() throws InterruptedException {
        TestRunner.startTest("Verify Search Assignment On Reports found in Table");
        try {

            itemAnalysisReportsFilter_pf.verifySearchedAssessmentByTitleIntoTable();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Validate and Check Resource Title Checkbox is Already Checked")
    public void ValidateAndCheckResourceTitleCheckboxIsAlreadyChecked() throws InterruptedException {
        TestRunner.startTest("Validate and Check Resource Title Checkbox is Already Checked");
        try {
            itemAnalysisReportsFilter_pf.VerifyResourceTitleCheckBox();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Validate and Click on Preview Button On Run Report")
    public void ValidateAndClickOnPreviewButtonOnRunReport() throws InterruptedException {
        TestRunner.startTest("Validate and Click on Preview Button On Run Report");
        try {
            itemAnalysisReportsFilter_pf.verifyAndClickPreview();
        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Get All Questions From Preview Report")
    public void GetAllQuestionsFromPreviewReport() throws InterruptedException {
        TestRunner.startTest("Get All Questions From Preview Report ");
        try {
            itemAnalysisReportsFilter_pf.VerifyReportPreviewQuestions();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Validate and Verify That Questions From Open Assignment and Question On Preview Report Match")
    public void ValidateAndVerifyThatQuestionsFromOpenAssignmentAndQuestionOnPreviewReportMatch() throws InterruptedException {
        TestRunner.startTest("Validate and Verify That Questions From Open Assignment and Question On Preview Report Match");
        try {

            itemAnalysisReportsFilter_pf.VerificationOfReportPreview();
        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

//    Run Report
    @And("Validate and Click on Assignment To Run Report")
    public void ValidateAndClickOnAssignmentToRunReport() throws InterruptedException {
        TestRunner.startTest("Validate and Click on Assignment To Run Report");
        try {
            itemAnalysisReportsFilter_pf.clickOnAssignmentCheckbox();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }


    @And("Validate and Click on Run Button")
    public void ValidateAndClickOnRunButton() throws InterruptedException {
        TestRunner.startTest("Validate and Click on Run Button on Run Report Screen");
        try {
            itemAnalysisReportsFilter_pf.VerifyAndClickRunButton();
        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Check, Verify and Click on Points Button")
    public void CheckVerifyAndClickOnPointsButton() throws InterruptedException {
        TestRunner.startTest("Check, Verify and Click on Points Button");
        try {
            itemAnalysisReportsFilter_pf.clickPointsButton();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Validate and Get Questions Points From Summary")
    public void ValidateAndGetQuestionsPointsFromSummary() throws InterruptedException {
        TestRunner.startTest("Validate and Get Questions Points From Summary");
        try {
            itemAnalysisReportsFilter_pf.getQuestionPointsFromSummary();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Validate and Get OverAll Average from Summary")
    public void ValidateAndGetOverAllAverageFromSummary() throws InterruptedException {
        TestRunner.startTest("Validate and Get OverAll Average from Summary");
        try {
            itemAnalysisReportsFilter_pf.getOverAllAverageFromSummary();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Validate and Get Questions Points From Run Report")
    public void ValidateAndGetQuestionsPointsFromRunReport() throws InterruptedException {
        TestRunner.startTest("Validate and Get Questions Points From Run Report");
        try {
            itemAnalysisReportsFilter_pf.getQuestionPointsFromRunReport();
        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Validate and Get OverAll Average from Run Report")
    public void ValidateAndGetOverAllAverageFromRunReport() throws InterruptedException {
        TestRunner.startTest( "Validate and Get OverAll Average from Run Report");
        try {
            itemAnalysisReportsFilter_pf.getOverAllAverageFromRunReport();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Verify Points and Average Match")
    public void VerifyPointsAndAverageMatch() throws InterruptedException {
        TestRunner.startTest("Verify Points and Average Match");
        try {
            itemAnalysisReportsFilter_pf.compareSummaryAndRunReportData();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Validate and Check Level And Scores Present on Run Report")
    public void ValidateAndCheckLevelAndScoresPresentOnRunReport() throws InterruptedException {
        TestRunner.startTest("Validate and Check Level And Scores Present on Run Report");
        try {
            itemAnalysisReportsFilter_pf.verifyLevelAndScores();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Validate and Check that Student Name and Status is also present on Run Report")
    public void ValidateAndCheckThatStudentNameAndStatusIsAlsoPresentOnRunReport() throws InterruptedException {
        TestRunner.startTest("Validate and Check that Student Name and Status is also present on Run Report");
        try {
            itemAnalysisReportsFilter_pf.verifyStudentAndStatusPresent();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Validate That In Courses Dropdown Correct Assignment Is AlReady Selected")
    public void ValidateThatInCoursesDropdownCorrectAssignmentIsAlReadySelected() throws InterruptedException {
        TestRunner.startTest("Validate That In Courses Dropdown Correct Assignment Is AlReady Selected");
        try {
            String assignmentNameForCorrect = CorrectAnswerExecutor_PF.assignmentNameForCorrect.get();
            System.out.println("Want to open attempted assignment: " + assignmentNameForCorrect);
            TestRunner.getTest().log(Status.INFO, "Want to open attempted assignment: " + assignmentNameForCorrect);

            itemAnalysisReportsFilter_pf.VerifyCorrectAssignmentIsAlreadySelectedInDropdown(assignmentNameForCorrect);
        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Validate and Click on Print Button On Run Report")
    public void ValidateAndClickOnPrintButtonOnRunReport() throws InterruptedException{
        TestRunner.startTest("Validate and Click on Print Button On Run Report");
        try {

            itemAnalysisReportsFilter_pf.validatePrint();
        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Validate and Check Print Loading")
    public void ValidateAndCheckPrintLoading() throws InterruptedException {
        TestRunner.startTest("Validate and Check Print Loading");
        try {
            itemAnalysisReportsFilter_pf.printLoading();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }
}
