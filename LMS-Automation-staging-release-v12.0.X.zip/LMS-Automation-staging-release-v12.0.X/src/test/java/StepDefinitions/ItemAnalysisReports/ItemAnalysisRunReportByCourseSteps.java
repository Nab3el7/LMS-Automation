package StepDefinitions.ItemAnalysisReports;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.ItemAnalysisReports.ItemAnalysisReportsFilter_PF;
import pageFactory.ItemAnalysisReports.ItemAnalysisRunReportByCourse_PF;

import java.time.Duration;

public class ItemAnalysisRunReportByCourseSteps {
    WebDriver driver = Configurations.getDriver();
    Helper helper;
    Actions actions;

    ItemAnalysisRunReportByCourse_PF itemAnalysisRunReportByCourse_pf;

    public WebDriverWait wait;
    WebElement loader = driver.findElement(By.xpath("//span[@role='progressbar']"));


    public ItemAnalysisRunReportByCourseSteps(){
        helper = new Helper();
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
        actions = new Actions(driver);
        itemAnalysisRunReportByCourse_pf = new ItemAnalysisRunReportByCourse_PF(driver);

    }

    @And("Validate and Get Questions Point For Report By Course From Summary")
    public void ValidateAndGetQuestionsPointForReportByCourseFromSummary() throws InterruptedException {
        TestRunner.startTest("Validate and Get Questions Point For Report By Course From Summary");
        try {

            itemAnalysisRunReportByCourse_pf.getQuestionPointsFromSummaryForByCourse();


        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Validate and Get Overall Average For Report By Course From Summary")
    public void ValidateAndGetOverallAverageForReportByCourseFromSummary() throws InterruptedException {
        TestRunner.startTest("Validate and Get Overall Average For Report By Course From Summary");
        try {
            itemAnalysisRunReportByCourse_pf.getOverAllAverageFromSummaryForByCourse();
        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number:   " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case failed : Exception is found");
            Assert.fail();
        }
    }

    @And("From List Of Levels Select Specific Class")
    public void FromListOfLevelsSelectSpecificClass() throws InterruptedException {
        TestRunner.startTest("From List Of Levels Select Specific Class");
        try {
            itemAnalysisRunReportByCourse_pf.FromLevelSelectClass();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Validate and Click on Assignment Name From Level")
    public void ValidateAndClickOnAssignmentNameFromLevel() throws InterruptedException {
        TestRunner.startTest("Validate and Click on Assignment Name From Level");
        try {
            itemAnalysisRunReportByCourse_pf.SelectAssignmentFromLevel();
        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }


    @And("Validate and Get Question Points By Course From Run Report")
    public void ValidateAndGetQuestionPointsByCourseFromRunReport() throws InterruptedException {
        TestRunner.startTest("Validate and Get Question Points By Course From Run Report");
        try {
            itemAnalysisRunReportByCourse_pf.getQuestionPointsFromRunReportForByCourse();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Validate and Get OverAll Average By Course From Run Report")
    public void ValidateAndGetOverAllAverageByCourseFromRunReport() throws InterruptedException {
        TestRunner.startTest("Validate and Get OverAll Average By Course From Run Report");
        try {

            itemAnalysisRunReportByCourse_pf.getOverAllAverageFromRunReportByCourse();
        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }

    }

    @And("Verify Points and Average Match For Report By Course")
    public void VerifyPointsAndAverageMatchForReportByCourse() throws InterruptedException {
        TestRunner.startTest("Verify Points and Average Match For Report By Course");
        try {
            itemAnalysisRunReportByCourse_pf.compareSummaryAndRunReportDataForReportByCourse();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }
}
