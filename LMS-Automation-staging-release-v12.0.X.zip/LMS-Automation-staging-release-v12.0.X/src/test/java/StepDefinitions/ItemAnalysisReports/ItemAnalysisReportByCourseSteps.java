package StepDefinitions.ItemAnalysisReports;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.ItemAnalysisReports.ItemAnalysisReportByCourse_PF;

import java.time.Duration;


public class ItemAnalysisReportByCourseSteps {
    WebDriver driver = Configurations.getDriver();

    Helper helper;

    Actions actions;
    ItemAnalysisReportByCourse_PF itemAnalysisReportByCourse_pf;

    public WebDriverWait wait;
    WebElement loader = driver.findElement(By.xpath("//span[@role='progressbar']"));



    public ItemAnalysisReportByCourseSteps(){
        helper = new Helper();
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
        actions = new Actions(driver);
        itemAnalysisReportByCourse_pf= new ItemAnalysisReportByCourse_PF(driver);

    }

    @And("Validate and Click on By Course")
    public void ValidateAndClickOnByCourse() throws InterruptedException {
        TestRunner.startTest("Validate and Click on By Course");
        try {
            itemAnalysisReportByCourse_pf.clickByCourseButton();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }


    @And("Get All Courses And Click On Course For Report")
    public void SelectCourse() throws InterruptedException{
        TestRunner.startTest("Get All Courses And Click On Course For Report");
        try {
            itemAnalysisReportByCourse_pf.SelectCourseForReport();

        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Select Course On Run Report")
    public void SelectCourseOnRunReport() throws InterruptedException {
        TestRunner.startTest("Select Course On Run Report");
        try {

//            wait.until(ExpectedConditions.invisibilityOf(loader));
            itemAnalysisReportByCourse_pf.SelectCourseFromReports();
        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

}
