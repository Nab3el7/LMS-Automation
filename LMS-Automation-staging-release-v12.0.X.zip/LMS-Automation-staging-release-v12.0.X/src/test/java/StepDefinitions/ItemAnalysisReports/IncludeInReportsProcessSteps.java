package StepDefinitions.ItemAnalysisReports;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Classes.AddClass_PF;
import pageFactory.Gradebook.*;
import pageFactory.ItemAnalysisReports.IncludeInReportsProcess_PF;
import pageFactory.StudentsModule.AddNewStudent_PF;

import java.time.Duration;

import static pageFactory.MyContent.AssignAssessment_PF.CategoryFromAssignment;

public class IncludeInReportsProcessSteps {
    WebDriver driver = Configurations.getDriver();

    Helper helper;
    GradeBookStudent_PF gradeBookStudent_pf;
    GradeBookSearchBox_PF gradeBookSearchBox_pf;

    NegativeTestGradeBook_PF negativeTestGradeBook_pf;
    AddNewStudent_PF addNewStudentPf;
    AddClass_PF addClassPf;
    Actions actions;
    PositiveTestCaseGradeBook_PF positiveTestCaseGradeBook_pf;
    ManualGrading_PF manualGrading_pf;

    IncludeInReportsProcess_PF includeInReportsProcess_pf;

    public WebDriverWait wait;
    WebElement loader = driver.findElement(By.xpath("//span[@role='progressbar']"));



    public IncludeInReportsProcessSteps(){
        helper = new Helper();
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
        actions = new Actions(driver);
        gradeBookStudent_pf = new GradeBookStudent_PF(driver);
        gradeBookSearchBox_pf = new GradeBookSearchBox_PF(driver);
        addNewStudentPf = new AddNewStudent_PF(driver);
        addClassPf= new AddClass_PF(driver);
        negativeTestGradeBook_pf= new NegativeTestGradeBook_PF(driver);
        positiveTestCaseGradeBook_pf = new PositiveTestCaseGradeBook_PF(driver);
        manualGrading_pf = new ManualGrading_PF(driver);
        includeInReportsProcess_pf = new IncludeInReportsProcess_PF(driver);
    }

    @And("Click On Unit, Assignment And Assign Specific Assignment Type Vocabulary Quiz For Include In Reports")
    public void SelectUnitAndAssignSpecificAssignmentTypeVQForCorrectAnswers() throws InterruptedException{
        TestRunner.startTest("Click On Unit, Assignment And Assign Specific Assignment Type Vocabulary Quiz For Include In Reports");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            includeInReportsProcess_pf.ReleaseAssignmentTypeVQForIncludeInReportToggle();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
        Thread.sleep(3000);
    }

    @And("Validate that Include In Reports Toggle Off Assignment is not Display in List")
    public void ValidateThatIncludeInReportsToggleOffAssignmentIsNotDisplayInList() throws InterruptedException {
        TestRunner.startTest("Validate that Include In Reports Toggle Off Assignment is not Display in List");
        try {

            includeInReportsProcess_pf.verifyNoDetailFoundInAssignmentTable();
        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Verify Categories from DropDown option For Include In Reports Toggle")
    public void SelectCategoriesFromDropDownOption() throws InterruptedException{
        TestRunner.startTest(" Select Categories from DropDown option ");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            includeInReportsProcess_pf.SelectCategoryFromReportsForIncludeInReportsToggle(CategoryFromAssignment);
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  Exception is found.");
            Assert.fail();
        }
//        Thread.sleep(2000);
    }
}
