package StepDefinitions.AssignmentModule;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.bs.A;
import io.cucumber.java.en.And;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Assignmment.AssignmentModule.AssignmentModuleEdit_PF;
import pageFactory.Assignmment.AssignmentModule.ClassInactive_PF;
import pageFactory.Assignmment.AssignmentModuleAssignNew_PF;
import pageFactory.Assignmment.CorrectAnswerExecutor_PF;
import pageFactory.Classes.AddClass_PF;

import java.time.Duration;

public class AssignmentsModuleEditSteps {
    WebDriver driver = Configurations.getDriver();
    Helper helper;
    AssignmentModuleAssignNew_PF assignmentModuleAssignNew_pf;
    Actions actions;
    AddClass_PF addClass_pf;

    AssignmentModuleEdit_PF assignmentModuleEdit_pf;

    public WebDriverWait wait;
    WebElement loader = driver.findElement(By.xpath("//span[@role='progressbar']"));


    public AssignmentsModuleEditSteps(){
        assignmentModuleAssignNew_pf= new AssignmentModuleAssignNew_PF(driver);
        helper = new Helper();
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
        actions = new Actions(driver);
        addClass_pf = new AddClass_PF(driver);
        assignmentModuleEdit_pf = new AssignmentModuleEdit_PF(driver);
    }

    @And("Validate and Search Assignment In Assignments Module for Edit")
    public void ValidateAndSearchAssignmentInAssignmentsModuleForEdit() throws InterruptedException{
        TestRunner.startTest("Validate and Search Assignment In Assignments Module");
        try {
//            Thread.sleep(3000);
            assignmentModuleEdit_pf.SearchAssignmentByNameInAssignmentModuleForEdit();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }

    @And("Verify search name found in Table in Assignment Module For Edit")
    public void VerifySearchNameFoundInTableInAssignmentModule() throws InterruptedException{
        TestRunner.startTest("Verify search name found in Table in Assignment Module");
        try {
            Thread.sleep(3000);
            assignmentModuleEdit_pf.verifySearchedAssessmentInAssignmentModuleByNameIntoTableForEdit();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }


    @And("Get start and Due date")
    public void GetStartAndDueDate() throws InterruptedException{
        TestRunner.startTest("Get start and Due date");
        try {
//            Thread.sleep(3000);
            assignmentModuleEdit_pf.GetStartAndDueDateOfAssignment();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }

    @And("Validate and Click on edit Icon")
    public void ValidateAndClickOnEditIcon() throws InterruptedException{
        TestRunner.startTest("Validate and Click on edit Icon");
        try {
//            Thread.sleep(3000);
            assignmentModuleEdit_pf.ClickOnEditIconAssignmentModule();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }

    @And("Get Screen Title")
    public void GetScreenTitle() throws InterruptedException{
        TestRunner.startTest("Get Edit Screen Title");
        try {
//            Thread.sleep(3000);
            assignmentModuleEdit_pf.EditScreenTitle();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }

    @And("Edit Assignment Title")
    public void EditAssignmentTitle() throws InterruptedException{
        TestRunner.startTest("Edit Assignment Title");
        try {
            Thread.sleep(3000);
            assignmentModuleEdit_pf.EditAssignmentTitleOnEditScreen();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }

    @And("Uncheck Open to any students Toggle")
    public void UncheckOpenToAnyStudentsToggle() throws InterruptedException{
        TestRunner.startTest("Uncheck Open to any students Toggle");
        try {
            Thread.sleep(3000);
            assignmentModuleEdit_pf.OpenToAnyStudentUncheckCheckbox();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }

    @And("Verify Uncheck And Check Again Open to any students Toggle")
    public void verifyUncheckOpenToAnyStudentsToggle() throws InterruptedException{
        TestRunner.startTest("Verify Uncheck And Check Again Open to any students Toggle");
        try {
            Thread.sleep(3000);
            assignmentModuleEdit_pf.verifyOpenToAnyStudentUncheckToggle();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }

    @And("Edit start date")
    public void EditStartDate() throws InterruptedException{
        TestRunner.startTest("Edit start date");
        try {
            Thread.sleep(3000);
            assignmentModuleEdit_pf.StartDateEdit();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }

    @And("Edit Due Date")
    public void EditDueDate() throws InterruptedException{
        TestRunner.startTest("Edit Due Date");
        try {
            Thread.sleep(3000);
            assignmentModuleEdit_pf.DueDateEdit();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }

    @And("Uncheck Allow Late Submission Checkbox")
    public void EditLateDate() throws InterruptedException {
        TestRunner.startTest("Uncheck Allow Late Submission Checkbox");
        try {
            Thread.sleep(200);
            assignmentModuleEdit_pf.uncheckAllowLateSubmission();
        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found.");
            Assert.fail();
        }
    }

    @And("Check, Validate That Student Listing is Present on Edit Screen")
    public void CheckValidateThatStudentListingIsPresentOnEditScreen() throws InterruptedException {
        TestRunner.startTest("Check, Validate That Student Listing is Present on Edit Screen");

        try {
            assignmentModuleEdit_pf.VerifyStudentListingOnEditScreen();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found.");
            Assert.fail();
        }
    }

    @And("Check, Validate That Student Listing is Present on Edit Screen in Group")
    public void CheckValidateThatStudentListingIsPresentOnEditScreenInGroup() throws InterruptedException {
        TestRunner.startTest("Check, Validate That Student Listing is Present on Edit Screen in Group");

        try {
            assignmentModuleEdit_pf.VerifyStudentListingOnEditScreenInGroup();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found.");
            Assert.fail();
        }
    }

    @And("Click on Save Button to save Edited Information")
    public void ClickOnSaveButtonToSaveEditedInformation() throws InterruptedException{
        TestRunner.startTest("Click on Save Button to save Edited Information");
        try {
//            Thread.sleep(3000);
            assignmentModuleEdit_pf.SaveInfoForEdit();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }

    @And("Scroll to up to validate Information is changed or not")
    public void ScrollToUpToValidateInformationIsChangedOrNot() throws InterruptedException{
        TestRunner.startTest("Scroll to up to validate Information is changed or not");
        try {
//            Thread.sleep(3000);
            assignmentModuleEdit_pf.ScrollToViewAll();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }

    @And("Validate and Search Assignment In Assignments Module for After Edit")
    public void ValidateAndSearchAssignmentInAssignmentsModuleForAfterEdit() throws InterruptedException{
        TestRunner.startTest("Validate and Search Assignment In Assignments Module for After Edit");
        try {
            Thread.sleep(3000);
            assignmentModuleEdit_pf.SearchAssignmetAfterEditWithPreviousTitle();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }
    @And("Validate and Search Assignment In Assignments Module for With Edit Title")
    public void ClearTheSearchBox() throws InterruptedException{

        TestRunner.startTest("Validate and Search Assignment In Assignments Module for With Edit Title");
        try {
//            Thread.sleep(3000);
            assignmentModuleEdit_pf.SearchAssignmentWithEditTitle();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }

    @And("Verify Edit search name found in Table in Assignment Module")
    public void VerifyEditSearchNameFoundInTableInAssignmentModule() throws InterruptedException{
        TestRunner.startTest("Verify Edit search name found in Table in Assignment Module");
        try {
            Thread.sleep(3000);
            assignmentModuleEdit_pf.ValidateEditTitleExist();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }

    @And("Verify Open to Any Student Toggle is Now Disable")
    public void VerifyOpenToAnyStudentToggleIsNowDisable() throws InterruptedException{
        TestRunner.startTest("Verify Open to Any Student Toggle is Now Disable");
        try {
            Thread.sleep(3000);
            assignmentModuleEdit_pf.OpenToAnyStudentOnAssignmentDisable();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }

    @And("Validate that start Date Update")
    public void ValidateThatStartDateUpdate() throws InterruptedException{
        TestRunner.startTest("Validate that start Date Update");
        try {
            Thread.sleep(3000);
            assignmentModuleEdit_pf.VerifyStartDatAlsoUpdateOnAssignment();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }

    @And("Validate That Due Date Update On Assignment Module")
    public void ValidateThatDueDateUpdateOnAssignmentModule() throws InterruptedException{
        TestRunner.startTest("Validate That Due Date Update On Assignment Module");
        try {
            Thread.sleep(3000);
            assignmentModuleEdit_pf.VerifyDueDateAlsoUpdateOnAssignment();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }

    @And("Validate And Edit Start Date For Specific Student")
    public void editStartDateForSpecificStudent() throws InterruptedException{
        TestRunner.startTest("Validate And Edit Start Date For Specific Student");
        try {
            Thread.sleep(3000);
            assignmentModuleEdit_pf.editStartDateSpecificStudent();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }

    @And("Validate And Edit End Date For Specific Student")
    public void editEndDateForSpecificStudent() throws InterruptedException{
        TestRunner.startTest("Validate And Edit End Date For Specific Student");
        try {
            assignmentModuleEdit_pf.editEndDateSpecificStudent();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }

    @And("Validate And Edit Assignment Review Category For Specific Student")
    public void editReviewCategoryForSpecificStudent() throws InterruptedException{
        TestRunner.startTest("Validate And Edit Assignment Review Category For Specific Student");
        try {
            assignmentModuleEdit_pf.editCategorySpecificStudent();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }

    @And("Validate And Click Apply Edit Assignment Button For Specific Student")
    public void clickApplyButtonForSpecificStudentEditInfo() throws InterruptedException{
        TestRunner.startTest("Validate And Click Apply Edit Assignment Button For Specific Student");
        try {
            assignmentModuleEdit_pf.applyEditInfoSpecificStudent();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }


//    GradeBook Verify Edit

    @And("Validate and Search Assignment In GradeBook Module for After Edit")
    public void ValidateAndSearchAssignmentInGradeBookModuleForAfterEdit() throws InterruptedException {
        TestRunner.startTest("Validate and Search Assignment In GradeBook Module for After Edit");

        try {
            assignmentModuleEdit_pf.searchAssignmentInGradeBookAfterEditWithPreviousTitle();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number:  " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found.");
            Assert.fail();
        }
    }


    @And("Validate and Search Assignment In GradeBook Module For Edited Title")
    public void ValidateAndSearchAssignmentInGradeBookModuleForEditedTitle() throws InterruptedException {
        TestRunner.startTest("Validate and Search Assignment In GradeBook Module For Edited Title");

        try {
            assignmentModuleEdit_pf.searchAssignmentInGradeBookAfterEditWithEditedTitle();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found.");
            Assert.fail();
        }
    }
}
