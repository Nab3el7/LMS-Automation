package StepDefinitions.AssignmentModule;

import StepDefinitions.Configurations;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Assignmment.AssignmentModule.EditAssignment_PF;

import java.time.Duration;

public class EditAssignmentSteps extends Configurations {
    WebDriver driver = Configurations.getDriver();
    public WebDriverWait wait;
    EditAssignment_PF editAssignmentPF;

    WebElement loader = driver.findElement(By.xpath("//span[@role='progressbar']"));

    public EditAssignmentSteps() {
        wait = new WebDriverWait(driver, Duration.ofSeconds(120));
        editAssignmentPF = new EditAssignment_PF(driver);
    }

    @And("Check, Validate And Verify Main Grade Toggle Button, Weights And Percentage In Edit Assignment")
    public void VerifyAndEditAssignmentScenarioMainGradeToggleButton() throws InterruptedException{
        TestRunner.startTest("Scenario Main Grade Toggle Verify And Edit Assignment");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            editAssignmentPF.editAssignmentScenarioGradeMainToggleButton();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
        Thread.sleep(3000);
    }

    @And("Check, Validate And Verify Partial Questions Grading, Weights And Percentage In Edit Assignment")
    public void VerifyAndEditAssignmentScenarioPartialQuestionGradeToggleButton() throws InterruptedException{
        TestRunner.startTest("Scenario Partial Question Gradings Verify And Edit Assignment");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            editAssignmentPF.editAssignmentScenarioParticularQuestionsToggleVerification();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
        Thread.sleep(3000);
    }

    @And("Check, Validate And Verify Distribute Weight Evenly, Weights And Percentage In Edit Assignment")
    public void VerifyAndEditAssignmentScenarioDistributeWeightEvenly() throws InterruptedException{
        TestRunner.startTest("Scenario Distribute Weight Evenly Verify And Edit Assignment");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            editAssignmentPF.editAssignmentScenarioDistributeWeightEvenlyVerification();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
        Thread.sleep(3000);
    }

    @And("Check, Validate And Verify Advance Gradings UI Behavior In Edit Assignment")
    public void VerifyAndEditAssignmentScenarioAdvanceGradingsUIBehavior() throws InterruptedException{
        TestRunner.startTest("Scenario Verify Advance Gradings UI Behavior In Edit Assignment");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            editAssignmentPF.verifyToggleButtonBehaviorInEditAssignment();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
        Thread.sleep(3000);
    }
}
