package StepDefinitions.AssignmentModule;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Assignmment.AssignmentModule.ClassInactive_PF;
import pageFactory.Assignmment.AssignmentModuleAssignNew_PF;
import pageFactory.Classes.AddClass_PF;

import java.time.Duration;

public class AssignmentModuleClassInactiveSteps {
    WebDriver driver = Configurations.getDriver();
    Helper helper;
    AssignmentModuleAssignNew_PF assignmentModuleAssignNew_pf;
    Actions actions;
    AddClass_PF addClass_pf;

    ClassInactive_PF classInactive_pf;
    public WebDriverWait wait;
    WebElement loader = driver.findElement(By.xpath("//span[@role='progressbar']"));


    public AssignmentModuleClassInactiveSteps(){
        assignmentModuleAssignNew_pf= new AssignmentModuleAssignNew_PF(driver);
        helper = new Helper();
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
        actions = new Actions(driver);
        classInactive_pf = new ClassInactive_PF(driver);
        addClass_pf = new AddClass_PF(driver);
    }

    @And("Select Active Status for Class")
    public void SelectActiveStatusForClass() throws InterruptedException{
        TestRunner.startTest( "  Select Active Status Dropdown");
        try {
            classInactive_pf.SelectActiveStatus();
        } catch (NoSuchElementException | ElementNotInteractableException | InterruptedException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
            Assert.fail();
        }
    }

    @And("Click Of Classes to Turn Off Display Inactive Toggle")
    public void ClickOnClassesToggleButtonToTurnOff() throws InterruptedException{
        TestRunner.startTest( "  Click Of Classes to Turn Off Display Inactive Toggle");
        try {
            classInactive_pf.DisplayInactiveToggle();
        } catch (NoSuchElementException | ElementNotInteractableException | InterruptedException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
            Assert.fail();
        }
    }

    @And("Select Newly Created Specific Class From List")
    public void SelectNewlyCreatedSpecificClassFromList() throws InterruptedException {
        TestRunner.startTest("Select Newly Created Specific Class From List");

        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));

            // Get the class name from the AddClass_PF
            String newlyCreatedClassName = addClass_pf.getClassName();
//            String newlyCreatedClassName = "Automated Class 824C";
            System.out.println("Newly Created Class Name: " + newlyCreatedClassName);

            // Pass the class name to the method responsible for selecting it
            classInactive_pf.SelectNewlyCreatedClassFromList(newlyCreatedClassName);
        }
        catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found Assignment Module not found");
            Assert.fail();
        }
//        Thread.sleep(2000);
    }

    @And("Validate and Edit Class Information and change it to Inactive Class")
    public void ValidateAndEditClassInformationAndChangeItToInactiveClass() throws InterruptedException{
        TestRunner.startTest( "  Validate and Edit Class Information and change it to Inactive Class");
        try {
            classInactive_pf.ChangeSchoolStatusToInactive();
        } catch (NoSuchElementException | ElementNotInteractableException | InterruptedException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
            Assert.fail();
        }
    }

    @And("Search Inactive Class By Keyword from Search Box")
    public void searchInactiveNewClassByKeyword() throws InterruptedException{
        TestRunner.startTest( "Search The New Class Added");
        try {
            classInactive_pf.searchInactiveClassByName();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }


    @And("Verify Inactive Class is not found in active Class List Assignment Module")
    public void VerifyInactiveClassIsNotFoundActiveClassListAssignmentModule() throws InterruptedException{
        TestRunner.startTest( "Verify Inactive Class is not found in active Class List Assignment Module");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));

            // Get the class name from the AddClass_PF
            String newlyCreatedClassName = addClass_pf.getClassName();
//            String newlyCreatedClassName = "Automated Class 824C";
            System.out.println("Newly Created Class Name: " + newlyCreatedClassName);

            // Pass the class name to the method responsible for selecting it
            classInactive_pf.ValidateInactiveClassIsNotInList(newlyCreatedClassName);
        }
        catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found Assignment Module not found");
            Assert.fail();
        }
//        Thread.sleep(2000);
    }

    @And("Validate Inactive Class is found In inactive classes dropdown")
    public void ValidateInactiveClassIsFoundInInactiveClassesDropdown() throws InterruptedException{
        TestRunner.startTest( "Verify Inactive Class is  found inactive Class dropdown List Assignment Module");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));

            // Get the class name from the AddClass_PF
            String newlyCreatedClassName = addClass_pf.getClassName();
//            String newlyCreatedClassName = "Automated Class 824C";
            System.out.println("Newly Created Class Name: " + newlyCreatedClassName);

            // Pass the class name to the method responsible for selecting it
            classInactive_pf.ValidateInactiveClassIsFoundInInactiveClassesDropdown(newlyCreatedClassName);
        }
        catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found Assignment Module not found");
            Assert.fail();
        }
//        Thread.sleep(2000);
    }

}
