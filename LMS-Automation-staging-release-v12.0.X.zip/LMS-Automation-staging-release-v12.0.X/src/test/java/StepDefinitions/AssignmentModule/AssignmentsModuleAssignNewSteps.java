package StepDefinitions.AssignmentModule;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import io.cucumber.java.sl.In;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Assignmment.AssignmentModuleAssignNew_PF;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.time.Duration;

import static pageFactory.Assignmment.ReleaseAssignment_PF.assignmentTypeFromAssignment;

//import static StepDefinitions.Configurations.driver;

public class AssignmentsModuleAssignNewSteps extends Configurations {
    WebDriver driver = Configurations.getDriver();
    Helper helper;
    AssignmentModuleAssignNew_PF assignmentModuleAssignNew_pf;
    Actions actions;

    public WebDriverWait wait;
    WebElement loader = driver.findElement(By.xpath("//span[@role='progressbar']"));


    public AssignmentsModuleAssignNewSteps(){
        assignmentModuleAssignNew_pf= new AssignmentModuleAssignNew_PF(driver);
        helper = new Helper();
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
        actions = new Actions(driver);
    }


    @And("Verify Side Navbar And Clicked on Assignments Module")
    public void VerifySideNavBarAndClickOnStudentsModule() throws InterruptedException {
        TestRunner.startTest( "Click on Assignments Module");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            assignmentModuleAssignNew_pf.SideNavBarAndClickOnAssignmentsModule();
        }
        catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found Assignment Module not found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Verify Assignments Dashboard")
    public void VerifyAssignmentsDashboard() throws InterruptedException {
        TestRunner.startTest( "Check and verify Assignments Module Dashboard");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            assignmentModuleAssignNew_pf.VerifyAssignmentModuleDashboard();
        }
        catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found Assignment Module Dashboard not Load");
            Assert.fail();
        }
    }

    @And("Click on Assign New Button")
    public void ClickAssignNewButton() throws InterruptedException{
        TestRunner.startTest( "Check and verify Assignments Module Dashboard Assign New Button");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            assignmentModuleAssignNew_pf.ClickOnAssignNewButton();
        }
        catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed :   Exception is found Assignment Module Dashboard  Assign New Button not Found");
            Assert.fail();
        }
    }

    @And("Check, Validate, Select Assignment step-I")
    public void SelectAssignment() throws InterruptedException{
        TestRunner.startTest( "Check and verify Select Assignment Step-1");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            assignmentModuleAssignNew_pf.SelectAssignmentStep();
        }
        catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found Assignment not select on step-1");
            Assert.fail();
        }
    }

    @And("Check, Validate And Click On Next Button For New Assignment")
    public void clickOnNextButton() throws InterruptedException{
        TestRunner.startTest( "CLick on Next Button for New Assessment");
        try {
            assignmentModuleAssignNew_pf.NextButton();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found NextButton is not Visible/Enable");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("check and validate fill Assignment Name")
    public void FillAssignmentName() throws InterruptedException{
        TestRunner.startTest("Fill Info for Assign Assignment");
        try {
            assignmentModuleAssignNew_pf.AssignmentInfo();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found Assignment Info not fill");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("check and validate fill Assignment Name for Assignment From GradeBook")
    public void FillAssignmentNameForAssignmentGradeBook() throws InterruptedException{
        TestRunner.startTest("Fill Info for Assign Assignment from GradeBook");
        try {
            assignmentModuleAssignNew_pf.AssignmentInfoForGradeBookAssignment();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found Assignment Info not fill");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Select Specific Class")
    public void SelectSpecificClass() throws InterruptedException{
        TestRunner.startTest("Select Class for Filter Verification ");
        try {
            assignmentModuleAssignNew_pf.selectSpecificClass();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :  Exception is found Specific class not selected");

            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Click On Show All Filters")
    public void ClickShowAllFilters() throws InterruptedException{
        TestRunner.startTest("Click on Show All Filter ");
        try {
            assignmentModuleAssignNew_pf.ClickShowAllFilters();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found Click on Show All Filter is not Display");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Select Assignment Type")
    public void SelectAssignmentType() throws InterruptedException{
        TestRunner.startTest("Click and Validate Select Assignment Type  ");
        try {
            assignmentModuleAssignNew_pf.SelectAssignmentType();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :  Exception is found Assignment Types not selected.");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Select Assignment Type Filter")
    public void SelectAssignmentTypeFilters() throws InterruptedException{
        TestRunner.startTest("Click and Validate Select Assignment Type  Filter");
        try {
            assignmentModuleAssignNew_pf.SelectAssignmentTypeFilters();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :  Exception is found Assignment Types not selected.");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Search Assignment By Keyword")
    public void SearchAssignmentByKeyword() throws InterruptedException{
        TestRunner.startTest("Search the Newly Created Assignment");
        try {
            assignmentModuleAssignNew_pf.SearchAssignmentByName();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :  Exception is found Newly Created Assignment not found.");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Verify The Assignments Table")
    public void VerifyTheAssignmentByKeyword() throws InterruptedException{
        TestRunner.startTest("Verify The New Assignment Added");
        try {
            assignmentModuleAssignNew_pf.verifyAssignments();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :  Exception is found. New Assignment not found in table");
            Assert.fail();
        }
    }

    @And("Verify search name found in Table")
    public void VerifySearchNameTable() {
        TestRunner.startTest("Verify The New Assessment Added");
        try {
            assignmentModuleAssignNew_pf.verifySearchedAssessmentByNameIntoTable();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :  Exception is found. New Created assessment not added");
            Assert.fail();
        }
    }

    @And("Check, Validate And Click On Edit Assignment Button")
    public void ClickOnAssignmentOpenButton() {
        TestRunner.startTest("Check, Validate And Click On Edit Assignment Button");
        System.out.println("I'm in to click on Assignment Edit Button");
        try {
            assignmentModuleAssignNew_pf.clickOnEditAssignmentButton();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found.");
            Assert.fail();
        }
    }

    @And("click Delete Button")
    public void ClickOnQuestionDeleteButton() throws InterruptedException{
        TestRunner.startTest("Check and validate to Click on Delete button");
        try {
            assignmentModuleAssignNew_pf.clickDeleteButton();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found. Delete button is Disable");
            Assert.fail();
        }
    }

    @And("Verify Delete Assignment Prompt")
    public void VerifyDeleteAssignmentPrompt() throws InterruptedException{
        TestRunner.startTest("Check and validate Delete Assignment Prompt");
        try {
            assignmentModuleAssignNew_pf.DeleteAssignmentPrompt();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found. Delete Assignment Prompt not found");
            Assert.fail();
        }
    }

    @And("Verify Toast Message of Delete Assessment")
    public void VerifyToastMessageDeleteAssessment(){
        TestRunner.startTest("Verify Display of Toast Message");
        try {
            assignmentModuleAssignNew_pf.verifyToastMessage();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found. Something Went Wrong");
            Assert.fail();
        }

    }

    @And("Verify In Assignments Module Deleted Assessment Not Shows")
    public void VerifyDeletedAssessmentNotShows() throws InterruptedException{
        TestRunner.startTest("Verify Deleted Assessment Not Shows");
        try {
            assignmentModuleAssignNew_pf.showsAssessmentIntoTable();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found. Delete Assignment Also shows in table");
            Assert.fail();
        }
    }

    @And("Verify data is Display according to Assignment Type")
    public void VerifyDataIsDisplayAccordingToAssignmentType() throws InterruptedException{
        TestRunner.startTest("Verify data is Display according to Assignment Type");
        try {
            assignmentModuleAssignNew_pf.DataAccordingToAssignmentTypeFilter();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found. ");
            Assert.fail();
        }
    }

    @And("Verify All DSB Is Present In Table")
    public void VerifyAllDSBIsPresentInTable() throws InterruptedException{
        TestRunner.startTest("Verify All DSB Is Present In Table");
        try {
            assignmentModuleAssignNew_pf.VerifyAllDSBIsPresentInTable(assignmentTypeFromAssignment);
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found. ");
            Assert.fail();
        }
    }

    @And("Verify All Custom Type Assessment Is Present In Table")
    public void VerifyAllCustomTypeAssessmentIsPresentInTable() throws InterruptedException{
        TestRunner.startTest("Verify All Custom Type Assessment Is Present In Table");
        try {
            assignmentModuleAssignNew_pf.VerifyAllCustomTypeAssessmentIsPresentInTable(assignmentTypeFromAssignment);
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }
//    assignment Status module
    @And("Select Assignments Module  Status Filter On Assignments")
    public void SelectAssignmentsModuleStatusFilterOnAssignments() throws InterruptedException{
        TestRunner.startTest("Select Assignments Module  Status Filter On Assignments");
        try {
            assignmentModuleAssignNew_pf.filtersAssignmentsByStatus();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }

    @And("Click On Dashboard and refresh")
    public void ClickOnDashboardAndRefresh() throws InterruptedException{
        TestRunner.startTest("Click On Dashboard and refresh");
        try {
            assignmentModuleAssignNew_pf.ClickOnDashboard();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }

    @And("Select Filter Not Started for The assignment that is release but not started")
    public void SelectFilterNotStartedForTheAssignmentThatIsReleaseButNotStarted() throws InterruptedException{
        TestRunner.startTest("Select Filter Not Started for The assignment that is release but not started");
        try {
            assignmentModuleAssignNew_pf.NotStartedFilter();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }

    @And("Validate and Check that Assignment is not Present in other Assignment status")
    public void ValidateAndCheckThatAssignmentIsNotPresentInOtherAssignmentStatus() throws InterruptedException{
        TestRunner.startTest("Validate and Check that Assignment is not Present in other Assignment status");
        try {
//            Thread.sleep(3000);
            assignmentModuleAssignNew_pf.VerifyThatAssignmentIsNotPresentInOtherStatus();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }

    @And("Verify After Resume Assignment is in Started Status")
    public void VerifyAfterResumeAssignmentIsInStartedStatus() throws InterruptedException{
        TestRunner.startTest("Verify After Resume Assignment is in Started Status");
        try {
//            Thread.sleep(3000);
            assignmentModuleAssignNew_pf.VerifyResumeAssignmentIsInStartedStatus();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }

    @And("Verify Assignment is not in Other Status After Resume")
    public void VerifyAssignmentIsNotInOtherStatusAfterResume() throws InterruptedException{
        TestRunner.startTest("Verify Assignment is not in Other Status After Resume");
        try {
//            Thread.sleep(3000);
            assignmentModuleAssignNew_pf.ResumeAssignmentIsNotInOtherStatusAssignment();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }

    @And("Validate After Assignment is complete is in Completed Status")
    public void ValidateAfterAssignmentIsCompleteIsInCompletedStatus() throws InterruptedException{
        TestRunner.startTest("Validate After Assignment is complete is in Completed Status");
        try {
//            Thread.sleep(3000);
            assignmentModuleAssignNew_pf.VerifyCompletedAssignmentStatus();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }

    @And("Validate Assignment is not under other Status After Completed")
    public void ValidateAssignmentIsNotInStatusAfterCompleted() throws InterruptedException{
        TestRunner.startTest("Validate Assignment is not under other Status After Completed");
        try {
//            Thread.sleep(3000);
            assignmentModuleAssignNew_pf.ValidateCompletedAssignmentIsNotInOtherStatusOfAssignment();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }
    @And("Validate Assignment that Needs Grading in NeedsGrading Status")
    public void ValidateAssignmentThatNeedsGradingInNeedsGradingStatus() throws InterruptedException{
        TestRunner.startTest("Validate Assignment that Needs Grading in NeedsGrading Status");
        try {
//            Thread.sleep(3000);
            assignmentModuleAssignNew_pf.VerifyNeedsGradingAssignmentStatus();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }

    @And("Validate Needs Grading Assignment is not In other Status")
    public void ValidateNeedsGradingAssignmentIsNotInOtherStatus() throws InterruptedException{
        TestRunner.startTest("Validate Needs Grading Assignment is not In other Status");
        try {
//            Thread.sleep(3000);
            assignmentModuleAssignNew_pf.ValidateNeedsGradingAssignmentInOtherStatus();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }

    @And("Verify Future Assignment In Future Status")
    public void VerifyFutureAssignmentInFutureStatus() throws InterruptedException{
        TestRunner.startTest("Verify Future Assignment In Future Status");
        try {
//            Thread.sleep(3000);
            assignmentModuleAssignNew_pf.ValidateAssignmentForFutureStatus();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }

    @And("Validate Future Status Assignment in other Status")
    public void ValidateFutureStatusAssignmentInOtherStatus() throws InterruptedException{
        TestRunner.startTest("Validate Future Status Assignment in other Status");
        try {
//            Thread.sleep(3000);
            assignmentModuleAssignNew_pf.ValidateFutureStatusAssignmentInOthStatus();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }

    @And("Select Title from Sort By filter")
    public void SelectTitleFromSortByFilter() throws InterruptedException{
        TestRunner.startTest("Select Title from Sort By filter");
        try {
            Thread.sleep(3000);
            assignmentModuleAssignNew_pf.SelectStatusByTitle();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }

    @And("Select DueDate From Sort By Filter")
    public void SelectDueDateFromSortByFilter() throws InterruptedException{
        TestRunner.startTest("Select DueDate From Sort By Filter");
        try {
            Thread.sleep(3000);
            assignmentModuleAssignNew_pf.SelectStatusByDueDate();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }

    @And("Select StartDate From Sort By Filter")
    public void SelectStartDateFromSortByFilter() throws InterruptedException{
        TestRunner.startTest("Select StartDate From Sort By Filter");
        try {
            Thread.sleep(3000);
            assignmentModuleAssignNew_pf.SelectStatusByStartDate();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }
//    Open Button
    @And("Validate and Search Assignment In Assignments Module")
    public void ValidateAndSearchAssignmentInAssignmentsModule() throws InterruptedException{
        TestRunner.startTest("Validate and Search Assignment In Assignments Module");
        try {
            Thread.sleep(3000);
            assignmentModuleAssignNew_pf.SearchAssignmentByNameInAssignmentModule();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }

    @And("Verify search name found in Table in Assignment Module")
    public void VerifySearchNameFoundInTableInAssignmentModule() throws InterruptedException{
        TestRunner.startTest("Verify search name found in Table in Assignment Module");
        try {
            Thread.sleep(3000);
            assignmentModuleAssignNew_pf.verifySearchedAssessmentInAssignmentModuleByNameIntoTable();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }

    @And("Check, and validate Assignment Open Button")
    public void CheckAndValidateAssignmentOpenButton() throws InterruptedException{
        TestRunner.startTest("Check, and validate Assignment Open Button");
        try {
            Thread.sleep(3000);
            assignmentModuleAssignNew_pf.ValidateOpenButtonDisplay();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }

    @And("Check, Validate Summary Button for Assignment")
    public void CheckValidateSummaryButtonForAssignment() throws InterruptedException{
        TestRunner.startTest("Check, Validate Summary Button for Assignment");
        try {
            Thread.sleep(3000);
            assignmentModuleAssignNew_pf.ValidateSummaryButtonDisplay();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }
    @And("Validate Summary Button Correctly Redirect to Summary page")
    public void ValidateSummaryButtonCorrectlyRedirectToSummaryPage() throws InterruptedException{
        TestRunner.startTest("Validate Summary Button Correctly Redirect to Summary page");
        try {
            Thread.sleep(3000);
            assignmentModuleAssignNew_pf.ValidateSummaryButtonRedirectToSummaryPage();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }

    @And("Check, Validate By Student Button for Assignment")
    public void CheckValidateSelectedButtonForAssignment() throws InterruptedException{
        TestRunner.startTest("Check, Validate By Student Button for Assignment");
        try {
            Thread.sleep(3000);
            assignmentModuleAssignNew_pf.ValidateSelectedButtonDisplay();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }

    }

    @And("Validate By Student Button Correctly Redirect to Selected page")
    public void ValidateSelectedButtonCorrectlyRedirectToSelectedPage() throws InterruptedException{
        TestRunner.startTest("Validate By Student Button Correctly Redirect to Selected page");
        try {
            Thread.sleep(3000);
            assignmentModuleAssignNew_pf.ValidateSelectedButtonRedirectToSelectedPage();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }

    @And("Check, Validate Print Button for Assignment")
    public void CheckValidatePrintButtonForAssignment() throws InterruptedException{
        TestRunner.startTest("Check, Validate Print Button for Assignment");
        try {
            Thread.sleep(3000);
            assignmentModuleAssignNew_pf.ValidatePrintButtonDisplay();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }

    }
    @And("Check, Validate Print Loading")
    public void CheckValidatePrintLoading() throws InterruptedException, AWTException {
        TestRunner.startTest("Check, Validate Print Loading");
        try {
            Thread.sleep(3000);
            assignmentModuleAssignNew_pf.ValidatePrintLoading();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
        Thread.sleep(2000);
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.print = function(){};");
        driver.navigate().refresh();

        Thread.sleep(2000);
    }

    @And("Check, Validate Assigned To Button for Assignment")
    public void CheckValidateAssignedToButtonForAssignment() throws InterruptedException{
        TestRunner.startTest("Check, Validate Assigned To Button for Assignment");
        try {
            Thread.sleep(3000);
            assignmentModuleAssignNew_pf.ValidateAssignedToButtonDisplay();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }

    @And("Validate Assigned To Button Correctly Redirect to GradeBook Dashboard")
    public void ValidateAssignedToButtonCorrectlyRedirectToGradeBookDashboard() throws InterruptedException{
        TestRunner.startTest("Validate Assigned To Button Correctly Redirect to GradeBook Dashboard");
        try {
            Thread.sleep(3000);
            assignmentModuleAssignNew_pf.ValidateAssignedToButtonRedirectToGradeBookDashboard();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }

    @And("Check, Validate Grade Button for Assignment")
    public void CheckValidateGradeButtonForAssignment() throws InterruptedException{
        TestRunner.startTest("Check, Validate Grade Button for Assignment");
        try {
            Thread.sleep(3000);
            assignmentModuleAssignNew_pf.ValidateGradeButtonDisplay();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }

    @And("Validate Grade Button Correctly Redirect to Grading Tab")
    public void ValidateGradeButtonCorrectlyRedirectToGradeTab() throws InterruptedException{
        TestRunner.startTest("Validate Grade Button Correctly Redirect to Grade Tab");
        try {
            Thread.sleep(3000);
            assignmentModuleAssignNew_pf.ValidateGradeButtonRedirectToGradingTab();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }


    @And("Check, Validate And Click On Assign New Button In Assignment Module")
    public void CheckValidateAndClickOnAssignNewButtonInAssignmentModule() throws InterruptedException {
        TestRunner.startTest("Check, Validate And Click On Assign New Button In Assignment Module");
        try {
            Thread.sleep(3000);
            assignmentModuleAssignNew_pf.clickAssignNewButton();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found.");
        }
    }

    @And("Refresh the page")
    public void RefreshThePage() throws InterruptedException{
        TestRunner.startTest("Refresh the page");

        try {
            assignmentModuleAssignNew_pf.refresh_Page();

        }catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }

    @And("Select Custom All Statuses Filter For Assignments")
    public void SelectCustomAllStatusesFilterForAssignments() throws InterruptedException {
        TestRunner.startTest("Select Custom All Statuses Filter For Assignments");
        try {
            assignmentModuleAssignNew_pf.filterAssignmentsByStatuses();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found.");
            Assert.fail();
        }
        driver.navigate().refresh();
    }


    @And("Select Type All Filter For Assignments")
    public void SelectTypeAllFilterForAssignments() throws InterruptedException {
        TestRunner.startTest("Select Type All Filter For Assignments");
        try {
            assignmentModuleAssignNew_pf.filterAssignmentByType();

        }catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found.");
            Assert.fail();
        }
        driver.navigate().refresh();
    }

    @And("Select Course On Assign New")
    public void SelectCourseOnAssignNew() throws InterruptedException {
        TestRunner.startTest("Select Course On Assign New");
        try {
            assignmentModuleAssignNew_pf.selected_Course_Assign_New();
        }catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found.");
            Assert.fail();
        }
        Actions actions = new Actions(driver);
        actions.sendKeys(Keys.ESCAPE).perform();
    }


    @And("Get Random Assignment Name From Table")
    public void GetRandomAssignmentNameFromTable() throws InterruptedException {
        TestRunner.startTest("Get Random Assignment Name From Table");
        try {
            assignmentModuleAssignNew_pf.getRandomAssignmentName();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found.");
            Assert.fail();
        }
    }

    @And("Check, Validate Search And Assignment In Search and Assignment In Table Match")
    public void SearchAssignmentNameInSearchBox() throws InterruptedException {
        TestRunner.startTest("Check, Validate Search And Assignment In Search and Assignment In Table Match");
        try {
            assignmentModuleAssignNew_pf.searchAssignmentAndValidate();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found.");
            Assert.fail();
        }
    }

    @And("Refreshing page")
    public void RefreshingPage() throws InterruptedException {
        TestRunner.startTest("Refreshing page");
        try {
            assignmentModuleAssignNew_pf.refreshingPageForReloadData();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found.");
            Assert.fail();
        }

    }

    @And("Check, Validate And Select New Assignment Step-I In Assign")
    public void SelectAssignmentFromAssignScreen(){
        TestRunner.startTest("Check and verify Select Assignment Assign-1");

        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            assignmentModuleAssignNew_pf.SelectAssignmentInShowAllTabAssignScreen();
        }
        catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found Assignment not select on step-1");

            Assert.fail();
        }
    }

    @And("Check, Validate And Click On Next Button From Assign Screen")
    public void clickOnNextButtonAssignScreen() throws InterruptedException{
        TestRunner.startTest("Check, Validate And Click On Next Button From Assign Screen");
        try {
            assignmentModuleAssignNew_pf.ClickOnNextButtonAssignScreen();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found NextButton is not Visible/Enable");

            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Check and validate fill Assignment Name for Assignment From Assign")
    public void FillAssignmentNameForAssignmentFromAssign() throws InterruptedException{
        TestRunner.startTest("Fill Info for Assign Assignment from Assign");
        try {
            assignmentModuleAssignNew_pf.AssignmentInfo();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found Assignment Info not fill");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Validate and Click on My Assessment Section")
    public void ValidateAndClickOnMyAssessmentSection() throws InterruptedException {
        TestRunner.startTest("Validate and Click on My Assessment Section");

        try {
            assignmentModuleAssignNew_pf.clickMyAssessmentSection();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Check, Validate By Question Button for Assignment")
    public void CheckValidateByQuestionButtonForAssignment() throws InterruptedException{
        TestRunner.startTest("Check, Validate By Question Button for Assignment");
        try {
            Thread.sleep(3000);
            assignmentModuleAssignNew_pf.ValidateSelectedButtonDisplay();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }

    }

    @And("Validate By Question Button Correctly Redirect to By Question")
    public void ValidateByQuestionButtonCorrectlyRedirectToByQuestionPage() throws InterruptedException{
        TestRunner.startTest("Validate By Question Button Correctly Redirect to By Question page");
        try {
            Thread.sleep(3000);
            assignmentModuleAssignNew_pf.ValidateByQuestionButtonRedirectToByQuestionPage();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }
}
