package StepDefinitions;

import APIAutomation.Teacher.Announcements.GetNewPage;
import APIAutomation.Teacher.Announcements.POST.POSTMarkAllAsReadAPI;
import APIAutomation.Teacher.Assignments.*;
import APIAutomation.Teacher.Assignments.POST.POSTAssignmentReleaseAPI;
import APIAutomation.Teacher.Assignments.POST.POSTAssignmentSaveUserUsageAPI;
import APIAutomation.Teacher.Dashboard.*;
import APIAutomation.Teacher.GradeBook.*;
import APIAutomation.Teacher.MyContent.*;
import APIAutomation.Teacher.MyContent.GetMyCoursesDropdownAPI;
import APIAutomation.Teacher.MyContent.POST.POSTAssessmentInformationAPI;

import APIAutomation.Teacher.Reports.*;
import APIAutomation.Teacher.Logout.POSTLogoutSaveUserUsageAPI;
import APIAutomation.POST.POSTSaveUserLoginAPI;
import APIAutomation.POST.LoginAPI;
import APIAutomation.Teacher.GradeBook.POST.POSTGradeBookSaveUserUsageAPI;
import APIAutomation.Teacher.MyContent.POST.POSTAssignmentQuestions;
import APIAutomation.Teacher.MyContent.PUT.PUTAssessmentStatus;
import APIAutomation.Teacher.Staff.GetStaffAPI;
import APIAutomation.Teacher.Staff.GetStaffDashboardFilters;
import APIAutomation.Teacher.Staff.GetStaffModuleDistrictAPI;
import APIAutomation.Teacher.Staff.GetStaffUserUsageAPI;
import APIAutomation.Teacher.Staff.POST.POSTStaffSaveUserUsage;
import APIAutomation.Students.*;
import APIAutomation.Students.POST.POSTStudentSaveUserUsageAPI;
import APIAutomation.TestApi;
import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class APIAutomationSteps extends Configurations {
    WebDriver driver = Configurations.getDriver();

    Helper helper;
    LoginAPI loginAPI;
    GetStandardPackageAPI getStandardPackageAPI;
    GetMyCoursesDropdownAPI getMyCoursesDropdownAPI;
    GetContentCountAPI getContentCountAPI;
    GetAssessmentType getAssessmentType;
    GetQuestionLookUpCountAPI getQuestionLookUpCountAPI;
    POSTAssessmentInformationAPI postAssessmentInformationAPI;
    GetAssessmentInformation getAssessmentInformationAPI;
    GetContentInformationByCourseIdAPI getContentInformationByCourseIdAPI;
    GetQuestionLookUpByAccess getQuestionLookUpByAccess;
    POSTAssignmentQuestions postAssignmentQuestionsAPI;
    PUTAssessmentStatus putAssessmentStatusAPI;
    GetMyCourseWidgetAPI getMyCourseWidgetAPI;
    GetUserModuleAPI getUserModuleAPI;
    GetUserProfileAPI getUserProfileAPI;
    POSTSaveUserLoginAPI getSaveUserLoginAPI;
    GetStudentPerfomanceAPI getStudentPerfomanceAPI;
    GetMyStudentsWidgetAPI getMyStudentsWidgetAPI;
    GetUserDashboardAPI getUserDashboardAPI;
    GetClassesDropdownAPI getClassesDropdownAPI;
    GetSchoolsAPI getSchoolsAPI;
    GetCalendarAPI getCalendarAPI;
    GetSortingOptionAPI getSortingOptionAPI;
    GetClassesDropdownAPIGradeBoook getClassesDropdownAPIGradeBoook;
    GetDistrictAPI getDistrictAPI;
    GetCategoryDetails getCategoryDetails;
    GetStudentClassProgress getStudentClassProgress;
    GetStudentByClassId getStudentByClassId;
    GetAllStudentProgressAPI getAllStudentProgressAPI;
    GetAssignmentType getAssignmentType;
    GetAssignmentStatusOptionsAPI getAssignmentStatusOptionsAPI;
    GetClassAssignmentsAPI getClassAssignmentsAPI;
    GetReviewPermissionListingAPI getReviewPermissionListingAPI;
    GetCategoryAPI getCategoryAPI;
    GetStudentsByClassIdsAPI getStudentsByClassIdsAPI;
    GetByUserIdAPI getByUserIdAPI;
    GetQuestionsAPI getQuestionsAPI;
    GetCountAPI getCountAPI;
    POSTGradeBookSaveUserUsageAPI postGradeBookSaveUserUsageAPI;
    TestApi testApi;
    POSTAssignmentSaveUserUsageAPI postAssignmentSaveUserUsageAPI;
    POSTAssignmentReleaseAPI postAssignmentReleaseAPI;
    GetStudentGradeLevelAPI getStudentGradeLevelAPI;
    GetSchoolYearDropDownAPI getSchoolYearDropDownAPI;
    GetUserProfileLanguagesAPI getUserProfileLanguagesAPI;
    GetStudentAPI getStudentAPI;
    POSTStudentSaveUserUsageAPI postStudentSaveUserUsageAPI;
    GetGradeLevelListingAPI getGradeLevelListingAPI;
    GetStudentClassesDropdownAPI getStudentClassesDropdownAPI;
    GetStaffAPI getStaffAPI;
    GetStaffDashboardFilters getStaffDashboardFilters;
    GetStaffUserUsageAPI getStaffUserUsageAPI;
    GetStaffModuleDistrictAPI getStaffModuleDistrictAPI;
    POSTStaffSaveUserUsage postStaffSaveUserUsage;
    POSTLogoutSaveUserUsageAPI postLogoutSaveUserUsageAPI;
    GetNewPage getNewPage;
    POSTMarkAllAsReadAPI postMarkAllAsReadAPI;

    GetReportsContentStandardsByIdAPI getReportsContentStandardsByIdAPI;
    GetReportsStudentPerformanceAPI getReportsStudentPerformanceAPI;
    GetReportsStandardOverviewAPI getReportsStandardOverviewAPI;
    GetReportsClassStudentsByIdAPI getReportsClassStudentsByIdAPI;
    GetReportsClassesDropdownAPI getReportsClassesDropdownAPI;
    GetReportsMasteryStandardsAPI getReportsMasteryStandardsAPI;
    GetReportsMasteryReportAPI getReportsMasteryReportAPI;
    GetReportCategoriesAPI getReportCategoriesAPI;
    GetReportsAssignmentItemsAPI getReportsAssignmentItemsAPI;

    String classID = "07E01DF08CCE4F048C824B0FAD333E23";
    String gradeLevelID = "32";
    String myCourseClassID= "-1";
    String studentPerformanceClassID= "-1";
    String myStudentWidgetClassID ="-1";
    String mySchoolID = "100";
    String calendarClassID= "-1";
    String gradeBookClassID= "7e934242-0081-4328-9ae6-a4a51c7cb18f";
    String districtId = "100";
    String orgId = "101";
    boolean printingBtn = false;
    String studentStatus = "All";
    String classStatus = "All";
    String viewBtn = "percentage";
    int sortBy = 1;
    boolean isDecimal = false;
    boolean refresh = false;
    String assignmentTypeFilter = "";
    String teacherId = "";
    String search = "";
    String assignmentFilter = "";
    String assignmentPage = "0";
    String assignmentSize = "50";
    String userId= "fc7b7700-bb6b-4bf9-baa7-7505aa00a009";
    String questionID= "AP_62191025EF444B0D9AA8B01D5E993EA8";
    String contentId = "07E01DF08CCE4F048C824B0FAD333E23";
    String page = "1";
    String searchFilter = "";
    String assessTypeFilter = "";
    String standardFilter = "";
    String size = "20";
    String category = "assessments";
    String assessmentTab = "showAll";
    String countType = "all";
    String staffRoleId= "";
    String staffSchoolId= null;
    String staffStatusId= "";
    String staffFilterType = "Today";
    String createdAssessmentID = "f6c49b49-3473-4f2c-8eb5-61dcd9707787";
    String studentTeacherId= "fc7b7700-bb6b-4bf9-baa7-7505aa00a009";
    String gradeId= null;
    String[] readStatuses = {"Unread", "Read", "Archive"};
    String[] announcementTypes = {"All", "Archive"};
    String[] questionsTypeFilter = {"inline-choice-spelling-interaction", "inline-choice-text-interaction", "graphic-gap-match-interaction", "match-dragdrop-interaction", "extended-text-interaction", "gap-match-interaction", "inline-choice-select-interaction", "match-interaction", "order-interaction", "choice-interaction", "choice-interaction-single"};


    String assessmentID = "7C8F34FFA1C54846A14E8EF2C1BB537D";
    String reportId= "7e934242-0081-4328-9ae6-a4a51c7cb18f";
    String reportStandardId = "-1";
    boolean isGradeRequired= true;
    boolean reportInProgress = false;
    String reportUserId= "-1";



    DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    String calendarStartDate = LocalDate.now().format(dateFormatter);
    String calendarEndDate = LocalDate.now().format(dateFormatter);


    public APIAutomationSteps() {
        helper = new Helper();
        loginAPI = new LoginAPI(driver);
        getStandardPackageAPI = new GetStandardPackageAPI(driver);
        getMyCoursesDropdownAPI = new GetMyCoursesDropdownAPI(driver);
        getContentInformationByCourseIdAPI = new GetContentInformationByCourseIdAPI(driver);
        getQuestionLookUpByAccess = new GetQuestionLookUpByAccess(driver);
        postAssignmentQuestionsAPI = new POSTAssignmentQuestions(driver);
        putAssessmentStatusAPI = new PUTAssessmentStatus(driver);
        getContentCountAPI = new GetContentCountAPI(driver);
        getAssessmentType = new GetAssessmentType(driver);
        getQuestionLookUpCountAPI = new GetQuestionLookUpCountAPI(driver);
        postAssessmentInformationAPI = new POSTAssessmentInformationAPI(driver);
        getAssessmentInformationAPI = new GetAssessmentInformation(driver);
        getMyCourseWidgetAPI = new GetMyCourseWidgetAPI(driver);
        getUserModuleAPI = new GetUserModuleAPI(driver);
        getUserProfileAPI = new GetUserProfileAPI(driver);
        getSaveUserLoginAPI = new POSTSaveUserLoginAPI(driver);
        getStudentPerfomanceAPI = new GetStudentPerfomanceAPI(driver);
        getMyStudentsWidgetAPI = new GetMyStudentsWidgetAPI(driver);
        getUserDashboardAPI = new GetUserDashboardAPI(driver);
        getClassesDropdownAPI =  new GetClassesDropdownAPI(driver);
        getSchoolsAPI = new GetSchoolsAPI(driver);
        getCalendarAPI= new GetCalendarAPI(driver);
        getSortingOptionAPI = new GetSortingOptionAPI(driver);
        getClassesDropdownAPIGradeBoook = new GetClassesDropdownAPIGradeBoook(driver);
        getDistrictAPI = new GetDistrictAPI(driver);
        getCategoryDetails= new GetCategoryDetails(driver);
        getStudentClassProgress = new GetStudentClassProgress(driver);
        getStudentByClassId = new GetStudentByClassId(driver);
        getAllStudentProgressAPI = new GetAllStudentProgressAPI(driver);
        postGradeBookSaveUserUsageAPI = new POSTGradeBookSaveUserUsageAPI(driver);
        testApi = new TestApi(driver);
        getAssignmentType = new GetAssignmentType(driver);
        getAssignmentStatusOptionsAPI = new GetAssignmentStatusOptionsAPI(driver);
        getClassAssignmentsAPI = new GetClassAssignmentsAPI(driver);
        getReviewPermissionListingAPI = new GetReviewPermissionListingAPI(driver);
        getCategoryAPI = new GetCategoryAPI(driver);
        getStudentsByClassIdsAPI = new GetStudentsByClassIdsAPI(driver);
        getByUserIdAPI = new GetByUserIdAPI(driver);
        getQuestionsAPI = new GetQuestionsAPI(driver);
        getCountAPI= new GetCountAPI(driver);
        postAssignmentSaveUserUsageAPI= new POSTAssignmentSaveUserUsageAPI(driver);
        postAssignmentReleaseAPI = new POSTAssignmentReleaseAPI(driver);
        getStudentGradeLevelAPI= new GetStudentGradeLevelAPI(driver);
        getSchoolYearDropDownAPI = new GetSchoolYearDropDownAPI(driver);
        getUserProfileLanguagesAPI= new GetUserProfileLanguagesAPI(driver);
        getStudentAPI = new GetStudentAPI(driver);
        postStudentSaveUserUsageAPI= new POSTStudentSaveUserUsageAPI(driver);
        getGradeLevelListingAPI= new GetGradeLevelListingAPI(driver);
        getStudentClassesDropdownAPI= new GetStudentClassesDropdownAPI(driver);
        getStaffAPI= new GetStaffAPI(driver);
        getStaffDashboardFilters = new GetStaffDashboardFilters(driver);
        getStaffUserUsageAPI = new GetStaffUserUsageAPI(driver);
        getStaffModuleDistrictAPI = new GetStaffModuleDistrictAPI(driver);
        postStaffSaveUserUsage = new POSTStaffSaveUserUsage(driver);
        postLogoutSaveUserUsageAPI = new POSTLogoutSaveUserUsageAPI(driver);
        // reports Module
        getReportsContentStandardsByIdAPI = new GetReportsContentStandardsByIdAPI(driver);
        getReportsStudentPerformanceAPI = new GetReportsStudentPerformanceAPI(driver);
        getReportsStandardOverviewAPI = new GetReportsStandardOverviewAPI(driver);
        getReportsClassStudentsByIdAPI = new GetReportsClassStudentsByIdAPI(driver);
        getReportsClassesDropdownAPI = new GetReportsClassesDropdownAPI(driver);
        getReportsMasteryStandardsAPI = new GetReportsMasteryStandardsAPI(driver);
        getReportsMasteryReportAPI = new GetReportsMasteryReportAPI(driver);
        getReportCategoriesAPI = new GetReportCategoriesAPI(driver);
        getReportsAssignmentItemsAPI = new GetReportsAssignmentItemsAPI(driver);
        getNewPage = new GetNewPage(driver);
        postMarkAllAsReadAPI = new POSTMarkAllAsReadAPI(driver);

    }

    @And("POST Teacher Login API")
    public void TeacherLoginForAccessToken() {
        TestRunner.startTest("Teacher Login API With CSV File");
        TestRunner.startTest("I'm in to call the teacher login api");
        try {
            loginAPI.LoginWithCsvData();
            TestRunner.getTest().log(Status.PASS,"Test Case Passed    :   Teacher is login through api successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("GET Dashboard UserModule API")
    public void DashboardUserModuleAPI() {
        TestRunner.startTest("Dashboard UserModule API");
        TestRunner.startTest("I'm in to call User Module API ");
        try {
            getUserModuleAPI.getUserModuleAPIConcurrently();
            TestRunner.getTest().log(Status.PASS,"Test Case Passed    :   API run successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("GET Dashboard UserProfile API")
    public void DashboardUserProfileAPI() {
        TestRunner.startTest("I'm in to call User Profile API ");
        try {
            getUserProfileAPI.getUserProfileAPIConcurrently();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed     :   API run successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("POST Dashboard SaveUserLogin API")
    public void DashboardSaveUserLoginAPI() {
        TestRunner.startTest("I'm in to call Save User Login API ");
        try {
            getSaveUserLoginAPI.getSaveUserLoginAPIConcurrently();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed     :   API run successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("GET Dashboard StudentPerformanceWidget API")
    public void studentPerformanceGetStudentPerformancePackage() {
        TestRunner.startTest("I'm in to call studentPerformance Get studentPerformance Package API ");
        try {
            getStudentPerfomanceAPI.getStudentPerfomanceAPIConcurrently(studentPerformanceClassID);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed     :   API run successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("GET Dashboard MyStudentWidget API")
    public void myStudentWidgetGetMyStudentWidgetPackage() {
        TestRunner.startTest("I'm in to call StudentWidget Get StudentWidget Package API ");
        try {
            getMyStudentsWidgetAPI.getMyStudentWidgetAPIConcurrently(myStudentWidgetClassID);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed     :   API run successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("GET Dashboard MyCourseWidget API")
    public void MyCourseWidgetGetStandardPackage(){
        TestRunner.startTest("I'm in to call MyCourseWidget Get MyCourseWidget Package API ");
        try {
            getMyCourseWidgetAPI.getMyCourseWidgetAPIConcurrently(myCourseClassID);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed     :   API run successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("GET Dashboard UserDashboard API")
    public void userDashboardGetUserDashboardPackage() {
        TestRunner.startTest("I'm in to call User Dashboard Get User Dashboard Package API ");
        try {
            getUserDashboardAPI.getUserdashboardAPIConcurrently();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed     :   API run successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("GET Dashboard ClassesDropdown API")
    public void ClassesDropdowndGetClassesDropdownPackage() throws InterruptedException, IOException, NoSuchAlgorithmException, KeyManagementException {
        TestRunner.startTest("I'm in to call Classes Dropdown Get Classes DropdownPackage API ");
        try {
            getClassesDropdownAPI.getClassesDropdownAPIConcurrently();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed     :   API run successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("GET Dashboard Schools API")
    public void getSchoolsAPIGetSchoolsPackage() throws InterruptedException, IOException, NoSuchAlgorithmException, KeyManagementException {
        TestRunner.startTest("I'm in to call Schools Get Schools Package API ");
        try {
            getSchoolsAPI.getSchoolsAPIConcurrently(mySchoolID);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed     :   API run successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("GET Dashboard Calendar API")
    public void getCalendarAPIGetCalendarPackage() throws InterruptedException, IOException, NoSuchAlgorithmException, KeyManagementException {
        TestRunner.startTest("I'm in to call Calendar Get Calendar Package API ");
        try {
            getCalendarAPI.GetCalendarAPIConcurrently(calendarClassID,calendarStartDate,calendarEndDate );
            TestRunner.getTest().log(Status.PASS, "Test Case Passed     :   API run successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

//    GradeBook Module

    @And("Get GradeBook SortingOption API")
    public void get_grade_book_sorting_option_api() throws InterruptedException, IOException, NoSuchAlgorithmException, KeyManagementException {
        TestRunner.startTest("I'm in to call GradeBookSorting ");
        try {
            getSortingOptionAPI.getSortingOptionAPIConcurrently();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed     :   API run successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("Get GradeBook classesDropdown API")
    public void get_grade_book_classesDropdown_api() throws InterruptedException, IOException, NoSuchAlgorithmException, KeyManagementException {
        TestRunner.startTest("I'm in to call GradeBook Classes Dropdown");
        try {
            getClassesDropdownAPIGradeBoook.getClassesDropdownAPIGradeBookConcurrently();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed     :   API run successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("Get GradeBook district API")
    public void get_GradeBook_district_api() throws InterruptedException {
        TestRunner.startTest("I'm in to call GradeBook District api");
        try {
            getDistrictAPI.getDistrictAPIConcurrently();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed     :   API run successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("Get GradeBook CategoryDetails API")
    public void get_grade_book_category_details_api() throws InterruptedException, IOException, NoSuchAlgorithmException, KeyManagementException {
        // Write code here that turns the phrase above into concrete actions
        TestRunner.startTest("I'm in to call GradeBook CategoryDetails API  ");
        try {
            getCategoryDetails.getCategoryDetailsAPIConcurrently(gradeBookClassID,calendarStartDate,calendarEndDate,districtId,orgId
                    ,printingBtn,studentStatus,classStatus,viewBtn,sortBy,isDecimal,refresh);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed     :   API run successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("Get GradeBook StudentClassProgress API")
    public void get_gradeBook_studentClassProgress_api() throws InterruptedException, IOException, NoSuchAlgorithmException, KeyManagementException {
        // Write code here that turns the phrase above into concrete actions
        TestRunner.startTest("I'm in to call GradeBook StudentClassProgress API  ");
        try {
            getStudentClassProgress.getStudentClassProgressAPIConcurrently(gradeBookClassID,calendarStartDate,calendarEndDate,districtId,orgId
                    ,printingBtn,studentStatus,classStatus,viewBtn,sortBy,isDecimal,refresh);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed     :   API run successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("Get GradeBook StudentByClassId API")
    public void get_gradeBook_studentByClassId_api() throws InterruptedException, IOException, NoSuchAlgorithmException, KeyManagementException {
        // Write code here that turns the phrase above into concrete actions
        TestRunner.startTest("I'm in to call GradeBook StudentByClassId API  ");
        try {
            getStudentByClassId.getStudentByClassIdAPIConcurrently(gradeBookClassID,calendarStartDate,calendarEndDate,districtId,orgId
                    ,printingBtn,studentStatus,classStatus,viewBtn,sortBy,isDecimal,refresh);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed     :   API run successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("Get GradeBook AllStudentProgress API")
    public void get_gradeBook_AllStudentProgress_api() throws InterruptedException, IOException, NoSuchAlgorithmException, KeyManagementException {
        // Write code here that turns the phrase above into concrete actions
        TestRunner.startTest("I'm in to call GradeBook StudentByClassId API  ");
        try {
            getAllStudentProgressAPI.getAllStudentProgressAPIConcurrently(gradeBookClassID,calendarStartDate,calendarEndDate,districtId,orgId
                    ,printingBtn,studentStatus,classStatus,viewBtn,sortBy,isDecimal,refresh);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed     :   API run successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("POST GradeBook SaveUserUsage API")
    public void GradeBookSaveUserUsageAPI() {
        TestRunner.startTest("I'm in to call GradeBook Save User Usage API ");
        try {
            postGradeBookSaveUserUsageAPI.getSaveUserUsageAPIConcurrently();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed     :   API run successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    // Assignment Module

    @And("Get AssignmentType API")
    public void get_assignmentType_api() throws InterruptedException ,IOException, NoSuchAlgorithmException, KeyManagementException {
        // Write code here that turns the phrase above into concrete actions
        TestRunner.startTest("I'm in to call Assignment Module AssignmentType API  ");
        Thread.sleep(500);
        try {
            getAssignmentType.getAssignmentTypeAPIConcurrently(gradeBookClassID);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed     :   API run successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("Get AssignmentStatusOptions API")
    public void get_assignmentStatusOptions_api() throws InterruptedException{
        TestRunner.startTest("I'm in to call Assignment Module Get AssignmentStatusOptions");
        Thread.sleep(500);
        try {
            getAssignmentStatusOptionsAPI.getAssignmentStatusOptionsAPIConcurrently();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed     :   API run successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("Get ClassAssignments API")
    public void get_classAssignments_api() throws InterruptedException{
        TestRunner.startTest("I'm in to call Assignment Module Get ClassAssignments");
        Thread.sleep(500);
        try {
            getClassAssignmentsAPI.getClassAssignmentsAPIAPIConcurrently(gradeBookClassID,assignmentTypeFilter,calendarStartDate,calendarEndDate,districtId,orgId,
                    teacherId,search,assignmentFilter,sortBy,assignmentPage,assignmentSize);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed     :   API run successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }


    @And("Get Assignment myCoursesDropdown API")
    public void get_AssignmentMyCoursesDropdown_api(){
            TestRunner.startTest("I'm in to call Assignment Module Get MyCoursesDropdown ");
            try {
                getMyCoursesDropdownAPI.getMyCoursesDropdownAPIConcurrently();
                TestRunner.getTest().log(Status.PASS, "Test Case Passed     :   API run successfully");
            } catch (Exception e) {
                System.out.println(e);
                System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
                TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found");
                Assert.fail();
            }
    }

    @And("Get count API")
    public void get_count_api(){
        TestRunner.startTest("I'm in to call Assignment Module Get  count/content API");
        try {
            getCountAPI.GetCountAPIConcurrently(contentId);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed     :   API run successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }


    @And("Get ByUserId API")
    public void get_byUserId_api(){
        TestRunner.startTest("I'm in to call Assignment Module Get ByUserId ");
        try {
            getByUserIdAPI.GetByUserIdAPIConcurrently(userId);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed     :   API run successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found");
            Assert.fail();
        }

    }

    @And("Get StudentsByClassIds API")
    public void get_studentsByClassIds_api(){
        TestRunner.startTest("I'm in to call Assignment Module Get StudentsByClassIds");
        try {
            getStudentsByClassIdsAPI.getStudentsByClassIdsAPIConcurrently(myCourseClassID);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed     :   API run successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found");
            Assert.fail();
        }

    }

    @And("Get Category API")
    public void get_category_api(){
        TestRunner.startTest("I'm in to call Assignment Module Get Category ");
        try {
            getCategoryAPI.getCategoryAPIConcurrently();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed     :   API run successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("Get ReviewPermissionListing API")
    public void get_reviewPermissionListing_api(){
        TestRunner.startTest("I'm in to call Assignment Module Get ReviewPermissionListing ");
        try {
            getReviewPermissionListingAPI.getReviewPermissionListingAPIConcurrently();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed     :   API run successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found");
            Assert.fail();
        }

    }

    @And("Get Questions assessmentInformation API")
    public void get_questions_assessmentInformation_api(){
        TestRunner.startTest("I'm in to call Assignment Module Get Questions assessmentInformation ");
        try {
            getQuestionsAPI.GetQuestionsAPIConcurrently(questionID);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed     :   API run successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("POST ReleaseAssignment API")
    public void ReleaseAssignment_API(){
        TestRunner.startTest("I'm in to call Assignment Module POST ReleaseAssignment API ");
        try {
            postAssignmentReleaseAPI.getAssignmentReleaseAPIConcurrently();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed     :   API run successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("POST Assignment SaveUserUsage API")
    public void Assignment_SaveUserUsage_API(){
        TestRunner.startTest("I'm in to call GradeBook Save User Usage API ");
        try {
            postAssignmentSaveUserUsageAPI.getAssignmentSaveUserUsageAPIConcurrently();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed     :   API run successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

//    My Content Module

    @And("GET MyContent Get Standard Package API")
    public void MyContentGetStandardPackage() throws InterruptedException, IOException, NoSuchAlgorithmException, KeyManagementException {
        TestRunner.startTest("I'm in to call MyContent Get Standard Package API ");
        try {
            getStandardPackageAPI.getStandardPackagesAPIConcurrently(classID, gradeLevelID);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed     :   API run successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("GET MyContent myCoursesDropdown API")
    public void MyContentMyCoursesDropdown() {
        TestRunner.startTest("I'm in to call MyContent Get myCoursesDropdown API");
        try {
            getMyCoursesDropdownAPI.getMyCoursesDropdownAPIConcurrently();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed     :   API run successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("GET MyContent ContentInformationByCourseID API")
    public void MyContentInformationByCourseID() {
        TestRunner.startTest("I'm in to call MyContent Get ContentInformation/ByCourseID API");
        try {
            getContentInformationByCourseIdAPI.getContentInformationByCourseIdAPIConcurrently(classID,contentId,page,searchFilter,assessTypeFilter, standardFilter,size,category,assessmentTab);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed     :   API run successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("GET MyContent ContentCount API")
    public void MyContentGetContentCount() {
        TestRunner.startTest("I'm in to call MyContent Get Content/Count API ");
        try {
            getContentCountAPI.getContentCountAPIConcurrently(contentId);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed     :   API run successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("GET MyContent QuestionLookUpCount API")
    public void MyContentQuestionLookUpCount() {
        TestRunner.startTest("I'm in to call MyContent get questionLookup/count? API");
        try {
            getQuestionLookUpCountAPI.getQuestionLookUpCountAPIConcurrently(contentId, countType);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed     :   API run successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("GET MyContent AssessmentType API")
    public void MyContentAssessmentType() {
        TestRunner.startTest("I'm in to call MyContent Assessment API ");
        try {
            getAssessmentType.getAssessmentTypeAPIConcurrently();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed     :   API run successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("POST MyContent AssessmentInformation API")
    public void MyContentAssessmentInformation() {
        TestRunner.startTest("I'm in to call MyContent post assessmentInformation API");
        try {
            postAssessmentInformationAPI.sendAssessmentInformationConcurrently();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed     :   API run successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("GET MyContent AssessmentInformation API")
    public void MyContentGetAssessmentInformation() {
        TestRunner.startTest("I'm in to call MyContent Get /assessmentInformation/ByID API ");
        try {
            getAssessmentInformationAPI.getAssessmentInformationAPIConcurrently(assessmentID);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed     :   API run successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("GET MyContent QuestionLookUpByAccess API")
    public void MyContentQuestionLookUpByAccess() {
        TestRunner.startTest("I'm in to call MyContent get questionLookup/byAccess? API");
        try {
            for (String questionTypeFilter : questionsTypeFilter) {
                System.out.println("Running API for type: " + questionTypeFilter);
                getQuestionLookUpByAccess.getQuestionLookUpByAccessAPIConcurrently(contentId, page, searchFilter, questionTypeFilter, standardFilter, size, assessmentTab);
                TestRunner.getTest().log(Status.PASS, "Test Case Passed     :   API run successfully");
            }
            // Combine all question types into a single string with %2C delimiter
            String combinedQuestionTypeFilter = String.join("%2C", questionsTypeFilter);
            System.out.println("Running API for combined types: " + combinedQuestionTypeFilter);
            getQuestionLookUpByAccess.getQuestionLookUpByAccessAPIConcurrently(contentId, page, searchFilter, combinedQuestionTypeFilter, standardFilter, size, assessmentTab);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed     :   API run successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("POST MyContent NewAssessmentQuestions API")
    public void MyContentNewAssessmentQuestions() {
        TestRunner.startTest("I'm in to call MyContent POST assessmentInformation/ByID API ");
        try {
            postAssignmentQuestionsAPI.getAssignmentQuestionsAPIConcurrently(createdAssessmentID);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed     :   API run successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("PUT MyContent NewAssessmentUpdateStatus API")
    public void MyContentNewAssessmentUpdateStatus() {
        TestRunner.startTest("I'm in to call MyContent PUT assessmentInformation/ByID/updateStatus API ");
        try {
            putAssessmentStatusAPI.updateAssessmentStatusConcurrently(createdAssessmentID);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed     :   API run successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

//    Test API

    @And("Get TestAPI API")
    public void TestAPIHandle() {
        TestRunner.startTest("I'm in to call Test API  ");
        try {
            testApi.getTestAPIConcurrently();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed     :   API run successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    // Students Module API's
    @And("Get Students studentGradeLevel API")
    public void Get_Students_studentGradeLevel_API(){
        TestRunner.startTest("I'm in to call Students Get studentGradeLevel API");
        try {
            getStudentGradeLevelAPI.getStudentGradeLevelAPIConcurrently(districtId,orgId,studentTeacherId,gradeBookClassID);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed     :   API run successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("Get Students SchoolYearDropDown API")
    public void Get_Students_SchoolYearDropDown_API(){
        TestRunner.startTest("I'm in to call Students Get SchoolYearDropDown API");
        try {
            getSchoolYearDropDownAPI.getSchoolYearDropDownAPIConcurrently();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed     :   API run successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("Get Students UserProfileLanguages API")
    public void Get_Students_UserProfileLanguages_API(){
        TestRunner.startTest("I'm in to call Students Get UserProfileLanguages API");
        try {
            getUserProfileLanguagesAPI.getUserProfileLanguagesAPIConcurrently();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed     :   API run successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("Get Students getStudent API")
    public void Get_Students_getStudent_API(){
        TestRunner.startTest("I'm in to call Students Get getStudent  API");
        try {
            getStudentAPI.GetStudentAPIConcurrently(gradeBookClassID,districtId,mySchoolID,studentTeacherId,gradeId, size,page);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed     :   API run successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("POST Student saveUserUsage API")
    public void POST_Student_saveUserUsage_API(){
        TestRunner.startTest("I'm in to call Students Get getStudent  API");
        try {
            postStudentSaveUserUsageAPI.getStudentSaveUserUsageAPIConcurrently();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed     :   API run successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("Get StudentGradeLevelListing API")
    public void Get_StudentGradeLevelListing_API(){
        TestRunner.startTest("I'm in to call Students Get getStudent  API");
        try {
            getGradeLevelListingAPI.getGradeLevelListingAPIConcurrently(userId);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed     :   API run successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("Get Student classesDropdown API")
    public void Get_Student_classesDropdown_API(){
        TestRunner.startTest("I'm in to call Students Get Student classesDropdown  API");
        try {
            getStudentClassesDropdownAPI.getStudentClassesDropdownAPIConcurrently(districtId,orgId,studentTeacherId);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed     :   API run successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    // Staff Module

    @And("Get Staff Module getStaff API")
    public void get_Staff_Module_getStaff_API(){
        TestRunner.startTest("I'm in to call Staff Get getStaff  API");
        try {
            getStaffAPI.getStaffAPIConcurrently(staffRoleId,staffSchoolId,districtId,searchFilter,staffStatusId,size,page);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed     :   API run successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("Get Staff Module getDashboardFilters API")
    public void Get_Staff_Module_getDashboardFilters_API(){
        TestRunner.startTest("I'm in to call Staff Get getDashboardFilters  API");
        try {
            getStaffDashboardFilters.getStaffDashboardFiltersAPIConcurrently();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed     :   API run successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }


    @And("Get Staff Module userUsage API")
    public void Get_Staff_Module_userUsage_API(){
        TestRunner.startTest("I'm in to call Staff Get getDashboardFilters  API");
        try {
            getStaffUserUsageAPI.getStaffUserUsageAPIConcurrently(userId, page,size,staffFilterType);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed     :   API run successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("Get Staff Module district API")
    public void Get_Staff_Module_district_API(){
        TestRunner.startTest("I'm in to call Staff Get staff/district  API");
        try {
            getStaffModuleDistrictAPI.getStaffModuleDistrictAPIConcurrently();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed     :   API run successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("POST Staff SaveUserUsage API")
    public void POST_Staff_SaveUserUsage_API(){
        TestRunner.startTest("I'm in to call Staff POST SaveUserUsage  API");
        try {
            postStaffSaveUserUsage.getStaffSaveUserUsageAPIConcurrently();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed     :   API run successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    // Reports Module

    @And("Get Reports getContentStandardsById API")
    public void Get_Reports_getContentStandardsById_API(){
        TestRunner.startTest("I'm in to call Reports Get ContentStandardsById  API");
        try {
            getReportsContentStandardsByIdAPI.getContentStandardsByIdAPIConcurrently(reportId,calendarStartDate,calendarEndDate,districtId,orgId,teacherId);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed     :   API run successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("Get Reports getStudentPerformance API")
    public void Get_Reports_getStudentPerformance_API(){
        TestRunner.startTest("I'm in to call Reports Get getStudentPerformance  API");
        try {
            getReportsStudentPerformanceAPI.getReportsStudentPerformanceAPIConcurrently(myCourseClassID);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed     :   API run successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found");
            Assert.fail();
        }

    }

    @And("Get Reports standardOverview API")
    public void Get_Reports_standardOverview_API(){
        TestRunner.startTest("I'm in to call Reports Get standardOverview  API");
        try {
            getReportsStandardOverviewAPI.getReportsStandardOverviewAPIConcurrently(reportId, calendarStartDate,calendarEndDate,districtId,orgId,teacherId, reportUserId,reportStandardId);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed     :   API run successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("Get Reports getClassStudentsById API")
    public void Get_Reports_getClassStudentsById_API(){
        TestRunner.startTest("I'm in to call Reports Get getClassStudentsById  API");
        try {
            getReportsClassStudentsByIdAPI.getReportsClassStudentsByIdAPIConcurrently(reportId, calendarStartDate,calendarEndDate,districtId,orgId,teacherId);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed     :   API run successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("Get Reports getClassesDropdown API")
    public void Get_Reports_getClassesDropdown_API(){
        TestRunner.startTest("I'm in to call Reports Get getClassesDropdown  API");
        try {
            getReportsClassesDropdownAPI.getReportsClassesDropdownAPIConcurrently(districtId,orgId,teacherId, classStatus,isGradeRequired);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed     :   API run successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }


    @And("Get Reports masteryStandards API")
    public void Get_Reports_masteryStandards_API(){
        TestRunner.startTest("I'm in to call Reports Get masteryStandards  API");
        try {
            getReportsMasteryStandardsAPI.getReportsMasteryStandardsAPIConcurrently(reportId,calendarStartDate,calendarEndDate,districtId,orgId,teacherId
            ,printingBtn,studentStatus,classStatus,viewBtn,sortBy,isDecimal,refresh,reportStandardId,reportUserId);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed     :   API run successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }


    @And("Get Reports getMasteryReport API")
    public void Get_Reports_getMasteryReport_API(){
        TestRunner.startTest("I'm in to call Reports Get getMasteryReport  API");
        try {
            getReportsMasteryReportAPI.getReportsMasteryReportAPIConcurrently(reportId,calendarStartDate,calendarEndDate,districtId,orgId,teacherId
                    ,printingBtn,studentStatus,classStatus,viewBtn,sortBy,isDecimal,refresh,reportStandardId,reportUserId);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed     :   API run successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("Get Reports getCategories API")
    public void Get_reports_getCategories_API(){
        TestRunner.startTest("I'm in to call Reports Get getCategories  API");
        try {
            getReportCategoriesAPI.getReportCategoriesAPIConcurrently(gradeBookClassID);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed     :   API run successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("Get Reports getAssignmentItems API")
    public void Get_Reports_getAssignmentItems_API(){
        TestRunner.startTest("I'm in to call Reports getAssignmentItems  API");
        try {
            getReportsAssignmentItemsAPI.getReportsAssignmentItemsConcurrently(reportId, page,reportInProgress,size);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed     :   API run successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found");
            Assert.fail();
        }

    }


    // Logout Module API
    @And("POST Teacher Logout SaveUserUsage API")
    public void POST_Teacher_Logout_API(){
        TestRunner.startTest("I'm in to call Logout POST SaveUserUsage  API");
        try {
            postLogoutSaveUserUsageAPI.getLogoutSaveUserUsageAPIConcurrently();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed     :   API run successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

//    Announcements Module API

    @And("GET Teacher Announcements getNewPage API")
    public void AnnouncementsGetNewPageAPI() {
        TestRunner.startTest("I'm in to call Announcements/getNewPage API");
        try {
            for (String readStatus : readStatuses) {
                System.out.println("Running API for read status: " + readStatus);
                TestRunner.getTest().log(Status.INFO, "Running API for read status: " + readStatus);
                getNewPage.getAnnouncementsNewPageAPIConcurrently(page, size, readStatus);
//                System.out.println("API run successfully for read status: " + readStatus);
                TestRunner.getTest().log(Status.INFO, " API run successfully for read status: " + readStatus);
            }
            TestRunner.getTest().log(Status.PASS, " Test Case Passed: All API calls run successfully");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("POST Teacher Announcements SaveUserUsage API")
    public void AnnouncementsMarkAllAsReadAPI() {
        TestRunner.startTest("I'm in to call announcement/markAllAsRead API");
        try {
            for (String announcementType : announcementTypes) {
                System.out.println("Running API for type: " + announcementType);
                TestRunner.getTest().log(Status.INFO, "Running API for type: " + announcementType);
                postMarkAllAsReadAPI.markAllAsReadConcurrently(announcementType);
                TestRunner.getTest().log(Status.PASS, "Test Case Passed     :   API run successfully");
            }
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }
}
