package StepDefinitions.GalSystemScenarios;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.GalSystemScenarios.GalSystemImpersonateUser_PF;

import java.time.Duration;

public class GalSystemImpersonateUserSteps {

    WebDriver driver = Configurations.getDriver();
    Helper helper;
    Actions actions;

    GalSystemImpersonateUser_PF galSystemImpersonateUser_pf;

    public WebDriverWait wait;
    WebElement loader = driver.findElement(By.xpath("//span[@role='progressbar']"));

    public GalSystemImpersonateUserSteps(){
        helper = new Helper();
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
        actions = new Actions(driver);
        galSystemImpersonateUser_pf = new GalSystemImpersonateUser_PF(driver);
    }

    @And("Validate and Click On Staff Impersonate Button")
    public void ValidateAndClickOnStaffImpersonateButton() throws InterruptedException {
        TestRunner.startTest("Validate and Click On Staff Impersonate Button");

        try {
            galSystemImpersonateUser_pf.clickStaffImpersonateButtonFromDots();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();

        }
    }

    @And("Validate Impersonate User Prompt Display")
    public void ValidateImpersonateUserPromptDisplay() throws InterruptedException {
        TestRunner.startTest("Validate Impersonate User Prompt Display");
        try {
            galSystemImpersonateUser_pf.verifyImpersonateUserPromptDisplay();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Validate and Get Prompt Information")
    public void ValidateAndGetPromptInformation() throws InterruptedException {
        TestRunner.startTest("Validate and Get Prompt Information");
        try {
            galSystemImpersonateUser_pf.getImpersonateUserInfo();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Validate And Check That Staff Name Match On Impersonate User Prompt")
    public void ValidateAndCheckThatStaffNameMatchOnImpersonateUserPrompt() throws InterruptedException {
        TestRunner.startTest("Validate And Check That Staff Name Match On Impersonate User Prompt");
        try {
            galSystemImpersonateUser_pf.validateStaffNameOnImpersonateUserPrompt();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number:  "+ Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Validate and Check Impersonate Button")
    public void ValidateAndCheckImpersonateButton() throws InterruptedException {
        TestRunner.startTest("Validate and Check Impersonate Button");
        try {
            galSystemImpersonateUser_pf.ImpersonateButton();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number:  "+ Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Validate User is again on GalSystem Edit District Screen")
    public void ValidateUserIsAgainOnGalSystemEditDistrictScreen() throws InterruptedException {
        TestRunner.startTest("Validate User is again on GalSystem Edit District Screen");

        try {
            galSystemImpersonateUser_pf.VerifyUserAgainOnGalSystem();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

}
