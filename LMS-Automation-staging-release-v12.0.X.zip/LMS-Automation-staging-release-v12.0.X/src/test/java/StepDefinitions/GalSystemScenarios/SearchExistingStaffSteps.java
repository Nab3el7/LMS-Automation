package StepDefinitions.GalSystemScenarios;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.GalSystemScenarios.GalSystemAddNewStaff_PF;
import pageFactory.GalSystemScenarios.GalSystemRoleFilter_PF;
import pageFactory.GalSystemScenarios.SearchExistingStaff_PF;

import java.time.Duration;

public class SearchExistingStaffSteps {
    WebDriver driver = Configurations.getDriver();
    Helper helper;
    Actions actions;


    GalSystemRoleFilter_PF galSystemRoleFilter_pf;
    GalSystemAddNewStaff_PF galSystemAddNewStaff_pf;
    SearchExistingStaff_PF searchExistingStaff_pf;

    public WebDriverWait wait;
    WebElement loader = driver.findElement(By.xpath("//span[@role='progressbar']"));


    public SearchExistingStaffSteps() {
        helper = new Helper();
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
        actions = new Actions(driver);
        galSystemRoleFilter_pf = new GalSystemRoleFilter_PF(driver);
        galSystemAddNewStaff_pf = new GalSystemAddNewStaff_PF(driver);
        searchExistingStaff_pf = new SearchExistingStaff_PF(driver);
    }

    @And("Validate Staff Table is Display")
    public void ValidateDataShowsIntoTable() throws InterruptedException {
        TestRunner.startTest("Validate Staff Table is Display");
        try {

            searchExistingStaff_pf.validateDataShowsIntoTable();
        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Search Existing User In Search Box")
    public void SearchNewStaffTeacher() throws InterruptedException {
        TestRunner.startTest("Search Existing User In Search Box");
        try {
            searchExistingStaff_pf.searchExistingUser();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Verify That Existing Staff Teacher Is Found In Table")
    public void VerifyTheNewStaffTeacherIsFoundInTable() throws InterruptedException{
        TestRunner.startTest("Verify That Existing Staff Teacher Is Found In Table");
        try {

            searchExistingStaff_pf.verifySearchedExistingStaffByNameIntoTable();
        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Validate and Click On Staff Edit Button")
    public void ValidateAndClickOnStaffEditButton() throws InterruptedException {
        TestRunner.startTest("Validate and Click On Staff Edit Button");
        try {
            searchExistingStaff_pf.clickStaffEditButtonDots();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Validate Teacher Information Prompt Display")
    public void ValidateTeacherInformationPromptDisplay() throws InterruptedException {
        TestRunner.startTest("Validate Teacher Information Prompt Display");
        try {
            searchExistingStaff_pf.verifyTeacherInformationPromptDisplay();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Validate Staff Name Is Display On Prompt")
    public void ValidateStaffNameIsDisplayOnPrompt() throws InterruptedException {
        TestRunner.startTest("Validate Staff Name Is Display On Prompt");
        try {
            searchExistingStaff_pf.verifyStaffNameOnPrompt();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Edit Teacher Login Email On Teacher Information Prompt")
    public void EditTeacherLoginEmailOnTeacherInformationPrompt() throws InterruptedException {
        TestRunner.startTest("Edit Teacher Login Email On Teacher Information Prompt");
        try {
            searchExistingStaff_pf.editTeacherLoginEmail();
        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Enter Teacher Password On Teacher Information Prompt")
    public void EnterTeacherPasswordOnTeacherInformationPrompt() throws InterruptedException{
        TestRunner.startTest("Enter Teacher Password On Teacher Information Prompt");
        try {
            searchExistingStaff_pf.addNewPassword();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed:  Exception is found");
            Assert.fail();
        }
    }

    @And("Enter Confirm Password On Teacher Information Prompt")
    public void EnterConfirmPasswordOnTeacherInformationPrompt() throws InterruptedException {
        TestRunner.startTest("Enter Confirm Password On Teacher Information Prompt");

        try {
            searchExistingStaff_pf.addNewConfirmPassword();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Validate and Click on Update Button On Teacher Information Prompt")
    public void ValidateAndClickOnUpdateButtonOnTeacherInformationPrompt() throws InterruptedException {
        TestRunner.startTest("Validate and Click on Update Button On Teacher Information Prompt");

        try {
            searchExistingStaff_pf.verifyAndClickUpdateButton();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed :  Exception is found");
            Assert.fail();
        }
    }

    @And("Verify New Updated Login Email also Update In Staff Table")
    public void VerifyNewUpdatedLoginEmailAlsoUpdateInStaffTable() throws InterruptedException {
        TestRunner.startTest("Verify New Updated Login Email also Update In Staff Table");
        try {
            searchExistingStaff_pf.VerifyEmailUpdateInTable();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Verify Side Navbar")
    public void TeacherIsOnLoginWithValidCredentialAfterEditInformationFromGalSystem() throws InterruptedException {
        TestRunner.startTest("Verify Side Navbar");
        try {
            searchExistingStaff_pf.ValidateSideNavbar();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }
}
