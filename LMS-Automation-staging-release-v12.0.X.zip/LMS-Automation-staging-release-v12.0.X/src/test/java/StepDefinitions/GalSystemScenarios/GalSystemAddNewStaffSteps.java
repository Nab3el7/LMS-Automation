package StepDefinitions.GalSystemScenarios;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.GalSystemScenarios.GalSystemAddNewStaff_PF;
import pageFactory.GalSystemScenarios.GalSystemRoleFilter_PF;

import java.time.Duration;

public class GalSystemAddNewStaffSteps {
    WebDriver driver = Configurations.getDriver();
    Helper helper;
    Actions actions;


    GalSystemRoleFilter_PF galSystemRoleFilter_pf;
    GalSystemAddNewStaff_PF galSystemAddNewStaff_pf;

    public WebDriverWait wait;
    WebElement loader = driver.findElement(By.xpath("//span[@role='progressbar']"));


    public GalSystemAddNewStaffSteps(){
        helper = new Helper();
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
        actions = new Actions(driver);
        galSystemRoleFilter_pf = new GalSystemRoleFilter_PF(driver);
        galSystemAddNewStaff_pf = new GalSystemAddNewStaff_PF(driver);
    }

    @And("Validate and Click on Add New Staff From GalSystem")
    public void ValidateSideNavBarAndClickOnSettings() throws InterruptedException{
        TestRunner.startTest("Validate and Click on Add New Staff From GalSystem");
        try {

            galSystemAddNewStaff_pf.ClickOnAddNewStaff();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }

    @And("Validate Add New Staff Prompt Display")
    public void ValidateAddNewStaffPromptDisplay() throws InterruptedException {
        TestRunner.startTest("Validate Add New Staff Prompt Display");
        try {

            galSystemAddNewStaff_pf.verifyAddNewStaffTeacherPrompt();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Enter First Name For New Staff Teacher")
    public void EnterFirstNameForNewStaff() throws InterruptedException {
        TestRunner.startTest("Enter First Name For New Staff/Teacher");
        try {
            galSystemAddNewStaff_pf.enterFirstNameForStaffTeacher();
        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Enter Last Name For New Staff Teacher")
    public void EnterLastNameForNewStaffTeacher() throws InterruptedException {
        TestRunner.startTest("Enter Last Name For New Staff Teacher");
        try {
            galSystemAddNewStaff_pf.enterLastNameForStaffTeacher();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Enter Email For New Staff Teacher")
    public void EnterEmailForNewStaffTeacher() throws InterruptedException {
        TestRunner.startTest("Enter Email For New Staff Teacher");
        try {
            galSystemAddNewStaff_pf.enterEmailForStaffTeacher();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Enter Password For New Staff Teacher")
    public void EnterPasswordForNewStaffTeacher() throws InterruptedException {
        TestRunner.startTest("Enter Password For New Staff Teacher");
        try {
            galSystemAddNewStaff_pf.enterPasswordForStaffTeacher();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();

        }
    }

    @And("Enter Confirm Password For New Staff Teacher")
    public void EnterConfirmPasswordForNewStaffTeacher() throws InterruptedException {
        TestRunner.startTest("Enter Confirm Password For New Staff Teacher");
        try {
            galSystemAddNewStaff_pf.enterConfirmPasswordForStaffTeacher();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number:  " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Select District For New Staff Teacher")
    public void SelectDistrictForNewStaffTeacher() throws InterruptedException {
        TestRunner.startTest("Select District For New Staff Teacher");
        try {
            galSystemAddNewStaff_pf.SelectDistrictForStaffTeacher();
        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Select Role For New Staff Teacher")
    public void SelectRoleForNewStaffTeacher() throws InterruptedException {
        TestRunner.startTest("Select Role For New Staff Teacher");
        try {
            galSystemAddNewStaff_pf.SelectRoleForStaffTeacher();
        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Enter Local Id For New Staff Teacher")
    public void EnterLocalIdForNewStaffTeacher() throws InterruptedException{
        TestRunner.startTest("Enter Local Id For New Staff Teacher");
        try {
            galSystemAddNewStaff_pf.EnterLocalIdForStaffTeacher();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Select Language For New Staff Teacher")
    public void SelectLanguageForNewStaffTeacher() throws InterruptedException {
        TestRunner.startTest("Select Language For New Staff Teacher");
        try {
            galSystemAddNewStaff_pf.SelectLanguageForStaffTeacher();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }


    @And("Enter Phone Number For New Staff Teacher")
    public void EnterPhoneNumberForNewStaffTeacher() throws InterruptedException {
        TestRunner.startTest("Enter Phone Number For New Staff Teacher");
        try {
            galSystemAddNewStaff_pf.EnterPhoneNumberForStaffTeacher();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }


    @And("Enter Address For New Staff Teacher")
    public void EnterAddressForNewStaffTeacher() throws InterruptedException {
        TestRunner.startTest("Enter Address For New Staff Teacher");
        try {
            galSystemAddNewStaff_pf.EnterAddressForStaffTeacher();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Validate and Click on Add New Organization")
    public void ValidateAndClickOnAddNewOrganization() throws InterruptedException {
        TestRunner.startTest("Validate and Click on + Add New Organization");
        try {
            galSystemAddNewStaff_pf.clickAddNewOrganizationButton();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Validate Add New Organization Prompt Display")
    public void ValidateAddNewOrganizationPromptDisplay() throws InterruptedException {
        TestRunner.startTest("Validate Add New Organization Prompt Display");
        try {
            galSystemAddNewStaff_pf.verifyAddNewOrganizationPromptDisplay();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Select School From Add New Organization")
    public void SelectSchoolFromAddNewOrganization() throws InterruptedException {
        TestRunner.startTest("Select School From Add New Organization");
        try {
            galSystemAddNewStaff_pf.selectSchoolForStaffTeacher();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Validate and Click on Save Button Add New Organization")
    public void ValidateAndClickOnSaveButtonAddNewOrganization() throws InterruptedException {
        TestRunner.startTest("Validate and Click on Save Button Add New Organization");
        try {
            galSystemAddNewStaff_pf.clickSaveButtonAddNewOrganization();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Verify and Click on Save Button Add New Staff Teacher")
    public void VerifyAndClickOnSaveButtonAddNewStaffTeacher() throws InterruptedException {
        TestRunner.startTest("Verify and Click on Save Button Add New Staff Teacher");
        try {
            galSystemAddNewStaff_pf.saveButtonAddNewStaffTeacher();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }


    @And("Validate Data Shows Into Table")
    public void ValidateDataShowsIntoTable() throws InterruptedException {
        TestRunner.startTest("Validate Data Shows Into Table");
        try {

            galSystemAddNewStaff_pf.verifyStaffShowsIntoTable();
        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Search New Staff Teacher")
    public void SearchNewStaffTeacher() throws InterruptedException {
        TestRunner.startTest("Search New Staff Teacher");
        try {
            galSystemAddNewStaff_pf.searchUser();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Verify The New Staff Teacher Is Found In Table")
    public void VerifyTheNewStaffTeacherIsFoundInTable() throws InterruptedException{
        TestRunner.startTest("Verify The New Staff Teacher Is Found In Table");
        try {

            galSystemAddNewStaff_pf.verifySearchedStaffByNameIntoTable();
        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

//    for Edit Staff

    @And("Validate New Staff Teacher Name Display On Prompt")
    public void ValidateNewStaffTeacherNameDisplayOnPrompt() throws InterruptedException {
        TestRunner.startTest("Validate New Staff Teacher Name Display On Prompt");
        try {

            galSystemAddNewStaff_pf.verifyNewStaffTeacherNameOnPrompt();
        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }
}
