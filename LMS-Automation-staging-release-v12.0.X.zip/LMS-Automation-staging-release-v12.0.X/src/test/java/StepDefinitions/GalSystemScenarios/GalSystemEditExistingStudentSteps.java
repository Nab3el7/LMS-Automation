package StepDefinitions.GalSystemScenarios;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.GalSystemScenarios.GalSystemAddNewStaff_PF;
import pageFactory.GalSystemScenarios.GalSystemEditExistingStudent_PF;
import pageFactory.GalSystemScenarios.GalSystemRoleFilter_PF;
import org.openqa.selenium.ElementNotInteractableException;

import java.time.Duration;

import static pageFactory.GalSystemScenarios.SearchExistingStaff_PF.updatedEmailTeacher;
import static pageFactory.GalSystemScenarios.SearchExistingStaff_PF.updatedPasswordStaff;

public class GalSystemEditExistingStudentSteps {

    WebDriver driver = Configurations.getDriver();
    Helper helper;
    Actions actions;


    GalSystemRoleFilter_PF galSystemRoleFilter_pf;
    GalSystemAddNewStaff_PF galSystemAddNewStaff_pf;

    GalSystemEditExistingStudent_PF galSystemEditExistingStudent_pf;

    public WebDriverWait wait;
    WebElement loader = driver.findElement(By.xpath("//span[@role='progressbar']"));


    public GalSystemEditExistingStudentSteps(){
        helper = new Helper();
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
        actions = new Actions(driver);
        galSystemRoleFilter_pf = new GalSystemRoleFilter_PF(driver);
        galSystemAddNewStaff_pf = new GalSystemAddNewStaff_PF(driver);
        galSystemEditExistingStudent_pf= new GalSystemEditExistingStudent_PF(driver);
    }

    @And("Select Student From Role Filter")
    public void SelectStudentFromRoleFilter() throws InterruptedException {
        TestRunner.startTest("Select Student From Role Filter");
        try {
            galSystemEditExistingStudent_pf.fromRoleFilterSelectStudent();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Validate and Search Student in Search box")
    public void ValidateAndSearchStudentInSearchBox() throws InterruptedException {
        TestRunner.startTest("Validate and Search Student in Search box");
        try {

            galSystemEditExistingStudent_pf.searchStudentInSearchBoxGalSystem();
        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }


    @And("Select Random Student From Table And Click On Edit Option")
    public void SelectRandomStudentFromList() throws InterruptedException {
        TestRunner.startTest("Select Random Student From Table And Click On Edit Option");
        try {
            galSystemEditExistingStudent_pf.selectRandomStudentAndClickEdit();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Validate and Check Student Information Prompt Display")
    public void ValidateAndCheckStudentInformationPromptDisplay() throws InterruptedException {
        TestRunner.startTest("Validate and Check Student Information Prompt Display");
        try {
            galSystemEditExistingStudent_pf.verifyStudentInformationPromptDisplay();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Validate and Check Student Name Is Display On Prompt")
    public void ValidateAndCheckStudentNameIsDisplayOnPrompt() throws InterruptedException {
        TestRunner.startTest("Validate and Check Student Name Is Display On Prompt");
        try {
            galSystemEditExistingStudent_pf.verifyStudentNameOnPrompt();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Validate and Check Class Enrollment Status is Display On Prompt")
    public void ValidateAndCheckClassEnrollmentStatusIsDisplayOnPrompt() throws InterruptedException {
        TestRunner.startTest("Validate and Check Class Enrollment Status is Display On Prompt");

        try {
            galSystemEditExistingStudent_pf.verifyClassEnrollmentStatusIsPresent();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Exception is found");
            Assert.fail();
        }
    }

    @And("Edit Student Login Email On Student Information Prompt")
    public void EditStudentLoginEmailOnStudentInformationPrompt() throws InterruptedException {
        TestRunner.startTest("Edit Student Login Email On Student Information Prompt");
        try {
            galSystemEditExistingStudent_pf.editStudentLoginEmail();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Enter Student Password On Student Information Prompt From GalSystem")
    public void EnterStudentPasswordOnStudentInformationPrompt() throws InterruptedException {
        TestRunner.startTest("Enter Student Password On Student Information Prompt From GalSystem");
        try {
            galSystemEditExistingStudent_pf.EditNewStudentPasswordFromGalSystem();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Enter Confirm Password On Student Information Prompt From GalSystem")
    public void EnterConfirmPasswordOnStudentInformationPromptFromGalSystem() throws InterruptedException {
        TestRunner.startTest("Enter Confirm Password On Student Information Prompt From GalSystem");
        try {
            galSystemEditExistingStudent_pf.editConfirmPasswordFromGalSystem();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Validate and Click on Update Button On Student Information Prompt GalSystem")
    public void ValidateAndClickOnUpdateButtonOnStudentInformationPromptGalSystem() throws InterruptedException {
        TestRunner.startTest("Validate and Click on Update Button On Student Information Prompt GalSystem");
        try {
            galSystemEditExistingStudent_pf.ClickUpdateButtonOnStudentInformationGalSystem();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Verify And Click on Clear Search Box")
    public void VerifyAndClickOnCrossButtonOfSearchBox() throws InterruptedException {
        TestRunner.startTest("Verify And Click on Clear Search Box");
        try {
            galSystemEditExistingStudent_pf.clickCrossButtonSearchBox();
        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Search Student Which is Updated In Search Box")
    public void SearchStudentWhichIsUpdatedInSearchBox() throws InterruptedException {
        TestRunner.startTest("Search Student Which is Updated In Search Box");
        try {

            galSystemEditExistingStudent_pf.searchUpdatedStudent();
        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Validate That Updated Student Is Found In Table")
    public void ValidateThatUpdatedStudentIsFoundInTable() throws InterruptedException {
        TestRunner.startTest("Validate That Updated Student Is Found In Table");
        try {
            galSystemEditExistingStudent_pf.verifySearchedStudentByNameIntoTable();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Verify and Check New Updated Login Email Also Update In Student Table")
    public void VerifyAndCheckNewUpdatedLoginEmailAlsoUpdateInStudentTable() throws InterruptedException {
        TestRunner.startTest("Verify and Check New Updated Login Email Also Update In Student Table");
        try {
            galSystemEditExistingStudent_pf.VerifyStudentEmailUpdateInTable();
        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Validate And Check Student Name On Student Dashboard")
    public void ValidateAndCheckStudentNameOnStudentDashboard() throws InterruptedException {
        TestRunner.startTest("Validate And Check Student Name On Student Dashboard");
        try {
            galSystemEditExistingStudent_pf.verifyStudentNameOnDashboard();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }


    @And("Validate and Check View Usage on Student Information")
    public void ValidateAndCheckViewUsageOnStudentInformation() throws InterruptedException {
        TestRunner.startTest("Validate and Check View Usage on Student Information");

        try {
            galSystemEditExistingStudent_pf.verifyViewUsageButton();
        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found ");
            Assert.fail();
        }
    }

    @And("Validate and Check Student Usage Prompt Display")
    public void ValidateAndCheckStudentUsagePromptDisplay() throws InterruptedException {
        TestRunner.startTest("Validate and Check Student Usage Prompt Display");
        try {
            galSystemEditExistingStudent_pf.verifyStudentUsagePromptDisplay();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Validate and Check User Info is Present on User Accounts Usage")
    public void ValidateAndCheckUserInfoIsPresentOnUserAccountsUsage() throws InterruptedException {
        TestRunner.startTest("Validate and Check User Info is Present on User Accounts Usage");
        try {
            galSystemEditExistingStudent_pf.userAccountUsageInfo();
        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Validate and Check That Today Button is By Default Clicked")
    public void ValidateAndCheckThatTodayButtonIsByDefaultClicked() throws InterruptedException {
        TestRunner.startTest("Validate and Check That Today Button is By Default Clicked");
        try {
            galSystemEditExistingStudent_pf.VerifyTodayClickedByDefault();
        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Validate and Check All Buttons are Display")
    public void ValidateAndCheckAllButtonsAreDisplay() throws InterruptedException {
        TestRunner.startTest("Validate and Check All Buttons are Display");
        try {
            galSystemEditExistingStudent_pf.VerifyAllButtonDisplay();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Validate and Check User Usage Aggregate Is Display")
    public void ValidateAndCheckUserUsageAggregateIsDisplay() throws InterruptedException {
        TestRunner.startTest("Validate and Check User Usage Aggregate Is Display");
        try {
            galSystemEditExistingStudent_pf.verifyUserUsageAggregateDisplay();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Validate and Click on Cross button")
    public void ValidateAndClickOnCrossButton() throws InterruptedException {
        TestRunner.startTest("Validate and Click on Cross button");
        try {
            galSystemEditExistingStudent_pf.verifyCrossButton();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
        Actions actions = new Actions(driver);
        actions.sendKeys(Keys.ESCAPE).perform();
    }
}
