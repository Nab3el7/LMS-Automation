package StepDefinitions.GalSystemScenarios;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.GalSystemScenarios.GalSystemAddNewStaff_PF;
import pageFactory.GalSystemScenarios.GalSystemDistrictAdminValidation_PF;
import pageFactory.GalSystemScenarios.GalSystemRoleFilter_PF;

import java.time.Duration;

public class GalSystemDistrictAdminValidationSteps {
    WebDriver driver = Configurations.getDriver();
    Helper helper;
    Actions actions;


    GalSystemRoleFilter_PF galSystemRoleFilter_pf;
    GalSystemAddNewStaff_PF galSystemAddNewStaff_pf;
    GalSystemDistrictAdminValidation_PF galSystemDistrictAdminValidation_pf;

    public WebDriverWait wait;
    WebElement loader = driver.findElement(By.xpath("//span[@role='progressbar']"));


    public GalSystemDistrictAdminValidationSteps(){
        helper = new Helper();
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
        actions = new Actions(driver);
        galSystemRoleFilter_pf = new GalSystemRoleFilter_PF(driver);
        galSystemAddNewStaff_pf = new GalSystemAddNewStaff_PF(driver);
        galSystemDistrictAdminValidation_pf = new GalSystemDistrictAdminValidation_PF(driver);
    }

    @And("Select Role District Admin From Role Filter")
    public void SelectRoleDistrictAdminFromRoleFilter() throws InterruptedException {
        TestRunner.startTest("Select Role District Admin From Role Filter");
        try {
            galSystemDistrictAdminValidation_pf.selectRoleDistrictAdmin();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Validate and Check Add Organization Is Disable For District Admin")
    public void ValidateAndCheckAddOrganizationIsDisableForDistrictAdmin() throws InterruptedException {
        TestRunner.startTest("Validate and Check Add Organization Is Disable For District Admin");
        try {
            galSystemDistrictAdminValidation_pf.VerifyAddOrganizationIsDisable();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
        Thread.sleep(500);
        Actions actions = new Actions(driver);
        actions.sendKeys(Keys.ESCAPE).perform();
    }

}
