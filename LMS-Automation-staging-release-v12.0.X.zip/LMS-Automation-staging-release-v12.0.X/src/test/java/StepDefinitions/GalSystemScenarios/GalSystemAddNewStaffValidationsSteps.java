package StepDefinitions.GalSystemScenarios;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import io.cucumber.java.mk_latn.No;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.GalSystemScenarios.GalSystemAddNewStaffValidations_PF;
import pageFactory.GalSystemScenarios.GalSystemAddNewStaff_PF;
import pageFactory.GalSystemScenarios.GalSystemRoleFilter_PF;

import java.time.Duration;

public class GalSystemAddNewStaffValidationsSteps {
    WebDriver driver = Configurations.getDriver();
    Helper helper;
    Actions actions;


//    GalSystemRoleFilter_PF galSystemRoleFilter_pf;
//    GalSystemAddNewStaff_PF galSystemAddNewStaff_pf;
    GalSystemAddNewStaffValidations_PF galSystemAddNewStaffValidations_pf;

    public WebDriverWait wait;
    WebElement loader = driver.findElement(By.xpath("//span[@role='progressbar']"));


    public GalSystemAddNewStaffValidationsSteps(){
        helper = new Helper();
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
        actions = new Actions(driver);
//        galSystemRoleFilter_pf = new GalSystemRoleFilter_PF(driver);
//        galSystemAddNewStaff_pf = new GalSystemAddNewStaff_PF(driver);
        galSystemAddNewStaffValidations_pf = new GalSystemAddNewStaffValidations_PF(driver);
    }

    @And("Validate and Check First Name Validation is Display")
    public void ValidateAndCheckFirstNameValidationIsDisplay() throws InterruptedException{
        TestRunner.startTest("Validate and Check First Name Validation is Display");
        try {
            galSystemAddNewStaffValidations_pf.verifyFirstNameValidation();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }

    }

    @And("Validate and Check Last Name Validation is Display")
    public void ValidateAndCheckLastNameValidationIsDisplay() throws InterruptedException {
        TestRunner.startTest("Validate and Check Last Name Validation is Display");
        try {
            galSystemAddNewStaffValidations_pf.verifyLastNameValidation();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Validate and Check Email Validation is Display")
    public void ValidateAndCheckEmailValidationIsDisplay() throws InterruptedException {
        TestRunner.startTest("Validate and Check Email Validation is Display");
        try {
            galSystemAddNewStaffValidations_pf.verifyEmailValidation();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Validate and Check Password Validation is Display")
    public void ValidateAndCheckPasswordValidationIsDisplay() throws InterruptedException{
        TestRunner.startTest("Validate and Check Password Validation is Display");
        try {
            galSystemAddNewStaffValidations_pf.verifyPasswordValidation();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Validate and Check Confirm Password Validation is Display")
    public void  ValidateAndCheckConfirmPasswordValidationIsDisplay() throws InterruptedException {
        TestRunner.startTest(" Validate and Check Confirm Password Validation is Display");
        try {
            galSystemAddNewStaffValidations_pf.verifyConfirmPasswordValidation();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Validate and Check Add Organization Validation is Display")
    public void ValidateAndCheckAddOrganizationValidationIsDisplay() throws InterruptedException{
        TestRunner.startTest("Validate and Check Add Organization Validation is Display");
        try {
            galSystemAddNewStaffValidations_pf.verifyAddOrganizationValidation();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Enter Invalid Phone Number and Validate Validation Display")
    public void EnterInvalidPhoneNumberAndValidateValidationDisplay() throws InterruptedException{
        TestRunner.startTest("Enter Invalid Phone Number and Validate Validation Display");
        try {
            galSystemAddNewStaffValidations_pf.verifyPhoneNumberValidation();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: "  + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }

    }

    @And("Enter Invalid Email and Validate Validation Display")
    public void EnterInvalidEmailAndValidateValidationDisplay() throws InterruptedException {
        TestRunner.startTest("Enter Invalid Email and Validate Validation Display");
        try {

            galSystemAddNewStaffValidations_pf.verifyInvalidEmailValidation();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed: Exception is found");
            Assert.fail();
        }
        Actions actions = new Actions(driver);
        actions.sendKeys(Keys.ESCAPE).perform();
    }

    @And("Enter Already Existing Email and Validate Validation Display")
    public void EnterAlreadyExistingEmailAndValidateValidationDisplay() throws InterruptedException {
        TestRunner.startTest("Enter Already Existing Email and Validate Validation Display");
        try {
            galSystemAddNewStaffValidations_pf.verifyAlreadyExistingEmailValidation();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }

    }
}
