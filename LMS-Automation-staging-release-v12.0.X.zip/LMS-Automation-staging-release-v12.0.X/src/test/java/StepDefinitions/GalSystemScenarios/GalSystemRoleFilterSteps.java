package StepDefinitions.GalSystemScenarios;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.GalSystemScenarios.GalSystemRoleFilter_PF;

import java.time.Duration;


public class GalSystemRoleFilterSteps {
    WebDriver driver = Configurations.getDriver();
    Helper helper;
    Actions actions;


    GalSystemRoleFilter_PF galSystemRoleFilter_pf;

    public WebDriverWait wait;
    WebElement loader = driver.findElement(By.xpath("//span[@role='progressbar']"));


    public GalSystemRoleFilterSteps(){
        helper = new Helper();
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
        actions = new Actions(driver);
        galSystemRoleFilter_pf = new GalSystemRoleFilter_PF(driver);
    }

    @And("Verify Side Navbar And Clicked on Settings")
    public void ValidateSideNavBarAndClickOnSettings() throws InterruptedException{
        TestRunner.startTest("Verify Side Navbar And Clicked on Settings");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            galSystemRoleFilter_pf.SideNavBarAndClickOnSettingsModule();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :    Exception is found.");
            Assert.fail();
        }
    }

    @And("Click On Florida From List")
    public void ClickOnFloridaFromList() throws InterruptedException {
        TestRunner.startTest("Click On Florida From List");
        try {
            galSystemRoleFilter_pf.ClickFloridaFromList();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found.");
            Assert.fail();
        }
    }

    @And("Validate And Search District By Keyword")
    public void ValidateAndSearchDistrictByKeyword() throws InterruptedException {
        TestRunner.startTest("Validate And Search District By Keyword");
        try {
            galSystemRoleFilter_pf.searchDistrictNameByKeyword();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found.");
            Assert.fail();
        }
    }

    @And("Verify District Shows Into Table")
    public void VerifyDistrictShowsIntoTable() throws InterruptedException {
        TestRunner.startTest("Verify District Shows Into Table");
        try {
            galSystemRoleFilter_pf.showsDistrictIntoTable();
        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found.");
            Assert.fail();
        }
    }

    @And("Verify The District by Keyword")
    public void VerifyTheDistrictByKeyword() throws InterruptedException {
        TestRunner.startTest("Verify The District by Keyword");
        try {
            galSystemRoleFilter_pf.verifySearchedDistrictByNameIntoTable();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found.");
            Assert.fail();
        }
    }

    @And("Validate and Click On FLDOE District From Table")
    public void ValidateAndClickOnFLDOEDistrictFromTable() throws InterruptedException {
        TestRunner.startTest("Validate and Click On FLDOE District From Table on Right Side");

        try {
            galSystemRoleFilter_pf.clickOnDistrictColumnName();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }

    }

    @And("Validate and Click On Save And Next Button")
    public void ValidateAndClickOnSaveNextButton() throws InterruptedException {
        TestRunner.startTest(" Validate and Click On Save And Next");
        try {

            Thread.sleep(2000);
            galSystemRoleFilter_pf.clickSaveNextButton();
        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Validate and Click on Save Button For District")
    public void ValidateAndClickOnSaveButtonForDistrict() throws InterruptedException {
        TestRunner.startTest("Validate and Click on Save Button For District");
        try {
            galSystemRoleFilter_pf.clickSaveButton();
        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Validate and Click On Save And Next Button Step-IV")
    public void ValidateAndClickOnSaveAndNextButtonStepIV() throws InterruptedException {
        TestRunner.startTest("Validate and Click On Save And Next Button Step-IV");
        try {
            galSystemRoleFilter_pf.stepIVClickSaveNextButton();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Validate In Role Filter Teacher Is Selected")
    public void ValidateInRoleFilterTeacherIsSelected() throws InterruptedException {
        TestRunner.startTest("Validate In Role Filter Teacher Is Selected");
        try {
            galSystemRoleFilter_pf.VerifyByDefaultTeacherIsSelectedInRoleFilter();

        }catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is Found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Select Role From DropDown And Validate Data Is Populate On GalSystem")
    public void SelectRoleFromDropDownAndValidateDataIsPopulateOnGalSystem() throws InterruptedException {
        TestRunner.startTest("Select Role From DropDown And Validate Data Is Populate On GalSystem");

        try {
            galSystemRoleFilter_pf.filterRoleDropdownOnGalSystem();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

}
