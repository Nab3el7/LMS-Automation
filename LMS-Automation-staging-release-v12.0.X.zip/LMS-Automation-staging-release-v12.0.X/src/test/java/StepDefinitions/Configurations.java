package StepDefinitions;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.time.Duration;
import java.util.Properties;
import java.util.concurrent.Semaphore;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.jetbrains.annotations.NotNull;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import io.github.cdimascio.dotenv.Dotenv;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.RemoteWebDriver;

public class Configurations {

    private static boolean isLocalProfile = false;
    private static boolean useLocalGrid = false;
    private static String customGridUrl = null;

    private static final ThreadLocal<WebDriver> driver = new ThreadLocal<>();
    
    // Semaphore to limit concurrent browser instances to 4
    // This ensures only 4 browsers are open at once, and when one closes, the next test can start
    private static final Semaphore browserSemaphore = new Semaphore(4, true); // 4 permits, fair ordering
    
    // Track if current thread has acquired a semaphore permit (to avoid double-acquisition)
    private static final ThreadLocal<Boolean> hasPermit = new ThreadLocal<>();

    public static String App_url = getDotEnv().get("APP_URL");

    public static String ScreenShotDirectory = System.getProperty("user.dir") + "/Screenshot";

    public static String username = getDotEnv().get("SITE_TEACHER_NAME");
    public static String password = getDotEnv().get("SITE_TEACHER_PASSWORD");

    public static String std_Email = getDotEnv().get("SITE_STUDENT_NAME");
    public static String std_Password = getDotEnv().get("SITE_STUDENT_PASSWORD");

    public static String Api_ThreadPool = getDotEnv().get("API_THREAD_POOL");

    static {
        // Initialize profile check on class load - load from application.properties and profile-specific file
        Properties properties = loadApplicationProperties();
        String activeProfile = properties.getProperty("spring.profiles.active", "local");
        isLocalProfile = activeProfile != null && activeProfile.equalsIgnoreCase("local");

        // Check if we should use local Selenium Grid
        // To enable local Selenium Grid, add to application.properties or application-local.properties:
        // selenium.grid.use.local=true
        // This will connect to http://localhost:4444 instead of using direct ChromeDriver
        String useLocalGridProp = properties.getProperty("selenium.grid.use.local", "false");
        useLocalGrid = "true".equalsIgnoreCase(useLocalGridProp);

        // Check for custom Selenium Grid URL
        // To use a custom Selenium Grid URL, add to application.properties:
        // selenium.grid.url=http://your-grid-host:4444
        // This takes precedence over selenium.grid.use.local
        customGridUrl = properties.getProperty("selenium.grid.url");

        System.out.println("Loaded properties. Active profile: " + activeProfile + ", isLocal: " + isLocalProfile);
        System.out.println("Selenium Grid - use local: " + useLocalGrid + ", custom URL: " + (customGridUrl != null ? customGridUrl : "none"));
        if (useLocalGrid) {
            System.out.println("🐳 Docker Selenium Grid enabled - will connect to http://localhost:4444");
        }

        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            try {
                WebDriver d = driver.get();
                if (d != null) {
                    d.quit();
                    System.out.println("Shutdown hook: WebDriver quit successfully");
                }
            } catch (Exception ignored) {}
        }));
    }

    /**
     * Loads application.properties and profile-specific properties file
     * @return Properties object with all loaded properties
     */
    private static Properties loadApplicationProperties() {
        Properties properties = new Properties();

        try {
            // Step 1: Load base application.properties
            InputStream baseStream = Configurations.class.getClassLoader()
                    .getResourceAsStream("application.properties");

            if (baseStream != null) {
                properties.load(baseStream);
                baseStream.close();
            }

            // Step 2: Get active profile
            String activeProfile = properties.getProperty("spring.profiles.active", "local");

            // Step 3: Load profile-specific properties (e.g., application-local.properties)
            String profileFileName = "application-" + activeProfile + ".properties";
            InputStream profileStream = Configurations.class.getClassLoader()
                    .getResourceAsStream(profileFileName);

            if (profileStream != null) {
                Properties profileProperties = new Properties();
                profileProperties.load(profileStream);
                profileStream.close();

                // Merge profile-specific properties (profile overrides base)
                properties.putAll(profileProperties);
                System.out.println("Loaded profile-specific properties from: " + profileFileName);
            } else {
                System.out.println("Profile-specific file not found: " + profileFileName + ", using base properties only");
            }

        } catch (IOException e) {
            System.out.println("Error loading application properties: " + e.getMessage());
        }

        return properties;
    }

    public static WebDriver getDriver() {
        WebDriver currentDriver = driver.get();

        // Check if driver exists and is still valid
        if (currentDriver == null || !isDriverValid(currentDriver)) {
            // If driver exists but is invalid, clean it up first and release its permit
            if (currentDriver != null) {
                System.out.println("Detected stale/invalid driver, cleaning up...");
                try {
                    // Try to release to pool first, otherwise quit
                    try {
                        com.gallopade.automation.util.BrowserPoolAccessor.releaseBrowser(currentDriver);
                    } catch (Exception e) {
                        currentDriver.quit();
                    }
                } catch (Exception e) {
                    System.out.println("Error closing stale driver: " + e.getMessage());
                }
                driver.remove();
                
                // Release semaphore permit for the stale driver
                if (hasPermit.get() != null && hasPermit.get()) {
                    browserSemaphore.release();
                    hasPermit.set(false);
                    System.out.println("🔄 Released semaphore permit for stale driver (Thread: " + 
                            Thread.currentThread().getName() + ")");
                }
            }

            System.out.println("Initializing WebDriver for thread: " + Thread.currentThread().getName());
            
            // Check if we already have a valid driver (from previous test case on same thread)
            WebDriver existingDriver = driver.get();
            if (existingDriver != null) {
                // Check if driver is valid - if tab crashed, we need a new one
                if (isDriverValid(existingDriver)) {
                    System.out.println("✅ Reusing existing browser connection for thread: " + Thread.currentThread().getName());
                    // Browser is already open and valid - need to re-acquire semaphore permit
                    if (hasPermit.get() == null || !hasPermit.get()) {
                        try {
                            browserSemaphore.acquire();
                            hasPermit.set(true);
                            System.out.println("✅ Re-acquired semaphore permit for existing browser");
                        } catch (InterruptedException e) {
                            Thread.currentThread().interrupt();
                            throw new RuntimeException("Thread interrupted while re-acquiring semaphore", e);
                        }
                    }
                    return existingDriver; // Return existing driver - no need to create new one
                } else {
                    // Driver exists but tab crashed - clean it up and create new one
                    System.out.println("⚠️ Existing driver tab crashed - cleaning up and creating new browser");
                    try {
                        existingDriver.quit();
                    } catch (Exception e) {
                        System.out.println("⚠️ Error quitting crashed driver: " + e.getMessage());
                    }
                    driver.remove();
                    // Release semaphore if held
                    if (hasPermit.get() != null && hasPermit.get()) {
                        try {
                            browserSemaphore.release();
                            hasPermit.set(false);
                        } catch (Exception e) {
                            System.out.println("⚠️ Error releasing semaphore: " + e.getMessage());
                        }
                    }
                }
            }
            
            System.out.println("⚠️ Previous driver was null or invalid - creating fresh driver instance");

            // CRITICAL: Ensure ThreadLocal is completely clear before acquiring new permit
            // This prevents any stale driver references from interfering
            if (driver.get() != null) {
                System.out.println("⚠️ Warning: ThreadLocal still has driver reference, forcing removal...");
                driver.remove();
            }
            
            // Clear permit flag to ensure clean state
            hasPermit.remove();

            // Acquire semaphore permit to limit concurrent browsers to 4
            // This ensures only 4 browsers are open at once
            // Only acquire if we don't already have a permit
            if (hasPermit.get() == null || !hasPermit.get()) {
                try {
                    int availablePermits = browserSemaphore.availablePermits();
                    int waitingThreads = 4 - availablePermits;
                    if (availablePermits == 0) {
                        System.out.println("⏳ Waiting for browser slot... (Thread: " + Thread.currentThread().getName() + 
                                ", " + waitingThreads + " browsers currently in use)");
                    } else {
                        System.out.println("📊 Browser slots available: " + availablePermits + "/4 (Thread: " + 
                                Thread.currentThread().getName() + ")");
                    }
                    
                    // Acquire permit (wait if all 4 slots are taken)
                    browserSemaphore.acquire();
                    hasPermit.set(true);
                    System.out.println("✅ Acquired browser slot (Thread: " + Thread.currentThread().getName() + 
                            ", Available slots: " + browserSemaphore.availablePermits() + "/4)");
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    throw new RuntimeException("Thread interrupted while waiting for browser slot", e);
                }
            }

            try {
                // Try to get browser from pool first (if Spring context is available)
                // ❌ DO NOT use browser pool when running on Selenium Grid
                if (!isLocalProfile || useLocalGrid || customGridUrl != null) {
                    System.out.println("ℹ️ Skipping BrowserPool usage for Selenium Grid execution");
                } else {
                    if (com.gallopade.automation.util.BrowserPoolAccessor.isPoolAvailable()) {
                        try {
                            WebDriver poolBrowser =
                                    com.gallopade.automation.util.BrowserPoolAccessor.acquireBrowser();
                            if (poolBrowser != null) {
                                driver.set(poolBrowser);
                                return poolBrowser;
                            }
                        } catch (Exception ignored) {}
                    }
                }
                initializeWebDriver();
            } catch (Exception e) {
                // If browser initialization fails, release the semaphore permit
                if (hasPermit.get() != null && hasPermit.get()) {
                    browserSemaphore.release();
                    hasPermit.set(false);
                    System.out.println("❌ Browser initialization failed, released semaphore permit (Thread: " + 
                            Thread.currentThread().getName() + ")");
                }
                throw e;
            }
        }

        return driver.get();
    }

    /**
     * Validates if the WebDriver instance is still valid and usable
     * @param driver The WebDriver instance to validate
     * @return true if driver is valid, false otherwise
     */
    public static boolean isDriverValid(WebDriver driver) {
        if (driver == null) {
            return false;
        }
        
        try {
            // Try to get window handles - this will throw an exception if driver is closed/invalid
            // This is the most reliable check for tab crashes
            java.util.Set<String> handles = driver.getWindowHandles();
            
            // If we get here, driver is responsive - check if handles are empty (tab might have crashed)
            if (handles == null || handles.isEmpty()) {
                System.out.println("⚠️ Driver has no window handles - tab may have crashed");
                return false;
            }
            
            // Additional check: verify session is not crashed by trying a lightweight command
            try {
                // Try to get title - lightweight operation that will fail if tab crashed
                driver.getTitle();
                return true;
            } catch (org.openqa.selenium.WebDriverException e) {
                // Check for tab crash errors
                String errorMsg = e.getMessage() != null ? e.getMessage().toLowerCase() : "";
                if (errorMsg.contains("tab crashed") || 
                    errorMsg.contains("session deleted") ||
                    errorMsg.contains("no such session") ||
                    errorMsg.contains("chrome not reachable") ||
                    errorMsg.contains("target frame detached") ||
                    errorMsg.contains("session not created") ||
                    errorMsg.contains("invalid session id")) {
                    System.out.println("⚠️ Driver tab crashed or session invalid: " + e.getMessage());
                    return false;
                }
                // Other exceptions might be recoverable - try one more check
                try {
                    driver.getWindowHandles(); // Second check
                    return true;
                } catch (Exception e2) {
                    return false;
                }
            }
        } catch (org.openqa.selenium.WebDriverException e) {
            String errorMsg = e.getMessage() != null ? e.getMessage().toLowerCase() : "";
            if (errorMsg.contains("tab crashed") || 
                errorMsg.contains("session deleted") ||
                errorMsg.contains("no such session") ||
                errorMsg.contains("chrome not reachable") ||
                errorMsg.contains("target frame detached") ||
                errorMsg.contains("session not created") ||
                errorMsg.contains("invalid session id") ||
                errorMsg.contains("connection refused") ||
                errorMsg.contains("connection reset")) {
                System.out.println("⚠️ Driver validation failed - tab crashed: " + e.getMessage());
                return false;
            }
            System.out.println("⚠️ Driver validation failed with recoverable error: " + e.getMessage());
            return false; // Be conservative - if we can't verify, assume invalid
        } catch (Exception e) {
            System.out.println("⚠️ Driver validation failed: " + e.getMessage());
            return false;
        }
    }


    private static void initializeWebDriver() {
        try {
            // Ensure any existing driver is cleaned up first
            WebDriver existingDriver = driver.get();
            if (existingDriver != null) {
                System.out.println("Cleaning up existing driver before reinitialization...");
                try {
                    existingDriver.quit();
                } catch (Exception e) {
                    System.out.println("Error cleaning up existing driver: " + e.getMessage());
                }
                driver.remove();
            }

            ChromeOptions chromeOptions = getOptions();

            // Check if we should use Selenium Grid (either remote profile OR local profile with local Grid enabled)
            boolean shouldUseGrid = !isLocalProfile || useLocalGrid || customGridUrl != null;

            if (isLocalProfile && !shouldUseGrid) {
                // For local execution without Grid, we need WebDriverManager to download/manage ChromeDriver
                System.out.println("Local profile detected - setting up ChromeDriver via WebDriverManager");
                WebDriverManager.chromedriver().setup();
                // WebDriverManager handles the driver path automatically, no need to set system property
                driver.set(new ChromeDriver(chromeOptions));
                System.out.println("Using LOCAL ChromeDriver");
            } else {
                // For RemoteWebDriver (Selenium Grid), we DON'T need WebDriverManager
                // The Selenium Grid already has ChromeDriver installed
                // WebDriverManager setup here causes unnecessary delays and can hang on subsequent threads
                if (useLocalGrid || customGridUrl != null) {
                    System.out.println("Local profile with Selenium Grid enabled - connecting to local Grid");
                } else {
                    System.out.println("Remote profile detected - connecting to Selenium Grid (skipping WebDriverManager)");
                }
                System.out.println("Thread: " + Thread.currentThread().getName() + " - Connecting to Selenium Grid");

                // Build Selenium Hub URLs array
                String[] seleniumHubUrls;

                if (customGridUrl != null) {
                    // Use custom URL if provided
                    System.out.println("Using custom Selenium Grid URL: " + customGridUrl);
                    seleniumHubUrls = new String[]{
                            customGridUrl,
                            customGridUrl + "/wd/hub"  // Also try legacy endpoint
                    };
                } else if (useLocalGrid) {
                    // For local Grid (Docker), use localhost URLs
                    System.out.println("🐳 Using Docker Selenium Grid URLs (localhost:4444)");
                    System.out.println("   Make sure Docker container is running: docker ps | grep selenium");
                    seleniumHubUrls = new String[]{
                            "http://localhost:4444",  // Selenium 4.x Grid endpoint (Docker)
                            "http://localhost:4444/wd/hub",  // Legacy endpoint (Docker)
                            "http://127.0.0.1:4444",  // Alternative localhost
                            "http://127.0.0.1:4444/wd/hub"  // Alternative localhost legacy
                    };
                } else {
                    // For remote profile, use remote URLs
                    // Reordered: FQDN URLs work best, try them first to avoid Grid full errors
                    seleniumHubUrls = new String[]{
                            "http://selenium-standalone.gallopade-staging.svc.cluster.local:4444",  // Selenium 4.x Grid (FQDN) - MOST RELIABLE
                            "http://selenium-standalone.gallopade-staging.svc.cluster.local:4444/wd/hub",  // Legacy (FQDN)
                            "http://selenium-standalone.gallopade-staging:4444",  // Selenium 4.x Grid (with namespace) - fallback
                            "http://selenium-standalone.gallopade-staging:4444/wd/hub",  // Legacy (with namespace) - fallback
                            "http://selenium-standalone:4444",  // Selenium 4.x Grid endpoint (same namespace) - last resort
                            "http://selenium-standalone:4444/wd/hub"  // Legacy endpoint (same namespace) - last resort
                    };
                }

                // Retry configuration
                int maxRetriesPerUrl = 3; // Number of retries per URL format
                int retryDelayMs = 2000; // Delay between retries (2 seconds)
                RemoteWebDriver remoteDriver = null;
                Exception lastException = null;
                String lastAttemptedUrl = seleniumHubUrls[0];

                System.out.println("Attempting to connect to Selenium Grid (Selenium 4.1) - will try " +
                        seleniumHubUrls.length + " URL formats with " + maxRetriesPerUrl + " retries per URL");

                // Check Grid slot status before attempting connection
                for (String hubUrl : seleniumHubUrls) {
                    if (isGridReachable(hubUrl)) {
                        checkAndDisplayGridSlotStatus(hubUrl);
                        break; // Only check the first reachable URL
                    }
                }

                // Set HTTP client factory for Selenium 4.x with improved connection handling
                System.setProperty("webdriver.http.factory", "jdk-http-client");
                // Set connection timeout for HTTP client (30 seconds - increased for Docker Grid)
                System.setProperty("webdriver.http.timeout", "30000");
                // Set read timeout for HTTP client (120 seconds - increased to prevent InterruptedException)
                // This prevents connections from being interrupted during long operations
                System.setProperty("webdriver.http.readtimeout", "120000");

                // Try each URL format with retries
                for (int urlIndex = 0; urlIndex < seleniumHubUrls.length; urlIndex++) {
                    String seleniumHubUrl = seleniumHubUrls[urlIndex];
                    lastAttemptedUrl = seleniumHubUrl;

                    // Quick connectivity check before attempting session creation
                    if (!isGridReachable(seleniumHubUrl)) {
                        System.out.println("Grid not reachable at " + seleniumHubUrl + ", trying next URL...");
                        continue; // Try next URL format
                    }

                    // Retry loop for each URL format
                    boolean connectionSucceeded = false;
                    for (int retryAttempt = 1; retryAttempt <= maxRetriesPerUrl; retryAttempt++) {
                        try {
                            if (retryAttempt > 1) {
                                System.out.println("Retry attempt " + retryAttempt + "/" + maxRetriesPerUrl + 
                                        " for " + seleniumHubUrl + " (waiting " + retryDelayMs + "ms before retry)...");
                                Thread.sleep(retryDelayMs);
                            } else {
                                System.out.println("Connection attempt to " + seleniumHubUrl + " (Selenium 4.1)");
                            }
                            
                            System.out.println("Connecting to browser on remote instance...");
                            System.out.println("   Grid URL: " + seleniumHubUrl);
                            System.out.println("   HTTP timeout: 30s, Read timeout: 120s");

                            // Create RemoteWebDriver directly - HTTP client timeouts are handled by system properties
                            // No need for CompletableFuture wrapper - it was causing timeout issues
                            long startTime = System.currentTimeMillis();
                            try {
                                // Direct connection - Selenium's HTTP client will use the timeout properties we set
                                remoteDriver = new RemoteWebDriver(new URL(seleniumHubUrl), chromeOptions);
                            } catch (org.openqa.selenium.SessionNotCreatedException e) {
                                String errorMsg = e.getMessage() != null ? e.getMessage() : "Unknown error";
                                if (errorMsg.contains("no available slots") || errorMsg.contains("Could not start")) {
                                    throw new RuntimeException("Grid has no available slots - all browsers are busy. " +
                                            "Wait for other tests to complete or reduce concurrent sessions.", e);
                                }
                                throw new RuntimeException("Failed to create browser session: " + errorMsg, e);
                            } catch (Exception e) {
                                String errorMsg = e.getMessage() != null ? e.getMessage() : e.getClass().getSimpleName();
                                if (errorMsg.contains("timeout") || errorMsg.contains("TimeoutException")) {
                                    throw new RuntimeException("Connection timeout - Grid may be slow or overloaded. " +
                                            "Try reducing concurrent sessions or increasing Grid resources. Error: " + errorMsg, e);
                                }
                                throw new RuntimeException("Failed to connect to Grid: " + errorMsg, e);
                            }
                            
                            long connectionTime = System.currentTimeMillis() - startTime;
                            System.out.println("✅ Browser session created in " + connectionTime + "ms");

                            // Configure timeouts using Selenium 4.x Duration API
                            remoteDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
                            remoteDriver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(300)); // 5 minutes
                            remoteDriver.manage().timeouts().scriptTimeout(Duration.ofSeconds(30));
                            
                            // Verify session is active with a lightweight command
                            try {
                                remoteDriver.getWindowHandles(); // Lightweight command to verify session
                                System.out.println("✅ Session verified and active");
                            } catch (Exception e) {
                                System.out.println("⚠️ Could not verify session: " + e.getMessage());
                                // Don't fail - session might still be valid, continue
                            }

                            System.out.println("✅ Successfully connected to Selenium Grid using: " + seleniumHubUrl +
                                    " (connection took " + connectionTime + "ms" + 
                                    (retryAttempt > 1 ? ", attempt " + retryAttempt : "") + ")");
                            System.out.println("Session ID: " + remoteDriver.getSessionId() + " (Selenium 4.1)");
                            connectionSucceeded = true;
                            break; // Success - exit retry loop
                        } catch (Exception e) {
                            lastException = e;
                            String errorMsg = e.getMessage() != null ? e.getMessage() : e.getClass().getSimpleName();
                            
                            // Check for timeout specifically
                            boolean isTimeout = errorMsg.contains("timeout") || 
                                              errorMsg.contains("TimeoutException") ||
                                              e instanceof java.util.concurrent.TimeoutException;
                            
                            if (isTimeout) {
                                System.err.println("❌ Connection timeout to " + seleniumHubUrl + 
                                                " (attempt " + retryAttempt + "/" + maxRetriesPerUrl + 
                                                ") - Browser instance on remote server may be unreachable or busy");
                                System.err.println("   This can happen when browser is on a different instance than test execution");
                            } else {
                                System.err.println("❌ Connection to " + seleniumHubUrl + " failed (attempt " + 
                                                retryAttempt + "/" + maxRetriesPerUrl + "): " + errorMsg);
                            }

                            // Track error type for logging
                            boolean isGridFull = errorMsg.contains("Could not start a new session") ||
                                    errorMsg.contains("no available slots") ||
                                    errorMsg.contains("Session creation failed");

                            if (isGridFull) {
                                System.out.println("⚠️ Grid session creation failed - may be due to no available slots");
                            }

                            // If this was the last retry for this URL, log and continue to next URL
                            if (retryAttempt == maxRetriesPerUrl) {
                                System.out.println("⚠️ All " + maxRetriesPerUrl + " retry attempts failed for " + seleniumHubUrl);
                                if (urlIndex < seleniumHubUrls.length - 1) {
                                    System.out.println("⚠️ Trying next URL format...");
                                }
                            }
                            
                            remoteDriver = null;
                        }
                    }

                    // If connection succeeded, break out of URL loop
                    if (connectionSucceeded && remoteDriver != null) {
                        break;
                    }
                }

                if (remoteDriver == null) {
                    // Log diagnostic information
                    try {
                        String hostname = java.net.InetAddress.getLocalHost().getHostName();
                        String hostAddress = java.net.InetAddress.getLocalHost().getHostAddress();
                        System.out.println("Diagnostic Info - Hostname: " + hostname + ", IP: " + hostAddress);
                        System.out.println("Diagnostic Info - Pod: " + System.getenv("HOSTNAME"));

                        // Try DNS resolution for all service names
                        String[] serviceNames = {
                                "selenium-standalone",
                                "selenium-standalone.gallopade-staging",
                                "selenium-standalone.gallopade-staging.svc.cluster.local"
                        };
                        for (String serviceName : serviceNames) {
                            try {
                                java.net.InetAddress addr = java.net.InetAddress.getByName(serviceName);
                                System.out.println("DNS Resolution - " + serviceName + " resolves to: " + addr.getHostAddress());
                            } catch (Exception e) {
                                System.out.println("DNS Resolution - Could not resolve " + serviceName + ": " + e.getMessage());
                            }
                        }
                    } catch (Exception e) {
                        System.out.println("Could not gather diagnostic info: " + e.getMessage());
                    }

                    String errorMsg = "❌ Failed to connect to Selenium Grid after trying " + seleniumHubUrls.length +
                            " URL formats with " + maxRetriesPerUrl + " retries each (" + 
                            (seleniumHubUrls.length * maxRetriesPerUrl) + " total attempts). " +
                            "Last attempted: " + lastAttemptedUrl + ". " +
                            "Please verify that selenium-standalone service is running and accessible in namespace 'gallopade-staging'. " +
                            "Last error: " + (lastException != null ? lastException.getMessage() : "Unknown error");
                    System.err.println(errorMsg);
                    if (lastException != null) {
                        lastException.printStackTrace();
                    }
                    throw new RuntimeException(errorMsg, lastException);
                }

                driver.set(remoteDriver);
                System.out.println("Using RemoteWebDriver for staging/other profile");
            }

            WebDriver newDriver = driver.get();
            if (newDriver == null) {
                throw new RuntimeException("Failed to initialize WebDriver - driver is null after initialization");
            }

            // Configure driver using Selenium 4.x APIs
            newDriver.manage().window().maximize();
            newDriver.manage().deleteAllCookies();
            newDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
            newDriver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(120));
            newDriver.manage().timeouts().scriptTimeout(Duration.ofSeconds(30)); // Script timeout

            System.out.println("WebDriver initialized successfully for thread: " + Thread.currentThread().getName());
        } catch (Exception e) {
            System.err.println("❌ Failed to initialize WebDriver: " + e.getMessage());
            e.printStackTrace();
            
            // CRITICAL: Clean up on failure to prevent resource leaks
            driver.remove();
            
            // Release semaphore permit if it was acquired
            if (hasPermit.get() != null && hasPermit.get()) {
                try {
                    browserSemaphore.release();
                    hasPermit.set(false);
                    System.out.println("🔄 Released semaphore permit after initialization failure");
                } catch (Exception releaseEx) {
                    System.err.println("⚠️ Error releasing semaphore after failure: " + releaseEx.getMessage());
                }
            }
            
            throw new RuntimeException("WebDriver initialization failed - driver connection lost. " +
                    "This may happen if Grid session was terminated. The next test will retry with a fresh connection.", e);
        }
    }

    /**
     * Closes the WebDriver for the current thread only.
     * This method is thread-safe and only affects the calling thread's driver instance.
     *
     * IMPORTANT: Each thread manages its own driver lifecycle independently.
     * Closing one thread's driver will NOT affect other threads' drivers.
     *
     * After each test case completes, the browser is closed/quit to ensure clean state.
     */
    public static void closeDriver() {
        String threadName = Thread.currentThread().getName();
        WebDriver currentDriver = driver.get();

        if (currentDriver != null) {
            try {
                // Validate driver is still valid before attempting to release/close
                if (isDriverValid(currentDriver)) {
                    System.out.println("Closing browser after test case completion for thread: " + threadName);

                    // Always quit the browser to free Grid session (don't reuse to prevent session leaks)
                    // This ensures Grid sessions are properly released after each test
                    try {
                        // Get session ID for logging before quitting
                        String sessionId = null;
                        try {
                            if (currentDriver instanceof org.openqa.selenium.remote.RemoteWebDriver) {
                                sessionId = ((org.openqa.selenium.remote.RemoteWebDriver) currentDriver).getSessionId().toString();
                            }
                        } catch (Exception e) {
                            // Session ID not available
                        }

                        // Quit the browser to free Grid session
                        // IMPORTANT: quit() terminates the Grid session completely
                        // This ensures clean state for next test case
                        currentDriver.quit();
                        System.out.println("✅ Browser session closed/quit after test case (thread: " + threadName +
                                (sessionId != null ? ", session: " + sessionId : "") + ")");

                        // Delay to allow Grid to fully clean up the session before next test starts
                        // This prevents "session not found" or connection errors in subsequent tests
                        Thread.sleep(2000); // 2 second delay for Grid session cleanup
                        System.out.println("✅ Grid session cleanup delay completed");

                    } catch (Exception e) {
                        System.err.println("⚠️ Error quitting browser: " + e.getMessage());
                        // Try to close all windows as fallback
                        try {
                            currentDriver.close();
                            System.out.println("✅ Browser window closed (fallback)");
                        } catch (Exception closeEx) {
                            System.err.println("⚠️ Error closing browser window: " + closeEx.getMessage());
                        }
                    }
                } else {
                    // Driver is invalid/crashed - still try to quit to free Grid slot
                    System.out.println("⚠️ Driver for thread " + threadName + " is invalid/crashed - attempting cleanup");
                    try {
                        currentDriver.quit();
                        System.out.println("✅ Crashed browser session closed");
                    } catch (Exception e) {
                        System.out.println("⚠️ Could not quit crashed browser (expected): " + e.getMessage());
                        // This is expected for crashed browsers - Grid will clean it up
                    }
                }
            } catch (Exception e) {
                System.err.println("❌ Error during WebDriver cleanup for thread " + threadName + ": " + e.getMessage());
                // Try to force quit as last resort
                try {
                    currentDriver.quit();
                } catch (Exception quitEx) {
                    System.err.println("❌ Failed to force quit browser: " + quitEx.getMessage());
                }
            } finally {
                // CRITICAL: Remove from ThreadLocal FIRST before releasing semaphore
                // This ensures the driver reference is cleared before next test can acquire permit
                driver.remove();
                System.out.println("✅ WebDriver removed from ThreadLocal for thread: " + threadName);
                
                // Clear the permit flag
                hasPermit.remove();
                
                // Release semaphore permit to allow next waiting test to get a browser
                // This must be in finally block to ensure it's always released, even if quit() failed
                // IMPORTANT: Release AFTER ThreadLocal is cleared to prevent race conditions
                try {
                    browserSemaphore.release();
                    int availableSlots = browserSemaphore.availablePermits();
                    System.out.println("🔄 Released browser slot (Thread: " + threadName + 
                            ", Available slots: " + availableSlots + "/4) - Next waiting test can now start");
                } catch (Exception e) {
                    System.err.println("⚠️ Error releasing semaphore for thread " + threadName + ": " + e.getMessage());
                    // Don't throw - semaphore release failure shouldn't block cleanup
                }
            }
        } else {
            System.out.println("ℹ️ No WebDriver found for thread: " + threadName + " (already closed or never initialized)");
            // Always clear ThreadLocal to ensure clean state
            driver.remove();
            
            // Release semaphore if we have a permit (in case driver was cleared but permit wasn't)
            // This ensures the slot is freed for the next test
            if (hasPermit.get() != null && hasPermit.get()) {
                try {
                    browserSemaphore.release();
                    hasPermit.remove();
                    int availableSlots = browserSemaphore.availablePermits();
                    System.out.println("🔄 Released semaphore permit (no driver found) - Thread: " + threadName + 
                            ", Available slots: " + availableSlots + "/4");
                } catch (Exception e) {
                    System.err.println("⚠️ Error releasing semaphore (no driver): " + e.getMessage());
                    hasPermit.remove(); // Clear flag even if release failed
                }
            } else {
                // No permit to release - ensure ThreadLocal is cleared
                hasPermit.remove();
                System.out.println("ℹ️ No permit to release - Thread: " + threadName);
            }
        }
    }

    /**
     * Releases semaphore permit but keeps browser connection open
     * This allows next test case to start while reusing the browser on same thread
     * IMPORTANT: Browser stays in ThreadLocal, only semaphore is released
     */
    public static void releaseSemaphoreButKeepBrowser() {
        String threadName = Thread.currentThread().getName();
        WebDriver currentDriver = driver.get();
        
        // Only release semaphore if we have a permit and a valid driver
        if (hasPermit.get() != null && hasPermit.get() && currentDriver != null && isDriverValid(currentDriver)) {
            try {
                browserSemaphore.release();
                hasPermit.set(false); // Clear permit flag but keep driver
                int availableSlots = browserSemaphore.availablePermits();
                System.out.println("🔄 Released semaphore permit (browser stays open) - Thread: " + threadName + 
                        ", Available slots: " + availableSlots + "/4");
                System.out.println("✅ Browser connection remains active for potential reuse on thread: " + threadName);
            } catch (Exception e) {
                System.err.println("⚠️ Error releasing semaphore (keeping browser open): " + e.getMessage());
            }
        } else {
            // If no permit or invalid driver, nothing to release
            if (currentDriver == null || !isDriverValid(currentDriver)) {
                System.out.println("ℹ️ No valid driver to keep open - semaphore already released or driver invalid");
            }
        }
    }
    
    /**
     * Forcefully releases semaphore permit - used as fallback to ensure slot is always freed
     * This should only be called when normal cleanup fails
     */
    public static void forceReleaseSemaphore() {
        String threadName = Thread.currentThread().getName();
        try {
            // Clear ThreadLocal first
            driver.remove();
            hasPermit.remove();
            
            // Release semaphore - this will work even if we've already released it
            // (Semaphore allows releasing more than acquired, but we track it with hasPermit)
            browserSemaphore.release();
            int availableSlots = browserSemaphore.availablePermits();
            System.out.println("🔄 Force released semaphore permit (fallback) - Thread: " + threadName + 
                    ", Available slots: " + availableSlots + "/4");
        } catch (Exception e) {
            System.err.println("❌ Error in force semaphore release: " + e.getMessage());
        }
    }
    
    /**
     * Forcefully resets the driver state - useful for cleanup between test runs
     */
    public static void resetDriver() {
        closeDriver();
        // Ensure ThreadLocal is cleared
        driver.remove();
    }
    
    /**
     * Cleans up all ThreadLocal drivers across all threads
     * This should be called in @AfterClass when all test cases are complete
     * IMPORTANT: This closes all browser connections and releases semaphore permits
     */
    public static void cleanupAllDrivers() {
        System.out.println("========================================");
        System.out.println("Cleaning up all WebDriver instances - all test cases completed");
        System.out.println("Thread: " + Thread.currentThread().getName());
        System.out.println("========================================");
        try {
            // Close driver for current thread - this will:
            // 1. Quit the browser (terminate Grid session)
            // 2. Remove from ThreadLocal
            // 3. Release semaphore permit
            closeDriver();
            System.out.println("✅ WebDriver cleanup completed for thread: " + Thread.currentThread().getName());
        } catch (Exception e) {
            System.err.println("⚠️ Error during driver cleanup: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Checks and cleans up any stale/invalid driver without initializing a new one
     * Useful for @Before hooks to ensure clean state
     * IMPORTANT: Only cleans up INVALID drivers - valid drivers are kept open for reuse
     */
    public static void validateAndCleanStaleDriver() {
        WebDriver currentDriver = driver.get();
        if (currentDriver != null) {
            try {
                // Only clean up if driver is invalid/stale
                if (!isDriverValid(currentDriver)) {
                    System.out.println("⚠️ Detected stale/invalid driver in @Before hook for thread: " + 
                            Thread.currentThread().getName() + " - cleaning up...");
                    try {
                        currentDriver.quit();
                        System.out.println("✅ Quit stale driver in @Before hook");
                    } catch (Exception e) {
                        System.out.println("⚠️ Error quitting stale driver in @Before: " + e.getMessage());
                    }
                    
                    // Remove from ThreadLocal
                    driver.remove();
                    
                    // Release semaphore permit if it was held
                    if (hasPermit.get() != null && hasPermit.get()) {
                        browserSemaphore.release();
                        hasPermit.set(false);
                        System.out.println("🔄 Released semaphore permit for stale driver");
                    }
                } else {
                    // Driver is valid - keep it open for reuse across test cases
                    System.out.println("✅ Valid driver found - reusing browser connection for thread: " + 
                            Thread.currentThread().getName());
                }
            } catch (Exception e) {
                System.out.println("⚠️ Error validating driver in @Before: " + e.getMessage());
                // If validation fails, assume driver is stale and clean up
                try {
                    driver.remove();
                    if (hasPermit.get() != null && hasPermit.get()) {
                        browserSemaphore.release();
                        hasPermit.set(false);
                    }
                } catch (Exception cleanupEx) {
                    System.out.println("⚠️ Error during cleanup: " + cleanupEx.getMessage());
                }
            }
        } else {
            System.out.println("ℹ️ No existing driver found - will create new one when needed for thread: " + 
                    Thread.currentThread().getName());
        }
    }

    /**
     * Checks and displays Selenium Grid slot status (running vs available)
     * Queries the Grid status endpoint to get slot information
     */
    private static void checkAndDisplayGridSlotStatus(String hubUrl) {
        try {
            // Build status URL - Selenium 4.x uses /status endpoint
            String baseUrl = hubUrl.replace("/wd/hub", "");
            if (!baseUrl.endsWith("/")) {
                baseUrl += "/";
            }
            String statusUrl = baseUrl + "status";
            
            // Query Grid status endpoint
            java.net.URL url = new java.net.URL(statusUrl);
            java.net.HttpURLConnection connection = (java.net.HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setConnectTimeout(5000);
            connection.setReadTimeout(5000);
            connection.setRequestProperty("Accept", "application/json");
            
            int responseCode = connection.getResponseCode();
            if (responseCode == 200) {
                // Read JSON response
                java.io.BufferedReader reader = new java.io.BufferedReader(
                    new java.io.InputStreamReader(connection.getInputStream()));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
                reader.close();
                connection.disconnect();
                
                // Parse JSON to extract slot information
                String jsonResponse = response.toString();
                parseAndDisplaySlotStatus(jsonResponse, hubUrl);
            } else {
                System.out.println("⚠️ Could not query Grid status (HTTP " + responseCode + ")");
            }
        } catch (Exception e) {
            System.out.println("⚠️ Could not check Grid slot status: " + e.getMessage());
        }
    }
    
    /**
     * Parses Grid status JSON and displays slot information
     * Selenium Grid 4.x status JSON structure:
     * { "value": { "ready": true, "nodes": [...], "slots": { "active": X, "idle": Y } } }
     */
    private static void parseAndDisplaySlotStatus(String jsonResponse, String hubUrl) {
        try {
            int totalSlots = 0;
            int runningSlots = 0;
            int availableSlots = 0;
            int totalNodes = 0;
            
            // Extract slot information from JSON - look for "slots" object
            // Pattern: "slots": { "active": number, "idle": number }
            java.util.regex.Pattern slotsPattern = java.util.regex.Pattern.compile(
                "\"slots\"\\s*:\\s*\\{\\s*\"active\"\\s*:\\s*(\\d+)\\s*,\\s*\"idle\"\\s*:\\s*(\\d+)");
            java.util.regex.Matcher slotsMatcher = slotsPattern.matcher(jsonResponse);
            
            if (slotsMatcher.find()) {
                runningSlots = Integer.parseInt(slotsMatcher.group(1));
                availableSlots = Integer.parseInt(slotsMatcher.group(2));
                totalSlots = runningSlots + availableSlots;
            } else {
                // Fallback: try separate patterns
                java.util.regex.Pattern activePattern = java.util.regex.Pattern.compile("\"active\"\\s*:\\s*(\\d+)");
                java.util.regex.Pattern idlePattern = java.util.regex.Pattern.compile("\"idle\"\\s*:\\s*(\\d+)");
                
                java.util.regex.Matcher activeMatcher = activePattern.matcher(jsonResponse);
                java.util.regex.Matcher idleMatcher = idlePattern.matcher(jsonResponse);
                
                if (activeMatcher.find()) {
                    runningSlots = Integer.parseInt(activeMatcher.group(1));
                }
                if (idleMatcher.find()) {
                    availableSlots = Integer.parseInt(idleMatcher.group(1));
                }
                totalSlots = runningSlots + availableSlots;
            }
            
            // Extract node count - count node objects in nodes array
            if (jsonResponse.contains("\"nodes\"")) {
                // Find the nodes array and count node entries
                int nodesStart = jsonResponse.indexOf("\"nodes\"");
                if (nodesStart >= 0) {
                    int arrayStart = jsonResponse.indexOf("[", nodesStart);
                    if (arrayStart >= 0) {
                        int arrayEnd = jsonResponse.indexOf("]", arrayStart);
                        if (arrayEnd > arrayStart) {
                            String nodesArray = jsonResponse.substring(arrayStart, arrayEnd);
                            // Count node objects by counting "{" that represent node entries
                            // More accurate: count occurrences of node identifiers
                            totalNodes = (int) nodesArray.chars()
                                .filter(ch -> ch == '{')
                                .count();
                        }
                    }
                }
            }
            
            // Display slot status - formatted for monitoring screen visibility
            StringBuilder slotStatusMsg = new StringBuilder();
            slotStatusMsg.append("\n═══════════════════════════════════════════════════════════════\n");
            slotStatusMsg.append("📊 Selenium Grid Slot Status: ").append(hubUrl).append("\n");
            slotStatusMsg.append("═══════════════════════════════════════════════════════════════\n");
            
            if (totalNodes > 0) {
                slotStatusMsg.append("Total Nodes: ").append(totalNodes).append("\n");
            }
            if (totalSlots > 0) {
                slotStatusMsg.append("Total Slots: ").append(totalSlots).append("\n");
                slotStatusMsg.append("Running Slots: ").append(runningSlots).append(" (active sessions)\n");
                slotStatusMsg.append("Available Slots: ").append(availableSlots).append(" (idle/ready)\n");
                
                double utilizationPercent = (runningSlots * 100.0) / totalSlots;
                slotStatusMsg.append("Grid Utilization: ").append(String.format("%.1f", utilizationPercent)).append("%\n");
                
                if (availableSlots == 0) {
                    slotStatusMsg.append("⚠️ WARNING: No available slots - Grid is full!\n");
                    slotStatusMsg.append("   This may cause connection failures. Wait for sessions to complete.\n");
                } else if (availableSlots < 2) {
                    slotStatusMsg.append("⚠️ WARNING: Only ").append(availableSlots).append(" slot(s) available - Grid nearly full\n");
                } else {
                    slotStatusMsg.append("✅ Grid has capacity - ").append(availableSlots).append(" slot(s) available\n");
                }
                
                // Create a compact summary line for status message
                String compactStatus = String.format("Grid Status: %d running, %d available (%.0f%% utilized)", 
                    runningSlots, availableSlots, utilizationPercent);
                slotStatusMsg.append("═══════════════════════════════════════════════════════════════\n");
                
                // Print to console (will be captured in logs for monitoring screen)
                System.out.println(slotStatusMsg.toString());
                
                // Also print compact version that will appear in status messages
                System.out.println("GRID_SLOT_STATUS: " + compactStatus);
            } else {
                slotStatusMsg.append("⚠️ Could not determine slot information from Grid status\n");
                slotStatusMsg.append("   Grid may be using a different status format\n");
                slotStatusMsg.append("═══════════════════════════════════════════════════════════════\n");
                System.out.println(slotStatusMsg.toString());
            }
            
        } catch (Exception e) {
            System.out.println("⚠️ Error parsing Grid status: " + e.getMessage());
            System.out.println("   Continuing with connection attempt...\n");
        }
    }

    /**
     * Quick check if Grid endpoint is reachable (TCP connection test)
     */
    private static boolean isGridReachable(String hubUrl) {
        try {
            // Extract host and port from URL
            URL url = new URL(hubUrl);
            String host = url.getHost();
            int port = url.getPort() > 0 ? url.getPort() : 4444;

            // Try TCP connection (quick check)
            try (java.net.Socket socket = new java.net.Socket()) {
                socket.connect(new java.net.InetSocketAddress(host, port), 2000); // 2 second timeout
                socket.close();
                System.out.println("Grid endpoint " + host + ":" + port + " is reachable");
                return true;
            }
        } catch (java.net.ConnectException e) {
            System.out.println("Grid endpoint " + hubUrl + " not reachable: " + e.getMessage());
            return false;
        } catch (java.net.SocketTimeoutException e) {
            System.out.println("Grid endpoint " + hubUrl + " connection timeout: " + e.getMessage());
            return false;
        } catch (Exception e) {
            System.out.println("Grid endpoint " + hubUrl + " check failed: " + e.getMessage());
            return false;
        }
    }

    private static ChromeOptions getOptions() {
        ChromeOptions chromeOptions = getChromeOptions();
        // Set page load strategy to avoid hanging on slow pages
        chromeOptions.setPageLoadStrategy(org.openqa.selenium.PageLoadStrategy.NORMAL);
        
        // IMPORTANT: Set session timeout to prevent Grid from timing out inactive sessions
        // This tells the Grid to keep the session alive for up to 30 minutes (1800 seconds)
        // This prevents "session timed out due to inactivity" errors
        chromeOptions.setCapability("se:sessionTimeout", 1800); // 30 minutes
        chromeOptions.setCapability("se:sessionRequestTimeout", 300); // 5 minutes to create session
        
        return chromeOptions;
    }

    @NotNull
    private static ChromeOptions getChromeOptions() {
        ChromeOptions chromeOptions = new ChromeOptions();
        chromeOptions.addArguments("--remote-allow-origins=*");
        
        // DOCKER-SPECIFIC: Enable headless mode for Docker Grid (more stable, less resource usage)
        // Headless mode is more stable in Docker environments and prevents rendering crashes
        boolean useLocalGrid = Boolean.parseBoolean(System.getProperty("selenium.grid.use.local", "false"));
        String customGridUrl = System.getProperty("selenium.grid.url");
        if (useLocalGrid || customGridUrl != null) {
            // Running on Docker Grid - use headless for stability
            chromeOptions.addArguments("--headless=new");
            System.out.println("🐳 Docker Grid detected - enabling headless mode for stability");
        }
        
        // CRITICAL: Docker/Grid stability flags - prevent tab crashes
        chromeOptions.addArguments("--no-sandbox");
        chromeOptions.addArguments("--disable-dev-shm-usage");
        chromeOptions.addArguments("--disable-setuid-sandbox");
        chromeOptions.addArguments("--disable-gpu");
        chromeOptions.addArguments("--disable-software-rasterizer");
        
        // Memory management - critical for Docker environments
        chromeOptions.addArguments("--disable-extensions");
        chromeOptions.addArguments("--disable-background-timer-throttling");
        chromeOptions.addArguments("--disable-backgrounding-occluded-windows");
        chromeOptions.addArguments("--disable-renderer-backgrounding");
        chromeOptions.addArguments("--disable-ipc-flooding-protection");
        chromeOptions.addArguments("--disable-background-networking");
        chromeOptions.addArguments("--disable-sync");
        chromeOptions.addArguments("--metrics-recording-only");
        chromeOptions.addArguments("--mute-audio");
        chromeOptions.addArguments("--disable-default-apps");
        chromeOptions.addArguments("--disable-component-extensions-with-background-pages");
        chromeOptions.addArguments("--disable-plugins");
        chromeOptions.addArguments("--disable-plugins-discovery");
        chromeOptions.addArguments("--disable-preconnect");
        
        // Renderer process limits - prevent crashes from too many processes
        // Note: --single-process can cause issues, so we use renderer-process-limit instead
        chromeOptions.addArguments("--renderer-process-limit=2"); // Limit renderer processes (2 is safer than 1)
        // Memory limits for renderer processes
        chromeOptions.addArguments("--js-flags=--max-old-space-size=2048"); // Limit JavaScript heap size
        
        // Stability flags to prevent crashes
        chromeOptions.addArguments("--disable-blink-features=AutomationControlled");
        chromeOptions.addArguments("--disable-infobars");
        chromeOptions.addArguments("--disable-notifications");
        chromeOptions.addArguments("--disable-popup-blocking");
        chromeOptions.addArguments("--disable-features=TranslateUI,VizDisplayCompositor");
        chromeOptions.addArguments("--window-size=1920,1080");
        
        // Additional Docker-specific stability flags
        chromeOptions.addArguments("--disable-web-security");
        chromeOptions.addArguments("--allow-running-insecure-content");
        chromeOptions.addArguments("--disable-site-isolation-trials");
        chromeOptions.addArguments("--disable-features=IsolateOrigins,site-per-process");
        
        // Crash recovery and stability
        chromeOptions.addArguments("--disable-hang-monitor");
        chromeOptions.addArguments("--disable-prompt-on-repost");
        chromeOptions.addArguments("--disable-domain-reliability");
        chromeOptions.addArguments("--disable-breakpad");
        chromeOptions.addArguments("--disable-client-side-phishing-detection");
        chromeOptions.addArguments("--disable-component-update");
        chromeOptions.addArguments("--disable-crash-reporter");
        
        // Memory and performance optimizations
        chromeOptions.addArguments("--aggressive-cache-discard");
        chromeOptions.addArguments("--disable-application-cache");
        chromeOptions.addArguments("--disable-offline-load-stale-cache");
        
        // Set preferences to prevent crashes and improve stability
        java.util.Map<String, Object> prefs = new java.util.HashMap<>();
        prefs.put("profile.default_content_setting_values.notifications", 2);
        prefs.put("profile.default_content_settings.popups", 0);
        prefs.put("profile.managed_default_content_settings.images", 1); // Allow images
        prefs.put("profile.default_content_setting_values.media_stream", 2); // Block media
        prefs.put("profile.default_content_setting_values.geolocation", 2); // Block geolocation
        prefs.put("profile.default_content_setting_values.midi_sysex", 2); // Block MIDI
        prefs.put("profile.default_content_setting_values.protected_media_identifier", 2);
        prefs.put("profile.content_settings.exceptions.automatic_downloads.*.setting", 1);
        prefs.put("profile.default_content_setting_values.automatic_downloads", 1);
        prefs.put("profile.password_manager_enabled", false);
        prefs.put("credentials_enable_service", false);
        prefs.put("profile.default_content_setting_values.cookies", 1); // Allow cookies
        
        chromeOptions.setExperimentalOption("useAutomationExtension", false);
        chromeOptions.setExperimentalOption("excludeSwitches", java.util.Arrays.asList(
            "enable-automation", 
            "enable-logging",
            "disable-background-timer-throttling",
            "disable-backgrounding-occluded-windows",
            "disable-renderer-backgrounding"
        ));
        chromeOptions.setExperimentalOption("prefs", prefs);
        
        // Add performance logging to help diagnose crashes
        chromeOptions.setCapability("goog:loggingPrefs", new java.util.HashMap<String, String>() {{
            put("performance", "ALL");
        }});
        
        return chromeOptions;
    }

    public static Dotenv getDotEnv() {
        String envPath = System.getProperty("user.dir");
        return Dotenv.configure().directory(envPath).load();
    }

    public static Boolean isProduction() {
        String appEnv = getDotEnv().get("APP_ENV");
        return "production".equals(appEnv);
    }

    public static Boolean isLocal() {
        String appEnv = getDotEnv().get("APP_ENV");
        return "local".equals(appEnv);
    }

    public static Boolean isTest() {
        String appEnv = getDotEnv().get("APP_ENV");
        return "test".equals(appEnv);
    }
}