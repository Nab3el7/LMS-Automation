package StepDefinitions.StudentsModule;

import StepDefinitions.AssignmentReviewSteps;
import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Gradebook.ManualGrading_PF;
import pageFactory.StudentsModule.AddNewStudent_PF;
import org.openqa.selenium.ElementNotInteractableException;


import java.time.Duration;

import static pageFactory.StudentsModule.ReadNewStdInfo_PF.updatedEmail;

//import static StepDefinitions.Configurations.driver;

public class AddNewStudentSteps extends Configurations {
    WebDriver driver = Configurations.getDriver();

    AddNewStudent_PF addNewStudentPf;
    Helper helper;


    public WebDriverWait wait;
    WebElement loader = driver.findElement(By.xpath("//span[@role='progressbar']"));



    public AddNewStudentSteps(){
        addNewStudentPf= new AddNewStudent_PF(driver);
        helper = new Helper();
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
    }
    @And("Verify Side Navbar And Clicked on Students Module")
    public void VerifySideNavBarAndClickOnStudentsModule() throws InterruptedException {
        TestRunner.startTest( "Add New Student  ");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            addNewStudentPf.SideNavBarAndClickOnStudentsModule();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }


    @And("Verify Student Dashboard")
    public void VerifyStudentsModuleDashboard() throws InterruptedException {
        TestRunner.startTest( "Verify the Students Module dashboard all elements");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            addNewStudentPf.StudentDashboard();
//            System.out.println("Test Case Passed    :   Students Module dashboard all element visible");
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
            Assert.fail();
        }
    }
    @And("Click on Add New Button")
    public void click_add_new(){
        TestRunner.startTest( " Verify Click on Add New Button ");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            addNewStudentPf.AddNewButton();
//            System.out.println("Test Case Passed    :   Add New Button Click successfully");
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
            Assert.fail();
        }
    }

    @And("Check, Validate, Fill Information for Add New Student")
    public void AddNewStudentInformation() throws InterruptedException{
        TestRunner.startTest( " Verify Click on Add New Button and Fill New student Information ");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            addNewStudentPf.AddNewStudentInfo();
//            System.out.println("Test Case Passed    : New Student Added successfully");
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
            Assert.fail();
        }
    }

    @And("Check and verify cancel button on Add new Student")
    public void CancelButtonOnStd() throws InterruptedException {
        TestRunner.startTest( " Check and verify cancel button on Add new Student ");

        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            addNewStudentPf.click_cancel_btn();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
            Assert.fail();
        }
    }

    @And("Check, Validate, Empty Information for Add New Student")
    public void testSubmitEmptyForm() throws InterruptedException {
        TestRunner.startTest( " Check, Validate, Empty Information for Add New Student ");
        try {
            addNewStudentPf.AddNewButton();
            addNewStudentPf.SaveInfo();
            addNewStudentPf.click_cancel_btn();

            WebElement firstNameError = driver.findElement(By.xpath("//p[contains(text(),'First Name is Required')]"));
            WebElement lastNameError = driver.findElement(By.xpath("//p[contains(text(),'Last Name is Required')]"));
            WebElement emailError = driver.findElement(By.xpath("//p[contains(text(),'Email is Required')]"));

            assert firstNameError.isDisplayed();
            assert lastNameError.isDisplayed();
            assert emailError.isDisplayed();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
            Assert.fail();
        }

    }

    @And("Check, Validate, Fill Information With Invalid Email Format for Add New Student")
    public void testInvalidEmailFormat() throws InterruptedException {
        TestRunner.startTest( " Check, Validate, Fill Information with Invalid Email Format for Add New Student ");
        try {
            addNewStudentPf.AddNewButton();
            addNewStudentPf.enterFirstName();
            addNewStudentPf.enterLastName();
            addNewStudentPf.enterIncorrectEmail();
            addNewStudentPf.enterPassword();
            addNewStudentPf.enterConfirmPassword();
            addNewStudentPf.SelectClasses();

            addNewStudentPf.SaveInfo();
            addNewStudentPf.click_cancel_btn();


            // Check for validation message on email field
            WebElement emailError = driver.findElement(By.xpath("//p[contains(text(),'Invalid email address')]"));
            assert emailError.isDisplayed();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
//            System.out.println(e);
//            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
//            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
//            Assert.fail();
        }
    }

    @And("Check, Validate, Fill Information With Mismatch Password for Add New Student")
    public void testPasswordMismatch() throws InterruptedException {
        TestRunner.startTest( " Check, Validate, Fill Information with Mismatch Password for Add New Student ");

        try {
            addNewStudentPf.AddNewButton();
            addNewStudentPf.enterFirstName();
            addNewStudentPf.enterLastName();
            addNewStudentPf.enterEmail();
            addNewStudentPf.enterPassword();
            addNewStudentPf.SelectClasses();

            addNewStudentPf.enterConfirmPasswordMisMatch();

            addNewStudentPf.SaveInfo();
            addNewStudentPf.click_cancel_btn();

            // Check for validation message on confirm password field
            WebElement passwordError = driver.findElement(By.xpath("//span[contains(text(),'Passwords do not match')]"));
            assert passwordError.isDisplayed();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
//            System.out.println(e);
//            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
//            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
//            Assert.fail();
        }
    }

    @And("Check, Validate, Fill Information With Invalid Phone Number for Add New Student")
    public void testInvalidPhoneNumber() throws InterruptedException {
        TestRunner.startTest( "Check, Validate, Fill Information with Invalid Phone Number for Add New Student");

        try {
//            addNewStudentPf.AddNewButton();
            addNewStudentPf.enterFirstName(); // Assume valid
            addNewStudentPf.enterLastName();  // Assume valid
            addNewStudentPf.enterEmail();     // Assume valid
            addNewStudentPf.enterPassword();  // Assume valid
            addNewStudentPf.enterConfirmPassword(); // Assume valid
            addNewStudentPf.SelectClasses();

            addNewStudentPf.EnterInvalidPhoneNumber();

            addNewStudentPf.SaveInfo();

            // Check for validation message on phone number field
            WebElement phoneError = driver.findElement(By.xpath("//span[contains(text(),'Invalid phone number')]"));
            assert phoneError.isDisplayed();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
            Assert.fail();
        }
    }

    @And("Check, Validate, Fill Information With Invalid Local ID for Add New Student")
    public void testInvalidLocalId() throws InterruptedException {
        TestRunner.startTest( "Check, Validate, Fill Information with Invalid Local ID for Add New Student");

        try {
//            addNewStudentPf.AddNewButton();
            addNewStudentPf.enterFirstName(); // Assume valid
            addNewStudentPf.enterLastName();  // Assume valid
            addNewStudentPf.enterEmail();     // Assume valid
            addNewStudentPf.enterPassword();  // Assume valid
            addNewStudentPf.enterConfirmPassword(); // Assume valid
            addNewStudentPf.SelectClasses();

            // Enter an invalid Local ID
            addNewStudentPf.EnterInvalidLocalId();

            addNewStudentPf.SaveInfo();

            // Check for validation message on Local ID field
            WebElement localIdError = driver.findElement(By.xpath("//span[contains(text(),'Invalid Local ID')]"));
            assert localIdError.isDisplayed();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
//            System.out.println(e);
//            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
//            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
//            Assert.fail();
        }
    }

    @And("Check, Validate, Fill Information With Unavailable Dropdown Options for Add New Student")
    public void testSelectUnavailableDropdownOptions() throws InterruptedException {
        TestRunner.startTest( "Check, Validate, Fill Information With Unavailable Dropdown Options for Add New Student");

        try {
            addNewStudentPf.AddNewButton();

            // Assuming dropdowns are empty due to no options
            addNewStudentPf.SelectDistrict();
            addNewStudentPf.SelectSchool();
            addNewStudentPf.SelectGrade();

            // Check that no dropdown options are available
            WebElement districtError = driver.findElement(By.xpath("//span[contains(text(),'No District available')]"));
            WebElement schoolError = driver.findElement(By.xpath("//span[contains(text(),'No School available')]"));
            WebElement gradeError = driver.findElement(By.xpath("//span[contains(text(),'No Grade available')]"));

            assert districtError.isDisplayed();
            assert schoolError.isDisplayed();
            assert gradeError.isDisplayed();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
//            System.out.println(e);
//            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
//            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
//            Assert.fail();
        }
    }

    @And("Check, Validate, Fill Information With Duplicate Email for Add New Student")
    public void testDuplicateEmail() throws InterruptedException {
        TestRunner.startTest( "Check, Validate, Fill Information with Duplicate Email for Add New Student");

        try {
            addNewStudentPf.AddNewButton();
            addNewStudentPf.enterFirstName(); // Assume valid
            addNewStudentPf.enterLastName();  // Assume valid

            // Enter an email that already exists in the system
            String existingEmail = "oliviajade01@gp.com";
            addNewStudentPf.enterExistingEmail(updatedEmail);

            addNewStudentPf.enterPassword();
            addNewStudentPf.enterConfirmPassword();
            addNewStudentPf.SelectClasses();

            addNewStudentPf.SaveInfo();
            addNewStudentPf.click_cancel_btn();

            // Check for validation message on duplicate email field
            WebElement emailError = driver.findElement(By.xpath("//span[contains(text(),'Email already exists')]"));
            assert emailError.isDisplayed();
        }
        catch (NoSuchElementException | ElementNotInteractableException e) {
//
//            System.out.println(e);
//            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
//            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
//            Assert.fail();
        }
    }

    @And("Verify Side Navbar and click on different Modules")
    public void VerifySideNavbarAndClickOnDifferentModules() throws InterruptedException{
        TestRunner.startTest( " Verify Side Navbar and click on different Modules ");

        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            addNewStudentPf.SideNavbarAndClickOnDifferentModules();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
            Assert.fail();
        }

    }

    @And("Verify that No Assignment is found on DashBoard For InActive Student")
    public void VerifyThatNoAssignmentIsFoundOnDashBoardForInActiveStudent() throws InterruptedException{
        TestRunner.startTest( " Verify that No Assignment is found on DashBoard For InActive Student ");

        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            addNewStudentPf.VerifyNoAssignmentOnMyAssignments();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
            Assert.fail();
        }
    }

    @And("Check, Verify that courses are also not found for inactive student")
    public void CheckVerifyThatCoursesAreAlsoNotFoundForInactiveStudent() throws InterruptedException{
        TestRunner.startTest( " Check, Verify that courses are also not found for inactive student ");

        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            addNewStudentPf.VerifyNoCourseFoundOnMyCourses();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
            Assert.fail();
        }
    }

}
