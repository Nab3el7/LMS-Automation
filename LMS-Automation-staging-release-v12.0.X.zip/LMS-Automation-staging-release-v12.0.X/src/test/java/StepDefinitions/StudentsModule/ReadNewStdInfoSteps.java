package StepDefinitions.StudentsModule;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.StudentsModule.AddNewStudent_PF;
import pageFactory.StudentsModule.ReadNewStdInfo_PF;

import java.awt.*;
import java.time.Duration;

//import static StepDefinitions.Configurations.driver;

public class ReadNewStdInfoSteps extends Configurations {
    WebDriver driver = Configurations.getDriver();
    Helper helper;
    ReadNewStdInfo_PF readNewStdInfo_pf;


    public WebDriverWait wait;
    WebElement loader = driver.findElement(By.xpath("//span[@role='progressbar']"));


    public ReadNewStdInfoSteps(){
        helper = new Helper();
        readNewStdInfo_pf= new ReadNewStdInfo_PF(driver);
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
    }


    @And("Check, fill and validate information")
    public void ReadNewStdInfo() throws InterruptedException{
        TestRunner.startTest( " Check Fill and validate new student Info");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            readNewStdInfo_pf.fill_Info();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
            Assert.fail();
        }
    }
    @And("Check, fill and validate information after Edit")
    public void ReadNewStdInfoafteredit() throws InterruptedException{
        TestRunner.startTest( " Check Fill and validate new student Info");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            readNewStdInfo_pf.fill_Infoafteredit();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
            Assert.fail();
        }
    }

    @And("Click on Apply Filter Button In student module")
    public void click_filterButton() throws InterruptedException{
       TestRunner.startTest( "  Check and Click on Apply Filter Button **********");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            readNewStdInfo_pf.apply_btn();
//            System.out.println("Test Case Passed    : Filter Button Clicked Successfully");
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed     :   Exception is found");
            Assert.fail();
        }
    }

    @And("Verify Students Shows Into Table")
    public void Search_Student() throws InterruptedException{
       TestRunner.startTest( "  Check on search anf find student **********");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            readNewStdInfo_pf.showsStudentIntoTable();
            System.out.println("Test Case Passed    : Search Student Successfully");
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed     :   Exception is found");
            Assert.fail();
        }
    }
    @And("Search after edit Student By Email")
    public void Search_Student_by_Eamil_after_Edit() throws InterruptedException{
        TestRunner.startTest( "  Check on search anf find student **********");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            readNewStdInfo_pf.search_student_afterEdit();
//            System.out.println("Test Case Passed    : Search Student Successfully");
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed     :   Exception is found");
            Assert.fail();
        }
    }

    @And("Read Student Information After edit")
    public void ReadStudentInformationAfterEdit() throws InterruptedException{
        TestRunner.startTest( "  Read Student Information After edit **********");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            readNewStdInfo_pf.ReadStdInfoAfterEdit();
//            System.out.println("Test Case Passed    : Search Student Successfully");
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed     :   Exception is found");
            Assert.fail();
        }
    }



    @And("Search New Student By Email")
    public void Search_Student_by_Eamil() throws InterruptedException{
       TestRunner.startTest( "  Check on search anf find student **********");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            readNewStdInfo_pf.search_student();
//            System.out.println("Test Case Passed    : Search Student Successfully");
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed     :   Exception is found");
            Assert.fail();
        }
    }
    @And("Search Usage Student By Email")
    public void Search_usage_Student_by_Eamil() throws InterruptedException{
        TestRunner.startTest( "  Check on search anf find student **********");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            readNewStdInfo_pf.search_Usage_student();
//            System.out.println("Test Case Passed    : Search Student Successfully");
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed     :   Exception is found");
            Assert.fail();
        }
    }


    @And("Read Student Information")
    public void read_std_info() throws InterruptedException{
       TestRunner.startTest( "  Check and Read Student Infomation **********");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            readNewStdInfo_pf.ReadStdInfo();
//            System.out.println("Test Case Passed    : Student Information read Successfully");
            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed     :   Exception is found");
            Assert.fail();
        }

    }


    //     for edit student Information
    @And("click on edit Button")
    public void click_edit_btn() throws InterruptedException{
       TestRunner.startTest( "  Check and validate to Click on Edit button in  student module **********");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            readNewStdInfo_pf.click_edit_button();
//            System.out.println("Test Case Passed    : Edit button click successfully");
            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed     :   Exception is found");
            Assert.fail();
        }
    }
    @And("click on Usage Button")
    public void click_Usage_btn() throws InterruptedException{
        TestRunner.startTest( "  Check and validate to Click on Usage button in  student module **********");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            readNewStdInfo_pf.click_Usage_button();
//            System.out.println("Test Case Passed    : Edit button click successfully");
            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
        }
        catch (NoSuchElementException | ElementNotInteractableException e) {
//            System.out.println(e);
//            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
//            TestRunner.getTest().log(Status.FAIL, "Test Case Failed     :   Exception is found");
//            Assert.fail();
        }
    }

    @And("Validate and Edit Student Information")
    public void edit_info() throws InterruptedException{
       TestRunner.startTest( "  Check and validate to Edit student Information **********");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            readNewStdInfo_pf.edit_std_info();
//            System.out.println("Test Case Passed    : Edit Information successfully");
            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed     :   Exception is found");
            Assert.fail();
        }
    }

    @And("Validate and Click on Update Button")
    public void update_button() throws InterruptedException {
       TestRunner.startTest( "  Validate and click Update Button  **********");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            readNewStdInfo_pf.click_update_btn();
            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed     :   Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }
    @And("Validate and Click on Account Setting Button")
    public void Account_button() throws InterruptedException {
        TestRunner.startTest( "  Validate and click Account Setting Button  **********");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            readNewStdInfo_pf.click_Account_btn();
//            System.out.println("Test Case Passed    : Update button clicks successfully");
            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed     :   Exception is found");
            Assert.fail();
        }
    }
    @And("Validate and Edit Account Setting Information")
    public void Updated_Account_Setting_info() throws InterruptedException{
        TestRunner.startTest( "  Check and validate to Edit student Information **********");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            readNewStdInfo_pf.edit_Account_Setting_info();
//            System.out.println("Test Case Passed    : Edit Information successfully");
            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed     :   Exception is found");
            Assert.fail();
        }
    }
    @And("Validate and Click on Classes Button")
    public void Classes_button() throws InterruptedException {
        TestRunner.startTest( "  Validate and click Classes Button  **********");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            readNewStdInfo_pf.click_Classes_btn();
//            System.out.println("Test Case Passed    : Update button clicks successfully");
            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed     :   Exception is found");
            Assert.fail();
        }
    }
    @And("Edit Select School Year")
    public void Edit_School_Year()throws InterruptedException {
        TestRunner.startTest( "  Select School Year Dropdown");
        try {
            readNewStdInfo_pf.edit_School_Year();
        } catch (NoSuchElementException | ElementNotInteractableException | InterruptedException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
            Assert.fail();
        }
    }
    @And("Select the Class FiltersStatus")
    public void SelectClassStatus()throws InterruptedException{
        TestRunner.startTest( "  Select Class Status Dropdown");
        try {
            readNewStdInfo_pf.SelectClassStatus();
        } catch (NoSuchElementException | ElementNotInteractableException | InterruptedException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception found");
            Assert.fail();
        }
    }

    @And("Validate and Verify Dialogue Box Message")
    public void validate_dialogue_box() throws InterruptedException{
       TestRunner.startTest( "  Verify Dialogue box Message   **********");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            readNewStdInfo_pf.verifyUpdateDialogBox();
//            System.out.println("Test Case Passed    : Student Edit successfully");
            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed     :   Exception is found");
            Assert.fail();
        }
    }

//    @And("Click on after Edit Cancel button")
//    public void After_Edit_cancel_btn() throws InterruptedException{
//       TestRunner.startTest( " Click and validate Cancel button **********");
//        try {
//            wait.until(ExpectedConditions.invisibilityOf(loader));
//            readNewStdInfo_pf.click_cancel_ater_edit_btn();
////            System.out.println("Test Case Passed    : Cancel button clicks successfully");
//            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
//        } catch (NoSuchElementException | ElementNotInteractableException e) {
//            System.out.println(e);
//            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
//            TestRunner.getTest().log(Status.FAIL, "Test Case Failed     :   Exception is found");
//            Assert.fail();
//        }
//    }
    @And("Click on Close button")
    public void colse_btn() throws InterruptedException{
        TestRunner.startTest( " Click and validate Close button **********");
        try {
            wait.until(ExpectedConditions.invisibilityOf(loader));
            readNewStdInfo_pf.click_Close_btn();
//
            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed     :   Exception is found");
            Assert.fail();
        }
    }
    @And("Clear search box for Student")
    public void ClearSearchBoxforStudent() throws InterruptedException{
        TestRunner.startTest("Clear search box");
        try {
            Thread.sleep(5000);
            readNewStdInfo_pf.ClearSearchBoxforStudent();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
//            logger.warn("**********  Test Case Failed    : Clearing not perform **********");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Search Box Clearing not perform ");

            Assert.fail();
        }
        Thread.sleep(3000);
    }


    @And("Check, Validate and Select Filter and Get Class List")
    public void CheckValidateAndSelectFilterAndGetClassList() throws InterruptedException {
        TestRunner.startTest("Check, Validate and Select Filter and Get Class List");

        try {
            readNewStdInfo_pf.getFilterStatusAndGetClassList();
            Thread.sleep(500);
            readNewStdInfo_pf.getClassListAndStore();

        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed     :   Exception is found");
            Assert.fail();
        }
    }

    @And("Check, Validate And Click on Courses")
    public void CheckValidateAndClickOnCourses() throws InterruptedException {
        TestRunner.startTest("Check, Validate And Click on Courses");

        try {

            readNewStdInfo_pf.clickOnCoursesStudentSide();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed     :   Exception is found");
            Assert.fail();
        }
    }

    @And("Check, Validate Select My Course From Dropdown")
    public void CheckValidateSelectMyCourseFromDropdown() throws InterruptedException {
        TestRunner.startTest("Check, Validate Select My Course From Dropdown");

        try {
            readNewStdInfo_pf.getMyCoursesListAndSelectCourse(readNewStdInfo_pf.classNamesForStudentModule);

        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed     :   Exception is found");
            Assert.fail();
        }
    }

    @And("Check, Validate Course Content on Courses Module")
    public void CheckValidateCourseContentOnCoursesModule() throws InterruptedException {
        TestRunner.startTest("Check, Validate Course Content on Courses Module");
        try {
            readNewStdInfo_pf.verifySearchBoxAndUnits();

        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed     :   Exception is found");
            Assert.fail();
        }
    }

    @And("Check, Validate Data Display on Right side")
    public void CheckValidateDataDisplayOnRightSide() throws InterruptedException {
        TestRunner.startTest("Check, Validate Data Display on Right side");

        try {
            readNewStdInfo_pf.verifyDataOnRightSide();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Check, Validate Search Box on Courses")
    public void CheckValidateSearchBoxOnCourses() throws InterruptedException {
        TestRunner.startTest("Check, Validate Search Box on Courses");

        try {

            readNewStdInfo_pf.validateSearchFunctionality();
        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed:  Exception is found");
            Assert.fail();
        }
    }

    @And("Check, Validate that unit Name Match After search")
    public void CheckValidateThatUnitNameMatchAfterSearch() throws InterruptedException {
        TestRunner.startTest("Check, Validate that unit Name Match After search");

        try {

            readNewStdInfo_pf.verifySearchUnitIsMatch();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Check, Validate that name match on right side")
    public void CheckValidateThatNameMatchOnRightSide() throws InterruptedException {
        TestRunner.startTest("Check, Validate that unit Name Match After search");

        try {

            readNewStdInfo_pf.verifyDataDisplay();
        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }

    }

    @And("Check, Validate and Click on Unit")
    public void CheckValidateAndClickOnUnit() throws InterruptedException {
        TestRunner.startTest("Check, Validate and Click on Unit");

        try {
            readNewStdInfo_pf.clickOnUnitName();

        } catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Check, Validate Assignment is Present In List")
    public void CheckValidateAssignmentIsPresentInList() throws InterruptedException {
        TestRunner.startTest("Check, Validate Assignment is Present In List");
        try {

            readNewStdInfo_pf.verifyAssignmentPresentInList();

        } catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Check , Validate Start, Submit Specific Assignment With Correct Answers")
    public void CheckValidateStartSubmitSpecificAssignmentWithCorrectAnswers() throws InterruptedException, AWTException {
        TestRunner.startTest("Check , Validate Start, Submit Specific Assignment With Correct Answers");

        try {
            readNewStdInfo_pf.VerifyAndStartAndSubmitAssignmentInCourses();

        } catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

}

