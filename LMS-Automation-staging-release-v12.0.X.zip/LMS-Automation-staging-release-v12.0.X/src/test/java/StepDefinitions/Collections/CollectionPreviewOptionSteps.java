package StepDefinitions.Collections;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Collections.CollectionPreviewOption_PF;
import pageFactory.Collections.CollectionWithReadOnly_PF;
import pageFactory.MyContent.CreateAssessment_PF;

import java.time.Duration;

public class CollectionPreviewOptionSteps {

    WebDriver driver = Configurations.getDriver();
    Helper helper;
    CollectionPreviewOption_PF collectionPreviewOption_pf;
    Actions actions;

    CollectionWithReadOnly_PF collectionWithReadOnly_pf;

    CreateAssessment_PF createAssessmentPF;

    public WebDriverWait wait;
    WebElement loader = driver.findElement(By.xpath("//span[@role='progressbar']"));


    public CollectionPreviewOptionSteps(){
        collectionPreviewOption_pf= new CollectionPreviewOption_PF(driver);
        collectionWithReadOnly_pf= new CollectionWithReadOnly_PF(driver);
        createAssessmentPF = new CreateAssessment_PF(driver);
        helper = new Helper();
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
        actions = new Actions(driver);
    }

    @And("Validate And Click on Preview Option")
    public void ValidateAndClickOnPreviewOption() throws InterruptedException{
        TestRunner.startTest("Validate And Click on Preview Option");
        try {
            collectionPreviewOption_pf.ClickPreviewOption();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }


    @And("Validate Collection Title field is disable In Preview Mode")
    public void ValidateCollectionTitleFieldIsDisableInPreviewMode() throws InterruptedException{
        TestRunner.startTest("Validate Collection Title field is disable In Preview Mode");
        try {
            collectionPreviewOption_pf.ValidateTitleFiledDisable();
        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();

        }
    }

    @And("Validate state dropdown is disabled In Preview Mode")
    public void ValidateStateDropdownIsDisabledInPreviewMode() throws InterruptedException{
        TestRunner.startTest("Validate state dropdown is disabled In Preview Mode");
        try {
            collectionPreviewOption_pf.ValidateStateDropdownDisable();
        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Validate Grade Level Dropdown Disable In Preview Mode")
    public void ValidateGradeLevelDropdownDisableInPreviewMode() throws InterruptedException{
        TestRunner.startTest("Validate Grade Level Dropdown Disable In Preview Mode");
        try {
            collectionPreviewOption_pf.ValidateGradeLevelDropdownDisable();
        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Validate Collection Level Dropdown Disable In Preview Mode")
    public void ValidateCollectionLevelDropdownDisableInPreviewMode() throws InterruptedException{
        TestRunner.startTest("Validate Collection Level Dropdown Disable In Preview Mode");
        try {
            collectionPreviewOption_pf.ValidateCollectionLevelDropdownDisable();
        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Validate Default Collection Rights Dropdown Disable In Preview Mode")
    public void ValidateDefaultCollectionRightsDropdownDisableInPreviewMode() throws InterruptedException{
        TestRunner.startTest("Validate Default Collection Rights Dropdown Disable In Preview Mode");
        try {
            collectionPreviewOption_pf.DefaultCollectionRightsDropdownDisable();
        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Validate District Filter Dropdown is disable In Preview Mode")
    public void ValidateDistrictFilterDropdownIsDisableInPreviewMode() throws InterruptedException{
        TestRunner.startTest("Validate District Filter Dropdown is disable In Preview Mode");
        try {
            collectionPreviewOption_pf.ValidateDistrictFilterDropdownDisable();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL," Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Validate Organization Name And Status DropDown is disable In Preview Mode")
    public void ValidateOrganizationNameDropDownIsDisableInPreviewMode() throws InterruptedException{
        TestRunner.startTest("Validate  Organization Name And Status DropDown is disable In Preview Mode");
        try {
            collectionPreviewOption_pf.ValidateOrganizationNameAndStatusDropdownDisable();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }

    }

    @And("Validate Save Button is Disable")
    public void ValidateSaveButtonIsDisable() throws InterruptedException{
        TestRunner.startTest("Validate Save Button is Disable");
        try {
            collectionPreviewOption_pf.saveButtonDisable();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Validate Add Staff Member Button is Disable In Preview Mode")
    public void ValidateAddStaffMemberButtonIsDisableInPreviewMode() throws InterruptedException{
        TestRunner.startTest("Validate Add Staff Member Button is Disable In Preview Mode");
        try {
            collectionPreviewOption_pf.VerifyAddStaffMembersButtonIsDisable();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Validate Add Existing Assessment Button is Disable In Preview Mode")
    public void ValidateAddExistingAssessmentButtonIsDisableInPreviewMode() throws InterruptedException{
        TestRunner.startTest("Validate Add Existing Assessment Button is Disable In Preview Mode");
        try {
            collectionPreviewOption_pf.verifyAddExistingAssessmentButtonDisable();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();

        }
    }

    @And("Validate Search box is Disable")
    public void ValidateSearchBoxIsDisable() throws InterruptedException{
        TestRunner.startTest("Validate Search box is Disable");
        try {
            collectionPreviewOption_pf.validateSearchContainerDisabled();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("validate Status Dropdown Disabled")
    public void validateStatusDropdownDisabled() throws InterruptedException{
        TestRunner.startTest("validate Status Dropdown Disabled");
        try {
            collectionPreviewOption_pf.validateStatusDropdownDisabled();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Validate Select School Dropdown Is Disable In Preview Mode")
    public void ValidateSelectSchoolDropdownIsDisableInPreviewMode() throws InterruptedException{
        TestRunner.startTest("Validate Select School Dropdown Is Disable In Preview Mode");
        try {
            collectionPreviewOption_pf.ValidateSelectSchoolDropdownDisable();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Validate Role DropDown Is Disable In Preview Mode")
    public void ValidateRoleDropDownIsDisableInPreviewMode() throws InterruptedException{
        TestRunner.startTest("Validate Role DropDown Is Disable In Preview Mode");
        try {
            collectionPreviewOption_pf.ValidateRoleDropdownDisable();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

}
