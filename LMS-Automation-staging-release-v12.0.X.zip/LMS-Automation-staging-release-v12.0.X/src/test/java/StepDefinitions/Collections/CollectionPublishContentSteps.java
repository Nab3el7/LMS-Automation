package StepDefinitions.Collections;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import io.cucumber.java.en_scouse.An;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Collections.CollectionPublishContent_PF;
import pageFactory.Collections.CollectionWithPublishRights_PF;
import pageFactory.Collections.CollectionWithReadOnly_PF;
import pageFactory.MyContent.CreateAssessment_PF;

import java.time.Duration;

public class CollectionPublishContentSteps {
    WebDriver driver = Configurations.getDriver();
    Helper helper;
    CollectionWithReadOnly_PF collectionWithReadOnlyPf;
    Actions actions;

    CreateAssessment_PF createAssessmentPF;

    CollectionWithPublishRights_PF collectionWithPublishRights_pf;

    CollectionPublishContent_PF  collectionPublishContent_pf;

    public WebDriverWait wait;
    WebElement loader = driver.findElement(By.xpath("//span[@role='progressbar']"));


    public CollectionPublishContentSteps() {
        collectionWithReadOnlyPf = new CollectionWithReadOnly_PF(driver);
        createAssessmentPF = new CreateAssessment_PF(driver);
        collectionWithPublishRights_pf = new CollectionWithPublishRights_PF(driver);
        collectionPublishContent_pf= new CollectionPublishContent_PF(driver);
        helper = new Helper();
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
        actions = new Actions(driver);
    }

    @And("Click on Publish Button From Dropdown")
    public void ClickOnPublishButtonFromDropdown() throws InterruptedException{
        TestRunner.startTest("Click on Publish Button From Dropdown");
        try {
            collectionPublishContent_pf.ClickPublishButton();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Validate Publish Content Prompt Is Displayed")
    public void ValidatePublishContentPromptIsDisplayed() throws InterruptedException{
        TestRunner.startTest("Validate Publish Content Prompt Is Displayed");
        try {
            collectionWithReadOnlyPf.verifyPrompt();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Get All Collection Names From Publish Content Prompt")
    public void GetAllCollectionNamesFromPublishContentPrompt() throws InterruptedException{
        TestRunner.startTest("Get All Collection Names From Publish Content Prompt");
        try {
            collectionPublishContent_pf.getAllCollectionFromPublishContent();
        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Validate and Click on Add Existing Button on Publish Content Prompt")
    public void ValidateAndClickOnAddExistingButton() throws InterruptedException{
        TestRunner.startTest("Validate and Click on Add Existing Button on Publish Content Prompt");
        try {
            collectionPublishContent_pf.ClickAddExistingButtonOnPublishContentPrompt();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Select Collection From DropDown")
    public void SelectCollectionFromDropDown() throws InterruptedException{
        TestRunner.startTest("Select Collection From DropDown");
        try {
            collectionPublishContent_pf.validateAndSelectCollectionFromDropdown();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Validate and Click on Save Button on Publish Content Prompt")
    public void ValidateAndClickOnSaveButtonOnPublishContentPrompt() throws InterruptedException{
        TestRunner.startTest("Validate and Click on Save Button on Publish Content Prompt");
        try {
            collectionPublishContent_pf.clickSaveButton();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Search the Collection In which New Content is Published")
    public void SearchCollectionInWhichNewContentIsPublished() throws InterruptedException {
        TestRunner.startTest("Search the Collection In which New Content is Published");

        try {
            collectionPublishContent_pf.searchCollectionInWhichContentPublish();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }


    @And("Verify Collection Table Shows")
    public void ValidateCollectionsShowsIntoTable() throws InterruptedException {
        TestRunner.startTest("Verify Collection Table Shows");
        try {

            collectionPublishContent_pf.VerifyShowsCollectionIntoTable();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found.");
            Assert.fail();
        }
        Thread.sleep(2000);

    }

    @And("Verify Collection In Which Content is Publish by Title in Table")
    public void ValidateNewlyCreatedCollectionTitleInTable() throws InterruptedException{

        TestRunner.startTest( "Verify Collection In Which Content is Publish by Title in Table");
        try {
            collectionPublishContent_pf.verifySearchedCollectionByTitleIntoTable();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("Click on Edit From Dropdown")
    public void ClickOnEditFromDropdown() throws InterruptedException{
        TestRunner.startTest("click on Edit From Dropdown");
        try {
            collectionPublishContent_pf.clickEditButton();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }


    @And("Search Question Title In Search Box To Verify Question is Publish")
    public void SearchQuestionTitleInSearchBoxToVerifyQuestionIsPublish() throws InterruptedException{
        TestRunner.startTest("Search Question Title In Search Box To Verify Question is Publish");
        try {
            collectionPublishContent_pf.VerifyAndSearchQuestionInSearchBox();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Verify Question Title Match With The Publish Question")
    public void VerifyQuestionTitleMatch() throws InterruptedException{
        TestRunner.startTest("Verify Question Title Match With The Publish Question");
        try {
            collectionPublishContent_pf.VerifyQuestionTitleMatchWithPublishQuestionTitle();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }


    @And("Verify In My Content Questions Shows Into Table")
    public void verifyQuestionsShowsIntoTable() throws InterruptedException {
        TestRunner.startTest("Verify Questions Shows Into Table");
        try {
            collectionPublishContent_pf.showsQuestionsIntoTable();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed    :   Exception is found. ");
            Assert.fail();
        }
    }

    @And("Select question for copy")
    public void SelectQuestionForCopy() throws InterruptedException{
        TestRunner.startTest("Select question for copy");
        try {
            collectionPublishContent_pf.copyQuestion();

        }catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed    :   Exception is found.");
            Assert.fail();
        }
    }

    @And("Click on copy option from dropdown")
    public void ClickOnCopyOptionFromDropdown() throws InterruptedException{
        TestRunner.startTest("Click on copy option from dropdown");
        try {
            collectionPublishContent_pf.selectCopyOption();

        }catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed    :   Exception is found.");
            Assert.fail();
        }
    }

    @And("Validate copy question Prompt")
    public void ValidateCopyQuestionPrompt() throws InterruptedException{
        TestRunner.startTest("Validate copy question Prompt");
        try {
            collectionPublishContent_pf.CopyQuestionModalBox();

        }catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed    :   Exception is found.");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Select Question Status Active")
    public void SelectQuestionStatusForCopyQuestion() throws InterruptedException{
        TestRunner.startTest("Select Question Status Active");
        try {
            collectionPublishContent_pf.SelectQuestionStatus();
        }catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed    :   Exception is found.");
            Assert.fail();
        }
    }

    @And("Search Newly Copy Question In Search Box")
    public void SearchNewlyCopyQuestionInSearchBox() throws InterruptedException{
        TestRunner.startTest("Search Newly Copy Question In Search Box");
        try {
            collectionPublishContent_pf.searchQuestionByName();

        }catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed    :   Exception is found.");
            Assert.fail();
        }
    }

    @And("Verify Custom Questions by Name Shows Into Table")
    public void VerifyCustomQuestionsByNameShowsIntoTable() throws InterruptedException{
        TestRunner.startTest("Verify Custom Questions by Name Shows Into Table");

        try {
            collectionPublishContent_pf.verifySearchedQuestionByNameIntoTable();

        }catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed    :   Exception is found.");
            Assert.fail();
        }
    }

    @And("Validate and Select My Question Custom Filter For Question Type")
    public void ValidateAndSelectMyQuestionCustomFilterForQuestionType() throws InterruptedException{
        TestRunner.startTest("Validate and Select My Question Custom Filter For Question Type");
        try {
            collectionPublishContent_pf.ValidateAndSelectMyQuestionFilter();

        }catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed    :   Exception is found.");
            Assert.fail();
        }
    }
}
