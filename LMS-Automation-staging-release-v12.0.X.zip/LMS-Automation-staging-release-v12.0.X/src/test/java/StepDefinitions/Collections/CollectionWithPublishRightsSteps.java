package StepDefinitions.Collections;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Collections.CollectionWithPublishRights_PF;
import pageFactory.Collections.CollectionWithReadOnly_PF;
import pageFactory.MyContent.CreateAssessment_PF;

import java.time.Duration;

public class CollectionWithPublishRightsSteps {

    WebDriver driver = Configurations.getDriver();
    Helper helper;
    CollectionWithReadOnly_PF collectionWithReadOnlyPf;
    Actions actions;

    CreateAssessment_PF createAssessmentPF;

    CollectionWithPublishRights_PF collectionWithPublishRights_pf;

    public WebDriverWait wait;
    WebElement loader = driver.findElement(By.xpath("//span[@role='progressbar']"));

    public static String staffName = "Automation-QA Teacher";


    public CollectionWithPublishRightsSteps() {
        collectionWithReadOnlyPf = new CollectionWithReadOnly_PF(driver);
        createAssessmentPF = new CreateAssessment_PF(driver);
        collectionWithPublishRights_pf = new CollectionWithPublishRights_PF(driver);
        helper = new Helper();
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
        actions = new Actions(driver);
    }

    @And("Enter Collection Title For Publish Rights")
    public void EnterCollectionTitleForPublishRights() throws InterruptedException {
        TestRunner.startTest("Enter Collection Title For Publish Rights");
        try {

            collectionWithPublishRights_pf.ValidateAndEnterCollectionTitle();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found.");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Select State for Collection with Publish Rights")
    public void SelectStateForCollection() throws InterruptedException {
        TestRunner.startTest("Select State for Collection with Publish Rights");
        try {

            collectionWithPublishRights_pf.validateAndSelectStateForCollection();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found.");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Select Collection Level For Publish Rights")
    public void SelectCollectionLevel() throws InterruptedException {
        TestRunner.startTest("Select Collection Level For Publish Rights");
        try {

            collectionWithPublishRights_pf.SelectCollectionLevelFromDropdown();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found.");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Select Collection Grade Level For Publish Rights")
    public void SelectCollectionGradeLevel() throws InterruptedException {
        TestRunner.startTest("Select Collection Grade Level For Publish Rights");
        try {

            collectionWithPublishRights_pf.SelectCollectionGradeLevelFromDropdown();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found.");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("From Default Collection Rights dropdown Select Publish Right")
    public void SelectReadOnlyCollectionRightFromDropDown() throws InterruptedException {
        TestRunner.startTest("From Default Collection Rights dropdown Select Publish Right");
        try {

            collectionWithPublishRights_pf.ValidateAndSelectPublishCollectionRightFromDropdown();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found.");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Select District Filter For Publish Right Collection")
    public void SelectDistrictFilter() throws InterruptedException {
        TestRunner.startTest("Select District Filter For Publish Right Collection");
        try {

            collectionWithPublishRights_pf.validateAndSelectDistrictFilterForPublishCollection();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found.");
            Assert.fail();
        }
    }

    @And("Select Organization Name For Publish Rights Collection")
    public void SelectOrganizationName() throws InterruptedException {
        TestRunner.startTest("Select Organization Name For Publish Rights Collection");
        try {

            collectionWithPublishRights_pf.validateAndSelectOrganizationNameForPublishRights();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found.");
            Assert.fail();
        }
    }

    @And("Select Active Status for Collection with Publish Rights")
    public void SelectActiveStatusForCollection() throws InterruptedException {
        TestRunner.startTest("Select Active Status for Collection For Publish Rights Collection");
        try {

            collectionWithPublishRights_pf.SelectActiveStatusForPublishRightCollection();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found.");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Select School for Collection with Publish Rights")
    public void SelectSchool() throws InterruptedException {
        TestRunner.startTest("Select School From Staff Selection Prompt");
        try {

            collectionWithPublishRights_pf.SelectSchoolForPublishRightCollection();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found.");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Click on Questions Tab")
    public void ClickOnQuestionsTabButton() throws InterruptedException {
        TestRunner.startTest("Click on Questions Tab Button");
        try {
            collectionWithPublishRights_pf.ValidateAndClickQuestionsTabButton();

        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Validate and Click on Add Existing Question Button")
    public void ValidateAndClickOnAddExistingQuestionsButton() throws InterruptedException {
        TestRunner.startTest("Validate and Click on Add Existing Question Button");

        try {
            collectionWithPublishRights_pf.ClickOnAddExistingQuestionButton();

        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }


    @And("Verify Question Selection Prompt Is Displayed")
    public void VerifyQuestionSelectionPromptIsDisplayed() throws InterruptedException {
        TestRunner.startTest("Verify Question Selection Prompt Is Displayed");

        try {
            collectionWithPublishRights_pf.verifyPromptQuestionSelectionPrompt();

        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();

        }
    }

    @And("Select Question From My Question Section")
    public void SelectQuestionFromQuestionSection() throws InterruptedException {
        TestRunner.startTest("Select Question From My Question Section");
        try {

            collectionWithPublishRights_pf.selectAllCheckboxesInsideQuestion();

        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }

    }

    @And("Select All Question After Filter Apply")
    public void SelectAllQuestionAfterFilterApply() throws InterruptedException {
        TestRunner.startTest("And Select All Question after filter apply");

        try {
            Thread.sleep(5000);
            collectionWithPublishRights_pf.selectQuestions();

        } catch (ElementNotInteractableException | NoSuchElementException e) {
            System.out.println(e);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Validate Staff and Collection right publish are matching in Table")
    public void ValidateStaffAndCollectionRightPublishAreMatchingInTable() throws InterruptedException {
        TestRunner.startTest("Validate Staff and Collection right publish are matching in Table");
        try {
            collectionWithPublishRights_pf.validateStaffAndCollectionRights();
        } catch (ElementNotInteractableException | NoSuchElementException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Search Collection with Publish Rights In Search Box")
    public void SearchCollectionNameInSearchBox() throws InterruptedException {
        TestRunner.startTest("Search Collection with Publish Rights In Search Box");
        try {

            collectionWithPublishRights_pf.SearchCollectionNameWithPublishRightsInSearchBox();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found.");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Validate Collections Shows Into Table")
    public void ValidateCollectionsShowsIntoTable() throws InterruptedException {
        TestRunner.startTest("Validate Collections Shows Into Table");
        try {

            collectionWithPublishRights_pf.showsCollectionIntoTable();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found.");
            Assert.fail();
        }
        Thread.sleep(2000);

    }

    @And("Validate Newly Created Collection by Title in Table")
    public void ValidateNewlyCreatedCollectionTitleInTable() throws InterruptedException{

        TestRunner.startTest( "Validate Newly Created Collection by Title in Table");
        try {
            collectionWithPublishRights_pf.verifySearchedCollectionByTitleIntoTable();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("Filter Verification on Content Collection Dashboard For Publish Rights Collection")
    public void SelectDistrictFilterOnCollectionDashboard() throws InterruptedException{
        TestRunner.startTest( "Filter Verification on Content Collection Dashboard");
        try {

            collectionWithPublishRights_pf.FilterVerificationOnContentCollection();
        }catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found.");
            Assert.fail();
        }
        Thread.sleep(2000);
    }


    @And("Verify and Search Collection Name in Left Panel Under Collections Section")
    public void ClickOnCollectionsButtonInAssessmentTab() throws InterruptedException{
        TestRunner.startTest("Validate and Search Collection Name in Left Panel Under Collections Section");
        try {
            collectionWithPublishRights_pf.left_panel_Collections_section_In_Questions();
        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed:  Exception is found");
            Assert.fail();
        }
    }


    @And("Verify Publish Rights for Other Staff Member from Dropdown that Only Preview Button Should Enabled")
    public void VerifyReadOnlyRightsForOtherStaffMemberFromDropdown() throws InterruptedException{
        TestRunner.startTest("Verify Publish Rights for Other Staff Member from Dropdown that Only Preview Button Should Enabled");

        try {
            collectionWithReadOnlyPf.ValidateEllipseOptionForOtherStaffWithReadOnlyRights();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }


    //    #   Verify and Search Collection With Publish Rights in Associated Content and verify Publish rights in content

    @And("Validate Only Preview And Publish Option is Enabled for Staff in DropDown For Publish Rights")
    public void ValidateOnlyPreviewAndPublishOptionIsEnabledForStaffInDropDownForPublishRights() throws InterruptedException{
        TestRunner.startTest("Validate Only Preview And Publish Option is Enabled for Staff in DropDown For Publish Rights");

        try {
            collectionWithPublishRights_pf.ValidateDropDownOptionsForPublishRights();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Verify Only Preview Option is Enabled for Staff in DropDown For Publish Rights")
    public void ValidateOnlyPreviewOptionIsEnabledForStaffInDropDownForPublishRights() throws InterruptedException{
        TestRunner.startTest("Verify Only Preview Option is Enabled for Staff in DropDown For Publish Rights");

        try {
            collectionWithReadOnlyPf.ValidateDropDownOptionsForReadOnlyRights();


        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }


}
