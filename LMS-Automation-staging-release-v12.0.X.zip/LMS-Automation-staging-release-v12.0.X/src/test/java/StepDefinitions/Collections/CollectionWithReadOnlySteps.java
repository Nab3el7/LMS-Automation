package StepDefinitions.Collections;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.bs.A;
import io.cucumber.java.en.And;
import org.junit.Assert;
import org.junit.Test;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Collections.CollectionWithReadOnly_PF;
import pageFactory.MyContent.CreateAssessment_PF;

import java.time.Duration;

public class CollectionWithReadOnlySteps extends Configurations {
    // Lazy initialization - get driver only when needed
    private WebDriver driver;
    private WebDriverWait wait;
    private WebElement loader;
    private Actions actions;

    Helper helper;
    CollectionWithReadOnly_PF collectionWithReadOnlyPf;
    CreateAssessment_PF createAssessmentPF;

    // for Go2 "Sophie Teacher"
    public static String staffName = "Automation-QA Teacher";

    // Lazy getters - initialize only when accessed
    private WebDriver getWebDriver() {
        if (driver == null) {
            driver = Configurations.getDriver();
        }
        return driver;
    }

    private WebDriverWait getWebDriverWait() {
        if (wait == null) {
            wait = new WebDriverWait(getWebDriver(), Duration.ofSeconds(60));
        }
        return wait;
    }

    private WebElement getLoader() {
        if (loader == null) {
            try {
                loader = getWebDriver().findElement(By.xpath("//span[@role='progressbar']"));
            } catch (NoSuchElementException e) {
                // Loader might not exist, return null
                return null;
            }
        }
        return loader;
    }

    private Actions getActions() {
        if (actions == null) {
            actions = new Actions(getWebDriver());
        }
        return actions;
    }

    public CollectionWithReadOnlySteps() {
        // Helper doesn't need driver immediately - it uses lazy initialization
        helper = new Helper();
        // Page objects will be initialized when driver is first accessed
    }

    // Initialize page objects when driver is first used
    private void ensurePageObjectsInitialized() {
        if (collectionWithReadOnlyPf == null) {
            collectionWithReadOnlyPf = new CollectionWithReadOnly_PF(getWebDriver());
            createAssessmentPF = new CreateAssessment_PF(getWebDriver());
        }
    }

    @And("Verify Side Navbar And Clicked on Custom Content Module")
    public void VerifySideNavBarAndClickOnStudentsModule() throws InterruptedException {
        TestRunner.startTest("Verify side Navbar and click on custom content module");
        try {
            ensurePageObjectsInitialized();
            // Wait for loader to disappear
            try {
                getWebDriverWait().until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//span[@role='progressbar']")));
            } catch (Exception e) {
                // Loader might not exist, continue
            }
            createAssessmentPF.SideNavBarAndClickOnMyContent();
            helper.waitForPageToLoad();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found Custom content module not found");
            Assert.fail();
        }
    }

    @And("Validate and Click on Collections Tab")
    public void ValidateAndClickOnCollectionsTab() throws InterruptedException {
        TestRunner.startTest("Verify side Navbar and click on custom content module");
        try {
            ensurePageObjectsInitialized();
            collectionWithReadOnlyPf.ClickOnCollectionsTabButton();
            helper.waitForPageToLoad();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found Custom content module not found");
            Assert.fail();
        }
    }

    @And("Validate and Click on Add New Button")
    public void ValidateAndClickOnAddNewButtonOnCollectionDashboard() throws InterruptedException {
        TestRunner.startTest("Validate and Click on Add New Button on Collections Dashboard");
        try {
            ensurePageObjectsInitialized();
            collectionWithReadOnlyPf.clickOnAddNewButton();
            helper.waitForPageToLoad();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found Add New Button not found/clickable");
            Assert.fail();
        }
    }

    @And("Add Collection Title")
    public void validateCollectionsBreadCrumb() throws InterruptedException{
        TestRunner.startTest( "Add Collection Title");
        try {

            collectionWithReadOnlyPf.ValidateAndAddCollectionTitle();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found.");
            Assert.fail();
        }
        helper.waitForPageToLoad();
    }

    @And("Select Active Status for Collection")
    public void SelectActiveStatusForCollection() throws InterruptedException {
        TestRunner.startTest("Select Active Status for Collection");
        try {
            ensurePageObjectsInitialized();
            collectionWithReadOnlyPf.SelectActiveStatus();
            helper.waitForPageToLoad();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found.");
            Assert.fail();
        }
    }

    @And("Select State for Collection")
    public void SelectStateForCollection() throws InterruptedException {
        TestRunner.startTest("Select State for Collection");
        try {
            ensurePageObjectsInitialized();
            collectionWithReadOnlyPf.validateAndSelectStateForCollection();
            helper.waitForPageToLoad();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found.");
            Assert.fail();
        }
    }

    @And("Select Collection Level")
    public void SelectCollectionLevel() throws InterruptedException {
        TestRunner.startTest("Select Collection Level for Collection");
        try {
            ensurePageObjectsInitialized();
            collectionWithReadOnlyPf.SelectCollectionLevelFromDropdown();
            helper.waitForPageToLoad();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found.");
            Assert.fail();
        }
    }

    @And("Select Collection Grade Level")
    public void SelectCollectionGradeLevel() throws InterruptedException {
        TestRunner.startTest("Select Collection Grade Level");
        try {
            ensurePageObjectsInitialized();
            collectionWithReadOnlyPf.SelectCollectionGradeLevelFromDropdown();
            helper.waitForPageToLoad();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found.");
            Assert.fail();
        }
    }

    @And("Select Default Collection Rights Read Only")
    public void SelectReadOnlyCollectionRightFromDropDown() throws InterruptedException {
        TestRunner.startTest("Select Default Collection Rights Read Only");
        try {
            ensurePageObjectsInitialized();
            collectionWithReadOnlyPf.ValidateAndSelectReadOnlyCollectionRight();
            helper.waitForPageToLoad();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found.");
            Assert.fail();
        }
    }

    @And("Validate and Click on Next Button")
    public void ValidateAndClickOnNextButton() throws InterruptedException {
        TestRunner.startTest("Validate and Click on Next Button");
        try {
            ensurePageObjectsInitialized();
            collectionWithReadOnlyPf.ClickNextButton();
            helper.waitForPageToLoad();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found.");
            Assert.fail();
        }
    }

    @And("Select District Filter")
    public void SelectDistrictFilter() throws InterruptedException {
        TestRunner.startTest("Select District Filter");
        try {
            ensurePageObjectsInitialized();
            collectionWithReadOnlyPf.validateAndSelectDistrictFilter();
            helper.waitForPageToLoad();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found.");
            Assert.fail();
        }
    }

    @And("Select Organization Name From Dropdown")
    public void SelectOrganizationName() throws InterruptedException {
        TestRunner.startTest("Select Organization Name From Dropdown");
        try {
            ensurePageObjectsInitialized();
            collectionWithReadOnlyPf.validateAndSelectOrganizationNameFromDropdown();
            helper.waitForPageToLoad();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found.");
            Assert.fail();
        }
    }

    @And("Validate And Click Next Button Step")
    public void clickNextButton() throws InterruptedException {
        TestRunner.startTest("CLick on Next Button");
        try {
            ensurePageObjectsInitialized();
            collectionWithReadOnlyPf.ValidateAndClickNextButtonStepII();
            helper.waitForPageToLoad();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found.");
            Assert.fail();
        }
    }

    @And("Validate and Click on Add Existing Assessment")
    public void ValidateAndClickOnAddExistingAssessment() throws InterruptedException {
        TestRunner.startTest("Validate and Click on Add Existing Assessment");
        try {
            ensurePageObjectsInitialized();
            collectionWithReadOnlyPf.ClickOnAddExistingAssessmentButton();
            helper.waitForPageToLoad();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found.");
            Assert.fail();
        }
    }

    @And("Verify Assessment Selection Prompt Is Displayed")
    public void VerifyAssessmentSelectionPromptIsDisplayed() throws InterruptedException {
        TestRunner.startTest("Verify Assessment Selection Prompt Is Displayed");
        try {
            ensurePageObjectsInitialized();
            collectionWithReadOnlyPf.verifyPrompt();
            helper.waitForPageToLoad();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found.");
            Assert.fail();
        }
    }

    @And("Select Assessments From My Assessment section")
    public void SelectAssessmentsFromMyAssessmentSection() throws InterruptedException {
        TestRunner.startTest("Select Assessments From My Assessment section");
        try {
            ensurePageObjectsInitialized();
            collectionWithReadOnlyPf.selectAllCheckboxesInsideAssessment();
            helper.waitForPageToLoad();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found.");
            Assert.fail();
        }
    }

    @And("Validate and Click on Apply Filter Button")
    public void ValidateAndClickOnApplyFilterButton() throws InterruptedException {
        TestRunner.startTest("Apply Filter Button");
        try {
            ensurePageObjectsInitialized();
            collectionWithReadOnlyPf.clickApplyFilterButton();
            helper.waitForPageToLoad();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found.");
            Assert.fail();
        }
    }

    @And("Select All Assessment after filter apply")
    public void SelectAllAssessmentAfterFilterApply() throws InterruptedException {
        TestRunner.startTest("Select All Assessment after filter apply");
        try {
            ensurePageObjectsInitialized();
            // Wait for loader and page to be ready
            try {
                getWebDriverWait().until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//span[@role='progressbar']")));
            } catch (Exception e) {
                // Loader might not exist, continue
            }
            helper.waitForPageToLoad();
            collectionWithReadOnlyPf.selectAssessment();
            helper.waitForPageToLoad();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found.");
            Assert.fail();
        }
    }

    @And("Validate and Click on Save Button")
    public void ValidateAndClickOnSaveButton() throws InterruptedException{
        TestRunner.startTest( "Validate and Click on Save Button");
        try {

            collectionWithReadOnlyPf.ClickSaveButton();
        }catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found.");
            Assert.fail();
        }
        helper.waitForPageToLoad();
    }

    @And("Validate Assessment count match")
    public void ValidateAssessmentCountMatch() throws InterruptedException{
        TestRunner.startTest( "Validate Assessment count match");
        try {

            collectionWithReadOnlyPf.VerifyAssessmentCountMatch();
        }catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found.");
            Assert.fail();
        }
        helper.waitForPageToLoad();
    }

    @And("Validate and Click on Add Staff Members Button")
    public void ValidateAndClickOnAddStaffMembersButton() throws InterruptedException{
        TestRunner.startTest( "Validate and Click on Add Staff Members Button");
        try {

            collectionWithReadOnlyPf.ClickOnAddStaffMembersButton();
        }catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found.");
            Assert.fail();
        }
        helper.waitForPageToLoad();
    }

    @And("Select District From Staff Selection prompt")
    public void SelectDistrictFromStaffSelectionPrompt() throws InterruptedException{
        TestRunner.startTest( "Select District From Staff Selection Prompt");
        try {

            collectionWithReadOnlyPf.SelectDistrictFromDropdown();
        }catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found.");
            Assert.fail();
        }
        helper.waitForPageToLoad();
    }

    @And("Select School")
    public void SelectSchool() throws InterruptedException{
        TestRunner.startTest( "Select School From Staff Selection Prompt");
        try {

            collectionWithReadOnlyPf.SelectSchoolFromDropDown();
        }catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found.");
            Assert.fail();
        }
        helper.waitForPageToLoad();
    }

    @And("Select Role From Dropdown")
    public void SelectRoleFromDropdown() throws InterruptedException{
        TestRunner.startTest( "Select Role From Dropdown");
        try {

            collectionWithReadOnlyPf.validateAndSelectRoleFromDropdown();
        }catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found.");
            Assert.fail();
        }
        helper.waitForPageToLoad();
    }

    @And("Search Staff By Name in search box")
    public void SearchStaffByNameInSearchBox() throws InterruptedException{
        TestRunner.startTest( "Search Staff By Name in search box");
        try {

            collectionWithReadOnlyPf.searchStaffByName(staffName);
        }catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found.");
            Assert.fail();
        }
        helper.waitForPageToLoad();
    }

    @And("Select Staff after filter apply")
    public void SelectStaffAfterFilterApply() throws InterruptedException{
        TestRunner.startTest( "Select Staff after filter apply");
        try {

            collectionWithReadOnlyPf.selectStaff();
        }catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found.");
            Assert.fail();
        }
        helper.waitForPageToLoad();
    }

    @And("Validate and Click on Save From Staff Selection")
    public void ValidateClickOnSaveFromStaffSelection() throws InterruptedException{
        TestRunner.startTest( "Validate and Click on Save From Staff Selection");
        try {

            collectionWithReadOnlyPf.SaveStaffSelection();
        }catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found.");
            Assert.fail();
        }
        helper.waitForPageToLoad();
    }

    @And("Validate Staff and Collection right in Table are matching")
    public void ValidateStaffAndCollectionRightInTableAreMatching() throws InterruptedException{
        TestRunner.startTest( "Validate Staff and Collection right in Table are matching");
        try {

            collectionWithReadOnlyPf.validateStaffAndCollectionRights();
        }catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found.");
            Assert.fail();
        }
        helper.waitForPageToLoad();
    }

    @And("Validate Selected User and Table Rows Count Match")
    public void ValidateSelectedUserAndTableRowsCountMatch() throws InterruptedException{
        TestRunner.startTest( "Validate Selected User and Table Rows Count Match");
        try {

            collectionWithReadOnlyPf.VerifySelectedUserCountAndTableRowsCountMatch();
        }catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found.");
            Assert.fail();
        }
        helper.waitForPageToLoad();
    }

    @And("Click on Save And Exit Button to Save Collection")
    public void ClickOnSaveAndExitButtonToSaveCollection() throws InterruptedException{
        TestRunner.startTest( "Click on Save And Exit Button to Save Collection");
        try {

            collectionWithReadOnlyPf.ValidateAndClickSaveAndExitButton();
        }catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found.");
            Assert.fail();
        }
        helper.waitForPageToLoad();
    }


//    filter Verification

    @And("Filter Verification on Content Collection Dashboard")
    public void SelectDistrictFilterOnCollectionDashboard() throws InterruptedException{
        TestRunner.startTest( "Filter Verification on Content Collection Dashboard");
        try {

            collectionWithReadOnlyPf.FilterVerificationOnContentCollection();
        }catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found.");
            Assert.fail();
        }
        helper.waitForPageToLoad();
    }

    @And("Click on Apply Filter Button In Content Collection Dashboard")
    public void ClickOnApplyFilterButtonContentCollectionDashboard() throws InterruptedException{

        TestRunner.startTest( "Click on Apply Filter Button In Content Collection Dashboard");
        try {

            collectionWithReadOnlyPf.ApplyFilterButtonContentCollection();
        }catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found.");
            Assert.fail();
        }
        helper.waitForPageToLoad();
    }

    @And("Search Collection Name In Search Box")
    public void SearchCollectionNameInSearchBox() throws InterruptedException{
        TestRunner.startTest( "Search Collection Name In Search Box");
        try {

            collectionWithReadOnlyPf.SearchCollectionNameReadOnlyInSearchBox();
        }catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found.");
            Assert.fail();
        }
        helper.waitForPageToLoad();
    }

    @And("Verify Collections Shows Into Table")
    public void VerifyCollectionsShowsIntoTable() throws InterruptedException{
        TestRunner.startTest( "Verify Collections Shows Into Table");
        try {

            collectionWithReadOnlyPf.showsCollectionIntoTable();
        }catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found.");
            Assert.fail();
        }
        helper.waitForPageToLoad();
    }

    @And("Verify Newly Created Collection by Title in Table")
    public void VerifyNewlyCreatedCollectionTitleInTable() throws InterruptedException{

        TestRunner.startTest( "Verify Newly Created Collection by Title in Table");
        try {
            collectionWithReadOnlyPf.verifySearchedCollectionByTitleIntoTable();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("Click On Collection Ellipse Button")
    public void ClickOnCollectionEllipseButton() throws InterruptedException{
        TestRunner.startTest( "Click On Collection Ellipse Button");
        try {
            collectionWithReadOnlyPf.CollectionEllipseButton();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("Verify That All Options In Ellipse is Enable For Author")
    public void VerifyThatAllOptionsInEllipseIsEnableForAuthor() throws InterruptedException{
        TestRunner.startTest( "Verify That All Options In Ellipse is Enable For Author");
        try {
            collectionWithReadOnlyPf.ValidateEllipseOptionForAuthor();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

//  Verify Search Collection in Associated Content and Verify Rights

    @And("Validate Assessment Dashboard")
    public void ValidateAssessmentDashboard() throws InterruptedException{
        TestRunner.startTest("Validate Assessment Dashboard");
        try {
            collectionWithReadOnlyPf.assessment_dashboard();
        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Validate and Search Collection Name in Left Panel Under Collections Section")
    public void ClickOnCollectionsButtonInAssessmentTab() throws InterruptedException{
        TestRunner.startTest("Validate and Search Collection Name in Left Panel Under Collections Section");
        try {
            collectionWithReadOnlyPf.left_panel_Collections_section();
        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed:  Exception is found");
            Assert.fail();
        }
    }

    @And("Apply filter Button")
    public void ApplyFilterButton() throws InterruptedException{
        TestRunner.startTest("Apply filter Button");
        try {
            collectionWithReadOnlyPf.applyFilterButtonCLick();
        }catch (NoSuchElementException| ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Validate Collection Assessment Shows Into Table")
    public void ValidateCollectionAssessmentShowsIntoTable() throws InterruptedException{
        TestRunner.startTest("Validate Collection Assessment Shows Into Table");
        try {
            collectionWithReadOnlyPf.showsCollectionAssessmentIntoTable();
        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Select Collection Assessment For which You Want To Verify Rights")
    public void SelectCollectionAssessmentForWhichYouWantToVerifyAuthorRights() throws InterruptedException{
        TestRunner.startTest("Select Collection Assessment For Which You Want To Verify Rights");

        try {

            collectionWithReadOnlyPf.SelectCollectionAssessmentToVerifyAuthorRights();
        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found.");
            Assert.fail();
        }
    }

    @And("Validate Preview and Publish Option is Enabled for Author in DropDown")
    public void ValidatePreviewAndPublishOptionIsEnabledForAuthorInDropDown() throws InterruptedException{
        TestRunner.startTest("Validate Preview and Publish Option is Enabled for Author in DropDown");

        try {

            collectionWithReadOnlyPf.ValidateDropDownOptionsForAuthor();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found.");
            Assert.fail();
        }
    }

    @And("Validate Total number of Collections Assessment Count Match on Assessment Tab")
    public void ValidateTotalNumberOfCollectionsAssessmentCountMatchOnAssessmentTab() throws InterruptedException{
        TestRunner.startTest("Validate Total number of Collections Assessment Count Match on Assessment Tab");

        try {
            collectionWithReadOnlyPf.verifyTotalAssessmentCollectionCount();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found.");
            Assert.fail();
        }
    }



//    Other Staff Member Read Only Collections Right Verification

    @And("Click On Collection Ellipse Button For Other Staff")
    public void ClickOnCollectionEllipseButtonForOtherStaff() throws InterruptedException{
        TestRunner.startTest("Click On Collection Ellipse Button For Other Staff");
        try {

            collectionWithReadOnlyPf.EllipseButtonForOtherStaff();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }


    @And("Verify Read Only Rights for Other Staff Member from Dropdown that Only Preview Button Should Enabled")
    public void VerifyReadOnlyRightsForOtherStaffMemberFromDropdown() throws InterruptedException{
        TestRunner.startTest("Verify Read Only Rights for Other Staff Member from Dropdown that Only Preview Button Should Enabled");

        try {
            collectionWithReadOnlyPf.ValidateEllipseOptionForOtherStaffWithReadOnlyRights();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }


//    #   Verify and Search Collection With Read Only Rights in Associated Content and verify Read only rights in content

    @And("Validate Only Preview Option is Enabled for Staff in DropDown For Read Only Rights")
    public void ValidateOnlyPreviewOptionIsEnabledForStaffInDropDownForReadOnlyRights() throws InterruptedException{
        TestRunner.startTest("Validate Only Preview Option is Enabled for Staff in DropDown For Read Only Rights");

        try {
            collectionWithReadOnlyPf.ValidateDropDownOptionsForReadOnlyRights();


        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Validate On Assessment Screen Collection Name Match")
    public void ValidateOnAssessmentScreenCollectionNameMatch() throws InterruptedException{
        TestRunner.startTest("Validate On Assessment Screen Collection Name Match");
        try {
            collectionWithReadOnlyPf.VerifyCollectionNameMatch();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

}
