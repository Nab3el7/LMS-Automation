package StepDefinitions.Collections;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Collections.CollectionAllStaffForLevelAboveProcess_PF;
import pageFactory.Collections.CollectionWithReadOnly_PF;
import pageFactory.MyContent.CreateAssessment_PF;

import java.time.Duration;

public class CollectionAllStaffForLevelAboveProcessSteps {
    WebDriver driver = Configurations.getDriver();
    Helper helper;
    CollectionWithReadOnly_PF collectionWithReadOnlyPf;
    Actions actions;

    CreateAssessment_PF createAssessmentPF;
    CollectionAllStaffForLevelAboveProcess_PF collectionAllStaffForLevelAboveProcess_pf;

    public WebDriverWait wait;
    WebElement loader = driver.findElement(By.xpath("//span[@role='progressbar']"));



    public CollectionAllStaffForLevelAboveProcessSteps(){
        collectionWithReadOnlyPf= new CollectionWithReadOnly_PF(driver);
        createAssessmentPF = new CreateAssessment_PF(driver);
        helper = new Helper();
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
        actions = new Actions(driver);
        collectionAllStaffForLevelAboveProcess_pf= new CollectionAllStaffForLevelAboveProcess_PF(driver);
    }

    @And("Add Collection Title For District Admin Collection")
    public void validateAndEnterTitle() throws InterruptedException{
        TestRunner.startTest( "Add Collection Title For District Admin Collection");
        try {

            collectionAllStaffForLevelAboveProcess_pf.EnterCollectionTitleForDistrictCollection();
        }catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found.");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Select Collection Level for District Collection")
    public void SelectCollectionLevelForDistrictCollection() throws InterruptedException {
        TestRunner.startTest("Select Collection Level for District Collection");

        try {
            collectionAllStaffForLevelAboveProcess_pf.selectCollectionLevelFromDropdown();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e);
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed  : Exception is found.");
            Assert.fail();
        }
    }

    @And("Select All Staff for level above have access to collection")
    public void SelectAllStaffForLevelAboveHaveAccessToCollection() throws InterruptedException{

        TestRunner.startTest("Select All Staff for level above have access to collection");

        try {
            collectionAllStaffForLevelAboveProcess_pf.clickOnAllStaffForLevelHaveAccessCheckbox();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found.");
            Assert.fail();
        }
    }

    @And("Validate On Step-II All Staff Level Above CheckBox and Text Is Present")
    public void ValidateOnStep_IIAllStaffLevelAboveCheckBoxAndTextIsPresent() throws InterruptedException{
        TestRunner.startTest("Validate On Step-II All Staff Level Above CheckBox and Text Is Present");

        try {
            collectionAllStaffForLevelAboveProcess_pf.VerifyAllStaffCheckBoxAndTextIsPresent();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed:  Exception is Found");
            Assert.fail();
        }
    }

    @And("Select District Filter For District Admin")
    public void SelectDistrictFilterForDistrictAdmin() throws InterruptedException {
        TestRunner.startTest("Select District Filter For District Admin");

        try {
            collectionAllStaffForLevelAboveProcess_pf.selectDistrictFilterOnStepII();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed:  Exception is Found");
            Assert.fail();
        }
    }

    @And("Select Organization Name From DropDown for District Admin")
    public void SelectOrganizationName() throws InterruptedException{
        TestRunner.startTest( "Select Organization Name From DropDown for District Admin");
        try {

            collectionAllStaffForLevelAboveProcess_pf.validateAndSelectOrganizationNameFromDropdownForDistrictAdmin();
        }catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found.");
            Assert.fail();
        }
    }

//  filter verification for district admin side collection


    @And("Validate and Verify Filter Verification on Content Collection Dashboard For District Admin Collection")
    public void SelectDistrictFilterOnCollectionDashboard() throws InterruptedException{
        TestRunner.startTest( "Validate and Verify Filter Verification on Content Collection Dashboard For District Admin Collection");
        try {

            collectionAllStaffForLevelAboveProcess_pf.FilterVerificationForDistrictAdminCollection();
        }catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found.");
            Assert.fail();
        }
        Thread.sleep(2000);
    }


//    search District Admin Collection

    @And("Verify and Search District Admin Collection Name In Search Box")
    public void SearchCollectionNameInSearchBox() throws InterruptedException{
        TestRunner.startTest( "Verify and Search District Admin Collection Name In Search Box");
        try {

            collectionAllStaffForLevelAboveProcess_pf.SearchDistrictAdminCollectionNameInSearchBox();
        }catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found.");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Verify District Admin Collections Shows Into Table")
    public void VerifyCollectionsShowsIntoTable() throws InterruptedException{
        TestRunner.startTest( "Verify District Admin Collections Shows Into Table");
        try {

            collectionAllStaffForLevelAboveProcess_pf.districtAdminCollectionsShowsIntoTable();
        }catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found.");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Verify District Admin Newly Created Collection by Title in Table")
    public void VerifyNewlyCreatedCollectionTitleInTable() throws InterruptedException{

        TestRunner.startTest( "Verify District Admin Newly Created Collection by Title in Table");
        try {
            collectionAllStaffForLevelAboveProcess_pf.verifyDistrictAdminSearchedCollectionByTitleIntoTable();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("Validate and Search District Admin Collection Name in Left Panel Under Collections Section")
    public void ClickOnCollectionsButtonInAssessmentTab() throws InterruptedException{
        TestRunner.startTest("Validate and Search District Admin Collection Name in Left Panel Under Collections Section");
        try {
            collectionAllStaffForLevelAboveProcess_pf.left_panel_district_Admin_Collections_section();
        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed:  Exception is found");
            Assert.fail();
        }
    }

    @And("Select Course for validate Collection")
    public void SelectCourseForValidateCollection() throws InterruptedException {
        TestRunner.startTest("Select Course for validate Collection");
        try {
            collectionAllStaffForLevelAboveProcess_pf.VerifySelectCourse();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }
}
