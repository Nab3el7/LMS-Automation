package StepDefinitions.Collections;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Collections.CollectionDeleteProcess_PF;
import pageFactory.Collections.CollectionRoleFilter_PF;
import pageFactory.Collections.CollectionWithReadOnly_PF;
import pageFactory.MyContent.CreateAssessment_PF;

import java.time.Duration;

public class CollectionDeleteProcessSteps {

    WebDriver driver = Configurations.getDriver();
    Helper helper;
    CollectionWithReadOnly_PF collectionWithReadOnlyPf;
    Actions actions;

    CreateAssessment_PF createAssessmentPF;
    CollectionDeleteProcess_PF collectionDeleteProcess_pf;

    CollectionRoleFilter_PF collectionRoleFilter_pf;
    public WebDriverWait wait;
    WebElement loader = driver.findElement(By.xpath("//span[@role='progressbar']"));



    public CollectionDeleteProcessSteps(){
        collectionWithReadOnlyPf= new CollectionWithReadOnly_PF(driver);
        createAssessmentPF = new CreateAssessment_PF(driver);
        collectionRoleFilter_pf = new CollectionRoleFilter_PF(driver);
        collectionDeleteProcess_pf = new CollectionDeleteProcess_PF(driver);
        helper = new Helper();
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
        actions = new Actions(driver);
    }

    @And("Validate And Click on Delete Option From Dropdown")
    public void ValidateAndClickOnDeleteOptionFromDropdown() throws InterruptedException{
        TestRunner.startTest("Validate And Click on Delete Option From Dropdown");
        try {
            collectionDeleteProcess_pf.ClickDeleteOptionFromDropdown();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed: Exception is Found");
            Assert.fail();
        }
    }

    @And("Verify Delete Content-Collection Dialog Prompt")
    public void VerifyDeleteContentCollectionDialogPrompt() throws InterruptedException{
        TestRunner.startTest("Verify Delete Content-Collection Dialog Prompt");

        try {
            collectionDeleteProcess_pf.VerifyDeleteDialogPrompt();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Validate Collection Name Match on Prompt")
    public void ValidateCollectionNameMatchOnPrompt() throws InterruptedException{
        TestRunner.startTest("Validate Collection Name Match on Prompt");
        try {
            collectionDeleteProcess_pf.verifyCollectionNameOnDeleteCollectionPrompt();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Validate And Click on Yes Button")
    public void ValidateAndClickOnYesButton() throws InterruptedException{
        TestRunner.startTest("Validate And Click on Yes Button");
        try {
            collectionDeleteProcess_pf.clickYesButton();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Verify and Search Delete Collection Name in Left Panel Under Collection Section")
    public void VerifyAndSearchDeleteCollectionNameInLeftPanelUnderCollectionSection() throws InterruptedException{
        TestRunner.startTest("Verify and Search Delete Collection Name in Left Panel Under Collection Section");

        try {
            collectionDeleteProcess_pf.VerifyDeleteCollectionInQuestionsUnderCollectionSection();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception is found: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Verify Delete Collection Found In Table")
    public void VerifyDeleteCollectionFoundInTable() throws InterruptedException{
        TestRunner.startTest("Verify Delete Collection Found In Table");
        try {
            collectionDeleteProcess_pf.ValidateDeleteCollectionInTable();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception is found: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }


    @And("Refresh The Collections Tab")
    public void RefreshTheCollectionsTab() throws InterruptedException{
        TestRunner.startTest("Refresh The Collections Tab After Collection is Delete");

        try {
            collectionDeleteProcess_pf.refreshCollectionScreen();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception is found: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is Found");
            Assert.fail();;
        }
        Thread.sleep(2000);
    }
}
