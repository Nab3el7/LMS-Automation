package StepDefinitions.Collections;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Collections.CollectionAuthorEditCollectionProcess_PF;
import pageFactory.Collections.CollectionWithReadOnly_PF;
import pageFactory.MyContent.CreateAssessment_PF;

import java.time.Duration;

public class CollectionAuthorEditCollectionProcessSteps {

    WebDriver driver = Configurations.getDriver();
    Helper helper;
    CollectionWithReadOnly_PF collectionWithReadOnlyPf;
    Actions actions;

    CreateAssessment_PF createAssessmentPF;
    CollectionAuthorEditCollectionProcess_PF collectionAuthorEditCollectionProcess_pf;

    public WebDriverWait wait;
    WebElement loader = driver.findElement(By.xpath("//span[@role='progressbar']"));

    public static String staffName ="Automation-QA Teacher";


    public CollectionAuthorEditCollectionProcessSteps(){
        collectionWithReadOnlyPf= new CollectionWithReadOnly_PF(driver);
        createAssessmentPF = new CreateAssessment_PF(driver);
        collectionAuthorEditCollectionProcess_pf = new CollectionAuthorEditCollectionProcess_PF(driver);
        helper = new Helper();
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
        actions = new Actions(driver);
    }

    @And("Validate and Click on Edit Option From Dropdown")
    public void ValidateAndClickOnPreviewOption() throws InterruptedException{
        TestRunner.startTest("Validate and Click on Edit Option From Dropdown");
        try {
            collectionAuthorEditCollectionProcess_pf.ClickEditOption();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Validate and Edit Collection Title on StepI")
    public void ValidateAndEditCollectionTitleOnStepI() throws InterruptedException {
        TestRunner.startTest("Validate and Edit Collection Title on StepI");

        try {
            collectionAuthorEditCollectionProcess_pf.editCollectionTitle();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Author Change Staff Publish Right to Read only From Default Collection Rights")
    public void AuthorChangeStaffPublishRightToReadOnlyFromDefaultCollectionRights() throws InterruptedException {
        TestRunner.startTest("Author Change Staff Publish Right to Read only From Default Collection Rights");

        try {

            collectionAuthorEditCollectionProcess_pf.ChangeDefaultRightsForOtherStaff();
        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed: Exception is found.");
            Assert.fail();
        }
    }

    @And("Search Edit Collection In Search Box")
    public void SearchEditCollectionInSearchBox() throws InterruptedException {
        TestRunner.startTest("Search Edit Collection In Search Box");

        try {
            collectionAuthorEditCollectionProcess_pf.SearchEditedCollectionNameInSearchBox();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Validate Collection Shows Into Table After Edit")
    public void ValidateCollectionShowsIntoTableAfterEdit() throws InterruptedException {
        TestRunner.startTest("Validate Collection Shows Into Table After Edit");

        try {
            collectionAuthorEditCollectionProcess_pf.verifyAfterEditShowsCollectionIntoTable();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Validate Edit Collection by Title in Table")
    public void ValidateEditCollectionByTitleInTable() throws InterruptedException {
        TestRunner.startTest("Validate Edit Collection by Title in Table");
        try {
            collectionAuthorEditCollectionProcess_pf.verifySearchedCollectionByTitleIntoTableAfterEdit();
        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Verify and Search Edit Collection Name in Left Panel Under Collections Sections")
    public void ClickOnCollectionsButtonInAssessmentTab() throws InterruptedException{
        TestRunner.startTest("Verify and Search Edit Collection Name in Left Panel Under Collections Sections");
        try {
            collectionAuthorEditCollectionProcess_pf.left_panel_Edit_Collections_section_In_Questions();
        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed:  Exception is found");
            Assert.fail();
        }
    }
}
