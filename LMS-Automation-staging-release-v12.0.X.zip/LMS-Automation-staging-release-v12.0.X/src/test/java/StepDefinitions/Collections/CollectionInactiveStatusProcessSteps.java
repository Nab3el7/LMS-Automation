package StepDefinitions.Collections;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Collections.CollectionDeleteProcess_PF;
import pageFactory.Collections.CollectionInactiveStatusProcess_PF;
import pageFactory.Collections.CollectionRoleFilter_PF;
import pageFactory.Collections.CollectionWithReadOnly_PF;
import pageFactory.MyContent.CreateAssessment_PF;

import java.time.Duration;

public class CollectionInactiveStatusProcessSteps {

    WebDriver driver = Configurations.getDriver();
    Helper helper;
    CollectionWithReadOnly_PF collectionWithReadOnlyPf;
    Actions actions;

    CreateAssessment_PF createAssessmentPF;
    CollectionDeleteProcess_PF collectionDeleteProcess_pf;
    CollectionInactiveStatusProcess_PF collectionInactiveStatusProcess_pf;

    CollectionRoleFilter_PF collectionRoleFilter_pf;
    public WebDriverWait wait;
    WebElement loader = driver.findElement(By.xpath("//span[@role='progressbar']"));


    public CollectionInactiveStatusProcessSteps() {
        collectionWithReadOnlyPf = new CollectionWithReadOnly_PF(driver);
        createAssessmentPF = new CreateAssessment_PF(driver);
        collectionRoleFilter_pf = new CollectionRoleFilter_PF(driver);
        collectionDeleteProcess_pf = new CollectionDeleteProcess_PF(driver);
        helper = new Helper();
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
        actions = new Actions(driver);
        collectionInactiveStatusProcess_pf= new CollectionInactiveStatusProcess_PF(driver);

    }

    @And("Enter Collection Title for Collection with Inactive Status")
    public void EnterCollectionTitleForPublishRights() throws InterruptedException {
        TestRunner.startTest("Enter Collection Title for Collection with Inactive Status");
        try {

            collectionInactiveStatusProcess_pf.ValidateAndEnterCollectionTitleForInactiveStatus();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found.");
            Assert.fail();
        }
        Thread.sleep(2000);
    }


    @And("Validate and Click On Previous Button")
    public void ValidateAndClickOnPreviousButton() throws InterruptedException{
        TestRunner.startTest("Validate and Click On Previous Button");
        try {

            collectionInactiveStatusProcess_pf.ClickOnPreviousButton();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found.");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Select Status Inactive From Status Dropdown")
    public void SelectStatusInactiveFromStatusDropdown() throws InterruptedException{
        TestRunner.startTest("Select Status Inactive From Status Dropdown");
        try {

            collectionInactiveStatusProcess_pf.SelectInactiveStatusStepI();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found.");
            Assert.fail();
        }
    }


    @And("Filter Verification For Inactive Collection on Content Collection Dashboard")
    public void SelectDistrictFilterOnCollectionDashboard() throws InterruptedException{
        TestRunner.startTest( "Filter Verification For Inactive Collection on Content Collection Dashboard");
        try {

            collectionInactiveStatusProcess_pf.FilterVerificationForInactiveCollectionOnContentCollection();
        }catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found.");
            Assert.fail();
        }
        Thread.sleep(2000);
    }


    @And("Select Collection Level For Inactive Collection")
    public void SelectCollectionLevelForPublishRights() throws InterruptedException {
        TestRunner.startTest("Select Collection Level For Inactive Collection");
        try {

            collectionInactiveStatusProcess_pf.SelectCollectionLevelFromDropdown();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found.");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Select District Filter For Inactive Collection")
    public void SelectDistrictFilter() throws InterruptedException {
        TestRunner.startTest("Select District Filter For Inactive Collection");
        try {

            collectionInactiveStatusProcess_pf.validateAndSelectDistrictFilterForInactiveCollection();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found.");
            Assert.fail();
        }
    }

    @And("Select School for Inactive Collection")
    public void SelectSchool() throws InterruptedException {
        TestRunner.startTest("Select School From Staff Selection Prompt");
        try {

            collectionInactiveStatusProcess_pf.SelectSchoolForInactiveCollection();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found.");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Search Collection with InActive Status In Search Box")
    public void SearchCollectionNameInSearchBox() throws InterruptedException {
        TestRunner.startTest("Search Collection with InActive Status In Search Box");
        try {

            collectionInactiveStatusProcess_pf.SearchCollectionNameWithInactiveStatusInSearchBox();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found.");
            Assert.fail();
        }
        Thread.sleep(2000);
    }


    @And("Validate Inactive Collections Shows Into Table")
    public void ValidateCollectionsShowsIntoTable() throws InterruptedException {
        TestRunner.startTest("Validate Inactive Collections Shows Into Table");
        try {

            collectionInactiveStatusProcess_pf.showsCollectionIntoTable();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found.");
            Assert.fail();
        }
        Thread.sleep(2000);

    }

    @And("Validate Newly Created Inactive Collection by Title in Table")
    public void ValidateNewlyCreatedCollectionTitleInTable() throws InterruptedException{

        TestRunner.startTest( "Validate Newly Created Inactive Collection by Title in Table");
        try {
            collectionInactiveStatusProcess_pf.verifySearchedCollectionByTitleIntoTable();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("Verify and Search Inactive Collection Name in Left Panel Under Collections Section")
    public void ClickOnCollectionsButtonInAssessmentTab() throws InterruptedException{
        TestRunner.startTest("Verify and Search Inactive Collection Name in Left Panel Under Collections Section");
        try {
            collectionInactiveStatusProcess_pf.left_panel_Collections_section_In_Questions();
        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed:  Exception is found");
            Assert.fail();
        }
    }

    @And("Select Filter To Validate Inactive Collection is not In Active Collection")
    public void SelectFilterToValidateInactiveCollectionIsNotInActiveCollection() throws InterruptedException{
        TestRunner.startTest("Select Filter To Validate Inactive Collection is not In Active Collection");

        try {
            collectionInactiveStatusProcess_pf.SelectFilterToValidateInactiveCollectionIsNotInActiveCollection();
        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed:  Exception is found");
            Assert.fail();
        }
    }

    @And("Validate That Inactive Collection Is Not Found In Active Collection List")
    public void ValidateThatInactiveCollectionIsNotFoundInActiveCollectionList() throws InterruptedException{
        TestRunner.startTest("Validate That Inactive Collection Is Not Found In Active Collection Lise");
        try {
            collectionInactiveStatusProcess_pf.ValidateInactiveCollectionInActiveCollectionInTable();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception is found: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }
}
