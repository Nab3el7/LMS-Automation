package StepDefinitions.Collections;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Collections.CollectionWithEditRightsFull_PF;
import pageFactory.Collections.CollectionWithReadOnly_PF;
import org.openqa.selenium.ElementNotInteractableException;

import java.time.Duration;

public class CollectionWithEditRightsFullSteps {

    WebDriver driver = Configurations.getDriver();
    Helper helper;
    CollectionWithReadOnly_PF collectionWithReadOnlyPf;
    Actions actions;

    CollectionWithEditRightsFull_PF collectionWithEditRightsFull_pf;

    public WebDriverWait wait;
    WebElement loader = driver.findElement(By.xpath("//span[@role='progressbar']"));

    public static String staffName ="Automation-QA Teacher";


    public CollectionWithEditRightsFullSteps(){
        collectionWithReadOnlyPf= new CollectionWithReadOnly_PF(driver);
        collectionWithEditRightsFull_pf= new CollectionWithEditRightsFull_PF(driver);
        helper = new Helper();
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
        actions = new Actions(driver);
    }


    @And("Add Collection Title For Edit Rights Full")
    public void AddCollectionTitleForEditRightsFull() throws InterruptedException {
        TestRunner.startTest("Add Collection Title For Edit Rights Full");
        try {
            collectionWithEditRightsFull_pf.VerifyAndAddCollectionTitleForEditRightsCollection();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found.");
            Assert.fail();
        }
    }

    @And("Select Collection Level For Edit Rights Full Collection")
    public void SelectCollectionLevelForEditRightsFullCollection() throws InterruptedException {
        TestRunner.startTest("Select Collection Level For Edit Rights Full Collection");

        try {

            collectionWithEditRightsFull_pf.selectCollectionLevelForEditRightsFullCollection();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("From Default Collection Rights Dropdown Select Edit Rights Full")
    public void FromDefaultCollectionRightsDropdownSelectEditRightsFull () throws InterruptedException {
        TestRunner.startTest("From Default Collection Rights Dropdown Select Edit Rights Full");

        try {
            collectionWithEditRightsFull_pf.ValidateAndSelectEditRightsFullFromDropdown();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Select District Filter For Edit Rights Full Collection")
    public void SelectDistrictFilterForEditRightsFullCollection() throws InterruptedException {
        TestRunner.startTest("Select District Filter For Edit Rights Full Collection");

        try {
            collectionWithEditRightsFull_pf.validateAndSelectDistrictFilterForEditRightsFullCollection();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Select Organization Name For Edit Rights Full Collection")
    public void SelectOrganizationNameForEditRightsFullCollection() throws InterruptedException {
        TestRunner.startTest("Select Organization Name For Edit Rights Full Collection");

        try {
            collectionWithEditRightsFull_pf.validateAndSelectOrganizationNameForEditRightsFullCollection();

        }catch (ElementNotInteractableException | NoSuchElementException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Select Active Status For Collection With Edit Rights Full")
    public void SelectActiveStatusForCollectionWithEditRightsFull() throws InterruptedException {
        TestRunner.startTest("Select Active Status For Collection With Edit Rights Full");

        try {
            collectionWithEditRightsFull_pf.SelectActiveStatusForEditRightsFullCollection();

        }catch (ElementNotInteractableException | NoSuchElementException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found. ");
            Assert.fail();
        }
    }

    @And("Click on Resources Tab")
    public void ClickOnResourcesTab() throws InterruptedException {
        TestRunner.startTest("Click on Resources Tab");

        try {

            collectionWithEditRightsFull_pf.ValidateAndClickResourcesTabButton();

        }catch (ElementNotInteractableException | NoSuchElementException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Validate and CLick on Add Existing Resource Button")
    public void ValidateAndCLickOnAddExistingResourceButton() throws InterruptedException {
        TestRunner.startTest("Validate and Click on Add Existing Resource Button");
        try {
            collectionWithEditRightsFull_pf.ClickOnAddExistingResourcesButton();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Verify Resource Selection Prompt Is Displayed")
    public void VerifyResourceSelectionPromptIsDisplayed() throws InterruptedException {
        TestRunner.startTest("Verify Resource Selection Prompt Is Displayed");
        try {
            collectionWithEditRightsFull_pf.verifyPromptResourceSelectionPrompt();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Select Resource From My Resources Section")
    public void SelectResourceFromMyResourcesSection() throws InterruptedException {
        TestRunner.startTest("Select Resource From My Resources Section");

        try {
            collectionWithEditRightsFull_pf.selectAllCheckboxesInsideResource();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Select All Resource After Filter Apply")
    public void SelectAllResourceAfterFilterApply() throws InterruptedException {
        TestRunner.startTest("Select All Resource After Filter Apply");

        try {
            Thread.sleep(2000);
            collectionWithEditRightsFull_pf.selectAllResources();

        }catch (NoSuchElementException | ElementNotInteractableException ex) {
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Validate Resources Count Match")
    public void ValidateResourcesCountMatch() throws InterruptedException {
        TestRunner.startTest("Validate Resources Count Match");
        try {

            collectionWithEditRightsFull_pf.VerifyResourcesCountMatch();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Validate Staff and Collection Edit Rights Full are matching in Table")
    public void  ValidateStaffAndCollectionEditRightsFullAreMatchingInTable() throws InterruptedException {
        TestRunner.startTest("Validate Staff and Collection Edit Rights Full are matching in Table");

        try {
            collectionWithEditRightsFull_pf.validateStaffAndCollectionRightsForEditRightsFull();
        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Validate and Check Filter Verification For Edit Rights Full Collection On Content Collection Dashboard")
    public void ValidateAndCheckFilterVerificationForEditRightsFullCollectionOnContentCollectionDashboard() throws InterruptedException {
        TestRunner.startTest("Validate and Check Filter Verification For Edit Rights Full Collection On Content Collection Dashboard");

        try {
            collectionWithEditRightsFull_pf.filterVerificationOnEditRightsFullCollection();

        }catch (NoSuchElementException | ElementNotInteractableException ex){
            System.out.println(ex.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found.");
        }
    }

    @And("Validate and Search Collection Name Edit Rights Full In Search Box")
    public void ValidateAndSearchCollectionNameEditRightsFullInSearchBox() throws InterruptedException {

        TestRunner.startTest( "Search Edit Right (Full) Collection Name In Search Box");
        try {

            collectionWithEditRightsFull_pf.SearchCollectionNameEditRightsFullInSearchBox();
        }catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found.");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Validate Edit Rights Full Collection Shows Into Table")
    public void ValidateEditRightsFullCollectionShowsIntoTable() throws InterruptedException {
        TestRunner.startTest( "Verify Edit Rights (Full) Collections Shows Into Table");
        try {

            collectionWithEditRightsFull_pf.verifyEditRightsCollectionShowsIntoTable();
        }catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Exception is found.");
            Assert.fail();
        }
        Thread.sleep(2000);
    }

    @And("Validate Edit Rights Full Collection is Present in Table by Title")
    public void ValidateEditRightsFullCollectionIsPresentInTableByTitle() throws InterruptedException {
        TestRunner.startTest( "Validate Edit Rights (Full)  Collection is Present in Table by Title");
        try {
            collectionWithEditRightsFull_pf.verifySearchedEditRightsFullCollectionByTitleIntoTable();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("Check, Validate And Click on Resources Tab And Validate Resources Dashboard")
    public void CheckValidateAndClickOnResourcesTabAndValidateResourcesDashboard() throws InterruptedException {
        TestRunner.startTest("Check, Validate And Click on Resources Tab And Validate Resources Dashboard");

        try {

            collectionWithEditRightsFull_pf.clickOnResourcesTab();
        }catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e.getMessage());
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    @And("Validate and Search Edit Rights Full Collection Name In Left Panel Under Collection Section")
    public void ValidateAndSearchEditRightsFullCollectionNameInLeftPanelUnderCollectionSection() throws InterruptedException{
        TestRunner.startTest("Validate and Search Edit Rights (Full) Collection Name in Left Panel Under Collections Section");
        try {
            collectionWithEditRightsFull_pf.left_panel_Collections_section_In_Resources();
        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed:  Exception is found");
            Assert.fail();
        }
    }

    @And("Validate Resources Shows Into table")
    public void ValidateResourcesShowsIntoTable() throws InterruptedException {
        TestRunner.startTest("Validate Resources Shows Into Table");
        try {
            collectionWithEditRightsFull_pf.showsCollectionResourcesIntoTable();
        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Select Collection Resource For Which You Want To Verify Rights")
    public void SelectCollectionResourceForWhichYouWantToVerifyRights() throws InterruptedException {
        TestRunner.startTest("Select Collection Resource For Which You Want To Verify Rights");

        try {

            collectionWithEditRightsFull_pf.SelectCollectionResourcesToVerifyAuthorRights();
        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found.");
            Assert.fail();
        }
    }

    @And("Validate For Edit rights Full Collection Preview ,Publish, Assign Option is Enabled for Author in DropDown")
    public void ValidateForEditRightsFullCollectionPreviewAndPublishOptionIsEnabledForAuthorInDropDown() throws InterruptedException {
        TestRunner.startTest("Validate For Edit rights Full Collection Preview ,Publish, Assign Option is Enabled for Author in DropDown");

        try {

            collectionWithEditRightsFull_pf.ValidateDropDownOptionsForAuthorForEditRightsFullCollection();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found.");
            Assert.fail();
        }
    }

    @And("Validate Preview and Edit Option is Enable For Other Staff That Have Edit Rights Full")
    public void ValidatePreviewAndEditOptionIsEnableForOtherStaffThatHaveEditRightsFull() throws InterruptedException {
        TestRunner.startTest("Validate Preview and Edit Option is Enable For Other Staff That Have Edit Rights Full");

        try {
            collectionWithEditRightsFull_pf.ValidateEllipseOptionForOtherStaffWithEditRightsFull();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }


//    Collection Validation
//
    @And("Validate Collection Title Validation is display")
    public void ValidateCollectionTitleValidationIsDisplay() throws InterruptedException {
        TestRunner.startTest("Validate Collection Title Validation is display");

        try {
            collectionWithEditRightsFull_pf.validateEmptyTitleField();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
            Assert.fail();
        }
    }

    @And("Validate Status Dropdown is disable")
    public void ValidateStatusDropdownIsDisable() throws InterruptedException{
        TestRunner.startTest("Validate Status Dropdown is disable");

        try {
            collectionWithEditRightsFull_pf.verifyStatusDropdownDisable();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }
}
