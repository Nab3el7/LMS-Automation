package StepDefinitions.Collections;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Collections.CollectionRoleFilter_PF;
import pageFactory.Collections.CollectionWithReadOnly_PF;
import pageFactory.MyContent.CreateAssessment_PF;

import java.time.Duration;

public class CollectionRoleFilterSteps {

    WebDriver driver = Configurations.getDriver();
    Helper helper;
    CollectionWithReadOnly_PF collectionWithReadOnlyPf;
    Actions actions;

    CreateAssessment_PF createAssessmentPF;

    CollectionRoleFilter_PF collectionRoleFilter_pf;
    public WebDriverWait wait;
    WebElement loader = driver.findElement(By.xpath("//span[@role='progressbar']"));



    public CollectionRoleFilterSteps(){
        collectionWithReadOnlyPf= new CollectionWithReadOnly_PF(driver);
        createAssessmentPF = new CreateAssessment_PF(driver);
        collectionRoleFilter_pf = new CollectionRoleFilter_PF(driver);
        helper = new Helper();
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
        actions = new Actions(driver);
    }

    @And("Select Role Filter For Staff and Members")
    public void SelectRoleFilterForStaffAndMembers() throws InterruptedException{
        TestRunner.startTest("Select Role Filter For Staff and Members");
        try {

            collectionRoleFilter_pf.filterRoleOnStaffMembers();
        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }

    }

    @And("Select Role Campus Admin From Dropdown")
    public void SelectRoleCampusAdminFromDropdown() throws InterruptedException{
        TestRunner.startTest("Select Role Campus Admin From Dropdown");
        try {
            collectionRoleFilter_pf.selectCampusAdmin();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found.");
            Assert.fail();
        }
    }


    @And("Select Role Teacher From DropDown")
    public void SelectRoleTeacherFromDropDown() throws InterruptedException{
        TestRunner.startTest("Select Role Teacher From DropDown");
        try {
            collectionRoleFilter_pf.selectTeacherDropdown();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Click On Save Button To Save Data on StepIII")
    public void ClickOnSaveButtonToSaveDataOnStepIII() throws InterruptedException{
        TestRunner.startTest("Click On Save Button To Save Data on StepIII");
        try {
            collectionRoleFilter_pf.ClickSaveButtonToSaveData();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception not found: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

//    Status Filter

    @And("Validate and Change Question Active Status Question to Archive Status")
    public void ValidateAndChangeQuestionActiveStatusQuestionToArchiveStatus() throws InterruptedException{
        TestRunner.startTest("Validate and Change Question Active Status Question to Archive Status");

        try {
            collectionRoleFilter_pf.ChangeActiveStatusToArchiveStatus();

        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception not found: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

    @And("Select Status Filter For Associated Content")
    public void SelectStatusFilterForAssociatedContent() throws InterruptedException{
        TestRunner.startTest("Select Status Filter For Associated Content");
        try {

            collectionRoleFilter_pf.statusFilterOnAssociatedContent();
        }catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e.getMessage());
            System.out.println("Exception not found: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception is found");
            Assert.fail();
        }
    }

}
