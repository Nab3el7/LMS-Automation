package util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Centralized logging utility - replaces System.out.println
 * Use this for consistent logging across the test framework
 */
public class TestLogger {
    
    private static final Logger log = LoggerFactory.getLogger(TestLogger.class);
    
    /**
     * Log info message
     * Use for general information about test execution
     */
    public static void info(String message, Object... args) {
        log.info(message, args);
    }
    
    /**
     * Log debug message
     * Use for detailed debugging information
     */
    public static void debug(String message, Object... args) {
        log.debug(message, args);
    }
    
    /**
     * Log warning message
     * Use for warnings that don't fail the test
     */
    public static void warn(String message, Object... args) {
        log.warn(message, args);
    }
    
    /**
     * Log error message
     * Use for errors that may cause test failure
     */
    public static void error(String message, Object... args) {
        log.error(message, args);
    }
    
    /**
     * Log error with exception
     */
    public static void error(String message, Throwable throwable) {
        log.error(message, throwable);
    }
    
    /**
     * Log test step
     * Use for logging test steps in a consistent format
     */
    public static void step(String stepDescription) {
        log.info("STEP: {}", stepDescription);
    }
    
    /**
     * Log test verification
     * Use for logging assertions and verifications
     */
    public static void verify(String verificationDescription) {
        log.info("VERIFY: {}", verificationDescription);
    }
    
    /**
     * Log test data
     * Use for logging test data values (be careful with sensitive data)
     */
    public static void data(String key, String value) {
        log.debug("DATA: {} = {}", key, maskSensitiveData(key, value));
    }
    
    /**
     * Mask sensitive data in logs
     */
    private static String maskSensitiveData(String key, String value) {
        if (value == null) {
            return null;
        }
        
        String lowerKey = key.toLowerCase();
        if (lowerKey.contains("password") || 
            lowerKey.contains("token") || 
            lowerKey.contains("secret") ||
            lowerKey.contains("key") ||
            lowerKey.contains("credential")) {
            return "***MASKED***";
        }
        
        return value;
    }
}

