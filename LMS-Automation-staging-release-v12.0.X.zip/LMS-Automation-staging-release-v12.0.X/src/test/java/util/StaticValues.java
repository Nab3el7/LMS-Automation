package util;

import java.util.HashMap;
import java.util.Map;

public class StaticValues {

    public static Map<String, Long> assignmentNameMap = new HashMap();
}
