package util;

import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

public class CommonUtil {
    private static String FILE_NAME = "AssignmentInformation.json";
    public static void writeJson(ReleaseAssignmentInformation releaseAssignmentInformation) {
        try {
            deleteAndCreateFile(FILE_NAME);
            ObjectMapper objectMapper = new ObjectMapper();
            objectMapper.writeValue(new File(FILE_NAME), releaseAssignmentInformation);
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
    }
    // new file

    public static ReleaseAssignmentInformation readJsonFromFile() {
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            return objectMapper.readValue(new File(FILE_NAME), ReleaseAssignmentInformation.class);
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return new ReleaseAssignmentInformation();
    }

    public static void deleteAndCreateFile(String filePath) {
        try {
            File file = new File(filePath);

            // Delete the file if it exists
            if (file.exists()) {
                if (file.delete()) {
                    System.out.println("File deleted: " + file.getPath());
                } else {
                    System.out.println("Failed to delete file: " + file.getPath());
                    throw new IOException("Failed to delete existing file: " + file.getPath());
                }
            } else {
                System.out.println("File does not exist, no need to delete: " + file.getPath());
            }

            // Create a new file
            if (file.createNewFile()) {
                System.out.println("File created: " + file.getPath());
            } else {
                System.out.println("Failed to create file: " + file.getPath());
                throw new IOException("Failed to create new file: " + file.getPath());
            }
        } catch (Exception ex) {
            System.out.println("File Creation Exception => " + ex.getMessage());
        }
    }
    public static Date getDateConversion (String dateString ) {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm");
        try {
            Date date = formatter.parse(dateString);
            System.out.println("Parsed Date: " + date);
            return date;
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return new Date();
    }


    public static String convertToStudentWidgetDateFormate(String date) {
        LocalDateTime dateTime = LocalDateTime.parse(date);
        DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern("hh:mm a yyyy-MM-dd");
        String formattedDateTime = dateTime.format(outputFormatter);
        formattedDateTime.replace("am","AM");
        formattedDateTime.replace("pm","PM");
        return formattedDateTime;
    }

}
