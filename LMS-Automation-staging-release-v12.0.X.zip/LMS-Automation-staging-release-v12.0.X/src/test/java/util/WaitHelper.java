package util;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

/**
 * Utility class for explicit waits - replaces Thread.sleep() calls
 * Use this instead of hardcoded Thread.sleep() for better test reliability
 */
public class WaitHelper {
    
    private static final int DEFAULT_TIMEOUT_SECONDS = 10;
    private static final int LONG_TIMEOUT_SECONDS = 30;
    private static final int SHORT_TIMEOUT_SECONDS = 5;
    
    /**
     * Wait for element to be clickable (default timeout)
     */
    public static WebElement waitForElementClickable(WebDriver driver, By locator) {
        return waitForElementClickable(driver, locator, DEFAULT_TIMEOUT_SECONDS);
    }
    
    /**
     * Wait for element to be clickable (long timeout for slow operations)
     */
    public static WebElement waitForElementClickableLong(WebDriver driver, By locator) {
        return waitForElementClickable(driver, locator, LONG_TIMEOUT_SECONDS);
    }
    
    /**
     * Wait for element to be clickable (short timeout for quick operations)
     */
    public static WebElement waitForElementClickableShort(WebDriver driver, By locator) {
        return waitForElementClickable(driver, locator, SHORT_TIMEOUT_SECONDS);
    }
    
    public static WebElement waitForElementClickable(WebDriver driver, By locator, int timeoutSeconds) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(timeoutSeconds));
        return wait.until(ExpectedConditions.elementToBeClickable(locator));
    }
    
    /**
     * Wait for element to be visible
     */
    public static WebElement waitForElementVisible(WebDriver driver, By locator) {
        return waitForElementVisible(driver, locator, DEFAULT_TIMEOUT_SECONDS);
    }
    
    public static WebElement waitForElementVisible(WebDriver driver, By locator, int timeoutSeconds) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(timeoutSeconds));
        return wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
    }
    
    /**
     * Wait for element to be present (in DOM, may not be visible)
     */
    public static WebElement waitForElementPresent(WebDriver driver, By locator) {
        return waitForElementPresent(driver, locator, DEFAULT_TIMEOUT_SECONDS);
    }
    
    public static WebElement waitForElementPresent(WebDriver driver, By locator, int timeoutSeconds) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(timeoutSeconds));
        return wait.until(ExpectedConditions.presenceOfElementLocated(locator));
    }
    
    /**
     * Wait for element to disappear
     */
    public static boolean waitForElementInvisible(WebDriver driver, By locator) {
        return waitForElementInvisible(driver, locator, DEFAULT_TIMEOUT_SECONDS);
    }
    
    public static boolean waitForElementInvisible(WebDriver driver, By locator, int timeoutSeconds) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(timeoutSeconds));
        return wait.until(ExpectedConditions.invisibilityOfElementLocated(locator));
    }
    
    /**
     * Wait for text to be present in element
     */
    public static boolean waitForTextToBePresent(WebDriver driver, By locator, String text) {
        return waitForTextToBePresent(driver, locator, text, DEFAULT_TIMEOUT_SECONDS);
    }
    
    public static boolean waitForTextToBePresent(WebDriver driver, By locator, String text, int timeoutSeconds) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(timeoutSeconds));
        return wait.until(ExpectedConditions.textToBePresentInElementLocated(locator, text));
    }
    
    /**
     * Wait for page title to contain text
     */
    public static boolean waitForTitleContains(WebDriver driver, String title) {
        return waitForTitleContains(driver, title, DEFAULT_TIMEOUT_SECONDS);
    }
    
    public static boolean waitForTitleContains(WebDriver driver, String title, int timeoutSeconds) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(timeoutSeconds));
        return wait.until(ExpectedConditions.titleContains(title));
    }
    
    /**
     * Wait for URL to contain text
     */
    public static boolean waitForUrlContains(WebDriver driver, String urlText) {
        return waitForUrlContains(driver, urlText, DEFAULT_TIMEOUT_SECONDS);
    }
    
    public static boolean waitForUrlContains(WebDriver driver, String urlText, int timeoutSeconds) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(timeoutSeconds));
        return wait.until(ExpectedConditions.urlContains(urlText));
    }
    
    /**
     * Wait for element to be stale (useful for page refreshes)
     */
    public static boolean waitForStaleness(WebDriver driver, WebElement element) {
        return waitForStaleness(driver, element, DEFAULT_TIMEOUT_SECONDS);
    }
    
    public static boolean waitForStaleness(WebDriver driver, WebElement element, int timeoutSeconds) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(timeoutSeconds));
        return wait.until(ExpectedConditions.stalenessOf(element));
    }
    
    /**
     * Wait for alert to be present
     */
    public static org.openqa.selenium.Alert waitForAlert(WebDriver driver) {
        return waitForAlert(driver, DEFAULT_TIMEOUT_SECONDS);
    }
    
    public static org.openqa.selenium.Alert waitForAlert(WebDriver driver, int timeoutSeconds) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(timeoutSeconds));
        return wait.until(ExpectedConditions.alertIsPresent());
    }
    
    /**
     * Wait for frame to be available and switch to it
     */
    public static WebDriver waitForFrameAndSwitch(WebDriver driver, By frameLocator) {
        return waitForFrameAndSwitch(driver, frameLocator, DEFAULT_TIMEOUT_SECONDS);
    }
    
    public static WebDriver waitForFrameAndSwitch(WebDriver driver, By frameLocator, int timeoutSeconds) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(timeoutSeconds));
        return wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(frameLocator));
    }
    
    /**
     * Wait for number of windows to be a specific count
     */
    public static boolean waitForNumberOfWindows(WebDriver driver, int expectedCount) {
        return waitForNumberOfWindows(driver, expectedCount, DEFAULT_TIMEOUT_SECONDS);
    }
    
    public static boolean waitForNumberOfWindows(WebDriver driver, int expectedCount, int timeoutSeconds) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(timeoutSeconds));
        return wait.until(ExpectedConditions.numberOfWindowsToBe(expectedCount));
    }
    
    /**
     * Wait for JavaScript to complete (document.readyState == 'complete')
     */
    public static boolean waitForPageLoad(WebDriver driver) {
        return waitForPageLoad(driver, DEFAULT_TIMEOUT_SECONDS);
    }
    
    public static boolean waitForPageLoad(WebDriver driver, int timeoutSeconds) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(timeoutSeconds));
        return wait.until(webDriver -> {
            return ((org.openqa.selenium.JavascriptExecutor) webDriver)
                .executeScript("return document.readyState").equals("complete");
        });
    }
    
    /**
     * Wait for a custom condition
     */
    public static <T> T waitFor(WebDriver driver, java.util.function.Function<WebDriver, T> condition) {
        return waitFor(driver, condition, DEFAULT_TIMEOUT_SECONDS);
    }
    
    public static <T> T waitFor(WebDriver driver, java.util.function.Function<WebDriver, T> condition, int timeoutSeconds) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(timeoutSeconds));
        return wait.until(condition);
    }
    
    /**
     * Static wait - ONLY use for non-UI waits (API delays, external services)
     * For UI waits, use the explicit wait methods above
     */
    public static void staticWait(long milliseconds) {
        try {
            Thread.sleep(milliseconds);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new RuntimeException("Wait interrupted", e);
        }
    }
}

