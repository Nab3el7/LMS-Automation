package util;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

public class testing {
    public static void main(String[] args) {
        // Original string
        //2024-05-20T13:45
        //01:44 PM 2024-05-20
        String originalString = "";
        LocalDateTime dateTime = LocalDateTime.parse("2024-05-20T13:45");
        DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern("hh:mm a yyyy-MM-dd");
        String formattedDateTime = dateTime.format(outputFormatter);

        // Split the original string based on ": " to extract the date-time part
        String dateTimeString = originalString.split(": ")[1];

        // Define the formatter for the date-time pattern
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("hh:mm a yyyy-MM-dd");

        // Parse the date-time string into a LocalDateTime object
//        LocalDateTime dateTime = LocalDateTime.parse(dateTimeString, formatter);

        // Print the parsed date-time
        System.out.println("Parsed date-time: " + dateTime);
    }
}