package pageFactory.GalSystemScenarios;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;
import java.util.Random;

public class GalSystemAddNewStaff_PF {
    WebDriverWait wait;
    WebDriver driver;
    Helper helper;
    Actions actions;
    JavascriptExecutor js;

    public GalSystemAddNewStaff_PF(WebDriver driver) {
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        helper = new Helper();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        actions = new Actions(driver);
    }

    @FindBy(xpath = "//button[normalize-space()='Add New Staff']")
    WebElement addNewStaff;

    @FindBy(xpath = "//input[@id='textField-firstName']")
    WebElement first_name;

    @FindBy(xpath = "//input[@id='textField-lastName']")
    WebElement last_name;

    @FindBy(xpath = "//input[@name='email']")
    WebElement email_address;

    @FindBy(xpath = "(//div[contains(@class, 'MuiSelect-select')])[3]") // Locate the dropdown
    WebElement dropdown_select_role;

    @FindBy(xpath = "(//label[normalize-space()='Select District']/parent::div)[1]") // Locate the dropdown
    WebElement dropdown_select_District;

    @FindBy(xpath = "//input[@name='localId']")
    WebElement local_Id;

    @FindBy(xpath = "(//div[contains(@class, 'MuiSelect-select')])[5]")
    WebElement select_language;

    @FindBy(xpath = "//input[@name='phone']")
    WebElement Phone_number;

    @FindBy(xpath = "//input[@name='address']")
    WebElement Home_address;

    @FindBy(xpath = "//button[normalize-space()='Add New Organization']")
    WebElement add_new_organization_button;

    @FindBy(xpath = "(//label[normalize-space()='Select School']/parent::div)")
    WebElement select_school;

    @FindBy(xpath = "//div[contains(@class, 'tabelbodydata')]")
    WebElement staffTable;


    public static String staffNameInTable;
    String searchUserByFirstName;

    private Random random = new Random();
    public String FirstNameForNewStaff;
    public String randomNewStaffEmail;
    public String passwordForNewStaff;
    public String selectedDistrictForNewStaff;
    public String selectedRoleForNewStaff;
    public String phoneNumberForNewStaff="555-0132";
    public String selectedSchoolForNewStaff;

    public void ClickOnAddNewStaff() throws InterruptedException {
        System.out.println("I'm Into Click on + Add New Staff Button");
        TestRunner.getTest().log(Status.INFO, "I'm Into Click on + Add New Staff Button");

        Thread.sleep(1000);

        wait.until(ExpectedConditions.elementToBeClickable(addNewStaff));

        if (addNewStaff.isDisplayed() && addNewStaff.isEnabled()) {
            addNewStaff.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed : + Add New Staff Button Click successfully");
        }else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : + Add New Staff Button is not Display/Enabled");
        }
    }

    public void verifyAddNewStaffTeacherPrompt() throws InterruptedException {
        System.out.println("I'm Into Validate that Add New Staff/ Teacher Prompt Display");
        TestRunner.getTest().log(Status.INFO,"I'm Into Validate that Add New Staff/ Teacher Prompt Display");

        Thread.sleep(2000);

        WebElement prompt = driver.findElement(By.xpath("//div[@role='dialog']"));
        boolean isDisplayed = prompt.isDisplayed();
        Assert.assertTrue("Prompt is not displayed.", isDisplayed);

        WebElement promptHeader = prompt.findElement(By.tagName("h2"));
        String headerText = promptHeader.getText();
        System.out.println("Prompt header text is: " + headerText);
        TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  Prompt Display Successfully");
    }


    public void enterFirstNameForStaffTeacher() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Enter New Staff/Teacher First Name");

        Thread.sleep(2000);
        first_name.click();
        first_name.clear();
        FirstNameForNewStaff = generateStaffInfo("AtmTeacherFName-");
        first_name.sendKeys(FirstNameForNewStaff);
        System.out.println("FirstName entered Successfully: " + FirstNameForNewStaff);
        TestRunner.getTest().log(Status.INFO, "New Teacher First Name is: " + FirstNameForNewStaff);
        TestRunner.getTest().log(Status.PASS, "Test Case Passed: New Teacher First Name Enter successfully");

    }

    public void enterLastNameForStaffTeacher() {
        TestRunner.getTest().log(Status.INFO, "Enter New Staff/Teacher Last Name");
        last_name.click();
        last_name.clear();
        String LastName = generateStaffInfo("AtmTeacherLName");
        last_name.sendKeys(LastName);
        System.out.println("LastName entered Successfully: " + LastName);
        TestRunner.getTest().log(Status.INFO, "New Staff Last Name is: " + LastName);
        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Last Name enter successfully");


    }

    public void enterEmailForStaffTeacher() {
        TestRunner.getTest().log(Status.INFO, "Enter New Staff/Teacher Email");

        email_address.click();
        email_address.clear();
        randomNewStaffEmail = randomClassNewStdEmail("staffTeacherAutomated");
        email_address.sendKeys(randomNewStaffEmail);
        System.out.println("Email added successfully: " + randomNewStaffEmail);
        TestRunner.getTest().log(Status.INFO, "New Staff Email is: " + randomNewStaffEmail);
        TestRunner.getTest().log(Status.PASS, "Test Case Passed: New Staff Email enter  successfully");

    }


    public void enterPasswordForStaffTeacher() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Enter New Staff/Teacher Password");
        Thread.sleep(2000);
        WebElement passwordField = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@name='password']")));

        passwordField.clear();

        Actions actions = new Actions(driver);
        actions.moveToElement(passwordField).click().sendKeys("Fltester@22").perform();

        System.out.println("Password added Successfully");

        actions.sendKeys(Keys.TAB);

        passwordForNewStaff = passwordField.getAttribute("value");
        System.out.println("Password field value after input: " + passwordForNewStaff);
        TestRunner.getTest().log(Status.INFO, "New Student Password is: " + passwordForNewStaff);

        if (!"Fltester@22".equals(passwordForNewStaff)) {
            throw new RuntimeException("Password field did not receive the expected value. Actual value: '" + passwordForNewStaff + "'");
        }
        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Password enter successfully");
    }

    public void enterConfirmPasswordForStaffTeacher() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Enter New Staff/Teacher Confirm Password");
        Thread.sleep(5000);

        WebElement confirmPasswordField = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@name='stdConfirmPassword']")));

        confirmPasswordField.clear();

        Actions actions = new Actions(driver);
        actions.moveToElement(confirmPasswordField).click().sendKeys("Fltester@22").perform();

        System.out.println("Confirm Password added Successfully");

        String confirmPasswordValue = confirmPasswordField.getAttribute("value");
        System.out.println("Confirm Password field value after input: " + confirmPasswordValue);
        TestRunner.getTest().log(Status.INFO, "New Student Password is: " + confirmPasswordValue);

        if (!"Fltester@22".equals(confirmPasswordValue)) {
            throw new RuntimeException("Confirm Password field did not receive the expected value. Actual value: '" + confirmPasswordValue + "'");
        }
        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Confirm Password enter successfully");

    }

    public void SelectDistrictForStaffTeacher() {
        TestRunner.getTest().log(Status.INFO, "Select District For New Staff/Teacher ");

        dropdown_select_District.click();

        WebElement listDistrict = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[contains(@role, 'listbox')]")));
        List<WebElement> optionsDistrict = listDistrict.findElements(By.xpath(".//li"));

        System.out.println("District List is: " + optionsDistrict.size());

        if (optionsDistrict.isEmpty()) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: No options found in the district dropdown");
            System.out.println("No options found in the district dropdown.");
            throw new RuntimeException("No District Value found in dropdown");

        } else {
            System.out.println("District:");

            boolean districtFound = false;
            String targetDistrict = "FLDOE District";

            for (WebElement district : optionsDistrict) {
                String districtText = district.getText().trim();
                System.out.println(districtText);

                if (districtText.equalsIgnoreCase(targetDistrict)) {
                    selectedDistrictForNewStaff = districtText;
                    district.click();
                    districtFound = true;
                    System.out.println("Selected District: " + selectedDistrictForNewStaff);
                    TestRunner.getTest().log(Status.INFO, "Selected District is: " + selectedDistrictForNewStaff);
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed: District selected successfully");
                    break;
                }
            }

            if (!districtFound) {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: 'FLDOE District' not found in the dropdown");
                throw new RuntimeException("'FLDOE District' not found in the dropdown");
            }
        }
    }

    public void SelectRoleForStaffTeacher() {

        TestRunner.getTest().log(Status.INFO, "Select Role For New Staff/Teacher ");

        dropdown_select_role.click();

        WebElement listRole = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[contains(@role, 'listbox')]")));
        List<WebElement> optionsRole = listRole.findElements(By.xpath(".//li"));

        System.out.println("District List is: " + optionsRole.size());

        if (optionsRole.isEmpty()) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: No options found in the district dropdown");
            System.out.println("No options found in the district dropdown.");
            throw new RuntimeException("No District Value found in dropdown");

        } else {
            System.out.println("District:");

            boolean RoleFound = false;
            String targetRole = "Teacher";

            for (WebElement role : optionsRole) {
                String roleText = role.getText().trim();
                System.out.println(roleText);

                if (roleText.equalsIgnoreCase(targetRole)) {
                    selectedRoleForNewStaff = roleText;
                    role.click();
                    RoleFound = true;
                    System.out.println("Selected Role: " + selectedRoleForNewStaff);
                    TestRunner.getTest().log(Status.INFO, "Selected Role is: " + selectedRoleForNewStaff);
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed: Role selected successfully");
                    break;
                }
            }

            if (!RoleFound) {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: 'Teacher' not found in the dropdown");
                throw new RuntimeException("'Teacher' not found in the dropdown");
            }
        }
    }

    public void EnterLocalIdForStaffTeacher(){
        TestRunner.getTest().log(Status.INFO, "Enter New Staff/Teacher LocalID");

        local_Id.click();
        helper.scrollToElement(driver, local_Id);

        ((JavascriptExecutor) driver).executeScript("arguments[0].value='';", local_Id);
        String Local_Id = generateStaffInfo("ID-");
        local_Id.sendKeys(Local_Id);
        System.out.println("Local ID " + Local_Id);
        TestRunner.getTest().log(Status.INFO, "Local ID  " + Local_Id);
        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Local ID Enter successfully");


    }

    public void SelectLanguageForStaffTeacher() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Select New Staff/Teacher Language");
        select_language.click();
        Thread.sleep(2000);

//        helper.scrollToElement(driver, select_language);

        List<WebElement> options = driver.findElements(By.xpath("//ul[contains(@role, 'listbox')]//li"));
        if (options.isEmpty()) {
            System.out.println("No options found in the dropdown.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: No options found in the dropdown.");
            return;
        }
        WebElement randomOption = options.get(random.nextInt(options.size()));
        randomOption.click();
        System.out.println("Language Select Successfully " + randomOption);

        TestRunner.getTest().log(Status.INFO, "Language Select  " + randomOption);
        TestRunner.getTest().log(Status.PASS, "Test Case Passed:  Language select successfully");

    }

    public void EnterPhoneNumberForStaffTeacher(){
        TestRunner.getTest().log(Status.INFO, "Enter New Staff/Teacher Phone Number");
        Phone_number.click();
        ((JavascriptExecutor) driver).executeScript("arguments[0].value='';", Phone_number);

//        String randomPhoneNumber = generateRandomPhoneNumber();

        Phone_number.sendKeys(phoneNumberForNewStaff);
        System.out.println("Phone Number enter Successfully " + phoneNumberForNewStaff);

        TestRunner.getTest().log(Status.INFO, "Enter Phone number is: " + phoneNumberForNewStaff);

        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Phone Number Enter successfully");

    }

    public void EnterAddressForStaffTeacher(){
        TestRunner.getTest().log(Status.INFO, "Enter New Staff/Teacher Address");

        Home_address.click();
        ((JavascriptExecutor) driver).executeScript("arguments[0].value='';", Home_address);
        String randomAddress = generateRandomAddress();
        Home_address.sendKeys(randomAddress);
        System.out.println("Address enter Successfully " + randomAddress);
        TestRunner.getTest().log(Status.INFO, "Address enter " + randomAddress);
        TestRunner.getTest().log(Status.PASS, "Test Case Passed:  Address Enter successfully");

    }

    public String generateRandomAddress() {
        Random random = new Random();

        // Random street number
        int streetNumber = random.nextInt(9000) + 100; // 100 to 9999

        // Random street name
        String[] streetNames = {"Main St", "Elm St", "Maple Ave", "Oak Dr", "Pine Ln", "Cedar Blvd", "Birch Ct"};
        String streetName = streetNames[random.nextInt(streetNames.length)];

        // Random city
        String[] cities = {"Springfield", "Riverside", "Greenville", "Centerville", "Fairview"};
        String city = cities[random.nextInt(cities.length)];

        // Random state
        String[] states = {"NY", "CA", "TX", "FL", "IL"};
        String state = states[random.nextInt(states.length)];

        // Random zip code
        int zipCode = random.nextInt(90000) + 10000; // 10000 to 99999

        // Format the address
        return String.format("%d %s, %s, %s %05d", streetNumber, streetName, city, state, zipCode);
    }


    public String randomClassNewStdEmail(String prefix) {
        Random randemail = new Random();
        int randomInt = randemail.nextInt(1000);
        return prefix + randomInt + "@yopmail.com";
    }


    public String generateStaffInfo(String prefix) {
        String characters = "abcdefghijklmnopqrstuvwxyz1234567890";
        StringBuilder randomTitle = new StringBuilder();
        Random random = new Random();
        int length = 4;
        randomTitle.append(prefix);
        for (int i = 0; i < length; i++) {
            randomTitle.append(characters.charAt(random.nextInt(characters.length())));
        }
        return randomTitle.toString();
    }


    public void clickAddNewOrganizationButton() throws InterruptedException {
        System.out.println("I'm Into Click on + Add New Organization Button");
        TestRunner.getTest().log(Status.INFO, "I'm into click + Add New Organization Button");

        if (add_new_organization_button.isDisplayed()) {
            add_new_organization_button.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed : Add New Organization Button Click Successfully");
        }else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Add New Organization Button not Display");
        }

    }

    public void verifyAddNewOrganizationPromptDisplay() throws InterruptedException {
        System.out.println("I'm Into Validate that Add New Organization Prompt Display");
        TestRunner.getTest().log(Status.INFO,"I'm Into Validate that Add New Organization Prompt Display");

        Thread.sleep(2000);

        WebElement prompt = driver.findElement(By.xpath("//div[@role='dialog']"));
        boolean isDisplayed = prompt.isDisplayed();
        Assert.assertTrue("Prompt is not displayed.", isDisplayed);

        WebElement promptHeader = prompt.findElement(By.tagName("h2"));
        String headerText = promptHeader.getText();
        System.out.println("Prompt header text is: " + headerText);
        TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  Prompt Display Successfully");
    }


    public void selectSchoolForStaffTeacher() throws InterruptedException{

        TestRunner.getTest().log(Status.INFO, "Select School For New Staff/Teacher From Add New Organization");

        select_school.click();

        WebElement listRole = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[contains(@role, 'listbox')]")));
        List<WebElement> optionsRole = listRole.findElements(By.xpath(".//li"));

        System.out.println("School List is: " + optionsRole.size());

        if (optionsRole.isEmpty()) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: No options found in the School dropdown");
            System.out.println("No options found in the School dropdown.");
            throw new RuntimeException("No School Value found in dropdown");

        } else {
            System.out.println("School:");

            boolean RoleFound = false;
            String targetRole = "Florida ES";

            for (WebElement role : optionsRole) {
                String roleText = role.getText().trim();
                System.out.println(roleText);

                if (roleText.equalsIgnoreCase(targetRole)) {
                    selectedSchoolForNewStaff = roleText;
                    role.click();
                    RoleFound = true;
                    System.out.println("Selected Role: " + selectedSchoolForNewStaff);
                    TestRunner.getTest().log(Status.INFO, "Selected Role is: " + selectedSchoolForNewStaff);
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed: Role selected successfully");
                    break;
                }
            }

            if (!RoleFound) {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: 'Teacher' not found in the dropdown");
                throw new RuntimeException("'Teacher' not found in the dropdown");
            }
        }
    }


    public void clickSaveButtonAddNewOrganization() throws InterruptedException {
        System.out.println("I'm Into Click on Save Button on Add New Organization Prompt");
        TestRunner.getTest().log(Status.INFO, "I'm Into Click on Save Button on Add New Organization Prompt");

        WebElement saveButtonAddOrganization= driver.findElement(By.xpath("//div[contains(@class,'organizationWrapper')]//button[contains(@name,'btn-signin')][normalize-space()='Save']"));

        if (saveButtonAddOrganization.isDisplayed()) {
            saveButtonAddOrganization.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed : Save Button Click Successfully");
        }else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Save Button not Display");
        }
    }

    public void saveButtonAddNewStaffTeacher() throws InterruptedException{
        System.out.println("I'm into click on Save Button on Add New Staff/Teacher ");
        TestRunner.getTest().log(Status.INFO, "I'm into click on Save Button on Add New Staff/Teacher");

        WebElement save_btn_add_new_staffTeacher= driver.findElement(By.xpath("//button[@name='btn-signin']"));

        if (save_btn_add_new_staffTeacher.isDisplayed() && save_btn_add_new_staffTeacher.isEnabled()){
            save_btn_add_new_staffTeacher.click();
            TestRunner.getTest().log(Status.PASS,"Test Case Passed : Save Button on Add New Staff Teacher click successfully");
        }else {
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed : Save Button on Add New Staff Teacher Not Display/Enabled");

        }

    }

//    public void verifyStaffShowsIntoTable() throws InterruptedException {
//        System.out.println("Validating that the Staff Table is visible...");
//        TestRunner.getTest().log(Status.INFO, "Validating that the Staff Table is visible...");
//
//        try {
//            WebElement tableBody = wait.until(ExpectedConditions.presenceOfElementLocated(
//                    By.xpath("//div[contains(@class, 'tabelbodydata')]//tbody")));
//
//            List<WebElement> rows = tableBody.findElements(By.tagName("tr"));
//
//            if (rows.isEmpty()) {
//                System.out.println("No Staff List found in the table.");
//                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: No Staff List found in the table.");
//                return;
//            }
//            Thread.sleep(2000);
//
//            System.out.println("Staff found in the table:");
//            TestRunner.getTest().log(Status.INFO, "Staff found in the table:");
//
//            for (int i = 0; i < rows.size(); i++) {
//                WebElement row = rows.get(i);
//
//                for (int attempt = 0; attempt < 2; attempt++) {
//                    try {
//                        WebElement nameElement = row.findElement(By.xpath(".//td[contains(@class, 'MuiTableCell')]//div[contains(@class,'rightSide')]//h6"));
//                        staffNameInTable = nameElement.getText();
//                        System.out.println("Staff Name: " + staffNameInTable);
//                        TestRunner.getTest().log(Status.INFO, "Staff Name: " + staffNameInTable);
//
//                        List<WebElement> cells = row.findElements(By.tagName("td"));
//                        StringBuilder rowText = new StringBuilder();
//                        for (WebElement cell : cells) {
//                            rowText.append(cell.getText()).append("\t");
//                        }
//                        System.out.println(rowText);
//                        TestRunner.getTest().log(Status.PASS, "Test case Passed: Staff List Found in Table Successfully");
//
//                        break; // success, exit retry loop
//
//                    } catch (StaleElementReferenceException e) {
//                        System.out.println("Stale element found on attempt " + (attempt + 1) + ", retrying...");
//                        TestRunner.getTest().log(Status.WARNING, "Stale element encountered on attempt " + (attempt + 1) + ", retrying...");
//
//                        // Re-fetch rows and retry the same index
//                        rows = tableBody.findElements(By.tagName("tr"));
//                        row = rows.get(i);
//                    }
//                }
//            }
//
//        } catch (TimeoutException | InterruptedException e) {
//            System.out.println("Timed out waiting for the staff table.");
//            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Staff Table not visible (timeout).");
//        }
//    }

    public void verifyStaffShowsIntoTable() throws InterruptedException{
        System.out.println("I'm Into Validate That Staff Table is Visible");
        TestRunner.getTest().log(Status.INFO, "I'm Into Validate That Staff Table is Visible");


        Thread.sleep(3000);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class, 'tabelbodydata')]//tbody")));

        List<WebElement> rows = staffTable.findElements(By.xpath(".//tbody/tr"));

        if (!rows.isEmpty()) {
            System.out.println("Staff found in the table:");
            TestRunner.getTest().log(Status.INFO, "Staff found in the table:");
            for (int i = 0; i < rows.size(); i++) {
                WebElement row = rows.get(i);

                try {
                    WebElement classNameElement = row.findElement(By.xpath(".//td[contains(@class, 'MuiTableCell')]//div[contains(@class,'rightSide')]//h6"));
                    staffNameInTable = classNameElement.getText();
                    System.out.println("Staff Name: " + staffNameInTable);
                    TestRunner.getTest().log(Status.INFO, "Staff Name: " + staffNameInTable);

                    List<WebElement> cells = row.findElements(By.xpath(".//td"));
                    for (WebElement cell : cells) {
                        System.out.print(cell.getText() + "\t");
                    }
                    System.out.println();
                    TestRunner.getTest().log(Status.PASS, "Test case Passed   : Staff List Found in Table  Successfully");

                } catch (StaleElementReferenceException e) {
                    System.out.println("Stale element found, retrying...");

                    rows = staffTable.findElements(By.xpath(".//tbody/tr"));
                    row = rows.get(i);

                    WebElement classNameElement = row.findElement(By.xpath(".//td[contains(@class, 'MuiTableCell')]//div[contains(@class,'rightSide')]//h6"));
                    staffNameInTable = classNameElement.getText();
                    System.out.println("Staff Name: " + staffNameInTable);
                    TestRunner.getTest().log(Status.INFO, "Staff Name: " + staffNameInTable);

                    List<WebElement> cells = row.findElements(By.xpath(".//td"));
                    for (WebElement cell : cells) {
                        System.out.print(cell.getText() + "\t");
                    }
                    System.out.println();
                    TestRunner.getTest().log(Status.PASS, "Test case Passed   : Staff List Found in Table  Successfully");
                }
            }
        } else {
            System.out.println("No Staff List found in the table.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : No Staff List found in the table");
//            throw new RuntimeException("No Search Classes Found...");
        }

    }

    public void searchUser(){
        System.out.println("I'm Into Search User in Search box");
        TestRunner.getTest().log(Status.INFO, "I'm Into Search User in Search Box");

        WebElement bottom_panel= driver.findElement(By.xpath("//div[contains(@class,'bottomwrapper')]"));
        bottom_panel.isDisplayed();

        try {
            WebElement searchBox = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder='Search User']")));
            if (searchBox.isDisplayed()) {
                searchBox.click();
                searchBox.clear();
                ((JavascriptExecutor) driver).executeScript("arguments[0].value='';", searchBox);
                System.out.println("I'm into Search User By First Name: " + FirstNameForNewStaff);
                TestRunner.getTest().log(Status.INFO, "I'm into Search User By First Name: " + FirstNameForNewStaff);

                searchUserByFirstName = FirstNameForNewStaff;
                System.out.println("Search User by First name: " + searchUserByFirstName);
                TestRunner.getTest().log(Status.INFO, "Search User by First name: " + searchUserByFirstName);
                searchBox.sendKeys(searchUserByFirstName);

                Actions actions = new Actions(driver);
                actions.sendKeys(Keys.ENTER).perform();
                TestRunner.getTest().log(Status.PASS, "Testcase Passed   : Enter Search User First Name Successfully");

                waitForTableToRefresh();
            } else {
                System.out.println("Search box is not displayed.");
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : Search box is not displayed");
//                throw new RuntimeException("Search Box not  Found.");
            }
        } catch (Exception e) {
            System.out.println("Search box is not available: " + e.getMessage());
        }


    }

    private void waitForTableToRefresh() {
        WebElement tableClasses = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class, 'tabelbodydata')]//tbody")));

//        wait.until(ExpectedConditions.stalenessOf(tableClasses));

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(".//tr")));

        System.out.println("Table has refreshed.");
        TestRunner.getTest().log(Status.INFO, "Table has refreshed.");

    }

    public void verifySearchedStaffByNameIntoTable() throws InterruptedException {

        if (staffNameInTable.contains(searchUserByFirstName)){
            System.out.println("Searched Staff found");
            TestRunner.getTest().log(Status.INFO, "Searched Staff found: " + searchUserByFirstName );
            TestRunner.getTest().log(Status.PASS, "Test case Passed   : Search Staff Found by First Name Successfully");

        } else {
            System.out.println("Searched Staff not found and search filter not working");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : Searched Staff not found and search filter not working");

        }
    }

    public void verifyNewStaffTeacherNameOnPrompt() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm Into Verify that New Staff Teacher Name is Display On Prompt: " + searchUserByFirstName );
        System.out.println("I'm Into Verify that New Staff Teacher Name is Display On Prompt: " + searchUserByFirstName );

        WebElement nameDiv = driver.findElement(By.xpath("//div[contains(@class,'flex justify-center items-start ')]"));

        String staffNameFromPrompt = nameDiv.getText().trim();

        if (staffNameFromPrompt.contains(searchUserByFirstName)) {
            System.out.println("Test Case Passed: New Staff Teacher Name Match on Teacher Information Prompt: " + staffNameFromPrompt);
            TestRunner.getTest().log(Status.PASS,"Test Case Passed: New Staff Teacher Name Match on Teacher Information Prompt: " + staffNameFromPrompt);
        } else {
            System.out.println("New User name does not match on Teacher Information Prompt. Found: " + staffNameFromPrompt + " Expected : " + searchUserByFirstName);
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed: New User name does not match on Teacher Information Prompt. Found: " + staffNameFromPrompt + " Expected : " + searchUserByFirstName);
        }
    }

}
