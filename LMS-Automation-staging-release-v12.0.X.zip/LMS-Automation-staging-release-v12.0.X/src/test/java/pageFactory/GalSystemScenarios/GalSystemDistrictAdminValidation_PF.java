package pageFactory.GalSystemScenarios;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

public class GalSystemDistrictAdminValidation_PF {
    WebDriverWait wait;
    WebDriver driver;
    Helper helper;
    Actions actions;
    JavascriptExecutor js;

    public GalSystemDistrictAdminValidation_PF(WebDriver driver) {
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        helper = new Helper();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        actions = new Actions(driver);
    }

    @FindBy(xpath = "(//div[contains(@class, 'MuiSelect-select')])[3]") // Locate the dropdown
    WebElement dropdown_select_role;

    public String selectedRoleForDistrictAdmin;

    public void selectRoleDistrictAdmin() throws InterruptedException {
        System.out.println("I'm Into Select Role 'District Admin' From Add New Staff / Teacher Prompt");
        TestRunner.getTest().log(Status.INFO, "I'm Into Select Role 'District Admin' From Add New Staff / Teacher Prompt");


        dropdown_select_role.click();

        WebElement listRole = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[contains(@role, 'listbox')]")));
        List<WebElement> optionsRole = listRole.findElements(By.xpath(".//li"));

        System.out.println("Role List is: " + optionsRole.size());

        if (optionsRole.isEmpty()) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: No options found in the Role dropdown");
            System.out.println("No options found in the Role dropdown.");
            throw new RuntimeException("No Role Value found in dropdown");

        } else {
            System.out.println("Role:");

            boolean RoleFound = false;
            String targetRole = "District Admin";

            for (WebElement role : optionsRole) {
                String roleText = role.getText().trim();
                System.out.println(roleText);

                if (roleText.equalsIgnoreCase(targetRole)) {
                    selectedRoleForDistrictAdmin = roleText;
                    role.click();
                    RoleFound = true;
                    System.out.println("Selected Role: " + selectedRoleForDistrictAdmin);
                    TestRunner.getTest().log(Status.INFO, "Selected Role is: " + selectedRoleForDistrictAdmin);
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed: Role selected successfully");
                    break;
                }
            }

            if (!RoleFound) {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: 'District Admin' not found in the dropdown");
                throw new RuntimeException("'District Admin' not found in the dropdown");
            }
        }

    }

    public void VerifyAddOrganizationIsDisable() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm Into Verify That Add Organization Is Disable For District Admin");
        System.out.println("I'm Into Verify That Add Organization Is Disable For District Admin");

        WebElement addOrgButtonWrapper = driver.findElement(By.xpath("//button[contains(., 'Add New Organization')]/ancestor::div[contains(@class,'disabled')]"));
        boolean isAddOrgDisabled = addOrgButtonWrapper != null;
        System.out.println("Add Organization Button Disabled " + isAddOrgDisabled);
        TestRunner.getTest().log(Status.INFO, "Add Organization Button Disabled " + isAddOrgDisabled);

        WebElement schoolTableWrapper = driver.findElement(By.xpath("//div[contains(@class,'addSchoolTable')]/ancestor::div[contains(@class,'disabled')]"));
        boolean isTableDisabled = schoolTableWrapper != null;
        System.out.println("School Table Disabled " + isTableDisabled);
        TestRunner.getTest().log(Status.INFO, "School Table Disabled " + isTableDisabled);

        if (isAddOrgDisabled && isTableDisabled) {
            System.out.println("Both Add Org button and Table are disabled");
            TestRunner.getTest().log(Status.PASS, "Both Add Organization button and Table are disabled For District Admin");
        } else {
            System.out.println("One or both elements are active");
            TestRunner.getTest().log(Status.FAIL, "One or both elements are active and it should be inactive");
        }
    }

}
