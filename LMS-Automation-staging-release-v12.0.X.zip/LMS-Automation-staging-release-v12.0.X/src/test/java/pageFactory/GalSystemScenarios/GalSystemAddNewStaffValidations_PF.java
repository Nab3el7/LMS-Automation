package pageFactory.GalSystemScenarios;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class GalSystemAddNewStaffValidations_PF {

    WebDriverWait wait;
    WebDriver driver;
    Helper helper;
    Actions actions;
    JavascriptExecutor js;

    public GalSystemAddNewStaffValidations_PF(WebDriver driver) {
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        helper = new Helper();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        actions = new Actions(driver);
    }

    public void verifyFirstNameValidation() throws InterruptedException {
        System.out.println("I'm into Verify that First Name Validation is display");
        TestRunner.getTest().log(Status.INFO,"I'm Into Verify That First Name Validation Is Display");

        try {

            WebElement first_name = driver.findElement(By.xpath("//input[@name='firstName']"));
            first_name.clear();

            // Check for validation error
            WebElement firstNameError = driver.findElement(By.xpath("//p[contains(text(),'First Name is required')]"));

            String firstName_field= firstNameError.getText();
            System.out.println("Validation for First Name  : " +  firstName_field);
            TestRunner.getTest().log(Status.INFO, "Validation for First Name  : " +  firstName_field);

            if (firstNameError.isDisplayed()) {
                System.out.println("Test Passed : Validation error displayed: 'First Name is required' Display Successfully");
                TestRunner.getTest().log(Status.PASS, "Test Case Passed : Validation error for 'First Name is required' is correctly displayed.");
            } else {
                System.out.println("Validation error not displayed. Test Failed.");
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Validation error for 'First Name is required' is not displayed.");
                assert false;
            }

        } catch (NoSuchElementException e) {
            // If the element is not found, the validation failed
            System.out.println("Validation error not found. Test Failed.");
            TestRunner.getTest().log(Status.FAIL, "Validation error for 'First Name is required' is not found.");
            assert false;
        }
    }

    public void verifyLastNameValidation() throws InterruptedException {
        System.out.println("I'm into Verify that Last Name Validation is display");
        TestRunner.getTest().log(Status.INFO,"I'm Into Verify That Last Name Validation Is Display");

        try {

            WebElement last_name = driver.findElement(By.xpath("//input[@name='lastName']"));
            last_name.clear();

            // Check for validation error
            WebElement lastNameError = driver.findElement(By.xpath("//p[contains(text(),'Last Name is required')]"));

            String lastName_field= lastNameError.getText();
            System.out.println("Validation for Last Name  : " +  lastName_field);
            TestRunner.getTest().log(Status.INFO, "Validation for Last Name  : " +  lastName_field);

            if (lastNameError.isDisplayed()) {
                System.out.println("Test Passed : Validation error displayed: 'Last Name is required' Display Successfully");
                TestRunner.getTest().log(Status.PASS, "Test Case Passed : Validation error for 'Last Name is required' is correctly displayed.");
            } else {
                System.out.println("Validation error not displayed. Test Failed.");
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Validation error for 'Last Name is required' is not displayed.");
                assert false;
            }

        } catch (NoSuchElementException e) {
            // If the element is not found, the validation failed
            System.out.println("Validation error not found. Test Failed.");
            TestRunner.getTest().log(Status.FAIL, "Validation error for 'Last Name is required' is not found.");
            assert false;
        }

    }

    public void verifyEmailValidation() throws InterruptedException {
        System.out.println("I'm into Verify that Email Validation is display");
        TestRunner.getTest().log(Status.INFO,"I'm Into Verify That Email Validation Is Display");

        try {

            WebElement email = driver.findElement(By.xpath("//input[@name='email']"));
            email.clear();

            // Check for validation error
            WebElement emailError = driver.findElement(By.xpath("//p[contains(text(),'Email is required')]"));

            String email_field= emailError.getText();
            System.out.println("Validation for Email  : " +  email_field);
            TestRunner.getTest().log(Status.INFO, "Validation for Email  : " +  email_field);

            if (emailError.isDisplayed()) {
                System.out.println("Test Passed : Validation error displayed: 'Email is required' Display Successfully");
                TestRunner.getTest().log(Status.PASS, "Test Case Passed : Validation error for 'Email is required' is correctly displayed.");
            } else {
                System.out.println("Validation error not displayed. Test Failed.");
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Validation error for 'Email is required' is not displayed.");
                assert false;
            }

        } catch (NoSuchElementException e) {
            // If the element is not found, the validation failed
            System.out.println("Validation error not found. Test Failed.");
            TestRunner.getTest().log(Status.FAIL, "Validation error for 'Email is required' is not found.");
            assert false;
        }

    }

    public void verifyPasswordValidation() throws InterruptedException {
        System.out.println("I'm into Verify that Password Validation is display");
        TestRunner.getTest().log(Status.INFO,"I'm Into Verify That Password Validation Is Display");

        try {

            WebElement password = driver.findElement(By.xpath("//input[@name='password']"));
            password.clear();

            // Check for validation error
            WebElement passwordError = driver.findElement(By.xpath("//p[contains(text(),'Password is required')]"));

            String password_field= passwordError.getText();
            System.out.println("Validation for Password  : " +  password_field);
            TestRunner.getTest().log(Status.INFO, "Validation for Password  : " +  password_field);

            if (passwordError.isDisplayed()) {
                System.out.println("Test Passed : Validation error displayed: 'Password is required' Display Successfully");
                TestRunner.getTest().log(Status.PASS, "Test Case Passed : Validation error for 'Password is required' is correctly displayed.");
            } else {
                System.out.println("Validation error not displayed. Test Failed.");
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Validation error for 'Password is required' is not displayed.");
                assert false;
            }

        } catch (NoSuchElementException e) {
            // If the element is not found, the validation failed
            System.out.println("Validation error not found. Test Failed.");
            TestRunner.getTest().log(Status.FAIL, "Validation error for 'Password is required' is not found.");
            assert false;
        }
    }

    public void verifyConfirmPasswordValidation() throws InterruptedException {
        System.out.println("I'm into Verify that Confirm Password Validation is display");
        TestRunner.getTest().log(Status.INFO,"I'm Into Verify That Confirm Password Validation Is Display");

        try {

            WebElement confirmPassword = driver.findElement(By.xpath("//input[@name='stdConfirmPassword']"));
            confirmPassword.clear();

            // Check for validation error
            WebElement confirmPasswordError = driver.findElement(By.xpath("//p[contains(text(),'Confirm Password is required')]"));

            String Confirm_password_field= confirmPasswordError.getText();
            System.out.println("Validation for Confirm Password  : " +  Confirm_password_field);
            TestRunner.getTest().log(Status.INFO, "Validation for Confirm Password  : " +  Confirm_password_field);

            if (confirmPasswordError.isDisplayed()) {
                System.out.println("Test Passed : Validation error displayed: 'Confirm Password is required' Display Successfully");
                TestRunner.getTest().log(Status.PASS, "Test Case Passed : Validation error for 'Confirm Password is required' is correctly displayed.");
            } else {
                System.out.println("Validation error not displayed. Test Failed.");
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Validation error for 'Confirm Password is required' is not displayed.");
                assert false;
            }

        } catch (NoSuchElementException e) {
            // If the element is not found, the validation failed
            System.out.println("Validation error not found. Test Failed.");
            TestRunner.getTest().log(Status.FAIL, "Validation error for 'Confirm Password is required' is not found.");
            assert false;
        }
    }

    public void verifyAddOrganizationValidation() throws InterruptedException {
        System.out.println("I'm into Verify that Add Organization Validation is display With Selecting Any Organization");
        TestRunner.getTest().log(Status.INFO,"I'm Into Verify That Add Organization Validation Is Display With Selecting Any Organization");

        try {

//            WebElement confirmPassword = driver.findElement(By.xpath("//input[@name='stdConfirmPassword']"));
//            confirmPassword.clear();

            // Check for validation error
            WebElement addOrganizationError = driver.findElement(By.xpath("//div[contains(text(),'No Detail Found')]"));

            String addOrganization_field= addOrganizationError.getText();
            System.out.println("Validation for Add Organization  : " +  addOrganization_field);
            TestRunner.getTest().log(Status.INFO, "Validation for Add Organization  : " +  addOrganization_field);

            if (addOrganizationError.isDisplayed()) {
                System.out.println("Test Passed : Validation error displayed: 'No Detail Found' Display Successfully");
                TestRunner.getTest().log(Status.PASS, "Test Case Passed : Validation error for 'No Detail Found' is correctly displayed.");
            } else {
                System.out.println("Validation error not displayed. Test Failed.");
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Validation error for 'No Detail Found' is not displayed.");
                assert false;
            }

             WebElement addOrganizationSchoolError = driver.findElement(By.xpath("//div[contains(text(),'At least one school needs to be added for the roles of Campus Admin and/or Teacher.')]"));

            String addOrganizationSchool_field= addOrganizationSchoolError.getText();
            System.out.println("Validation for Add Organization  : " +  addOrganizationSchool_field);
            TestRunner.getTest().log(Status.INFO, "Validation for Add Organization  : " +  addOrganizationSchool_field);

            if (addOrganizationSchoolError.isDisplayed()) {
                System.out.println("Test Passed : Validation error displayed: 'At least one school needs to be added for the roles of Campus Admin and/or Teacher.' Display Successfully");
                TestRunner.getTest().log(Status.PASS, "Test Case Passed : Validation error for 'At least one school needs to be added for the roles of Campus Admin and/or Teacher.' is correctly displayed.");
            } else {
                System.out.println("Validation error not displayed. Test Failed.");
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Validation error for 'At least one school needs to be added for the roles of Campus Admin and/or Teacher.' is not displayed.");
                assert false;
            }

        } catch (NoSuchElementException e) {
            // If the element is not found, the validation failed
            System.out.println("Validation error not found. Test Failed.");
            TestRunner.getTest().log(Status.FAIL, "Validation error for 'No Detail Found' is not found.");
            assert false;
        }
    }


    public void verifyPhoneNumberValidation() throws InterruptedException{
        System.out.println("I'm into Verify that PhoneNumber Validation is display");
        TestRunner.getTest().log(Status.INFO,"I'm Into Verify That PhoneNumber Validation Is Display");

        try {

            WebElement phoneNumberField = driver.findElement(By.xpath("//input[@name='phone']"));
            helper.scrollToElement(driver, phoneNumberField);

            phoneNumberField.clear();

            phoneNumberField.sendKeys("1");


            // Check for validation error
            WebElement phoneNumberError = driver.findElement(By.xpath("//p[@id='textField-phone-helper-text']"));

            String phoneNumber_field= phoneNumberError.getText();
            System.out.println("Validation for Phone Number  : " +  phoneNumber_field);
            TestRunner.getTest().log(Status.INFO, "Validation for Phone Number  : " +  phoneNumber_field);

            if (phoneNumberError.isDisplayed()) {
                System.out.println("Test Passed : Validation error displayed: 'Phone Number Validation' Display Successfully");
                TestRunner.getTest().log(Status.PASS, "Test Case Passed : Validation error for 'Phone Number Validation'' is correctly displayed.");
            } else {
                System.out.println("Validation error not displayed. Test Failed.");
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Validation error for 'Phone Number Validation'' is not displayed.");
                assert false;
            }


        } catch (NoSuchElementException e) {
            // If the element is not found, the validation failed
            System.out.println("Validation error not found. Test Failed.");
            TestRunner.getTest().log(Status.FAIL, "Validation error for 'Phone Number Validation' is not found.");
            assert false;
        }
    }

    public void verifyInvalidEmailValidation() throws InterruptedException{

        System.out.println("I'm into Verify that Invalid Email Format Validation is display");
        TestRunner.getTest().log(Status.INFO,"I'm Into Verify That Invalid Email  Validation Is Display");

        try {

            WebElement email_Field = driver.findElement(By.xpath("//input[@name='email']"));
            helper.scrollToElement(driver, email_Field);
            email_Field.click();

            String oldEmail = email_Field.getAttribute("value");
            System.out.println("Email: " + oldEmail);
            TestRunner.getTest().log(Status.INFO,"Email: " + oldEmail);

            Actions actions = new Actions(driver);
            email_Field.click();

            for (int i = 0; i < oldEmail.length(); i++) {
                actions.sendKeys(Keys.BACK_SPACE).perform();
            }

            email_Field.sendKeys("fl");

            // Check for validation error
            WebElement Invalid_Email_Format_Email_Error = driver.findElement(By.xpath("//p[contains(text(),'Invalid email format')]"));

            String Invalid_email_field= Invalid_Email_Format_Email_Error.getText();
            System.out.println("Validation for Invalid Email : " +  Invalid_email_field);
            TestRunner.getTest().log(Status.INFO, "Validation for Invalid Email : " +  Invalid_email_field);

            if (Invalid_Email_Format_Email_Error.isDisplayed()) {
                System.out.println("Test Passed : Validation error displayed: 'Invalid email format' Display Successfully");
                TestRunner.getTest().log(Status.PASS, "Test Case Passed : Validation error for 'Invalid email format' is correctly displayed.");
            } else {
                System.out.println("Validation error not displayed. Test Failed.");
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Validation error for 'Invalid email format' is not displayed.");
                assert false;
            }

        } catch (NoSuchElementException e) {
            // If the element is not found, the validation failed
            System.out.println("Validation error not found. Test Failed.");
            TestRunner.getTest().log(Status.FAIL, "Validation error for 'Invalid email format' is not found.");
            assert false;
        }

    }

    public void verifyAlreadyExistingEmailValidation() throws InterruptedException {
        System.out.println("I'm into Verify that Already Existing Email Format Validation is displayed");
        TestRunner.getTest().log(Status.INFO, "I'm Into Verify That Already Existing Email Validation Is Displayed");

        try {
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

            WebElement email_Field = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@name='email']")));
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", email_Field);
            Thread.sleep(300);

            email_Field.click();

            String oldEmail = email_Field.getAttribute("value");
            System.out.println("Email: " + oldEmail);
            TestRunner.getTest().log(Status.INFO,"Email: " + oldEmail);

            Actions actions = new Actions(driver);
            email_Field.click();

            for (int i = 0; i < oldEmail.length(); i++) {
                actions.sendKeys(Keys.BACK_SPACE).perform();
            }


            email_Field.sendKeys("saadiateacher-112@gp.com");

            Thread.sleep(1000);

            clickSaveButtonForValidation();

            WebElement alreadyUsedError = driver.findElement(By.xpath("//p[contains(text(),'Email already in use')]"));
            String errorText = alreadyUsedError.getText();

            System.out.println("Validation for Already Existing Email: " + errorText);
            TestRunner.getTest().log(Status.INFO, "Validation for Already Existing Email: " + errorText);

            if (alreadyUsedError.isDisplayed()) {
                System.out.println("Test Passed: Validation error displayed: 'Email already in use'");
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: Validation error for 'Email already in use' is correctly displayed.");
            } else {
                System.out.println("Validation error not displayed. Test Failed.");
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Validation error for 'Email already in use' is not displayed.");
                assert false;
            }

        } catch (NoSuchElementException e) {
            System.out.println("Validation error not found. Test Failed.");
            TestRunner.getTest().log(Status.FAIL, "Validation error for 'Email already in use' is not found.");
            assert false;
        }
    }

    public void clickSaveButtonForValidation() throws InterruptedException {

        WebElement save_btn= driver.findElement(By.xpath("//button[@name='btn-signin']"));

        save_btn.click();

    }
}
