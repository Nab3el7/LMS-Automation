package pageFactory.GalSystemScenarios;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.sl.In;
import org.junit.Assert;
import org.junit.Test;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;
import java.util.Random;

import static pageFactory.GalSystemScenarios.GalSystemAddNewStaff_PF.staffNameInTable;
import static pageFactory.GalSystemScenarios.SearchExistingStaff_PF.existingStaffNameInTable;

public class GalSystemEditExistingStudent_PF {

    WebDriverWait wait;
    WebDriver driver;
    Helper helper;
    Actions actions;
    JavascriptExecutor js;

    public GalSystemEditExistingStudent_PF(WebDriver driver) {
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        helper = new Helper();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        actions = new Actions(driver);
    }

    @FindBy(xpath = "//div[contains(@class, 'tabelbodydata')]//tbody")
    WebElement questionsContainerTable;


    public void fromRoleFilterSelectStudent() throws InterruptedException {

        TestRunner.getTest().log(Status.INFO,"I'm Into Select Student From Role Filter");
        System.out.println("I'm Into Select Student From Role Filter");

        String[] roleArray = {"Student"};

        for (String role : roleArray) {
            TestRunner.getTest().log(Status.INFO, "Filtering Role Dropdown: " + role);

            try {
                WebElement statusDropdown = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(@class, 'MuiSelect-select') and @role='button' or @role='combobox'])[1]")));
                statusDropdown.click();

                List<WebElement> statusOptions = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//ul[@role='listbox']//li")));
                boolean statusFound = false;

                for (WebElement option : statusOptions) {
                    String optionText = option.getText().trim();
                    if (optionText.equalsIgnoreCase(role)) {
                        option.click();
                        statusFound = true;
                        TestRunner.getTest().log(Status.INFO, "Selected Role: " + optionText);
                        break;
                    }
                }

                if (!statusFound) {
                    TestRunner.getTest().log(Status.FAIL, "Role not found in the dropdown: " + role);
                    throw new RuntimeException("Role not found in the dropdown: " + role);
                }

//                Thread.sleep(2000);
                waitForTableToRefreshForGalSystem();

                if (isNoDataFoundDisplayed()) {
                    TestRunner.getTest().log(Status.INFO, "No Data found for the Role: " + role);
                    System.out.println("No Data found for the Role: " + role);
                    continue;
                }

                WebElement questionsTable = wait.until(ExpectedConditions.visibilityOf(questionsContainerTable));
                List<WebElement> questionRows = questionsTable.findElements(By.xpath(".//tr"));

                boolean allRowsMatchStatus = true;

//                for (WebElement row : questionRows) {
//                    WebElement statusCell = row.findElement(By.xpath(".//td[contains(@class, 'cell-3')]"));
//                    String rowStatus = statusCell.getText().trim();
//
//                    if (!rowStatus.equalsIgnoreCase(role)) {
//                        allRowsMatchStatus = false;
//                        System.out.println("Row Role is: " + rowStatus);
//                        TestRunner.getTest().log(Status.FAIL, "Data with mismatched Role found: " + rowStatus);
//                    } else {
//                        TestRunner.getTest().log(Status.INFO, "Data row with Role: " + rowStatus);
//                    }
//                }

                for (WebElement row : questionRows) {
                    WebElement statusCell = row.findElement(By.xpath(".//td[contains(@class, 'cell-3')]"));
                    String rowStatus = statusCell.getText();
                    String expectedRole = role.replaceAll("\\s+", "").trim();               // sanitize expected role too

                    if (!rowStatus.equalsIgnoreCase(expectedRole)) {
                        allRowsMatchStatus = false;
                        System.out.println("Row Role is: " + rowStatus);
                        TestRunner.getTest().log(Status.FAIL, "Data with mismatched Role found: " + rowStatus);
                    } else {
                        TestRunner.getTest().log(Status.INFO, "Data row with Role: " + rowStatus);
                    }
                }


                if (allRowsMatchStatus) {
                    TestRunner.getTest().log(Status.PASS, "All Data match the selected Role: " + role);
                } else {
                    TestRunner.getTest().log(Status.FAIL, "Some Data do not match the selected Role: " + role);
                }

            } catch (NoSuchElementException | ElementNotInteractableException e) {
                TestRunner.getTest().log(Status.WARNING, "Table not load in current time frame");
            }
        }
    }

    private boolean isNoDataFoundDisplayed() {
        try {
            WebElement noDataFound = driver.findElement(By.xpath("//div[contains(@class, 'tabelbodydata')]//div[contains(text(),'No Detail Found')]"));
            return noDataFound.isDisplayed();
        } catch (NoSuchElementException e) {
            return false;
        }
    }

    private void waitForTableToRefreshForGalSystem() throws InterruptedException{
        try {
            WebElement questionsTable = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class, 'tabelbodydata')]//tbody")));

            List<WebElement> rowsBeforeRefresh = questionsTable.findElements(By.xpath(".//tr"));
            System.out.println("Number of rows before refresh: " + rowsBeforeRefresh.size());

            Thread.sleep(2000);

            List<WebElement> rowsAfterRefresh = questionsTable.findElements(By.xpath(".//tr"));
            System.out.println("Number of rows after refresh: " + rowsAfterRefresh.size());

            if (rowsBeforeRefresh.size() != rowsAfterRefresh.size()) {
                System.out.println("Table has refreshed. Number of rows before refresh: " + rowsBeforeRefresh.size() + ", after refresh: " + rowsAfterRefresh.size());
                TestRunner.getTest().log(Status.INFO, "Table has refreshed. Number of rows before refresh: " + rowsBeforeRefresh.size() + ", after refresh: " + rowsAfterRefresh.size());
            } else {
                System.out.println("Table did not refresh as expected. Rows before: " + rowsBeforeRefresh.size() + ", Rows after: " + rowsAfterRefresh.size());
            }

            for (WebElement row : rowsAfterRefresh) {
                System.out.println("Table Row: " + row.getText());
            }

        } catch (NoSuchElementException | TimeoutException e) {
            System.out.println("Error while waiting for table refresh: " + e.getMessage());
//            TestRunner.getTest().log(Status.FAIL,"Test Case Fail : Error while waiting for table refresh");

        }

    }

    public String ExistingStudent="Automated Student";

    public static String searchStudentByFirstName;

    public void searchStudentInSearchBoxGalSystem() throws InterruptedException {
        System.out.println("I'm Into Search Student In Search box");
        TestRunner.getTest().log(Status.INFO,"I'm Into Search Student In Search box");


        System.out.println("I'm Into Search Existing Student in Search box");
        TestRunner.getTest().log(Status.INFO, "I'm Into Search Existing Student in Search Box");

        WebElement bottom_panel= driver.findElement(By.xpath("//div[contains(@class,'bottomwrapper')]"));
        bottom_panel.isDisplayed();

        try {
            WebElement searchBox = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder='Search User']")));
            if (searchBox.isDisplayed()) {
                searchBox.click();
                searchBox.clear();
                ((JavascriptExecutor) driver).executeScript("arguments[0].value='';", searchBox);
                System.out.println("I'm into Search Existing Student By Name: " + ExistingStudent);
                TestRunner.getTest().log(Status.INFO, "I'm into Search Existing Student By Name: " + ExistingStudent);

                searchStudentByFirstName = ExistingStudent;
                System.out.println("Search Existing Student by name: " + searchStudentByFirstName);
                TestRunner.getTest().log(Status.INFO, "Search Existing Student by name: " + searchStudentByFirstName);
                searchBox.sendKeys(searchStudentByFirstName);

                Actions actions = new Actions(driver);
                actions.sendKeys(Keys.ENTER).perform();
                TestRunner.getTest().log(Status.PASS, "Testcase Passed   : Enter Search Existing Student Name Successfully");

                waitForTableToRefresh();
            } else {
                System.out.println("Search box is not displayed.");
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : Search box is not displayed");
//                throw new RuntimeException("Search Box not  Found.");
            }
        } catch (Exception e) {
            System.out.println("Search box is not available: " + e.getMessage());
        }


    }

    private void waitForTableToRefresh() {
        WebElement tableClasses = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class, 'tabelbodydata')]//tbody")));

//        wait.until(ExpectedConditions.stalenessOf(tableClasses));

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(".//tr")));

        System.out.println("Table has refreshed.");
        TestRunner.getTest().log(Status.INFO, "Table has refreshed.");

    }

    public String randomExStudentName;
    public String randomExStudentEmail;

    public void selectRandomStudentAndClickEdit() throws InterruptedException {
        System.out.println("I'm Into Select Random Student From Table");
        TestRunner.getTest().log(Status.INFO, "I'm Into Select Random Student From Table");

        // Wait for the table to be visible
        WebElement staffTable = wait.until(ExpectedConditions.presenceOfElementLocated(
                By.xpath("//div[contains(@class, 'tabelbodydata')]//tbody")));

        List<WebElement> rows = staffTable.findElements(By.xpath(".//tr"));

        if (!rows.isEmpty()) {
            Random random = new Random();
            int randomIndex = random.nextInt(rows.size());
            WebElement randomRow = rows.get(randomIndex);

            // Get Student Name and Email
            WebElement nameElement = randomRow.findElement(By.xpath(".//td[contains(@class, 'MuiTableCell')]//div[contains(@class,'rightSide')]//h6"));
            randomExStudentName = nameElement.getText();

            WebElement emailElement = randomRow.findElement(By.xpath(".//td[3]")); // Adjust if needed
            randomExStudentEmail = emailElement.getText();

            System.out.println("Random Student: " + randomExStudentName + " | " + randomExStudentEmail);
            TestRunner.getTest().log(Status.INFO, "Random Student: " + randomExStudentName + " | " + randomExStudentEmail);

            System.out.println("I'm Into Click on Edit Option");
            TestRunner.getTest().log(Status.INFO, "I'm Into Click on Edit Option");

            WebElement editDots = randomRow.findElement(By.xpath(".//button[@aria-label='DropDownButtom']"));
            editDots.click();

            // Wait for menu to appear and click "View / Edit"
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//ul[@role='menu']//li")));
            WebElement editBtn = driver.findElement(By.xpath("//ul[@role='menu']//span[normalize-space()='View / Edit']"));
            editBtn.click();

            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
            TestRunner.getTest().log(Status.PASS, "Edit button clicked successfully for student: " + randomExStudentName);
        } else {
            System.out.println("No students found in the table.");
            TestRunner.getTest().log(Status.FAIL, "No students found in the table.");
        }
    }


    public void verifyStudentInformationPromptDisplay() throws InterruptedException {
        System.out.println("I'm Into Verify that Student Information Prompt is display");
        TestRunner.getTest().log(Status.INFO, "I'm Into Verify that Student Information Prompt is display");
        Thread.sleep(2000);

        WebElement prompt = driver.findElement(By.xpath("//div[@role='dialog']"));
        boolean isDisplayed = prompt.isDisplayed();
        Assert.assertTrue("Prompt is not displayed.", isDisplayed);

        WebElement promptHeader = prompt.findElement(By.tagName("h2"));
        String headerText = promptHeader.getText();
        System.out.println("Prompt header text is: " + headerText);
        TestRunner.getTest().log(Status.PASS, "Test Case Passed   : Student Information Prompt Display Successfully");
    }

    public void verifyStudentNameOnPrompt() throws InterruptedException {
        System.out.println("I'm into Verify Student Name is Present on Student Information Prompt");
        TestRunner.getTest().log(Status.INFO, "I'm into Verify Student Name is Present on Student Information Prompt");

        WebElement nameDiv = driver.findElement(By.xpath("(//div[contains(@class,'flex justify-center items-start ')]//span)[1]"));

        String studentNameFromPrompt = nameDiv.getText().trim();

        if (studentNameFromPrompt.equalsIgnoreCase(randomExStudentName)) {
            System.out.println("Test Case Passed: Student Name Match on Student Information Prompt: " + studentNameFromPrompt);
            TestRunner.getTest().log(Status.PASS,"Test Case Passed: Student Name Match on Student Information Prompt: " + studentNameFromPrompt);
        } else {
            System.out.println("Student name does not match on Student Information Prompt. Found: " + studentNameFromPrompt + " Expected : " + randomExStudentName);
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed: Student name does not match on Student Information Prompt. Found: " + studentNameFromPrompt + " Expected : " + randomExStudentName);
        }


        System.out.println("I'm Into Verify That Student Name is Also Present on Bottom of Prompt");
        TestRunner.getTest().log(Status.INFO, "I'm Into Verify That Student Name is Also Present on Bottom of Prompt");


        WebElement bottomNameDiv = driver.findElement(By.xpath("(//div[contains(@class, 'flex justify-center')]//span)[3]"));

        String studentNameFromPromptBottom = bottomNameDiv.getText().trim();

        if (studentNameFromPromptBottom.equalsIgnoreCase(randomExStudentName)) {
            System.out.println("Test Case Passed: Student Name Match on Student Information Prompt: " + studentNameFromPromptBottom);
            TestRunner.getTest().log(Status.PASS,"Test Case Passed: Student Name Match on Student Information Prompt: " + studentNameFromPromptBottom);
        } else {
            System.out.println("Student name does not match on Student Information Prompt. Found: " + studentNameFromPromptBottom + " Expected : " + randomExStudentName);
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed: Student name does not match on Student Information Prompt. Found: " + studentNameFromPromptBottom + " Expected : " + randomExStudentName);
        }
    }


    public void verifyClassEnrollmentStatusIsPresent() throws InterruptedException {
        System.out.println("I'm Into Verify That Class Enrollment Status is Also Present On Prompt");
        TestRunner.getTest().log(Status.INFO, "I'm Into Verify That Class Enrollment Status is Also Present on Prompt");

        try {
            // Wait for the status element to be present
            WebElement statusElement = wait.until(ExpectedConditions.visibilityOfElementLocated(
                    By.xpath("//span[@class='status']")));

            String enrollmentStatus = statusElement.getText().trim();

            if (!enrollmentStatus.isEmpty()) {
                System.out.println("Class Enrollment Status is visible: " + enrollmentStatus);
                TestRunner.getTest().log(Status.PASS, "Class Enrollment Status is visible: " + enrollmentStatus);

                // Optional: verify if it's Active or Inactive
                if (enrollmentStatus.equalsIgnoreCase("Active") || enrollmentStatus.equalsIgnoreCase("Inactive")) {
                    System.out.println("Status is valid: " + enrollmentStatus);
                } else {
                    System.out.println("Unexpected Status: " + enrollmentStatus);
                }
            } else {
                System.out.println("Class Enrollment Status element is present but empty.");
                TestRunner.getTest().log(Status.FAIL, "Class Enrollment Status element is present but empty.");
            }

        } catch (TimeoutException e) {
            System.out.println("Class Enrollment Status not found on the page.");
            TestRunner.getTest().log(Status.FAIL, "Class Enrollment Status not found on the page.");
        }

    }

    @FindBy(xpath = "//input[@name='userName']")
    WebElement email;

    public void editStudentLoginEmail() throws InterruptedException {

        TestRunner.getTest().log(Status.INFO,"I'm Into Edit Student Login Email on Student Information Prompt");
        System.out.println("I'm Into Edit Student Login Email on Student Information Prompt");


        String oldEmail = email.getAttribute("value");
        System.out.println("Previous Email of Student: " + oldEmail);
        TestRunner.getTest().log(Status.INFO,"Previous Email of Student: " + oldEmail);

        Actions actions = new Actions(driver);
        email.click();

        for (int i = 0; i < oldEmail.length(); i++) {
            actions.sendKeys(Keys.BACK_SPACE).perform();
        }

        email.click();
        for (int i = 0; i < oldEmail.length(); i++) {
            actions.sendKeys(Keys.BACK_SPACE).perform();
        }

        email.click();
        for (int i = 0; i < oldEmail.length(); i++) {
            actions.sendKeys(Keys.BACK_SPACE).perform();
        }

        email.click();
        for (int i = 0; i < oldEmail.length(); i++) {
            actions.sendKeys(Keys.BACK_SPACE).perform();
        }

        String newEmail = randomClassNewStdEmail("autoupdatedstd");
        email.sendKeys(newEmail);

        updatedEmailStudent = email.getAttribute("value");
        System.out.println("Updated Email is: " + updatedEmailStudent);

        if (!oldEmail.equals(updatedEmailStudent)) {
            System.out.println("Email updated Successfully");
            TestRunner.getTest().log(Status.INFO, "Email changed from '" + oldEmail + "' to '" + updatedEmailStudent + "'.");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Email  Edit successfully");
        } else {
            System.out.println("Email was not changed");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Email was not changed");
        }

    }

    public static String updatedEmailStudent;
    public static String updatedPasswordStudent;


    public String randomClassNewStdEmail (String prefix){
        Random randemail = new Random();
        int randomInt = randemail.nextInt(1000);
        return prefix + randomInt + "@gallopade.com";
    }

    public void EditNewStudentPasswordFromGalSystem() throws InterruptedException {

        TestRunner.getTest().log(Status.INFO, "Enter Password On Student Information Prompt");
        System.out.println("Enter Password On Student Information Prompt");

        Thread.sleep(1000);
        WebElement passwordField = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@name='stdPassword']")));

        passwordField.clear();

        Actions actions = new Actions(driver);
        actions.moveToElement(passwordField).click().sendKeys("Fltester23").perform();

        System.out.println("Password added Successfully");

        actions.sendKeys(Keys.TAB);

        updatedPasswordStudent = passwordField.getAttribute("value");
        System.out.println("Password field value after input: " + updatedPasswordStudent);
        TestRunner.getTest().log(Status.INFO, "Updated Password  For Student is: " + updatedPasswordStudent);

        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Password enter successfully");
    }

    public void editConfirmPasswordFromGalSystem() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Enter Confirm Password On Student Information Prompt");
        System.out.println("Enter Confirm Password On Student Information Prompt");

        Thread.sleep(2000);

        WebElement confirmPasswordField = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@name='stdConfirmPassword']")));

        confirmPasswordField.clear();

        Actions actions = new Actions(driver);
        actions.moveToElement(confirmPasswordField).click().sendKeys("Fltester23").perform();

        System.out.println("Confirm Password added Successfully");

        String confirmPasswordValue = confirmPasswordField.getAttribute("value");
        System.out.println("Confirm Password field value after input: " + confirmPasswordValue);
        TestRunner.getTest().log(Status.INFO, "New Confirm Password is: " + confirmPasswordValue);

        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Confirm Password enter successfully");

    }


    public void ClickUpdateButtonOnStudentInformationGalSystem() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm Into Verify and Click on Update Button On Student Information Prompt");
        System.out.println("I'm Into Verify and Click on Update Button On Student Information Prompt");

        WebElement update_btn= driver.findElement(By.xpath("//button[normalize-space()='Update']"));

        if (update_btn.isEnabled() && update_btn.isDisplayed()){
            update_btn.click();
            System.out.println("Update Button click Successfully");
            TestRunner.getTest().log(Status.PASS,"Test Case Passed: Update Button Click Successfully");
        }else {
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed: Update Button is not Display/Enabled");
        }
    }


    public void clickCrossButtonSearchBox() throws InterruptedException {
        System.out.println("I'm Into Verify And Click on Clear Search Box");
        TestRunner.getTest().log(Status.INFO, "I'm Into Verify And Click on Clear Search Box");
        Thread.sleep(2000);


        WebElement searchBox = wait.until(ExpectedConditions.presenceOfElementLocated(
                By.xpath("//input[contains(@id, 'SearchField')]")));

        ((JavascriptExecutor) driver).executeScript("arguments[0].value = '';", searchBox);


        TestRunner.getTest().log(Status.PASS,"Search Box Clear successfully");

    }


    public static String searchUpdatedStudentByName;
    public void searchUpdatedStudent() throws InterruptedException{
        System.out.println("I'm Into Search Updated Student in Search box");
        TestRunner.getTest().log(Status.INFO, "I'm Into Search Updated Student in Search Box");
        Thread.sleep(5000);

        WebElement bottom_panel= driver.findElement(By.xpath("//div[contains(@class,'bottomwrapper')]"));
        bottom_panel.isDisplayed();

        try {
            WebElement searchBox = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder='Search User']")));
            if (searchBox.isDisplayed()) {
                searchBox.click();
                searchBox.clear();
                ((JavascriptExecutor) driver).executeScript("arguments[0].value='';", searchBox);
                System.out.println("I'm into Search Updated Student By Name: " + randomExStudentName);
                TestRunner.getTest().log(Status.INFO, "I'm into Search Updated Student By Name: " + randomExStudentName);

                searchUpdatedStudentByName = randomExStudentName;
                System.out.println("I'm into Search Updated Student By Name:: " + searchUpdatedStudentByName);
                TestRunner.getTest().log(Status.INFO, "I'm into Search Updated Student By Name:: " + searchUpdatedStudentByName);
                searchBox.sendKeys(searchUpdatedStudentByName);

                Actions actions = new Actions(driver);
                actions.sendKeys(Keys.ENTER).perform();
                TestRunner.getTest().log(Status.PASS, "Testcase Passed   : Enter Search Updated Student By Name Successfully");

                waitForTableToRefresh();
            } else {
                System.out.println("Search box is not displayed.");
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : Search box is not displayed");
//                throw new RuntimeException("Search Box not  Found.");
            }
        } catch (Exception e) {
            System.out.println("Search box is not available: " + e.getMessage());
        }


    }

    public void verifySearchedStudentByNameIntoTable() throws InterruptedException{

        if (staffNameInTable.contains(searchUpdatedStudentByName)){
            System.out.println("Searched Student found");
            TestRunner.getTest().log(Status.INFO, "Searched Existing Student found: " + searchUpdatedStudentByName );
            TestRunner.getTest().log(Status.PASS, "Test case Passed   : Search Existing Student Found by Name Successfully");

        } else {
            System.out.println("Searched Student not found and search filter not working");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : Searched Student not found and search filter not working");

        }
    }

    @FindBy(xpath = "//div[contains(@class, 'tabelbodydata')]")
    WebElement studentTable;

    public void VerifyStudentEmailUpdateInTable() throws InterruptedException {

        System.out.println("I'm Into Verify That New Email is Also Updated in the Student Table");
        TestRunner.getTest().log(Status.INFO, "I'm Into Verify That New Email is Also Updated in the Student Table");

        Thread.sleep(3000);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class, 'tabelbodydata')]//tbody")));

        List<WebElement> rows = studentTable.findElements(By.xpath(".//tbody/tr"));

        if (!rows.isEmpty()) {
            WebElement row = rows.get(0);
            WebElement emailCell = row.findElement(By.xpath(".//td[3]"));

            String emailInTable = emailCell.getText().trim();
            System.out.println("Email found in table: " + emailInTable);
            TestRunner.getTest().log(Status.INFO, "Email found in table: " + emailInTable);


            if (emailInTable.equalsIgnoreCase(updatedEmailStudent)) {
                System.out.println("Email matched: " + emailInTable);
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: Email matched: " + emailInTable);
            } else {
                System.out.println("Email did not match. Expected: " + updatedEmailStudent + ", Found: " + emailInTable);
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Email did not match. Expected: " + updatedEmailStudent + ", Found: " + emailInTable);
            }
        } else {
            System.out.println("No rows found in the table.");
            TestRunner.getTest().log(Status.FAIL, "No rows found in the staff table.");
        }
    }

    public void verifyStudentNameOnDashboard() throws InterruptedException {
        System.out.println("I'm Into Verify Student Name on Student Dashboard");
        TestRunner.getTest().log(Status.INFO,"I'm Into Verify Student Name on Student Dashboard");

        WebElement studentNameElement = driver.findElement(By.xpath("//div[contains(@class,'studentPortal-header')]//span[@class='notranslate']"));
        String studentName = studentNameElement.getText();
        System.out.println("Student Name: " + studentName);
        TestRunner.getTest().log(Status.INFO,"Student Name On Student Dashboard: " + studentName);

        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Student Name Found Successfully on Student Dashboard");
    }


    public void verifyViewUsageButton() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm Into verify View Usage Button");
        System.out.println("I'm into verify view usage Button");

        WebElement btn_viewUsage= driver.findElement(By.xpath("//button[normalize-space()='View Usage']"));

        if (btn_viewUsage.isDisplayed()) {
            btn_viewUsage.click();
            TestRunner.getTest().log(Status.PASS,"Test Case Passed: View Usage Button is Displayed and Clicked Successfully");
        }else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: View Usage Button is not Displayed/Enabled");
        }
    }

    public void verifyStudentUsagePromptDisplay() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm Into Verify that Student Usage Prompt is Display");
        System.out.println("I'm into Verify that student Usage Prompt is Display");

        Thread.sleep(2000);

        WebElement prompt = driver.findElement(By.xpath("//div[@role='dialog']"));
        boolean isDisplayed = prompt.isDisplayed();
        Assert.assertTrue("Prompt is not displayed.", isDisplayed);

        WebElement promptHeader = prompt.findElement(By.tagName("h2"));
        String headerText = promptHeader.getText();
        System.out.println("Prompt header text is: " + headerText);
        TestRunner.getTest().log(Status.PASS, "Test Case Passed   : Student Usage Prompt Display Successfully");
    }

    public void userAccountUsageInfo() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into Verify Student Information on Account Usage");
        System.out.println("I'm into Verify Student Information on Account Usage");

// Get name and email
        WebElement nameEmailElement = driver.findElement(By.cssSelector(".header2child1"));
        String nameEmail = nameEmailElement.getText();

// Split name and email
        String[] parts = nameEmail.split(" - ");
        String name = parts[0];
        String email = parts[1];

// Get role
        WebElement roleElement = driver.findElement(By.cssSelector(".header2child2"));
        String role = roleElement.getText().replace("Role: ", "");

// Get usage date and time
        WebElement usageElement = driver.findElement(By.xpath("//div[contains(text(),'Usage data is as of')]"));
        String usageData = usageElement.getText().replace("Usage data is as of ", "");

        System.out.println("Name: " + name);
        TestRunner.getTest().log(Status.INFO, "Name: " + name);

        System.out.println("Email: " + email);
        TestRunner.getTest().log(Status.INFO, "Email: " + email);

        System.out.println("Role: " + role);
        TestRunner.getTest().log(Status.INFO, "Role: " + role);

        System.out.println("Usage Data: " + usageData);
        TestRunner.getTest().log(Status.INFO, "Usage Data: " + usageData);
    }

    public void VerifyTodayClickedByDefault() throws InterruptedException {
        System.out.println("I'm Into Verify that Today's Button Is Already Pressed/Clicked");
        TestRunner.getTest().log(Status.INFO, "I'm Into Verify That Today's Button is Already Pressed/Clicked");

        WebElement todayButton = driver.findElement(By.xpath("//button[.//span[text()='Today']]"));
        String isPressed = todayButton.getAttribute("aria-pressed");

        if ("true".equals(isPressed)) {
            System.out.println("Today button is already pressed.");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Today button is already pressed.");
        } else {
            System.out.println("Today button is NOT pressed.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: By Default Today button is NOT pressed.");
        }

    }

    public void VerifyAllButtonDisplay() throws InterruptedException {

        System.out.println("I'm Into Verify All Button Display on User Accounts Usage");
        TestRunner.getTest().log(Status.INFO, "I'm Into Verify All Button Display on User Accounts Usage");

        String[] expectedButtons = {"All Time", "Today", "Week", "Month"};

        for (String label : expectedButtons) {
            try {
                // Locate button by visible span text
                WebElement button = driver.findElement(By.xpath("//button[.//span[text()='" + label + "']]"));

                // Check if button is displayed
                if (button.isDisplayed()) {
                    System.out.println("'" + label + "' button is visible on UI.");
                    TestRunner.getTest().log(Status.PASS,"Test Case Passed: '" + label + "' button is visible on UI ");
                } else {
                    System.out.println("'" + label + "' button is NOT visible.");
                    TestRunner.getTest().log(Status.FAIL, "Test Case Failed:  '" + label + "' button is NOT visible.");
                }
            } catch (NoSuchElementException e) {
                System.out.println("'" + label + "' button is NOT found on the page.");
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: '" + label + "' button is NOT found on the page.");
            }
        }
    }

    public void verifyUserUsageAggregateDisplay() throws InterruptedException {
        System.out.println("I'm Into Verify that User Usage Aggregate Is Display On UI");
        TestRunner.getTest().log(Status.INFO, "I'm Into Verify That User Usage Aggregate Is Display On UI");

        try {
            WebElement usageSection = driver.findElement(By.xpath("//div[contains(@class, 'UserUsageAggrigateWrapper')]"));

            if (usageSection.isDisplayed()) {
                System.out.println(" UserUsageAggrigate section is visible on the UI.");
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: UserUsageAggrigate section is visible on the UI.");


                WebElement usageHeader = driver.findElement(By.xpath("//div[contains(@class, 'UserUsageAggrigateWrapper')]//span[text()='Today Totals']"));
                if (usageHeader.isDisplayed()) {
                    System.out.println("✅ 'Today Totals' header found inside UserUsageAggrigate section.");
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed: 'Today Totals' header found inside UserUsageAggrigate section.");
                } else {
                    TestRunner.getTest().log(Status.FAIL, "Test Case Failed: 'Today Totals' header Not found inside UserUsageAggrigate section.");

                }

            } else {
                System.out.println(" UserUsageAggrigate section is NOT visible.");
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed:UserUsageAggrigate section is NOT visible. ");
            }
        } catch (NoSuchElementException e) {
            System.out.println(" UserUsageAggrigate section is NOT found on the page.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: UserUsageAggrigate section is NOT found on the page");
        }

    }

    public void verifyCrossButton() throws InterruptedException {
        System.out.println("I'm Into click on cross button");
        TestRunner.getTest().log(Status.INFO, "I'm into click on cross button");

        try {

            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            WebElement closeButton = wait.until(ExpectedConditions.elementToBeClickable(
                    By.xpath("(//div[contains(@class, 'MuiDialog-root')]//button[@aria-label='close'])[2]")));

            closeButton.click();
            System.out.println("✅ Close button clicked successfully.");
            TestRunner.getTest().log(Status.PASS, "Close button clicked successfully");
        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "Failed to click the close button");
            System.out.println("❌ Failed to click the close button: " + e.getMessage());
        }

    }

}
