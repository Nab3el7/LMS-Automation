package pageFactory.GalSystemScenarios;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

public class GalSystemRoleFilter_PF {

    WebDriverWait wait;
    WebDriver driver;
    Helper helper;
    Actions actions;

    @FindBy(xpath = "//div[@aria-label='Settings Module']")
    WebElement link_Settings_Module;

    public GalSystemRoleFilter_PF(WebDriver driver) {
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        helper = new Helper();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        actions = new Actions(driver);
    }


    public void SideNavBarAndClickOnSettingsModule() throws InterruptedException {
        System.out.println("I'm in checking the side navbar");
        TestRunner.getTest().log(Status.INFO, "I'm in checking the side navbar");

        Thread.sleep(1000);

        WebElement navBar = driver.findElement(By.xpath("//div[@class='navigation']"));

        List<WebElement> totalLinks = navBar.findElements(By.tagName("a"));

        for (WebElement link : totalLinks) {
            String hrefValue = link.getAttribute("href");
            System.out.println("Link is: " + hrefValue);
        }

        if (link_Settings_Module.isDisplayed()) {
            link_Settings_Module.click();
            TestRunner.getTest().log(Status.PASS, "Testcase Passed   :  Side Navbar Shows and Clicked on Settings Module Successfully");
        } else {
            TestRunner.getTest().log(Status.FAIL, "Testcase Failed   :  Side navbar and not shows and not clicked on Settings Module");
        }

    }

    public void ClickFloridaFromList() throws InterruptedException {
        System.out.println("I'm Into Click On Florida From List District");
        TestRunner.getTest().log(Status.INFO, "I'm Into Click On Florida From List Of District");
        try {

            String targetDistrictName = "Florida";

            // Wait for the school list to be visible
            wait.until(ExpectedConditions.visibilityOfElementLocated(
                    By.xpath("//div[contains(@class,'adminSettingDashboardRightPanel-listSchools')]")
            ));

            // Get all listed schools
            List<WebElement> schools = driver.findElements(
                    By.xpath("(//div[contains(@class, 'scrollbarWrapper')])[2]//div[@class='outercontainer username']")
            );

            boolean found = false;
            for (WebElement school : schools) {
                String schoolName = school.getText().trim();
                if (schoolName.equalsIgnoreCase(targetDistrictName)) {
                    school.click();
                    System.out.println("Selected District Name: " + schoolName);
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed: District Name Found In List: " + targetDistrictName);
                    found = true;
                    break;
                }
            }

            if (!found) {
                System.out.println("District Name not found: " + targetDistrictName);
                TestRunner.getTest().log(Status.FAIL, "District Name Not Found In List: " + targetDistrictName);
            }

            // Optional: Verify it is selected
            WebElement selected = driver.findElement(
                    By.xpath("//div[contains(@class,'outercontainer selected')]//div[text()='" + targetDistrictName + "']")
            );

            if (selected.isDisplayed()) {
                System.out.println("Verified selection: " + targetDistrictName);
            }

        } catch (Exception e) {
            System.out.println("District List not Found On Administrative Settings Screen");
            System.out.println(e.getMessage());
        }

    }

    String districtNameByKeyword= "FLDOE District";
    String searchDistrictByKeyword;

    public void searchDistrictNameByKeyword() throws InterruptedException{

        System.out.println("I'm Into Search District Name By Keyword");
        TestRunner.getTest().log(Status.INFO, "I'm Into Search District Name by Keyword");

        System.out.println("Want to search District Name By Keyword In Settings Module: " + districtNameByKeyword);
        TestRunner.getTest().log(Status.INFO, "Want to search District Name By Keyword In Settings Module: " + districtNameByKeyword);


        try {
            WebElement searchBox = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder='Search District by keyword']")));
            if (searchBox.isDisplayed()) {
                searchBox.click();
                searchBox.clear();
                ((JavascriptExecutor) driver).executeScript("arguments[0].value='';", searchBox);
                searchDistrictByKeyword = districtNameByKeyword;
                System.out.println("Search by District name: " + searchDistrictByKeyword);
                TestRunner.getTest().log(Status.INFO, "Search by District name: " + searchDistrictByKeyword);
                searchBox.sendKeys(searchDistrictByKeyword);

                Actions actions = new Actions(driver);
                actions.sendKeys(Keys.ENTER).perform();
                TestRunner.getTest().log(Status.PASS, "Testcase Passed   : Enter Search District keyword Successfully");

                waitForTableToRefresh();
            } else {
                System.out.println("Search box is not displayed.");
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : Search box is not displayed");
//                throw new RuntimeException("Search Box not  Found.");
            }
        } catch (Exception e) {
            System.out.println("Search box is not available: " + e.getMessage());
        }

    }

    public static String districtNameInTable;


    @FindBy(xpath = "//div[contains(@class, 'adminSettingDashboardRightPanel')]")
    WebElement classesTable;

    private void waitForTableToRefresh() {
        WebElement tableClasses = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class, 'adminSettingDashboardRightPanel')]//tbody")));

//        wait.until(ExpectedConditions.stalenessOf(tableClasses));

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(".//tr")));

        System.out.println("Table has refreshed.");
        TestRunner.getTest().log(Status.INFO, "Table has refreshed.");

    }


    public void showsDistrictIntoTable() throws InterruptedException {
        Thread.sleep(3000);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class, 'adminSettingDashboardRightPanel')]//tbody")));

        List<WebElement> rows = classesTable.findElements(By.xpath(".//tbody/tr"));

        if (!rows.isEmpty()) {
            System.out.println("District found in the table:");
            TestRunner.getTest().log(Status.INFO, "District found in the table:");
            for (int i = 0; i < rows.size(); i++) {
                WebElement row = rows.get(i);

                try {
                    WebElement classNameElement = row.findElement(By.xpath(".//td[contains(@class, 'MuiTableCell')]//div[@class='district-name']"));
                    districtNameInTable = classNameElement.getText();
                    System.out.println("District Name: " + districtNameInTable);
                    TestRunner.getTest().log(Status.INFO, "District Name: " + districtNameInTable);

                    List<WebElement> cells = row.findElements(By.xpath(".//td"));
                    for (WebElement cell : cells) {
                        System.out.print(cell.getText() + "\t");
                    }
                    System.out.println();
                    TestRunner.getTest().log(Status.PASS, "Test case Passed   : District Found in Table  Successfully");

                } catch (StaleElementReferenceException e) {
                    System.out.println("Stale element found, retrying...");

                    rows = classesTable.findElements(By.xpath(".//tbody/tr"));
                    row = rows.get(i);

                    WebElement classNameElement = row.findElement(By.xpath(".//td[contains(@class, 'MuiTableCell')]//div[@class='district-name']"));
                    districtNameInTable = classNameElement.getText();
                    System.out.println("District Name: " + districtNameInTable);
                    TestRunner.getTest().log(Status.INFO, "District Name: " + districtNameInTable);

                    List<WebElement> cells = row.findElements(By.xpath(".//td"));
                    for (WebElement cell : cells) {
                        System.out.print(cell.getText() + "\t");
                    }
                    System.out.println();
                    TestRunner.getTest().log(Status.PASS, "Testcase Passed   : District Found in Table  Successfully");
                }
            }
        } else {
            System.out.println("No searched District found in the table.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : No District found in the table by searching");
//            throw new RuntimeException("No Search Classes Found...");
        }
        helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());

    }


    public void verifySearchedDistrictByNameIntoTable(){
        if (districtNameInTable.contains(searchDistrictByKeyword)){
            System.out.println("Searched District found");
            TestRunner.getTest().log(Status.INFO, "Searched District found: " + districtNameByKeyword );
            TestRunner.getTest().log(Status.PASS, "Testcase Passed   : Search District by keyword Successfully");

        } else {
            System.out.println("Searched District not found and search filter not working");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : Searched District not found and search filter not working");
//            throw new RuntimeException("No class is found table .");
        }
    }


    public void clickOnDistrictColumnName() throws InterruptedException {

        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class, 'adminSettingDashboardRightPanel')]//tbody")));

        List<WebElement> rows = classesTable.findElements(By.xpath(".//tbody/tr"));

        if (!rows.isEmpty()) {
            System.out.println("District found in the table:");
            TestRunner.getTest().log(Status.INFO, "District found in the table:");

            // Click on the first column in the first row
            WebElement firstRow = rows.get(0);
            WebElement firstColumn = firstRow.findElement(By.xpath(".//td[1]//a"));
            Thread.sleep(1000);// First column
            firstColumn.click();

            System.out.println("Clicked on the first column in the first row.");
            TestRunner.getTest().log(Status.INFO, "Clicked on the first column in the first row.");
            TestRunner.getTest().log(Status.PASS, "Test case Passed: Clicked on the first column successfully.");
        } else {
            System.out.println("No district found in the table.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: No District found in the table by searching");
        }

    }

    @FindBy(xpath = "//button[@id='btn-saveNext']")
    WebElement btn_SaveNext;


    public void clickSaveNextButton() {
        System.out.println("I'm Into Click On Save And Next Button");
        TestRunner.getTest().log(Status.INFO, "I'm Into Click On Save And Next Button");

        try {
            // Wait for the button to be clickable
            wait.until(ExpectedConditions.elementToBeClickable(btn_SaveNext));

            // First, try scrolling to the button
            helper.scrollToElement(driver, btn_SaveNext);

            // Then, check if the button is displayed and clickable
            if (btn_SaveNext.isDisplayed() && btn_SaveNext.isEnabled()) {
                // If the button is visible and enabled, click it
                btn_SaveNext.click();
                TestRunner.getTest().log(Status.PASS, "Test Case Passed : Click and Save Next Button successfully ");
            } else {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Save next Button is Not Displayed/Enabled");
            }
        } catch (Exception e) {
            // If normal click fails, attempt using JavaScript
            System.out.println("JavaScript click failed, retrying with JS.");
            TestRunner.getTest().log(Status.INFO, "JavaScript click failed, retrying with JS.");

            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript("arguments[0].scrollIntoView(true); arguments[0].click();", btn_SaveNext);

            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Click and Save Next Button successfully using JavaScript");
        }
    }

    public void clickSaveButton() throws InterruptedException {

        Thread.sleep(500);
        WebElement save_button= driver.findElement(By.xpath("//button[@id='btn-save']"));

        if (save_button.isDisplayed()){
            save_button.click();
            TestRunner.getTest().log(Status.PASS,"Test Case Passed : Save Button is Clicked Successfully");
        }else {
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed : Save Button is Disabled");
            Assert.fail();
        }
    }

    @FindBy(xpath = "(//button[@name='btn-submit-applyfilter'])[3]")
    WebElement btn_SaveNext_StepIV;

    public void stepIVClickSaveNextButton() throws InterruptedException {
        Thread.sleep(1000);

        wait.until(ExpectedConditions.elementToBeClickable(btn_SaveNext_StepIV));

        if (btn_SaveNext_StepIV.isDisplayed()) {
            btn_SaveNext_StepIV.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed : Click and Save next Button successfully ");
        }else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Click and Save next Button is not displayed/clickable at step IV ");
        }

    }


    public void VerifyByDefaultTeacherIsSelectedInRoleFilter() throws InterruptedException {
        System.out.println("I'm Into Verify That In Role Filter Teacher Is Selected By Default");
        TestRunner.getTest().log(Status.INFO, "I'm Into Verify That In Role Filter Teacher Is Selected By Default");


        WebElement roleDropdownButton = driver.findElement(By.xpath("//label[text()='Role']/following-sibling::div//div[@role='button' or @role='combobox']"));

        String selectedRole = roleDropdownButton.getText();

        if ("Teacher".equals(selectedRole)) {
            System.out.println("Test Case Passed: Default role is correctly set to 'Teacher'.");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Default role is correctly set to 'Teacher'.");
        } else {
            System.out.println("Test Case Failed: Default role is not 'Teacher'. Current selection: " + selectedRole);
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Default role is not 'Teacher'. Current selection: " + selectedRole);
        }

    }

    @FindBy(xpath = "//div[contains(@class, 'tabelbodydata')]//tbody")
    WebElement questionsContainerTable;


    public void filterRoleDropdownOnGalSystem() throws InterruptedException {
        String[] roleArray = {"Teacher", "Student", "District Admin","Campus Admin"};

        for (String role : roleArray) {
            TestRunner.getTest().log(Status.INFO, "Filtering Role Dropdown: " + role);

            try {
                WebElement statusDropdown = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(@class, 'MuiSelect-select') and @role='button' or @role='combobox'])[1]")));
                statusDropdown.click();

                List<WebElement> statusOptions = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//ul[@role='listbox']//li")));
                boolean statusFound = false;

                for (WebElement option : statusOptions) {
                    String optionText = option.getText().trim();
                    if (optionText.equalsIgnoreCase(role)) {
                        option.click();
                        statusFound = true;
                        TestRunner.getTest().log(Status.INFO, "Selected Role: " + optionText);
                        break;
                    }
                }

                if (!statusFound) {
                    TestRunner.getTest().log(Status.FAIL, "Role not found in the dropdown: " + role);
                    throw new RuntimeException("Role not found in the dropdown: " + role);
                }

                Thread.sleep(2000);
                waitForTableToRefreshForGalSystem();

                if (isNoDataFoundDisplayed()) {
                    TestRunner.getTest().log(Status.INFO, "No Data found for the Role: " + role);
                    System.out.println("No Data found for the Role: " + role);
                    continue;
                }

                WebElement questionsTable = wait.until(ExpectedConditions.visibilityOf(questionsContainerTable));
                List<WebElement> questionRows = questionsTable.findElements(By.xpath(".//tr"));

                boolean allRowsMatchStatus = true;

//                for (WebElement row : questionRows) {
//                    WebElement statusCell = row.findElement(By.xpath(".//td[contains(@class, 'cell-3')]"));
//                    String rowStatus = statusCell.getText().trim();
//
//                    if (!rowStatus.equalsIgnoreCase(role)) {
//                        allRowsMatchStatus = false;
//                        System.out.println("Row Role is: " + rowStatus);
//                        TestRunner.getTest().log(Status.FAIL, "Data with mismatched Role found: " + rowStatus);
//                    } else {
//                        TestRunner.getTest().log(Status.INFO, "Data row with Role: " + rowStatus);
//                    }
//                }

                for (WebElement row : questionRows) {
                    WebElement statusCell = row.findElement(By.xpath(".//td[contains(@class, 'cell-3')]"));
                    String rowStatus = statusCell.getText();
                    String expectedRole = role.replaceAll("\\s+", "").trim();               // sanitize expected role too

                    if (!rowStatus.equalsIgnoreCase(expectedRole)) {
                        allRowsMatchStatus = false;
                        System.out.println("Row Role is: " + rowStatus);
                        TestRunner.getTest().log(Status.FAIL, "Data with mismatched Role found: " + rowStatus);
                    } else {
                        TestRunner.getTest().log(Status.INFO, "Data row with Role: " + rowStatus);
                    }
                }


                if (allRowsMatchStatus) {
                    TestRunner.getTest().log(Status.PASS, "All Data match the selected Role: " + role);
                } else {
                    TestRunner.getTest().log(Status.FAIL, "Some Data do not match the selected Role: " + role);
                }

            } catch (NoSuchElementException | ElementNotInteractableException e) {
                TestRunner.getTest().log(Status.WARNING, "Table not load in current time frame");
            }
        }
    }

    private boolean isNoDataFoundDisplayed() {
        try {
            WebElement noDataFound = driver.findElement(By.xpath("//div[contains(@class, 'tabelbodydata')]//div[contains(text(),'No Detail Found')]"));
            return noDataFound.isDisplayed();
        } catch (NoSuchElementException e) {
            return false;
        }
    }

    private void waitForTableToRefreshForGalSystem() throws InterruptedException{
        try {
            WebElement questionsTable = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class, 'tabelbodydata')]//tbody")));

            List<WebElement> rowsBeforeRefresh = questionsTable.findElements(By.xpath(".//tr"));
            System.out.println("Number of rows before refresh: " + rowsBeforeRefresh.size());

            Thread.sleep(2000);

            List<WebElement> rowsAfterRefresh = questionsTable.findElements(By.xpath(".//tr"));
            System.out.println("Number of rows after refresh: " + rowsAfterRefresh.size());

            if (rowsBeforeRefresh.size() != rowsAfterRefresh.size()) {
                System.out.println("Table has refreshed. Number of rows before refresh: " + rowsBeforeRefresh.size() + ", after refresh: " + rowsAfterRefresh.size());
                TestRunner.getTest().log(Status.INFO, "Table has refreshed. Number of rows before refresh: " + rowsBeforeRefresh.size() + ", after refresh: " + rowsAfterRefresh.size());
            } else {
                System.out.println("Table did not refresh as expected. Rows before: " + rowsBeforeRefresh.size() + ", Rows after: " + rowsAfterRefresh.size());
            }

            for (WebElement row : rowsAfterRefresh) {
                System.out.println("Table Row: " + row.getText());
            }

        } catch (NoSuchElementException | TimeoutException e) {
            System.out.println("Error while waiting for table refresh: " + e.getMessage());
//            TestRunner.getTest().log(Status.FAIL,"Test Case Fail : Error while waiting for table refresh");

        }
    }

}

