package pageFactory.GalSystemScenarios;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

import static pageFactory.GalSystemScenarios.SearchExistingStaff_PF.searchUserByFirstName;

public class GalSystemImpersonateUser_PF {

    WebDriverWait wait;
    WebDriver driver;
    Helper helper;
    Actions actions;
    JavascriptExecutor js;

    public GalSystemImpersonateUser_PF(WebDriver driver) {
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        helper = new Helper();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        actions = new Actions(driver);
    }

    public void clickStaffImpersonateButtonFromDots() throws InterruptedException {
        System.out.println("I'm in to Click Impersonate Button Dots");
        TestRunner.getTest().log(Status.INFO,"I'm in to Click Impersonate Button");

        WebElement ImpersonateDots= driver.findElement(By.xpath("//button[@aria-label='DropDownButtom']"));
        ImpersonateDots.click();

        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//ul[@role='menu']//li")));

        WebElement ImpersonateDots_btn= driver.findElement(By.xpath(".//span[normalize-space()='Impersonate']"));
        ImpersonateDots_btn.click();
        helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
        TestRunner.getTest().log(Status.PASS, "Testcase Passed   :  Impersonate button click successfully");
    }

    public void verifyImpersonateUserPromptDisplay() throws InterruptedException {
        System.out.println("I'm into verify that Impersonate User Prompt is display");
        TestRunner.getTest().log(Status.INFO, "I'm into verify that Impersonate User Prompt is display");

        Thread.sleep(2000);

        WebElement prompt = driver.findElement(By.xpath("//div[@role='dialog']"));
        boolean isDisplayed = prompt.isDisplayed();
        Assert.assertTrue("Impersonate User Prompt is not displayed.", isDisplayed);

        WebElement promptHeader = prompt.findElement(By.tagName("h2"));
        String headerText = promptHeader.getText();
        System.out.println("Prompt header text is: " + headerText);
        TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  Prompt Display Successfully");
    }

    public void getImpersonateUserInfo() throws InterruptedException {
        System.out.println("I'm Into Get Impersonate User Information From Prompt");
        TestRunner.getTest().log(Status.INFO,"I'm Into Get Impersonate User Information From Prompt");

        WebElement dialogContent = driver.findElement(By.xpath("//div[contains(@class,'MuiDialogContent-root')]"));
        String dialogText = dialogContent.getText();

        System.out.println("Dialog Text: " + dialogText);
        TestRunner.getTest().log(Status.INFO, "Impersonate User Dialog Text is: " + dialogText);

        TestRunner.getTest().log(Status.PASS, "Test Case Passed:  Impersonate User Prompt Test Display Successfully");

    }

    public void validateStaffNameOnImpersonateUserPrompt() throws InterruptedException {
        System.out.println("I'm into verify That Staff is Display and Match on Impersonate User Prompt");
        TestRunner.getTest().log(Status.INFO, "I'm into verify That Staff is Display and Match on Impersonate User Prompt");

        WebElement staffNameFromImpersonateUserPrompt= driver.findElement(By.xpath("//p[@class='primary space']"));

        String actualStaffName = staffNameFromImpersonateUserPrompt.getText().trim();

        System.out.println("Name From Impersonate User Prompt: " + actualStaffName);
        TestRunner.getTest().log(Status.INFO, "Name From Impersonate User Prompt: " + actualStaffName);

        if (actualStaffName.equals(searchUserByFirstName)) {
            System.out.println("Test Passed: Staff Name On Impersonate User  - " + actualStaffName  + " Matches with Staff Name In Table: " + searchUserByFirstName);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Staff Name On Impersonate User  - " + actualStaffName  + " Matches with Staff Name In Table: " + searchUserByFirstName);
        } else {
            System.out.println("Test Failed: Expected '" + searchUserByFirstName + "' but found '" + actualStaffName + "'");
            TestRunner.getTest().log(Status.FAIL, "Test Failed: Expected '" + searchUserByFirstName + "' but found '" + actualStaffName + " ' ");

        }

    }

    public void ImpersonateButton() throws InterruptedException {
        System.out.println("I'm into click on Impersonate Button on Impersonate User Prompt");
        TestRunner.getTest().log(Status.INFO, "I'm into click on Impersonate Button on Impersonate User Prompt");

        WebElement impersonateButton= driver.findElement(By.xpath("//button[contains(text(),'Impersonate')]"));

        String originalWindow = driver.getWindowHandle();

        impersonateButton.click();

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(driver -> driver.getWindowHandles().size() > 1);

        for (String windowHandle : driver.getWindowHandles()) {
            if (!windowHandle.equals(originalWindow)) {
                driver.switchTo().window(windowHandle);
                break;
            }
        }

        System.out.println("I'm on New Window of Impersonate User");
        TestRunner.getTest().log(Status.INFO,"I'm on New Window of Impersonate User");
        Thread.sleep(1000);

        WebElement impersonateAlert = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='impersonateUserAlert']")));
        String alertText = impersonateAlert.getText().trim();

        System.out.println("Impersonate User Alert on New Window: " + alertText);
        TestRunner.getTest().log(Status.INFO,"Impersonate User Alert on New Window: " + alertText);


        System.out.println("Now I'm Into Click on Close Session Button" );
        TestRunner.getTest().log(Status.INFO,"Now I'm Into Click on Close Session Button");

        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement closeSessionButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Close Session']")));
        closeSessionButton.click();

        System.out.println("Now Impersonate User Prompt is Display" );
        TestRunner.getTest().log(Status.INFO,"Now Impersonate User Prompt is Display");

        verifyImpersonateUserPromptDisplay();

        System.out.println("Now Click on Exit Session Button on Impersonate User Prompt" );
        TestRunner.getTest().log(Status.INFO,"Now Click on Exit Session Button on Impersonate User Prompt");

        WebElement exitSessionButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Exit Session']")));
        exitSessionButton.click();

        wait.until(driver -> driver.getWindowHandles().size() == 1);


        for (String windowHandle : driver.getWindowHandles()) {
            driver.switchTo().window(windowHandle);
        }

        System.out.println("Switched back to original window. Now Click on Exit Session Button on Impersonate User Prompt");
        TestRunner.getTest().log(Status.INFO,"Switched back to original window. Now we are on Original Window of Edit District");

    }


    public void VerifyUserAgainOnGalSystem() throws InterruptedException {
        System.out.println("I'm Into Verify that User is again on GalSystem Edit District Screen After Impersonation");
        TestRunner.getTest().log(Status.INFO,"I'm Into Verify that User is again on GalSystem Edit District Screen After Impersonation");

        WebElement titleElement = driver.findElement(By.xpath("//div[contains(@class,'title')]"));

        String actualText = titleElement.getText().trim();

        String expectedText = "Edit District";

        if (actualText.equalsIgnoreCase(expectedText)) {
            System.out.println("Test Passed: Title matches - " + actualText + "  And User is successfully Back to GalSystem Side After Impersonation");
            TestRunner.getTest().log(Status.PASS,"Test Passed: Title matches - " + actualText + "  And User is successfully Back to GalSystem Side After Impersonation");
        } else {
            System.out.println("Test Failed: Expected ' " + expectedText + " ' but found '" + actualText + " '");
            TestRunner.getTest().log(Status.FAIL,"Test Failed: Expected Title:   "  + expectedText +  "  Not  matches with Actual Title:  - " + actualText + "  And User is Not Back to GalSystem Side After Impersonation");
        }

    }

}
