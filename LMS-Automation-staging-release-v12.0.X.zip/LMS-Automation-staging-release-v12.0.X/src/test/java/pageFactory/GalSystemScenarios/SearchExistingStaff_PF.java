package pageFactory.GalSystemScenarios;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;
import java.util.Random;

public class SearchExistingStaff_PF {
    WebDriverWait wait;
    WebDriver driver;
    Helper helper;
    Actions actions;
    JavascriptExecutor js;

    public SearchExistingStaff_PF(WebDriver driver) {
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        helper = new Helper();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        actions = new Actions(driver);
    }

    @FindBy(xpath = "//div[contains(@class, 'tabelbodydata')]")
    WebElement staffTable;


    public static String existingStaffNameInTable;
    public static String searchUserByFirstName;

    public String ExistingUser="Devin Staff";

//    public void validateDataShowsIntoTable() {
//        System.out.println("Validating that the Staff Table is visible...");
//        TestRunner.getTest().log(Status.INFO, "Validating that the Staff Table is visible...");
//
//        try {
//            WebElement tableBody = wait.until(ExpectedConditions.presenceOfElementLocated(
//                    By.xpath("//div[contains(@class, 'tabelbodydata')]//tbody")));
//
//            List<WebElement> rows = tableBody.findElements(By.tagName("tr"));
//
//            if (rows.isEmpty()) {
//                System.out.println("No Staff List found in the table.");
//                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: No Staff List found in the table.");
//                return;
//            }
//
//            System.out.println("Staff found in the table:");
//            TestRunner.getTest().log(Status.INFO, "Staff found in the table:");
//
//            for (int i = 0; i < rows.size(); i++) {
//                WebElement row = rows.get(i);
//
//                for (int attempt = 0; attempt < 2; attempt++) {
//                    try {
//                        WebElement nameElement = row.findElement(By.xpath(".//td[contains(@class, 'MuiTableCell')]//div[contains(@class,'rightSide')]//h6"));
//                        existingStaffNameInTable = nameElement.getText();
//                        System.out.println("Staff Name: " + existingStaffNameInTable);
//                        TestRunner.getTest().log(Status.INFO, "Staff Name: " + existingStaffNameInTable);
//
//                        List<WebElement> cells = row.findElements(By.tagName("td"));
//                        StringBuilder rowText = new StringBuilder();
//                        for (WebElement cell : cells) {
//                            rowText.append(cell.getText()).append("\t");
//                        }
//                        System.out.println(rowText);
//                        TestRunner.getTest().log(Status.PASS, "Test case Passed: Staff List Found in Table Successfully");
//                        break; // success
//
//                    } catch (StaleElementReferenceException e) {
//                        System.out.println("Stale element found on attempt " + (attempt + 1) + ", retrying...");
//                        TestRunner.getTest().log(Status.WARNING, "Stale element encountered on attempt " + (attempt + 1) + ", retrying...");
//
//                        rows = tableBody.findElements(By.tagName("tr"));
//                        row = rows.get(i);
//                    }
//                }
//            }
//
//        } catch (TimeoutException e) {
//            System.out.println("Timed out waiting for the staff table.");
//            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Staff Table not visible (timeout).");
//        }
//    }

    public void validateDataShowsIntoTable() throws InterruptedException{
        System.out.println("I'm Into Validate That Staff Table is Visible");
        TestRunner.getTest().log(Status.INFO, "I'm Into Validate That Staff Table is Visible");


        Thread.sleep(3000);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class, 'tabelbodydata')]//tbody")));

        List<WebElement> rows = staffTable.findElements(By.xpath(".//tbody/tr"));

        if (!rows.isEmpty()) {
            System.out.println("Staff found in the table:");
            TestRunner.getTest().log(Status.INFO, "Staff found in the table:");
            for (int i = 0; i < rows.size(); i++) {
                WebElement row = rows.get(i);

                try {
                    WebElement classNameElement = row.findElement(By.xpath(".//td[contains(@class, 'MuiTableCell')]//div[contains(@class,'rightSide')]//h6"));
                    existingStaffNameInTable = classNameElement.getText();
                    System.out.println("Staff Name: " + existingStaffNameInTable);
                    TestRunner.getTest().log(Status.INFO, "Staff Name: " + existingStaffNameInTable);

                    List<WebElement> cells = row.findElements(By.xpath(".//td"));
                    for (WebElement cell : cells) {
                        System.out.print(cell.getText() + "\t");
                    }
                    System.out.println();
                    TestRunner.getTest().log(Status.PASS, "Test case Passed   : Staff List Found in Table  Successfully");

                } catch (StaleElementReferenceException e) {
                    System.out.println("Stale element found, retrying...");

                    rows = staffTable.findElements(By.xpath(".//tbody/tr"));
                    row = rows.get(i);

                    WebElement classNameElement = row.findElement(By.xpath(".//td[contains(@class, 'MuiTableCell')]//div[contains(@class,'rightSide')]//h6"));
                    existingStaffNameInTable = classNameElement.getText();
                    System.out.println("Staff Name: " + existingStaffNameInTable);
                    TestRunner.getTest().log(Status.INFO, "Staff Name: " + existingStaffNameInTable);

                    List<WebElement> cells = row.findElements(By.xpath(".//td"));
                    for (WebElement cell : cells) {
                        System.out.print(cell.getText() + "\t");
                    }
                    System.out.println();
                    TestRunner.getTest().log(Status.PASS, "Test case Passed   : Staff List Found in Table  Successfully");
                }
            }
        } else {
            System.out.println("No Staff List found in the table.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : No Staff List found in the table");
        }

    }


    public void searchExistingUser() throws InterruptedException{
        System.out.println("I'm Into Search Existing User in Search box");
        TestRunner.getTest().log(Status.INFO, "I'm Into Search Existing User in Search Box");

        WebElement bottom_panel= driver.findElement(By.xpath("//div[contains(@class,'bottomwrapper')]"));
        bottom_panel.isDisplayed();

        try {
            WebElement searchBox = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder='Search User']")));
            if (searchBox.isDisplayed()) {
                searchBox.click();
                searchBox.clear();
                ((JavascriptExecutor) driver).executeScript("arguments[0].value='';", searchBox);
                System.out.println("I'm into Search Existing User By First Name: " + ExistingUser);
                TestRunner.getTest().log(Status.INFO, "I'm into Search Existing User By First Name: " + ExistingUser);

                searchUserByFirstName = ExistingUser;
                System.out.println("Search Existing User by First name: " + searchUserByFirstName);
                TestRunner.getTest().log(Status.INFO, "Search Existing User by First name: " + searchUserByFirstName);
                searchBox.sendKeys(searchUserByFirstName);

                Actions actions = new Actions(driver);
                actions.sendKeys(Keys.ENTER).perform();
                TestRunner.getTest().log(Status.PASS, "Testcase Passed   : Enter Search Existing User First Name Successfully");

                waitForTableToRefresh();
            } else {
                System.out.println("Search box is not displayed.");
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : Search box is not displayed");
//                throw new RuntimeException("Search Box not  Found.");
            }
        } catch (Exception e) {
            System.out.println("Search box is not available: " + e.getMessage());
        }


    }

    private void waitForTableToRefresh() {
        WebElement tableClasses = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class, 'tabelbodydata')]//tbody")));

//        wait.until(ExpectedConditions.stalenessOf(tableClasses));

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(".//tr")));

        System.out.println("Table has refreshed.");
        TestRunner.getTest().log(Status.INFO, "Table has refreshed.");

    }

    public void verifySearchedExistingStaffByNameIntoTable() throws InterruptedException {

        if (existingStaffNameInTable.contains(searchUserByFirstName)){
            System.out.println("Searched Existing Staff found");
            TestRunner.getTest().log(Status.INFO, "Searched Existing Staff found: " + searchUserByFirstName );
            TestRunner.getTest().log(Status.PASS, "Test case Passed   : Search Existing Staff Found by First Name Successfully");

        } else {
            System.out.println("Searched Existing Staff not found and search filter not working");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : Searched  Existing Staff not found and search filter not working");

        }
    }


    public void clickStaffEditButtonDots() throws InterruptedException {
        System.out.println("I'm in to Click Edit Button Dots");
        TestRunner.getTest().log(Status.INFO,"I'm in to Click Edit Button");

        WebElement editDots= driver.findElement(By.xpath("//button[@aria-label='DropDownButtom']"));
        editDots.click();

        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//ul[@role='menu']//li")));

        WebElement edit_btn= driver.findElement(By.xpath(".//span[normalize-space()='View / Edit']"));
        edit_btn.click();
        helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
        TestRunner.getTest().log(Status.PASS, "Testcase Passed   :  Edit button click successfully");
    }


    public void verifyTeacherInformationPromptDisplay() throws InterruptedException {
        System.out.println("I'm into verify that Teacher Information Prompt is display");
        TestRunner.getTest().log(Status.INFO, "I'm into verify that Teacher Information Prompt is display");


        Thread.sleep(2000);

        WebElement prompt = driver.findElement(By.xpath("//div[@role='dialog']"));
        boolean isDisplayed = prompt.isDisplayed();
        Assert.assertTrue("Prompt is not displayed.", isDisplayed);

        WebElement promptHeader = prompt.findElement(By.tagName("h2"));
        String headerText = promptHeader.getText();
        System.out.println("Prompt header text is: " + headerText);
        TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  Prompt Display Successfully");
    }

    public void verifyStaffNameOnPrompt() throws InterruptedException {
        System.out.println("I'm into Verify Staff Name is Present on Teacher Information Prompt");
        TestRunner.getTest().log(Status.INFO, "I'm into Verify Staff Name is Present on Teacher Information Prompt");

        WebElement nameDiv = driver.findElement(By.xpath("//div[contains(@class,'flex justify-center items-start ')]"));

        String staffNameFromPrompt = nameDiv.getText().trim();

        if (staffNameFromPrompt.equalsIgnoreCase(ExistingUser)) {
            System.out.println("Test Case Passed: Staff Teacher Name Match on Teacher Information Prompt: " + staffNameFromPrompt);
            TestRunner.getTest().log(Status.PASS,"Test Case Passed: Staff Teacher Name Match on Teacher Information Prompt: " + staffNameFromPrompt);
        } else {
            System.out.println("User name does not match on Teacher Information Prompt. Found: " + staffNameFromPrompt + " Expected : " + ExistingUser);
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed: User name does not match on Teacher Information Prompt. Found: " + staffNameFromPrompt + " Expected : " + ExistingUser);
        }

    }

    public static String updatedEmailTeacher;
    public static String updatedPasswordStaff;

    @FindBy(xpath = "//input[@name='userName']")
    WebElement email;

    public void editTeacherLoginEmail() throws InterruptedException {
        System.out.println("I'm Into Edit/Update Teacher Login Email");
        TestRunner.getTest().log(Status.INFO, "I'm Into Edit/Update Teacher Login Email");

        String oldEmail = email.getAttribute("value");
        System.out.println("Previous Email of Teacher: " + oldEmail);
        TestRunner.getTest().log(Status.INFO,"Previous Email of Teacher: " + oldEmail);

        Actions actions = new Actions(driver);
        email.click();

        for (int i = 0; i < oldEmail.length(); i++) {
            actions.sendKeys(Keys.BACK_SPACE).perform();
        }

        email.click();
        for (int i = 0; i < oldEmail.length(); i++) {
            actions.sendKeys(Keys.BACK_SPACE).perform();
        }

        email.click();
        for (int i = 0; i < oldEmail.length(); i++) {
            actions.sendKeys(Keys.BACK_SPACE).perform();
        }

        email.click();
        for (int i = 0; i < oldEmail.length(); i++) {
            actions.sendKeys(Keys.BACK_SPACE).perform();
        }

        String newEmail = randomClassNewStdEmail("autoupdatedteacher");
        email.sendKeys(newEmail);

        updatedEmailTeacher = email.getAttribute("value");
        System.out.println("Updated Email is: " + updatedEmailTeacher);

        if (!oldEmail.equals(updatedEmailTeacher)) {
            System.out.println("Email updated Successfully");
            TestRunner.getTest().log(Status.INFO, "Email changed from '" + oldEmail + "' to '" + updatedEmailTeacher + "'.");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Email  Edit successfully");
        } else {
            System.out.println("Email was not changed");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Email was not changed");
        }
    }

    public String randomClassNewStdEmail (String prefix){
        Random randemail = new Random();
        int randomInt = randemail.nextInt(1000);
        return prefix + randomInt + "@gallopade.com";
    }


    public void addNewPassword() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Enter Password On Teacher Information Prompt");
        System.out.println("Enter Password On Teacher Information Prompt");

        Thread.sleep(1000);
        WebElement passwordField = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@name='stdPassword']")));

        passwordField.clear();

        Actions actions = new Actions(driver);
        actions.moveToElement(passwordField).click().sendKeys("Fltester@23").perform();

        System.out.println("Password added Successfully");

        actions.sendKeys(Keys.TAB);

        updatedPasswordStaff = passwordField.getAttribute("value");
        System.out.println("Password field value after input: " + updatedPasswordStaff);
        TestRunner.getTest().log(Status.INFO, "Updated Password  For Staff is: " + updatedPasswordStaff);

        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Password enter successfully");
    }

    public void addNewConfirmPassword() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Enter Confirm Password On Teacher Information Prompt");
        System.out.println("Enter Confirm Password On Teacher Information Prompt");

        Thread.sleep(2000);

        WebElement confirmPasswordField = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@name='stdConfirmPassword']")));

        confirmPasswordField.clear();

        Actions actions = new Actions(driver);
        actions.moveToElement(confirmPasswordField).click().sendKeys("Fltester@23").perform();

        System.out.println("Confirm Password added Successfully");

        String confirmPasswordValue = confirmPasswordField.getAttribute("value");
        System.out.println("Confirm Password field value after input: " + confirmPasswordValue);
        TestRunner.getTest().log(Status.INFO, "New Confirm Password is: " + confirmPasswordValue);

        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Confirm Password enter successfully");

    }

    public void verifyAndClickUpdateButton() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm Into Verify and Click on Update Button On Teacher Information Prompt");
        System.out.println("I'm Into Verify and Click on Update Button On Teacher Information Prompt");

        WebElement update_btn= driver.findElement(By.xpath("//button[normalize-space()='Update']"));

        if (update_btn.isEnabled() && update_btn.isDisplayed()){
            update_btn.click();
            System.out.println("Update Button click Successfully");
            TestRunner.getTest().log(Status.PASS,"Test Case Passed: Update Button Click Successfully");
        }else {
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed: Update Button is not Display/Enabled");
        }
    }


    public void VerifyEmailUpdateInTable() throws InterruptedException {
        System.out.println("I'm Into Verify That New Email is Also Updated in the Staff Table");
        TestRunner.getTest().log(Status.INFO, "I'm Into Verify That New Email is Also Updated in the Staff Table");

        Thread.sleep(3000);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class, 'tabelbodydata')]//tbody")));

        List<WebElement> rows = staffTable.findElements(By.xpath(".//tbody/tr"));

        if (!rows.isEmpty()) {
            WebElement row = rows.get(0);
            WebElement emailCell = row.findElement(By.xpath(".//td[3]"));

            String emailInTable = emailCell.getText().trim();
            System.out.println("Email found in table: " + emailInTable);
            TestRunner.getTest().log(Status.INFO, "Email found in table: " + emailInTable);


            if (emailInTable.equalsIgnoreCase(updatedEmailTeacher)) {
                System.out.println("Email matched: " + emailInTable);
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: Email matched: " + emailInTable);
            } else {
                System.out.println("Email did not match. Expected: " + updatedEmailTeacher + ", Found: " + emailInTable);
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Email did not match. Expected: " + updatedEmailTeacher + ", Found: " + emailInTable);
            }
        } else {
            System.out.println("No rows found in the table.");
            TestRunner.getTest().log(Status.FAIL, "No rows found in the staff table.");
        }
    }

//    public void VerifyEmailUpdateInTable() throws InterruptedException {
//        System.out.println("I'm Into Verify That New Email is Also Updated in the Staff Table");
//        TestRunner.getTest().log(Status.INFO, "I'm Into Verify That New Email is Also Updated in the Staff Table");
//
//        // Wait for the table body to load
//        Thread.sleep(3000);
//        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class, 'tabelbodydata')]//tbody")));
//
//        // Get the only row from the table
//        WebElement row = driver.findElement(By.xpath("//div[contains(@class, 'tabelbodydata')]//tbody/tr"));
//
//        // Get the email from the 3rd column (td[3])
//        String actualEmail = row.findElement(By.xpath("./td[3]")).getText().trim();
//        System.out.println("Email found in table: " + actualEmail);
//        TestRunner.getTest().log(Status.INFO, "Email found in table: " + actualEmail);
//
//        // Replace with your expected email value
//        String expectedEmail = "autoUpdatedTeacher417@gallopade.com";
//
//        // Compare actual and expected email
//        if (actualEmail.equalsIgnoreCase(expectedEmail)) {
//            System.out.println("Email matched successfully!");
//            TestRunner.getTest().log(Status.PASS, "Email matched successfully with: " + expectedEmail);
//        } else {
//            System.out.println("Email mismatch! Expected: " + expectedEmail + ", Found: " + actualEmail);
//            TestRunner.getTest().log(Status.FAIL, "Email mismatch! Expected: " + expectedEmail + ", Found: " + actualEmail);
//        }
//    }


    public void ValidateSideNavbar() throws InterruptedException {
        System.out.println("I'm Into Verify Side Nav Bar for Teacher");
        TestRunner.getTest().log(Status.INFO,"I'm Into Verify Side Nav Bar for Teacher");

        Thread.sleep(1000);

        WebElement navBar = driver.findElement(By.xpath("//div[@class='navigation']"));

        List<WebElement> totalLinks = navBar.findElements(By.tagName("a"));

        for (WebElement link : totalLinks) {
            String hrefValue = link.getAttribute("href");
            System.out.println("Link is: " + hrefValue);
            TestRunner.getTest().log(Status.INFO, "Side Nav Bar is: " + hrefValue);
        }
    }

}
