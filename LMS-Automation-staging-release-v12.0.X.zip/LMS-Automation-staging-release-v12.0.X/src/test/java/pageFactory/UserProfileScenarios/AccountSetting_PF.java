package pageFactory.UserProfileScenarios;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import pageFactory.Filters_PF;

import java.time.Duration;
import java.util.List;
import java.util.Random;

import static pageFactory.StudentsModule.AddNewStudent_PF.UpdatePhonenumber;

public class AccountSetting_PF {
    WebDriverWait wait;
    WebDriver driver;
    Helper helper;
    Actions actions;
    JavascriptExecutor js;
    public  AccountSetting_PF(WebDriver driver){
        this.driver = Configurations.getDriver();
        helper = new Helper();
//        filtersPF = new Filters_PF(driver);
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        actions = new Actions(driver);
    }
    @FindBy(xpath = "//div[contains(@class, 'rashid')]")
    WebElement User_btn;
    @FindBy(xpath = "//input[@id='textField-firstName']")
    WebElement user_first_name;
    @FindBy(xpath = "//input[@id='textField-lastName']")
    WebElement user_last_name;
    @FindBy(xpath = "//input[@name='phone']")
    WebElement user_Phone_number;

    @FindBy(xpath = "//input[@name='address']")
    WebElement user_address;
    @FindBy(xpath = "//label[normalize-space()='Language']/parent::div")
    WebElement user_language;
    @FindBy(xpath = "//button[normalize-space()='Update']")
    WebElement user_btn_update;
    @FindBy(xpath = "//button[normalize-space()='Profile']")
    WebElement profile_btn;

    private Random random = new Random();

    public static String UpdatedPasswordValue;
    public static String updatedName;
    public static String UpdatenewPhone = "+1 (415) 555-0132";


    public void SelectUserButton() throws InterruptedException {
        Thread.sleep(2000);
        User_btn.click();
        List<WebElement> Profile = User_btn.findElements(By.xpath("//ul[@role='menu']/div"));

        String Useroption = helper.selectValueFromDropdown(Profile);
        TestRunner.getTest().log(Status.INFO, "Click Profile_btn:" + Useroption);
        TestRunner.getTest().log(Status.PASS, "Test Case Passed : Profile_btn Click successfully ");
    }
    public void edit_UserProfile_info() throws InterruptedException {

        TestRunner.startTest(" Check Fill and validate new student Info");
        TestRunner.getTest().log(Status.INFO, "Edit Student Information: ");

        Thread.sleep(500);
        System.out.println("I'm in edit student Information Screen");
        User_firstName();
        User_lastName();
        User_Address();
        User_phone_number();
        User_Language();
        uploadUserImage();


        //        logger.info("Test Case Passed  :  Classes  Edit successfully");
    }
    public void User_firstName() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "User First Name");

        String oldName = user_first_name.getAttribute("value");
        System.out.println("Old Name: " + oldName);
        Actions actions = new Actions(driver);
        user_first_name.click();

        for (int i = 0; i < oldName.length(); i++) {
            actions.sendKeys(Keys.BACK_SPACE).perform();
        }

        String NewFirstName = generateUserInfo("District");
        user_first_name.sendKeys(NewFirstName);

        updatedName = user_first_name.getAttribute("value");
        System.out.println("Updated First Name: " + updatedName);

        if (!oldName.equals(updatedName)) {
            System.out.println("The First name was successfully updated.");
            TestRunner.getTest().log(Status.INFO, "Updated First Name is: " + updatedName);
            TestRunner.getTest().log(Status.INFO, "First name changed from '" + oldName + "' to '" + updatedName + "'.");

            TestRunner.getTest().log(Status.PASS, "Test Case Passed: First Name Edit successfully");


        } else {
            System.out.println("The First name was not changed.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: The First name was not changed");
        }
    }

    public void User_lastName() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "User Last Name");

        String lastOldName = user_last_name.getAttribute("value");
        System.out.println("Old Last Name is: " + lastOldName);

        Actions actions = new Actions(driver);

        user_last_name.click();
        for (int i = 0; i < lastOldName.length(); i++) {
            actions.sendKeys(Keys.BACK_SPACE).perform();
        }

        String Lastname = generateUserInfo("Admin");
        user_last_name.sendKeys(Lastname);

        String updatedLastname = user_last_name.getAttribute("value");
        System.out.println("Updated Last Name is: " + updatedLastname);

        if ((!lastOldName.equals(updatedLastname))) {
            System.out.println("Last name was changed successfully");
            TestRunner.getTest().log(Status.INFO, "Last Name changed from '" + lastOldName + "' to '" + updatedLastname + "'.");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Last Name  Edit successfully");

        } else {
            System.out.println("The Last name was not changed.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: The Last name was not changed");
        }

    }
    public void User_Address() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Edit User Address");

        String oldAddress = user_address.getAttribute("value");
        System.out.println("Old Address is: " + oldAddress);
        Actions actions = new Actions(driver);

        user_address.click();

        for (int i = 0; i < oldAddress.length(); i++) {
            actions.sendKeys(Keys.BACK_SPACE).perform();
        }
        String newAddress = generateUserInfo("Address-");
        user_address.sendKeys(newAddress);

        String updatedAddress = user_address.getAttribute("value");
        System.out.println("Updated Address is: " + updatedAddress);

        if (!oldAddress.equals(updatedAddress)) {
            System.out.println("Address updated Successfully");
            TestRunner.getTest().log(Status.INFO, "Address changed from '" + oldAddress + "' to '" + updatedAddress + "'.");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed : Address  Edit successfully");

        } else {
            System.out.println("Address was not changed");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Address was not changed");

        }

    }
    public void User_phone_number() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Edit User Phone number");

        String oldNumber = user_Phone_number.getAttribute("value");
        System.out.println("Old Phone Number is: " + oldNumber);

        Actions actions = new Actions(driver);

        user_Phone_number.click();

        for (int i = 0; i < oldNumber.length(); i++) {
            actions.sendKeys(Keys.BACK_SPACE).perform();
        }

        TestRunner.getTest().log(Status.INFO, "Enter New User Phone Number");
        user_Phone_number.click();
        ((JavascriptExecutor) driver).executeScript("arguments[0].value='';", user_Phone_number);

        String newPhnNumber = generateRandomPhoneNumber();
        user_Phone_number.sendKeys(UpdatenewPhone);

        String UpdatenewPhone = user_Phone_number.getAttribute("value");
        System.out.println("Update Phone number is: " + UpdatenewPhone);

        if (!oldNumber.equals(UpdatenewPhone)) {
            System.out.println("Phone Number updated Successfully");
            TestRunner.getTest().log(Status.INFO, "Phone Number changed from '" + oldNumber + "' to '" + UpdatenewPhone + "'.");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed:Phone Number  Edit successfully");

            TestRunner.getTest().log(Status.INFO, "Enter New Student Phone Number");
            user_Phone_number.click();
            ((JavascriptExecutor) driver).executeScript("arguments[0].value='';", user_Phone_number);


//        String randomPhoneNumber = generateRandomPhoneNumber();
            user_Phone_number.sendKeys(UpdatePhonenumber);
            System.out.println("Phone Number enter Successfully " + UpdatePhonenumber);


            TestRunner.getTest().log(Status.INFO, "Enter Phone number is: " + UpdatePhonenumber);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Phone Number Enter successfully");


            TestRunner.getTest().log(Status.INFO, "Enter Phone number is: " + UpdatePhonenumber);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Phone Number Enter successfully");
        }

    }
    public void User_Language () throws InterruptedException {
        String oldLanguage = user_language.getText();
        System.out.println("Old Language is: " + oldLanguage);
        user_language.click();

        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].scrollIntoView(true);", user_language);

        WebElement listLanguage = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[contains(@role, 'listbox')]")));
        List<WebElement> options = listLanguage.findElements(By.xpath(".//li"));

        if (options.isEmpty()) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: No options found in the dropdown ");
            System.out.println("No options found in the dropdown.");
            return;
        }
        WebElement randomOption = options.get(random.nextInt(options.size()));
        js.executeScript("arguments[0].scrollIntoView(true);", randomOption);
        randomOption.click();

        // Retrieve and print the new language
        String newLanguage = user_language.getText();
        System.out.println("New Language is: " + newLanguage);

        if (oldLanguage.equals(newLanguage)) {
            System.out.println("Language selection did not change.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Language selection did not change..");

        } else {
            System.out.println("Language selection changed from '" + oldLanguage + "' to '" + newLanguage + "'.");
            TestRunner.getTest().log(Status.INFO, "Language selection changed from '" + oldLanguage + "' to '" + newLanguage + "'.");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Language  Edit successfully");


        }

    }
    public void uploadUserImage() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Uploading image for User Profile");

        // Locate the input type='file' element
        WebElement inputFile = driver.findElement(By.xpath("//input[@type='file']"));

        // Optionally clear any previous value (some browsers may not allow clearing file input this way)
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].value='';", inputFile);

        // Provide full path to the image
        String filePath = System.getProperty("user.dir") + "/src/test/resources/drivers/DummyImg.png";

        // Upload image
        inputFile.sendKeys(filePath);

        Thread.sleep(2000);
        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Image uploaded successfully");
    }

    public void click_User_update_btn() throws InterruptedException {
        Thread.sleep(500);
        if (user_btn_update.isEnabled()) {
            user_btn_update.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Update button clicks successfully");
        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Update button Disable due to Password not enter successfully");
        }


    }
    //    ***************************** Account Setting *****************************************
    public void click_Profile_btn () throws InterruptedException {
        Thread.sleep(2000);
        profile_btn.click();
        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Account Setting button clicks successfully");
        Thread.sleep(3000);


    }

    public void User_Account_Setting_info () throws InterruptedException {

        TestRunner.startTest(" Check Fill and validate Account Setting Info");
        TestRunner.getTest().log(Status.INFO, " Account Setting Information: ");

        Thread.sleep(2000);
        System.out.println("I'm in Updated Account Setting Information Screen");
        User_Update_Password();
        User_Update_ConfirmPassword();
    }
    public void User_Update_Password () throws InterruptedException {
        // Log the action in the test report
        TestRunner.getTest().log(Status.INFO, "Enter Updated User Password");
        Thread.sleep(2000);

        WebElement passwordField = driver.findElement(By.xpath("//input[@name='userNewpassword']"));

        Actions actions = new Actions(driver);
        actions.moveToElement(passwordField).click().sendKeys("Fltester@23").perform();

        System.out.println("Confirm Password added Successfully");

        UpdatedPasswordValue = passwordField.getAttribute("value");
        System.out.println("Password field value after input: " + UpdatedPasswordValue);
        TestRunner.getTest().log(Status.INFO, "New User Password is: " + UpdatedPasswordValue);

        UpdatedPasswordValue = passwordField.getAttribute("value");

        System.out.println("Password field value after input: " + UpdatedPasswordValue);

        TestRunner.getTest().log(Status.INFO, "New User Password is: " + UpdatedPasswordValue);

        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Password enter successfully");
    }
    public void User_Update_ConfirmPassword () throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Enter Updated User Confirm Password");
        Thread.sleep(5000);

        WebElement confirmPasswordField = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@name='userConfirmPassword']")));

//        confirmPasswordField.clear();

        Actions actions = new Actions(driver);
        actions.moveToElement(confirmPasswordField).click().sendKeys("Fltester@23").perform();

        System.out.println("Confirm Password added Successfully");

        String confirmPasswordValue = confirmPasswordField.getAttribute("value");
        System.out.println("Confirm Password field value after input: " + confirmPasswordValue);
        TestRunner.getTest().log(Status.INFO, "New Student Password is: " + confirmPasswordValue);

//        if (!"Fltester@22".equals(confirmPasswordValue)) {
//            throw new RuntimeException("Confirm Password field did not receive the expected value. Actual value: '" + confirmPasswordValue + "'");
//        }
        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Confirm Password enter successfully");


    }

    public String generateUserInfo (String prefix){
        String characters = "abcdefghijklmnopqrstuvwxyz";
        StringBuilder randomTitle = new StringBuilder();
        Random random = new Random();
        int length = 4;
        randomTitle.append(prefix);
        for (int i = 0; i < length; i++) {
            randomTitle.append(characters.charAt(random.nextInt(characters.length())));
        }
        return randomTitle.toString();
    }
    public String generateRandomPhoneNumber () {
        String characters = "0123456789";
        StringBuilder randomTitle = new StringBuilder();
        Random random = new Random();
        int length = 11;
        for (int i = 0; i < length; i++) {
            randomTitle.append(characters.charAt(random.nextInt(characters.length())));
        }
        return randomTitle.toString();
    }
//    ******************************** Negative Scenarios Test Case *********************************************

public void NegativeUserProfileTests() throws InterruptedException {
    negative_FirstNameBlank();
    negative_InvalidPhoneNumber();
    negative_InvalidImageUpload();
    negative_LanguageDropdownNotLoaded();
    negative_UpdateButtonDisabled();
}
    public void negative_FirstNameBlank() {
        try {
            TestRunner.getTest().log(Status.INFO, "Negative Test: First Name Blank");

            user_first_name.clear();
            user_first_name.sendKeys("");  // leave it blank

            click_User_update_btn();

            // Check for error message or disabled button
            WebElement error = driver.findElement(By.id("firstNameError")); // example ID
            Assert.assertTrue(error.isDisplayed(), "First name error not displayed");

            TestRunner.getTest().log(Status.PASS, "Validation shown when first name is left blank");

        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "Failed to validate empty first name scenario: " + e.getMessage());
        }
    }
    public void negative_InvalidPhoneNumber() {
        try {
            TestRunner.getTest().log(Status.INFO, "Negative Test: Invalid Phone Number");

            user_Phone_number.clear();
            user_Phone_number.sendKeys("abcd1234"); // Invalid phone number

            click_User_update_btn();

            WebElement phoneError = driver.findElement(By.id("phoneError")); // hypothetical element
            Assert.assertTrue(phoneError.isDisplayed(), "Phone number error not shown");

            TestRunner.getTest().log(Status.PASS, "Invalid phone number validation works as expected");

        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "Exception in invalid phone test: " + e.getMessage());
        }
    }
    public void negative_InvalidImageUpload() {
        try {
            TestRunner.getTest().log(Status.INFO, "Negative Test: Upload Unsupported File");

            WebElement inputFile = driver.findElement(By.xpath("//input[@type='file']"));
            String invalidFilePath = System.getProperty("user.dir") + "/src/test/resources/testdata/document.pdf";
            inputFile.sendKeys(invalidFilePath);

            WebElement error = driver.findElement(By.id("uploadError")); // example
            Assert.assertTrue(error.isDisplayed(), "Unsupported file type error not shown");

            TestRunner.getTest().log(Status.PASS, "Upload rejected for unsupported file type");

        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "Upload error not handled correctly: " + e.getMessage());
        }
    }
    public void negative_LanguageDropdownNotLoaded() {
        try {
            TestRunner.getTest().log(Status.INFO, "Negative Test: Language dropdown unavailable");

            user_language.click();

            // Simulate dropdown not loaded or not found
            List<WebElement> options = driver.findElements(By.xpath("//ul[@role='listbox']//li"));
            if (options.isEmpty()) {
                throw new Exception("Dropdown options not loaded");
            }

        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "Language dropdown failed to load: " + e.getMessage());
        }
    }
    public void negative_UpdateButtonDisabled() {
        try {
            TestRunner.getTest().log(Status.INFO, "Negative Test: Update Button Should Be Disabled");

            user_first_name.clear();  // Make form invalid
            Thread.sleep(500);

            if (!user_btn_update.isEnabled()) {
                TestRunner.getTest().log(Status.PASS, "Update button is correctly disabled due to invalid input");
            } else {
                TestRunner.getTest().log(Status.FAIL, "Update button is enabled despite invalid form");
            }

        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "Error checking Update button state: " + e.getMessage());
        }
    }
// *************************** Negative Account Setting ********************************************

    public void Negative_User_Account_Setting_info () throws InterruptedException {

        TestRunner.startTest(" Check Fill and validate Account Setting Info");
        TestRunner.getTest().log(Status.INFO, " Account Setting Information: ");

        Thread.sleep(2000);
        System.out.println("I'm in Negative Account Setting Information Screen");
        negative_BlankPassword();
        negative_BlankConfirmPassword();
    }
public void negative_BlankPassword() {
    try {
        WebElement passwordField = driver.findElement(By.xpath("//input[@name='userNewpassword']"));
        WebElement confirmPasswordField = driver.findElement(By.xpath("//input[@name='userConfirmPassword']"));

        passwordField.clear();
        confirmPasswordField.clear();

        confirmPasswordField.sendKeys("Fltester@23");

        WebElement error = driver.findElement(By.id("New Password is Required.")); // Hypothetical
        Assert.assertTrue(error.isDisplayed(), "Blank password error not shown");

        TestRunner.getTest().log(Status.PASS, "Blank password validation works as expected.");
    } catch (Exception e) {
        TestRunner.getTest().log(Status.FAIL, "Blank password error not handled: " + e.getMessage());
    }
}
    public void negative_BlankConfirmPassword() {
        try {
            WebElement passwordField = driver.findElement(By.xpath("//input[@name='userNewpassword']"));
            WebElement confirmPasswordField = driver.findElement(By.xpath("//input[@name='userConfirmPassword']"));

            passwordField.clear();
            confirmPasswordField.clear();

            passwordField.sendKeys("Fltester@23");

            WebElement error = driver.findElement(By.id("Required")); // Hypothetical
            Assert.assertTrue(error.isDisplayed(), "Confirm password blank error not displayed");

            TestRunner.getTest().log(Status.PASS, "Blank confirm password validation passed.");
        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "Blank confirm password case not handled: " + e.getMessage());
        }
    }



}

