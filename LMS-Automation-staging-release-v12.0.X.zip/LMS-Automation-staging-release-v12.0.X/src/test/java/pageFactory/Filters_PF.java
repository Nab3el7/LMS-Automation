package pageFactory;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;
import java.util.Random;

import static pageFactory.NotificationModule.CreateNotificationByTeacher_PF.specificClasses;
import static pageFactory.StudentsModule.AddNewStudent_PF.selectedClass;

public class Filters_PF {
    WebDriver driver;
    public WebDriverWait wait;

    String selectedDistrict;
    String selectedTeacher;

    Helper helper;

    @FindBy(xpath = "//label[normalize-space()='Select District']/parent::div") // Locate the dropdown
    WebElement dropdown_select_district;

    @FindBy(xpath = "//label[normalize-space()='Select School']/parent::div") // Locate the dropdown
    WebElement dropdown_select_school;
    @FindBy(xpath = "//label[normalize-space()='Select School Year']/parent::div") // Locate the dropdown
    WebElement dropdown_select_school_year;

    @FindBy(xpath = "//label[normalize-space()='Select Teachers']/parent::div") // Locate the dropdown
    WebElement dropdown_select_teacher;

    @FindBy(xpath = "//div[contains(text(),'Classes')]/following-sibling::div//div[@role='button' or @role='combobox']")
    WebElement select_classes;

    @FindBy(xpath = "//h6[normalize-space()='Grades']/parent::div")
    WebElement select_grade;

    public Filters_PF(WebDriver driver) {
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        PageFactory.initElements(driver, this);
        helper = new Helper();
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
    }

    public void select_District() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm in to select District");

        dropdown_select_district.click();
        WebElement listDistricts = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//ul[@role='listbox']")));

        List<WebElement> optionsDistrict = listDistricts.findElements(By.xpath(".//li"));

        System.out.println("District List is: " + optionsDistrict.size());

        if (optionsDistrict.isEmpty()) {
            System.out.println("No options found in the District dropdown.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :No options found in the District dropdown.");
//            throw new RuntimeException("No District Found.");
        } else {
            System.out.println("District:");
            selectedDistrict = helper.selectValueFromDropdown(optionsDistrict);
            TestRunner.getTest().log(Status.INFO, "Selected District Name: " + selectedDistrict);
            System.out.println("Selected District Name: " + selectedDistrict);
            TestRunner.getTest().log(Status.PASS, "Testcase Passed   :  School district selected successfully");
        }

        Actions actions = new Actions(driver);
        actions.sendKeys(Keys.ESCAPE).build().perform();
    }

    public void select_School(String selectedSchool){
        TestRunner.getTest().log(Status.INFO, "I'm in to select School");
        dropdown_select_school.click();
        WebElement listSchools = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//ul[@role='listbox']")));

        List<WebElement> optionsSchools = listSchools.findElements(By.xpath(".//li"));

        System.out.println("Schools List is: " + optionsSchools.size());

        if (optionsSchools.isEmpty()) {
            System.out.println("No options found in the Schools dropdown.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : No options found in the Schools dropdown.");
//            throw new RuntimeException("No School Found.");

        } else {
            System.out.println("Schools:");

            for (WebElement school : optionsSchools) {
                System.out.println(school.getText());
                if (school.getText().equals(selectedSchool)) {
                    school.click();
                    TestRunner.getTest().log(Status.INFO, "Clicked on School: " + selectedSchool);
                    System.out.println("Clicked on School: " + selectedSchool);
                    TestRunner.getTest().log(Status.PASS, "Testcase Passed   :  School selected successfully");
                    break;
                }
            }
        }

        Actions actions = new Actions(driver);
        actions.sendKeys(Keys.ESCAPE).build().perform();
    }
    public void select_School_year(String selectedSchool){
        TestRunner.getTest().log(Status.INFO, "I'm in to select School");
        dropdown_select_school_year.click();
        WebElement listSchools = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//ul[@role='listbox']")));

        List<WebElement> optionsSchools = listSchools.findElements(By.xpath(".//li"));

        System.out.println("Schools List is: " + optionsSchools.size());

        if (optionsSchools.isEmpty()) {
            System.out.println("No options found in the Schools dropdown.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : No options found in the Schools dropdown.");
//            throw new RuntimeException("No School Found.");

        } else {
            System.out.println("Schools:");

            for (WebElement school : optionsSchools) {
                System.out.println(school.getText());
                if (school.getText().equals(selectedSchool)) {
                    school.click();
                    TestRunner.getTest().log(Status.INFO, "Clicked on School: " + selectedSchool);
                    System.out.println("Clicked on School: " + selectedSchool);
                    TestRunner.getTest().log(Status.PASS, "Testcase Passed   :  School selected successfully");
                    break;
                }
            }
        }

        Actions actions = new Actions(driver);
        actions.sendKeys(Keys.ESCAPE).build().perform();
    }

    public void select_teacher() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm in to select Teacher");
        dropdown_select_teacher.click();
        WebElement listTeachers = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//ul[@role='listbox']")));

        List<WebElement> optionsTeacher = listTeachers.findElements(By.xpath(".//li"));

        System.out.println("Teachers List is: " + optionsTeacher.size());

        if (optionsTeacher.isEmpty()) {
            System.out.println("No options found in the Teachers dropdown.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : No options found in the Teachers dropdown.");
//            throw new RuntimeException("No Teacher Found.");

        } else {
            System.out.println("Teacher:");
            selectedTeacher = helper.selectValueFromDropdown(optionsTeacher);
            TestRunner.getTest().log(Status.INFO, "Selected Teacher Name: " + selectedTeacher);
            System.out.println("Selected Teacher Name: " + selectedTeacher);
            TestRunner.getTest().log(Status.PASS, "Testcase Passed   :  School teacher selected successfully");

        }

        Actions actions = new Actions(driver);
        actions.sendKeys(Keys.ESCAPE).build().perform();
    }
    public void select_Grades() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm in to select Grades");
        Thread.sleep(500);
        select_grade.click();

        Thread.sleep(1000);
        List<WebElement> optionsGrades = driver.findElements(By.xpath("//ul//li"));

        System.out.println("Grades List is: " + optionsGrades.size());

        if (optionsGrades.isEmpty()) {
            System.out.println("No options found in the Grade dropdown.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : No options found in the Grade dropdown");

//            throw new RuntimeException("No Grades Found.");
        } else {
            System.out.println("Grades:");
            WebElement all_grades= driver.findElement(By.xpath("//input[@name='-1']"));
            System.out.println(all_grades.getText());
            all_grades.click();
            System.out.println("Grade Clicked Successfully");
            TestRunner.getTest().log(Status.PASS, "Testcase Passed   :   Grades selected successfully");
        }

        Actions actions = new Actions(driver);
        actions.sendKeys(Keys.ESCAPE).build().perform();
    }

    public void select_Classes(String selectedClass) throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm in to select Classes");
        select_classes.click();

        Thread.sleep(1000);
        List<WebElement> optionsClasses = driver.findElements(By.xpath("//ul[@role='listbox']//li"));

        System.out.println("Classes List is: " + optionsClasses.size());

        if (optionsClasses.isEmpty()) {
            System.out.println("No options found in the Classes dropdown.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : No options found in the Classes dropdown.");
            throw new RuntimeException("No Classes Found.");
        } else {
            System.out.println("Classes:");

            for (WebElement classes : optionsClasses) {
                System.out.println(classes.getText());
                if (classes.getText().equals(selectedClass)) {
                    classes.click();
                    TestRunner.getTest().log(Status.INFO, "Selected Class is: " + selectedClass);
                    System.out.println("Clicked on Course: " + selectedClass);
                    TestRunner.getTest().log(Status.PASS, "Testcase Passed   :  Classes selected successfully");
                    break;
                }
            }
        }
        Actions actions = new Actions(driver);
        actions.sendKeys(Keys.ESCAPE).build().perform();
    }



    public void afteredit_select_Classes(String selectedClass) throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm in to select Classes");
        select_classes.click();

        Thread.sleep(1000);
        List<WebElement> optionsClasses = driver.findElements(By.xpath("//ul[@role='listbox']//li"));

        System.out.println("Classes List is: " + optionsClasses.size());

        if (optionsClasses.isEmpty()) {
            System.out.println("No options found in the Classes dropdown.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : No options found in the Classes dropdown.");
            throw new RuntimeException("No Classes Found.");
        } else {
            System.out.println("Classes:");

            for (WebElement classes : optionsClasses) {
                System.out.println(classes.getText());
                if (classes.getText().equals(specificClasses)) {
                    classes.click();
                    TestRunner.getTest().log(Status.INFO, "Selected Class is: " + specificClasses);
                    System.out.println("Clicked on Course: " + specificClasses);
                    TestRunner.getTest().log(Status.PASS, "Testcase Passed   :  Classes selected successfully");
                    break;
                }
            }
        }
        Actions actions = new Actions(driver);
        actions.sendKeys(Keys.ESCAPE).build().perform();
    }

}