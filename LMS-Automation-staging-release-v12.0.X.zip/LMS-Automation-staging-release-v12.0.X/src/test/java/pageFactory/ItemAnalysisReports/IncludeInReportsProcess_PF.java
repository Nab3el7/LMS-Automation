package pageFactory.ItemAnalysisReports;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Assignmment.CorrectAnswerExecutor_PF;
import pageFactory.Assignmment.ReleaseAssignment_PF;
import pageFactory.MyContent.AssignAssessment_PF;

import java.time.Duration;
import java.util.List;

public class IncludeInReportsProcess_PF {

    WebDriverWait wait;
    WebDriver driver;
    Helper helper;
    Actions actions;
    JavascriptExecutor js;

    CorrectAnswerExecutor_PF correctAnswerExecutor_pf;
    AssignAssessment_PF assignAssessment_pf;
    ReleaseAssignment_PF releaseAssignment_pf;

    public IncludeInReportsProcess_PF(WebDriver driver) {
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        helper = new Helper();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        actions = new Actions(driver);
        correctAnswerExecutor_pf = new CorrectAnswerExecutor_PF(driver);
        assignAssessment_pf = new AssignAssessment_PF(driver);
        releaseAssignment_pf= new ReleaseAssignment_PF(driver);
    }

    @FindBy(xpath = "//div[contains(text(),'Unit 1 Vocabulary Quiz')]/ancestor::div[4] | //img[contains(@src,'cardimage-vocabulary_quiz.png')]/ancestor::div[2]")
    public WebElement rowCourseVQ;


    public void ReleaseAssignmentTypeVQForIncludeInReportToggle() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO,"Release Assignment Type VQ For Include In Reports");
        System.out.println("Release Assignment Type VQ For Include In Reports");
        selectUnitForReleaseAssignment();

        Thread.sleep(2000);
        WebElement listContentPlayer = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@id='ContentPlayerMainPanel']")));

        if (listContentPlayer.isDisplayed() && listContentPlayer.isEnabled()) {
//            WebElement btnAssignForSpecificAssignment = listContentPlayer.findElement(By.xpath("(//div[contains(@class, 'MuiBox-root')]//button[contains(text(), 'Assign')])[4]"));
//            btnAssignForSpecificAssignment.click();

            WebElement btnAssignForSpecificAssignment = rowCourseVQ.findElement(By.xpath(".//button[normalize-space(text())='Assign']"));
            btnAssignForSpecificAssignment.click();

            WebElement dialogAssignment = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@role='dialog']")));
            if (dialogAssignment.isDisplayed()) {

                correctAnswerExecutor_pf.EnterAssignmentTitleForCorrectAnswers();
                correctAnswerExecutor_pf.selectSpecificClasses();
                assignAssessment_pf.setDateTimeAndCategory();
                assignAssessment_pf.enterAdditionalSettings();
                uncheckIncludeInReportToggle();
                releaseAssignment_pf.AdvancedGradingOptions();
                assignAssessment_pf.assignAssignment();
                assignAssessment_pf.verifyDialogBox();
                TestRunner.getTest().log(Status.PASS, "Test Case Passed : Specific Assignment Type VQ Released Successfully");
            }
        }
    }

    public void selectUnitForReleaseAssignment() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        // Find all units (even hidden)
        List<WebElement> totalUnits = driver.findElements(
                By.xpath("(//div[contains(@class, 'navigation')])[2]//a//span[contains(text(),'Unit 1')]")
        );

        String totalUnitName = null;

        for (WebElement unit : totalUnits) {
            // Get textContent instead of getText()
            totalUnitName = unit.getAttribute("textContent").trim();
            System.out.println("Unit Name: " + totalUnitName);

            if (totalUnitName.contains("Unit 1")) {
                // Expand parent panels if needed
                ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", unit);
                ((JavascriptExecutor) driver).executeScript("arguments[0].click();", unit); // JS click works even if hidden

                break;
            }
        }

        TestRunner.getTest().log(Status.PASS, "Test Case passed: " + totalUnitName + " selected successfully");

    }

    public void uncheckIncludeInReportToggle() throws InterruptedException {
        System.out.println("I'm into uncheck Include In Report Toggle");
        TestRunner.getTest().log(Status.INFO, "I'm into uncheck Include In Report Toggle");

        try {
            // Locate the checkbox input for "Include in Reports"
            WebElement includeInReportsCheckbox = driver.findElement(By.xpath("//input[@name='includeInReport']"));

            // Check if it's currently checked
            if (includeInReportsCheckbox.isSelected()) {
                includeInReportsCheckbox.click();  // Uncheck it
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: 'Include in Reports' toggle was checked. It has now been unchecked.");
            } else {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: 'Include in Reports' toggle was already unchecked.");
            }
        } catch (NoSuchElementException e) {
            TestRunner.getTest().log(Status.FAIL, "'Include in Reports' toggle not found on the Assign modal.");
        }
    }

    public void verifyNoDetailFoundInAssignmentTable() throws InterruptedException{
        System.out.println("I'm into verify that Include In Toggle off Assignment is not display in list of Report");
        TestRunner.getTest().log(Status.INFO,"I'm into verify that Include In Toggle off Assignment is not display in list of Report");

        try {

            WebElement noDetailMessage = driver.findElement(By.xpath("//div[contains(@class,'textstyling') and text()='No Detail Found']"));

            if (noDetailMessage.isDisplayed()) {
                System.out.println("Test Case Passed: Assignment With Include In Toggle Off 'No Detail Found' is displayed in the table.");
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: Assignment With Include In Toggle Off 'No Detail Found' is displayed in the table.");
            } else {
                System.out.println("Test Case Failed:  'No Detail Found' is not visible. Assignment list is Display");
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed:  'No Detail Found' is not visible. Assignment list is Display");
            }
        } catch (NoSuchElementException e) {
            System.out.println("Test Case Failed:  'No Detail Found' element was not found.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: 'No Detail Found' element was not found in the DOM.");
        }
    }


    public void SelectCategoryFromReportsForIncludeInReportsToggle(String selectedCategory) throws InterruptedException {
        Thread.sleep(1000);

        TestRunner.getTest().log(Status.INFO, "Checking if category exists: " + selectedCategory);
        System.out.println("Checking if category exists: " + selectedCategory);

        Thread.sleep(2000);

        WebElement assignmentTypeFilter = driver.findElement(
                By.xpath("(//div[contains(@class,'FilterOptions')][.//div[contains(@class, 'scrollbarWrapper')]//ul])[2]")
        );
        List<WebElement> totalTypes = assignmentTypeFilter.findElements(By.tagName("li"));

        System.out.println("Total categories found: " + totalTypes.size());
        TestRunner.getTest().log(Status.INFO, "Total Categories found: " + totalTypes.size());

        boolean typeFound = false;

        for (WebElement typeElement : totalTypes) {
            String typeNameText = typeElement.findElement(
                    By.xpath(".//span[contains(@class, 'MuiFormControlLabel-label')]//h6")
            ).getText();
            System.out.println("Category name: " + typeNameText);

            if (typeNameText.equalsIgnoreCase(selectedCategory)) {
                typeFound = true;
                break;
            }
        }

        if (typeFound) {
            TestRunner.getTest().log(Status.FAIL, "Category '" + selectedCategory + "' was found (unexpected). For Include In Report Toggle Off then also category must not found");

        } else {
            TestRunner.getTest().log(Status.PASS, "Category '" + selectedCategory + "' was NOT found as expected.");
            System.out.println("Test Passed: Category not found.");
        }
    }

}
