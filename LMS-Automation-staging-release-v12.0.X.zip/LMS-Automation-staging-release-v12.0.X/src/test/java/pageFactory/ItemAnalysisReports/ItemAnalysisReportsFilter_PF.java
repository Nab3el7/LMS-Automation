package pageFactory.ItemAnalysisReports;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Assignmment.CorrectAnswerExecutor_PF;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import static pageFactory.Gradebook.PositiveTestCaseGradeBook_PF.QuestionIDsOnOpenAssignment;

public class ItemAnalysisReportsFilter_PF {

    WebDriverWait wait;
    WebDriver driver;
    Helper helper;
    Actions actions;
    JavascriptExecutor js;

//    @FindBy(xpath = "//div[normalize-space(text())='School Year']/following-sibling::div//div[contains(@class, 'MuiSelect-select')]")
    @FindBy(xpath = "//div[normalize-space(text())='School Year']/following-sibling::div//input/parent::div")
    WebElement dropdown_select_schoolYear;

//    @FindBy(xpath = "//div[normalize-space(text())='District']/following-sibling::div//div[contains(@class, 'MuiSelect-select')]")
    @FindBy(xpath = "//div[normalize-space(text())='District']/following-sibling::div//input/parent::div")
    WebElement district_filter;

//    @FindBy(xpath = "//div[normalize-space(text())='School']/following-sibling::div//div[contains(@class, 'MuiSelect-select')]")
    @FindBy(xpath = "//div[normalize-space(text())='School']/following-sibling::div//input/parent::div")
    WebElement school_filter_Dropdown;

//    @FindBy(xpath = "//div[normalize-space(text())='Teacher']/following-sibling::div//div[contains(@class, 'MuiSelect-select')]")
    @FindBy(xpath = "//div[contains(normalize-space(text()), 'Teacher')]/following-sibling::div//input/parent::div")
    WebElement teacher_Dropdown;

    @FindBy(xpath = "//nav[@aria-label='pagination navigation']")
    WebElement nav_Pagination;

    @FindBy(xpath = "//button[@aria-label='Print']")
    WebElement btn_Print;

    public static List<String> QuestionIDsPreviewReport = new ArrayList<>();
    public static ThreadLocal<String> assignmentNameInReportTable = ThreadLocal.withInitial(() -> "");

    String questionID = null;
    public String selectedSchoolYear;
    public String selectedDistrict;
    public String school_filter;
    public String selectedTeacherFilter;

    public ItemAnalysisReportsFilter_PF(WebDriver driver) {
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        helper = new Helper();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        actions = new Actions(driver);
    }

    public void SideNavBarAndClickOnReportsModule() throws InterruptedException {
        System.out.println("I'm Into Verify Side Nav Bar and Click on Reports Module");
        TestRunner.getTest().log(Status.INFO, "I'm Into Verify Side Nav Bar and Click on Reports Module");
        Thread.sleep(1000);

        try {
            // Wait for any backdrop/overlay to disappear if it exists
            try {
                wait.until(ExpectedConditions.invisibilityOfElementLocated(By.className("MuiBackdrop-root")));
            } catch (Exception e) {
                System.out.println("No backdrop found or already disappeared");
                TestRunner.getTest().log(Status.INFO, "No backdrop found or already disappeared");
            }

            // Wait for navigation bar to be present
            WebElement navBar = wait.until(ExpectedConditions.presenceOfElementLocated(
                    By.xpath("//div[@class='navigation']")));

            List<WebElement> totalLinks = navBar.findElements(By.tagName("a"));
            System.out.println("Total links found: " + totalLinks.size());

            for (WebElement link : totalLinks) {
                String hrefValue = link.getAttribute("href");
                System.out.println("Link is: " + hrefValue);

                if (hrefValue != null && hrefValue.contains("/reports")) {
                    try {
                        // Scroll the link into view first
                        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block: 'center', behavior: 'instant'});", link);
                        Thread.sleep(300);

                        // Wait for link to be visible (not necessarily clickable)
                        wait.until(ExpectedConditions.visibilityOf(link));

                        // Try to find the button inside the anchor tag (the actual clickable element)
                        WebElement button = null;
                        try {
                            button = link.findElement(By.tagName("button"));
                            System.out.println("Found button inside Reports link");
                        } catch (NoSuchElementException e) {
                            System.out.println("No button found inside anchor tag, will click link directly");
                        }

                        // Try clicking with multiple strategies
                        boolean clicked = false;
                        
                        // Strategy 1: Try clicking the button if it exists
                        if (button != null) {
                            try {
                                // Use Actions class to move to and click the button
                                actions.moveToElement(button).pause(200).click().perform();
                                System.out.println("Successfully clicked Reports button using Actions");
                                clicked = true;
                            } catch (Exception e) {
                                System.out.println("Actions click on button failed: " + e.getMessage());
                            }
                        }
                        
                        // Strategy 2: If button click didn't work, try JavaScript on button
                        if (!clicked && button != null) {
                            try {
                                ((JavascriptExecutor) driver).executeScript("arguments[0].click();", button);
                                System.out.println("Successfully clicked Reports button using JavaScript");
                                clicked = true;
                            } catch (Exception e) {
                                System.out.println("JavaScript click on button failed: " + e.getMessage());
                            }
                        }
                        
                        // Strategy 3: Try JavaScript click on the anchor tag
                        if (!clicked) {
                            try {
                                ((JavascriptExecutor) driver).executeScript("arguments[0].click();", link);
                                System.out.println("Successfully clicked Reports link using JavaScript");
                                clicked = true;
                            } catch (Exception e) {
                                System.out.println("JavaScript click on link failed: " + e.getMessage());
                            }
                        }
                        
                        // Strategy 4: Final fallback - navigate directly using href
                        if (!clicked) {
                            String href = link.getAttribute("href");
                            if (href != null && !href.isEmpty()) {
                                System.out.println("Navigating directly to: " + href);
                                driver.navigate().to(href);
                                clicked = true;
                            }
                        }

                        if (clicked) {
                            TestRunner.getTest().log(Status.PASS, "Testcase Passed   :  Side navbar shows and clicked on Reports Module");
                            Thread.sleep(1000); // Wait for page navigation
                            break; // Break the loop after finding and clicking the Reports link
                        } else {
                            throw new RuntimeException("All click strategies failed");
                        }

                    } catch (Exception e) {
                        System.out.println("Exception occurred: " + e.getMessage());
                        TestRunner.getTest().log(Status.WARNING, "Exception occurred, trying direct navigation: " + e.getMessage());
                        // Final fallback: Navigate directly using href
                        try {
                            String href = link.getAttribute("href");
                            if (href != null && !href.isEmpty()) {
                                driver.navigate().to(href);
                                TestRunner.getTest().log(Status.PASS, "Testcase Passed   :  Side navbar shows and navigated to Reports Module");
                                break;
                            }
                        } catch (Exception navException) {
                            System.out.println("Direct navigation also failed: " + navException.getMessage());
                            TestRunner.getTest().log(Status.FAIL, "Testcase Failed   :  All methods failed to click Reports Module");
                            throw navException;
                        }
                    }
                }
            }
        } catch (Exception e) {
            System.out.println("Exception occurred while clicking Reports Module: " + e.getMessage());
            TestRunner.getTest().log(Status.FAIL, "Testcase Failed   :  Exception occurred while clicking Reports Module: " + e.getMessage());
        }
    }

    public void VerifyAndClickOnItemAnalysisReport() throws InterruptedException {
        System.out.println("I'm Into Click on Item Analysis Reports From Favourite Reports");
        TestRunner.getTest().log(Status.INFO,"I'm Into Click on Item Analysis Reports From Favourite Reports");

        WebElement item_analysis_Report= driver.findElement(By.xpath("//box[normalize-space()='Item Analysis Report']"));

        if (item_analysis_Report.isDisplayed()){
            item_analysis_Report.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Item Analysis Reports Click Successfully");
        }else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Item Analysis Reports Not Found on Reports Dashboard");
        }
    }

    public void verifyLeftSideText() throws InterruptedException {
        System.out.println("I'm Into Verify That Left Side Text is Present and Match with expected Text on Reports Screen");
        TestRunner.getTest().log(Status.INFO, "I'm Into Verify That Left Side Text is Present and Match with expected Text on Reports Screen");

        String expectedText = "Please select and Apply Filters on the left and then\nselect an assignment to run report";

        try {
            WebElement element = driver.findElement(By.xpath("//div[contains(@class,'assessments-container')]//h4"));

            if (element.isDisplayed()) {
                System.out.println("Text is present on Reports Screen.");
                TestRunner.getTest().log(Status.PASS,"Text is present on Reports Screen.");

                String actualText = element.getText();
                TestRunner.getTest().log(Status.INFO,"Text From Reports Screen: " + actualText);
                System.out.println("Text From Reports Screen: " + actualText);

                if (actualText.equals(expectedText)) {
                    System.out.println("Actual Text : " + actualText + " match with Expected Text: " + expectedText);
                    TestRunner.getTest().log(Status.PASS,"Actual Text : " + actualText + "  match with Expected Text: " + expectedText);
                } else {

                    System.out.println("Actual Text : " + actualText + "  Not match with Expected Text: " + expectedText);
                    TestRunner.getTest().log(Status.FAIL,"Actual Text : " + actualText + "  Not match with Expected Text: " + expectedText);
                }

            } else {
                System.out.println("Text is Not present on Reports Screen.");
                TestRunner.getTest().log(Status.FAIL,"Text is Not present on Reports Screen.");
            }

        } catch (NoSuchElementException e) {
            System.out.println("Text Element is not present in the DOM.");
            TestRunner.getTest().log(Status.FAIL,"Text Element is not present in the DOM..");
        }
    }

    public void ValidateByDefaultByClassButtonIsPressed() throws InterruptedException{
        System.out.println("I'm Into Validate that By Default By Class is Checked/Pressed");
        TestRunner.getTest().log(Status.INFO, "I'm Into Validate that By Default By Class is Checked/Pressed");

        WebElement byClassButton = driver.findElement(By.xpath("//button[contains(., 'By Class') and @aria-pressed='true']"));

        boolean isByClassSelected = byClassButton.getAttribute("aria-pressed").equals("true");

        if (isByClassSelected) {
            TestRunner.getTest().log(Status.PASS, "The 'By Class' button is pressed by default.");
            System.out.println("The 'By Class' button is pressed by default.");
        } else {
            TestRunner.getTest().log(Status.FAIL, "The 'By Class' button is not pressed by default.");
            System.out.println("The 'By Class' button is not pressed by default.");
        }
    }

    public void selectSchoolYearForReport() throws InterruptedException {
        System.out.println("I'm Into Select School Year For Report From Dropdown");
        TestRunner.getTest().log(Status.INFO, "I'm Into Select School Year For Report From Dropdown");
        
        try {
            // Wait for any backdrop/overlay to disappear if it exists
            try {
                wait.until(ExpectedConditions.invisibilityOfElementLocated(By.className("MuiBackdrop-root")));
                Thread.sleep(300);
            } catch (Exception e) {
                System.out.println("No backdrop found or already disappeared");
                TestRunner.getTest().log(Status.INFO, "No backdrop found or already disappeared");
            }

            // Wait for dropdown to be clickable and then click
            try {
                wait.until(ExpectedConditions.elementToBeClickable(dropdown_select_schoolYear));
                dropdown_select_schoolYear.click();
            } catch (ElementClickInterceptedException e) {
                System.out.println("Click intercepted by backdrop, using JavaScript click: " + e.getMessage());
                TestRunner.getTest().log(Status.INFO, "Click intercepted, using JavaScript click");
                ((JavascriptExecutor) driver).executeScript("arguments[0].click();", dropdown_select_schoolYear);
            }

            WebElement listRole = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[contains(@role, 'listbox')]")));
            List<WebElement> optionsRole = listRole.findElements(By.xpath(".//li"));

            System.out.println("School Year List is: " + optionsRole.size());

            if (optionsRole.isEmpty()) {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: No options found in the School Year dropdown");
                System.out.println("No options found in the School Year dropdown.");
                throw new RuntimeException("No School Year Value found in dropdown");

            } else {
                System.out.println("School Year:");

                boolean RoleFound = false;
                String targetRole = "2025-2026-Active";

                for (WebElement role : optionsRole) {
                    String roleText = role.getText().trim();
                    System.out.println(roleText);

                    if (roleText.equalsIgnoreCase(targetRole)) {
                        selectedSchoolYear = roleText;
                        try {
                            role.click();
                        } catch (ElementClickInterceptedException e) {
                            System.out.println("Role click intercepted, using JavaScript click");
                            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", role);
                        }
                        RoleFound = true;
                        System.out.println("Selected School Year : " + selectedSchoolYear);
                        TestRunner.getTest().log(Status.INFO, "Selected School Year  is: " + selectedSchoolYear);
                        TestRunner.getTest().log(Status.PASS, "Test Case Passed: School Year selected successfully");
                        break;
                    }
                }

                if (!RoleFound) {
                    TestRunner.getTest().log(Status.FAIL, "Test Case Failed: '2025-2026-Active' not found in the dropdown");
                    throw new RuntimeException("'2025-2026-Active' not found in the dropdown");
                }
            }
        } catch (Exception e) {
            System.out.println("Exception occurred in selectSchoolYearForReport: " + e.getMessage());
            TestRunner.getTest().log(Status.FAIL, "Exception occurred in selectSchoolYearForReport: " + e.getMessage());
            e.printStackTrace();
            throw e;
        }
    }

    public void selectDistrictForReport() {
        try {
            System.out.println("I'm Into Select District From Dropdown");
            TestRunner.getTest().log(Status.INFO, "I'm Into Select District From Dropdown");

            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
            wait.until(ExpectedConditions.elementToBeClickable(district_filter)).click();

            WebElement listDistrict = wait.until(ExpectedConditions.presenceOfElementLocated(
                    By.xpath("//ul[@role='listbox']")
            ));

            List<WebElement> optionsDistrict = listDistrict.findElements(By.xpath(".//li"));
            Thread.sleep(1000);

            System.out.println("District List Size: " + optionsDistrict.size());

            if (optionsDistrict.isEmpty()) {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: No options found in the District dropdown");
                System.out.println("No options found in the District dropdown.");
                throw new RuntimeException("No District Value found in dropdown");
            } else {
                System.out.println("Available District Options:");
                boolean districtFound = false;

                for (WebElement district : optionsDistrict) {
                    String districtName = district.getText();
                    System.out.println(districtName);

                    if (districtName.contains("Florida Demo District")) {
                        districtFound = true;
                        district.click();
                        selectedDistrict = districtName;
                        System.out.println("Selected District: " + selectedDistrict);
                        TestRunner.getTest().log(Status.INFO, "Selected District: " + selectedDistrict);
                        break;
                    }
                }

                Thread.sleep(1000);
                actions.sendKeys(Keys.ESCAPE).perform();

                if (!districtFound) {
                    TestRunner.getTest().log(Status.FAIL, "Test Case Failed: District 'Florida Demo District' not found");
                    System.out.println("District 'Florida Demo District' not found.");
                    throw new RuntimeException("District 'Florida Demo District' not found in dropdown");
                }
            }

        } catch (TimeoutException e) {
            TestRunner.getTest().log(Status.FAIL, "Timeout waiting for District dropdown: " + e.getMessage());

        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "Exception in selectDistrictForReport: " + e.getMessage());
        }
    }

    public void selectSchoolForReport() throws InterruptedException {
        System.out.println("I'm Into Select School From Dropdown");
        TestRunner.getTest().log(Status.INFO, "I'm Into Select School From Dropdown");

        school_filter_Dropdown.click();

        WebElement listDistrict = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[contains(@role, 'listbox')]")));
        List<WebElement> optionsDistrict = listDistrict.findElements(By.xpath(".//li"));
        Thread.sleep(1000);

        System.out.println("School List is: " + optionsDistrict.size());

        if (optionsDistrict.isEmpty()) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: No options found in the School dropdown");
            System.out.println("No options found in the School dropdown.");
            throw new RuntimeException("No School Value found in dropdown");

        } else {
            System.out.println("School Filter:");

            boolean schoolFound = false;

            for (WebElement school : optionsDistrict) {
                String schoolName = school.getText();
                System.out.println(schoolName);

                if (schoolName.contains("Florida ES")) {
                    schoolFound = true;
                    school.click();
                    school_filter = schoolName;
                    System.out.println("Selected School: " + school_filter);
                    TestRunner.getTest().log(Status.INFO, "Selected School: " + school_filter);
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed: School Filter selected successfully");
                    break;
                }
            }

            Thread.sleep(1000);
            actions.sendKeys(Keys.ESCAPE).perform();

            if (!schoolFound) {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: School 'Florida ES' not found");
                System.out.println("School 'Florida ES' not found.");
                throw new RuntimeException("School 'Florida ES' not found in dropdown");
            }
        }
    }

    public void selectTeacherForReport() throws InterruptedException {
        System.out.println("I'm Into Select Teacher From Dropdown");
        TestRunner.getTest().log(Status.INFO, "I'm Into Select Teacher From Dropdown");

        teacher_Dropdown.click();

        WebElement listDistrict = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[contains(@role, 'listbox')]")));
        List<WebElement> optionsDistrict = listDistrict.findElements(By.xpath(".//li"));
        Thread.sleep(1000);

        System.out.println("Teacher List is: " + optionsDistrict.size());

        if (optionsDistrict.isEmpty()) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: No options found in the Teacher dropdown");
            System.out.println("No options found in the Teacher dropdown.");
            throw new RuntimeException("No Teacher Value found in dropdown");

        } else {
            System.out.println("Teacher Filter:");

            boolean teacherFound = false;

            for (WebElement teacher : optionsDistrict) {
                String teacherName = teacher.getText();
                System.out.println(teacherName);

                if (teacherName.contains("Maria Gomez") || teacherName.contains("Harry Potter") || teacherName.contains("Automation-QA Teacher")) {
                    teacherFound = true;
                    teacher.click();
                    selectedTeacherFilter = teacherName;
                    System.out.println("Selected Teacher: " + selectedTeacherFilter);
                    TestRunner.getTest().log(Status.INFO, "Selected Teacher: " + selectedTeacherFilter);
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed: Teacher Filter selected successfully");
                    break;
                }
            }

            Thread.sleep(1000);
            actions.sendKeys(Keys.ESCAPE).perform();

            if (!teacherFound) {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Teacher 'Maria Gomez', 'Harry Potter', or 'Automation-QA Teacher' not found");
                System.out.println("Teacher 'Maria Gomez', 'Harry Potter', or 'Automation-QA Teacher' not found.");
                throw new RuntimeException("Teacher 'Maria Gomez', 'Harry Potter', or 'Automation-QA Teacher' not found in dropdown");
            }
        }
    }

    public void SelectCategoryFromReports(String selectedCategory) throws InterruptedException{
        Thread.sleep(1000);

        TestRunner.getTest().log(Status.INFO, "I'm in to select Categories For Reports");

        TestRunner.getTest().log(Status.INFO, " Select Category From Assignment Release: " + selectedCategory);
        System.out.println("select Category From Assignment Release: " + selectedCategory);

        Thread.sleep(2000);
        // Locate the Assignment Type Filter list container
        WebElement assignmentTypeFilter = driver.findElement(By.xpath("(//div[contains(@class,'FilterOptions')][.//div[contains(@class, 'scrollbarWrapper')]//ul])[2]"));
        List<WebElement> totalTypes = assignmentTypeFilter.findElements(By.tagName("li"));

        System.out.println("Total types are: " + totalTypes.size());
        TestRunner.getTest().log(Status.INFO, "Total Categories are: " + totalTypes.size());

        boolean typeFound = false;

        for (WebElement typeElement : totalTypes) {
            // Get the text of the assignment type within the current `li` element
            String typeNameText = typeElement.findElement(By.xpath(".//span[contains(@class, 'MuiFormControlLabel-label')]//h6")).getText();
            System.out.println("Categories name is: " + typeNameText);

            // Check if this is the desired assignment type to select
            if (typeNameText.equalsIgnoreCase(selectedCategory)) {
                typeFound = true;
                WebElement checkBox = typeElement.findElement(By.xpath(".//input[@type='checkbox']"));

                boolean isChecked = checkBox.isSelected();

                if (isChecked) {
                    System.out.println("Checkbox for " + selectedCategory + " is already selected.");
                    TestRunner.getTest().log(Status.INFO, "Checkbox for " + selectedCategory + " is already selected.");
                } else {
                    checkBox.click();
                    System.out.println("Checkbox for " + selectedCategory + " is now selected.");
                    TestRunner.getTest().log(Status.INFO, "Checkbox for " + selectedCategory + " is now selected.");
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed: Assignment Type is selected successfully");
                }
                break;
            }
        }

        if (!typeFound) {
            TestRunner.getTest().log(Status.INFO, "No checkbox found for: " + selectedCategory);
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: No Option Found for: " + selectedCategory);
        }
    }

    public static void setReportName(String assignmentName) {
        assignmentNameInReportTable.set(assignmentName);
    }

    public static String getReportName() {
        return assignmentNameInReportTable.get();
    }

    public void verifyDataInRightSideReport() throws InterruptedException {
        System.out.println("I'm Into Verify Data Display On Right Side Table of Reports");
        TestRunner.getTest().log(Status.INFO, "I'm Into Verify Data Display On Right Side Table of Reports");
        Thread.sleep(2000);


        try {
            WebElement tableBody = wait.until(ExpectedConditions.presenceOfElementLocated(
                    By.xpath("//div[contains(@class, 'SelectAssignmentTable')]//tbody")));

            List<WebElement> rows = tableBody.findElements(By.tagName("tr"));

            if (rows.isEmpty()) {
                System.out.println("No Assignment List found in the table.");
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: No Assignment List found in the table.");
                return;
            }

            System.out.println("Assignment found in the table:");
            TestRunner.getTest().log(Status.INFO, "Assignment found in the table:");

            for (int i = 0; i < rows.size(); i++) {
                WebElement row = rows.get(i);

                for (int attempt = 0; attempt < 2; attempt++) {
                    try {
                        WebElement nameElement = row.findElement(By.xpath(".//td[2]//a"));
                        setReportName(nameElement.getText());
//                        assignmentNameInReportTable = nameElement.getText();
                        System.out.println("Assignment Name On Run Report Screen: " + getReportName());
                        TestRunner.getTest().log(Status.INFO, "Assignment Name On Run Report Screen: " + getReportName());

                        List<WebElement> cells = row.findElements(By.tagName("td"));
                        StringBuilder rowText = new StringBuilder();
                        for (WebElement cell : cells) {
                            rowText.append(cell.getText()).append("\t");
                        }
                        System.out.println(rowText);
                        TestRunner.getTest().log(Status.PASS, "Test case Passed: Assignment List Found in Table Successfully");

                        break; // success, exit retry loop

                    } catch (StaleElementReferenceException e) {
                        System.out.println("Stale element found on attempt " + (attempt + 1) + ", retrying...");
                        TestRunner.getTest().log(Status.WARNING, "Stale element encountered on attempt " + (attempt + 1) + ", retrying...");

                        // Re-fetch rows and retry the same index
                        rows = tableBody.findElements(By.tagName("tr"));
                        row = rows.get(i);
                    }
                }
            }

        } catch (TimeoutException e) {
            System.out.println("Timed out waiting for the Report Assignment table.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Report Assignment Table not visible (timeout).");
        }
    }

    public void verifyAndClickAssignmentTitleCheckbox() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm Into Verify and Click on Assignment Title Checkbox");
        System.out.println("I'm Into verify and Click on Assignment Title Checkbox");

        Thread.sleep(1000);
        WebElement checkbox = driver.findElement(By.xpath("//label[.//span[contains(text(),'Assignment Title')]]//input[@type='checkbox']"));
        helper.scrollToElement(driver, checkbox);

        checkbox.click();
        System.out.println("Test Case Passed: Assignment Title Check box Clicked successfully");
        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Assignment Title Check box Clicked successfully");
    }

    public void searchAssignmentByTitleForReport() throws InterruptedException {

        System.out.println("I'm into search Assignment By Title On Run Report: " + "AttemptAssignmentCorrect_Mon Dec 01 11:26:19 PKT 2025");
                //CorrectAnswerExecutor_PF.assignmentNameForCorrect.get());
        TestRunner.getTest().log(Status.INFO, "I'm Into search Assignment By Title On Run Report: " + "AttemptAssignmentCorrect_Mon Dec 01 11:26:19 PKT 2025");
                //CorrectAnswerExecutor_PF.assignmentNameForCorrect.get());


        WebElement right_panel = driver.findElement(By.xpath("//div[contains(@class,'flex items-center')]"));
        right_panel.isDisplayed();


        try {
            WebElement searchBox = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder='Search By Title']")));
            if (searchBox.isDisplayed()) {
                searchBox.click();
                searchBox.clear();
                ((JavascriptExecutor) driver).executeScript("arguments[0].value='';", searchBox);

                String assignmentNameForCorrect = "AttemptAssignmentCorrect_Mon Dec 01 11:26:19 PKT 2025";
                        //CorrectAnswerExecutor_PF.assignmentNameForCorrect.get();
                System.out.println("Search Assignment name By Title: " + assignmentNameForCorrect);
                searchBox.sendKeys(assignmentNameForCorrect);

                TestRunner.getTest().log(Status.INFO, "Search Assignment name By Title: " + assignmentNameForCorrect);

                Actions actions = new Actions(driver);
                actions.sendKeys(Keys.ENTER).perform();


                TestRunner.getTest().log(Status.PASS, "Test Case Passed   :   Enter Search Assignment keyword Successfully");

                waitForTableToRefresh();
            } else {
                System.out.println("Search box is not displayed.");
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : Search box is not displayed.");
//                throw new RuntimeException("Search Box not  Found.");
            }
        } catch (Exception e) {
            System.out.println("Search box is not available: " + e.getMessage());
        }

    }

    private void waitForTableToRefresh() {

//        WebElement firstDiv = driver.findElement(By.xpath("//div[contains(@class, 'left-content-header')]/div[contains(@class, 'MuiBox-root')]/div[1]"));
//        System.out.println("TAssessment able has refreshed.");

        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class, 'SelectAssignmentTable')]//tbody//td[2]//a")));

        System.out.println("Report Assessment Table has refreshed.");
        TestRunner.getTest().log(Status.PASS, "Test Case Passed : Report Assessment Table has refreshed");


    }


    public void verifySearchedAssessmentByTitleIntoTable() {

        String assignmentNameForCorrect = "AttemptAssignmentCorrect_Mon Dec 01 11:26:19 PKT 2025";
                //CorrectAnswerExecutor_PF.assignmentNameForCorrect.get();
        System.out.println("Want to search assignment into table: " + assignmentNameForCorrect);
        TestRunner.getTest().log(Status.INFO, "Want to search assignment into table: " + assignmentNameForCorrect);

        String assignmentNameFinal= getReportName();
        TestRunner.getTest().log(Status.INFO,"Assignment Name in table that you want: " + assignmentNameFinal);

        System.out.println("Assignment name in table that you want: " + assignmentNameFinal);

        if (assignmentNameFinal.contains(assignmentNameForCorrect)) {
            System.out.println("Searched Assessment found: " + assignmentNameFinal + " is match with " + assignmentNameForCorrect);
            TestRunner.getTest().log(Status.INFO, "Searched Assessment found: " + assignmentNameFinal + "  is match with " + assignmentNameForCorrect);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed : Search Assessment by keyword Successfully");


        } else {
            System.out.println("Searched Assessment not found and search filter not working");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Searched Assessment not found and search filter not working");
        }
    }

    public void VerifyResourceTitleCheckBox() throws InterruptedException {
        System.out.println("I'm into verify that By Default Resource Title checkbox is already checked/clicked");
        TestRunner.getTest().log(Status.INFO, "I'm into verify that By Default Resource Title resource title checkbox is already checked/clicked");

        WebElement checkbox_resourceTitle = driver.findElement(
                By.xpath("//label[.//span[contains(text(),'Resource Title')]]//input[@type='checkbox']")
        );

        if (checkbox_resourceTitle.isSelected()) {
            System.out.println("Test Case Pass: By Default Resource Title checkbox is already selected.");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: By Default Resource Title checkbox is already selected.");
        } else {
            System.out.println("Test Case Fail: : By Default Resource Title checkbox is NOT selected.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: By Default Resource Title checkbox is NOT selected.");

        }
    }

    public void verifyAndClickPreview() throws InterruptedException {
        System.out.println("I'm into click on Preview Button ");
        TestRunner.getTest().log(Status.INFO, "I'm into click on Preview Button");


        WebElement preview_btn= driver.findElement(By.xpath("//span[normalize-space()='Preview']"));
        if (preview_btn.isDisplayed()){
            preview_btn.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed : Preview Button Display and Click successfully");
        }else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Preview Button Not Display/Clicked");

        }

    }

    public void VerifyReportPreviewQuestions() throws InterruptedException{
        TestRunner.startTest("I'm into Get All questions From Preview Report");

        if (!isPaginationDisplayed()) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Pagination not display on Open Assignment ");
        }

        try {
            List<WebElement> questionButtons = nav_Pagination.findElements(By.xpath("//button[contains(@aria-label, 'Go to page')]"));

            for (WebElement questionButton : questionButtons) {
                String questionText = questionButton.getText();
                System.out.println("Question: " + questionText);
                TestRunner.getTest().log(Status.INFO, "Total Questions: " + questionText);
            }
            QuestionIDsPreviewReport.clear();

            TestRunner.startTest("Get All Question From Report Preview");

            boolean hasNextPage = true;
            while (hasNextPage) {
                GetQuestionIdsFromReportPreview();

                try {
                    WebElement btnNextPage = driver.findElement(By.xpath("//button[@aria-label='Go to next page']"));
                    if (btnNextPage.isEnabled()) {
                        btnNextPage.click();
                        TestRunner.getTest().log(Status.INFO, "Navigating to the next page.");
                        Thread.sleep(2000);
                    } else {
                        hasNextPage = false;
                    }
                } catch (NoSuchElementException e) {
                    hasNextPage = false;
                    TestRunner.getTest().log(Status.INFO, "Reached the last page.");
                }
            }

            System.out.println("All Assignment Questions get Successfully From Preview Report");
            TestRunner.getTest().log(Status.INFO, "All Assignment Questions get Successfully From Preview Report");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: All Assignment Questions get Successfully From Preview Report");
            ClickOnCrossButton();

        } catch (NoSuchElementException | ElementNotInteractableException | TimeoutException e) {
            System.out.println("No Question found.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : No Question found or Question not visible");
        }
    }

    private boolean isPaginationDisplayed() {
        try {
            return nav_Pagination.isDisplayed();
        } catch (NoSuchElementException | ElementNotInteractableException | TimeoutException e) {
            return false;
        }
    }

    public void ClickOnCrossButton() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm into click on x button on Preview Report");
        System.out.println("I'm into click on x button on Preview Report");


        WebElement crossButton= driver.findElement(By.xpath("//button[@aria-label='close']"));
        if (crossButton.isDisplayed()){
            crossButton.click();
            System.out.println("X button Found and click successfully");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: X button click Successfully");
        }else {
            System.out.println("X button not found");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: X button Not Found");

        }
    }


    public void GetQuestionIdsFromReportPreview() throws InterruptedException{
        Thread.sleep(3000);
        System.out.println("I'm in Getting all questions From Preview For Report");
        TestRunner.getTest().log(Status.INFO, "I'm in Getting all questions From Preview For Report");
        Thread.sleep(1000);
        //    new WebDriverWait(driver, Duration.ofSeconds(30));

        WebElement questionPlayer = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("lesson-player-ifram")));
        driver.switchTo().frame(questionPlayer);
        WebElement QuestionBody = driver.findElement(By.xpath("//div[contains(@class, 'LessonPlayerRoot')]"));

        WebElement QuestionPlayer = null;

        try {
            List<WebElement> MultiParts = QuestionBody.findElements(By.xpath("//div[contains(@class, 'planComponentQuestion')]"));
            System.out.println("Total number of multi-part on this page: " + MultiParts.size());
            TestRunner.getTest().log(Status.INFO, "Total part of question (if multipart question exists): " + MultiParts.size());

            for (WebElement part : MultiParts) {
                QuestionPlayer = part.findElement(By.xpath(".//div[contains(@class, 'QuestionPlayer')]"));

                System.out.println("Question is found");
                String questionType = QuestionPlayer.getAttribute("data-type");
                System.out.println("Question Type is: " + questionType);
                TestRunner.getTest().log(Status.INFO, "Attempted question type is: " + questionType);

                WebElement questionRoot = QuestionPlayer.findElement(By.xpath(".//div[contains(@class, 'question-root')]"));
                questionID = questionRoot.getAttribute("data-question-id");
                System.out.println("Question ID is: " + questionID);
                TestRunner.getTest().log(Status.INFO, "Attempted question ID is: " + questionID);

                System.out.println("I'm in to store Question ID's In Open Assignment: " + questionID);
                TestRunner.getTest().log(Status.INFO, "I'm in to store Question ID's In Open Assignment : " + questionID);
                QuestionIDsPreviewReport.add(questionID);
                System.out.println("Question ID's: " + QuestionIDsPreviewReport);

            }
        } catch (NoSuchElementException e) {
            System.out.println("This is a content player question and have no any data type question");
            TestRunner.getTest().log(Status.INFO, "This is a content player question and have no any data type question");

            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
        } finally {
            driver.switchTo().defaultContent();
        }
    }


    public void VerificationOfReportPreview() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm verifying that questions from Assignment Open Button and from Preview On Report match.");
        System.out.println("I'm verifying that questions from Assignment Open Button and from Preview On Report match.");

        // Assuming QuestionIDsOnOpenAssignment and QuestionIDsPreviewGradeBook are populated elsewhere
        if (QuestionIDsOnOpenAssignment.isEmpty() || QuestionIDsPreviewReport.isEmpty()) {
            System.out.println("One of the lists is empty, cannot compare.");
            TestRunner.getTest().log(Status.FAIL, "One of the lists is empty, cannot compare.");
            return;
        }

        // Ensure both lists have the same size before comparing
        if (QuestionIDsOnOpenAssignment.size() != QuestionIDsPreviewReport.size()) {
            System.out.println("The lists are of different sizes, comparison cannot be done.");
            TestRunner.getTest().log(Status.FAIL, "The lists are of different sizes, comparison cannot be done.");
            return;
        }

        // Compare lists index by index
        for (int i = 0; i < QuestionIDsOnOpenAssignment.size(); i++) {
            String idFromOpen = QuestionIDsOnOpenAssignment.get(i);
            String idFromPreview = QuestionIDsPreviewReport.get(i);

            // Add 1 to the index in the output to start from 1
            if (idFromOpen.equals(idFromPreview)) {
                System.out.println("Question " + (i + 1) + ": IDs match (" + idFromOpen + ")");
                TestRunner.getTest().log(Status.PASS, "Question " + (i + 1) + ": IDs match (" + idFromOpen + ")");
            } else {
                System.out.println("Question " + (i + 1) + ": IDs do not match (Open: " + idFromOpen + ", Preview: " + idFromPreview + ")");
                TestRunner.getTest().log(Status.FAIL, "Question " + (i + 1) + ": IDs do not match (Open: " + idFromOpen + ", Preview: " + idFromPreview + ")");
            }
        }
    }


    public void clickOnAssignmentCheckbox() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm Into Click on Assignment Checkbox");
        System.out.println("I'm Into Click on Assignment Checkbox");

        WebElement checkbox = driver.findElement(By.xpath("//td[contains(@class, 'checkboxSelectionTableCell')]//input[@type='checkbox']"));
        checkbox.click();

    }


    public void VerifyAndClickRunButton() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm Into Click on Run Button");
        System.out.println("I'm Into Click on Run Button");
        Thread.sleep(1000);

        WebElement runBtn = driver.findElement(By.xpath("//button[normalize-space()='Run']"));

        if (runBtn.isDisplayed() && runBtn.isEnabled()) {
            runBtn.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Run Button is Displayed and Enabled, Clicked Successfully");
        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Run Button is either Not Displayed or Not Enabled");
        }

    }


    public void clickPointsButton() throws InterruptedException {
        System.out.println("I'm Into Click on View Points");
        TestRunner.getTest().log(Status.INFO, "I'm Into Click on View Points");

        WebElement points_btn= driver.findElement(By.xpath("//button[@value='point']"));

        if (points_btn.isDisplayed()){
            points_btn.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: View Points Click successfully");
        }else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: View Points Not Displayed");
        }
    }

    List<String> valuesFromSummary = new ArrayList<>();
    List<String> questionIdsFromSummary = new ArrayList<>();
    List<String> overallAverageValuesFromSummary = new ArrayList<>();

    public static double overallAverageValueFromSummary;


    public void getQuestionPointsFromSummary() throws InterruptedException {
        System.out.println("I'm into Get Each Question Points From Summary ");
        TestRunner.getTest().log(Status.INFO, "I'm Into Get Each Question Points From Summary");

        Thread.sleep(2000);


        // Locate all <div> elements with class "overAllAverage"
        List<WebElement> divElements = driver.findElements(By.cssSelector("tr.MuiTableRow-root td div.overAllAverage"));

        // Loop through each element and collect data
        for (WebElement div : divElements) {
            valuesFromSummary.add(div.getText());  // Store the visible value (like "1", "4", "8")
            questionIdsFromSummary.add(div.getAttribute("data-question-id"));  // Store the question ID
        }

        // Optional: Print for verification
        for (int i = 0; i < valuesFromSummary.size(); i++) {
            System.out.println("Value: " + valuesFromSummary.get(i) + " | Question ID: " + questionIdsFromSummary.get(i));
            TestRunner.getTest().log(Status.INFO, "Value: " + valuesFromSummary.get(i) + " | Question ID: " + questionIdsFromSummary.get(i));
        }

    }


    public void getOverAllAverageFromSummary() throws InterruptedException {
        System.out.println("I'm into Get OverAll Average From Summary");
        TestRunner.getTest().log(Status.INFO, "I'm into Get OverAll Average From Summary");


        WebElement overallAverageElement = driver.findElement(By.cssSelector("div.header-left span.overAllAverage"));
        String overallAverage = overallAverageElement.getText();
        overallAverageValueFromSummary = Double.parseDouble(overallAverage);

        System.out.println("Stored Overall Average: " + overallAverageValueFromSummary);
        TestRunner.getTest().log(Status.INFO, "OverAverage From Summary: " + overallAverageValueFromSummary);

    }


    List<String> valuesFromRunReport = new ArrayList<>();
    List<String> questionIdsFromRunReport = new ArrayList<>();
    public static double overallAverageValueFromRunReport;

    public void getQuestionPointsFromRunReport() throws InterruptedException {
        System.out.println("I'm into Get Each Question Points From Run Report");
        TestRunner.getTest().log(Status.INFO, "I'm Into Get Each Question Points From Run Report");

        Thread.sleep(2000);


        List<WebElement> divElements = driver.findElements(By.cssSelector("tr.MuiTableRow-root td div.overAllAverage"));


        for (WebElement div : divElements) {
            valuesFromRunReport.add(div.getText());
            questionIdsFromRunReport.add(div.getAttribute("data-question-id"));
        }

        for (int i = 0; i < valuesFromRunReport.size(); i++) {
            System.out.println("Value Point From Run Report: " + valuesFromRunReport.get(i) +
                    " | Question ID From Run report: " + questionIdsFromRunReport.get(i));

            TestRunner.getTest().log(Status.INFO, "Value Point From Run Report: " + valuesFromRunReport.get(i) +
                    " | Question ID From Run report: " + questionIdsFromRunReport.get(i));
        }

    }

    public void getOverAllAverageFromRunReport() throws InterruptedException {
        System.out.println("I'm into Get OverAll Average From Run Report");
        TestRunner.getTest().log(Status.INFO, "I'm into Get OverAll Average From Run Report");


        WebElement overallAverageElement = driver.findElement(By.cssSelector("div.header-left span.overAllAverage"));
        String overallAverage = overallAverageElement.getText();
        overallAverageValueFromRunReport = Double.parseDouble(overallAverage);

        System.out.println("Stored Overall Average From Run Report: " + overallAverageValueFromRunReport);
        TestRunner.getTest().log(Status.INFO, "OverAverage From Run Report: " + overallAverageValueFromRunReport);

    }


    public void compareSummaryAndRunReportData() throws InterruptedException {
        System.out.println("I'm into Verify that Points and Scores Match on Run Report");
        TestRunner.getTest().log(Status.INFO, "I'm into verify that Points and Scores Match on Run Report");


        boolean allMatch = true;

        // Check size first (optional sanity check)
        if (questionIdsFromSummary.size() != questionIdsFromRunReport.size()) {
            System.out.println("Mismatch in question ID count!");
            allMatch = false;
        }

        // Compare question-wise values
        for (int i = 0; i < questionIdsFromSummary.size(); i++) {
            String questionIdSummary = questionIdsFromSummary.get(i);
            String valueSummary = valuesFromSummary.get(i);

            int runIndex = questionIdsFromRunReport.indexOf(questionIdSummary);

            if (runIndex != -1) {
                String valueRunReport = valuesFromRunReport.get(runIndex);

                if (!valueSummary.equals(valueRunReport)) {
                    System.out.println(" Mismatch found for Question ID: " + questionIdSummary +
                            " | Summary: " + valueSummary + " | Run Report: " + valueRunReport);

                    TestRunner.getTest().log(Status.FAIL,"Test Case Failed: Mismatch found for Question ID: " + questionIdSummary +
                    " | Summary: " + valueSummary + " | Run Report: " + valueRunReport);

                    allMatch = false;
                } else {
                    System.out.println(" Matched for Question ID: " + questionIdSummary +
                            " | Value: " + valueSummary);
                    TestRunner.getTest().log(Status.PASS,"Test Case Passed: Matched for Question ID: " + questionIdSummary +
                    " | Value: " + valueSummary  + " match with Value on Run Report: " + valueRunReport);
                }
            } else {
                System.out.println(" Question ID from Summary not found in Run Report: " + questionIdSummary);
                TestRunner.getTest().log(Status.FAIL, "Question ID from Summary not found in Run Report: " + questionIdSummary);
                allMatch = false;
            }
        }

        // Compare overall averages
        if (overallAverageValueFromSummary != overallAverageValueFromRunReport) {
            System.out.println("Test Case Failed:  Overall average mismatch | Summary: " + overallAverageValueFromSummary +
                    " | Run Report: " + overallAverageValueFromRunReport);
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed:  Overall average mismatch | Summary: " + overallAverageValueFromSummary +
            " | Run Report: " + overallAverageValueFromRunReport );

            allMatch = false;
        } else {
            System.out.println("Test Case Passed: Overall average matched: " + overallAverageValueFromSummary);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Overall average matched: " + overallAverageValueFromSummary);
        }

        if (allMatch) {
            System.out.println("All values matched successfully!");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: All values matched successfully!");
        } else {
            System.out.println(" Differences found in comparison.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Differences found in comparison");
        }
    }

    public void verifyLevelAndScores() throws InterruptedException {
        System.out.println("I'm into verify that Level and Scores Present on Run Report");
        TestRunner.getTest().log(Status.INFO, "I'm into verify that Level and Scores Present on Run Report");
        Thread.sleep(2000);

        WebElement table = driver.findElement(By.xpath("(//div[contains(@class, 'AssignmentSummary')])"));
        List<WebElement> rows = table.findElements(By.xpath(".//tbody/tr"));

        for (WebElement row : rows) {
            try {
                // Extract student name
                WebElement levelCell = row.findElement(By.xpath(".//td[1]"));
                String LevelName = levelCell.getText().trim();

                if (LevelName.isEmpty()) {
                    // Fail condition if student name is empty
                    System.out.println("No Data Found in Level");
                    TestRunner.getTest().log(Status.FAIL, "No Data Found in Level");
                    continue; // Skip the current iteration if student name is not found
                }

                System.out.println("Level Name: " + LevelName);
                TestRunner.getTest().log(Status.INFO, "Level Name : " + LevelName);

                // Extract student status
                WebElement statusCell = row.findElement(By.xpath(".//td[2]"));
                String status = statusCell.getText().trim();

                if (status.isEmpty()) {
                    // Fail condition if status is empty
                    System.out.println("Score not found for Level: " + LevelName);
                    TestRunner.getTest().log(Status.FAIL, "Score not found for Level: " + LevelName);
                    continue; // Skip the current iteration if status is not found
                }

                System.out.println("Score : " + status);
                TestRunner.getTest().log(Status.INFO, "Score: " + status);

            } catch (NoSuchElementException e) {
                // Handle case when student name or status is missing
                System.out.println("Element not found in row: " + row);
                TestRunner.getTest().log(Status.FAIL, "Element missing in row: " + row);
            }
        }
    }

    public void verifyStudentAndStatusPresent() throws InterruptedException {
        System.out.println("I'm into verify that student and status is also present on Run Report");
        TestRunner.getTest().log(Status.INFO, "I'm into verify that student and status is also present on Run Report");

        WebElement table = driver.findElement(By.xpath("(//div[contains(@class, 'AssignmentSummary')])[2]"));
        List<WebElement> rows = table.findElements(By.xpath(".//tbody/tr"));

        for (WebElement row : rows) {
            try {

                WebElement studentCell = row.findElement(By.xpath(".//td[1]"));
                String studentName = studentCell.getText().trim();

                if (studentName.isEmpty()) {

                    System.out.println("Student Name not found");
                    TestRunner.getTest().log(Status.FAIL, "Student Name not found in row");
                    continue;
                }

                System.out.println("Student's Name: " + studentName);
                TestRunner.getTest().log(Status.INFO, "Student's Name: " + studentName);


                WebElement statusCell = row.findElement(By.xpath(".//td[2]"));
                String status = statusCell.getText().trim();

                if (status.isEmpty()) {

                    System.out.println("Status not found for student: " + studentName);
                    TestRunner.getTest().log(Status.FAIL, "Status not found for student: " + studentName);
                    continue;
                }

                System.out.println("Student Status: " + status);
                TestRunner.getTest().log(Status.INFO, "Student Status: " + status);

            } catch (NoSuchElementException e) {
                // Handle case when student name or status is missing
                System.out.println("Element not found in row: " + row);
                TestRunner.getTest().log(Status.FAIL, "Element missing in row: " + row);
            }
        }
    }

    public void VerifyCorrectAssignmentIsAlreadySelectedInDropdown(String assignmentName) throws InterruptedException {
        System.out.println("I'm into Verify that Correct Assignment is already Selected in dropdown");
        TestRunner.getTest().log(Status.INFO, "I'm into verify that correct assignment is already selected in dropdown");

        try {
            // Locate the dropdown where the selected assignment name is displayed
            WebElement selectedDropdownValue = driver.findElement(By.xpath("//div[contains(@class,'MuiSelect-select') and contains(@class,'MuiOutlinedInput-input')]"));

            // Get the visible text (selected assignment name)
            String selectedAssignmentName = selectedDropdownValue.getText().trim();
            System.out.println("Selected Assignment: " + selectedAssignmentName);
            TestRunner.getTest().log(Status.INFO, "Selected Assignment: " + selectedAssignmentName);

            // Compare it with the expected assignment name
            if (selectedAssignmentName.equalsIgnoreCase(assignmentName.trim())) {
                TestRunner.getTest().log(Status.PASS, "Correct assignment is selected: " + assignmentName);
            } else {
                TestRunner.getTest().log(Status.FAIL, "Incorrect assignment selected. Expected: " + assignmentName + ", but found: " + selectedAssignmentName);
            }

        } catch (NoSuchElementException e) {
            TestRunner.getTest().log(Status.FAIL, "Dropdown or selected assignment element not found.");
            System.out.println("Dropdown or selected assignment element not found.");
        }
    }

    public void validatePrint() throws InterruptedException {
        Thread.sleep(2000);
        System.out.println("I'm Into Validate Printing Functionality");
        TestRunner.getTest().log(Status.INFO, "I'm Into Validate Printing Functionality");

        try {
            wait.until(ExpectedConditions.visibilityOf(btn_Print));
            if (btn_Print.isDisplayed()) {
                btn_Print.click();
                TestRunner.getTest().log(Status.PASS, "Testcase Passed: Print Button clicked successfully");
            } else {
                TestRunner.getTest().log(Status.FAIL, "Print Button is not displayed");
            }
        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "Exception occurred while clicking Print Button: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public void printLoading() throws InterruptedException{
        WebElement loader = driver.findElement(By.xpath("//span[@class=\"BackdropLoader-title\"]"));
        wait.until(ExpectedConditions.invisibilityOf(loader));
        TestRunner.getTest().log(Status.PASS, "Testcase Passed   :  Printing Action Perform successfully");

    }

}
