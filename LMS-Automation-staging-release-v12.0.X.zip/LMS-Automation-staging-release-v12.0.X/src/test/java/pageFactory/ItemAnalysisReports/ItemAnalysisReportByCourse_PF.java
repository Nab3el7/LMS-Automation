package pageFactory.ItemAnalysisReports;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

public class ItemAnalysisReportByCourse_PF {
    WebDriverWait wait;
    WebDriver driver;
    Helper helper;
    Actions actions;
    JavascriptExecutor js;

    public ItemAnalysisReportByCourse_PF(WebDriver driver) {
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        helper = new Helper();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        actions = new Actions(driver);
    }
    @FindBy(xpath = "//div[contains(@class, 'CourseContainer')]")
    WebElement list_MyCourses;

    @FindBy(xpath = "//div[normalize-space(text())='Course']/following-sibling::div//div[contains(@class, 'MuiSelect-select')]")
    WebElement course_for_report;


    public static String selectedCourseNameForReport;


    public void clickByCourseButton() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into click on By Class Button");
        System.out.println("I'm Into Click on By Class Button");

        WebElement byCourse_btn= driver.findElement(By.xpath("//button[@value='courseView']"));

        if (byCourse_btn.isDisplayed()){
            byCourse_btn.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: By Course Button is Display and  Click successfully");
        }else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: By Course Button is Not Display");

        }

    }

    public void SelectCourseForReport() {
        TestRunner.getTest().log(Status.INFO, "I am in to select Course ");
        wait.until(ExpectedConditions.visibilityOf(list_MyCourses));

        WebElement courseContainer = list_MyCourses;
        List<WebElement> courseLinks = courseContainer.findElements(By.xpath(".//div[contains(@class, 'CourseRoot')]"));

        for (WebElement courseLink : courseLinks) {
            System.out.println("Course Name: " + courseLink.getText());
        }

        if (!courseLinks.isEmpty()) {
            WebElement firstCourse = courseLinks.get(0);
            selectedCourseNameForReport = firstCourse.getText();
            System.out.println("Selected Course For Report is: " + selectedCourseNameForReport);
            TestRunner.getTest().log(Status.INFO, "Selected Course For Report is: " + selectedCourseNameForReport);
            firstCourse.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed : Course Select Successfully");
        } else {
            System.out.println("No courses found");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : No courses found");
            throw new RuntimeException("No Course Found.");
        }
    }

    public void SelectCourseFromReports() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm in to select Course");

        Thread.sleep(2000);
        course_for_report.click();

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        WebElement listDistrict = wait.until(ExpectedConditions.presenceOfElementLocated(
                By.xpath("//ul[@role='listbox']")));

        List<WebElement> optionsDistrict = listDistrict.findElements(By.xpath(".//li"));

        System.out.println("Course List Size: " + optionsDistrict.size());
        System.out.println("Selected course to search: '" + selectedCourseNameForReport + "'");

        boolean courseFound = false;

        for (WebElement district : optionsDistrict) {
            String optionText = district.getText().trim();
            System.out.println("Dropdown option: '" + optionText + "'");

            if (selectedCourseNameForReport.replaceAll("\\s+", " ")
                    .trim()
                    .contains(optionText)) {
                wait.until(ExpectedConditions.elementToBeClickable(district));
                district.click();
                courseFound = true;

                TestRunner.getTest().log(Status.INFO, "Clicked on Course: " + optionText);
                System.out.println("Clicked on Course: " + optionText);
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: Course selected successfully");
                break;
            }
        }

        if (!courseFound) {
            System.out.println("The selected course '" + selectedCourseNameForReport + "' was not found in the dropdown.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Course not found - " + selectedCourseNameForReport);
        }

    }



}
