package pageFactory.ItemAnalysisReports;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Assignmment.CorrectAnswerExecutor_PF;
import pageFactory.Assignmment.TeacherAssignment_PF;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

public class ItemAnalysisRunReportByCourse_PF {
    WebDriverWait wait;
    WebDriver driver;
    Helper helper;
    Actions actions;
    JavascriptExecutor js;

    public ItemAnalysisRunReportByCourse_PF(WebDriver driver) {
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        helper = new Helper();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        actions = new Actions(driver);
    }

    List<String> summaryValues = new ArrayList<>();
    List<String> summaryQuestionIds = new ArrayList<>();

    List<String> SummaryOverallAverageValue = new ArrayList<>();

    public void getQuestionPointsFromSummaryForByCourse() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "");

        System.out.println("I'm into Get Each Question Points From Summary For Verification of Report By Course");
        TestRunner.getTest().log(Status.INFO, "I'm Into Get Each Question Points From Summary For Verification of Report By Course");

        Thread.sleep(2000);


// Locate all <div> elements with class "overAllAverage"
        List<WebElement> divElements = driver.findElements(By.cssSelector("tr.MuiTableRow-root td div.overAllAverage"));

// Loop through each element and collect data
        for (WebElement div : divElements) {
            summaryValues.add(div.getText());  // Store the visible value (like "1", "4", "8")
            summaryQuestionIds.add(div.getAttribute("data-question-id"));  // Store the question ID
        }

// Optional: Print for verification
        for (int i = 0; i < summaryValues.size(); i++) {
            System.out.println("Value: " + summaryValues.get(i) + " | Question ID: " + summaryQuestionIds.get(i));
            TestRunner.getTest().log(Status.INFO, "Value: " + summaryValues.get(i) + " | Question ID: " + summaryQuestionIds.get(i));
        }

    }


    public void getOverAllAverageFromSummaryForByCourse() throws InterruptedException {
        System.out.println("I'm into Get OverAll Average From Summary For Verification of Report By Course");
        TestRunner.getTest().log(Status.INFO, "I'm into Get OverAll Average From Summary For Verification of Report By Course");

        Thread.sleep(2000);

        SummaryOverallAverageValue.clear();

        try {

            // Fetch Summary Table averages safely
            try {
                List<WebElement> overallAverageList = driver.findElements(
                        By.xpath("//td[div[text()='Overall Average']]/following-sibling::td/div")
                );

                if (overallAverageList.isEmpty()) {
                    System.out.println("⚠ No Overall Average values found in Summary table");
                    TestRunner.getTest().log(Status.WARNING, "No Overall Average values found in Summary table");
                } else {
                    for (WebElement div : overallAverageList) {
                        try {
                            String value = div.getText().trim();
                            if (!value.isEmpty()) {
                                SummaryOverallAverageValue.add(value);

                                System.out.println("Overall Average value from summary row: " + value);
                            }
                        } catch (Exception innerEx) {
                            System.out.println("⚠ Error reading value from row: " + innerEx.getMessage());
                        }
                    }
                }

            } catch (Exception ex) {
                System.out.println("⚠ Unable to read Summary table Overall Average values");
                TestRunner.getTest().log(Status.WARNING, "Unable to read Summary table Overall Average values");
            }

            System.out.println("Total Overall Average values stored: " + SummaryOverallAverageValue.size());
            TestRunner.getTest().log(Status.INFO, "Total Overall Average values stored: " + SummaryOverallAverageValue.size());
            TestRunner.getTest().log(Status.PASS, "Completed getting Overall Average values from Summary (with safe handling)");

            System.out.println("=========== FINAL STORED OVERALL AVERAGE VALUES ===========");
            System.out.println("Stored Values: " + SummaryOverallAverageValue);
            System.out.println("============================================================");
            TestRunner.getTest().log(Status.INFO, "Stored Values: " + SummaryOverallAverageValue);


        } catch (Exception e) {
            // FINAL CATCH (never fails test case)
            System.out.println("⚠ Unexpected error in getOverAllAverageFromSummary");
            TestRunner.getTest().log(Status.WARNING, "Unexpected error while getting Overall Average from Summary");
        }

    }

    public void FromLevelSelectClass() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "From Level Select Specific class");
        System.out.println("From Level Select Specific class");

        Thread.sleep(2000);
        WebElement table = driver.findElement(By.xpath("(//div[contains(@class, 'AssignmentSummary')])"));
        List<WebElement> rows = table.findElements(By.xpath(".//tbody/tr"));

        for (WebElement row : rows) {
            try {
                // Extract level name
                WebElement levelCell = row.findElement(By.xpath(".//td[1]"));
                String LevelName = levelCell.getText().trim();

                if (LevelName.isEmpty()) {
                    System.out.println("No Data Found in Level");
                    TestRunner.getTest().log(Status.FAIL, "No Data Found in Level");
                    continue;
                }

                System.out.println("Level Name: " + LevelName);
                TestRunner.getTest().log(Status.INFO, "Level Name : " + LevelName);

                // Check for specific level name ignoring case
                if (LevelName.equalsIgnoreCase("FL Grade 5")) {
                    WebElement iconButton = row.findElement(By.xpath(".//div[@class='titleDistrict notranslate']/following-sibling::*[name()='svg']"));
                    iconButton.click();
                    System.out.println("Clicked on button for FL Grade 5 Successfully");
                    TestRunner.getTest().log(Status.PASS, "Clicked on button for FL Grade 5 Successfully");
                    break; // Exit the loop after clicking
                }

            } catch (NoSuchElementException e) {
                System.out.println("Element not found in row: " + row);
                TestRunner.getTest().log(Status.FAIL, "Element missing in row: " + row);
            }
        }
    }


    public void SelectAssignmentFromLevel() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm Into Select Assignment From Level: " + CorrectAnswerExecutor_PF.assignmentNameForCorrect.get());
        System.out.println("I'm Into Select Assignment From Level" + CorrectAnswerExecutor_PF.assignmentNameForCorrect.get());

        String assignmentNameForCorrect = CorrectAnswerExecutor_PF.assignmentNameForCorrect.get();

        Thread.sleep(3000);

        WebElement table = driver.findElement(By.xpath("(//div[contains(@class, 'AssignmentSummary')])"));
        List<WebElement> rows = table.findElements(By.xpath(".//tbody/tr"));

        for (WebElement row : rows) {
            try {
                // Extract level name
                WebElement levelCell = row.findElement(By.xpath(".//td[1]"));
                String LevelName = levelCell.getText().trim();

                if (LevelName.isEmpty()) {
                    System.out.println("No Data Found in Level");
                    TestRunner.getTest().log(Status.FAIL, "No Data Found in Level");
                    continue;
                }

                System.out.println("Level Name: " + LevelName);
                TestRunner.getTest().log(Status.INFO, "Level Name : " + LevelName);

                // Check for specific level name ignoring case
                if (LevelName.equalsIgnoreCase(assignmentNameForCorrect)) {
                    WebElement iconButton = row.findElement(By.xpath(".//div[@class='titleDistrict notranslate']/following-sibling::*[name()='svg']"));
                    iconButton.click();
                    System.out.println("Clicked on button for Assignment "   + assignmentNameForCorrect  + " Successfully");
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed: Clicked on button for Assignment "   + assignmentNameForCorrect  + " Successfully");
                    break; // Exit the loop after clicking
                }

            } catch (NoSuchElementException e) {
                System.out.println(assignmentNameForCorrect + " not found in row: " + row);
                TestRunner.getTest().log(Status.FAIL, assignmentNameForCorrect + "  missing in row: " + row);
            }
        }
    }


    List<String> valuesFromRunReportByCourse = new ArrayList<>();
    List<String> questionIdsFromRunReportByCourse = new ArrayList<>();
    List<String> overallAverageValueFromRunReportByCourse = new ArrayList<>() ;

    public void getQuestionPointsFromRunReportForByCourse() throws InterruptedException {
        System.out.println("I'm into Get Each Question Points From Run Report For By Course");
        TestRunner.getTest().log(Status.INFO,"I'm into Get Each Question Points From Run Report For By Course");


        Thread.sleep(2000);


        List<WebElement> divElements = driver.findElements(By.cssSelector("tr.MuiTableRow-root td div.overAllAverage"));


        for (WebElement div : divElements) {
            valuesFromRunReportByCourse.add(div.getText());
            questionIdsFromRunReportByCourse.add(div.getAttribute("data-question-id"));
        }

        for (int i = 0; i < valuesFromRunReportByCourse.size(); i++) {
            System.out.println("Value Point From Run Report By Course: " + valuesFromRunReportByCourse.get(i) +
                    " | Question ID From Run report By Course: " + questionIdsFromRunReportByCourse.get(i));

            TestRunner.getTest().log(Status.INFO, "Value Point From Run Report By Course: " + valuesFromRunReportByCourse.get(i) +
                    " | Question ID From Run report By Course: " + questionIdsFromRunReportByCourse.get(i));
        }
    }

    public void getOverAllAverageFromRunReportByCourse() throws InterruptedException {
        System.out.println("I'm into Get OverAll Average From Run Report By Course");
        TestRunner.getTest().log(Status.INFO, "I'm into Get OverAll Average From Run Report By Course");

        // Clear previous values
        overallAverageValueFromRunReportByCourse.clear();

        try {
            // Find all divs in the Overall Average row within the second StudentAssignmentQuestionsWrapper
            List<WebElement> overallAverageElements = driver.findElements(
                    By.xpath("(//div[contains(@class,'StudentAssignmentQuestionsWrapper')])[2]//tr[contains(@data-rbd-draggable-id,'OverAllAverage')]//div[contains(@class,'overAllAverage')]")
            );

            if (overallAverageElements.isEmpty()) {
                System.out.println("⚠ No Overall Average values found in the table");
                TestRunner.getTest().log(Status.WARNING, "No Overall Average values found in the table");
            } else {
                // Store all values as Strings
                for (WebElement el : overallAverageElements) {
                    String value = el.getText().trim();
                    if (!value.isEmpty()) {
                        overallAverageValueFromRunReportByCourse.add(value);
                    }
                }

                // Print all stored values at once
                System.out.println("Stored Overall Average Values: " + overallAverageValueFromRunReportByCourse);
                TestRunner.getTest().log(Status.INFO, "Stored Overall Average Values: " + overallAverageValueFromRunReportByCourse);
            }

        } catch (Exception e) {
            System.out.println("⚠ Unable to get Overall Average values from Run Report: " + e.getMessage());
            TestRunner.getTest().log(Status.WARNING, "Unable to get Overall Average values from Run Report: " + e.getMessage());
        }
    }

    public void compareSummaryAndRunReportDataForReportByCourse() throws InterruptedException {

        System.out.println("I'm into Verify that Points and Scores Match on Run Report By Course");
        TestRunner.getTest().log(Status.INFO, "I'm into verify that Points and Scores Match on Run Report By Course");


        boolean allMatch = true;

        // Compare overall averages
        if (!SummaryOverallAverageValue.equals(overallAverageValueFromRunReportByCourse)) {
            System.out.println("Test Case Failed: Overall average mismatch | Summary: " + SummaryOverallAverageValue +
                    " | Run Report: " + overallAverageValueFromRunReportByCourse);
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Overall average mismatch | Summary: " + SummaryOverallAverageValue +
                    " | Run Report: " + overallAverageValueFromRunReportByCourse );
            allMatch = false;
        } else {
            System.out.println("Test Case Passed: Overall average matched: " + SummaryOverallAverageValue);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Overall average matched: " + overallAverageValueFromRunReportByCourse);
        }


        if (allMatch) {
            System.out.println("All values matched successfully!");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: All values matched successfully!");
        } else {
            System.out.println(" Differences found in comparison.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Differences found in comparison");
        }
    }

}
