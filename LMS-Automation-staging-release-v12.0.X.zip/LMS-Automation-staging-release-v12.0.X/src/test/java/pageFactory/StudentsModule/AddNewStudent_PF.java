package pageFactory.StudentsModule;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.StudentsModule.AddNewStudentSteps;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.NotificationModule.CreateNotificationByTeacher_PF;

import java.awt.*;
import java.time.Duration;
import java.util.List;
import java.util.Random;

import static pageFactory.Gradebook.AssignmentVerification_PF.specificClasses;

public class AddNewStudent_PF {
    WebDriverWait wait;
    WebDriver driver;
    Helper helper;
    JavascriptExecutor js;

    @FindBy(xpath = "//div[@aria-label='Students Module']")
    WebElement link_Student_Module;

    @FindBy(xpath = "//button[normalize-space()='+ Add New']")
    WebElement Button_AddNew;

    @FindBy(xpath = "//input[@id='textField-firstName']")
    WebElement first_name;

    @FindBy(xpath = "//input[@id='textField-lastName']")
    WebElement last_name;

    @FindBy(xpath = "//input[@name='email']")
    WebElement email_address;

    @FindBy(xpath = "//input[@name='phone']")
    WebElement Phone_number;

    @FindBy(xpath = "//input[@name='address']")
    WebElement Home_address;

    @FindBy(xpath = "//input[@name='LocalId']")
    WebElement local_Id;

    @FindBy(xpath = "(//label[normalize-space()='Select District']/parent::div)[2]") // Locate the dropdown
    WebElement dropdown_select;

    @FindBy(xpath = "(//label[normalize-space()='Select School']/parent::div)[2]") // Locate the dropdown
    WebElement dropdown_select_school;

    @FindBy(xpath = "//label[normalize-space()='Select School Year']/parent::div")
    WebElement select_school_year;

    @FindBy(xpath = "//label[normalize-space()='Select Grade']/parent::div")
    WebElement select_grade;

    @FindBy(xpath = "//label[normalize-space()='Select Classes']/parent::div")
    WebElement select_classes;

    @FindBy(xpath = "//label[normalize-space()='Language']/parent::div")
    WebElement select_language;

    @FindBy(xpath = "//button[normalize-space()='Save & Exit']")
    WebElement save_details;

    @FindBy(xpath = "//button[normalize-space()='Cancel']")
    WebElement cancel_btn;

    @FindBy(xpath = "//div[@class='rrt-middle-container']")
    WebElement toastContainer;

    @FindBy(xpath = "//div[@aria-labelledby='simple-tab-2']")
    WebElement panel_Assignments;

    public static String UpdatePhonenumber = "+1 415-555-0132";

    private Random random = new Random();
    public static String randomClassNewStdEmail;
    public static String selectedDistrict;
    public static  String selectedSchool;
    public static String selectedGrade;
    public static String selectedClass;
    public static String passwordValue;
    public static String UpdatedPhone="+1 415-555-0132";

    public static String FirstNameForNewStd;



    public AddNewStudent_PF(WebDriver driver){
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        helper = new Helper();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        js = (JavascriptExecutor) driver;
    }



    public void SideNavBarAndClickOnStudentsModule() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm in checking the side navbar click on Student Module");
        System.out.println("I'm in checking the side navbar");
        Thread.sleep(1000);

        try {
            // First, check if any dialogs are open and wait for them to close
            try {
                List<WebElement> openDialogs = driver.findElements(By.xpath("//div[@role='dialog']"));
                for (WebElement dialog : openDialogs) {
                    if (dialog.isDisplayed()) {
                        System.out.println("Dialog detected, waiting for it to close...");
                        TestRunner.getTest().log(Status.INFO, "Dialog detected, waiting for it to close");
                        wait.until(ExpectedConditions.invisibilityOf(dialog));
                        Thread.sleep(500);
                    }
                }
            } catch (Exception e) {
                // If no dialog found, continue
                System.out.println("No dialog found, proceeding...");
            }

            // Wait for navigation bar to be present
            WebElement navBar = wait.until(ExpectedConditions.presenceOfElementLocated(
                    By.xpath("//div[@class='navigation']")));

            List<WebElement> totalLinks = navBar.findElements(By.tagName("a"));
            System.out.println("Total links found: " + totalLinks.size());

            for (WebElement link : totalLinks) {
                String hrefValue = link.getAttribute("href");
                System.out.println("Link is: " + hrefValue);
            }

            // Wait for Students Module link to be visible and clickable
            WebElement studentModuleLink = wait.until(ExpectedConditions.visibilityOf(link_Student_Module));
            
            if (studentModuleLink.isDisplayed()) {
                // Scroll element into view
                helper.scrollToElement(driver, studentModuleLink);
                ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", studentModuleLink);
                Thread.sleep(500);
                
                // Wait for element to be clickable
                wait.until(ExpectedConditions.elementToBeClickable(studentModuleLink));
                
                // Try to click with multiple strategies
                try {
                    studentModuleLink.click();
                    System.out.println("✅ Students Module clicked successfully (normal click)");
                } catch (ElementClickInterceptedException e) {
                    // If intercepted, use JavaScript click
                    System.out.println("Normal click intercepted, using JavaScript click");
                    ((JavascriptExecutor) driver).executeScript("arguments[0].click();", studentModuleLink);
                    System.out.println("✅ Students Module clicked successfully (JavaScript click)");
                }
                
                TestRunner.getTest().log(Status.PASS, "Testcase Passed: Side Navbar Shows and Clicked on Students Module");
            } else {
                TestRunner.getTest().log(Status.FAIL, "Testcase Failed: Side navbar not shows and not clicked on Student Module");
            }
        } catch (TimeoutException e) {
            TestRunner.getTest().log(Status.FAIL, "Testcase Failed: Timeout waiting for Students Module link - " + e.getMessage());
            System.out.println("Error: Timeout waiting for Students Module link - " + e.getMessage());
        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "Testcase Failed: Error clicking Students Module - " + e.getMessage());
            System.out.println("Error clicking Students Module: " + e.getMessage());
        }
    }


    public void StudentDashboard() throws InterruptedException {
        System.out.println("I'm in Students Module dashboard");
        TestRunner.getTest().log(Status.INFO, "I'm in Students Module dashboard");
        Thread.sleep(1000);

        WebElement breadCrumb = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ol[contains(@class, 'MuiBreadcrumbs')]")));
        System.out.println("BreadCrumb is: " + breadCrumb.getText());
        TestRunner.getTest().log(Status.PASS, "Testcase Passed   :   Students Module dashboard all element visible");


    }

    public void AddNewButton(){
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='+ Add New']")));
        try {
            wait.until(ExpectedConditions.elementToBeClickable(Button_AddNew));
            if (Button_AddNew.isDisplayed() && Button_AddNew.isEnabled()) {
                Button_AddNew.click();
                TestRunner.getTest().log(Status.PASS, "Testcase Passed   :  Add New Student button successfully");
            } else {
                TestRunner.getTest().log(Status.FAIL, "Testcase Failed   :  Add New Student button disabled");
            }
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println("Exception: " + e.getMessage());
            throw new RuntimeException("Add student button disabled");
        }
    }

    public void AddNewStudentInfo() throws InterruptedException{
        TestRunner.startTest( "Fill Student Information for Add New Student ");
        TestRunner.getTest().log(Status.INFO, "Fill New Student Information");
        processStudentInfo();

    }

    public void processStudentInfo() throws InterruptedException {
        enterFirstName();
        enterLastName();
        enterEmail();
//        enterPassword();
        enterConfirmPassword();
//        SelectDistrict();
//        SelectSchool();
        SelectSchoolYear();
        SelectGrade();
        SelectClasses();
//        EnterPhoneNumber();
        SelectLanguage();
        enterPassword();
//        EnterAddress();
//        EnterLocalId();
        SaveInfo();
//        SelectClasses();
    }

    public void enterFirstName() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Enter New Student First Name");

        Thread.sleep(2000);
        first_name.click();
        first_name.clear();
        FirstNameForNewStd = generateStudentInfo("AtmStdFName-");
        first_name.sendKeys(FirstNameForNewStd);
        System.out.println("FirstName entered Successfully: " + FirstNameForNewStd);
        TestRunner.getTest().log(Status.INFO, "New Student First Name is: " + FirstNameForNewStd);
        TestRunner.getTest().log(Status.PASS, "Test Case Passed: New Student First Name successfully");

    }

    public void enterLastName() {
        TestRunner.getTest().log(Status.INFO, "Enter New Student Last Name");
        last_name.click();
        last_name.clear();
        String LastName = generateStudentInfo("AtmStdLName");
        last_name.sendKeys(LastName);
        System.out.println("LastName entered Successfully: " + LastName);
        TestRunner.getTest().log(Status.INFO, "New Student Last Name is: " + LastName);
        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Last Name enter Click successfully");


    }

    public void enterEmail() {
        TestRunner.getTest().log(Status.INFO, "Enter New Student Email");
        email_address.click();
        email_address.clear();
        randomClassNewStdEmail = randomClassNewStdEmail("stdAutomatedstd");
        email_address.sendKeys(randomClassNewStdEmail);
        System.out.println("Email added successfully: " + randomClassNewStdEmail);
        TestRunner.getTest().log(Status.INFO, "New Student Email is: " + randomClassNewStdEmail);
        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Email  enter Click successfully");

    }

    public void enterIncorrectEmail() {
        TestRunner.getTest().log(Status.INFO, "Enter Incorrect  Email");
        email_address.click();
        email_address.clear();
        email_address.sendKeys("invalidEmail");
        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Invalid Email enter Click successfully");
    }

    public void enterExistingEmail(String email) {
        TestRunner.getTest().log(Status.INFO, "Enter Existing Email");

        email_address.click();
        email_address.clear();
        email_address.sendKeys(email);
        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Existing Email enter Click successfully");


    }

    public String randomClassNewStdEmail(String prefix) {
        Random randemail = new Random();
        int randomInt = randemail.nextInt(1000);
        return prefix + randomInt + "@yopmail.com";
    }


    public void enterPassword() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Enter New Student Password");
        Thread.sleep(2000);
        WebElement passwordField = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@name='password']")));

        passwordField.clear();

        Actions actions = new Actions(driver);
        actions.moveToElement(passwordField).click().sendKeys("Fltester@22").perform();

        System.out.println("Password added Successfully");

        actions.sendKeys(Keys.TAB);

        passwordValue = passwordField.getAttribute("value");
        System.out.println("Password field value after input: " + passwordValue);
        TestRunner.getTest().log(Status.INFO, "New Student Password is: " + passwordValue);

        if (!"Fltester@22".equals(passwordValue)) {
            throw new RuntimeException("Password field did not receive the expected value. Actual value: '" + passwordValue + "'");
        }
        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Password enter successfully");
    }

    public void enterConfirmPassword() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Enter New Student Confirm Password");
        Thread.sleep(5000);

        WebElement confirmPasswordField = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@name='confirmPassword']")));

        confirmPasswordField.clear();

        Actions actions = new Actions(driver);
        actions.moveToElement(confirmPasswordField).click().sendKeys("Fltester@22").perform();

        System.out.println("Confirm Password added Successfully");

        String confirmPasswordValue = confirmPasswordField.getAttribute("value");
        System.out.println("Confirm Password field value after input: " + confirmPasswordValue);
        TestRunner.getTest().log(Status.INFO, "New Student Password is: " + confirmPasswordValue);

        if (!"Fltester@22".equals(confirmPasswordValue)) {
            throw new RuntimeException("Confirm Password field did not receive the expected value. Actual value: '" + confirmPasswordValue + "'");
        }
        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Confirm Password enter successfully");

    }

    public void enterConfirmPasswordMisMatch() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Enter New Student Confirm Password Mismatch");
        Thread.sleep(5000);

        WebElement confirmPasswordField = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@name='confirmPassword']")));

        confirmPasswordField.clear();

        Actions actions = new Actions(driver);
        actions.moveToElement(confirmPasswordField).click().sendKeys("Fltester@2").perform();

        System.out.println("Confirm Password added Successfully");

        String confirmPasswordValue = confirmPasswordField.getAttribute("value");
        System.out.println("Confirm Password field value after input: " + confirmPasswordValue);

        TestRunner.getTest().log(Status.INFO, "New Student Password is: " + confirmPasswordValue);
        if (!"Fltester@2".equals(confirmPasswordValue)) {
            throw new RuntimeException("Confirm Password field did not receive the expected value. Actual value: '" + confirmPasswordValue + "'");
        }
        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Mismatch Confirm Password enter Click successfully");

    }

    public void SelectDistrict(){
        TestRunner.getTest().log(Status.INFO, "Select District");

        dropdown_select.click();

        WebElement listDistrict = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[contains(@role, 'listbox')]")));
        List<WebElement> optionsDistrict = listDistrict.findElements(By.xpath(".//li"));

        System.out.println("District List is: " + optionsDistrict.size());

        if (optionsDistrict.isEmpty()) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: No options found in the district dropdown");
            System.out.println("No options found in the district dropdown.");
            throw new RuntimeException("No District Value found in dropdown");

        } else {
            System.out.println("District:");

            for (WebElement district : optionsDistrict) {
                System.out.println(district.getText());
            }
            if (!optionsDistrict.isEmpty()) {
                Random random = new Random();
                int randomCourse = random.nextInt(optionsDistrict.size());
                WebElement selectedOption = optionsDistrict.get(randomCourse);
                selectedDistrict = selectedOption.getText();
                selectedOption.click();
//                selectedDistrict = selectedOption.getText();
                System.out.println("Selected District: " + selectedDistrict);
                TestRunner.getTest().log(Status.INFO, "Selected District is: " + selectedDistrict);
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: District select successfully");
            }
        }

    }
    public void SelectSchool(){
        TestRunner.getTest().log(Status.INFO, "Select School");
        dropdown_select_school.click();
        WebElement listSchools = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[contains(@role, 'listbox')]")));
        List<WebElement> optionsSchools = listSchools.findElements(By.xpath(".//li"));

        System.out.println("Schools List is: " + optionsSchools.size());

        if (optionsSchools.isEmpty()) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: No options found in the Schools dropdown");
            System.out.println("No options found in the Schools dropdown.");
            throw new RuntimeException("No School found in dropdown");

        } else {
            System.out.println("Schools:");

            for (WebElement school : optionsSchools) {
                System.out.println(school.getText());
            }
            if (!optionsSchools.isEmpty()) {
                Random random = new Random();
                int randomCourse = random.nextInt(optionsSchools.size());
                WebElement selectedOption = optionsSchools.get(randomCourse);
                selectedSchool = selectedOption.getText();
                selectedOption.click();
//                selectedSchool = selectedOption.getText();
                System.out.println("Selected School: " + selectedSchool);
                TestRunner.getTest().log(Status.INFO, "Selected School is: " + selectedSchool);
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: School select successfully");

            }
        }
    }
    public void SelectSchoolYear() {
        TestRunner.getTest().log(Status.INFO, "Selecting School year");
        select_school_year.click();
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].scrollIntoView(true);", select_school_year);

        List<WebElement> options = driver.findElements(By.xpath("//ul[contains(@role, 'listbox')]//li"));

        if (options.isEmpty()) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: No options found in the Schools year dropdown");
            System.out.println("No options found in the dropdown.");
            return;
        }

        boolean optionFound = false;
        for (WebElement option : options) {
            String title = option.getAttribute("title");
            if (title != null && title.contains("Active")) {
                option.click();
                System.out.println("Selected option for School Year: " + title);
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: School Year selected successfully");
                optionFound = true;
                break;
            }
        }

        if (!optionFound) {
            System.out.println("No 'Active' option found in the dropdown.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: No 'Active' option found in the dropdown.");

        }
    }

    public void SelectGrade(){
        TestRunner.getTest().log(Status.INFO, "Selecting Grade ");
        select_grade.click();
        WebElement listGrade = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[contains(@role, 'listbox')]")));
        List<WebElement> optionsGrade = listGrade.findElements(By.xpath(".//li"));

        System.out.println("Grades List is: " + optionsGrade.size());

        if (optionsGrade.isEmpty()) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: No options found in the Grades dropdown");
            System.out.println("No options found in the Grades dropdown.");
            throw new RuntimeException("No Grade found in dropdown");

        } else {
            System.out.println("Grades:");

            for (WebElement grades : optionsGrade) {
                System.out.println(grades.getText());
            }
            if (!optionsGrade.isEmpty()) {
                Random random = new Random();
                int randomCourse = random.nextInt(optionsGrade.size());
                WebElement selectedOption = optionsGrade.get(randomCourse);
                selectedGrade = selectedOption.getText();
                selectedOption.click();
//                selectedGrade = selectedOption.getText();
                System.out.println("Selected Grade: " + selectedGrade);
                TestRunner.getTest().log(Status.INFO, "Selected Grade is: " + selectedGrade);
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: Grade select successfully");
            }
        }
    }

    public void SelectClasses() {
        TestRunner.getTest().log(Status.INFO, "Selecting a random class from the dropdown");

        select_classes.click(); // Click to open the dropdown

        // Click to open the dropdown
        WebElement listClasses = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[@role='listbox']")));
        List<WebElement> optionsClasses = listClasses.findElements(By.xpath(".//li"));

        int classCount = optionsClasses.size();
        System.out.println("Classes List size: " + classCount);
        TestRunner.getTest().log(Status.INFO, "Number of classes available: " + classCount);

        if (classCount == 0) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: No options found in the Classes dropdown");
            System.out.println("No options found in the Classes dropdown.");
            throw new RuntimeException("No Classes found in dropdown");

        } else {
            System.out.println("Classes available:");
            boolean classFound = false;

            for (WebElement option : optionsClasses) {
                String className = option.getText();
                System.out.println(className);

                if (className.equals(specificClasses)) {
                    option.click();  // Select the class by clicking on it
                    System.out.println("Selected Class: " + specificClasses);
                    TestRunner.getTest().log(Status.INFO, "Selected Class: " + specificClasses);
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed: Class selected successfully");
                    classFound = true;
                    break;
                }
            }

            if (!classFound) {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Specific class not found in the Classes dropdown");
                throw new RuntimeException("Specific class not found in dropdown: " + specificClasses);
            }
        }

    }

    public void EnterPhoneNumber(){
        TestRunner.getTest().log(Status.INFO, "Enter New Student Phone Number");
        Phone_number.click();
        ((JavascriptExecutor) driver).executeScript("arguments[0].value='';", Phone_number);

//        String randomPhoneNumber = generateRandomPhoneNumber();

        Phone_number.sendKeys(UpdatedPhone);
        System.out.println("Phone Number enter Successfully " + UpdatedPhone);

        TestRunner.getTest().log(Status.INFO, "Enter Phone number is: " + UpdatedPhone);

        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Phone Number Enter successfully");

    }

    public void EnterInvalidPhoneNumber(){
        TestRunner.getTest().log(Status.INFO, "Enter New Student InValid Phone Number");
        Phone_number.click();
        ((JavascriptExecutor) driver).executeScript("arguments[0].value='';", Phone_number);

        Phone_number.sendKeys("InvalidPhone123");
        System.out.println("Phone Number enter Successfully ");
        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Invalid Phone Number Enter successfully");

    }
    public void SelectLanguage() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Select New Student Language");
        select_language.click();
        Thread.sleep(2000);

        helper.scrollToElement(driver, select_language);

        List<WebElement> options = driver.findElements(By.xpath("//ul[contains(@role, 'listbox')]//li"));
        if (options.isEmpty()) {
            System.out.println("No options found in the dropdown.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: No options found in the dropdown.");
            return;
        }
        WebElement randomOption = options.get(random.nextInt(options.size()));
        String selectedLanguageText = randomOption.getText().trim();
        js.executeScript("arguments[0].scrollIntoView(true);", randomOption);
        randomOption.click();
        System.out.println("Language Select Successfully: " + selectedLanguageText);

        TestRunner.getTest().log(Status.INFO, "Language Select: " + selectedLanguageText);
        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Language select successfully - " + selectedLanguageText);

    }


    public void EnterAddress(){
        TestRunner.getTest().log(Status.INFO, "Enter New Student Address");
        Home_address.click();
        ((JavascriptExecutor) driver).executeScript("arguments[0].value='';", Home_address);
        String randomAddress = generateRandomAddress();
        Home_address.sendKeys(randomAddress);
        System.out.println("Address enter Successfully " + randomAddress);
        TestRunner.getTest().log(Status.INFO, "Address enter " + randomAddress);
        TestRunner.getTest().log(Status.PASS, "Test Case Passed:  Address Enter successfully");

    }

    public void EnterLocalId(){
        TestRunner.getTest().log(Status.INFO, "Enter New Student LocalID");
        local_Id.click();
        ((JavascriptExecutor) driver).executeScript("arguments[0].value='';", local_Id);
        String Local_Id = generateStudentInfo("ID-");
        local_Id.sendKeys(Local_Id);
        System.out.println("Local ID " + Local_Id);
        TestRunner.getTest().log(Status.INFO, "Local ID  " + Local_Id);
        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Local ID Enter successfully");


    }

    public void EnterInvalidLocalId(){
        TestRunner.getTest().log(Status.INFO, "Enter New Student InValid LocalID");
        local_Id.click();
        ((JavascriptExecutor) driver).executeScript("arguments[0].value='';", local_Id);
        local_Id.sendKeys("InvalidID!@#");
        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Invalid Local ID Enter successfully");

    }

    public void SaveInfo() throws InterruptedException{
        save_details.click();
        System.out.println("New Student Information Save Successfully ");
        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Save button clicked successfully");

    }

    public void click_cancel_btn() throws InterruptedException {
        Thread.sleep(5000);
        cancel_btn.click();
        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Cancel button clicked successfully");


    }
    public String generateRandomAddress() {
        Random random = new Random();

        // Random street number
        int streetNumber = random.nextInt(9000) + 100; // 100 to 9999

        // Random street name
        String[] streetNames = {"Main St", "Elm St", "Maple Ave", "Oak Dr", "Pine Ln", "Cedar Blvd", "Birch Ct"};
        String streetName = streetNames[random.nextInt(streetNames.length)];

        // Random city
        String[] cities = {"Springfield", "Riverside", "Greenville", "Centerville", "Fairview"};
        String city = cities[random.nextInt(cities.length)];

        // Random state
        String[] states = {"NY", "CA", "TX", "FL", "IL"};
        String state = states[random.nextInt(states.length)];

        // Random zip code
        int zipCode = random.nextInt(90000) + 10000; // 10000 to 99999

        // Format the address
        return String.format("%d %s, %s, %s %05d", streetNumber, streetName, city, state, zipCode);
    }

    public String generateRandomPhoneNumber() {
        String characters = "0123456789";
        StringBuilder randomTitle = new StringBuilder();
        Random random = new Random();
        int length = 11;
        for (int i = 0; i < length; i++) {
            randomTitle.append(characters.charAt(random.nextInt(characters.length())));
        }
        return randomTitle.toString();
    }

    public String generateRandomPassword(String prefix) {
        String characters = "ABCDEFGHIHKLMNOPQRSTUVWXYZ0123456789";
        StringBuilder randomPassword = new StringBuilder();
        Random random = new Random();
        int length = 8; // Length of the random password

        randomPassword.append(prefix);
        for (int i = 0; i < length; i++) {
            randomPassword.append(characters.charAt(random.nextInt(characters.length())));
        }

        return randomPassword.toString();
    }

    public String generateStudentInfo(String prefix) {
        String characters = "abcdefghijklmnopqrstuvwxyz";
        StringBuilder randomTitle = new StringBuilder();
        Random random = new Random();
        int length = 4;
        randomTitle.append(prefix);
        for (int i = 0; i < length; i++) {
            randomTitle.append(characters.charAt(random.nextInt(characters.length())));
        }
        return randomTitle.toString();
    }

    // for new Student Login
    public void SideNavbarAndClickOnDifferentModules() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm in checking the side navbar For New Student");
        System.out.println("I'm in checking the side navbar");
        Thread.sleep(3000);

        WebElement navBar = driver.findElement(By.xpath("//div[@class='navigation']"));

        List<WebElement> totalLinks = navBar.findElements(By.tagName("a"));

        for (WebElement link : totalLinks) {
            String hrefValue = link.getAttribute("href");
            System.out.println("Link is: " + hrefValue);
        }
        TestRunner.getTest().log(Status.PASS, "Test Case Password: Dashboard is visible and Load for new Student Successfully");

        TestRunner.getTest().log(Status.INFO, "I'm in to CLick on Courses from Side Navbar");
//        clickOnCourses();
    }

    // click on Courses
    public void clickOnCourses() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm into Click on Courses from side Navbar");
        System.out.println("I'm into Click on Courses from side Navbar");
        Thread.sleep(1000);

        WebElement stdCourse= driver.findElement(By.xpath("//div[@aria-label='Student Courses']"));

        if (stdCourse.isDisplayed()) {

            stdCourse.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Courses Click Successfully");
        }else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Passed: Courses Button not Found");
        }

        WebElement dashboard= driver.findElement(By.xpath("//span[normalize-space()='Dashboard']"));
        if (dashboard.isDisplayed()){
            dashboard.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Dashboard Click Successfully");
        }else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Passed: Dashboard Button not Found");
        }

    }

    public void VerifyNoAssignmentOnMyAssignments() throws InterruptedException {
        if (!panel_Assignments.isDisplayed()) {
            throw new NoSuchElementException("Assignments panel is not displayed");
        }

        WebElement panelTabOpen = driver.findElement(By.xpath("//div[@aria-labelledby='simple-tab-2']"));
        wait.until(ExpectedConditions.visibilityOf(panelTabOpen));
        Thread.sleep(2000);
        List<WebElement> totalAssignments = panel_Assignments.findElements(By.xpath(".//div[contains(@class, 'MuiGrid-container')]"));
        System.out.println("Total Assignments: " + totalAssignments.size());

        TestRunner.getTest().log(Status.INFO, "I'm into Verify that for InActive Student there is no Assignment");
        System.out.println("I'm into Verify that for InActive Student there is no Assignment");
        Thread.sleep(1000);

        if (totalAssignments.size() == 0) {
            // Check if the "Assignments not found!" message is displayed
            try {
                WebElement noAssignmentsMessage = driver.findElement(By.xpath("//div[contains(text(),'Assignments not found!')]"));

                if (noAssignmentsMessage.isDisplayed()) {
                    System.out.println(" For Inactive Student Assignments not found message is displayed.");
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed: For Inactive Student 'Assignments not found!' message is displayed.");
                } else {
                    System.out.println("'Assignments not found!' message is not displayed.");
                    TestRunner.getTest().log(Status.FAIL, "Test Case Failed: For Inactive Student 'Assignments not found!' message is not displayed.");
                    throw new RuntimeException("Test Case Failed: For Inactive Student 'Assignments not found!' message not found.");
                }
            } catch (NoSuchElementException e) {
                System.out.println("'Assignments not found!' message is not present.");
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: 'Assignments not found!' message is not present.");
                throw new RuntimeException("Test Case Failed: 'Assignments not found!' message not found.");
            }
        } else {
            System.out.println("Total assignments found: " + totalAssignments.size());
            TestRunner.getTest().log(Status.INFO, "Total assignments found: " + totalAssignments.size());
        }

    }

    public void VerifyNoCourseFoundOnMyCourses() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm into Verify that for InActive Student there is no Course in My Courses");
        System.out.println("I'm into Verify that for InActive Student there is no Course in My Courses");
        Thread.sleep(1000);

        WebElement my_courses = driver.findElement(By.xpath("(//div[@class='ScrollbarsCustom-Content'])[2]"));

        if (!my_courses.isDisplayed()) {
            throw new NoSuchElementException("My Courses panel is not displayed");
        } else {
            System.out.println("My Courses panel is displayed.");
            TestRunner.getTest().log(Status.INFO, "My Courses panel is displayed.");

            // Check if "Course not found!" message is present
            try {
                WebElement courseNotFoundMessage = my_courses.findElement(By.xpath(".//div[contains(text(),'Course not found!')]"));

                if (courseNotFoundMessage.isDisplayed()) {
                    System.out.println("For inactive Student Course not found message is displayed.");
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed: For Inactive Student 'Course not found!' message is displayed.");
                }
            } catch (NoSuchElementException e) {
                System.out.println("'Course not found!' message is not present, courses are available.");
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: For Inactive Student Courses must not available. But now courses are available.");
                throw new RuntimeException("Test Case Failed: For Inactive Student Courses must not available. But Now Courses are Available");
            }
        }

    }
}
