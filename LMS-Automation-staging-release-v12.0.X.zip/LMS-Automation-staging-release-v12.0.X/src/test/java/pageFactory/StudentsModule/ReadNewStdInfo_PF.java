package pageFactory.StudentsModule;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.StudentsModule.AddNewStudentSteps;
import StepDefinitions.TestRunner;
import apiHandler.GetAPIHandler;
import com.aventstack.extentreports.Status;
import io.cucumber.java.sl.In;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Assignmment.CorrectAnswerExecutor_PF;
import pageFactory.Assignmment.StudentExecutor_PF;
import pageFactory.Filters_PF;

import java.awt.*;
import java.beans.IntrospectionException;
import java.time.Duration;
import java.util.*;
import java.util.List;

import static pageFactory.NotificationModule.CreateNotificationByTeacher_PF.specificClasses;
import static pageFactory.StudentsModule.AddNewStudent_PF.*;

public class ReadNewStdInfo_PF {
    WebDriverWait wait;
    WebDriver driver;
    Helper helper;
    AddNewStudent_PF addNewStudentPf;

    StudentExecutor_PF studentExecutor;
    CorrectAnswerExecutor_PF correctAnswerExecutorPf;
    GetAPIHandler getAPIHandler;

    @FindBy(xpath = "//div[@class='left-panel']")
    WebElement left_Panel;

    @FindBy(xpath = "//label[normalize-space()='Select District']/parent::div") // Locate the dropdown
    WebElement dropdown_select_district;

    @FindBy(xpath = "//label[normalize-space()='Select School']/parent::div") // Locate the dropdown
    WebElement dropdown_select_school;

    @FindBy(xpath = "//label[normalize-space()='Select Teachers']/parent::div") // Locate the dropdown
    WebElement dropdown_select_teacher;

    @FindBy(xpath = "//label[contains(text(),'Select Classes')]/parent::div")
    WebElement edit_select_classes;


    @FindBy(xpath = "//h6[normalize-space()='Grades']/parent::div")
    WebElement select_grade;

    @FindBy(xpath = "//button[normalize-space()='Apply Filters']")
    WebElement apply_filter;

    @FindBy(xpath = "(//div[contains(@class, 'studentDashboardRightPanel')]/parent::div)")
    WebElement std_table;

    public static String selectedTeacher;

    Filters_PF filtersPF;

    @FindBy(xpath = "//input[@id='textField-firstName']")
    WebElement first_name;

    @FindBy(xpath = "//input[@id='textField-lastName']")
    WebElement last_name;

    @FindBy(xpath = "//input[@name='email']")
    WebElement email;

    @FindBy(xpath = "//input[@name='phone']")
    WebElement edt_Phone_number;

    @FindBy(xpath = "//input[@name='address']")
    WebElement edt_Home_address;

    @FindBy(xpath = "//input[@name='LocalId']")
    WebElement edt_local_Id;

    @FindBy(xpath = "//label[normalize-space()='Language']/parent::div")
    WebElement edt_language;

    @FindBy(xpath = "(//label[normalize-space()='Select District']/parent::div)[2]")
    WebElement district_select;

    @FindBy(xpath = "//label[normalize-space()='Select Grade']/parent::div")
    WebElement edt_select_grade;

    @FindBy(xpath = "(//label[normalize-space()='Select School']/parent::div)[2]") // Locate the dropdown
    WebElement edt_select_school;

//    @FindBy(xpath = "//label[normalize-space()='Select Classes']/parent::div")
//    WebElement edt_classes;

    @FindBy(xpath = "//label[normalize-space()='Select School Year']/parent::div")
    WebElement edt_school_year;

    @FindBy(xpath = "//button[normalize-space()='Update']")
    WebElement btn_update;
    @FindBy(xpath = "//button[normalize-space()='Account Settings']")
    WebElement Account_btn;
    @FindBy(xpath = "//button[contains(text(),'Classes')]")
    WebElement classes_btn;
    @FindBy(xpath = "//label[text()='Filter Status']/following-sibling::div//div[@role='button' or @role='combobox']")
    WebElement Status_filter;

    @FindBy(xpath = "//div[@class='rrt-middle-container']")
    WebElement toastContainer;


    private Random random = new Random();
    public static String updatedEmail;
    public static String updatedName;
    public static String UpdatedPasswordValue;
    public static String UpdatenewPhone = "+1 (415) 555-0132";

    public ReadNewStdInfo_PF(WebDriver driver) {
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        helper = new Helper();
        addNewStudentPf = new AddNewStudent_PF(driver);
        filtersPF = new Filters_PF(driver);
        studentExecutor = new StudentExecutor_PF(driver);
        correctAnswerExecutorPf = new CorrectAnswerExecutor_PF(driver);
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
    }

    public void fill_Info() throws InterruptedException {
        TestRunner.startTest(" Filters In student Dashboard");
        TestRunner.getTest().log(Status.INFO, "I'm To fill Filters Information On Student Dashboard");

        Thread.sleep(100);
        left_Panel.isDisplayed();

        filtersPF.select_District();
        filtersPF.select_School(selectedSchool);
//        filtersPF.select_teacher();
        filtersPF.select_Classes(specificClasses);
        filtersPF.select_Grades();
    }

    public void fill_Infoafteredit() throws InterruptedException {
        TestRunner.startTest(" Filters In student Dashboard");
        TestRunner.getTest().log(Status.INFO, "I'm To fill Filters Information On Student Dashboard");

        Thread.sleep(100);
        left_Panel.isDisplayed();

        filtersPF.select_District();
        filtersPF.select_School(selectedSchool);
//        filtersPF.select_teacher();
        filtersPF.afteredit_select_Classes(specificClasses);
        filtersPF.select_Grades();
    }

    public void apply_btn() {
//        apply_filter.click();
//        TestRunner.getTest().log(Status.PASS, "Testcase Passed   :   Filter Button Clicked Successfully");


        TestRunner.getTest().log(Status.INFO, "Attempting to click Apply Filters button");
        System.out.println("Attempting to click Apply Filters button");

        try {
            // Wait for any dialog to disappear first
            try {
                WebElement dialog = driver.findElement(By.xpath("//div[@role='dialog' and contains(@class, 'MuiDialog-paper')]"));
                wait.until(ExpectedConditions.invisibilityOf(dialog));
                Thread.sleep(500); // Small delay after dialog disappears
            } catch (NoSuchElementException e) {
                // Dialog doesn't exist, continue
            } catch (Exception e) {
                // Dialog might be in different state, continue anyway
            }

            // Wait for the button to be visible and clickable
            wait.until(ExpectedConditions.visibilityOf(apply_filter));
            wait.until(ExpectedConditions.elementToBeClickable(apply_filter));

            // Scroll the element into view
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({behavior: 'smooth', block: 'center'});", apply_filter);
            Thread.sleep(500);

            // Try regular click first
            try {
                apply_filter.click();
                TestRunner.getTest().log(Status.PASS, "Testcase Passed: Filter Button Clicked Successfully");
                System.out.println("Filter Button Clicked Successfully");
            } catch (ElementClickInterceptedException e) {
                // If regular click fails, use JavaScript click
                System.out.println("Regular click intercepted, trying JavaScript click");
                ((JavascriptExecutor) driver).executeScript("arguments[0].click();", apply_filter);
                TestRunner.getTest().log(Status.PASS, "Testcase Passed: Filter Button Clicked Successfully (using JavaScript)");
                System.out.println("Filter Button Clicked Successfully (using JavaScript)");
            }

        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "Testcase Failed: Unable to click Apply Filters button - ");
            System.out.println("Testcase Failed: Unable to click Apply Filters button - ");
            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
        }
    }

    public void showsStudentIntoTable() throws InterruptedException {
        if (!std_table.isDisplayed()) {
            System.out.println("Student table is not displayed.");
            TestRunner.getTest().log(Status.FAIL, "Testcase Failed   :  Student table is not displayed.");

            return;
        }

        List<WebElement> rows = std_table.findElements(By.xpath(".//tbody/tr"));

        if (!rows.isEmpty()) {
            System.out.println("Students found in the table:");
            TestRunner.getTest().log(Status.INFO, "Students found in the table in Student Dashboard");

            for (WebElement row : rows) {
                try {
                    // Locate the 3rd cell in the current row
                    WebElement studentEmailElement = row.findElement(By.xpath(".//td[contains(@class, 'MuiTableCell')][3]"));
                    String std_email = studentEmailElement.getText();
                    System.out.println("Student Email: " + std_email);
                } catch (StaleElementReferenceException e) {
                    System.out.println("Encountered stale element reference exception. Skipping row...");
                }
            }

        } else {
            System.out.println("No classes found in the table.");
        }
    }

    public void search_student_afterEdit() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Search Newly Created Student in Search Box");

        Thread.sleep(1000);

        try {
            // Wait for search box to be visible and clickable
            WebElement searchBox = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder='Search by Name or Email']")));
            wait.until(ExpectedConditions.elementToBeClickable(searchBox));

            if (searchBox.isDisplayed()) {
                // Scroll the element into view
                ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({behavior: 'smooth', block: 'center'});", searchBox);
                Thread.sleep(500);

                // Try to click on the search box with fallback to JavaScript click
                try {
                    searchBox.click();
                } catch (ElementClickInterceptedException e) {
                    System.out.println("Regular click intercepted, using JavaScript click");
                    ((JavascriptExecutor) driver).executeScript("arguments[0].click();", searchBox);
                }

                Thread.sleep(300);

                // Clear the search box using multiple strategies
                try {
                    // Strategy 1: Select all and delete
                    Actions actions = new Actions(driver);
                    actions.keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).perform();
                    Thread.sleep(200);
                    actions.sendKeys(Keys.DELETE).perform();
                } catch (Exception e) {
                    // Strategy 2: Use clear() method
                    try {
                        searchBox.clear();
                    } catch (Exception e2) {
                        // Strategy 3: JavaScript clear
                        ((JavascriptExecutor) driver).executeScript("arguments[0].value = '';", searchBox);
                    }
                }

                Thread.sleep(500);

                // Enter the email
                System.out.println("Search by Student Email: " + updatedEmail);
                searchBox.sendKeys(updatedEmail);
                TestRunner.getTest().log(Status.INFO, "email of student that we are searching: " + updatedEmail);
                System.out.println("Search box is displayed and clicked.");
                TestRunner.getTest().log(Status.PASS, "Testcase Passed   :   Search Student By Email Successfully");

            } else {
                System.out.println("Search box is not displayed.");
                TestRunner.getTest().log(Status.FAIL, "Testcase Failed   : Search box is not displayed.");
                helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());

            }
        } catch (Exception e) {
            System.out.println("Search box is not available: ");
            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
            TestRunner.getTest().log(Status.FAIL, "Testcase Failed: Error searching for student - " );

        }
    }

    public void search_student() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Search Newly Created Student in Search Box");

        Thread.sleep(1000);

        try {
            // Wait for search box to be visible and clickable
            WebElement searchBox = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder='Search by Name or Email']")));
            wait.until(ExpectedConditions.elementToBeClickable(searchBox));

            if (searchBox.isDisplayed()) {
                // Scroll the element into view
                ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({behavior: 'smooth', block: 'center'});", searchBox);
                Thread.sleep(500);

                // Try to click on the search box with fallback to JavaScript click
                try {
                    searchBox.click();
                } catch (ElementClickInterceptedException e) {
                    System.out.println("Regular click intercepted, using JavaScript click");
                    ((JavascriptExecutor) driver).executeScript("arguments[0].click();", searchBox);
                }

                Thread.sleep(500);

                // Clear the search box if needed
                try {
                    String currentValue = searchBox.getAttribute("value");
                    if (currentValue != null && !currentValue.isEmpty()) {
                        Actions actions = new Actions(driver);
                        actions.keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).perform();
                        Thread.sleep(200);
                        actions.sendKeys(Keys.DELETE).perform();
                    }
                } catch (Exception e) {
                    // If clearing fails, try JavaScript clear
                    ((JavascriptExecutor) driver).executeScript("arguments[0].value = '';", searchBox);
                }

                Thread.sleep(500);

                // Enter the email
                System.out.println("Search by Student Email: " + randomClassNewStdEmail);
                searchBox.sendKeys(randomClassNewStdEmail);
                TestRunner.getTest().log(Status.INFO, "email of student that we are searching: " + randomClassNewStdEmail);
                System.out.println("Search box is displayed and clicked.");
                TestRunner.getTest().log(Status.PASS, "Testcase Passed   :   Search Student By Email Successfully");

            } else {
                System.out.println("Search box is not displayed.");
                TestRunner.getTest().log(Status.FAIL, "Testcase Failed   : Search box is not displayed.");
                throw new RuntimeException("Search Box did not Display");

            }
        } catch (Exception e) {
            System.out.println("Search box is not available: " + e.getMessage());
            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
            TestRunner.getTest().log(Status.FAIL, "Testcase Failed: Error searching for student - " + e.getMessage());
        }
    }

    public void search_Usage_student() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Search Newly Created Student in Search Box");

        Thread.sleep(1000);

        try {
            WebElement searchBox = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder='Search Titles']")));

            if (searchBox.isDisplayed()) {
                // Click on the search box
                searchBox.click();
                Thread.sleep(2000);
                System.out.println("Search by Student Email: " + updatedEmail);
                searchBox.sendKeys(updatedEmail);
                TestRunner.getTest().log(Status.INFO, "email of student that we are searching: " + updatedEmail);
                System.out.println("Search box is displayed and clicked.");
                TestRunner.getTest().log(Status.PASS, "Testcase Passed   :   Search Student By Email Successfully");

            } else {
                System.out.println("Search box is not displayed.");
                TestRunner.getTest().log(Status.FAIL, "Testcase Failed   : Search box is not displayed.");
                throw new RuntimeException("Search Box did not Display");

            }
        } catch (Exception e) {
            System.out.println("Search box is not available: " + e.getMessage());
            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());

        }
    }

    public void ReadStdInfo() throws InterruptedException {

        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class, 'studentDashboardRightPanel')]//tbody")));

        List<WebElement> rows = std_table.findElements(By.xpath(".//tbody/tr"));

        if (!std_table.isDisplayed()) {
            System.out.println("Student table is not displayed.");
            TestRunner.getTest().log(Status.FAIL, "Testcase Failed   : New Student Not Found By Name or Email.");
            throw new RuntimeException("No students found in the table");
        }

        if (!rows.isEmpty()) {
            System.out.println("Students found in the table:");
            for (WebElement row : rows) {
                checkEmailInRow(row);
            }
            TestRunner.getTest().log(Status.PASS, "Testcase Passed   : Students found in the table.");

        }
//        else {
//            System.out.println("No students found in the table.");
//            TestRunner.getTest().log(Status.FAIL, "Testcase Failed   : No students found in the table..");
//            throw new RuntimeException("No students found in the table");
//
//        }
    }

    public void ReadStdInfoAfterEdit() throws InterruptedException {

        Thread.sleep(3000);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class, 'studentDashboardRightPanel')]//tbody")));

        List<WebElement> rows = std_table.findElements(By.xpath(".//tbody/tr"));

        if (!std_table.isDisplayed()) {
            System.out.println("Student table is not displayed.");
            TestRunner.getTest().log(Status.FAIL, "Testcase Failed   : New Student Not Found By Name or Email.");
            throw new RuntimeException("No students found in the table");
        }

        if (!rows.isEmpty()) {
            System.out.println("Students found in the table:");
            for (WebElement row : rows) {
                checkEmailInRowAfterEdit(row);
            }
            TestRunner.getTest().log(Status.PASS, "Testcase Passed   : Students found in the table.");

        }
//        else {
//            System.out.println("No students found in the table.");
//            TestRunner.getTest().log(Status.FAIL, "Testcase Failed   : No students found in the table..");
//            throw new RuntimeException("No students found in the table");
//
//        }
    }

    private void checkEmailInRowAfterEdit(WebElement row) throws InterruptedException {
        Thread.sleep(3000);
        try {
            WebElement studentEmailElement = row.findElement(By.xpath(".//td[contains(@class, 'MuiTableCell')][3]"));
            String std_email = studentEmailElement.getText();
            System.out.println("Student Email: " + std_email);
            if (std_email.equals(updatedEmail)) {
                System.out.println("The email matches the given random email. Student exists.");
                TestRunner.getTest().log(Status.INFO, "Student with Email search: " + updatedEmail);
                TestRunner.getTest().log(Status.PASS, "Testcase Passed   : Student search Successfully.");

            }
//            else {
//                TestRunner.getTest().log(Status.FAIL, "Testcase Failed   : The email does not match in table. Student does not exist.");
//            }
        } catch (StaleElementReferenceException e) {
            System.out.println("Encountered stale element reference exception. Skipping row...");
        }
    }


    private void checkEmailInRow(WebElement row) {
        try {
            WebElement studentEmailElement = row.findElement(By.xpath(".//td[contains(@class, 'MuiTableCell')][3]"));
            String std_email = studentEmailElement.getText();
            System.out.println("Student Email: " + std_email);
            if (std_email.equals(randomClassNewStdEmail)) {
                System.out.println("The email matches the given random email. Student exists.");
                TestRunner.getTest().log(Status.INFO, "Student with Email search: " + randomClassNewStdEmail);
                TestRunner.getTest().log(Status.PASS, "Testcase Passed   : Student search Successfully.");

            }
//            else {
//                TestRunner.getTest().log(Status.FAIL, "Testcase Failed   : The email does not match in table. Student does not exist.");
//            }
        } catch (StaleElementReferenceException e) {
            System.out.println("Encountered stale element reference exception. Skipping row...");
        }
    }

    public void click_edit_button() throws InterruptedException {
        Thread.sleep(500);

        WebElement dots_click = driver.findElement(By.xpath("//button[@aria-label='DropDownButtom']"));
        dots_click.click();
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//ul[@role='menu']//li")));

        WebElement edit_btn = driver.findElement(By.xpath("//span[normalize-space()='View / Edit']"));
        edit_btn.click();

        TestRunner.getTest().log(Status.PASS, "Testcase Passed   : Edit button click successfully.");


    }

    public void edit_std_info() throws InterruptedException {

        TestRunner.startTest(" Check Fill and validate new student Info");
        TestRunner.getTest().log(Status.INFO, "Edit Student Information: ");

        Thread.sleep(500);
        System.out.println("I'm in edit student Information Screen");
        edit_firstName();
        edit_lastName();
        edit_email();
//        edit_district();
//        edit_school();
//        Edit_School_Year();
        edit_grade();
        edit_classes();
        edit_Language();
//        edit_phone_number();
//        edit_Address();
//        edit_localId();
        //        logger.info("Test Case Passed  :  Classes  Edit successfully");
    }

    public void edit_firstName() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Edit Student First Name");

        String oldName = first_name.getAttribute("value");
        System.out.println("Old Name: " + oldName);
        Actions actions = new Actions(driver);
        first_name.click();

        for (int i = 0; i < oldName.length(); i++) {
            actions.sendKeys(Keys.BACK_SPACE).perform();
        }

        String NewFirstName = generateStudentInfo("EditNewStu-");
        first_name.sendKeys(NewFirstName);

        updatedName = first_name.getAttribute("value");
        System.out.println("Updated First Name: " + updatedName);

        if (!oldName.equals(updatedName)) {
            System.out.println("The First name was successfully updated.");
            TestRunner.getTest().log(Status.INFO, "Updated First Name is: " + updatedName);
            TestRunner.getTest().log(Status.INFO, "First name changed from '" + oldName + "' to '" + updatedName + "'.");

            TestRunner.getTest().log(Status.PASS, "Test Case Passed: First Name  Edit successfully");


        } else {
            System.out.println("The First name was not changed.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: The First name was not changed");
        }
    }

    public void edit_lastName() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Edit Student Last Name");

        String lastOldName = last_name.getAttribute("value");
        System.out.println("Old Last Name is: " + lastOldName);

        Actions actions = new Actions(driver);

        last_name.click();
        for (int i = 0; i < lastOldName.length(); i++) {
            actions.sendKeys(Keys.BACK_SPACE).perform();
        }

        String Lastname = generateStudentInfo("Last-");
        last_name.sendKeys(Lastname);

        String updatedLastname = last_name.getAttribute("value");
        System.out.println("Updated Last Name is: " + updatedLastname);

        if ((!lastOldName.equals(updatedLastname))) {
            System.out.println("Last name was changed successfully");
            TestRunner.getTest().log(Status.INFO, "Last Name changed from '" + lastOldName + "' to '" + updatedLastname + "'.");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Last Name  Edit successfully");

        } else {
            System.out.println("The Last name was not changed.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: The Last name was not changed");
        }

    }

    public void edit_email() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Edit Student Email");

        String oldEmail = email.getAttribute("value");
        System.out.println("Old Email is: " + oldEmail);
        Actions actions = new Actions(driver);
        email.click();

        for (int i = 0; i < oldEmail.length(); i++) {
            actions.sendKeys(Keys.BACK_SPACE).perform();
        }

        String newEmail = randomClassNewStdEmail("editStdAutomatedStd");
        email.sendKeys(newEmail);

        updatedEmail = email.getAttribute("value");
        System.out.println("Updated Email is: " + updatedEmail);

        if (!oldEmail.equals(updatedEmail)) {
            System.out.println("Email updated Successfully");
            TestRunner.getTest().log(Status.INFO, "Email changed from '" + oldEmail + "' to '" + updatedEmail + "'.");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Email  Edit successfully");
        } else {
            System.out.println("Email was not changed");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Email was not changed");
        }
    }

    public void edit_phone_number() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Edit Student Phone number");

        String oldNumber = edt_Phone_number.getAttribute("value");
        System.out.println("Old Phone Number is: " + oldNumber);

        Actions actions = new Actions(driver);

        edt_Phone_number.click();

        for (int i = 0; i < oldNumber.length(); i++) {
            actions.sendKeys(Keys.BACK_SPACE).perform();
        }
        String newPhnNumber = generateRandomPhoneNumber();
        edt_Phone_number.sendKeys(UpdatenewPhone);

        String UpdatenewPhone = edt_Phone_number.getAttribute("value");
        System.out.println("Update Phone number is: " + UpdatenewPhone);

        if (!oldNumber.equals(UpdatenewPhone)) {
            System.out.println("Phone Number updated Successfully");
            TestRunner.getTest().log(Status.INFO, "Phone Number changed from '" + oldNumber + "' to '" + UpdatenewPhone + "'.");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed:Phone Number  Edit successfully");

            TestRunner.getTest().log(Status.INFO, "Enter New Student Phone Number");
            edt_Phone_number.click();
            ((JavascriptExecutor) driver).executeScript("arguments[0].value='';", edt_Phone_number);

//        String randomPhoneNumber = generateRandomPhoneNumber();
            edt_Phone_number.sendKeys(UpdatePhonenumber);
            System.out.println("Phone Number enter Successfully " + UpdatePhonenumber);


            TestRunner.getTest().log(Status.INFO, "Enter Phone number is: " + UpdatePhonenumber);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Phone Number Enter successfully");
        }
    }

    public void edit_Address() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Edit Student Address");

        String oldAddress = edt_Home_address.getAttribute("value");
        System.out.println("Old Address is: " + oldAddress);
        Actions actions = new Actions(driver);

        edt_Home_address.click();

        for (int i = 0; i < oldAddress.length(); i++) {
            actions.sendKeys(Keys.BACK_SPACE).perform();
        }
        String newAddress = generateStudentInfo("Address-");
        edt_Home_address.sendKeys(newAddress);

        String updatedAddress = edt_Home_address.getAttribute("value");
        System.out.println("Updated Address is: " + updatedAddress);

        if (!oldAddress.equals(updatedAddress)) {
            System.out.println("Address updated Successfully");
            TestRunner.getTest().log(Status.INFO, "Address changed from '" + oldAddress + "' to '" + updatedAddress + "'.");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed : Address  Edit successfully");

        } else {
            System.out.println("Address was not changed");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Address was not changed");

        }

    }

    public void edit_localId() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Edit Local ID");
        String oldLocalId = edt_local_Id.getAttribute("value");
        System.out.println("Old Local Id is: " + oldLocalId);

        Actions actions = new Actions(driver);

        edt_local_Id.click();

        for (int i = 0; i < oldLocalId.length(); i++) {
            actions.sendKeys(Keys.BACK_SPACE).perform();
        }
        String newLocalId = generateStudentInfo("GP-");
        edt_local_Id.sendKeys(newLocalId);

        String updatedLocalId = edt_local_Id.getAttribute("value");
        System.out.println("Updated Local Id: " + updatedLocalId);

        if (!oldLocalId.equals(updatedLocalId)) {
            System.out.println("Local ID updated Successfully");
            TestRunner.getTest().log(Status.INFO, "Local Id  changed from '" + oldLocalId + "' to '" + updatedLocalId + "'.");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed : Local ID  Edit successfully");


        } else {
            System.out.println("Local ID  was not changed");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Local ID  was not changed");

        }
    }

    public void edit_district() throws InterruptedException {

        String oldDistrict = district_select.getText();
        System.out.println("Old District is: " + oldDistrict);

        // Click to open the dropdown
        district_select.click();

        // Wait for the dropdown list to become visible
        WebElement listDistrict = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[contains(@role, 'listbox')]")));
        List<WebElement> optionsDistrict = listDistrict.findElements(By.xpath(".//li"));

        System.out.println("District List is: " + optionsDistrict.size());

        // Check if any options are available
        if (optionsDistrict.isEmpty()) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: No options found in the district dropdown");
            System.out.println("No options found in the district dropdown.");
            throw new RuntimeException("No District found in dropdown");

        } else {
            System.out.println("District Options:");

            // Print all available districts
            for (WebElement district : optionsDistrict) {
                System.out.println(district.getText());
            }

            // Select a random district if options are available
            Random random = new Random();
            int randomIndex = random.nextInt(optionsDistrict.size());
            WebElement selectedOption = optionsDistrict.get(randomIndex);
            String selectedDistrict = selectedOption.getText();
            selectedOption.click();
//            String selectedDistrict = selectedOption.getText();
            System.out.println("New Selected District: " + selectedDistrict);
            TestRunner.getTest().log(Status.INFO, "New Selected District is: " + selectedDistrict);

            // Verify if the selection has changed
            if (oldDistrict.equals(selectedDistrict)) {
                System.out.println("District selection did not change.");
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: District selection did not change.");

            } else {
                System.out.println("District selection changed from '" + oldDistrict + "' to '" + selectedDistrict + "'.");
                TestRunner.getTest().log(Status.INFO, "District selection changed from '" + oldDistrict + "' to '" + selectedDistrict + "'.");
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: District  Edit successfully");
            }
        }
    }

    //    public void edit_school(){
//        String oldSchool=edt_select_school.getText();
//        System.out.println("Old School is: " + oldSchool);
//
//        edt_select_school.click();
//
//        WebElement listSchools = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[contains(@role, 'listbox')]")));
//        List<WebElement> optionsSchools = listSchools.findElements(By.xpath(".//li"));
//
//        System.out.println("Schools List is: " + optionsSchools.size());
//
//        if (optionsSchools.isEmpty()) {
//            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: No options found in the Schools dropdown");
//            System.out.println("No options found in the Schools dropdown.");
//            throw new RuntimeException("No School found in dropdown");
//
//        } else {
//            System.out.println("Schools:");
//
//            for (WebElement school : optionsSchools) {
//                System.out.println(school.getText());
//            }
//            Random random = new Random();
//            int randomCourse = random.nextInt(optionsSchools.size());
//            WebElement selectedOption = optionsSchools.get(randomCourse);
//            selectedOption.click();
//            String selectedSchool = selectedOption.getText();
//            System.out.println("New Selected School: " + selectedSchool);
//            TestRunner.getTest().log(Status.INFO, "New Selected School is: " + selectedSchool);
//
//
//            if (oldSchool.equals(selectedSchool)) {
//                System.out.println("School selection did not change.");
//                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: School selection did not change.");
//
//            } else {
//                System.out.println("School selection changed from '" + oldSchool + "' to '" + selectedSchool + "'.");
//                TestRunner.getTest().log(Status.INFO, "School selection changed from '" + oldSchool + "' to '" + selectedSchool + "'.");
//                TestRunner.getTest().log(Status.PASS, "Test Case Passed: School  Edit successfully");
//            }
//        }
//    }
    public void edit_school() {
        String oldSchool = edt_select_school.getText();
        System.out.println("Old School is: " + oldSchool);

        edt_select_school.click();

        List<WebElement> optionsSchools = null;

        // Use a loop to handle stale elements
        for (int attempts = 0; attempts < 3; attempts++) {
            try {
                WebElement listSchools = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[contains(@role, 'listbox')]")));
                optionsSchools = listSchools.findElements(By.xpath(".//li"));

                System.out.println("Schools List is: " + optionsSchools.size());

                if (optionsSchools.isEmpty()) {
                    TestRunner.getTest().log(Status.FAIL, "Test Case Failed: No options found in the Schools dropdown");
                    System.out.println("No options found in the Schools dropdown.");
                    throw new RuntimeException("No School found in dropdown");
                } else {
                    System.out.println("Schools:");

                    for (WebElement school : optionsSchools) {
                        System.out.println(school.getText());
                    }

                    Random random = new Random();
                    int randomCourse = random.nextInt(optionsSchools.size());
                    WebElement selectedOption = optionsSchools.get(randomCourse);
                    String selectedSchool = selectedOption.getText();
                    selectedOption.click();
//                String selectedSchool = selectedOption.getText();
                    System.out.println("New Selected School: " + selectedSchool);
                    TestRunner.getTest().log(Status.INFO, "New Selected School is: " + selectedSchool);

                    if (oldSchool.equals(selectedSchool)) {
                        System.out.println("School selection did not change.");
                        TestRunner.getTest().log(Status.FAIL, "Test Case Failed: School selection did not change.");
                    } else {
                        System.out.println("School selection changed from '" + oldSchool + "' to '" + selectedSchool + "'.");
                        TestRunner.getTest().log(Status.INFO, "School selection changed from '" + oldSchool + "' to '" + selectedSchool + "'.");
                        TestRunner.getTest().log(Status.PASS, "Test Case Passed: School Edit successfully");
                    }
                    break; // Exit the loop if successful
                }
            } catch (StaleElementReferenceException e) {
                System.out.println("Stale element encountered. Retrying...");
                // Re-click to reopen the dropdown if necessary
                edt_select_school.click();
            }
        }
    }

    public void Edit_School_Year() {
        String oldSchool = edt_school_year.getText();
        System.out.println("Old School Year is: " + oldSchool);

        edt_school_year.click();

        WebElement listSchools = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[contains(@role, 'listbox')]")));
        List<WebElement> optionsSchools = listSchools.findElements(By.xpath(".//li"));

        System.out.println("Schools Year List is: " + optionsSchools.size());

        if (optionsSchools.isEmpty()) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: No options found in the Schools dropdown");
            System.out.println("No options found in the Schools Year dropdown.");
            throw new RuntimeException("No School Year found in dropdown");

        } else {
            System.out.println("Schools Year:");

            for (WebElement school : optionsSchools) {
                System.out.println(school.getText());
            }
            Random random = new Random();
            int randomCourse = random.nextInt(optionsSchools.size());
            WebElement selectedOption = optionsSchools.get(randomCourse);
            selectedOption.click();
            String selectedSchool = selectedOption.getText();
            System.out.println("New Selected School Year: " + selectedSchool);
            TestRunner.getTest().log(Status.INFO, "New Selected School is: " + selectedSchool);


            if (oldSchool.equals(selectedSchool)) {
                System.out.println("School Year selection did not change.");
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: School Year selection did not change.");

            } else {
                System.out.println("School Year selection changed from '" + oldSchool + "' to '" + selectedSchool + "'.");
                TestRunner.getTest().log(Status.INFO, "School selection changed from '" + oldSchool + "' to '" + selectedSchool + "'.");
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: School  Edit successfully");
            }
        }
    }


    public void edit_grade() {
        String oldGrade = edt_select_grade.getText();
        System.out.println("Old grade is: " + oldGrade);

        edt_select_grade.click();
        WebElement listGrade = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[contains(@role, 'listbox')]")));
        List<WebElement> optionsGrade = listGrade.findElements(By.xpath(".//li"));

        System.out.println("Grades List is: " + optionsGrade.size());

        if (optionsGrade.isEmpty()) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: No options found in the Grades dropdown");
            System.out.println("No options found in the Grades dropdown.");
            return;
        }
        List<WebElement> filteredOptions = new ArrayList<>();
        List<String> excludedValues = List.of("Unknown", "Other", "Ungraded");

        for (WebElement option : optionsGrade) {
            String text = option.getText();
            if (!excludedValues.contains(text)) {
                filteredOptions.add(option);
            }
        }

        System.out.println("Filtered Grades:");

        if (filteredOptions.isEmpty()) {
            System.out.println("No valid options available after filtering.");
            return;
        }

        for (WebElement option : filteredOptions) {
            System.out.println(option.getText());
        }

        WebElement selectedOption = filteredOptions.get(random.nextInt(filteredOptions.size()));
        String selectedGrade = selectedOption.getText();
        selectedOption.click();
//        String selectedGrade = selectedOption.getText();
        System.out.println("Selected Grade: " + selectedGrade);
        TestRunner.getTest().log(Status.INFO, "New Selected Grade is: " + selectedGrade);

        if (oldGrade.equals(selectedGrade)) {
            System.out.println("Grade selection did not change.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Grade selection did not change..");

        } else {


            System.out.println("Grade selection changed from '" + oldGrade + "' to '" + selectedGrade + "'.");
            TestRunner.getTest().log(Status.INFO, "Grade selection changed from '" + oldGrade + "' to '" + selectedGrade + "'.");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Grade  Edit successfully");
        }
    }

    public void edit_classes() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Selecting Class ");

        edit_select_classes.click();
        // Click to open the dropdown
        WebElement listClasses = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[@role='listbox']")));
        List<WebElement> optionsClasses = listClasses.findElements(By.xpath(".//li"));

        int classCount = optionsClasses.size();
        System.out.println("Classes List size: " + classCount);
        TestRunner.getTest().log(Status.INFO, "Number of classes available: " + classCount);

        if (classCount == 0) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: No options found in the Classes dropdown");
            System.out.println("No options found in the Classes dropdown.");
            throw new RuntimeException("No Classes found in dropdown");

        } else {
            System.out.println("Classes available:");
            boolean classFound = false;

            for (WebElement option : optionsClasses) {
                String className = option.getText();
                System.out.println(className);

                if (className.equals(specificClasses)) {
                    // Check if the option is disabled (aria-disabled="true")
                    String ariaDisabled = option.getAttribute("aria-disabled");

                    if (ariaDisabled != null && ariaDisabled.equals("true")) {
                        System.out.println("Class '" + specificClasses + "' is already selected (disabled).");
                        TestRunner.getTest().log(Status.INFO, "Class '" + specificClasses + "' is already selected.");
                        Actions action = new Actions(driver);
                        action.sendKeys(Keys.ESCAPE).perform();
                        Thread.sleep(1000);
                        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Class already selected.");
                    } else {
                        try {
                            helper.scrollToElement(driver, option);

                            // Click the option
                            option.click();
                            System.out.println("Selected Class: " + specificClasses);
                            TestRunner.getTest().log(Status.INFO, "Selected Class: " + specificClasses);
                            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Class selected successfully.");
                        } catch (ElementClickInterceptedException e) {
                            System.out.println("Element click intercepted: attempting to click using JavaScript.");
                            JavascriptExecutor js = (JavascriptExecutor) driver;
                            js.executeScript("arguments[0].click();", option);  // Fallback to JS click
                            System.out.println("Class clicked using JavaScript: " + specificClasses);
                            TestRunner.getTest().log(Status.INFO, "Class clicked using JavaScript: " + specificClasses);
                        }
                    }
                    classFound = true;
                    break;
                }
            }

            if (!classFound) {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Specific class not found in the Classes dropdown.");
                throw new RuntimeException("Specific class not found in dropdown: " + specificClasses);
            }


        }
    }

    public void edit_Language() throws InterruptedException {
        String oldLanguage = edt_language.getText();
        System.out.println("Old Language is: " + oldLanguage);
        edt_language.click();

        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].scrollIntoView(true);", edt_language);

        WebElement listLanguage = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[contains(@role, 'listbox')]")));
        List<WebElement> options = listLanguage.findElements(By.xpath(".//li"));

        if (options.isEmpty()) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: No options found in the dropdown ");
            System.out.println("No options found in the dropdown.");
            return;
        }
        WebElement randomOption = options.get(random.nextInt(options.size()));
        js.executeScript("arguments[0].scrollIntoView(true);", randomOption);
        randomOption.click();

        // Retrieve and print the new language
        String newLanguage = edt_language.getText();
        System.out.println("New Language is: " + newLanguage);

        if (oldLanguage.equals(newLanguage)) {
            System.out.println("Language selection did not change.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Language selection did not change..");

        } else {
            System.out.println("Language selection changed from '" + oldLanguage + "' to '" + newLanguage + "'.");
            TestRunner.getTest().log(Status.INFO, "Language selection changed from '" + oldLanguage + "' to '" + newLanguage + "'.");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Language  Edit successfully");


        }
    }

    public void click_update_btn() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Attempting to click Update button");
        System.out.println("Attempting to click Update button");

        Thread.sleep(500);

        try {
            // Wait for the button to be visible and clickable
            wait.until(ExpectedConditions.visibilityOf(btn_update));
            wait.until(ExpectedConditions.elementToBeClickable(btn_update));

            if (btn_update.isEnabled()) {
                // Scroll the element into view
                ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({behavior: 'smooth', block: 'center'});", btn_update);
                Thread.sleep(500);

                // Try regular click first
                try {
                    btn_update.click();
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed: Update button clicks successfully");
                    System.out.println("Update button clicked successfully");
                } catch (ElementClickInterceptedException e) {
                    // If regular click fails, use JavaScript click
                    System.out.println("Regular click intercepted, trying JavaScript click");
                    ((JavascriptExecutor) driver).executeScript("arguments[0].click();", btn_update);
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed: Update button clicks successfully (using JavaScript)");
                    System.out.println("Update button clicked successfully (using JavaScript)");
                }
            } else {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Update button Disable due to Password not enter successfully");
                System.out.println("Update button is disabled");
            }
        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Unable to click Update button - " + e.getMessage());
            System.out.println("Error clicking Update button: " + e.getMessage());
            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
        }
    }

    //    ***************************** Account Setting *****************************************
    public void click_Account_btn() throws InterruptedException {
        Thread.sleep(2000);
        Account_btn.click();
        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Account Setting button clicks successfully");
        Thread.sleep(3000);

    }

    public void edit_Account_Setting_info() throws InterruptedException {

        TestRunner.startTest(" Check Fill and validate Account Setting Info");
        TestRunner.getTest().log(Status.INFO, "Edit Account Setting Information: ");

        Thread.sleep(2000);
        System.out.println("I'm in Updated Account Setting Information Screen");
        Update_Password();
        enterUpdate_ConfirmPassword();
    }

    public void Update_Password() throws InterruptedException {
        // Log the action in the test report
        TestRunner.getTest().log(Status.INFO, "Enter Updated Student Password");
        Thread.sleep(2000);

        WebElement passwordField = driver.findElement(By.xpath("//input[@name='userNewpassword']"));

        Actions actions = new Actions(driver);
        actions.moveToElement(passwordField).click().sendKeys("Fltester@23").perform();

        System.out.println("Confirm Password added Successfully");

        UpdatedPasswordValue = passwordField.getAttribute("value");
        System.out.println("Password field value after input: " + UpdatedPasswordValue);
        TestRunner.getTest().log(Status.INFO, "New Student Password is: " + UpdatedPasswordValue);

        UpdatedPasswordValue = passwordField.getAttribute("value");

        System.out.println("Password field value after input: " + UpdatedPasswordValue);

        TestRunner.getTest().log(Status.INFO, "New Student Password is: " + UpdatedPasswordValue);

        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Password enter successfully");
    }

    public void enterUpdate_ConfirmPassword() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Enter Updated Student Confirm Password");
        Thread.sleep(5000);

        WebElement confirmPasswordField = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@name='confirmPassword']")));

//        confirmPasswordField.clear();

        Actions actions = new Actions(driver);
        actions.moveToElement(confirmPasswordField).click().sendKeys("Fltester@23").perform();

        System.out.println("Confirm Password added Successfully");

        String confirmPasswordValue = confirmPasswordField.getAttribute("value");
        System.out.println("Confirm Password field value after input: " + confirmPasswordValue);
        TestRunner.getTest().log(Status.INFO, "New Student Password is: " + confirmPasswordValue);

//        if (!"Fltester@22".equals(confirmPasswordValue)) {
//            throw new RuntimeException("Confirm Password field did not receive the expected value. Actual value: '" + confirmPasswordValue + "'");
//        }
        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Confirm Password enter successfully");

    }

    //    ******************************** Classses ***************************************
    public void click_Classes_btn() throws InterruptedException {
        Thread.sleep(500);
        classes_btn.click();
        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Account Setting button clicks successfully");

    }

    //*************************** Select School Year **************************************
    public void edit_School_Year() throws InterruptedException {
        String oldSchool = edt_school_year.getText();
        System.out.println("Old School Year is: " + oldSchool);

        edt_school_year.click();

        WebElement listSchools = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[contains(@role, 'listbox')]")));
        List<WebElement> optionsSchools = listSchools.findElements(By.xpath(".//li"));

        System.out.println("Schools Year List is: " + optionsSchools.size());

        if (optionsSchools.isEmpty()) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: No options found in the Schools dropdown");
            System.out.println("No options found in the Schools Year dropdown.");
            throw new RuntimeException("No School Year found in dropdown");

        } else {
            System.out.println("Schools Year:");

            for (WebElement school : optionsSchools) {
                System.out.println(school.getText());
            }
            Random random = new Random();
            int randomCourse = random.nextInt(optionsSchools.size());
            WebElement selectedOption = optionsSchools.get(randomCourse);
            selectedOption.click();
            String selectedSchool = selectedOption.getText();
            System.out.println("New Selected School Year: " + selectedSchool);
            TestRunner.getTest().log(Status.INFO, "New Selected School is: " + selectedSchool);


            if (oldSchool.equals(selectedSchool)) {
                System.out.println("School Year selection did not change.");
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: School Year selection did not change.");

            } else {
                System.out.println("School Year selection changed from '" + oldSchool + "' to '" + selectedSchool + "'.");
                TestRunner.getTest().log(Status.INFO, "School selection changed from '" + oldSchool + "' to '" + selectedSchool + "'.");
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: School  Edit successfully");
            }
        }
    }

    public void SelectClassStatus() throws InterruptedException {
        Status_filter.click();
        List<WebElement> SchoolStatusOptions = Status_filter.findElements(By.xpath("//ul[@role='listbox']/li"));
//        selectRandomValueFromDropdown(SchoolStatusOptions);
        String schoolStatus = helper.selectValueFromDropdown(SchoolStatusOptions);
        TestRunner.getTest().log(Status.INFO, "Selected School Status Name:" + schoolStatus);
        TestRunner.getTest().log(Status.PASS, "Test Case Passed : School Status Select successfully ");
    }


    public void verifyUpdateDialogBox() throws InterruptedException {
//        String messageXPath = "//div[@class='rrt-middle-container']//div[@class='rrt-text']";
//
//        // Wait for the message to be visible
//        WebElement successMessageElement = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(messageXPath)));
//
//        // Capture the text of the success message
//        String successMessage = successMessageElement.getText();
//        System.out.println("Success Message: " + successMessage);

        WebElement successMessageContainer = wait.until(ExpectedConditions.visibilityOf(toastContainer));
        if (successMessageContainer.isDisplayed()) {
            String messageTitle = successMessageContainer.findElement(By.className("rrt-title")).getText();
            String messageText = successMessageContainer.findElement(By.className("rrt-text")).getText();

            System.out.println("Message Title: " + messageTitle);
            System.out.println("Message Text: " + messageText);

        } else {
            System.out.println("Success message is not displayed.");
            throw new RuntimeException("Toast Message is display wrong message'");

        }

    }

    //    public void click_cancel_ater_edit_btn() throws InterruptedException {
//        Thread.sleep(500);
//        WebElement cancel_btn= driver.findElement(By.xpath("//button[normalize-space()='Cancel']"));
//        cancel_btn.click();
//        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Cancel button clicks successfully");
//    }
//    ********************************* Close Button *********************************************
    public void click_Close_btn() throws InterruptedException {
        Thread.sleep(2000);
        WebElement close_btn = driver.findElement(By.xpath("//button[@aria-label='close']"));
        close_btn.click();
        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Close button clicks successfully");
    }

    public void ClearSearchBoxforStudent() throws InterruptedException {
        try {
            // Wait for search bar to be present and clickable
            WebElement searchBar = wait.until(ExpectedConditions.presenceOfElementLocated(
                    By.xpath("//input[@placeholder='Search by Name or Email']")));
            
            String oldsearch = searchBar.getAttribute("value");
            System.out.println("Old Email is: " + oldsearch);
            
            if (oldsearch == null || oldsearch.isEmpty()) {
                System.out.println("Search box is already empty");
                TestRunner.getTest().log(Status.INFO, "Search box is already empty");
                return;
            }
            
            // Scroll element into view
            helper.scrollToElement(driver, searchBar);
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", searchBar);
            Thread.sleep(500);
            
            // Wait for element to be clickable
            wait.until(ExpectedConditions.elementToBeClickable(searchBar));
            
            // Try to click and focus on the search bar
            try {
                searchBar.click();
            } catch (ElementClickInterceptedException e) {
                // If click is intercepted, use JavaScript to focus
                ((JavascriptExecutor) driver).executeScript("arguments[0].focus();", searchBar);
                ((JavascriptExecutor) driver).executeScript("arguments[0].click();", searchBar);
            }
            
            Thread.sleep(300);
            
            // Clear the field using multiple strategies
            try {
                // Strategy 1: Select all and delete
                Actions actions = new Actions(driver);
                actions.keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).perform();
                Thread.sleep(200);
                actions.sendKeys(Keys.DELETE).perform();
            } catch (Exception e) {
                // Strategy 2: Use clear() method
                try {
                    searchBar.clear();
                } catch (Exception e2) {
                    // Strategy 3: JavaScript clear
                    ((JavascriptExecutor) driver).executeScript("arguments[0].value = '';", searchBar);
                }
            }
            
            // Verify the field is cleared
            String newValue = searchBar.getAttribute("value");
            if (newValue == null || newValue.isEmpty()) {
                System.out.println("Search box cleared successfully");
                TestRunner.getTest().log(Status.PASS, "Testcase Passed: Search Box clear Successfully");
            } else {
                System.out.println("Warning: Search box may not be fully cleared. Remaining value: " + newValue);
                TestRunner.getTest().log(Status.WARNING, "Search box may not be fully cleared");
            }
            
        } catch (TimeoutException e) {
            TestRunner.getTest().log(Status.FAIL, "Search box not found: " + e.getMessage());
            System.out.println("Error: Search box not found - " + e.getMessage());
        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "Failed to clear search box: " + e.getMessage());
            System.out.println("Error clearing search box: " + e.getMessage());
        }
    }

    //    ******************************** User Usage View ******************************************
    public void click_Usage_button() throws InterruptedException {
        Thread.sleep(500);

        WebElement usage_dots_click = driver.findElement(By.xpath("//button[@aria-label='DropDownButtom']"));
        usage_dots_click.click();
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//ul[@role='menu']//li")));

        WebElement usage_btn = driver.findElement(By.xpath("//span[normalize-space()='Usage']"));
        usage_btn.click();

        TestRunner.getTest().log(Status.PASS, "Testcase Passed   : Edit button click successfully.");
    }

    public String generateRandomAddress() {
        Random random = new Random();

        // Random street number
        int streetNumber = random.nextInt(9000) + 100; // 100 to 9999

        // Random street name
        String[] streetNames = {"Main St", "Elm St", "Maple Ave", "Oak Dr", "Pine Ln", "Cedar Blvd", "Birch Ct"};
        String streetName = streetNames[random.nextInt(streetNames.length)];

        // Random city
        String[] cities = {"Springfield", "Riverside", "Greenville", "Centerville", "Fairview"};
        String city = cities[random.nextInt(cities.length)];

        // Random state
        String[] states = {"NY", "CA", "TX", "FL", "IL"};
        String state = states[random.nextInt(states.length)];

        // Random zip code
        int zipCode = random.nextInt(90000) + 10000; // 10000 to 99999

        // Format the address
        return String.format("%d %s, %s, %s %05d", streetNumber, streetName, city, state, zipCode);
    }

    public String generateRandomPhoneNumber() {
        String characters = "0123456789";
        StringBuilder randomTitle = new StringBuilder();
        Random random = new Random();
        int length = 11;
        for (int i = 0; i < length; i++) {
            randomTitle.append(characters.charAt(random.nextInt(characters.length())));
        }
        return randomTitle.toString();
    }

    public String randomClassNewStdEmail(String prefix) {
        Random randemail = new Random();
        int randomInt = randemail.nextInt(1000);
        return prefix + randomInt + "@gallopade.com";
    }

    public String generateStudentInfo(String prefix) {
        String characters = "abcdefghijklmnopqrstuvwxyz";
        StringBuilder randomTitle = new StringBuilder();
        Random random = new Random();
        int length = 4;
        randomTitle.append(prefix);
        for (int i = 0; i < length; i++) {
            randomTitle.append(characters.charAt(random.nextInt(characters.length())));
        }
        return randomTitle.toString();
    }

    public void getFilterStatusAndGetClassList() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Selecting 'All' from the Filter Status dropdown");

        // 1️⃣ Click the Filter Status combobox
        WebElement filterStatusDropdown = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//label[normalize-space(.)='Filter Status']/following::div[@role='combobox'][1]")));
        filterStatusDropdown.click();

        // 2️⃣ Wait for the options list to appear
        WebElement listStatus = wait.until(
                ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[@role='listbox']")));
        List<WebElement> optionsStatus = listStatus.findElements(By.xpath(".//li"));

        int statusCount = optionsStatus.size();
        System.out.println("Status List size: " + statusCount);
        TestRunner.getTest().log(Status.INFO, "Number of statuses available: " + statusCount);

        if (statusCount == 0) {
            TestRunner.getTest().log(Status.FAIL, "No options found in the Filter Status dropdown");
            throw new RuntimeException("No statuses found in dropdown");
        }

        // 3️⃣ Iterate and click the “All” option
        boolean allFound = false;
        for (WebElement option : optionsStatus) {
            String statusName = option.getText().trim();
            System.out.println("Status option: " + statusName);

            if (statusName.equalsIgnoreCase("All")) {
                option.click();
                System.out.println("Selected Status: All");
                TestRunner.getTest().log(Status.INFO, "Selected Status: All");
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: 'All' selected successfully");
                allFound = true;
                break;
            }
        }

        if (!allFound) {
            TestRunner.getTest().log(Status.FAIL, "'All' option not found in the Filter Status dropdown");
            throw new RuntimeException("'All' option not found in dropdown");
        }
    }

    //    public List<String> classNamesForStudentModule = new ArrayList<>();
    public List<String> classNamesForStudentModule =
            new ArrayList<>(Arrays.asList("FL Grade 5"));


    public void getClassListAndStore() throws InterruptedException {

        TestRunner.getTest().log(Status.INFO, "I'm into Get Class List");

// 1️⃣ Wait for table body
        By tableBodyLocator = By.xpath("//div[@class='table-container']//tbody");
        wait.until(ExpectedConditions.visibilityOfElementLocated(tableBodyLocator));

// 2️⃣ Get total rows count dynamically each iteration
        List<WebElement> rows = driver.findElements(By.xpath("//div[@class='table-container']//tbody/tr"));
        System.out.println("Total Rows: " + rows.size());
        TestRunner.getTest().log(Status.INFO, "Total Rows: " + rows.size());


// 4️⃣ Loop with index to re-find elements each time
        for (int i = 1; i <= rows.size(); i++) {
            // Always re-locate the first cell in current row by index
            By firstCellLocator = By.xpath("//div[@class='table-container']//tbody/tr[" + i + "]/td[1]");

            WebElement firstCell = wait.until(ExpectedConditions.presenceOfElementLocated(firstCellLocator));

            // Then re-locate the aria-label element fresh
            WebElement ariaElement = firstCell.findElement(By.xpath(".//div[@aria-label]"));

            // Extract aria-label value
            String className = ariaElement.getAttribute("aria-label").trim();

            System.out.println("Class Name (aria-label): " + className);
            TestRunner.getTest().log(Status.INFO, "Class Name: " + className);

            classNamesForStudentModule.add(className);
        }

// 5️⃣ Print the list or use it
        System.out.println("All class names: " + classNamesForStudentModule);
        TestRunner.getTest().log(Status.INFO, "Classes found: " + classNamesForStudentModule);

    }

    public void clickOnCoursesStudentSide() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Attempting to click on Courses Module");
        System.out.println("Attempting to click on Courses Module");

        WebElement coursesModule = null;

        try {
            // Try multiple locator strategies to find the Courses element
            // Strategy 1: Try to find the anchor tag with href="/courses"
            try {
                coursesModule = wait.until(ExpectedConditions.presenceOfElementLocated(
                        By.xpath("//a[@href='/courses']")));
                System.out.println("Found Courses module using anchor tag locator");
            } catch (TimeoutException e) {
                // Strategy 2: Try to find the button containing "Courses" text
                try {
                    coursesModule = wait.until(ExpectedConditions.presenceOfElementLocated(
                            By.xpath("//button[.//span[normalize-space()='Courses']]")));
                    System.out.println("Found Courses module using button locator");
                } catch (TimeoutException e2) {
                    // Strategy 3: Try to find by aria-label
                    try {
                        coursesModule = wait.until(ExpectedConditions.presenceOfElementLocated(
                                By.xpath("//div[@aria-label='Student Courses']//button")));
                        System.out.println("Found Courses module using aria-label locator");
                    } catch (TimeoutException e3) {
                        // Strategy 4: Try the span and get its parent button
                        WebElement spanElement = wait.until(ExpectedConditions.presenceOfElementLocated(
                                By.xpath("//span[normalize-space()='Courses']")));
                        coursesModule = spanElement.findElement(By.xpath("./ancestor::button[1]"));
                        System.out.println("Found Courses module using span parent button");
                    }
                }
            }

            // Wait for the element to be visible and clickable
            wait.until(ExpectedConditions.visibilityOf(coursesModule));
            wait.until(ExpectedConditions.elementToBeClickable(coursesModule));

            // Scroll the element into view
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({behavior: 'smooth', block: 'center'});", coursesModule);
            Thread.sleep(500);

            // Try regular click first
            try {
                coursesModule.click();
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: Courses Module Click successfully");
                System.out.println("Courses Module clicked successfully");
            } catch (ElementClickInterceptedException e) {
                // If regular click fails, use JavaScript click
                System.out.println("Regular click intercepted, trying JavaScript click");
                ((JavascriptExecutor) driver).executeScript("arguments[0].click();", coursesModule);
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: Courses Module Click successfully (using JavaScript)");
                System.out.println("Courses Module clicked successfully (using JavaScript)");
            }

        } catch (TimeoutException e) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Timeout waiting for Courses Module - " + e.getMessage());
            System.out.println("Timeout waiting for Courses Module: " + e.getMessage());
            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
            throw e;
        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Unable to click Courses Module - " + e.getMessage());
            System.out.println("Error clicking Courses Module: " + e.getMessage());
            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
            throw e;
        }
    }

    public void getMyCoursesListAndSelectCourse(List<String> classNames) throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into get My Courses List And Select Course");
        System.out.println("Getting My Courses List And Selecting Course");

        Thread.sleep(1000);

        try {
            // 1️⃣ Wait for and open the dropdown
            WebElement comboBox = wait.until(ExpectedConditions.presenceOfElementLocated(
                    By.xpath("(//div[@role='combobox'])[1]")));

            // Wait for it to be visible and clickable
            wait.until(ExpectedConditions.visibilityOf(comboBox));
            wait.until(ExpectedConditions.elementToBeClickable(comboBox));

            // Scroll into view
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({behavior: 'smooth', block: 'center'});", comboBox);
            Thread.sleep(500);

            // Try to click the combobox with fallback to JavaScript click
            try {
                comboBox.click();
            } catch (ElementClickInterceptedException e) {
                System.out.println("Regular click intercepted, using JavaScript click for combobox");
                ((JavascriptExecutor) driver).executeScript("arguments[0].click();", comboBox);
            }

            Thread.sleep(500);

            // 2️⃣ Wait for listbox options
            WebElement listBox = wait.until(ExpectedConditions.visibilityOfElementLocated(
                    By.xpath("//ul[@role='listbox']")));

            // 3️⃣ Grab all li options
            List<WebElement> options = listBox.findElements(By.xpath(".//li"));

            if (options.isEmpty()) {
                TestRunner.getTest().log(Status.FAIL, "No options found in the dropdown listbox");
                throw new RuntimeException("No options found in the dropdown listbox");
            }

            System.out.println("Found " + options.size() + " options in dropdown");

            // 4️⃣ Collect all title texts
            Set<String> dropdownTexts = new HashSet<>();
            for (WebElement option : options) {
                try {
                    WebElement titleSpan = option.findElement(By.xpath(".//span[contains(@class,'ListItemText-title')]"));
                    dropdownTexts.add(titleSpan.getText().trim());
                } catch (NoSuchElementException e) {
                    System.out.println("Warning: Could not find title span in option, skipping...");
                }
            }

            // 5️⃣ Verify all required classNames exist
            for (String name : classNames) {
                if (!dropdownTexts.contains(name)) {
                    TestRunner.getTest().log(Status.FAIL, "Class not found in dropdown: " + name);
                    System.out.println("Class not found in dropdown: " + name);
                    throw new RuntimeException("Class not found in dropdown: " + name);
                }
            }
            TestRunner.getTest().log(Status.PASS, "All class names found in dropdown");
            System.out.println("All class names found in dropdown");

            // 6️⃣ Click the first <li> whose title matches any of your classNames
            for (WebElement option : options) {
                try {
                    WebElement titleSpan = option.findElement(By.xpath(".//span[contains(@class,'ListItemText-title')]"));
                    String titleText = titleSpan.getText().trim();
                    if (classNames.contains(titleText)) {
                        // Scroll option into view before clicking
                        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({behavior: 'smooth', block: 'center'});", option);
                        Thread.sleep(300);

                        // Try regular click first, fallback to JavaScript click
                        try {
                            option.click();
                        } catch (ElementClickInterceptedException e) {
                            System.out.println("Regular click intercepted for option, using JavaScript click");
                            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", option);
                        }

                        TestRunner.getTest().log(Status.PASS, "Clicked class: " + titleText);
                        System.out.println("Clicked class: " + titleText);
                        return;
                    }
                } catch (NoSuchElementException e) {
                    // Skip options without title span
                    continue;
                }
            }

        } catch (TimeoutException e) {
            TestRunner.getTest().log(Status.FAIL, "Timeout waiting for combobox or listbox: " + e.getMessage());
            System.out.println("Timeout waiting for combobox or listbox: " + e.getMessage());
            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
            throw e;
        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "Error in getMyCoursesListAndSelectCourse: " + e.getMessage());
            System.out.println("Error in getMyCoursesListAndSelectCourse: " + e.getMessage());
            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
            throw e;
        }
    }


    public void verifySearchBoxAndUnits() {
        TestRunner.getTest().log(Status.INFO, "Verifying search box and content tree");

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        // 1️⃣ Locate the search box <input>
        WebElement searchBox = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//input[starts-with(@id,'SearchField-')]")
        ));

        if (searchBox.isDisplayed()) {
            TestRunner.getTest().log(Status.PASS, "Search box is displayed");
            System.out.println("✅ Search box is displayed");
        } else {
            TestRunner.getTest().log(Status.FAIL, "Search box is NOT displayed");
            throw new RuntimeException("Search box not visible");
        }

        // 2️⃣ Locate the content tree (ul role='tree')
        WebElement contentTree = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//ul[@role='tree']")
        ));

        if (contentTree.isDisplayed()) {
            TestRunner.getTest().log(Status.PASS, "Content tree is displayed");
            System.out.println("✅ Content tree is displayed");
        } else {
            TestRunner.getTest().log(Status.FAIL, "Content tree is NOT displayed");
            throw new RuntimeException("Content tree not visible");
        }

        // 3️⃣ Grab all label-container text from li items and print
        List<WebElement> unitLabels = contentTree.findElements(By.xpath(".//div[@class='label-container']"));

        System.out.println("Total units found: " + unitLabels.size());
        for (WebElement unit : unitLabels) {
            String unitText = unit.getText().trim();
            System.out.println("Unit: " + unitText);
            TestRunner.getTest().log(Status.INFO, "Unit: " + unitText);
        }
    }


    public void verifyDataOnRightSide() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into verify that is display on Right side");


        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        WebElement studentEBookNode = wait.until(ExpectedConditions.presenceOfElementLocated(
                By.xpath("//div[@class='label-container' and normalize-space(text())='Student eBook']")
        ));

// scroll into view
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block: 'center'});", studentEBookNode);

// then click with JS to avoid overlay
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", studentEBookNode);

        TestRunner.getTest().log(Status.PASS, "Clicked Student eBook node");

        // 2️⃣ Wait until the right-side panel shows the Student eBook heading
        WebElement rightPanelHeading = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//div[@class='right-container']//h6/span[normalize-space(text())='Student eBook']")
        ));

        if (rightPanelHeading.isDisplayed()) {
            TestRunner.getTest().log(Status.PASS, "Right side shows Student eBook heading");
            System.out.println("✅ Right side heading is Student eBook");
        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Right side No data is Visible");
        }

        // 3️⃣ Grab all cards under the right side
        List<WebElement> cards = driver.findElements(By.xpath(
                "//div[@class='right-container']//div[contains(@class,'cardContainer')]"
        ));
        System.out.println("Found " + cards.size() + " cards for Student eBook:");

        for (WebElement card : cards) {
            String title = card.findElement(By.xpath(".//h6/span")).getText().trim();
            String subtitle = card.findElement(By.xpath(".//span[@class='isLeafContentDetail']")).getText().trim();
            System.out.println("Card title: " + title + " | Detail: " + subtitle);

            TestRunner.getTest().log(Status.INFO, "Card title: " + title + " | Detail: " + subtitle);
        }
    }

    public String randomUnitName;

    public void validateSearchFunctionality() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into get Random Unit/Chapter Name and Verify Search");

        // Get all unit labels
        List<WebElement> units = driver.findElements(
                By.xpath("//div[@class='label-container' and contains(normalize-space(.), 'Unit ')]")
        );

        if (!units.isEmpty()) {
            // Pick a random index
            Random rand = new Random();
            int randomIndex = rand.nextInt(units.size());

            // Get the random unit name
            randomUnitName = units.get(randomIndex).getText();

            System.out.println("Random Unit Name: " + randomUnitName);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Unit Name Get Successfully");
            // now you can store/use randomUnitName variable anywhere
        } else {
            System.out.println("No units found!");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: No units found!");
        }


        TestRunner.getTest().log(Status.INFO, "Now Check and Verify Search Functionality");

        WebElement searchBox = driver.findElement(
                By.xpath("//input[@placeholder='Search within course']")
        );

// clear any existing text first
        searchBox.clear();

// enter your random unit name
        searchBox.sendKeys(randomUnitName);

// optionally press Enter if the search triggers on Enter:
        searchBox.sendKeys(Keys.ENTER);

        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Search Box Name Enter successfully");

    }


    public void verifySearchUnitIsMatch() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into verify After search Unit Name Match");

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        try {
            WebElement matchedUnit = wait.until(ExpectedConditions.visibilityOfElementLocated(
                    By.xpath("//div[@class='label-container' and normalize-space(text())='" + randomUnitName + "']")
            ));

            // log to extent
            TestRunner.getTest().log(Status.PASS, "Unit '" + randomUnitName + "'  that search found successfully.");

            System.out.println("Matched Unit: " + matchedUnit.getText());
            TestRunner.getTest().log(Status.PASS, "Search Unit Name: " + randomUnitName + " match with the " + matchedUnit.getText());

            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript("arguments[0].click();", matchedUnit);

        } catch (TimeoutException e) {

            TestRunner.getTest().log(Status.FAIL, "Unit '" + randomUnitName + "' was not found in the list.");

        }

    }

    public void verifyDataDisplay() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into verify data display on right side");


        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        // 2️⃣ Wait until the right-side panel shows the Student eBook heading
        WebElement rightPanelHeading = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//div[@class='right-container']//div[contains(@class,'coursesDasboardContainer')]//h6")
        ));

        if (rightPanelHeading.isDisplayed()) {
            TestRunner.getTest().log(Status.PASS, "Right side shows Data" + rightPanelHeading.getText());
            System.out.println("✅ Right side heading is Display");
        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Right side No data is Visible");
        }
    }


    public void clickOnUnitName() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into click on Unit Name");
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));

        By unitLink = By.xpath("//li[contains(@class,'MuiTreeItem-root')]//a[.//div[@class='label-container' and normalize-space(.)='Unit 1: Good Citizens']]");

        WebElement unitElement = wait.until(ExpectedConditions.presenceOfElementLocated(unitLink));

        try {
            WebElement unit1 = wait.until(ExpectedConditions.elementToBeClickable(unitElement));

            if (unit1.isDisplayed()) {
                Thread.sleep(500);
                unit1.click();
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: Clicked on Unit 1: Good Citizens successfully");
                System.out.println("Clicked on Unit 1 successfully");
            } else {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Unit 1: Good Citizens is present but not displayed");
                System.out.println("Unit 1 present but not displayed");
            }
        } catch (TimeoutException e) {
            TestRunner.getTest().log(Status.FAIL, "Unit Navigation Tree Not Display");
            System.out.println("Unit Navigation Tree Not Display");
        }
    }

    public void verifyAssignmentPresentInList() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "verify Assignment Present In List");


        String assignmentNameForCorrect = CorrectAnswerExecutor_PF.assignmentNameForCorrect.get();
        System.out.println("Want to Search assignment In List: " + assignmentNameForCorrect);

        Thread.sleep(1000);

        // expected assignment name
// get all assignment name spans inside <h6>
        List<WebElement> assignmentNames = driver.findElements(
                By.xpath("//div[contains(@class,'cardContainer')]//h6/span")
        );

// flag to see if found
        boolean found = false;

// iterate through assignment names
        for (WebElement assignment : assignmentNames) {
            String actualName = assignment.getText().trim();
            System.out.println("Assignment: " + actualName);
            TestRunner.getTest().log(Status.INFO,"Assignment: " + actualName );
            if (actualName.equalsIgnoreCase(assignmentNameForCorrect)) {

                // ✅ mark test as passed
                TestRunner.getTest().log(Status.PASS,
                        "Test Case Passed: Assignment '" + assignmentNameForCorrect + "' found in Courses List");
                found = true;
                break;
            }
        }

// if not found, fail test case
        if (!found) {
            TestRunner.getTest().log(Status.FAIL,
                    "Test Case Failed: Assignment '" + assignmentNameForCorrect + "' not found in Courses Assignment List");
            Assert.fail("Assignment '" + assignmentNameForCorrect + "' not found in Courses Assignment List");
        }

    }


    public void VerifyAndStartAndSubmitAssignmentInCourses() throws InterruptedException, AWTException {

        String assignmentNameForCorrect = CorrectAnswerExecutor_PF.assignmentNameForCorrect.get();
        System.out.println("Want to Search assignment In List: " + assignmentNameForCorrect);

// get all assignment name spans inside <h6>
        List<WebElement> assignmentNames = driver.findElements(
                By.xpath("//div[contains(@class,'cardContainer')]//h6/span")
        );

        boolean found = false;

        for (WebElement assignment : assignmentNames) {
            String actualName = assignment.getText().trim();
            System.out.println("Assignment: " + actualName);

            if (actualName.equalsIgnoreCase(assignmentNameForCorrect)) {
                TestRunner.getTest().log(Status.PASS,
                        "Test Case Passed: Assignment '" + assignmentNameForCorrect + "' found in Courses List");
                found = true;

                try {
                    // Look for START or RESUME button inside this card
                    WebElement startOrResumeButton = assignment.findElement(
                            By.xpath(".//ancestor::div[contains(@class,'cardContainer')]//button[.//span[@type='START' or @type='RESUME']]")
                    );

                    if (startOrResumeButton.isDisplayed()) {
                        startOrResumeButton.click();
                        TestRunner.getTest().log(Status.PASS,
                                "Successfully clicked START/RESUME button for assignment: " + actualName);

                        System.out.println("Assignment started");
                        Thread.sleep(3000);

                        studentExecutor.handleTeacherInstructionsDialog();
                        correctAnswerExecutorPf.AttemptAndSubmitWithCorrectAnswers();
                        Thread.sleep(2000);
                    } else {
                        System.out.println("START/RESUME button is not displayed for assignment: " + actualName);
                    }

                } catch (NoSuchElementException e) {
                    TestRunner.getTest().log(Status.FAIL,
                            "START/RESUME button not found for assignment: " + actualName);
                    System.out.println("START/RESUME button not found for assignment: " + actualName);
                }
                break;
            }
        }

// if not found, fail test case
        if (!found) {
            TestRunner.getTest().log(Status.FAIL,
                    "Test Case Failed: Assignment '" + assignmentNameForCorrect + "' not found in Courses Assignment List");
            Assert.fail("Assignment '" + assignmentNameForCorrect + "' not found in Courses Assignment List");
        }

    }
}
