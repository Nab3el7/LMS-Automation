package pageFactory.Classes;

import StepDefinitions.ClassesModule.AddClassSteps;
import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Filters_PF;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

import static org.openqa.selenium.By.tagName;

public class AddClass_PF {

    public WebDriverWait wait;
    Helper helper;
    Filters_PF filtersPF;

    public static String selectedSchool;
    public static String className;


    @FindBy(xpath = "//div[@aria-label='Classes Module']")
    WebElement link_Class;

    @FindBy(xpath = "//button[normalize-space()='Add Class']")
    WebElement btn_AddClass;

    @FindBy(xpath = "//input[@id='textField-className']")
    WebElement edt_Classname;

    @FindBy(xpath = "//input[contains(@id, 'SelectTextFieldsSearch')]/parent::div")
    WebElement dropDown_SchoolName;

    @FindBy(xpath = "//label[text()='Status']/following-sibling::div//div[@role='button' or @role='combobox']")
    WebElement dropDown_SchoolStatus;

    @FindBy(xpath = "//div[@id='selectField-Courses']")
    WebElement dropDown_Courses;

    @FindBy(xpath = "//input[@id='textField-period']")
    WebElement edt_CoursePeriod;

    @FindBy(xpath = "//input[@placeholder='Select Course Content']")
    WebElement dropDown_CourseContent;

    @FindBy(xpath = "//button[normalize-space()='Add Co-Teacher']")
    WebElement btn_AddCoTeacher;

    @FindBy(xpath = "//button[@id='btn-nextClasses']")
    WebElement btn_Next;

    @FindBy(xpath = "//div[contains(@class, 'stepAddStudentsTable')]")
    WebElement table_AllStudents;

    @FindBy(xpath = "//button[normalize-space()='Add New']")
    WebElement btn_AddNewStudent;

    @FindBy(xpath = "//button[normalize-space()='Save/Next']")
    WebElement btn_SaveNext;

    @FindBy(xpath = "//input[@name='stdFirstName']")
    WebElement edt_NewStdFName;

    @FindBy(xpath = "//input[@name='stdMiddleName']")
    WebElement edt_NewStdMName;

    @FindBy(xpath = "//input[@name='stdLastName']")
    WebElement edt_NewStdLName;

    @FindBy(xpath = "//input[@name='login']")
    WebElement edt_NewStdEmail;

    @FindBy(xpath = "//input[@name='stdPassword']")
    WebElement edt_NewStdPassword;

    @FindBy(xpath = "//input[@name='stdConfirmPassword']")
    WebElement edt_NewStdConfirmPassword;

    @FindBy(xpath = "//label[text()='Grade']/following-sibling::div//div[@role='button' or @role='combobox']")
    WebElement dropDown_NewStdGrade;

    @FindBy(xpath = "//div[contains(@aria-label,'boy koala')]")
    WebElement img_NewStdAvatar;

    @FindBy(xpath = "//button[normalize-space()='Save']")
    WebElement btn_Save;


    WebDriver driver;
    public AddClass_PF(WebDriver driver) {   //constructor
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
        filtersPF = new Filters_PF(driver);
        helper = new Helper();
    }

    public void SideNavBarAndClickOnClass() throws InterruptedException {
        System.out.println("I'm in checking the side navbar and click on Classes");
        TestRunner.getTest().log(Status.INFO, "I'm in checking the side navbar and click on Classes Module");

        Thread.sleep(1000);

        WebElement navBar = driver.findElement(By.xpath("//div[@class='navigation']"));

        List<WebElement> totalLinks = navBar.findElements(tagName("a"));

        for (WebElement link : totalLinks) {
            String hrefValue = link.getAttribute("href");
            System.out.println("Link is: " + hrefValue);
        }

        // Wait for the backdrop/overlay to disappear if it exists
        try {
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.className("MuiBackdrop-root")));
            TestRunner.getTest().log(Status.INFO, "Backdrop disappeared");
        } catch (TimeoutException e) {
            TestRunner.getTest().log(Status.INFO, "No backdrop found or already disappeared");
        }

        if (link_Class.isDisplayed()) {
            try {
                // Wait for element to be clickable
                wait.until(ExpectedConditions.elementToBeClickable(link_Class));
                link_Class.click();
                TestRunner.getTest().log(Status.PASS, "Testcase Passed   :   Side Navbar Shows and Class link clicked successfully");
            } catch (ElementClickInterceptedException e) {
                // If click is intercepted by backdrop, use JavaScript click as fallback
                TestRunner.getTest().log(Status.INFO, "Click intercepted, using JavaScript click");
                ((JavascriptExecutor) driver).executeScript("arguments[0].click();", link_Class);
                TestRunner.getTest().log(Status.PASS, "Testcase Passed   :   Side Navbar Shows and Class link clicked successfully (via JavaScript)");
            }
        } else {
            TestRunner.getTest().log(Status.FAIL, "Testcase Failed   :  Side navbar not shows and Class link not clicked");
        }

    }

    public void ClassDashboard() {
        System.out.println("I'm in class dashboard");
        TestRunner.getTest().log(Status.INFO, "I'm in MY classes dashboard");


        WebElement breadCrumbOfClass = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ol[contains(@class, 'MuiBreadcrumbs')]")));
        System.out.println("Class BreadCrumb is: " + breadCrumbOfClass.getText());

        // Wait for elements to be present (headless-compatible)
        // Wait for each element individually with timeout handling
        try {
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class, 'ClassesDashboardLeftPanel')]")));
            TestRunner.getTest().log(Status.INFO, "Left panel found");
        } catch (TimeoutException e) {
            TestRunner.getTest().log(Status.WARNING, "Left panel not found within timeout: " + e.getMessage());
        }
        
        try {
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class, 'ClassesDashboardRightPanel')]")));
            TestRunner.getTest().log(Status.INFO, "Right panel found");
        } catch (TimeoutException e) {
            TestRunner.getTest().log(Status.WARNING, "Right panel not found within timeout: " + e.getMessage());
        }
        
        try {
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class, 'selectTextFieldsWrapper')]")));
            TestRunner.getTest().log(Status.INFO, "Select wrapper found");
        } catch (TimeoutException e) {
            TestRunner.getTest().log(Status.WARNING, "Select wrapper not found within timeout: " + e.getMessage());
        }
        
        // Additional wait to ensure elements are ready (small delay for rendering in headless)
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ie) {
            Thread.currentThread().interrupt();
        }

        TestRunner.getTest().log(Status.PASS, "Testcase Passed   :  MY Classes dashboard all element visible");


    }

    public void clickOnAddClass(){
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Add Class']")));
        if (btn_AddClass.isDisplayed() && btn_AddClass.isEnabled()) {
            btn_AddClass.click();
            TestRunner.getTest().log(Status.PASS, "Testcase Passed   :  Add class button successfully");
        } else {
            TestRunner.getTest().log(Status.FAIL, "Testcase Failed   :  Add class button disabled");
            throw new RuntimeException("Add class button disabled");
        }

    }

    public void clickOnAdCoTeacher(){
        btn_AddCoTeacher.click();
        TestRunner.getTest().log(Status.PASS, "Testcase Passed   : Add Co Teacher Button clicked successfully ");

    }

    public void clickOnNextButton(){
        btn_Next.click();
        TestRunner.getTest().log(Status.PASS, "Testcase Passed   : Next Button clicked successfully");


    }

    public void clickOnAddNewStudent(){
        btn_AddNewStudent.click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@role='dialog']")));
        TestRunner.getTest().log(Status.PASS, "Test Case Passed : Add new student button click successfully ");
    }

    public void clickOnSaveNextButton(){
        wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@role='dialog']")));

        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].click();", btn_SaveNext);
        TestRunner.getTest().log(Status.PASS, "Test Case Passed : Click and Save next Button successfully ");

    }

    public void EnterClassNewStdAvatar(){
        img_NewStdAvatar.click();
        TestRunner.getTest().log(Status.PASS, "Test Case Passed : New student Avatar enter successfully ");

    }

    public void clickOnSave(){
        btn_Save.click();
        System.out.println("Save Button clicked Successfully");
        TestRunner.getTest().log(Status.PASS, "Test Case Passed : Save Button clicked Successfully");
    }

    public void SaveClassNewStd(){
        WebElement dialog = driver.findElement(By.xpath("//div[@role='dialog']"));
        WebElement dialogSaveButton = dialog.findElement(By.xpath("//div[contains(@class,'btnContainer')]"));
        dialogSaveButton.click();

        WebElement successMessageElement = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='rrt-middle-container']//div[@class='rrt-text']")));

        String successMessage = successMessageElement.getText();
        System.out.println("Alert Message is: " + successMessage);

        TestRunner.getTest().log(Status.PASS, "Test Case Passed : New Class New Student Save Message successfully ");

    }

    public void EnterClassName(){
        edt_Classname.click();
        ((JavascriptExecutor) driver).executeScript("arguments[0].value='';", edt_Classname);
        className = generateRandomClassName("Automated Class ");
        edt_Classname.sendKeys(className);
        TestRunner.getTest().log(Status.INFO, "Entered Class name is:" + className);
        TestRunner.getTest().log(Status.PASS, "Test Case Passed : Class Name Enter successfully ");


    }

    public String getClassName() {
        return className;
    }

    public void SelectSchoolName() throws InterruptedException{
        dropDown_SchoolName.click();
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//ul[@role='listbox']")));
        List<WebElement> SchoolNameOptions = driver.findElements(By.xpath("//ul[@role='listbox']//li"));
        System.out.println("Total schools: " + SchoolNameOptions.size());
        selectedSchool = helper.selectValueFromDropdown(SchoolNameOptions);
        System.out.println("Selected School Name: " + selectedSchool);
        TestRunner.getTest().log(Status.INFO, "Selected School Name:" + selectedSchool);
        TestRunner.getTest().log(Status.PASS, "Test Case Passed : School Name Select successfully");

    }

    public String getSelectedSchool() {
        return selectedSchool;
    }

    public void SelectSchoolStatus() throws InterruptedException {
        dropDown_SchoolStatus.click();
        List<WebElement> SchoolStatusOptions = dropDown_SchoolStatus.findElements(By.xpath("//ul[@role='listbox']/li"));
//        selectRandomValueFromDropdown(SchoolStatusOptions);
        String schoolStatus = helper.selectValueFromDropdown(SchoolStatusOptions);
        TestRunner.getTest().log(Status.INFO, "Selected School Status Name:" + schoolStatus);
        TestRunner.getTest().log(Status.PASS, "Test Case Passed : School Status Select successfully ");

    }

    public void SelectCourses() throws InterruptedException{
        dropDown_Courses.click();
        List<WebElement> SchoolCoursesOptions = dropDown_Courses.findElements(By.xpath("//ul[@role='listbox']/li"));
        helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
//        selectRandomValueFromDropdown(SchoolCoursesOptions);
        String selectCourse = helper.selectValueFromDropdown(SchoolCoursesOptions);
        TestRunner.getTest().log(Status.INFO, "Selected Course  Name:" + selectCourse);
        TestRunner.getTest().log(Status.PASS, "Test Case Passed : Course Select successfully ");
    }

    public void EnterCoursePeriodName(){
        edt_CoursePeriod.click();
        ((JavascriptExecutor) driver).executeScript("arguments[0].value='';", edt_CoursePeriod);
        edt_CoursePeriod.sendKeys("40");

        TestRunner.getTest().log(Status.PASS, "Test Case Passed : Course Period enter successfully");

    }

    public void SelectCourseContent() throws InterruptedException{
        dropDown_CourseContent.click();
        List<WebElement> CourseContentOptions = dropDown_CourseContent.findElements(By.xpath("//ul[@role='listbox']/li"));
//        selectRandomValueFromDropdown(CourseContentOptions);
        String selectCourseContent = helper.selectValueFromDropdown(CourseContentOptions);
        TestRunner.getTest().log(Status.INFO, "Selected Course Content Name:" + selectCourseContent);
        TestRunner.getTest().log(Status.PASS, "Test Case Passed : Course Content enter successfully");
    }

    public void SelectStudentAllGrades() {
        WebElement dropdownGrades = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//label[text()='All Grades']/following-sibling::div//div[@role='button' or @role='combobox']")));
        dropdownGrades.click();

        List<WebElement> StudentAllGradesOptions = driver.findElements(By.xpath("//ul[@role='listbox']//li"));

        if (!StudentAllGradesOptions.isEmpty()) {
            List<WebElement> filteredOptions = new ArrayList<>();
            for (WebElement option : StudentAllGradesOptions) {
                String optionText = option.getText();
                System.out.println("Option Text is: " + optionText);
                if (!optionText.equalsIgnoreCase("Other") && !optionText.equalsIgnoreCase("Ungraded") && !optionText.equalsIgnoreCase("Unknown")) {
                    filteredOptions.add(option);
                }
            }

            if (!filteredOptions.isEmpty()) {
                selectRandomValueFromDropdown(filteredOptions);
                String selectedGrade = driver.findElement(By.xpath("//label[text()='All Grades']/following-sibling::div//div[@role='button' or @role='combobox']")).getText();
                System.out.println("Selected Grade: " + selectedGrade);
                TestRunner.getTest().log(Status.INFO, "Selected Grade: " + selectedGrade);
                TestRunner.getTest().log(Status.PASS, "Test Case Passed : Grades Select successfully ");

            } else {
                System.out.println("No valid options available to select.");
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  No valid options available to select");
//                throw new RuntimeException("No  Student All Grades Found.");

            }

        } else {
            System.out.println("No options available to select.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : No options available to select.");
        }
    }

    public void GetTableAllStudents() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Get all students and select students into table");

        try {
            // Null check
            if (table_AllStudents == null) {
                System.out.println("Table element is not initialized.");
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Table element is not initialized.");
                return;
            }

            // Visibility check
            if (!table_AllStudents.isDisplayed()) {
                System.out.println("Table is not displayed.");
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Table is not displayed.");
                return;
            }

            // Check for "No Detail Found"
            List<WebElement> noDetailElements = table_AllStudents.findElements(By.xpath(".//div[contains(text(), 'No Detail Found')]"));
            if (!noDetailElements.isEmpty()) {
                System.out.println("No students exist in this grade.");
                TestRunner.getTest().log(Status.WARNING, "No students exist in this grade. Trying to select another grade...");
                handleEmptyStudentTable();
                return;
            }

            // Get student rows
            List<WebElement> rows_Students = table_AllStudents.findElements(By.xpath(".//table//tbody//tr"));
            System.out.println("Total Students are: " + rows_Students.size());
            TestRunner.getTest().log(Status.INFO, "Total Students are: " + rows_Students.size());

            if (rows_Students.size() <= 1) {
                System.out.println("Not enough students to select two.");
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Less than 2 students found.");
                return;
            }

            Collections.shuffle(rows_Students);
            int selectedCount = 0;

            for (int i = 0; i < 2 && i < rows_Students.size(); i++) {
                WebElement std_row = rows_Students.get(i);
                try {
                    WebElement checkbox = std_row.findElement(By.xpath(".//td[1]//input[@type='checkbox']"));
                    if (!checkbox.isSelected()) {
                        checkbox.click();
                    }

                    boolean isSelected = checkbox.isSelected();
                    System.out.println("Student at index " + i + " checkbox selected: " + isSelected);
                    TestRunner.getTest().log(Status.INFO, "Student at index " + i + " checkbox selected: " + isSelected);

                    if (isSelected) {
                        selectedCount++;
                    }
                } catch (NoSuchElementException e) {
                    System.out.println("Checkbox not found in row " + i);
                    TestRunner.getTest().log(Status.WARNING, "Checkbox not found in row " + i);
                }
            }

            System.out.println("Number of students selected: " + selectedCount);
            TestRunner.getTest().log(Status.INFO, "Number of students selected: " + selectedCount);

            if (selectedCount == 2) {
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: Random 2 students selected successfully.");
            } else {
                TestRunner.getTest().log(Status.WARNING, "Only " + selectedCount + " students were selected.");
            }

        } catch (StaleElementReferenceException e) {
            System.out.println("StaleElementReferenceException caught, please retry.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: StaleElementReferenceException occurred.");
            throw e;

        } catch (Exception e) {
            System.out.println("Exception occurred: " + e.getMessage());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception occurred - " + e.getMessage());
            throw e;
        }
    }

    public void handleEmptyStudentTable() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Checking if student details exist in the table");

        WebElement tableBody = table_AllStudents.findElement(By.xpath(".//table//tbody"));
        String tableText = tableBody.getText().trim();

        if (tableText.equalsIgnoreCase("No Detail Found")) {
            System.out.println("No students exist in this grade.");
            TestRunner.getTest().log(Status.INFO, "No students exist in this grade.");

            // Call method to select another grade
            SelectStudentAllGrades();

            Thread.sleep(3000);

            // Retry fetching students again after selecting another grade
            GetTableAllStudents();
        } else {
            GetTableAllStudents();
        }
    }

    public void EnterClassNewStdFName(){
        edt_NewStdFName.click();
        ((JavascriptExecutor) driver).executeScript("arguments[0].value='';", edt_NewStdFName);
        String randomClassStdFName = generateRandomClassName("Automated Student ");
        TestRunner.getTest().log(Status.INFO, "Student First name: " + randomClassStdFName);
        edt_NewStdFName.sendKeys(randomClassStdFName);
        TestRunner.getTest().log(Status.PASS, "Test Case Passed :  First Enter successfully ");

    }

    public void EnterClassNewStdMName(){
        edt_NewStdMName.click();
        ((JavascriptExecutor) driver).executeScript("arguments[0].value='';", edt_NewStdMName);
        String randomClassNewStdMName = generateRandomClassName("Automated Student ");
        TestRunner.getTest().log(Status.INFO, "Student Middle name: " + randomClassNewStdMName);
        edt_NewStdMName.sendKeys(randomClassNewStdMName);
        TestRunner.getTest().log(Status.PASS, "Test Case Passed : Middle Name  Enter successfully");

    }

    public void EnterClassNewStdLName(){
        edt_NewStdLName.click();
        ((JavascriptExecutor) driver).executeScript("arguments[0].value='';", edt_NewStdLName);
        String randomClassNewStdLName = generateRandomClassName("Automated Student ");
        TestRunner.getTest().log(Status.INFO, "Student Last name: " + randomClassNewStdLName);
        edt_NewStdLName.sendKeys(randomClassNewStdLName);
        TestRunner.getTest().log(Status.PASS, "Test Case Passed : Last Name  Enter successfully ");

    }

    public void EnterClassNewStdEmail(){
        edt_NewStdEmail.click();
        ((JavascriptExecutor) driver).executeScript("arguments[0].value='';", edt_NewStdEmail);
        String randomClassNewStdEmail = randomClassNewStdEmail("automatedstd");  //automatedstd839@yopmail.com
        TestRunner.getTest().log(Status.INFO, "Student Email: " + randomClassNewStdEmail);
        edt_NewStdEmail.sendKeys(randomClassNewStdEmail);
        TestRunner.getTest().log(Status.PASS, "Test Case Passed :  Email  Enter successfully");
    }

    public void EnterClassNewStdPassword(){
        edt_NewStdPassword.click();
        ((JavascriptExecutor) driver).executeScript("arguments[0].value='';", edt_NewStdPassword);
        edt_NewStdPassword.sendKeys("P@ssw0rd!#");
        TestRunner.getTest().log(Status.PASS, "Test Case Passed :  Password  Enter successfully");

    }

    public void EnterClassNewStdConfirmPassword() {
        edt_NewStdConfirmPassword.click();
        ((JavascriptExecutor) driver).executeScript("arguments[0].value='';", edt_NewStdConfirmPassword);
        edt_NewStdConfirmPassword.sendKeys("P@ssw0rd!#");
        TestRunner.getTest().log(Status.PASS, "Test Case Passed : Confirm Password  Enter successfully ");

    }

    public void SelectClassNewStdGrade() throws InterruptedException {
        dropDown_NewStdGrade.click();
        List<WebElement> StudentAllGradesOptions = dropDown_NewStdGrade.findElements(By.xpath("//ul[@role='listbox']/li"));
        String selectedNewStdGrade = helper.selectValueFromDropdown(StudentAllGradesOptions);
        TestRunner.getTest().log(Status.INFO, "New Student Grade is:" + selectedNewStdGrade);
        System.out.println("New Student Grade is: " + selectedNewStdGrade);
        TestRunner.getTest().log(Status.PASS, "Test Case Passed : Grade select successfully");

    }

    public void GetTableClassInfo(){
        String tbl_ClassInfo = driver.findElement(By.xpath("//div[@class='break-all']")).getText();
        System.out.println(tbl_ClassInfo);
        TestRunner.getTest().log(Status.INFO, "Student Info Table " + tbl_ClassInfo);
        TestRunner.getTest().log(Status.PASS, "Test Case Passed : Class Info Table get Successfully ");
    }

    public void GetTableStudentInfo(){
        String tbl_StudentInfo = driver.findElement(By.xpath("//*[contains(@class, 'confirmStdTable')]")).getText();
        System.out.println(tbl_StudentInfo);
        TestRunner.getTest().log(Status.INFO, "Student Info Table " + tbl_StudentInfo);
        TestRunner.getTest().log(Status.PASS, "Test Case Passed : Student Info Table get Successfully");

    }

    public String generateRandomClassName(String prefix) {
        String characters = "ABC123456789";
        StringBuilder randomClassName = new StringBuilder();
        Random random = new Random();
        int length = 4;
        randomClassName.append(prefix);
        for (int i = 0; i < length; i++) {
            randomClassName.append(characters.charAt(random.nextInt(characters.length())));
        }
        return randomClassName.toString();
    }

    public String selectRandomValueFromDropdown(List<WebElement> options) {
        if (options.isEmpty()) {
            throw new IllegalArgumentException("The options list must not be empty");
        }
        Random random = new Random();
        int index = random.nextInt(options.size());
        WebElement selectedOption = options.get(index);
        selectedOption.click();
        System.out.println("Selected value: " + selectedOption.getText());
        return selectedOption.getText();
    }

    public String randomClassNewStdEmail(String prefix) {
        Random randemail = new Random();
        int randomInt = randemail.nextInt(1000);
        return prefix + randomInt + "@givmail.com";
    }
}
