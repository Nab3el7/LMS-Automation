package pageFactory.Classes;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

import static org.openqa.selenium.By.tagName;
import static pageFactory.Classes.AddClass_PF.className;
import static pageFactory.StudentsModule.AddNewStudent_PF.randomClassNewStdEmail;
import static pageFactory.StudentsModule.AddNewStudent_PF.selectedGrade;

public class EditClass_PF {
    public WebDriverWait wait;
    WebDriver driver;
    Helper helper;

    static String UpdateCoursePeriodValue = "50";

    @FindBy(xpath = "//input[@id='textField-period']")
    WebElement CoursePeriod;

    @FindBy(xpath = "//input[@placeholder='Search student by keyword']")
    WebElement SearchStudentByKeyword;

    @FindBy(xpath = "//div[@aria-label='User Dashboard']")
    WebElement link_Dashboard;

    @FindBy(xpath = "//div[text()='My Courses']//button[@aria-label='setting']")
    WebElement button_MyCourseSetting;

    @FindBy(xpath = "//div[@id='demo-multiple-chip']")
    WebElement Dropdown_MultipleCourses;

    @FindBy(xpath = "//ul[@role='listbox']")
    WebElement Dropdown_Courses;

    @FindBy(xpath = "//button[normalize-space()='Next']")
    WebElement button_Next;

    @FindBy(xpath = "//div[contains(@class, 'ManageCourseClass')]")
    WebElement div_ManageCourse;

    public EditClass_PF(WebDriver driver) {
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
        helper = new Helper();
    }


    public void clickEditButton() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm in to Click Edit Button");
        Thread.sleep(500);

        WebElement editDots= driver.findElement(By.xpath("//button[@aria-label='DropDownButtom']"));
        editDots.click();

        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//ul[@role='menu']//li")));

        WebElement edit_btn= driver.findElement(By.xpath(".//span[normalize-space()='Edit']"));
        edit_btn.click();
        helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
        TestRunner.getTest().log(Status.PASS, "Testcase Passed   :  Edit button click successfully");

    }

    public void editClassInfo() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm in edit class Information Screen");
        Thread.sleep(2000);
        System.out.println("I'm in edit class Information Screen");

        wait.until(ExpectedConditions.elementToBeClickable(CoursePeriod));

        String existingCoursePeriod = CoursePeriod.getAttribute("value");
        System.out.println("Existing Course Period: " + existingCoursePeriod);
        TestRunner.getTest().log(Status.INFO, "Existing Course Period: " + existingCoursePeriod);
        Actions actions = new Actions(driver);

        CoursePeriod.click();

        for (int i = 0; i < existingCoursePeriod.length(); i++) {
            actions.sendKeys(Keys.BACK_SPACE).perform();
        }

        ((JavascriptExecutor) driver).executeScript("arguments[0].value='';", CoursePeriod);

        CoursePeriod.sendKeys(UpdateCoursePeriodValue);

        String updatedCoursePeriod = CoursePeriod.getAttribute("value");
        TestRunner.getTest().log(Status.INFO, "Updated Course Period: " + updatedCoursePeriod);
        System.out.println("Updated Course Period: " + updatedCoursePeriod);

        TestRunner.getTest().log(Status.PASS, "Testcase Passed   :  Edit Information successfully");

    }

    public void SelectNewStudentGradeForEdit() {
        TestRunner.getTest().log(Status.INFO, "I'm in select new student Grade for Edit");
        WebElement dropdownGrades = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//label[text()='All Grades']/following-sibling::div//div[@role='button' or @role='combobox']")));
        dropdownGrades.click();

        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//ul[@role='listbox']//li")));
        List<WebElement> StudentAllGradesOptions = driver.findElements(By.xpath("//ul[@role='listbox']//li"));

        if (!StudentAllGradesOptions.isEmpty()) {
            boolean gradeFound = false;

            for (WebElement option : StudentAllGradesOptions) {
                String optionText = option.getText();
                System.out.println("Option Text is: " + optionText);

                if (optionText.equals(selectedGrade)) {
                    option.click();
                    gradeFound = true;
                    break;
                }
            }

            if (gradeFound) {
                TestRunner.getTest().log(Status.INFO, "Selected Grade:" + selectedGrade);
                System.out.println("Selected Grade: " + selectedGrade);
                TestRunner.getTest().log(Status.PASS, "Test Case Passed   :   Grade " + selectedGrade + " selected successfully.");
            } else {
                System.out.println("Selected grade '" + selectedGrade + "' not found in the dropdown.");
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  Grade " + selectedGrade + " not found in dropdown.");
            }
        } else {
            System.out.println("No options available to select.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  No grades available in the dropdown.");
        }
    }

    public void editClassInfoSearchStudentByKeyword() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm in Edit Class Information search student by keyword");
        Thread.sleep(2000);

        wait.until(ExpectedConditions.elementToBeClickable(SearchStudentByKeyword));

        if (SearchStudentByKeyword.isEnabled() && SearchStudentByKeyword.isDisplayed()) {
            SearchStudentByKeyword.click();
            System.out.println("Clicked on the search input for student keyword search.");

            System.out.println("Search student: " + randomClassNewStdEmail);
            TestRunner.getTest().log(Status.INFO, "Searching for student with email: " + randomClassNewStdEmail);

            SearchStudentByKeyword.sendKeys(randomClassNewStdEmail);
            TestRunner.getTest().log(Status.PASS, "Testcase Passed   :  Entered student email into the search input");

        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  Search input is either not enabled or not displayed.");
        }
    }


    public void verifyUpdatedClassPeriod() {
        TestRunner.getTest().log(Status.INFO, "I'm in Verify Updated Class Period");
        List<WebElement> rows = driver.findElements(By.xpath("//table[contains(@class,'MuiTable-root')]//tbody//tr"));

        boolean periodFound = false;
        for (WebElement row : rows) {
            String periodText = row.findElement(By.xpath(".//td[contains(@class,'cell-period')]//div")).getText().trim();

            if (periodText.equals(UpdateCoursePeriodValue)) {
                periodFound = true;
                break;
            }
        }

        if (periodFound) {
            TestRunner.getTest().log(Status.INFO, "The class period has been updated to: " + UpdateCoursePeriodValue);
            System.out.println("The class period has been updated to: " + UpdateCoursePeriodValue);
            TestRunner.getTest().log(Status.PASS, "Testcase Passed   :  Edited Information successfully");


        } else {
            System.out.println("The class period has not been updated or not found.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : The class period has not been updated or not found.");
//            throw new RuntimeException("Class information is not Updated.");
        }
    }

    public void SideNavBarAndClickOnDashboard() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm in checking the side navbar and click on Class");
        System.out.println("I'm in checking the side navbar and click on Class");
        Thread.sleep(1000);

        WebElement navBar = driver.findElement(By.xpath("//div[@class='navigation']"));

        List<WebElement> totalLinks = navBar.findElements(tagName("a"));

        for (WebElement link : totalLinks) {
            String hrefValue = link.getAttribute("href");
            System.out.println("Link is: " + hrefValue);
        }

        link_Dashboard.click();
        TestRunner.getTest().log(Status.PASS, "Testcase Passed   :  Dashboard link clicked successfully");
    }

    public void clickOnMyCourseSetting() {
        TestRunner.getTest().log(Status.INFO, "I'm in Click on My Course Setting");
        wait.until(ExpectedConditions.elementToBeClickable(button_MyCourseSetting));

        if (button_MyCourseSetting.isEnabled()) {
            button_MyCourseSetting.click();
            TestRunner.getTest().log(Status.PASS, "Testcase Passed   : My Course Setting button clicked successfully");
        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : My Course Setting button is not enabled.");
        }
    }

    public void clickOnDropdownCourses() {
        TestRunner.getTest().log(Status.INFO, "I'm in Click on Courses Dropdown");
        wait.until(ExpectedConditions.elementToBeClickable(Dropdown_MultipleCourses));

        if (Dropdown_MultipleCourses.isEnabled()) {
            Dropdown_MultipleCourses.click();
            TestRunner.getTest().log(Status.PASS, "Testcase Passed   :  Course dropdown clicked successfully");

            WebElement CoursesDropdown = wait.until(ExpectedConditions.elementToBeClickable(Dropdown_Courses));

            List<WebElement> CoursesList = CoursesDropdown.findElements(By.xpath(".//li"));

            if (CoursesList.isEmpty()) {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : No courses available in the dropdown list");
            } else {
                for (WebElement course : CoursesList) {
                    WebElement addButton = course.findElement(By.xpath(".//child::button"));
                    addButton.click();
                    TestRunner.getTest().log(Status.INFO, "Course added:"+  course.getText());
                }
                TestRunner.getTest().log(Status.PASS, "Testcase Passed   :  All available courses were added successfully.");
            }

        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : Course dropdown is not enabled.");
        }
    }

    public void clickOnMyCourseNextButton() {
        TestRunner.getTest().log(Status.INFO, "Click On My Courses Next Button");
        wait.until(ExpectedConditions.elementToBeClickable(button_Next));

        if (button_Next.isEnabled()) {
            button_Next.click();
            TestRunner.getTest().log(Status.PASS, "Testcase Passed   :  My Course Next button clicked successfully.");
        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : My Course Next button is not enabled.");
        }
    }

    public void clickOnListManagedCourses() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "Click on List managed Courses");
        WebElement divClasses= wait.until(ExpectedConditions.elementToBeClickable(div_ManageCourse));

        if (div_ManageCourse.isEnabled()) {

            List<WebElement> listClasses = divClasses.findElements(By.xpath(".//div[contains(@class, 'headingAvaiable')]/child::span"));

            System.out.println("Class name: " + className);
            TestRunner.getTest().log(Status.INFO, "Looking for class:" + className);

            boolean classFound = false;

            for (WebElement classElement : listClasses) {
                String currentClassName = classElement.getText();
                System.out.println("Class name is: " + currentClassName);

                if (currentClassName.equals(className)) {
                    classElement.getText();
                    helper.scrollToElement(driver, classElement);
                    Thread.sleep(2000);
                    WebElement classDropdown = classElement.findElement(By.xpath("/following-sibling::div"));
                    if (classDropdown.isEnabled() && classDropdown.isDisplayed()) {
                        classDropdown.click();

                        WebElement CoursesDropdown = wait.until(ExpectedConditions.elementToBeClickable(Dropdown_Courses));

                        List<WebElement> CoursesList = CoursesDropdown.findElements(By.xpath(".//li"));

                        if (CoursesList.isEmpty()) {
                            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : No courses available in the class dropdown list.");
                        } else {
                            for (WebElement course : CoursesList) {
                                course.click();
                                WebElement addButton = course.findElement(By.xpath(".//child::button"));
                                addButton.click();
                                TestRunner.getTest().log(Status.INFO, "Course added in new class: " + course.getText());
                                break;
                            }
                            TestRunner.getTest().log(Status.PASS, "Testcase Passed   :  All available courses were added successfully in new class.");
                        }

                    }

                    TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  Class " + className + " selected successfully.");

                    classFound = true;
                }
            }

            if (!classFound) {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : Class " + className + "' not found in the list");

            }
        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : Manage Course dropdown is not enabled");
        }
    }

}
