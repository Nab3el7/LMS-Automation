package pageFactory.Classes;

import StepDefinitions.ClassesModule.AddClassSteps;
import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.junit.experimental.theories.Theories;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Filters_PF;

import java.time.Duration;
import java.util.List;

public class ClassFilters_PF {

    public WebDriverWait wait;
    WebDriver driver;
    Filters_PF filtersPF;
    AddClass_PF addClassPF;
    Helper helper;


    public static String className;
    String searchClassByKeyword;

    @FindBy(xpath = "//button[normalize-space()='Apply Filters']")
    WebElement btn_SchoolApplyFilter;

    @FindBy(xpath = "//div[contains(@class, 'ClassesDashboardRightPanel')]")
    WebElement classesTable;

    public ClassFilters_PF(WebDriver driver) {
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
        filtersPF = new Filters_PF(driver);
        addClassPF = new AddClass_PF(driver);
        helper = new Helper();
    }

    public void selectSchoolDistrict() throws InterruptedException {
        filtersPF.select_District();
    }

    public void selectSchool(String schoolName) throws InterruptedException {
        filtersPF.select_School(schoolName);
    }

    public void selectSchoolTeacher() throws InterruptedException {
        Thread.sleep(2000);
        filtersPF.select_teacher();

    }

    public void applySchoolFilter() {
        btn_SchoolApplyFilter.click();
        TestRunner.getTest().log(Status.PASS, "Testcase Passed   : Filter Button Clicked Successfully");


    }

    public void showsClassesIntoTable() throws InterruptedException {
//        Thread.sleep(3000);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class, 'ClassesDashboardRightPanel')]//tbody")));

        List<WebElement> rows = classesTable.findElements(By.xpath(".//tbody/tr"));

        if (!rows.isEmpty()) {
            System.out.println("Classes found in the table:");
            TestRunner.getTest().log(Status.INFO, "Classes found in the table:");
            for (int i = 0; i < rows.size(); i++) {
                WebElement row = rows.get(i);

                try {
                    WebElement classNameElement = row.findElement(By.xpath(".//td[contains(@class, 'cell-class')]//div[@class='classnamedisplay']"));
                    className = classNameElement.getText();
                    System.out.println("Class Name: " + className);
                    TestRunner.getTest().log(Status.INFO, "Class Name: " + className);

                    List<WebElement> cells = row.findElements(By.xpath(".//td"));
                    for (WebElement cell : cells) {
                        System.out.print(cell.getText() + "\t");
                    }
                    System.out.println();
                    TestRunner.getTest().log(Status.PASS, "Testcase Passed   : Classes Found in Table  Successfully");

                } catch (StaleElementReferenceException e) {
                    System.out.println("Stale element found, retrying...");

                    rows = classesTable.findElements(By.xpath(".//tbody/tr"));
                    row = rows.get(i);

                    WebElement classNameElement = row.findElement(By.xpath(".//td[contains(@class, 'cell-class')]//div[@class='classnamedisplay']"));
                    String className = classNameElement.getText();
                    System.out.println("Class Name: " + className);
                    TestRunner.getTest().log(Status.INFO, "Class Name: " + className);

                    List<WebElement> cells = row.findElements(By.xpath(".//td"));
                    for (WebElement cell : cells) {
                        System.out.print(cell.getText() + "\t");
                    }
                    System.out.println();
                    TestRunner.getTest().log(Status.PASS, "Testcase Passed   : Classes Found in Table  Successfully");
                }
            }
        } else {
            System.out.println("No searched classes found in the table.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : No New Class found in the table by searching");
//            throw new RuntimeException("No Search Classes Found...");
        }
        helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());

    }

    public void searchClassByName(){
        TestRunner.getTest().log(Status.INFO, "I'm in search Class By Name");
        WebElement right_panel= driver.findElement(By.xpath("//div[@class='right-panel']"));
        right_panel.isDisplayed();

        try {
            WebElement searchBox = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder='Search Class by keyword']")));
            if (searchBox.isDisplayed()) {
                searchBox.click();
                searchBox.clear();
                ((JavascriptExecutor) driver).executeScript("arguments[0].value='';", searchBox);
                searchClassByKeyword = addClassPF.getClassName();
                System.out.println("Search by class name: " + searchClassByKeyword);
                TestRunner.getTest().log(Status.INFO, "Search by class name: " + searchClassByKeyword);
                searchBox.sendKeys(searchClassByKeyword);

                Actions actions = new Actions(driver);
                actions.sendKeys(Keys.ENTER).perform();
                TestRunner.getTest().log(Status.PASS, "Testcase Passed   : Enter Search Student keyword Successfully");

                waitForTableToRefresh();
            } else {
                System.out.println("Search box is not displayed.");
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : Search box is not displayed");
//                throw new RuntimeException("Search Box not  Found.");
            }
        } catch (Exception e) {
            System.out.println("Search box is not available: " + e.getMessage());
        }


    }

    private void waitForTableToRefresh() {
        WebElement tableClasses = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class, 'ClassesDashboardRightPanel')]//tbody")));

        wait.until(ExpectedConditions.stalenessOf(tableClasses));

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(".//tr")));

        System.out.println("Table has refreshed.");
        TestRunner.getTest().log(Status.INFO, "Table has refreshed.");

    }

    public void verifySearchedClassByNameIntoTable(){
        if (className.contains(searchClassByKeyword)){
            System.out.println("Searched class found");
            TestRunner.getTest().log(Status.INFO, "Searched class found: " + searchClassByKeyword );
            TestRunner.getTest().log(Status.PASS, "Testcase Passed   : Search Class by keyword Successfully");

        } else {
            System.out.println("Searched class not found and search filter not working");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : Searched class not found and search filter not working");
//            throw new RuntimeException("No class is found table .");
        }
    }

}
