package pageFactory.Classes.Group;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class AddGroup_PF {

    public WebDriverWait wait;
    WebDriver driver;
    Helper helper;

    public static String className;
    public static String groupName;
    public static String specificClassForGroup = "FL Grade 5";
    private static final String searchStudentEmail = "david@gallopade.com";
            //"student9250@gmail.com";


    @FindBy(xpath = "//button[normalize-space()='Add Group']")
    WebElement btn_AddGroup;

    @FindBy(xpath = "//input[@id='textField-className']")
    WebElement edt_GroupName;

    @FindBy(xpath = "//label[contains(normalize-space(),'Select Classes')]/parent::div")
    WebElement select_GroupClass;

    @FindBy(xpath = "//div[contains(@class, 'stepAddStudentsTable')]//table")
    WebElement table_AllStudents;

    @FindBy(xpath = "//button[normalize-space()='Next' or normalize-space()='Save/Next']")
    WebElement btn_SaveNext;

    @FindBy(xpath = "//button[normalize-space()='Exit']")
    WebElement btn_Exit;

    @FindBy(xpath = "//div[contains(@class, 'ClassesDashboardRightPanel')]")
    WebElement classesTable;

    public AddGroup_PF(WebDriver driver) {   //constructor
        this.driver = Configurations.getDriver();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
        helper = new Helper();
    }

    public void clickOnAddGroup() {
        try {
            TestRunner.getTest().log(Status.INFO, "Attempting to click the 'Add Group' button");
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Add Group']")));
            wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Add Group']")));
            if (btn_AddGroup.isDisplayed() && btn_AddGroup.isEnabled()) {
                btn_AddGroup.click();
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: 'Add Group' button clicked successfully.");
            } else {
                TestRunner.getTest().log(Status.FAIL, "'Add Group' button is either not visible or not enabled.");
                throw new RuntimeException("'Add Group' button is not interactable.");
            }

        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "Exception occurred while clicking the 'Add Group' button: " + e.getMessage());
        }
    }

//    Page 1

    public void EnterNewGroupName() {
        TestRunner.getTest().log(Status.INFO, "Entering New Group Name");
        try {
            if (edt_GroupName.isDisplayed() && edt_GroupName.isEnabled()) {
                edt_GroupName.click();
                ((JavascriptExecutor) driver).executeScript("arguments[0].value='';", edt_GroupName);
                groupName = generateRandomNumber("AutomatedGroup");
                edt_GroupName.sendKeys(groupName);
                TestRunner.getTest().log(Status.INFO, "Entered Group name is: " + groupName);
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: Group name entered successfully.");
            } else {
                TestRunner.getTest().log(Status.FAIL, "Group name field is not displayed or not enabled.");
            }
        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "Exception occurred while entering group name: " + e.getMessage());
        }
    }

    public String getNewGroupName() {
        return groupName;
    }

    public void SelectNewGroupClass() {
        try {
            TestRunner.getTest().log(Status.INFO, "Attempting to select a specific class from the dropdown");

            if (select_GroupClass.isDisplayed() && select_GroupClass.isEnabled()) {
                select_GroupClass.click();

                WebElement listClasses = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[@role='listbox']")));
                List<WebElement> optionsClasses = listClasses.findElements(By.xpath(".//li"));

                int classCount = optionsClasses.size();
                TestRunner.getTest().log(Status.INFO, "Number of classes available: " + classCount);

                if (classCount == 0) {
                    TestRunner.getTest().log(Status.FAIL, "No options found in the Classes dropdown.");
                    throw new RuntimeException("No Classes found in dropdown.");
                }

                boolean classFound = false;
                for (WebElement option : optionsClasses) {
                    String className = option.getText();
                    if (className.equals(specificClassForGroup)) {
                        option.click();
                        TestRunner.getTest().log(Status.INFO, "Selected Class: " + specificClassForGroup);
                        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Class selected successfully.");
                        classFound = true;
                        break;
                    }
                }

                if (!classFound) {
                    TestRunner.getTest().log(Status.FAIL, "Specific class not found in the Classes dropdown: " + specificClassForGroup);
                    throw new RuntimeException("Specific class not found in dropdown: " + specificClassForGroup);
                }
            } else {
                TestRunner.getTest().log(Status.FAIL, "Class dropdown is either not displayed or not enabled.");
                throw new RuntimeException("Class dropdown is not interactable.");
            }

        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "Exception occurred while selecting a class: " + e.getMessage());
        }
    }

    public void EnterNewGroupDescription() throws InterruptedException{
        try {
            TestRunner.getTest().log(Status.INFO, "Attempting to enter a new group description");
            WebElement RichTextBoxBody = driver.findElement(By.xpath("//div[@class='tox-edit-area']/iframe"));

            driver.switchTo().frame(RichTextBoxBody);

            WebElement editGroupDescriptionTextBox = driver.findElement(By.xpath("//body[@id='tinymce']//p"));
            System.out.println("Edit text area is found");

            editGroupDescriptionTextBox.clear();

            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript("arguments[0].value='';", editGroupDescriptionTextBox);

            String randomGroupDescriptionText = helper.generateRandomText("Student Hint ");
            System.out.println(randomGroupDescriptionText);

            editGroupDescriptionTextBox.sendKeys(randomGroupDescriptionText);
            TestRunner.getTest().log(Status.INFO, "Group Description Text is: " + randomGroupDescriptionText);

            TestRunner.getTest().log(Status.PASS, "Test Case Passed   : New group description entered successfully");
        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "Exception occurred while entering group description: " + e.getMessage());
        } finally {
            driver.switchTo().defaultContent();
        }
    }

    public void clickOnGroupSaveNextButton() throws InterruptedException{
        Thread.sleep(5000);
        try {
            TestRunner.getTest().log(Status.INFO, "Attempting to click the 'Save & Next' button for the group");

            if (btn_SaveNext.isDisplayed() && btn_SaveNext.isEnabled()) {
                JavascriptExecutor js = (JavascriptExecutor) driver;
                js.executeScript("arguments[0].click();", btn_SaveNext);
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: 'Save & Next' button clicked successfully.");
            } else {
                TestRunner.getTest().log(Status.FAIL, "'Save & Next' button is either not visible or not enabled.");
                throw new RuntimeException("'Save & Next' button is not interactable.");
            }

        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "Exception occurred while clicking the 'Save & Next' button: " + e.getMessage());
        }
    }

//    Page 2

    public void GetTableAllStudentsAndSelect() {
        WebElement studentTable = null;
        try {
            TestRunner.getTest().log(Status.INFO, "Attempting to get student table and select student(s)");

            // Wait for table to be present (headless-compatible - checks presence not visibility)
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class, 'stepAddStudentsTable')]//table")));
            
            // Wait for at least one row to be present in the table
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class, 'stepAddStudentsTable')]//table//tbody//tr")));
            
            TestRunner.getTest().log(Status.INFO, "Student table is present and has rows");

            // Re-find the table element to avoid stale element issues
            studentTable = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class, 'stepAddStudentsTable')]//table")));
            
            List<WebElement> rows_Students = studentTable.findElements(By.xpath(".//tbody//tr"));
            int totalRows = rows_Students.size();
            TestRunner.getTest().log(Status.INFO, "Total students found in the table: " + totalRows);
            System.out.println("Total Students: " + totalRows);

            if (rows_Students.isEmpty()) {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: No rows found in the student table.");
                throw new RuntimeException("No rows found in the student table.");
            }

            int studentsToSelect = (totalRows > 2) ? 2 : 1;

            Collections.shuffle(rows_Students);
            int selectedCount = 0;

            for (int i = 0; i < studentsToSelect; i++) {
                boolean success = false;
                int retries = 2;

                while (!success && retries > 0) {
                    try {
                        // Re-fetch rows to avoid stale elements
                        rows_Students = studentTable.findElements(By.xpath(".//tbody//tr"));
                        WebElement std_row = rows_Students.get(i);
                        
                        // Find the checkbox input element
                        WebElement checkbox = std_row.findElement(By.xpath(".//td[1]//input[@type='checkbox']"));
                        
                        // Scroll to the row for visibility
                        helper.scrollToElement(driver, std_row);
                        
                        // Use JavaScript click directly (works better in headless mode)
                        // Don't wait for clickability as it may never become clickable in headless
                        if (!checkbox.isSelected()) {
                            try {
                                // Try clicking the label/parent element first (Material-UI pattern)
                                WebElement label = std_row.findElement(By.xpath(".//td[1]//label"));
                                ((JavascriptExecutor) driver).executeScript("arguments[0].click();", label);
                            } catch (Exception e1) {
                                // If label click fails, try clicking the checkbox directly with JavaScript
                                ((JavascriptExecutor) driver).executeScript("arguments[0].click();", checkbox);
                            }
                        }

                        // Wait a moment and verify selection
                        try {
                            Thread.sleep(500);
                        } catch (InterruptedException ie) {
                            Thread.currentThread().interrupt();
                        }
                        
                        // Re-check if selected (re-fetch to avoid stale element)
                        checkbox = std_row.findElement(By.xpath(".//td[1]//input[@type='checkbox']"));
                        if (checkbox.isSelected()) {
                            selectedCount++;
                            success = true;
                        } else {
                            // If still not selected, try one more time with direct JavaScript
                            ((JavascriptExecutor) driver).executeScript("arguments[0].checked = true; arguments[0].dispatchEvent(new Event('change', { bubbles: true }));", checkbox);
                            try {
                                Thread.sleep(300);
                            } catch (InterruptedException ie) {
                                Thread.currentThread().interrupt();
                            }
                            checkbox = std_row.findElement(By.xpath(".//td[1]//input[@type='checkbox']"));
                            if (checkbox.isSelected()) {
                                selectedCount++;
                                success = true;
                            } else {
                                retries--;
                            }
                        }

                    } catch (StaleElementReferenceException e) {
                        TestRunner.getTest().log(Status.INFO, "StaleElementReferenceException encountered, retrying row fetch.");
                        // Re-find the table element
                        studentTable = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class, 'stepAddStudentsTable')]//table")));
                        rows_Students = studentTable.findElements(By.xpath(".//tbody//tr"));
                        retries--;
                    } catch (Exception e) {
                        TestRunner.getTest().log(Status.INFO, "Exception while selecting checkbox: " + e.getMessage());
                        retries--;
                    }
                }

                if (!success) {
                    TestRunner.getTest().log(Status.INFO, "Unable to select student at index " + i + " after retries.");
                }
            }

            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Students selected successfully.");
            TestRunner.getTest().log(Status.INFO, "Number of students selected: " + selectedCount);
            System.out.println("Number of students selected: " + selectedCount);

        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "Exception occurred while selecting students from table: " + e.getMessage());
            System.out.println("Exception: " + e.getMessage());
        }
    }

//    Search and select the student

    public void searchAndSelectStudentInNewGroup() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Searching for student: " + searchStudentEmail);

        WebElement searchBox = driver.findElement(By.xpath("//input[@placeholder='Filter students from selected classes']"));
        searchBox.clear();
        searchBox.sendKeys(searchStudentEmail);
        Thread.sleep(2000); // Allow time for search results to update

        // Wait for search results to load
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class, 'stepAddStudentsTable')]//table//tbody//tr")));

        List<WebElement> rows_Students = table_AllStudents.findElements(By.xpath(".//tbody//tr"));
        System.out.println("Total Students after search: " + rows_Students.size());

        if (rows_Students.isEmpty()) {
            System.out.println("No matching student found.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: No matching student found.");
            return;
        }

        boolean studentSelected = false;

        for (int attempt = 0; attempt < 3; attempt++) { // Retry mechanism for stale elements
            try {
                // Re-fetch table rows in case of DOM update
                rows_Students = table_AllStudents.findElements(By.xpath(".//tbody//tr"));

                WebElement std_row = rows_Students.get(0);
                WebElement checkbox = std_row.findElement(By.xpath(".//td[1]//label//input[@type='checkbox']"));

                if (checkbox.isSelected()) {
                    System.out.println("Student '" + searchStudentEmail + "' is already selected.");
                    TestRunner.getTest().log(Status.INFO, "Student '" + searchStudentEmail + "' is already selected.");
                } else {
                    // Scroll to element for headless compatibility
                    helper.scrollToElement(driver, std_row);
                    
                    // Use JavaScript click for headless mode compatibility
                    try {
                        // Try clicking the label first (Material-UI pattern)
                        WebElement label = std_row.findElement(By.xpath(".//td[1]//label"));
                        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", label);
                    } catch (Exception e1) {
                        // If label click fails, try clicking the checkbox directly with JavaScript
                        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", checkbox);
                    }
                    
                    // Wait a moment for the selection to register
                    try {
                        Thread.sleep(500);
                    } catch (InterruptedException ie) {
                        Thread.currentThread().interrupt();
                    }
                    
                    // Re-fetch checkbox to avoid stale element
                    checkbox = std_row.findElement(By.xpath(".//td[1]//label//input[@type='checkbox']"));
                    
                    if (checkbox.isSelected()) {
                        System.out.println("Student '" + searchStudentEmail + "' selected successfully.");
                        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Student '" + searchStudentEmail + "' selected successfully.");
                    } else {
                        // Final fallback: directly set checked state
                        ((JavascriptExecutor) driver).executeScript("arguments[0].checked = true; arguments[0].dispatchEvent(new Event('change', { bubbles: true }));", checkbox);
                        try {
                            Thread.sleep(300);
                        } catch (InterruptedException ie) {
                            Thread.currentThread().interrupt();
                        }
                        checkbox = std_row.findElement(By.xpath(".//td[1]//label//input[@type='checkbox']"));
                        if (checkbox.isSelected()) {
                            System.out.println("Student '" + searchStudentEmail + "' selected successfully (via fallback).");
                            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Student '" + searchStudentEmail + "' selected successfully.");
                        } else {
                            System.out.println("Failed to select student '" + searchStudentEmail + "'.");
                            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Unable to select student '" + searchStudentEmail + "'.");
                        }
                    }
                }
                studentSelected = true;
                break; // Exit retry loop if no exception occurs

            } catch (StaleElementReferenceException e) {
                System.out.println("StaleElementReferenceException caught. Retrying... Attempt " + (attempt + 1));
            }
        }

        if (!studentSelected) {
            System.out.println("Failed to interact with student checkbox after retries.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Unable to interact with student checkbox.");
        }
    }

    //    Search and select the InActive Students

    public void searchAndSelectInActiveStudentInNewGroup() throws InterruptedException {
        System.out.println("Searching inactive student...");
        TestRunner.getTest().log(Status.INFO, "Searching inactive student...");
        boolean studentSelected = false;

        try {
            WebElement inActiveToggleButton = driver.findElement(By.xpath("//div[contains(@class, 'CalenderContainer-AccordionSummary')]//input"));

            if (inActiveToggleButton.isDisplayed()) {
                helper.scrollToElement(driver, inActiveToggleButton);
                Thread.sleep(500);
                inActiveToggleButton.click();
                Thread.sleep(2000);

                try {
                    wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class, 'stepAddStudentsTable')]//table//tbody//tr")));
                } catch (TimeoutException e) {
                    System.out.println("Student table not loaded.");
                    TestRunner.getTest().log(Status.FAIL, "Student table not loaded.");
                    return;
                }

                List<WebElement> rows_Students = table_AllStudents.findElements(By.xpath(".//tbody//tr"));
                System.out.println("Total InActive Students: " + rows_Students.size());

                if (rows_Students.isEmpty()) {
                    System.out.println("No inactive student found.");
                    TestRunner.getTest().log(Status.FAIL, "No inactive student found.");
                    return;
                }

                for (int attempt = 0; attempt < 3; attempt++) {
                    try {
                        rows_Students = table_AllStudents.findElements(By.xpath(".//tbody//tr"));
                        Random rand = new Random();
                        WebElement randomStudentRow = rows_Students.get(rand.nextInt(rows_Students.size()));

                        WebElement checkbox = randomStudentRow.findElement(By.xpath(".//td[1]//input[@type='checkbox']"));

                        if (checkbox.isSelected()) {
                            System.out.println("Randomly selected student is already selected.");
                            TestRunner.getTest().log(Status.INFO, "Randomly selected student is already selected.");
                        } else {
                            checkbox.click();
                            wait.until(ExpectedConditions.elementToBeSelected(checkbox));

                            if (checkbox.isSelected()) {
                                System.out.println("Student selected successfully.");
                                TestRunner.getTest().log(Status.PASS, "Student selected successfully.");
                            } else {
                                System.out.println("Failed to select the student.");
                                TestRunner.getTest().log(Status.FAIL, "Failed to select the student.");
                            }
                        }
                        studentSelected = true;
                        break;

                    } catch (StaleElementReferenceException e) {
                        System.out.println("StaleElementReferenceException caught. Retrying... Attempt " + (attempt + 1));
                    }
                }
            } else {
                System.out.println("Inactive toggle button is not displayed.");
                TestRunner.getTest().log(Status.FAIL, "Inactive toggle button is not visible.");
                return;
            }

        } catch (NoSuchElementException e) {
            System.out.println("Inactive toggle button not found.");
            TestRunner.getTest().log(Status.FAIL, "Inactive toggle button not found.");
            return;
        }

        if (!studentSelected) {
            System.out.println("Failed to interact with student checkbox after retries.");
            TestRunner.getTest().log(Status.FAIL, "Unable to interact with student checkbox.");
        }
    }

//    Page 3

    public void verifyGroupAndStudentInformation() throws InterruptedException{
        // Verifying Group Information
        String expectedGroupName = groupName;
        String expectedStatus = "Active";
        String expectedClass = "FL Grade 5";

        // Verifying Student Information
        String expectedStudentEmail = "student5095@gmail.com";
        String expectedStudentStatus = "Active";
        String expectedStudentGrade = "Grade 5";


        String groupInfo = driver.findElement(By.xpath("//div[contains(@class, 'bottomwrapper')]")).getText();
        System.out.println(groupInfo);
        TestRunner.getTest().log(Status.INFO, "Group Info " + groupInfo);
        TestRunner.getTest().log(Status.PASS, "Test Case Passed : Group Info get Successfully ");

        TestRunner.getTest().log(Status.PASS, "Group information verified successfully");
    }

    public void clickOnGroupExitButton() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "Exit new group");
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].click();", btn_Exit);
        TestRunner.getTest().log(Status.PASS, "Test Case Passed : Group exit successfully ");

    }

    public void searchClassByNameForGroup(){
        TestRunner.getTest().log(Status.INFO, "I'm in search Class By Name");
        WebElement right_panel= driver.findElement(By.xpath("//div[@class='right-panel']"));
        right_panel.isDisplayed();

        try {
            WebElement searchBox = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder='Search Class by keyword']")));
            if (searchBox.isDisplayed()) {
                searchBox.click();
                searchBox.clear();
                ((JavascriptExecutor) driver).executeScript("arguments[0].value='';", searchBox);
                System.out.println("Search by class name: " + specificClassForGroup);
                TestRunner.getTest().log(Status.INFO, "Search by class name: " + specificClassForGroup);
                searchBox.sendKeys(specificClassForGroup);

                Actions actions = new Actions(driver);
                actions.sendKeys(Keys.ENTER).perform();
                TestRunner.getTest().log(Status.PASS, "Testcase Passed   : Enter Search Student keyword Successfully");

                waitForTableToRefresh();
            } else {
                System.out.println("Search box is not displayed.");
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : Search box is not displayed");
//                throw new RuntimeException("Search Box not  Found.");
            }
        } catch (Exception e) {
            System.out.println("Search box is not available: " + e.getMessage());
        }
    }

    private void waitForTableToRefresh() {
        WebElement tableClasses = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class, 'ClassesDashboardRightPanel')]//tbody")));

        wait.until(ExpectedConditions.stalenessOf(tableClasses));

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(".//tr")));

        System.out.println("Table has refreshed.");
        TestRunner.getTest().log(Status.INFO, "Table has refreshed.");

    }

    public void showsGroupClassIntoTable() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm in to show group class in table");
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class, 'ClassesDashboardRightPanel')]//tbody")));

        List<WebElement> rows = classesTable.findElements(By.xpath(".//tbody/tr"));

        if (!rows.isEmpty()) {
            System.out.println("Classes found in the table:");
            TestRunner.getTest().log(Status.INFO, "Classes found in the table:");
            for (int i = 0; i < rows.size(); i++) {
                WebElement row = rows.get(i);

                try {
                    WebElement classNameElement = row.findElement(By.xpath(".//td[contains(@class, 'cell-class')]//div[@class='classnamedisplay']"));
                    className = classNameElement.getText();
                    System.out.println("Class Name: " + className);
                    TestRunner.getTest().log(Status.INFO, "Class Name: " + className);

                    List<WebElement> cells = row.findElements(By.xpath(".//td"));
                    for (WebElement cell : cells) {
                        System.out.print(cell.getText() + "\t");
                    }
                    System.out.println();
                    TestRunner.getTest().log(Status.PASS, "Testcase Passed   : Classes Found in Table  Successfully");

                } catch (StaleElementReferenceException e) {
                    System.out.println("Stale element found, retrying...");

                    rows = classesTable.findElements(By.xpath(".//tbody/tr"));
                    row = rows.get(i);

                    WebElement classNameElement = row.findElement(By.xpath(".//td[contains(@class, 'cell-class')]//div[@class='classnamedisplay']"));
                    String className = classNameElement.getText();
                    System.out.println("Class Name: " + className);
                    TestRunner.getTest().log(Status.INFO, "Class Name: " + className);

                    List<WebElement> cells = row.findElements(By.xpath(".//td"));
                    for (WebElement cell : cells) {
                        System.out.print(cell.getText() + "\t");
                    }
                    System.out.println();
                    TestRunner.getTest().log(Status.PASS, "Testcase Passed : Class Shows in Table Successfully");
                }
            }
        } else {
            System.out.println("No searched classes found in the table.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : No New Class found in the table by searching");
        }
        helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());

    }

    public String generateRandomNumber(String prefix) {
        String characters = "ABC123456789";
        StringBuilder randomClassName = new StringBuilder();
        Random random = new Random();
        int length = 4;
        randomClassName.append(prefix);
        for (int i = 0; i < length; i++) {
            randomClassName.append(characters.charAt(random.nextInt(characters.length())));
        }
        return randomClassName.toString();
    }
}
