package pageFactory.Classes.Group;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.Collections;
import java.util.List;

public class EditGroup_PF {
    public WebDriverWait wait;
    WebDriver driver;
    Helper helper;
    AddGroup_PF addGroupPF;

    final String selectedSpecificGroupName = Configurations.getDotEnv().get("SITE_SELECTED_GROUP");

    @FindBy(xpath = "//div[contains(@class, 'stepAddStudentsTable')]//table")
    WebElement table_AllStudents;

    @FindBy(xpath = "//button[normalize-space()='Save']")
    WebElement btn_Save;

    @FindBy(xpath = "//label[text()='Status']/following-sibling::div//div[@role='button' or @role='combobox']")
    WebElement dropDown_GroupStatus;

    @FindBy(xpath = "//ul[@role='listbox']")
    WebElement list_GroupStatus;

    @FindBy(xpath = "//label[text()='Select Group']/following-sibling::div//div[@role='button' or @role='combobox']")
    WebElement dropDown_GroupInGradeBook;

    public EditGroup_PF(WebDriver driver) {
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
        helper = new Helper();
        addGroupPF = new AddGroup_PF(driver);
    }

    public void clickEditGroupButton() {
        String searchGroupByKeyword = addGroupPF.getNewGroupName();

        TestRunner.getTest().log(Status.INFO, "Attempting to click Edit Group Button for group: " + searchGroupByKeyword);

        // XPath to locate the group name dynamically
        String groupXPath = "//div[contains(@class,'ribbon')]//div[text()='" + searchGroupByKeyword + "']/parent::div/parent::a";

        // Wait until the group is present and clickable
        WebElement groupLink = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(groupXPath)));

        if (groupLink.isDisplayed()) {
            helper.takeScreenshot(driver, "GroupFound_" + searchGroupByKeyword);
            groupLink.click();
            TestRunner.getTest().log(Status.PASS, "Group '" + searchGroupByKeyword + "' clicked successfully for editing.");
        } else {
            TestRunner.getTest().log(Status.FAIL, "Group '" + searchGroupByKeyword + "' not found or not clickable.");
            throw new RuntimeException("Group not found or not clickable: " + searchGroupByKeyword);
        }
    }

    public void editGroupClassInfo() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm in edit group class Information Screen");
        Thread.sleep(2000);
        System.out.println("I'm in edit group class Information Screen");

        WebElement RichTextBoxBody = driver.findElement(By.xpath("//div[@class='tox-edit-area']/iframe"));

        driver.switchTo().frame(RichTextBoxBody);

        WebElement editGroupDescriptionTextBox = driver.findElement(By.xpath("//body[@id='tinymce']//p"));
        System.out.println("Edit text area is found");

        editGroupDescriptionTextBox.clear();

        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].value='';", editGroupDescriptionTextBox);

        String randomUpdatedGroupDescriptionText = helper.generateRandomText("Updated Student Hint ");
        System.out.println(randomUpdatedGroupDescriptionText);

        editGroupDescriptionTextBox.sendKeys(randomUpdatedGroupDescriptionText);
        TestRunner.getTest().log(Status.INFO, "Updated Group Description Text is: " + randomUpdatedGroupDescriptionText);

        driver.switchTo().defaultContent();

        TestRunner.getTest().log(Status.INFO, "Updated Group Info: " + randomUpdatedGroupDescriptionText);
        System.out.println("Updated Group Info: " + randomUpdatedGroupDescriptionText);

        TestRunner.getTest().log(Status.PASS, "Testcase Passed : Edit group info added successfully");

    }

    public void SelectNewStudentForEditInGroup() {
        TestRunner.getTest().log(Status.INFO, "I'm in select new student for Edit in Group");
        try {
            wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(@class, 'stepAddStudentsTable')]//table")));
        } catch (TimeoutException e) {
            System.out.println("Student table not displayed - assuming students already selected or none available.");
            TestRunner.getTest().log(Status.INFO, "Students already selected");
            return;
        }

        if (!table_AllStudents.isDisplayed()) {
            System.out.println("Table is not displayed.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Student table is not displayed.");
            return;
        }

        List<WebElement> rows_Students = table_AllStudents.findElements(By.xpath(".//tbody//tr"));
        System.out.println("Total Students: " + rows_Students.size());

        if (rows_Students.isEmpty()) {
            System.out.println("No rows found in the table.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: No rows found in the table");
            throw new RuntimeException("No Row Found in table");
        }

        // Determine the number of students to select
        int studentsToSelect = (rows_Students.size() > 2) ? 2 : 1;

        // Shuffle and select random students
        Collections.shuffle(rows_Students);
        int selectedCount = 0;

        for (int i = 0; i < studentsToSelect; i++) {
            try {
                WebElement std_row = rows_Students.get(i);
                WebElement checkbox = std_row.findElement(By.xpath(".//td[1]//input[@type='checkbox']"));

                if (!checkbox.isSelected()) {
                    checkbox.click();
                }

                if (checkbox.isSelected()) {
                    selectedCount++;
                }
            } catch (StaleElementReferenceException e) {
                System.out.println("StaleElementReferenceException caught, refetching rows.");
                rows_Students = table_AllStudents.findElements(By.xpath(".//tbody//tr"));
                i--; // Retry the same index
            }
        }

        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Students selected successfully for edit group");
        System.out.println("Number of students selected: " + selectedCount);
        TestRunner.getTest().log(Status.INFO, "Number of students selected: " + selectedCount);
    }

    public void clickOnGroupSaveButton() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "Save group new student");
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].click();", btn_Save);
        TestRunner.getTest().log(Status.PASS, "Test Case Passed : Click and Save Button successfully ");

    }

    public void editGroupClassInfoInActive() {
        TestRunner.getTest().log(Status.INFO, "I'm in to select the group status 'InActive'");
        wait.until(ExpectedConditions.elementToBeClickable(dropDown_GroupStatus));

        if (dropDown_GroupStatus.isEnabled()) {
            dropDown_GroupStatus.click();
            TestRunner.getTest().log(Status.INFO, "Group status dropdown clicked successfully");

            WebElement groupStatusDropdown = wait.until(ExpectedConditions.elementToBeClickable(list_GroupStatus));
            List<WebElement> groupStatusList = groupStatusDropdown.findElements(By.xpath(".//li"));

            if (groupStatusList.isEmpty()) {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : No group status available in the dropdown list");
            } else {
                boolean statusFound = false;
                for (WebElement statusList : groupStatusList) {
                    String statusText = statusList.getText().trim();
                    if (statusText.equalsIgnoreCase("InActive")) {
                        statusList.click();
                        TestRunner.getTest().log(Status.PASS, "Group status selected: " + statusText);
                        statusFound = true;
                        break;
                    }
                }
                if (!statusFound) {
                    TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : 'InActive' status not found in the dropdown list");
                }
            }

        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : Group status dropdown is not enabled.");
        }
    }

    public void validateInActiveGroup() {
        String searchGroupByKeyword = addGroupPF.getNewGroupName();

        TestRunner.getTest().log(Status.INFO, "Validating that the InActive group is not visible: " + searchGroupByKeyword);

        String groupXPath = "//div[contains(@class,'ribbon')]//div[text()='" + searchGroupByKeyword + "']/parent::div/parent::a";

        try {
            driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));
            List<WebElement> groupElements = driver.findElements(By.xpath(groupXPath));

            if (groupElements.isEmpty()) {
                TestRunner.getTest().log(Status.PASS, "Test Passed: InActive group '" + searchGroupByKeyword + "' is not visible, as expected.");
            } else {
                helper.takeScreenshot(driver, "InActiveGroupVisible_" + searchGroupByKeyword);
                TestRunner.getTest().log(Status.FAIL, "InActive group '" + searchGroupByKeyword + "' is visible, but it should not be.");
            }
        } finally {
            driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
        }
    }

    public void searchAndSelectGroupInGradeBook() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm in to select the group in 'GradeBook'");
        Thread.sleep(5000);
        wait.until(ExpectedConditions.elementToBeClickable(dropDown_GroupInGradeBook));

        if (dropDown_GroupInGradeBook.isEnabled()) {
            dropDown_GroupInGradeBook.click();
            TestRunner.getTest().log(Status.INFO, "Groups dropdown clicked successfully");

            WebElement groupDropdown = wait.until(ExpectedConditions.elementToBeClickable(list_GroupStatus));
            List<WebElement> groupsList = groupDropdown.findElements(By.xpath(".//li"));

            if (groupsList.isEmpty()) {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : No group available in the dropdown list");
            } else {
                boolean groupsFound = false;
                String selectedGroupName = addGroupPF.getNewGroupName();
                System.out.println("Want to select the group " + selectedGroupName);
                TestRunner.getTest().log(Status.INFO, "Want to select the group " + selectedGroupName);
                for (WebElement groupList : groupsList) {
                    String groupText = groupList.getText().trim();
                    if (groupText.equalsIgnoreCase(selectedGroupName)) {
                        groupList.click();
                        TestRunner.getTest().log(Status.PASS, "Test Case Passed : Group selected " + groupText);
                        groupsFound = true;
                        break;
                    }
                }
                if (!groupsFound) {
                    TestRunner.getTest().log(Status.FAIL, "Test Case Failed : '" + selectedGroupName + "' not found in the dropdown list");
                }
            }

        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : Groups dropdown is not enabled.");
        }
    }

    public void searchAndSelectSpecificGroupInGradeBook() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm in to select the specific group in 'GradeBook'");
        wait.until(ExpectedConditions.elementToBeClickable(dropDown_GroupInGradeBook));

        if (dropDown_GroupInGradeBook.isEnabled()) {
            dropDown_GroupInGradeBook.click();
            TestRunner.getTest().log(Status.INFO, "Groups dropdown clicked successfully");

            WebElement groupDropdown = wait.until(ExpectedConditions.elementToBeClickable(list_GroupStatus));
            List<WebElement> groupsList = groupDropdown.findElements(By.xpath(".//li"));

            if (groupsList.isEmpty()) {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : No group available in the dropdown list");
            } else {
                boolean groupsFound = false;
                TestRunner.getTest().log(Status.INFO, "Want to select the group " + selectedSpecificGroupName);
                for (WebElement groupList : groupsList) {
                    String groupText = groupList.getText().trim();
                    if (groupText.equalsIgnoreCase(selectedSpecificGroupName)) {
                        groupList.click();
                        TestRunner.getTest().log(Status.PASS, "Test Case Passed : Group selected " + groupText);
                        groupsFound = true;
                        break;
                    }
                }
                if (!groupsFound) {
                    TestRunner.getTest().log(Status.FAIL, "Test Case Failed : '" + selectedSpecificGroupName + "' not found in the dropdown list");
                }
            }

        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : Groups dropdown is not enabled.");
        }
    }

}
