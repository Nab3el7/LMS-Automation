package pageFactory.MyContent.AssessmentsPF;

import StepDefinitions.Configurations;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

public class Assessments_PF {
    public WebDriverWait wait;
    WebDriver driver;

    public static String assessmentName;


    @FindBy(xpath = "//div[contains(@class, 'AssessmentDashboardRightPanel')]//tbody")
    WebElement assessmentContainerTable;


    public Assessments_PF(WebDriver driver) {
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
    }

//    public void filterAssessmentByStatus() {
//        String[] statusArray = {"Active", "Editing", "Locked"};
//
//        for (String status : statusArray) {
//            TestRunner.getTest().log(Status.INFO, "Filtering Assessment By Status: " + status);
//
//            try {
//                WebElement statusDropdown = driver.findElement(By.xpath("(//div[contains(@class, 'MuiSelect-select') and @role='button'])[3]"));
//                statusDropdown.click();
//
//                List<WebElement> statusOptions = driver.findElements(By.xpath("//ul[@role='listbox']//li"));
//                boolean statusFound = false;
//
//                for (WebElement option : statusOptions) {
//                    String optionText = option.getText().trim();
//                    if (optionText.equalsIgnoreCase(status)) {
//                        option.click();
//                        statusFound = true;
//                        TestRunner.getTest().log(Status.INFO, "Selected Status: " + optionText);
//                        break;
//                    }
//                }
//
//                if (!statusFound) {
//                    TestRunner.getTest().log(Status.FAIL, "Status not found in the dropdown: " + status);
//                    throw new RuntimeException("Status not found in the dropdown: " + status);
//                }
//
//                Thread.sleep(3000);
//                List<WebElement> noDetailFoundText = driver.findElements(By.xpath("//div[contains(@class, 'AssessmentDashboardRightPanel')]//div[contains(text(), 'No Detail Found')]"));
//                if (!noDetailFoundText.isEmpty()) {
//                    TestRunner.getTest().log(Status.INFO, "No assessments found for the status: " + status);
//                    System.out.println("No assessments found for the status: " + status);
//                    continue;
//                }
//

    /// /                waitForAssessmentTableToRefresh();
//
//                WebElement questionsTable = driver.findElement(By.xpath("//div[contains(@class, 'AssessmentDashboardRightPanel')]//tbody"));
//                List<WebElement> questionRows = questionsTable.findElements(By.xpath(".//tr"));
//
//                if (questionRows.isEmpty()) {
//                    TestRunner.getTest().log(Status.INFO, "No assessments found for the status: " + status);
//                    System.out.println("No assessments found for the status: " + status);
//                    TestRunner.getTest().log(Status.INFO, "No data found for status: " + status);
//                    continue;
//                }
//
//                boolean allRowsMatchStatus = true;
//                for (WebElement row : questionRows) {
//                    try {
//                        String rowData = row.getText().trim();
//                        System.out.println("Row Data: " + rowData);
//                        TestRunner.getTest().log(Status.INFO, "Row Data: " + rowData);
//
//                        WebElement statusCell = row.findElement(By.xpath(".//td[contains(@class, 'cell-4')]"));
//                        String rowStatus = statusCell.getText().trim();
//
//                        System.out.println("Row Status: " + rowStatus);
//                        TestRunner.getTest().log(Status.INFO, "Row Status: " + rowStatus);
//
//                        if (rowStatus.equalsIgnoreCase(status)) {
//                            TestRunner.getTest().log(Status.PASS, "Row with matching status found: " + rowStatus);
//                        } else {
//                            TestRunner.getTest().log(Status.FAIL, "Row status does not match selected status: " + rowStatus);
//                            allRowsMatchStatus = false;
//                        }
//                    } catch (NoSuchElementException e) {
//                        TestRunner.getTest().log(Status.FAIL, "Error while getting status for row: " + e.getMessage());
//                    }
//                }
//
//                if (allRowsMatchStatus) {
//                    TestRunner.getTest().log(Status.PASS, "All assessment rows match the selected status: " + status);
//                } else {
//                    TestRunner.getTest().log(Status.FAIL, "Some assessments do not match the selected status: " + status);
//                }
//            } catch (Exception e) {
//                TestRunner.getTest().log(Status.FAIL, "Exception occurred while filtering by status: " + status + ". Error: " + e.getMessage());
//            }
//        }
//    }
    public void filterAssessmentByStatus() {
        String[] statusArray = {"Active", "Editing", "Locked"};

        for (String status : statusArray) {
            TestRunner.getTest().log(Status.INFO, "Filtering Assessment By Status: " + status);

            try {
                WebElement statusDropdown = driver.findElement(By.xpath("(//div[contains(@class, 'MuiSelect-select') and @role='button' or @role='combobox'])[3]"));
                statusDropdown.click();

                WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(60));
                wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath("//ul[@role='listbox']//li")));

                List<WebElement> statusOptions = driver.findElements(By.xpath("//ul[@role='listbox']//li"));
                boolean statusFound = false;

                // Check if the status is in the dropdown
                for (WebElement option : statusOptions) {
                    String optionText = option.getText().trim();
                    if (optionText.equalsIgnoreCase(status)) {
                        option.click();
                        statusFound = true;
                        TestRunner.getTest().log(Status.INFO, "Selected Status: " + optionText);
                        break;
                    }
                }

                if (!statusFound) {
                    TestRunner.getTest().log(Status.FAIL, "Status not found in the dropdown: " + status);
                    throw new RuntimeException("Status not found in the dropdown: " + status);
                }

                Thread.sleep(3000);

                List<WebElement> noDetailFoundText = driver.findElements(By.xpath("//div[contains(@class, 'AssessmentDashboardRightPanel')]//div[contains(text(), 'No Detail Found')]"));
                if (!noDetailFoundText.isEmpty()) {
                    TestRunner.getTest().log(Status.INFO, "No Detail Found found for the status: " + status);
                    System.out.println("No Detail Found for the status: " + status);
                    continue;
                }

                WebElement questionsTable = driver.findElement(By.xpath("//div[contains(@class, 'AssessmentDashboardRightPanel')]//tbody"));
                List<WebElement> questionRows = questionsTable.findElements(By.xpath(".//tr"));
                Thread.sleep(2000);

                if (questionRows.isEmpty()) {
                    TestRunner.getTest().log(Status.FAIL, "No assessments found for the status: " + status);
                    System.out.println("No assessments found for the status: " + status);
                    TestRunner.getTest().log(Status.FAIL, "No Rows found for status: " + status);
                    continue;
                }

                boolean allRowsMatchStatus = true;
                for (WebElement row : questionRows) {
                    try {
                        String rowData = row.getText().trim();
                        System.out.println("Row Data: " + rowData);
                        TestRunner.getTest().log(Status.INFO, "Row Data: " + rowData);

                        // Check if the row has any data
                        if (rowData.isEmpty()) {
                            TestRunner.getTest().log(Status.FAIL, "Table Row has no data. Failing test for status: " + status);
                            allRowsMatchStatus = false;
                            break;
                        }

                        // Proceed with the status check for rows with data
                        WebElement statusCell = row.findElement(By.xpath(".//td[contains(@class, 'cell-4')]"));
                        String rowStatus = statusCell.getText().trim();

                        System.out.println("Row Status: " + rowStatus);
                        TestRunner.getTest().log(Status.INFO, "Row Status: " + rowStatus);

                        // Compare row status with selected status
                        if (rowStatus.equalsIgnoreCase(status)) {
                            TestRunner.getTest().log(Status.PASS, "Row with matching status found: " + rowStatus);
                        } else {
                            TestRunner.getTest().log(Status.FAIL, "Row status does not match selected status: " + rowStatus);
                            allRowsMatchStatus = false;
                        }
                    } catch (NoSuchElementException e) {
                        TestRunner.getTest().log(Status.FAIL, "Error while getting status for row: " + e.getMessage());
                    }
                }

                if (allRowsMatchStatus) {
                    TestRunner.getTest().log(Status.PASS, "All assessment rows match the selected status: " + status);
                } else {
                    TestRunner.getTest().log(Status.FAIL, "Some assessments do not match the selected status: " + status);
                }
                Thread.sleep(2000); // Wait before moving to next status

            } catch (Exception e) {
                TestRunner.getTest().log(Status.FAIL, "Exception occurred while filtering by status: " + status + ". Error: " + e.getMessage());
            }
        }
    }

    public void showsAssessmentIntoTable() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm in Show Assessment Into table");
        Thread.sleep(2000);

        try {
            WebElement questionsTable = wait.until(ExpectedConditions.visibilityOf(assessmentContainerTable));

            if (questionsTable != null) {
                List<WebElement> questionRows = questionsTable.findElements(By.xpath(".//tr"));

                if (questionRows.isEmpty()) {
                    TestRunner.getTest().log(Status.FAIL, "No rows found in the table.");
                    return;
                }

                // Check if any <td> has text
                boolean dataFound = false;
                for (WebElement row : questionRows) {
                    List<WebElement> cells = row.findElements(By.tagName("td"));
                    for (WebElement cell : cells) {
                        if (!cell.getText().trim().isEmpty()) {
                            dataFound = true;
                            break;
                        }
                    }
                    if (dataFound) break;
                }

                // If no data found, exit early
                if (!dataFound) {
                    TestRunner.getTest().log(Status.FAIL, "No data found in the table cells. Cannot proceed.");
                    return;
                }

                // ✅ Data exists — proceed
                TestRunner.getTest().log(Status.INFO, "Data found in table. Processing rows...");

                for (int i = 0; i < questionRows.size(); i++) {
                    WebElement questionRow = questionRows.get(i);
                    int retryCount = 0;
                    boolean success = false;

                    while (retryCount < 3) {
                        try {
                            WebElement questionNameElement = questionRow.findElement(By.xpath(".//td[contains(@class, 'cell-0')]"));
                            assessmentName = questionNameElement.getText();
                            System.out.println("Assessment Name: " + assessmentName);
                            TestRunner.getTest().log(Status.INFO, "Assessment Name: " + assessmentName);

                            List<WebElement> questionNameCells = questionRow.findElements(By.xpath(".//td"));
                            for (WebElement questionNameCell : questionNameCells) {
                                System.out.print(questionNameCell.getText() + "\t");
                            }
                            System.out.println();

                            success = true;
                            break;

                        } catch (StaleElementReferenceException e) {
                            System.out.println("Stale element found, retrying...");
                            questionRows = questionsTable.findElements(By.xpath(".//tbody//tr"));
                            retryCount++;
                        }
                    }

                    if (!success) {
                        TestRunner.getTest().log(Status.WARNING, "Could not process row " + (i + 1));
                    }
                }
            }
        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "Exception occurred while checking table: " + e.getMessage());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Assessment table not displayed ");
        }
    }



//    public void showsAssessmentIntoTable() throws InterruptedException {
//        TestRunner.getTest().log(Status.INFO, "I'm in Show Assessment Into table");
//        Thread.sleep(2000);
//        try {
//            WebElement questionsTable = wait.until(ExpectedConditions.visibilityOf(assessmentContainerTable));
//
//            if (questionsTable != null) {
//                List<WebElement> questionRows = questionsTable.findElements(By.xpath(".//tr"));
//
//                if (!questionRows.isEmpty()) {
//                    System.out.println("Questions found in the table:");
//                    TestRunner.getTest().log(Status.INFO, "Questions found in the table:");
//
//                    boolean allRowsProcessedSuccessfully = true;
//
//                    for (int i = 0; i < questionRows.size(); i++) {
//                        WebElement questionRow = questionRows.get(i);
//
//                        int retryCount = 0;
//                        boolean success = false;
//
//                        while (retryCount < 3) {
//                            try {
//                                WebElement questionNameElement = questionRow.findElement(By.xpath(".//td[contains(@class, 'cell-0')]"));
//                                assessmentName = questionNameElement.getText();
//                                System.out.println("Assessment Name: " + assessmentName);
//                                TestRunner.getTest().log(Status.INFO, "Assessment Name: " + assessmentName);
//
//                                List<WebElement> questionNameCells = questionRow.findElements(By.xpath(".//td"));
//                                for (WebElement questionNameCell : questionNameCells) {
//                                    System.out.print(questionNameCell.getText() + "\t");
//                                }
//                                System.out.println();
//
//                                success = true;
//                                break;
//
//                            } catch (StaleElementReferenceException e) {
//                                System.out.println("Stale element found, retrying...");
//
//                                questionRows = questionsTable.findElements(By.xpath(".//tbody//tr"));
//
//                                if (i >= questionRows.size()) {
//                                    System.out.println("Row index " + i + " is out of bounds after refresh.");
//                                    break;
//                                }
//
//                                questionRow = questionRows.get(i);
//                                retryCount++;
//                            } catch (NoSuchElementException e) {
//                                System.out.println("Element not found in the row: " + e.getMessage());
//                                break;
//                            }
//                        }
//
//                        if (!success) {
//                            System.out.println("Failed to retrieve assessment row after several attempts.");
//                            allRowsProcessedSuccessfully = false;
//                        }
//                    }
//
//                    if (allRowsProcessedSuccessfully) {
//                        TestRunner.getTest().log(Status.PASS, "Test Case Passed  : Assessment Shows Into Table Successfully");
//                    } else {
//                        TestRunner.getTest().log(Status.FAIL, "Test Case Failed  : One or more assessment could not be processed.");
//                    }
//                } else {
//                    TestRunner.getTest().log(Status.FAIL, "Test Case Failed  : No assessment found in the table.");
//                    throw new RuntimeException("No assessment found in the table");
//                }
//            } else {
//                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Assessment table is not visible.");
//                throw new RuntimeException("Assessment table is not visible");
//
//            }
//        } catch (TimeoutException e) {
//            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Timeout waiting for table to be visible or accessible. " + e.getMessage());
//        } catch (Exception e) {
//            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: An unexpected error occurred. " + e.getMessage());
//        }
//    }

    private void waitForAssessmentTableToRefresh() {
        try {
            WebElement questionsTable = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class, 'AssessmentDashboardRightPanel')]//tbody")));

            List<WebElement> rowsBeforeRefresh = questionsTable.findElements(By.xpath(".//tr"));
            System.out.println("Number of rows before refresh: " + rowsBeforeRefresh.size());

            if (rowsBeforeRefresh.isEmpty()) {
                System.out.println("No assessments found in the table.");
                TestRunner.getTest().log(Status.INFO, "No assessments found in the table.");
                return;
            }

            Thread.sleep(2000);

            List<WebElement> rowsAfterRefresh = questionsTable.findElements(By.xpath(".//tr"));
            System.out.println("Number of rows after refresh: " + rowsAfterRefresh.size());

            if (rowsAfterRefresh.isEmpty()) {
                System.out.println("No assessments found in the table after refresh.");
                TestRunner.getTest().log(Status.INFO, "No assessments found in the table after refresh.");
                return;
            }

            if (rowsBeforeRefresh.size() != rowsAfterRefresh.size()) {
                System.out.println("Table has refreshed. Number of rows before refresh: " + rowsBeforeRefresh.size() + ", after refresh: " + rowsAfterRefresh.size());
                TestRunner.getTest().log(Status.INFO, "Table has refreshed. Number of rows before refresh: " + rowsBeforeRefresh.size() + ", after refresh: " + rowsAfterRefresh.size());
            } else {
                System.out.println("Table did not refresh as expected. Rows before: " + rowsBeforeRefresh.size() + ", Rows after: " + rowsAfterRefresh.size());
                TestRunner.getTest().log(Status.INFO, "Table did not refresh as expected. Rows before: " + rowsBeforeRefresh.size() + ", Rows after: " + rowsAfterRefresh.size());
            }

            for (WebElement row : rowsAfterRefresh) {
                System.out.println("Table Row: " + row.getText());
                TestRunner.getTest().log(Status.INFO, "Table Row: " + row.getText());
            }

        } catch (TimeoutException e) {
            System.out.println("Timeout while waiting for table refresh: " + e.getMessage());
            TestRunner.getTest().log(Status.FAIL, "Timeout occurred while waiting for table to refresh.");
        } catch (NoSuchElementException e) {
            System.out.println("No assessments table found: " + e.getMessage());
            TestRunner.getTest().log(Status.FAIL, "No assessments table found.");
        } catch (Exception e) {
            System.out.println("Error while waiting for table refresh: " + e.getMessage());
            TestRunner.getTest().log(Status.FAIL, "Error occurred while waiting for table to refresh: " + e.getMessage());
        }
    }
}
