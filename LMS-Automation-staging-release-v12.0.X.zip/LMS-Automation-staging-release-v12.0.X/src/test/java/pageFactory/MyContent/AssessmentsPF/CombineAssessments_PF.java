package pageFactory.MyContent.AssessmentsPF;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.*;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Gradebook.AssignmentVerification_PF;
import pageFactory.Gradebook.ManualGrading_PF;
import pageFactory.MyContent.CreateAssessment_PF;

import java.time.Duration;
import java.util.*;

import static pageFactory.Gradebook.AssignmentScoreVerification_PF.totalQuestions;
import static pageFactory.Gradebook.ManualGrading_PF.totalQuestionsGradebookSummary;

public class CombineAssessments_PF {
    public WebDriverWait wait;
    WebDriver driver;
    Helper helper;

    CreateAssessment_PF createAssessmentPF;
    AssignmentVerification_PF assignmentVerificationPF;
    ManualGrading_PF manualGradingPF;

    public List<WebElement> vocabularyQuizCheckboxes = new ArrayList<>();
    public List<WebElement> experTrackCheckboxes = new ArrayList<>();
    public Map<String, Integer> selectedAssessmentQuestions = new HashMap<>();
    public List<WebElement> selectedCheckboxes = new ArrayList<>();


    public static String combineAssessmentName;
    public static int totalQuestionsAcrossAllAssignments;
    public static int totalRowsCount = 0;

    @FindBy(xpath = "//div[@class='Assessments']")
    WebElement div_Assessments;

    @FindBy(xpath = "//div[contains(@class, 'StudentListingAndTableWrapper')]")
    WebElement studentAssignmentTable;

    @FindBy(xpath = "//span[@role='progressbar']")
    WebElement progressBar;

    public CombineAssessments_PF (WebDriver driver){
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
        helper =new Helper();
        createAssessmentPF = new CreateAssessment_PF(driver);
        manualGradingPF = new ManualGrading_PF(driver);
        assignmentVerificationPF = new AssignmentVerification_PF(driver);
    }

    public void clickOnCombineAssessmentButton(){
        WebElement btnCombineAssessments = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Combine Assessments']")));
        if (btnCombineAssessments.isEnabled() && btnCombineAssessments.isDisplayed()){
            btnCombineAssessments.click();
            System.out.println("Clicked on Combine Assessments");
            TestRunner.getTest().log(Status.PASS, "Clicked on Combine Assessments successfully");
        } else {
            System.out.println("Combine Assessments button is not enabled");
            TestRunner.getTest().log(Status.FAIL, "Combine Assessments button is not enabled");
        }
    }

    public void combineAssessmentsIntoTable() throws InterruptedException {
        Thread.sleep(10000);

        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(@class, 'AssessmentDashboardRightPanel')]//tbody[@data-rbd-droppable-id='table']")));

        WebElement panelAssessments = driver.findElement(By.xpath("//div[contains(@class, 'AssessmentDashboardRightPanel')]"));
        WebElement tableAssessments = panelAssessments.findElement(By.xpath("//tbody[@data-rbd-droppable-id='table']"));
        List<WebElement> rowsAssessments = tableAssessments.findElements(By.tagName("tr"));

        int totalAssessments = rowsAssessments.size();
        System.out.println("Total number of assessments: " + totalAssessments);
        TestRunner.getTest().log(Status.INFO, "Total number of assessments: " + totalAssessments);

        for (WebElement row : rowsAssessments) {
            WebElement typeCell = row.findElement(By.xpath(".//td[contains(@class, 'cell-1')]"));
            String assessmentType = typeCell.getText().trim();

            if (assessmentType.equals("Vocabulary Quiz")) {
                WebElement checkbox = row.findElement(By.xpath(".//input[@type='checkbox']"));
                vocabularyQuizCheckboxes.add(checkbox);
            } else if (assessmentType.equals("ExperTrack")) {
                WebElement checkbox = row.findElement(By.xpath(".//input[@type='checkbox']"));
                experTrackCheckboxes.add(checkbox);
            }
        }

        if (vocabularyQuizCheckboxes.isEmpty()) {
            System.out.println("No Vocabulary Quiz assignments found.");
            TestRunner.getTest().log(Status.INFO, "No Vocabulary Quiz assignments found.");
        }
        if (experTrackCheckboxes.isEmpty()) {
            System.out.println("No ExperTrack assignments found.");
            TestRunner.getTest().log(Status.INFO, "No ExperTrack assignments found.");
        }

        if (vocabularyQuizCheckboxes.size() > 2) {
            selectRandomCheckboxes(vocabularyQuizCheckboxes, 1);
        } else if (!vocabularyQuizCheckboxes.isEmpty()) {
            selectRandomCheckboxes(vocabularyQuizCheckboxes, 1);
        }

        if (experTrackCheckboxes.size() > 2) {
            selectRandomCheckboxes(experTrackCheckboxes, 1);
        } else if (!experTrackCheckboxes.isEmpty()) {
            selectRandomCheckboxes(experTrackCheckboxes, 1);
        }

        totalQuestionsAcrossAllAssignments = 0;

        for (WebElement selectedCheckbox : selectedCheckboxes) {
            WebElement row = selectedCheckbox.findElement(By.xpath("./ancestor::tr"));

            WebElement typeCell = row.findElement(By.xpath(".//td[contains(@class, 'cell-1')]"));
            String assessmentType = typeCell.getText().trim();

            WebElement titleCell = row.findElement(By.xpath(".//td[contains(@class, 'cell-0')]"));
            String assignmentName = titleCell.getText().trim();

            WebElement dropdownButton = row.findElement(By.xpath(".//td//button[@aria-label='DropDownButtom']"));
            dropdownButton.click();

            WebElement previewOption = wait.until(ExpectedConditions.elementToBeClickable(By.id("preview")));
            previewOption.click();

            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class, 'PagingContainer')]")));

            int questionCount = getTotalQuestionsInPreview(wait);

            System.out.println("Assignment: " + assignmentName + " | Type: " + assessmentType + " | Total Questions: " + questionCount);
            TestRunner.getTest().log(Status.INFO, "Assignment: " + assignmentName + " | Type: " + assessmentType + " | Total Questions: " + questionCount);

            selectedAssessmentQuestions.put(assignmentName, questionCount);
            totalQuestionsAcrossAllAssignments += questionCount;

            closePreviewUsingESC();

            TestRunner.getTest().log(Status.INFO, "Previewed " + assignmentName + " and captured total questions: " + questionCount);

        }

        System.out.println("Total questions across all selected assignments: " + totalQuestionsAcrossAllAssignments);
        TestRunner.getTest().log(Status.INFO, "Total questions across all selected assignments: " + totalQuestionsAcrossAllAssignments);

        WebElement combineButton = driver.findElement(By.xpath("//button[normalize-space()='Combine']"));
        if (combineButton.isEnabled()) {
            helper.scrollToElement(driver, combineButton);
            Thread.sleep(2000);
            combineButton.click();
            TestRunner.getTest().log(Status.PASS, "Combine button clicked successfully.");
        } else {
            System.out.println("Combine button is not enabled.");
            TestRunner.getTest().log(Status.FAIL, "Combine button is not enabled.");
        }
    }

    private void selectRandomCheckboxes(List<WebElement> checkboxes, int numberOfSelections) {
        Random random = new Random();
        Set<Integer> selectedIndices = new HashSet<>();

        while (selectedIndices.size() < numberOfSelections) {
            int randomIndex = random.nextInt(checkboxes.size());
            if (!selectedIndices.contains(randomIndex)) {
                WebElement checkbox = checkboxes.get(randomIndex);
                checkbox.click();
                selectedCheckboxes.add(checkbox);
                selectedIndices.add(randomIndex);
            }
        }
    }

    private int getTotalQuestionsInPreview(WebDriverWait wait) throws InterruptedException {
        WebElement paginationContainer = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//nav[@aria-label='pagination navigation'])[2]")));

        Thread.sleep(1000);

        List<WebElement> pages = paginationContainer.findElements(By.xpath(".//ul/li/button[contains(@class, 'MuiPaginationItem-page')]"));
        int totalPages = pages.size();

        System.out.println("Total questions in the individual assignment: " + totalPages);
        TestRunner.getTest().log(Status.INFO, "Total questions in the individual assignment: " + totalPages);

        totalQuestionsAcrossAllAssignments += totalPages;

        return totalPages;
    }

    private void closePreviewUsingESC() throws InterruptedException {
        By closeButtonLocator = By.xpath("//button[@aria-label='close']");
        try {
            WebElement closeButton = wait.until(ExpectedConditions.elementToBeClickable(closeButtonLocator));
            helper.scrollToElement(driver, closeButton);
            closeButton.click();
            Thread.sleep(500);
            System.out.println("Closed the preview using close button.");
            TestRunner.getTest().log(Status.INFO, "Closed the preview using close button.");
        } catch (TimeoutException | NoSuchElementException | ElementClickInterceptedException e) {
            Actions actions = new Actions(driver);
            actions.sendKeys(Keys.ESCAPE).perform();
            Thread.sleep(1000);
            System.out.println("Closed the preview using ESC key fallback.");
            TestRunner.getTest().log(Status.INFO, "Closed the preview using ESC key fallback.");
        }
    }


    public void enterCombineAssessmentName() throws InterruptedException {
        Thread.sleep(2000);
        WebElement dialogBox = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@role='dialog']")));

        if (dialogBox.isDisplayed()) {
            System.out.println("Combine Assessment dialog box is displayed.");
            TestRunner.getTest().log(Status.INFO, "Combine Assessment dialog box is displayed.");

            WebElement edtCombineAssessmentName = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@role='dialog']//div[contains(@class, 'MuiOutlinedInput-root')]//input[@type='text']")));

            combineAssessmentName = "Automated Combined Assessment " + new Date();

            edtCombineAssessmentName.clear();
            edtCombineAssessmentName.sendKeys(combineAssessmentName);
            System.out.println("Entered Combine Assessment Name: " + combineAssessmentName);
            TestRunner.getTest().log(Status.INFO, "Entered Combine Assessment Name: " + combineAssessmentName);

            By saveButtonLocator = By.xpath("//div[@role='dialog']//button[normalize-space()='Save'] | //button[normalize-space()='Yes']");
            WebElement saveButton = wait.until(ExpectedConditions.presenceOfElementLocated(saveButtonLocator));
            helper.scrollToElement(driver, saveButton);
            wait.until(ExpectedConditions.elementToBeClickable(saveButton));
            try {
                saveButton.click();
            } catch (ElementClickInterceptedException e) {
                ((JavascriptExecutor) driver).executeScript("arguments[0].click();", saveButton);
            }
            System.out.println("Save the combined assessment successfully.");
            TestRunner.getTest().log(Status.PASS, "Save the combined assessment successfully.");
        } else {
            System.out.println("Combine Assessment dialog box is not displayed.");
            TestRunner.getTest().log(Status.FAIL, "Combine Assessment dialog box is not displayed.");
            throw new RuntimeException("Combine Assessment dialog box is not displayed.");
        }
    }

    public void validateCombinedAssessmentQuestionAndEnterWeightPercentage() throws InterruptedException {
        WebElement btnShowAll = driver.findElement(By.xpath("//div[@class='pagingClass']//button[@id='btn-saveNext']"));

        if (btnShowAll.isDisplayed() && btnShowAll.isEnabled()) {
            btnShowAll.click();
            System.out.println("Show All Button clicked.");
        }

        Thread.sleep(5000);

        WebElement screenQuestion = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(@class, 'MetaDataWrapper')]")));
        WebElement tableAssessment = screenQuestion.findElement(By.xpath("//table"));
        List<WebElement> rows = tableAssessment.findElements(By.tagName("tr"));

        totalRowsCount += rows.size() - 1;

        Random random = new Random();

        for (int i = 1; i < rows.size(); i++) {
            WebElement row = rows.get(i);
            List<WebElement> cells = row.findElements(By.tagName("td"));

            WebElement weightInput = cells.get(2).findElement(By.tagName("input"));
            WebElement percentageInput = cells.get(3).findElement(By.tagName("input"));

            scrollIntoView(weightInput);
            scrollIntoView(percentageInput);

            clearInputWithJs(driver, weightInput);
            clearInputWithJs(driver, percentageInput);

            int randomWeight = random.nextInt(9) + 1;
            int randomPercentage = random.nextInt(100);

            sendKeysWithJs(driver, weightInput, String.valueOf(randomWeight));
            sendKeysWithJs(driver, percentageInput, String.valueOf(randomPercentage));
        }

        Thread.sleep(500);

        System.out.println("Total questions: " + totalRowsCount);
        TestRunner.getTest().log(Status.INFO, "Total questions: " + totalRowsCount);

        if (totalRowsCount == totalQuestionsAcrossAllAssignments) {
            System.out.println("Validation successful! Total rows match the total questions across all selected assignments.");
            TestRunner.getTest().log(Status.PASS, "Validation successful! Total rows (" + totalRowsCount + ") match the total questions across all selected assignments (" + totalQuestionsAcrossAllAssignments + ").");
        } else {
            System.out.println("Validation failed! Total rows (" + totalRowsCount + ") do not match the total questions across all selected assignments (" + totalQuestionsAcrossAllAssignments + ").");
            TestRunner.getTest().log(Status.FAIL, "Validation failed! Total rows (" + totalRowsCount + ") do not match the total questions across all selected assignments (" + totalQuestionsAcrossAllAssignments + ").");
        }

        TestRunner.getTest().log(Status.PASS, "Test Case Passed : Enter Weight and Percentage successfully");
    }

    private void scrollIntoView(WebElement element) {
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
    }
    private void clearInputWithJs(WebDriver driver, WebElement element) {
        ((JavascriptExecutor) driver).executeScript("arguments[0].value = '';", element);
    }
    private void sendKeysWithJs(WebDriver driver, WebElement element, String keys) {
        ((JavascriptExecutor) driver).executeScript("arguments[0].value = arguments[1];", element, keys);
    }

    public void searchCombinedAssessment() throws InterruptedException{
        WebElement divSearchEditFieldAssessment = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='Assessments']")));

        helper.scrollToElement(driver, divSearchEditFieldAssessment);

        WebElement edt_SearchAssessment = divSearchEditFieldAssessment.findElement(By.xpath(".//input[@placeholder='Search Assessments']"));

        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].value='';", edt_SearchAssessment);

        TestRunner.getTest().log(Status.INFO, "Want to search assessment name is: " + combineAssessmentName);

        edt_SearchAssessment.sendKeys(combineAssessmentName);

        createAssessmentPF.AssessmentTableInReadAble();

        List<WebElement> assessmentRows = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//div[contains(@class, 'AssessmentDashboardRightPanel')]//tbody//tr")));
        System.out.println("Assessment dashboard loaded with " + assessmentRows.size() + " rows.");
        TestRunner.getTest().log(Status.INFO, "Total number of My Assessments are: " + assessmentRows.size());

        try {
            for (WebElement row : assessmentRows) {
                WebElement rowText = wait.until(ExpectedConditions.visibilityOf(row.findElement(By.xpath(".//td[2]//div"))));
                System.out.println(rowText.getText());
                if (rowText.getText().equals(combineAssessmentName)) {
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed : New combined assessment search successfully");
                }else {
                    System.out.println("No assessment found with the name: " + combineAssessmentName);
                    TestRunner.getTest().log(Status.FAIL, "Test Case Failed : New created combined assessment {" + combineAssessmentName + "} not found in table:");
                    throw new RuntimeException("New created combined assessment not found in table");
                }
            }
        } catch (StaleElementReferenceException e) {
            System.out.println("Stale element encountered, retrying...");
            wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//div[contains(@class, 'AssessmentDashboardRightPanel')]//tbody//tr")));
        }

    }

    public void clickAssignTheCombineAssessment() {
        try {
            WebElement SearchAssessmentDashboard = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class, 'AssessmentDashboardRightPanel')]//tbody")));

            List<WebElement> totalSearchAssignments = SearchAssessmentDashboard.findElements(By.xpath(".//tr"));
            System.out.println("Total Search Assignment is: " + totalSearchAssignments.size());

            boolean found = false;

            for (WebElement searchAssignment : totalSearchAssignments) {
                createAssessmentPF.AssessmentTableInReadAble();
                WebElement nameElement = searchAssignment.findElement(By.xpath(".//td[2]//div"));
                String searchedAssignmentName = nameElement.getText();

                System.out.println("Searched assignment name: " + searchedAssignmentName);
                TestRunner.getTest().log(Status.INFO, "Searched assignment name: " + searchedAssignmentName);

                if (searchedAssignmentName.equals(combineAssessmentName)) {
                    WebElement assignButton = searchAssignment.findElement(By.xpath(".//button[normalize-space()='Assign']"));
                    if (assignButton.isDisplayed() && assignButton.isEnabled()) {
                        System.out.println("Assign button found for: " + combineAssessmentName);
                        found = true;
                        Thread.sleep(1000);
                        createAssessmentPF.ReleaseCustomAssignmentForCorrectAnswers();
                        TestRunner.getTest().log(Status.PASS, "Test Case Passed : Release Combine Assignment successfully");
                    }

                    Thread.sleep(1000);
                    break;
                }
            }

            if (!found) {
                System.out.println("No combine assignment found with the name: " + combineAssessmentName);
                throw new RuntimeException("Combined Assessment Name not found");

            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public void verifyCombinedAssessmentTotalQuestionStudentSide() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Verify the total questions when student attempt the combine assessment");
        int totalQuestionsInAssignment = Integer.parseInt(totalQuestions.get());
        if (totalQuestionsInAssignment == totalQuestionsAcrossAllAssignments) {
            System.out.println("Validation successful! Total rows match the total questions across all selected assignments.");
            TestRunner.getTest().log(Status.PASS, "Validation successful! Total rows (" + totalRowsCount + ") match the total questions across all selected assignments (" + totalQuestionsAcrossAllAssignments + ").");
        } else {
            System.out.println("Validation failed! Total rows (" + totalRowsCount + ") do not match the total questions across all selected assignments (" + totalQuestionsAcrossAllAssignments + ").");
            TestRunner.getTest().log(Status.FAIL, "Validation failed! Total rows (" + totalRowsCount + ") do not match the total questions across all selected assignments (" + totalQuestionsAcrossAllAssignments + ").");
        }
    }

    public void verifyQuestionsAndSearchCombineAssessmentInGradebook(String assignmentName) throws InterruptedException {
        WebElement assignmentTable = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(@class, 'StudentListingAndTableWrapper')]")));

        List<WebElement> assignmentContainers = assignmentTable.findElements(By.xpath(".//thead//tr//th"));
        System.out.println("Total Assignment Names are: " + assignmentContainers.size());

        for (int i = 0; i < assignmentContainers.size(); i++) {
            WebElement assignment = assignmentContainers.get(i);
            String assignmentsName = assignment.getText();
            System.out.println("Assignment Name: " + assignmentsName);

            if (assignmentsName.equalsIgnoreCase(assignmentName)) {
                System.out.println("Found assignment: " + assignmentsName);

                boolean staleElement = true;
                while (staleElement) {
                    try {
                        assignmentContainers = assignmentTable.findElements(By.xpath(".//thead//tr//th"));
                        assignment = assignmentContainers.get(i);

                        wait.until(ExpectedConditions.elementToBeClickable(assignment));
                        assignment.click();
                        staleElement = false;

                        System.out.println("Assignment found");
                        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Assignment found successfully " + assignmentsName);

                        Thread.sleep(2000);
                        assignmentVerificationPF.clickGradeButton();
                        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Click on Grade button successfully " + assignmentsName);

                        try {
                            if (progressBar != null && progressBar.isDisplayed()) {
                                wait.until(ExpectedConditions.invisibilityOf(progressBar));
                            }
                        } catch (NoSuchElementException | StaleElementReferenceException e) {
                            System.out.println("Progress bar not found or disappeared already.");
                        }
                        manualGradingPF.ClickOnSummaryTab();
                        try {
                            if (progressBar != null && progressBar.isDisplayed()) {
                                wait.until(ExpectedConditions.invisibilityOf(progressBar));
                            }
                        } catch (NoSuchElementException | StaleElementReferenceException e) {
                            System.out.println("Progress bar not found or disappeared already.");
                        }
                        manualGradingPF.AssignmentScoresSummary();
                        verifyQuestionsCombinedAssessmentsFromGradebook();
                    } catch (StaleElementReferenceException e) {
                        System.out.println("StaleElementReferenceException occurred. Retrying...");
                        staleElement = true;
                    } catch (NoSuchElementException e) {
                        TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Grade button not found for assignment: " + combineAssessmentName);
                        return;
                    }
                }
                break;
            }
        }
    }

    public void verifyQuestionsCombinedAssessmentsFromGradebook() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Verify the total questions when teacher view the combine assessment");
        int totalQuestionsInGradebook = Integer.parseInt(totalQuestionsGradebookSummary.get());
        if (totalQuestionsInGradebook == totalQuestionsAcrossAllAssignments) {
            System.out.println("Validation successful! Total rows match the total questions across all selected assignments.");
            TestRunner.getTest().log(Status.PASS, "Validation successful! Total rows (" + totalRowsCount + ") match the total questions across all selected assignments (" + totalQuestionsAcrossAllAssignments + ").");
        } else {
            System.out.println("Validation failed! Total rows (" + totalRowsCount + ") do not match the total questions across all selected assignments (" + totalQuestionsAcrossAllAssignments + ").");
            TestRunner.getTest().log(Status.FAIL, "Validation failed! Total rows (" + totalRowsCount + ") do not match the total questions across all selected assignments (" + totalQuestionsAcrossAllAssignments + ").");
        }
    }
}
