package pageFactory.MyContent;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.MyContentModule.CreateAssessmentSteps;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.sl.In;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Assignmment.CorrectAnswerExecutor_PF;
import pageFactory.Assignmment.InCorrectAnswerExecutor_PF;
import pageFactory.Assignmment.ReleaseAssignment_PF;

import java.time.Duration;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

import static org.openqa.selenium.By.tagName;

public class CreateAssessment_PF extends Configurations{

    WebDriverWait wait;
    WebDriver driver;

    public static String assessmentStatus = "Active";

    Helper helper;
    AssignAssessment_PF assignAssessment;
    CorrectAnswerExecutor_PF correctAnswerExecutor;
    InCorrectAnswerExecutor_PF inCorrectAnswerExecutor;
    ReleaseAssignment_PF releaseAssignment_pf;


//    public static String CustomAssessmentName = Configurations.getDotEnv().get("SITE_CUSTOM_ASSESSMENT_NAME");

    public static final String BASE_NAME = Configurations.getDotEnv().get("SITE_CUSTOM_ASSESSMENT_NAME");
    public static final String CustomAssessmentName;

    static {
        Random random = new Random();
        StringBuilder sb = new StringBuilder(6);
        String charSet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

        for (int i = 0; i < 6; i++) {
            int randomIndex = random.nextInt(charSet.length());
            sb.append(charSet.charAt(randomIndex));
        }

        String randomString = sb.toString();
        CustomAssessmentName = BASE_NAME + " " + randomString;
    }

//    public static String selectedCourse = "Florida 3rd Grade Social Studies";
    public static String selectedCourse;
    static String typeNameText;
    private static int totalCheckboxesToClick = 0;

    @FindBy(xpath = "//div[@aria-label='Content Module']")
    WebElement link_MyContent;

    @FindBy(xpath = "//span[@role='progressbar']")
    WebElement progressBar;

    @FindBy(xpath = "(//div[contains(@class, 'selectTextFieldsWrapper')])[1]")
    WebElement dropDown_SelectCourse;

    @FindBy(xpath = "//div[contains(@class, 'AssessmentDashboardRightPanel')]")
    WebElement rightPanel_AssessmentDashboard;

    @FindBy(xpath = "//div[contains(@class, 'navigation-container')]")
    WebElement nav_Header;

    @FindBy(xpath = "//div[contains(@class, 'footer-container')]")
    WebElement container_Footer;

    @FindBy(xpath = "//div[contains(@class, 'AssessmentInformationWrapper')]")
    WebElement wrapper_AssessmentInformation;

    @FindBy(xpath = "//div[@class='screens-container']")
    WebElement container_NewQuestions;

    @FindBy(xpath = "//div[contains(@class, 'MetaDataWrapper')]")
    WebElement container_FinalizeQuestion;

    @FindBy(xpath = "//button[normalize-space()='Apply Filter']")
    WebElement btn_ApplyFilter;

    @FindBy(xpath = "//div[@class='screens-container']")
    WebElement div_SelectedQuestionTable;

    @FindBy(xpath = "//div[@aria-controls='Assessments-content']")
    WebElement div_AssessmentContent;

    @FindBy(xpath = "//div[@class='Assessments']")
    WebElement div_Assessments;

    @FindBy(xpath = "//span[text()='Assessment Status']/following-sibling::div//div[@role='button' or @role='combobox']")
    WebElement assessmentStatusDropdown;

    @FindBy(xpath = "//button[@id='btn-saveNext']")
    WebElement btn_Save;

    @FindBy(xpath = "//button[normalize-space()='Assign']")
    WebElement btn_Assign;

    @FindBy(xpath = "//span[text()='All Statuses']/ancestor::div[contains(@class,'MuiSelect-select')]")
    WebElement dropDown_QuestionStatus;

    @FindBy(xpath = "//ul[@role='listbox']")
    WebElement list_QuestionStatus;

    public  CreateAssessment_PF(WebDriver driver){
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        helper = new Helper();
        assignAssessment = new AssignAssessment_PF(driver);
        correctAnswerExecutor = new CorrectAnswerExecutor_PF(driver);
        inCorrectAnswerExecutor = new InCorrectAnswerExecutor_PF(driver);
        releaseAssignment_pf = new ReleaseAssignment_PF(driver);
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
    }

    public void SideNavBarAndClickOnMyContent() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm in checking the side navbar and click on My Content");
        Thread.sleep(1000);

        WebElement navBar = driver.findElement(By.xpath("//div[@class='navigation']"));

        List<WebElement> totalLinks = navBar.findElements(tagName("a"));

        for (WebElement link : totalLinks) {
            String hrefValue = link.getAttribute("href");
            System.out.println("Link is: " + hrefValue);

            if (hrefValue.contains("/content")) {
                WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

                // Wait for the overlay or backdrop to disappear if it exists
                wait.until(ExpectedConditions.invisibilityOfElementLocated(By.className("MuiBackdrop-root")));

                try {
                    link.click();
                } catch (ElementClickInterceptedException e) {
                    // If the click is intercepted, use JavaScript as a fallback
                    ((JavascriptExecutor) driver).executeScript("arguments[0].click();", link);
                }

                TestRunner.getTest().log(Status.PASS, "Testcase Passed: Side navbar shows and clicked on My Content");
            }

        }

    }

    public void waitUntilProgressBar() {
        wait.until(ExpectedConditions.invisibilityOf(progressBar));
    }

    public void MyContentDashboard() throws InterruptedException {
        System.out.println("I'm in My Content dashboard");
        TestRunner.getTest().log(Status.INFO, "I'm in My Content dashboard");

        Thread.sleep(1000);

        WebElement breadCrumbOfMyContent = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ol[contains(@class, 'MuiBreadcrumbs')]")));
        System.out.println("My Content BreadCrumb is: " + breadCrumbOfMyContent.getText());

        WebElement dropdownCourses = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class, 'selectTextFieldsWrapper')]")));
        WebElement assessmentDashboard = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class, 'AssessmentDashboardContainer')]")));
        WebElement assessmentFilter = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class, 'AssessmentDashboardLeftPanel')]")));
        WebElement assessmentTable = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class, 'AssessmentDashboardRightPanel')]")));

        if (dropdownCourses.isDisplayed() && assessmentDashboard.isDisplayed() && assessmentFilter.isDisplayed() && assessmentTable.isDisplayed()) {
            TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  My Content Dashboard all elements are Visible");
        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  My Content Dashboard all elements are not Visible");
        }

    }

    public void SelectCourse() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm in Select Course");
        Thread.sleep(3000);
        WebElement dropDown_SelectCourse = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//div[contains(@class, 'selectTextFieldsWrapper')])[1]")));

        if (dropDown_SelectCourse.isDisplayed() && dropDown_SelectCourse.isEnabled()) {
            dropDown_SelectCourse.click();
            System.out.println("Courses dropdown  is enabled and click");
            TestRunner.getTest().log(Status.INFO, "Courses dropdown  is  enabled and click");
            Thread.sleep(5000);

            WebElement listCourse = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[@role='listbox']")));
            List<WebElement> optionsCourses = listCourse.findElements(By.xpath(".//li"));

            System.out.println("Courses List is: " + optionsCourses.size());

            if (optionsCourses.isEmpty()) {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  No options found in the courses dropdown.");
//                throw new RuntimeException("No options found in the courses dropdown.");
            } else {
                System.out.println("Courses:");

                for (WebElement course : optionsCourses) {
                    System.out.println(course.getText());
                }
                if (!optionsCourses.isEmpty()) {
                    Random random = new Random();
                    int randomCourse = random.nextInt(optionsCourses.size());
                    WebElement selectedOption = optionsCourses.get(randomCourse);
                    selectedCourse = selectedOption.getText();
                    selectedOption.click();
                    System.out.println("Selected Course: " + selectedCourse);

                    TestRunner.getTest().log(Status.INFO, "Selected Course : " + selectedCourse);
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  Course is selected successfully ");
                }
            }
        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  Courses dropdown not shows or clickable");
        }
    }

    public void AddNewButton() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm in Click Add New Button");
        Thread.sleep(1000);
        rightPanel_AssessmentDashboard.isDisplayed();

        WebElement btn_AddNew = rightPanel_AssessmentDashboard.findElement(By.xpath("//button[normalize-space()='Add New']"));

        if (btn_AddNew.isDisplayed() && btn_AddNew.isEnabled()) {
            btn_AddNew.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  Clicked on Add New button");

            Thread.sleep(1000);
            String currentURL = driver.getCurrentUrl();
            System.out.println("New Assessment URL is: " + currentURL);

            if (currentURL.contains("content/assessment/authoring/itembank")) {
                TestRunner.getTest().log(Status.INFO, "URL verification passed.");
            } else {
                System.out.println("URL verification failed.");
                TestRunner.getTest().log(Status.INFO, "URL verification failed.");
            }

        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  Add New button is not displayed or clickable.");
//            throw new RuntimeException("Add New button is not displayed or clickable");
        }

    }

//    Select Item Bank(s)

    public void SelectItemBank() throws InterruptedException {
        Thread.sleep(500);

        nav_Header.isDisplayed();
        TestRunner.getTest().log(Status.INFO, "Navigation header is: " + nav_Header.getText());

        WebElement containerQuestionScreen = nav_Header.findElement(By.xpath("//div[contains(@class, 'screens-container')]"));

        List<WebElement> listItems = containerQuestionScreen.findElements(tagName("li"));
        TestRunner.getTest().log(Status.INFO, "Total list items : " + listItems.size());

        if (listItems.isEmpty()) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  No any item bank found.");
//            throw new RuntimeException("No item bank found.");

        } else {
            System.out.println("List of elements:");

            for (WebElement listItem : listItems) {
                System.out.println(listItem.getText());
            }

            WebElement itemBankGallopadeQuestions = containerQuestionScreen.findElement(By.xpath(".//input[contains(@name,'gpQuestion')]"));
            if (itemBankGallopadeQuestions.isEnabled()){
                itemBankGallopadeQuestions.click();
                System.out.println("Clicked on the Gallopade Questions input.");
                TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  Gallopade Questions selected successfully");
            } else {
                System.out.println("Could not clicked on the Gallopade Questions input item bank.");
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Gallopade Questions item bank could not selected");
            }
        }
    }

    public void SelectMyQuestionItemBank() throws InterruptedException {
        Thread.sleep(500);

        nav_Header.isDisplayed();
        TestRunner.getTest().log(Status.INFO, "Navigation header is: " + nav_Header.getText());

        WebElement containerQuestionScreen = nav_Header.findElement(By.xpath("//div[contains(@class, 'screens-container')]"));

        List<WebElement> listItems = containerQuestionScreen.findElements(By.tagName("li"));
        TestRunner.getTest().log(Status.INFO, "Total list items : " + listItems.size());

        if (listItems.isEmpty()) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  No item bank found.");
        } else {
            System.out.println("List of elements:");

            for (WebElement listItem : listItems) {
                System.out.println(listItem.getText());
            }

            WebElement itemBankMyQuestions = containerQuestionScreen.findElement(By.xpath(".//input[contains(@name,'ownQuestion')]"));
            if (itemBankMyQuestions.isEnabled()){
                itemBankMyQuestions.click();
                System.out.println("Clicked on the My Questions input item bank.");
                TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  My Questions item bank selected successfully");
            } else {
                System.out.println("Could not clicked on the My Questions input item bank.");
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed : My Questions item bank could not selected");
            }

        }
    }

    public void NextButton() throws InterruptedException {
        Thread.sleep(1000);
        container_Footer.isDisplayed();

        helper.scrollToElement(driver, container_Footer);
        Thread.sleep(1000);

        WebElement btn_Next = container_Footer.findElement(By.xpath("//button[normalize-space()='Next']"));

        if (btn_Next.isDisplayed() && btn_Next.isEnabled()) {
            btn_Next.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed : Next button clicked successfully");

            Thread.sleep(1000);
            String currentAssessmentInformationURL = driver.getCurrentUrl();
            System.out.println("New Assessment Information URL is: " + currentAssessmentInformationURL);

            if (currentAssessmentInformationURL.contains("/content/assessment/authoring/")) {
                System.out.println("Assessment Information URL verification passed.");
                TestRunner.getTest().log(Status.INFO, "Assessment Information URL verification passed");

            } else {
                TestRunner.getTest().log(Status.INFO, "Assessment Information URL verification failed");
            }

        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Next button is not displayed or clickable.");
//            throw new RuntimeException("Assessment Information URL verification failed.");

        }

    }

//    Assessment Information

    public void AssessmentInformation() throws InterruptedException{
        Thread.sleep(1000);

        wrapper_AssessmentInformation.isDisplayed();

        WebElement edt_AssessmentTitle = wrapper_AssessmentInformation.findElement(By.xpath("//input[@name='title']"));
        edt_AssessmentTitle.clear();
        edt_AssessmentTitle.sendKeys(CustomAssessmentName);
        TestRunner.getTest().log(Status.INFO, "Name of new custom assessment: " + CustomAssessmentName);
        Thread.sleep(1000);

        WebElement edt_AssessmentSubTitle = wrapper_AssessmentInformation.findElement(By.xpath("//input[@name='subTitle']"));
        edt_AssessmentSubTitle.clear();
        edt_AssessmentSubTitle.sendKeys(CustomAssessmentName);
        TestRunner.getTest().log(Status.INFO, "Name of new custom assessment sub title: " + CustomAssessmentName);
        Thread.sleep(1000);

        WebElement dropDownCourses = wrapper_AssessmentInformation.findElement(By.xpath("(//div[contains(@class, 'selectTextFieldsWrapper')])[3]"));
        dropDownCourses.click();

        WebElement listCourse = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[@role='listbox']")));
        List<WebElement> optionsCourses = listCourse.findElements(By.xpath(".//li"));

        System.out.println("Courses List is: " + optionsCourses.size());

        if (optionsCourses.isEmpty()) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : No options found in the courses dropdown.");
            throw new RuntimeException("No options found in the courses dropdown.");
        } else {
            System.out.println("Courses:");

            for (WebElement course : optionsCourses) {
                System.out.println(course.getText());
                if (course.getText().equals(selectedCourse)) {
                    course.click();
                    System.out.println("Clicked on Course: " + selectedCourse);
                    TestRunner.getTest().log(Status.INFO, "Selected course for new custom assessment: " + selectedCourse);
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed : Course Select successfully");
                    break;
                }
            }
        }

        Thread.sleep(1000);
//        wrapper_AssessmentInformation.findElement(By.xpath("(//div[@class = 'tox-edit-area'])[1]"));

    }

    public void AddMultipleCustomQuestions() throws InterruptedException {
        Thread.sleep(1000);
        container_NewQuestions.isDisplayed();

        WebElement panelQuestions = container_NewQuestions.findElement(By.xpath("//div[contains(@class, 'SelectQuestionsRightWrapper')]"));
        WebElement panelHeaderTotalQuestions = panelQuestions.findElement(By.xpath("//div[contains(@class, 'leftQuestionHeader')]"));
        System.out.println("Header questions shows: " + panelHeaderTotalQuestions.getText());

        WebElement totalQuestions = panelHeaderTotalQuestions.findElement(By.xpath("//span[contains(@class, 'title-counter')]"));
        System.out.println("Total Questions found: " + totalQuestions.getText());
        TestRunner.getTest().log(Status.INFO, "Total Questions: " + totalQuestions.getText());

        WebElement btnClearAllFilters = panelQuestions.findElement(By.xpath("//button[normalize-space()='Clear all Filter']"));
        btnClearAllFilters.click();
        System.out.println("All filters cleared!");
        TestRunner.getTest().log(Status.INFO, "All filters cleared successfully");

        Thread.sleep(500);

        WebElement typeContainer = driver.findElement(By.xpath("(//div[@aria-labelledby='Questions-header']//div[contains(@class, 'treeViewCheckbox') and contains(@class, 'false')])[1]"));
        helper.scrollToElement(driver, typeContainer);
        Thread.sleep(2000);
        List<WebElement> totalTypes = typeContainer.findElements(By.tagName("li"));

        System.out.println("Total types are: " + totalTypes.size());
        TestRunner.getTest().log(Status.INFO, "Total types of questions are: " + totalTypes.size());

        JavascriptExecutor js = (JavascriptExecutor) driver;

        WebElement lastChecked = null;

        List<String> skippedTypes = Arrays.asList("Drawing", "Fill-in-the-Blank Typing", "Image Labeling", "Label Image Typing", "Open Response");

        if (!totalTypes.isEmpty()) {
            for (WebElement type : totalTypes) {
                typeNameText = type.findElement(By.xpath(".//span[@class='text']")).getText();
                Thread.sleep(1000);
                helper.scrollToElement(driver, type);
                Thread.sleep(500);

                if (skippedTypes.stream().anyMatch(typeNameText::contains)) {
                    System.out.println("Skipping: " + typeNameText);
                    continue;
                }
                WebElement checkbox = type.findElement(By.xpath(".//input[@type='checkbox']"));

                if (lastChecked != null && lastChecked.isSelected()) {
                    js.executeScript("arguments[0].click();", lastChecked);
                    System.out.println("Unchecked last checkbox.");
                }

                if (!checkbox.isSelected()) {
                    js.executeScript("arguments[0].click();", checkbox);
                    System.out.println("Question Type Selected: " + typeNameText);
                    TestRunner.getTest().log(Status.INFO, "Question Type Selected: " + typeNameText);
                    lastChecked = checkbox;
                    Thread.sleep(1000);
                }

                btn_ApplyFilter.click();
                Thread.sleep(1000);
                TestRunner.getTest().log(Status.PASS, "Test Case Passed : Apply filter clicked successfully on question types");

                selectAndProcessCheckboxes(panelQuestions);
            }
        }
    }

    public void AddMultipleCustomMyQuestions() throws InterruptedException {
        Thread.sleep(1000);
        container_NewQuestions.isDisplayed();

        WebElement panelQuestions = container_NewQuestions.findElement(By.xpath("//div[contains(@class, 'SelectQuestionsRightWrapper')]"));
        WebElement panelHeaderTotalQuestions = panelQuestions.findElement(By.xpath("//div[contains(@class, 'leftQuestionHeader')]"));
        System.out.println("Header questions shows: " + panelHeaderTotalQuestions.getText());

        WebElement totalQuestions = panelHeaderTotalQuestions.findElement(By.xpath("//span[contains(@class, 'title-counter')]"));
        System.out.println("Total Questions found: " + totalQuestions.getText());
        TestRunner.getTest().log(Status.INFO, "Total Questions: " + totalQuestions.getText());

        WebElement btnClearAllFilters = panelQuestions.findElement(By.xpath("//button[normalize-space()='Clear all Filter']"));
        btnClearAllFilters.click();
        System.out.println("All filters cleared!");
        TestRunner.getTest().log(Status.INFO, "All filters cleared successfully");

        TestRunner.getTest().log(Status.INFO, "I'm in to select the question status 'Active'");
        wait.until(ExpectedConditions.elementToBeClickable(dropDown_QuestionStatus));

        if (dropDown_QuestionStatus.isEnabled()) {
            dropDown_QuestionStatus.click();
            TestRunner.getTest().log(Status.INFO, "Question status dropdown clicked successfully");

            WebElement questionStatusDropdown = wait.until(ExpectedConditions.elementToBeClickable(list_QuestionStatus));
            List<WebElement> questionStatusList = questionStatusDropdown.findElements(By.xpath(".//li"));

            if (questionStatusList.isEmpty()) {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : No question status available in the dropdown list");
            } else {
                boolean statusFound = false;
                for (WebElement statusList : questionStatusList) {
                    String statusText = statusList.getText().trim();
                    if (statusText.equalsIgnoreCase("Active")) {
                        statusList.click();
                        TestRunner.getTest().log(Status.PASS, "Question status selected: " + statusText);
                        statusFound = true;
                        break;
                    }
                }
                if (!statusFound) {
                    TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : 'Active' status not found in the dropdown list");
                }
            }

        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : Question status dropdown is not enabled.");
        }

        Thread.sleep(2000);
        WebElement filterContainer = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@aria-labelledby='Questions-header']")));
        WebElement btnMyQuestions = filterContainer.findElement(By.xpath("//button[@value = 'myQuestions']"));
        wait.until(ExpectedConditions.elementToBeClickable(btnMyQuestions));
        btnMyQuestions.click();
        Thread.sleep(2000);

        WebElement typeMyQuestions = driver.findElement(By.xpath("(//div[@aria-labelledby='Questions-header']//div[contains(@class, 'treeViewCheckbox') and contains(@class, 'false')])[2]"));
        helper.scrollToElement(driver, typeMyQuestions);
        Thread.sleep(2000);
        List<WebElement> totalTypes = typeMyQuestions.findElements(By.tagName("li"));

        System.out.println("Total types are: " + totalTypes.size());
        TestRunner.getTest().log(Status.INFO, "Total types of questions are: " + totalTypes.size());

        JavascriptExecutor js = (JavascriptExecutor) driver;

        WebElement lastChecked = null;

        List<String> skippedTypes = Arrays.asList("Drawing", "Fill-in-the-Blank Typing", "Image Labeling", "Label Image Typing", "Open Response");

        if (!totalTypes.isEmpty()) {
            for (WebElement type : totalTypes) {
                typeNameText = type.findElement(By.xpath(".//span[@class='text']")).getText();
                Thread.sleep(1000);
                helper.scrollToElement(driver, type);
                Thread.sleep(500);

                if (skippedTypes.stream().anyMatch(typeNameText::contains)) {
                    System.out.println("Skipping: " + typeNameText);
                    continue;
                }

                WebElement checkbox = type.findElement(By.xpath(".//input[@type='checkbox']"));

                if (!checkbox.isEnabled()) {
                    System.out.println("Checkbox for " + typeNameText + " is disabled. Skipping.");
                    TestRunner.getTest().log(Status.INFO, "Checkbox for " + typeNameText + " is disabled. Skipping.");
                    continue;
                }

                if (lastChecked != null && lastChecked.isSelected()) {
                    js.executeScript("arguments[0].click();", lastChecked);
                    System.out.println("Unchecked last checkbox.");
                }

                if (!checkbox.isSelected()) {
                    js.executeScript("arguments[0].click();", checkbox);
                    System.out.println("Question Type Selected: " + typeNameText);
                    TestRunner.getTest().log(Status.INFO, "Question Type Selected: " + typeNameText);
                    lastChecked = checkbox;
                    Thread.sleep(1000);
                }

                btn_ApplyFilter.click();
                Thread.sleep(1000);
                TestRunner.getTest().log(Status.PASS, "Test Case Passed : Apply filter clicked successfully on question types");

                selectAndProcessCheckboxes(panelQuestions);
            }
        }
    }

    public void selectAndProcessCheckboxes(WebElement panelQuestions) {
        wait.until(ExpectedConditions.visibilityOf(panelQuestions));
        List<WebElement> checkboxes = panelQuestions.findElements(By.xpath(".//tbody//input[@type='checkbox']"));
        System.out.println("Total size in tbody: " + checkboxes.size());
        TestRunner.getTest().log(Status.INFO, "Total question in table: " + typeNameText  + " " + checkboxes.size());

        int totalCheckboxesClicked = 0;

        // Randomly click 3 to 4 checkboxes
        if (!checkboxes.isEmpty()) {
            Random random = new Random();
            Collections.shuffle(checkboxes, random);

            // Determine the number of checkboxes to click (between 3 and 4)
            int checkboxesToClick = Math.min(checkboxes.size(), 2 + random.nextInt(1));
            totalCheckboxesToClick += checkboxesToClick;
            System.out.println("Number of checkboxes to click: " + checkboxesToClick);

            for (int i = 0; i < checkboxesToClick; i++) {
                WebElement checkbox = checkboxes.get(i);
                if (!checkbox.isSelected()) {
                    checkbox.click();
                    totalCheckboxesClicked++;
                    System.out.println("Checkbox at index " + i + " clicked.");
                }
            }

            System.out.println("Total checkboxes clicked: " + totalCheckboxesClicked);
            System.out.println("Total checkboxes to click (sum across all calls): " + totalCheckboxesToClick);
            TestRunner.getTest().log(Status.INFO, "Total question(s) selected of type " + typeNameText + ": "+ totalCheckboxesToClick);

            WebElement btnAddSelected = panelQuestions.findElement(By.xpath(".//button[normalize-space()='Add Selected']"));
            if (btnAddSelected != null && btnAddSelected.isDisplayed()) {
                helper.scrollToElement(driver,btnAddSelected);
//                btnAddSelected.click();
                JavascriptExecutor js = (JavascriptExecutor) driver;
                js.executeScript("arguments[0].click();", btnAddSelected);
                System.out.println("Selected questions added!");
                TestRunner.getTest().log(Status.PASS, "Test Case Passed    :   Selected questions added successfully");

            }
        } else {
            System.out.println("No checkboxes found in tbody.");
            TestRunner.getTest().log(Status.INFO, "No questions found in table of type " + typeNameText);
        }
    }


//    Finalize Question: Delete/Order/Weight

    public void setSequenceWeightPercentageRepeatedly() {
        try {
            WebElement btnShowAll = driver.findElement(By.xpath("//div[@class='pagingClass']//button[@id='btn-saveNext']"));

            if (btnShowAll.isDisplayed() && btnShowAll.isEnabled()) {
                btnShowAll.click();
                System.out.println("Show All Button clicked.");
            } else {
                System.out.println("Show All Button not clickable.");
                TestRunner.getTest().log(Status.WARNING, "Show All Button not clickable.");
            }

            Thread.sleep(5000);

            wait.until(ExpectedConditions.visibilityOf(container_FinalizeQuestion));

            WebElement wrapperTable = container_FinalizeQuestion.findElement(By.xpath("//div[contains(@class, 'MetaDataWrapper')]//table"));
            List<WebElement> rows = wrapperTable.findElements(By.tagName("tr"));

            int totalRowsCount = rows.size() - 1;

            if (totalRowsCount <= 0) {
                System.out.println("No rows found in the table.");
                TestRunner.getTest().log(Status.WARNING, "No rows found in the table.");
                return;
            }

            Random random = new Random();

            for (int i = 1; i < rows.size(); i++) {
                try {
                    WebElement row = rows.get(i);
                    List<WebElement> cells = row.findElements(By.tagName("td"));

                    WebElement weightInput = cells.get(2).findElement(By.tagName("input"));
                    WebElement percentageInput = cells.get(3).findElement(By.tagName("input"));

                    scrollIntoView(weightInput);
                    scrollIntoView(percentageInput);

                    clearInputWithJs(driver, weightInput);
                    clearInputWithJs(driver, percentageInput);

                    int randomWeight = random.nextInt(10) + 1;
                    int randomPercentage = random.nextInt(100);

                    sendKeysWithJs(driver, weightInput, String.valueOf(randomWeight));
                    sendKeysWithJs(driver, percentageInput, String.valueOf(randomPercentage));

                } catch (Exception rowEx) {
                    System.out.println("Error handling row " + i + ": " + rowEx.getMessage());
                    TestRunner.getTest().log(Status.WARNING, "Error handling row " + i + ": " + rowEx.getMessage());
                }
            }

            Thread.sleep(500);

            System.out.println("Total rows across all pages: " + totalRowsCount);
            TestRunner.getTest().log(Status.INFO, "Total questions across all pages: " + totalRowsCount);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Entered Weight and Percentage successfully");

        } catch (Exception e) {
            System.out.println("Exception in setSequenceWeightPercentageRepeatedly: " + e.getMessage());
            TestRunner.getTest().log(Status.FAIL, "Exception in setSequenceWeightPercentageRepeatedly: " + e.getMessage());
        }
    }

    public void setSequenceWeightPercentage() throws InterruptedException {

        wait.until(ExpectedConditions.visibilityOf(container_FinalizeQuestion));

        WebElement wrapperTable = container_FinalizeQuestion.findElement(By.xpath("//div[contains(@class, 'MetaDataWrapper')]//table"));

        List<WebElement> rows = wrapperTable.findElements(By.tagName("tr"));

        for (int i = 1; i < rows.size(); i++) {
            WebElement row = rows.get(i);
            List<WebElement> cells = row.findElements(By.tagName("td"));

            WebElement sequenceInput = cells.get(1).findElement(By.tagName("input"));
            WebElement weightInput = cells.get(2).findElement(By.tagName("input"));
            WebElement percentageInput = cells.get(3).findElement(By.tagName("input"));

            scrollIntoView(sequenceInput);
            scrollIntoView(weightInput);
            scrollIntoView(percentageInput);

            clearInputWithJs(driver, sequenceInput);
            clearInputWithJs(driver, weightInput);
            clearInputWithJs(driver, percentageInput);

            Random random = new Random();
            int randomSequence = random.nextInt(rows.size()) + 1;
            int randomWeight = random.nextInt(10) + 1;
            int randomPercentage = random.nextInt(100);

            sendKeysWithJs(driver, sequenceInput, String.valueOf(randomSequence));
            sendKeysWithJs(driver, weightInput, String.valueOf(randomWeight));
            sendKeysWithJs(driver, percentageInput, String.valueOf(randomPercentage));
        }
    }

    private void scrollIntoView(WebElement element) {
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
    }
    private void clearInputWithJs(WebDriver driver, WebElement element) {
        ((JavascriptExecutor) driver).executeScript("arguments[0].value = '';", element);
    }
    private void sendKeysWithJs(WebDriver driver, WebElement element, String keys) {
        ((JavascriptExecutor) driver).executeScript("arguments[0].value = arguments[1];", element, keys);
    }

    public void listFinalizeQuestions() throws InterruptedException{
        Thread.sleep(1000);

        container_FinalizeQuestion.isDisplayed();

        WebElement tableFinalizeQuestions = container_FinalizeQuestion.findElement(By.xpath("//table[contains(@class,'MuiTable-root')]"));

        WebElement tableBody = tableFinalizeQuestions.findElement(tagName("tbody"));

        List<WebElement> rowsFinalizeQuestions = tableBody.findElements(tagName("tr"));

        for (WebElement rowFinalizeQuestions : rowsFinalizeQuestions) {
            System.out.println(rowFinalizeQuestions.getText());
        }

        Actions actions = new Actions(driver);

        List<WebElement> valuesDragAble = tableFinalizeQuestions.findElements(By.xpath("//td[@role='button' or @role='combobox']"));
        System.out.println("Total dragdrop able questions: " + valuesDragAble.size());

        WebElement secondRow = null;
        if (rowsFinalizeQuestions.size() > 1) {
            secondRow = rowsFinalizeQuestions.get(1);
        }

        for (WebElement dragValue : valuesDragAble) {
            System.out.println("Value to be dragged: " + dragValue.getText());
            highlightElement(dragValue);

            if (secondRow != null) {
                // Perform drag and drop using moveToElement method
                actions.moveToElement(dragValue).clickAndHold().moveToElement(secondRow).release().build().perform();
                highlightElement(secondRow);
            } else {
                // If there is no second row, you may need to handle this case accordingly
                System.out.println("There is no second row to drop the element after.");
                break;
            }

            Thread.sleep(2000);
        }

    }

    private void highlightElement(WebElement element) {
        JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
        jsExecutor.executeScript("arguments[0].setAttribute('style', 'border: 2px solid red;');", element);
        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        jsExecutor.executeScript("arguments[0].setAttribute('style', '');", element);
    }

//    Summary/Save

    public void SaveNewAssessment() throws InterruptedException {
        wait.until(ExpectedConditions.elementToBeClickable(assessmentStatusDropdown));
        assessmentStatusDropdown.click();
        Thread.sleep(2000);

        List<WebElement> assessmentStatusOptions = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//ul[@role='listbox']//li")));

        for (WebElement option : assessmentStatusOptions) {
            System.out.println("Assessment Status: " + option.getText());
            if (option.getText().equals(assessmentStatus)) {
                System.out.println("Selected assignment status: " + option.getText());
                TestRunner.getTest().log(Status.INFO, "Selected assignment status: " + option.getText());
                option.click();
                break;
            }
        }

        Thread.sleep(2000);
        wait.until(ExpectedConditions.elementToBeClickable(btn_Save));
        btn_Save.click();
        TestRunner.getTest().log(Status.PASS, "Test Case Passed : Click on Save New Assessment button successfully");
    }

//    Search Custom Assessment

    public void SelectCourseSearchForCustomAssessment() throws InterruptedException {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//div[contains(@class, 'selectTextFieldsWrapper')])[1]")));
        if (dropDown_SelectCourse.isEnabled() && dropDown_SelectCourse.isDisplayed() ) {
            dropDown_SelectCourse.click();
            TestRunner.getTest().log(Status.INFO, "Course dropdown enabled and click on course dropdown");
            Thread.sleep(1000);
        }

        WebElement listCourse = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[@role='listbox']")));
        List<WebElement> optionsCourses = listCourse.findElements(By.xpath(".//li"));

        System.out.println("Courses List is: " + optionsCourses.size());
        TestRunner.getTest().log(Status.INFO, "Total courses: " + optionsCourses.size());

        if (optionsCourses.isEmpty()) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : No options found in the courses dropdown.");
            throw new RuntimeException("No Course Found");

        } else {
            System.out.println("Courses:");

            for (WebElement course : optionsCourses) {
                System.out.println(course.getText());
                if (course.getText().equals(selectedCourse)) {
                    System.out.println("Clicked on Course: " + selectedCourse);
                    TestRunner.getTest().log(Status.INFO, "Selected course: " + course.getText());
                    course.click();
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed : Course is selected successfully" + selectedCourse);
                    break;
                }
            }
        }
    }

    public void ClickAndApplyCustomAssessment() throws InterruptedException{
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));

        WebElement gridAssessmentContent = wait.until(ExpectedConditions.visibilityOf(div_AssessmentContent));

        helper.scrollToElement(driver, gridAssessmentContent);

        WebElement btn_Assessment = driver.findElement(By.xpath("//div[@aria-label='Platform']//button[.//span[contains(text(), 'My Assessments')]]"));
        btn_Assessment.click();
        TestRunner.getTest().log(Status.INFO, "My Assessment clicked successfully in assessment grid");

        WebElement typeAssessment = driver.findElement(By.xpath("(//div[@aria-labelledby='Assessments-header']//div[contains(@class, 'treeViewCheckbox') and contains(@class, 'false')])[2]"));
        List<WebElement> totalTypes = typeAssessment.findElements(By.tagName("li"));

        System.out.println("Total types are: " + totalTypes.size());
        TestRunner.getTest().log(Status.INFO, "Total types in My Assessment are: " + totalTypes.size());

        for (WebElement typeName : totalTypes) {
            String typeNameText = typeName.findElement(By.xpath(".//span[@class='text']")).getText();
            System.out.println("Type name is: " + typeNameText);
            TestRunner.getTest().log(Status.INFO, "Type name is: " + typeNameText);

//            if (typeNameText.contains("Custom Student Book")) {
                WebElement checkBox = typeName.findElement(By.xpath(".//span[@role='checkbox']"));

                boolean isChecked = checkBox.isSelected();
                if (isChecked) {
                    System.out.println("Custom Student Book is already selected.");
                } else {
                    checkBox.click();
                    System.out.println("Custom Student Book is now selected.");
                }
//                break;
//            }
        }

        WebElement ApplyFilterButton = wait.until(ExpectedConditions.elementToBeClickable(btn_ApplyFilter));
        ApplyFilterButton.click();
        System.out.println("Apply Filter button has been clicked.");
        TestRunner.getTest().log(Status.INFO, "Apply Filter button has been clicked.");

        TestRunner.getTest().log(Status.PASS, "Test Case Passed : Custom Student Book filter applied successfully");

        AssessmentTableInReadAble();

    }

    public void ClickAndEnterNameForSearchAssessment() throws InterruptedException{
        WebElement divSearchEditFieldAssessment = wait.until(ExpectedConditions.visibilityOf(div_Assessments));

        helper.scrollToElement(driver, divSearchEditFieldAssessment);

        WebElement edt_SearchAssessment = divSearchEditFieldAssessment.findElement(By.xpath(".//input[@placeholder='Search Assessments']"));

        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].value='';", edt_SearchAssessment);

        TestRunner.getTest().log(Status.INFO, "Want to search assessment name is: " + CustomAssessmentName);

        edt_SearchAssessment.sendKeys(CustomAssessmentName);

        AssessmentTableInReadAble();

        List<WebElement> assessmentRows = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//div[contains(@class, 'AssessmentDashboardRightPanel')]//tbody//tr")));
        System.out.println("Assessment dashboard loaded with " + assessmentRows.size() + " rows.");
        TestRunner.getTest().log(Status.INFO, "Total number of My Assessments are: " + assessmentRows.size());

        try {
            for (WebElement row : assessmentRows) {
                WebElement rowText = wait.until(ExpectedConditions.visibilityOf(row.findElement(By.xpath(".//td[2]//div"))));
                System.out.println(rowText.getText());
                if (rowText.getText().equals(CustomAssessmentName)) {
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed : New custom assessment search successfully");
                }else {
                    System.out.println("No assessment found with the name: " + CustomAssessmentName);
                    TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Custom new created assessment {" + CustomAssessmentName + "} not found in table:");
//                    throw new RuntimeException("Custom new created assessment not found in table");
                }
            }
        } catch (StaleElementReferenceException e) {
            System.out.println("Stale element encountered, retrying...");
            assessmentRows = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//div[contains(@class, 'AssessmentDashboardRightPanel')]//tbody//tr")));
        }

    }

    public void verifyAssessmentStatus() throws InterruptedException{
        WebElement assessmentRow = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(@class, 'AssessmentDashboardRightPanel')]//tbody//tr")));
        WebElement statusAssessment = assessmentRow.findElement(By.xpath(".//td[contains(@class, 'cell-4')]"));
        System.out.println(statusAssessment.getText());

        if (statusAssessment.getText().equalsIgnoreCase(assessmentStatus)){
            TestRunner.getTest().log(Status.PASS, "Assessment status matched...");
        } else {
            TestRunner.getTest().log(Status.FAIL, "Assessment status not matched...");
        }
    }

    public void ClickOnAssignAndProcessToAssignAssessment() {
        try {
            WebElement SearchAssessmentDashboard = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class, 'AssessmentDashboardRightPanel')]//tbody")));

            List<WebElement> totalSearchAssignments = SearchAssessmentDashboard.findElements(By.xpath(".//tr"));
            System.out.println("Total Search Assignment is: " + totalSearchAssignments.size());

            boolean found = false;

            for (WebElement searchAssignment : totalSearchAssignments) {
                AssessmentTableInReadAble();
                WebElement nameElement = searchAssignment.findElement(By.xpath(".//td[2]//div"));
                String searchedAssignmentName = nameElement.getText();

                System.out.println("Searched assignment name: " + searchedAssignmentName);
                TestRunner.getTest().log(Status.INFO, "Searched assignment name: " + searchedAssignmentName);

                if (searchedAssignmentName.equals(CustomAssessmentName)) {
                    WebElement assignButton = searchAssignment.findElement(By.xpath(".//button[normalize-space()='Assign']"));
                    if (assignButton.isDisplayed() && assignButton.isEnabled()) {
                        System.out.println("Assign button found for: " + CustomAssessmentName);
                        found = true;
                        Thread.sleep(1000);
                        ReleaseCustomAssignmentForCorrectAnswers();
                        TestRunner.getTest().log(Status.PASS, "Test Case Passed : Release Custom Assignment for correct Answers successfully");

                        Thread.sleep(1000);
//                        ReleaseSpecificAssignmentForInCorrectAnswers();
                        TestRunner.getTest().log(Status.PASS,"Test Case Passed    :   Release Custom Assignment for In-correct Answers successfully");
                    }

                    Thread.sleep(1000);
                    break;
                }
            }

            if (!found) {
                System.out.println("No assignment found with the name: " + CustomAssessmentName);
                throw new RuntimeException("Custom Assessment Name not found");

            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public void ClickOnAssignAndProcessToAssignAssessmentInGroup() {
        try {
            WebElement SearchAssessmentDashboard = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class, 'AssessmentDashboardRightPanel')]//tbody")));

            List<WebElement> totalSearchAssignments = SearchAssessmentDashboard.findElements(By.xpath(".//tr"));
            System.out.println("Total Search Assignment is: " + totalSearchAssignments.size());

            boolean found = false;

            for (WebElement searchAssignment : totalSearchAssignments) {
                AssessmentTableInReadAble();
                WebElement nameElement = searchAssignment.findElement(By.xpath(".//td[2]//div"));
                String searchedAssignmentName = nameElement.getText();

                System.out.println("Searched assignment name: " + searchedAssignmentName);
                TestRunner.getTest().log(Status.INFO, "Searched assignment name: " + searchedAssignmentName);

                if (searchedAssignmentName.equals(CustomAssessmentName)) {
                    WebElement assignButton = searchAssignment.findElement(By.xpath(".//button[normalize-space()='Assign']"));
                    if (assignButton.isDisplayed() && assignButton.isEnabled()) {
                        System.out.println("Assign button found for: " + CustomAssessmentName);
                        found = true;
                        Thread.sleep(1000);
                        ReleaseCustomAssignmentInGroupForCorrectAnswers();
                        TestRunner.getTest().log(Status.PASS, "Test Case Passed : Release Custom Assignment for correct Answers successfully");

                        Thread.sleep(1000);
//                        ReleaseSpecificAssignmentForInCorrectAnswers();
                        TestRunner.getTest().log(Status.PASS,"Test Case Passed    :   Release Custom Assignment for In-correct Answers successfully");
                    }

                    Thread.sleep(1000);
                    break;
                }
            }

            if (!found) {
                System.out.println("No assignment found with the name: " + CustomAssessmentName);
                throw new RuntimeException("Custom Assessment Name not found");

            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public void AssessmentTableInReadAble() throws InterruptedException{
        Thread.sleep(5000);
        WebElement assessmentTable = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(@class, 'AssessmentDashboardRightPanel')]//tbody")));

        if (assessmentTable.isEnabled() && assessmentTable.isDisplayed()) {
            List<WebElement> assessmentRows = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//div[contains(@class, 'AssessmentDashboardRightPanel')]//tbody//tr")));
            System.out.println("Assessment dashboard loaded with " + assessmentRows.size() + " rows.");
            TestRunner.getTest().log(Status.INFO, "Total number of My Assessments are: " + assessmentRows.size());

            boolean rowsLoaded = false;
            while (!rowsLoaded) {
                try {
                    for (WebElement row : assessmentRows) {
                        WebElement rowText = wait.until(ExpectedConditions.visibilityOf(row.findElement(By.xpath(".//td[2]//div"))));
                        System.out.println(rowText.getText());
                    }
                    rowsLoaded = true;
                } catch (StaleElementReferenceException e) {
                    System.out.println("Stale element encountered, retrying...");
                    assessmentRows = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//div[contains(@class, 'AssessmentDashboardRightPanel')]//tbody//tr")));
                }
            }

            System.out.println("All rows are in readable mode.");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed    :   All assessments loaded successfully");
        } else {
            System.out.println("No assessment found with the name: " + CustomAssessmentName);
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Custom new created assessment {" + CustomAssessmentName + "} not found in table:");
            throw new RuntimeException("Custom new created assessment not found in table");
        }

    }

    public void ReleaseCustomAssignmentForCorrectAnswers() throws InterruptedException {
        TestRunner.startTest("Release custom assignment that attempted for correct answer");
        btn_Assign.click();

        WebElement dialogAssignment = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@role='dialog']")));
        dialogAssignment.isDisplayed();
        TestRunner.getTest().log(Status.INFO, "Release assignment prompt shows successfully");

        releaseAssignment_pf.getAssignmentTypeFromAssignment();
        correctAnswerExecutor.EnterAssignmentTitleForCorrectAnswers();
        correctAnswerExecutor.selectSpecificClasses();
        assignAssessment.setDateTimeAndCategory();
        assignAssessment.enterAdditionalSettings();
        assignAssessment.enterWeightPercentage();
        assignAssessment.assignAssignment();
        assignAssessment.verifyDialogBox();
    }

    public void ReleaseCustomAssignmentInGroupForCorrectAnswers() throws InterruptedException {
        TestRunner.startTest("Release custom assignment that attempted for correct answer");
        btn_Assign.click();

        WebElement dialogAssignment = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@role='dialog']")));
        dialogAssignment.isDisplayed();
        TestRunner.getTest().log(Status.INFO, "Release assignment prompt shows successfully");

        releaseAssignment_pf.getAssignmentTypeFromAssignment();
        correctAnswerExecutor.EnterAssignmentTitleForCorrectAnswers();
        correctAnswerExecutor.selectSpecificGroup();
        assignAssessment.setDateTimeAndCategory();
        assignAssessment.enterAdditionalSettings();
        assignAssessment.enterWeightPercentage();
        assignAssessment.assignAssignment();
        assignAssessment.verifyDialogBox();
    }

    public void ReleaseSpecificAssignmentForInCorrectAnswers() throws InterruptedException{
        TestRunner.startTest("Release custom assignment that attempted for incorrect answer");
        btn_Assign.click();

        WebElement dialogAssignment = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@role='dialog']")));
        dialogAssignment.isDisplayed();
        TestRunner.getTest().log(Status.INFO, "Release assignment prompt shows successfully");

        inCorrectAnswerExecutor.EnterAssignmentTitleForInCorrectAnswers();
        inCorrectAnswerExecutor.selectSpecificClasses();
        assignAssessment.setDateTimeAndCategory();
        assignAssessment.enterAdditionalSettings();
        assignAssessment.enterWeightPercentage();
        assignAssessment.assignAssignment();
        assignAssessment.verifyDialogBox();
    }

//    Negative scenarios

    public void testEmptyAssessmentTitle() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into Validate Empty Title Show Validation");
        System.out.println("I'm into Validate Empty Title Show Validation");

        try {
            // Perform actions
            AddNewButton();
            SelectItemBank();
            NextButton();

            WebElement edt_AssessmentTitle = driver.findElement(By.xpath("//input[@name='title']"));
            edt_AssessmentTitle.clear();  // Clear the title to trigger validation

            NextButton();  // Attempt to go to the next step without title

            // Check for validation error
            WebElement titleError = driver.findElement(By.xpath("//p[contains(text(),'Required')]"));

            if (titleError.isDisplayed()) {
                System.out.println("Test Passed : Validation error displayed: 'Required'.");
                TestRunner.getTest().log(Status.PASS, "Test Passed : Validation error for 'Required' is correctly displayed.");
            } else {
                System.out.println("Validation error not displayed. Test Failed.");
                TestRunner.getTest().log(Status.FAIL, "Validation error for 'Required' is not displayed.");
                assert false;  // Fail the test
            }

        } catch (NoSuchElementException e) {
            // If the element is not found, the validation failed
            System.out.println("Validation error not found. Test Failed.");
            TestRunner.getTest().log(Status.FAIL, "Validation error for 'Required' is not found.");
            assert false;  // Fail the test
        }

    }

    public void testEmptyAssessmentCourse() throws InterruptedException{

        TestRunner.getTest().log(Status.INFO, "I'm into Validate Empty Course Show Validation");
        System.out.println("I'm into Validate Empty Course Show Validation");

        try {
            Thread.sleep(1000);

            wrapper_AssessmentInformation.isDisplayed();

            WebElement edt_AssessmentTitle = wrapper_AssessmentInformation.findElement(By.xpath("//input[@name='title']"));
            edt_AssessmentTitle.clear();
            edt_AssessmentTitle.sendKeys(CustomAssessmentName);
            TestRunner.getTest().log(Status.INFO, "Name of new custom assessment: " + CustomAssessmentName); // Clear the title to trigger validation
            Thread.sleep(1000);

            WebElement edt_AssessmentSubTitle = wrapper_AssessmentInformation.findElement(By.xpath("//input[@name='subTitle']"));
            edt_AssessmentSubTitle.clear();
            edt_AssessmentSubTitle.sendKeys(CustomAssessmentName);
            TestRunner.getTest().log(Status.INFO, "Name of new custom assessment sub title: " + CustomAssessmentName);
            Thread.sleep(1000);

            NextButton();  // Attempt to go to the next step without title

            // Check for validation error
            WebElement titleCourse = driver.findElement(By.xpath("//p[contains(text(),'Required')]"));

            if (titleCourse.isDisplayed()) {
                System.out.println("Test Passed : Validation error displayed For Course: 'Required'.");
                TestRunner.getTest().log(Status.PASS, "Test Passed : Validation error for 'Required' is correctly displayed For Course");
            } else {
                System.out.println("Validation error not displayed For Course. Test Failed.");
                TestRunner.getTest().log(Status.FAIL, "Validation error for 'Required' is not displayed For Course");
                assert false;  // Fail the test
            }

        } catch (NoSuchElementException e) {
            // If the element is not found, the validation failed
            System.out.println("Validation error not found For Course. Test Failed.");
            TestRunner.getTest().log(Status.FAIL, "Validation error for 'Required' is not found For Course");
            assert false;  // Fail the test
        }

    }

    public void testEmptyDescription() throws InterruptedException {
        AddNewButton();
        SelectItemBank();
        NextButton();
        AssessmentInformation();

        WebElement edt_Description = driver.findElement(By.xpath("(//div[@class = 'tox-edit-area'])[1]"));
        edt_Description.clear();

        SaveNewAssessment();

        // Check for validation error
        WebElement descriptionError = driver.findElement(By.xpath("//span[contains(text(),'Description is required')]"));
        assert descriptionError.isDisplayed();
    }

    public void testInvalidAssessmentType() throws InterruptedException {
        AddNewButton();
        SelectItemBank();
        NextButton();
        AssessmentInformation();

        WebElement dropdown_AssessmentType = driver.findElement(By.xpath("//div[contains(@class, 'selectTextFieldsWrapper')][4]"));
        dropdown_AssessmentType.click();

        WebElement listOptions = driver.findElement(By.xpath("//ul[@role='listbox']"));
        List<WebElement> options = listOptions.findElements(By.xpath(".//li"));

        // Select an invalid type (assuming such an option exists for testing)
        WebElement invalidOption = options.get(options.size() - 1);
        invalidOption.click();

        SaveNewAssessment();

        // Verify that an error is shown or the selection is handled correctly
        WebElement typeError = driver.findElement(By.xpath("//span[contains(text(),'Invalid assessment type')]"));
        assert typeError.isDisplayed();
    }

    public void testNoQuestionsSelected() throws InterruptedException {
        AddNewButton();
        SelectItemBank();
        NextButton();
        AssessmentInformation();
        NextButton(); // Proceed without selecting any questions

        // Check for validation error
        WebElement questionsError = driver.findElement(By.xpath("//span[contains(text(),'Select at least one question')]"));
        assert questionsError.isDisplayed();
    }

    public void testInvalidWeightDistribution() throws InterruptedException {
        AddNewButton();
        SelectItemBank();
        NextButton();
        AssessmentInformation();
        NextButton();

        setSequenceWeightPercentage();

        WebElement weightError = driver.findElement(By.xpath("//span[contains(text(),'Weight must be between 0 and 100')]"));
        assert weightError.isDisplayed();
    }

    public void testIncorrectStatusSelection() throws InterruptedException {
        AddNewButton();
        SelectItemBank();
        NextButton();
        AssessmentInformation();

        WebElement dropdown_Status = driver.findElement(By.xpath("//span[text()='Assessment Status']/following-sibling::div//div[@role='button' or @role='combobox']"));
        dropdown_Status.click();

        WebElement listStatusOptions = driver.findElement(By.xpath("//ul[@role='listbox']"));
        List<WebElement> statusOptions = listStatusOptions.findElements(By.xpath(".//li"));

        // Select an incorrect status
        WebElement incorrectStatus = statusOptions.get(statusOptions.size() - 1);
        incorrectStatus.click();

        SaveNewAssessment();

        // Verify error or warning
        WebElement statusError = driver.findElement(By.xpath("//span[contains(text(),'This status does not allow assignments')]"));
        assert statusError.isDisplayed();
    }

    public void ClickStepIIAssessmentInformation() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm into click on Step II Assessment Information from Nav bar");
        System.out.println("I'm into click on Step II Assessment Information from Nav bar");

        WebElement StepIIAssessmentInformation= driver.findElement(By.xpath("//div[contains(@class,'MuiStep-root MuiStep-horizontal')][2]"));

        if (StepIIAssessmentInformation.isDisplayed()){
            helper.scrollToElement(driver, StepIIAssessmentInformation);
            Thread.sleep(3000);
            StepIIAssessmentInformation.click();
            System.out.println("Step-II Assessment Information click successfully fom Nav Bar");
            TestRunner.getTest().log(Status.INFO, "Step-II Assessment Information click successfully fom Nav Bar");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Step-II Assessment Information click successfully fom Nav Bar");
        }else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Step-II Assessment Information not Visible in Nav Bar");
            throw new RuntimeException("Step-II Assessment Information not Visible in Nav Ba");
        }
    }

    public void ValidateInfoRetainedOnStepII() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm into Validate that Information is Retained on Step II ");
        System.out.println("I'm into Validate that Information is Retained on Step II");

        ValidateTitleStepII();
        ValidateCourseStepII();

    }

    public void ValidateTitleStepII() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "Validate Title On stepII that Title is Retained ");
        System.out.println("Validate Title On stepII that Title is Retained ");

        WebElement AssessmentTitle_Retained = wrapper_AssessmentInformation.findElement(By.xpath("//input[@name='title']"));

        //         for Title
        String retrievedTitleStepII = AssessmentTitle_Retained.getAttribute("value");
        System.out.println("Retrieved Title is: " + retrievedTitleStepII);
        TestRunner.getTest().log(Status.INFO, "Retrieved Title is: " + retrievedTitleStepII);

        if (CustomAssessmentName.equals(retrievedTitleStepII)) {
            System.out.println("Test Case Passed: Step II Title information is retained.");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Step II information is retained.");
        } else {
            System.out.println("Test Case Failed: Step II Title information is not retained.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Step II Title information is not retained.");
            throw new RuntimeException("Step II Title information is not retained.");
        }

    }

    public void ValidateCourseStepII() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "Validate Course On stepII that Course is Retained");
        System.out.println("Validate Course On stepII that Course is Retained");

        WebElement selectedValueForCourse = driver.findElement(By.xpath("(//div[contains(@class,'MuiSelect-select MuiSelect-outlined MuiOutlinedInput-input MuiInputBase-input')])[3]/parent::div"));

        String currentSelectedValueForCourse = selectedValueForCourse.getText();
        System.out.println("Retrieved Course is: " + currentSelectedValueForCourse);
        TestRunner.getTest().log(Status.INFO, "Retrieved Course is: " + currentSelectedValueForCourse);

        if (selectedCourse.equals(currentSelectedValueForCourse)) {
            System.out.println("Test Case Passed: Correct course is selected: " + selectedCourse);
            TestRunner.getTest().log(Status.INFO, "Retried Correct course: " + selectedCourse);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Correct course is selected: " + selectedCourse);
        } else {
            System.out.println("Test Case Failed: Incorrect course selected. Expected: " + selectedCourse + ", but found: " + currentSelectedValueForCourse);
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Incorrect course selected. Expected: " + selectedCourse + ", but found: " + currentSelectedValueForCourse);
            throw new RuntimeException("Step II Course information is not retained.");
        }

    }


    public static String TotalSelectedQuestion;

    public void SelectedQuestionOnStepIII() throws InterruptedException{

        TestRunner.getTest().log(Status.INFO, "I'm into Get Total Selected Questions On Step III");
        System.out.println("I'm into Get Total Selected Questions On Step III");

        WebElement total_selectedQuestions= driver.findElement(By.xpath("//div[contains(@class,'leftRight bottomHeader')]/span"));
        helper.scrollToElement(driver,total_selectedQuestions);

        TotalSelectedQuestion = total_selectedQuestions.getText();  // Store the text in the global variable

        System.out.println("Text in the span element: " + TotalSelectedQuestion);

        TestRunner.getTest().log(Status.INFO, "Total Selected Questions : " + TotalSelectedQuestion);
        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Total Selected Questions found Successfully ");


    }

    public void ValidateTotalSelectedQuestionRetained() throws InterruptedException{

        TestRunner.getTest().log(Status.INFO, "I'm into Validate Total Selected Questions On Step III is Retained Or Not");
        System.out.println("I'm into Validate Total Selected Questions On Step III is Retained Or No");

        WebElement Selected_questionStepIII= driver.findElement(By.xpath("//div[contains(@class,'leftRight bottomHeader')]/span"));

        String currentSelectedQuestions = Selected_questionStepIII.getText();
        System.out.println("Retrieved Course is: " + currentSelectedQuestions);
        TestRunner.getTest().log(Status.INFO, "Retrieved Course is: " + currentSelectedQuestions);

        if (TotalSelectedQuestion.equals(currentSelectedQuestions)) {
            System.out.println("Test Case Passed: Total Selected Question Retained: " + TotalSelectedQuestion);
            TestRunner.getTest().log(Status.INFO, "Total Selected Question Retained: " + TotalSelectedQuestion);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Total Selected Question Retained: " + TotalSelectedQuestion);
        } else {
            System.out.println("Test Case Failed: Incorrect Total Selected Question  is not Retained. Expected: " + TotalSelectedQuestion + ", but found: " + currentSelectedQuestions);
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Incorrect Total Selected Question  is not Retained.. Expected: " + TotalSelectedQuestion + ", but found: " + currentSelectedQuestions);
            throw new RuntimeException("Total Selected Question  is not Retained.");
        }
    }

    public void ClickStepIIISelectNewQuestions() throws InterruptedException{

        TestRunner.getTest().log(Status.INFO, "I'm into click on Step III Select New Question from Nav bar");
        System.out.println("I'm into click on Step III Select New Question from Nav bar");

        WebElement StepIIISelectNewQuestions= driver.findElement(By.xpath("//div[contains(@class,'MuiStep-root MuiStep-horizontal')][3]"));

        if (StepIIISelectNewQuestions.isDisplayed()){
            helper.scrollToElement(driver, StepIIISelectNewQuestions);
            StepIIISelectNewQuestions.click();
            System.out.println("StepIII Select New Questions click successfully fom Nav Bar");
            TestRunner.getTest().log(Status.INFO, "Step III Select New Questions click successfully fom Nav Bar");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Step III Select New Questions click successfully fom Nav Bar");
        }else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Step III Select New Questions not Visible in Nav Bar");
            throw new RuntimeException("Step III Select New Questions not Visible in Nav Bar");
        }

    }

    public static String selectedStatusForCustomAssessmentSummary;


    public void SelectStatusForAssignment() throws InterruptedException {

        TestRunner.getTest().log(Status.INFO, "I'm into Select Status For Assignment");
        System.out.println("I'm into Select Status For Assignment");

        wait.until(ExpectedConditions.elementToBeClickable(assessmentStatusDropdown));
        assessmentStatusDropdown.click();
        Thread.sleep(2000);

        List<WebElement> assessmentStatusOptions = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//ul[@role='listbox']//li")));

        for (WebElement option : assessmentStatusOptions) {
            System.out.println("Assessment Status: " + option.getText());
            if (option.getText().equals("Active")) {  // Change "Active" to your desired status if needed
                selectedStatusForCustomAssessmentSummary = option.getText();  // Store the selected status in the global variable
                System.out.println("Selected assignment status: " + selectedStatusForCustomAssessmentSummary);
                TestRunner.getTest().log(Status.INFO, "Selected assignment status: " + selectedStatusForCustomAssessmentSummary);
                option.click();
                break;
            }
        }
    }

    public void IsAssessmentStatusRetainedOnSummary() throws InterruptedException{

        TestRunner.getTest().log(Status.INFO, "I'm into Validate Assessment Status is Retained or Not");
        System.out.println("I'm into Validate Assessment Status is Retained or Not");


        WebElement selectedValueForCourse = driver.findElement(By.xpath("(//div[contains(@aria-haspopup,'listbox')])[2]"));

        String currentSelectedStatus = selectedValueForCourse.getText();
        System.out.println("Retrieved Status is: " + currentSelectedStatus);
        TestRunner.getTest().log(Status.INFO, "Retrieved Status is: " + currentSelectedStatus);

        if (selectedStatusForCustomAssessmentSummary.equals(currentSelectedStatus)) {
            System.out.println("Test Case Passed: Correct Status is Retained: " + selectedStatusForCustomAssessmentSummary);
            TestRunner.getTest().log(Status.INFO, " Correct Status is Retained: " + selectedStatusForCustomAssessmentSummary);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed:  Correct Status is Retained: " + selectedStatusForCustomAssessmentSummary);
        } else {
            System.out.println("Test Case Failed: Incorrect  Status. Expected: " + selectedStatusForCustomAssessmentSummary + ", but found: " + currentSelectedStatus);
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Incorrect  Status. Expected: " + selectedStatusForCustomAssessmentSummary + ", but found: " + currentSelectedStatus);
            throw new RuntimeException("Incorrect  Status ");
        }

    }

    public void ClickStepIVFinalizeQuestions() throws InterruptedException{

        TestRunner.getTest().log(Status.INFO, "I'm into click on Step IV Select New Question from Nav bar");
        System.out.println("I'm into click on Step IV Select New Question from Nav bar");

        WebElement StepIIISelectNewQuestions= driver.findElement(By.xpath("//div[contains(@class,'MuiStep-root MuiStep-horizontal')][4]"));

        if (StepIIISelectNewQuestions.isDisplayed()){
            helper.scrollToElement(driver, StepIIISelectNewQuestions);
            StepIIISelectNewQuestions.click();
            System.out.println("StepIV Finalize Questions click successfully fom Nav Bar");
            TestRunner.getTest().log(Status.INFO, "Step IV Finalize Questions click successfully fom Nav Bar");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Step IV Finalize Questions click successfully fom Nav Bar");
        }else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Step IV Finalize Questions not Visible in Nav Bar");
            throw new RuntimeException("Step IV Finalize Questions not Visible in Nav Bar");
        }
    }

    public void NewAssessmentSummarySaveBtn() throws InterruptedException{

        Thread.sleep(2000);
        wait.until(ExpectedConditions.elementToBeClickable(btn_Save));
        btn_Save.click();
        TestRunner.getTest().log(Status.PASS, "Test Case Passed : Click on Save New Assessment button successfully");
    }

}
