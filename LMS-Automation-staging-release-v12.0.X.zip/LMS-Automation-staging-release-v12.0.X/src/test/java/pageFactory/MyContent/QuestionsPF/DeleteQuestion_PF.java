package pageFactory.MyContent.QuestionsPF;

import StepDefinitions.Configurations;
import StepDefinitions.MyContentModule.QuestionsSteps.DeleteQuestionsSteps;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

public class DeleteQuestion_PF {
    public WebDriverWait wait;
    WebDriver driver;

    Actions actions;

    @FindBy(xpath = "//ul[@role='menu']")
    WebElement btnMenu;

    @FindBy(xpath = "//div[@aria-labelledby='customized-dialog-title']")
    WebElement customizedDialogTitle;

    public DeleteQuestion_PF(WebDriver driver) {
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
        actions = new Actions(driver);
    }



    public void clickQuestionMenuButton() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm in Click Question Menu Button");
        Thread.sleep(500);

        WebElement menuDots= driver.findElement(By.xpath("//button[@aria-label='DropDownButtom']"));
        menuDots.click();

        WebElement menuOptions = wait.until(ExpectedConditions.elementToBeClickable(btnMenu));
        List<WebElement> optionsQuestions = menuOptions.findElements(By.xpath(".//li"));

        for (WebElement option : optionsQuestions) {
            if (option.getText().equalsIgnoreCase("Delete")) {
                if(option.isEnabled() && wait.until(ExpectedConditions.elementToBeClickable(option)) != null) {
                    option.click();
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  Delete button click successfully");
                } else {
                    TestRunner.getTest().log(Status.FAIL, "Test Case Failed  : The " + option.getText() + " option is either not enabled or not clickable.");
                    throw new RuntimeException("Delete Option is either not enabled or not clickable");
                }
                break;
            }
        }
    }

    public void DeleteQuestionPrompt() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Delete Question Prompt");
        Thread.sleep(500);

        WebElement promptDelete = wait.until(ExpectedConditions.elementToBeClickable(customizedDialogTitle));

        if(promptDelete.isDisplayed() && promptDelete.isEnabled()){
            WebElement deletePromptText = promptDelete.findElement(By.xpath(".//div[contains(@class, 'deleteCard')]"));
            System.out.println("Deleted question is: " + deletePromptText.getText());

            WebElement btnDeleteYes = promptDelete.findElement(By.xpath(".//button[normalize-space()='Yes']"));

            if(btnDeleteYes.isEnabled()){
                btnDeleteYes.click();
                TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  Question deleted successfully");
            }
        }
        actions.sendKeys(Keys.ESCAPE).build().perform();
    }

    public void showsQuestionsIntoTable() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Verify Delete Shows Question Into table");
        Thread.sleep(2000);
        try {
            WebElement questionsTableContainer = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class, 'QuestionDashboardContainer')]")));

            if (questionsTableContainer != null) {
                WebElement divQuestion = questionsTableContainer.findElement(By.xpath("(.//div[contains(@class, 'textstyling')])[2]"));
                String expectedSearchedQuestionNotFount = divQuestion.getText();
                System.out.println(expectedSearchedQuestionNotFount);

                if (expectedSearchedQuestionNotFount.equalsIgnoreCase("No Detail Found")) {
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  Deleted question not found successfully");
                }

            }
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: An unexpected error occurred. " + e.getMessage());

        }
    }
}
