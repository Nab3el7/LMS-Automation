package pageFactory.MyContent.QuestionsPF;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

public class EditQuestion_PF {
    public WebDriverWait wait;
    WebDriver driver;
    Helper helper;
    Actions actions;

    static String UpdatedQuestionPointsValue = "73";
    String updatedQuestionPoints;
    static String UpdatedQuestionStatus = "Active";

    @FindBy(xpath = "//ul[@role='menu']")
    WebElement editMenu;

    @FindBy(xpath = "//input[@name='points']")
    WebElement editPoints;

    @FindBy(xpath = "//label[normalize-space(text())='Status']/following-sibling::div//div[@role='button' or @role='combobox']")
    WebElement editStatusDropdown;

    @FindBy(xpath = "//div[@class='controls-container']//button[@id='btn-saveNext']")
    WebElement btnSaveEditQuestion;

    public EditQuestion_PF(WebDriver driver) {
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
        actions = new Actions(driver);
        helper = new Helper();
    }


    public void clickQuestionEditButton() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm in Click Question Edit Button");
        Thread.sleep(500);

        WebElement editDots= driver.findElement(By.xpath("//button[@aria-label='DropDownButtom']"));
        editDots.click();

        WebElement menuOptions = wait.until(ExpectedConditions.elementToBeClickable(editMenu));
        List<WebElement> optionsQuestions = menuOptions.findElements(By.xpath(".//li"));

        for (WebElement option : optionsQuestions) {
            if (option.getText().equalsIgnoreCase("Edit")) {
                if(option.isEnabled() && wait.until(ExpectedConditions.elementToBeClickable(option)) != null) {
                    option.click();
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  Edit button click successfully");

                } else {
                    TestRunner.getTest().log(Status.FAIL, "Test Case Failed  : The 'Edit' option is either not enabled or not clickable.");

                }
                break;
            }
        }

    }

    public void editQuestionInfo() throws InterruptedException{
        TestRunner.startTest("I'm in Edit question Information");
        Thread.sleep(2000);
        System.out.println("I'm in edit question Information Screen");
        TestRunner.getTest().log(Status.INFO, "I'm in edit question Information Screen");
        updateQuestionPoints();
        updateQuestionStatus();
    }

    private void updateQuestionPoints(){
        System.out.println("I'm in edit question points");
        TestRunner.getTest().log(Status.INFO, "I'm in edit question points");

        wait.until(ExpectedConditions.elementToBeClickable(editPoints));

        String existingQuestionPoints = editPoints.getAttribute("value");
        System.out.println("Existing Question Points: " + existingQuestionPoints);
        TestRunner.getTest().log(Status.INFO, "Existing Question Points Value is: " + existingQuestionPoints);

        editPoints.click();

        for (int i = 0; i < existingQuestionPoints.length(); i++) {
            actions.sendKeys(Keys.BACK_SPACE).perform();
        }

        ((JavascriptExecutor) driver).executeScript("arguments[0].value='';", editPoints);

        editPoints.sendKeys(UpdatedQuestionPointsValue);

        updatedQuestionPoints = editPoints.getAttribute("value");
        System.out.println("Updated Question Points: " + updatedQuestionPoints);
        TestRunner.getTest().log(Status.INFO, "Updated Question Points Value is: " + UpdatedQuestionPointsValue);
        TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  Edit question points successfully");
    }

    private void updateQuestionStatus() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm in Updating Question Status");
        Thread.sleep(2000);
        System.out.println("I'm in edit question status");

        wait.until(ExpectedConditions.elementToBeClickable(editStatusDropdown));

//        String existingQuestionStatus = editStatusDropdown.getAttribute("value");
//        System.out.println("Existing Question Status: " + existingQuestionStatus);
//        TestRunner.getTest().log(Status.INFO, "Existing Question Status: " + existingQuestionStatus);

        String existingQuestionStatus = editStatusDropdown.getText();
        System.out.println("Existing Question Status: " + existingQuestionStatus);
        TestRunner.getTest().log(Status.INFO, "Existing Question Status: " + existingQuestionStatus);


        editStatusDropdown.click();

        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//ul[@role='listbox']")));
        List<WebElement> editQuestionStatusOptions = driver.findElements(By.xpath("//ul[@role='listbox']//li"));

        System.out.println("Available Question Status Options:");
        for (WebElement option : editQuestionStatusOptions) {
            System.out.println(option.getText());
            TestRunner.getTest().log(Status.INFO, " Available Question Status Options:" + option.getText());

        }

        for (WebElement option : editQuestionStatusOptions) {
            if (option.getText().equalsIgnoreCase(UpdatedQuestionStatus)) {
                System.out.println("Selected " + option.getText() + " status");
                TestRunner.getTest().log(Status.INFO, "New Selected " + option.getText() + " status");
                option.click();
                TestRunner.getTest().log(Status.PASS, "Test Case Passed   :   Edit question status successfully");
                break;
            }
        }

    }
//
//    public void clickOnEditQuestionSaveButton(){
//        TestRunner.getTest().log(Status.INFO, "Click on Edit question save button");
//        wait.until(ExpectedConditions.elementToBeClickable(btnSaveEditQuestion));
//        helper.scrollToElement(driver,btnSaveEditQuestion);
//        btnSaveEditQuestion.click();
//        TestRunner.getTest().log(Status.PASS, "Test Case Passed   :   Edit question saved successfully");
//    }
public void clickOnEditQuestionSaveButton() {
    TestRunner.getTest().log(Status.INFO, "Click on Edit question save button");

    // Wait for the overlay or backdrop to disappear if it exists
    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    wait.until(ExpectedConditions.invisibilityOfElementLocated(By.className("MuiBackdrop-root")));

    // Scroll to the button to ensure it’s in view
    helper.scrollToElement(driver, btnSaveEditQuestion);

    try {
        // Attempt to click the button
        wait.until(ExpectedConditions.elementToBeClickable(btnSaveEditQuestion));
        btnSaveEditQuestion.click();
    } catch (ElementClickInterceptedException e) {
        // If an intercept occurs, attempt to click using JavaScript
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", btnSaveEditQuestion);
    }

    TestRunner.getTest().log(Status.PASS, "Test Case Passed: Edit question saved successfully");
}


    public void verifyUpdatedQuestionInfo() {
        TestRunner.getTest().log(Status.INFO, "Verify updated Question information");
        List<WebElement> rowsQuestions = driver.findElements(By.xpath("//table[contains(@class,'MuiTable-root')]//tbody//tr"));

        boolean statusFound = false;
        for (WebElement rowQuestion : rowsQuestions) {
            String updatedQuestionStatusText = rowQuestion.findElement(By.xpath(".//td[contains(@class,'cell-5')]//div")).getText().trim();

            if (updatedQuestionStatusText.equals(UpdatedQuestionStatus)) {
                statusFound = true;
                break;
            }
        }

        if (statusFound) {
            System.out.println("The question status has been updated to: " + UpdatedQuestionStatus);
            TestRunner.getTest().log(Status.INFO, "The question status has been updated to: " + UpdatedQuestionStatus);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed   : Edited Information successfully");
        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : The question status has not been updated or not found.\"");
        }
    }

}
