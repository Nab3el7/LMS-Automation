package pageFactory.MyContent.QuestionsPF;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.w3c.dom.html.HTMLInputElement;
import org.openqa.selenium.ElementNotInteractableException;

import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

//import static StepDefinitions.Configurations.driver;
import static pageFactory.MyContent.QuestionsPF.FilterQuestion_PF.questionName;

public class CreateQuestion_PF {

        public WebDriverWait wait;
        WebDriver driver;
        Helper helper;
            CustomQuestionsTypes_PF customQuestionsTypesPF;
        Actions actions;

        public static String questionTitle;
        public static String points = "40";
        public static String selectedCourse;
        public static String selectedQuestionType = "Drawing";

        public static List<String> selectedStandards = new ArrayList<>();

        @FindBy(xpath = "//div[@role='group']//button[.//span[text()='Questions']]")
        WebElement tabQuestion;

        @FindBy(xpath = "//div[contains(@class, 'MuiAccordionSummary-content')][text()='Standards']")
        WebElement standardsElement;

        @FindBy(xpath = "//div[contains(@class, 'MuiAccordionSummary-content')][text()='Questions']")
        WebElement questionsElement;

        @FindBy(xpath = "//div[@aria-labelledby='Questions-header']")
        WebElement questionsContentContainer;

        @FindBy(xpath = "//div[contains(@class, 'tabelbodydata')]")
        WebElement tableQuestionsContainer;

        @FindBy(xpath = "//button[normalize-space()='Add New']")
        WebElement addNewQuestionButton;

        @FindBy(xpath = "//div[contains(@class, 'QuestionAuthoring')]")
        WebElement authoringQuestionsContainer;

        @FindBy(xpath = "//div[contains(@class, 'header-container')]")
        WebElement newQuestionHeaderContainer;

        @FindBy(xpath = "//div[contains(@class, 'navigation-container')]")
        WebElement newQuestionNavigationContainer;

        @FindBy(xpath = "//div[contains(@class, 'screens-container')]")
        WebElement newQuestionScreensContainer;

        @FindBy(xpath = "//input[@name='questionTitle']")
        WebElement questionTitleInput;

        @FindBy(xpath = "//input[@name='points']")
        WebElement pointsInput;

        @FindBy(xpath = "//label[normalize-space(text())='Status']/following-sibling::div//div[@role='button' or @role='combobox']")
        WebElement statusDropdown;

        @FindBy(xpath = "//label[normalize-space(text())='Select Course']/following-sibling::div//button[@aria-label='Open']")
        WebElement courseDropdown;

        @FindBy(xpath = "//label[.//span[contains(text(), 'Display Student Hint')]]//input[@type='checkbox']")
        WebElement displayHint;

        @FindBy(xpath = "(//button[normalize-space()='Next'])[1]")
        WebElement newQuestionNextButton;

        @FindBy(xpath = "//label[normalize-space(text())='Question Type']/following-sibling::div//div[@role='button' or @role='combobox']")
        WebElement newQuestionTypeDropdown;

        @FindBy(xpath = "//div[.//label[normalize-space(text())='Number of Choices']]//input[@name='numofChoices']")
        WebElement multipleChoiceTypeDropdown;

        @FindBy(xpath = "//div[contains(@class, 'questionType')]")
        WebElement questionAnswersContainer;

        @FindBy(xpath = "//button[normalize-space()='Add Standard']")
        WebElement btnAddStandard;

        @FindBy(xpath = "//div[@aria-labelledby='customized-dialog-title']")
        WebElement customizedDialogTitle;

        @FindBy(xpath = "//div[contains(@class, 'react-checkbox-tree')]//input[@type='checkbox']/parent::label")
        WebElement checkboxStandardAndUnits;

        @FindBy(xpath = "//button[@type='button'][normalize-space()='Save']")
        WebElement btnSaveStandardAndUnits;

        @FindBy(xpath = "//button[normalize-space()='Add Unit and Chapter']")
        WebElement btnAddUnitAndChapter;

        @FindBy(xpath = "//input[@placeholder='Enter in desired topic/keyword']")
        WebElement topicsKeywordInput;

        @FindBy(xpath = "//button[@id='btn-publish']")
        WebElement btnSaveNewQuestion;


        @FindBy(xpath = "//div[@class='rrt-middle-container']")
        WebElement toastContainer;
        @FindBy(xpath = "//button[normalize-space()='View All']")
        WebElement btnViewAll;

    public static String messageTitle;
    public static String messageText;




        public CreateQuestion_PF (WebDriver driver) {
//        this.driver = driver;
            this.driver = Configurations.getDriver();
            PageFactory.initElements(driver, this);
            wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        customQuestionsTypesPF = new CustomQuestionsTypes_PF(driver);
            actions = new Actions(driver);
            helper = new Helper();
        }


        public void clickOnQuestionTab() {
            System.out.println("I'm in to click on the question tab");
            TestRunner.getTest().log(Status.INFO, "I'm in to click on the question tab");

            wait.until(ExpectedConditions.elementToBeClickable(tabQuestion));
            tabQuestion.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  Question tab button click successfully");


            System.out.println("Waiting for question dashboard visible...");
            wait.until(ExpectedConditions.visibilityOf(standardsElement));
            wait.until(ExpectedConditions.visibilityOf(questionsElement));
            wait.until(ExpectedConditions.visibilityOf(questionsContentContainer));
            wait.until(ExpectedConditions.visibilityOf(tableQuestionsContainer));

            System.out.println("Question dashboard are visible, actions can be performed.");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  Question dashboard are visible, actions can be performed");

        }

        public void clickOnAddQuestionButton() {
            TestRunner.getTest().log(Status.INFO, "I'm in to click on the add question button");
            System.out.println("I'm in to click on the add question button");

            wait.until(ExpectedConditions.elementToBeClickable(addNewQuestionButton));
            addNewQuestionButton.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  Add New Question button click successfully");

            System.out.println("Waiting for new question dashboard visible...");

            wait.until(ExpectedConditions.visibilityOf(authoringQuestionsContainer));
            wait.until(ExpectedConditions.visibilityOf(newQuestionHeaderContainer));
            wait.until(ExpectedConditions.visibilityOf(newQuestionNavigationContainer));
            wait.until(ExpectedConditions.visibilityOf(newQuestionScreensContainer));

            System.out.println("New Question dashboard are visible, actions can be performed.");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  New Question dashboard are visible, actions can be performed");
        }

//    Step I Title, Points/Weight, Status, Course and Hint

        public void EnterQuestionTitle() {
            TestRunner.getTest().log(Status.INFO, "I'm Enter Question Title");
            questionTitleInput.click();
            ((JavascriptExecutor) driver).executeScript("arguments[0].value='';", questionTitleInput);
            questionTitle = helper.generateRandomText("Automated Question ");
            System.out.println("Question title is: " + questionTitle);
            questionTitleInput.sendKeys(questionTitle);
            TestRunner.getTest().log(Status.INFO, "new Question Title is:" + questionTitle);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed   : New question title enter successfully");

        }

        public String getQuestionTitle() {
            return questionTitle;
        }

        public void EnterQuestionPoints() {
            TestRunner.getTest().log(Status.INFO, "I'm Enter Question Points");
            pointsInput.click();
            ((JavascriptExecutor) driver).executeScript("arguments[0].value='';", pointsInput);
            pointsInput.sendKeys(points);
            TestRunner.getTest().log(Status.INFO, "new Question Points are:" + points);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed   : New question points enter successfully");
        }


        // public void SelectQuestionStatus() {

        public void SelectQuestionStatus() throws InterruptedException {
            TestRunner.getTest().log(Status.INFO, "I'm Select New Question Status");
            wait.until(ExpectedConditions.elementToBeClickable(statusDropdown));
            statusDropdown.click();
            Thread.sleep(3000);

            wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//ul[@role='listbox']//li")));
            List<WebElement> QuestionStatusOptions = driver.findElements(By.xpath("//ul[@role='listbox']//li"));

            System.out.println("Available Question Status Options:");
            for (WebElement option : QuestionStatusOptions) {
                System.out.println(option.getText());
            }

            for (WebElement option : QuestionStatusOptions) {
                if (option.getText().equalsIgnoreCase("Editing")) {
                    option.click();
                    System.out.println("Selected " + option.getText() + " status");
                    break;
                }
            }
            TestRunner.getTest().log(Status.PASS, "Test Case Passed   : New question status selected successfully");
        }

        public void SelectQuestionCourse() throws InterruptedException {
            TestRunner.getTest().log(Status.INFO, "I'm Select New Question Courses");
            wait.until(ExpectedConditions.elementToBeClickable(courseDropdown));
            Thread.sleep(3000);
            courseDropdown.click();

            wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//ul[@role='listbox']//li")));
            List<WebElement> QuestionCourseOptions = driver.findElements(By.xpath("//ul[@role='listbox']//li"));
            System.out.println("Total courses: " + QuestionCourseOptions.size());

            selectedCourse = helper.selectValueFromDropdown(QuestionCourseOptions);
            System.out.println("Selected Course Name: " + selectedCourse);
            TestRunner.getTest().log(Status.INFO, "Selected Course Name: " + selectedCourse);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed   : New question course selected successfully");
        }

        public String getSelectedCourse() {
            return selectedCourse;
        }

        public void SelectQuestionStudentHint() {
            TestRunner.getTest().log(Status.INFO, "I'm in Select Question Student Hint");
            if (displayHint.isEnabled() && !displayHint.isSelected()) {
                displayHint.click();
                TestRunner.getTest().log(Status.PASS, "Test Case Passed   : New question checkbox student hint selected successfully");
            } else {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  New question checkbox student hint not found ");
                throw new RuntimeException("No Check Box Found.");

            }
        }

        public void EnterQuestionHint() {
            TestRunner.getTest().log(Status.INFO, "I'm in Enter Question Hint");
            WebElement RichTextBoxBody = driver.findElement(By.xpath("//div[@class='tox-edit-area']/iframe"));

            driver.switchTo().frame(RichTextBoxBody);

            WebElement editStudentHintTextBox = driver.findElement(By.xpath("//body[@id='tinymce']//p"));
            System.out.println("Edit text area is found");

            editStudentHintTextBox.clear();

            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript("arguments[0].value='';", editStudentHintTextBox);

            String randomStudentHintText = helper.generateRandomText("Student Hint ");
            System.out.println(randomStudentHintText);

            editStudentHintTextBox.sendKeys(randomStudentHintText);
            TestRunner.getTest().log(Status.INFO, "Student Hint Text is: " + randomStudentHintText);

            driver.switchTo().defaultContent();

            TestRunner.getTest().log(Status.PASS, "Test Case Passed   : New question display student hint selected successfully");

        }

        public void clickOnNewQuestionNextButton() {
            TestRunner.getTest().log(Status.INFO, "I'm in Click on New Question Next Button");
            wait.until(ExpectedConditions.elementToBeClickable(newQuestionNextButton));
            newQuestionNextButton.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed   : New question next button successfully");

        }
    public void clickOnNewQuestionViewAllButton() {
        TestRunner.getTest().log(Status.INFO, "I'm in Click on New Question ViewAll Button");
        wait.until(ExpectedConditions.elementToBeClickable(btnViewAll));
        btnViewAll.click();
        TestRunner.getTest().log(Status.PASS, "Test Case Passed   : New question next button successfully");

    }

//    Step II Select Question type and Correct answer

        public void SelectNewCustomQuestionType() throws InterruptedException {
            TestRunner.getTest().log(Status.INFO, "I'm in Select New Custom Question Type ");
            Thread.sleep(2000);
            try {
                newQuestionTypeDropdown.click();
                Thread.sleep(1000);
                wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//ul[@role='listbox']")));
                List<WebElement> questionTypeOptions = driver.findElements(By.xpath("//ul[@role='listbox']//li"));
                System.out.println("Total types: " + questionTypeOptions.size());
                TestRunner.getTest().log(Status.INFO, "Total types: " + questionTypeOptions.size());

                selectedQuestionType = helper.selectValueFromDropdown(questionTypeOptions);
                System.out.println("Selected Question Name: " + selectedQuestionType);
                TestRunner.getTest().log(Status.INFO, "Selected Question Name: " + selectedQuestionType);

                switch (selectedQuestionType.toLowerCase()) {
                    case "multiple choice" -> customQuestionsTypesPF.EnterNewQuestionTypeMultipleChoiceQuestion();
                    case "multiple select" -> customQuestionsTypesPF.EnterNewQuestionTypeMultipleSelectQuestion();
                    case "sequencing" -> customQuestionsTypesPF.EnterNewQuestionTypeSequenceQuestion();
                    case "open response" -> customQuestionsTypesPF.EnterNewQuestionTypeOpenResponseQuestion();
                    case "spelling" -> customQuestionsTypesPF.EnterNewQuestionTypeSpellingQuestion();
                    case "drawing" -> customQuestionsTypesPF.EnterNewQuestionTypeDrawingQuestion();
                    default -> System.out.println("No option selected");
                }

                actions.sendKeys(Keys.ESCAPE).build().perform();

                System.out.println("Selected Type Name: " + selectedQuestionType);
                TestRunner.getTest().log(Status.INFO, "Selected Type Name: " + selectedQuestionType);
                TestRunner.getTest().log(Status.PASS, "Test Case Passed   : New question type " + selectedQuestionType + " selected successfully");
            } catch (NoSuchElementException | ElementNotInteractableException e) {
                System.out.println(e.getMessage());
            }
        }


        public void SelectNewQuestionTypeMultipleChoice() throws InterruptedException {
            TestRunner.getTest().log(Status.INFO, "I'm in Select New Custom Question Type Multiple Choice ");
            newQuestionTypeDropdown.click();
            Thread.sleep(2000);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//ul[@role='listbox']")));
            List<WebElement> QuestionTypeOptions = driver.findElements(By.xpath("//ul[@role='listbox']//li"));
            System.out.println("Total types: " + QuestionTypeOptions.size());

            for (WebElement option : QuestionTypeOptions) {
                System.out.println("Types: " + option.getText());

                if (option.getText().equals("Multiple Choice")) {
                    option.click();
                    selectedQuestionType = option.getText();

                    TestRunner.getTest().log(Status.PASS, "Test Case Passed   : New question type multiple choice selected successfully");
                    break;
                }
            }
            actions.sendKeys(Keys.ESCAPE).build().perform();

            System.out.println("Selected Type Name: " + selectedQuestionType);
            TestRunner.getTest().log(Status.INFO, "Selected Type Name: " + selectedQuestionType);
        }

        public String getSelectedQuestionType() {
            return selectedQuestionType;
        }

//    Step III Add Standard, Add Units&Chapters and Topics Keyword

        public void StandardSelection() throws InterruptedException {
            TestRunner.getTest().log(Status.INFO, "I'm in Select Standard Selection ");

            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[normalize-space()='Add Standard']")));

            // Wait for any toast/dialog overlays to disappear before clicking
            try {
                wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[contains(@class,'rrt-') or contains(@id,'dialogDesc-')]")));
            } catch (TimeoutException e) {
                TestRunner.getTest().log(Status.INFO, "Toast/dialog still visible, proceeding with cautious click.");
            }

            helper.scrollToElement(driver, btnAddStandard);

            if (btnAddStandard.isDisplayed() && btnAddStandard.isEnabled()) {
                try {
                    btnAddStandard.click();
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed   : Add Standards button clicked Successfully");
                } catch (ElementClickInterceptedException e) {
                    TestRunner.getTest().log(Status.WARNING, "Add Standard click intercepted, retrying with JavaScript: " + e.getMessage());
                    ((JavascriptExecutor) driver).executeScript("arguments[0].click();", btnAddStandard);
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed   : Add Standards button clicked via JavaScript");
                }
            } else {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed    : Add Standard Button is not Displayed/Enabled");
                throw new RuntimeException("Add Standard Button is not Displayed/Enabled");
            }

            TestRunner.getTest().log(Status.INFO, "I'm in Select Standard Selection Dialogue Box ");
            WebElement dialogBoxAddStandards = wait.until(ExpectedConditions.visibilityOf(customizedDialogTitle));
            System.out.println("Selecting Standard(s)");
            WebElement dropdownStandards = dialogBoxAddStandards.findElement(By.xpath("(.//div[contains(@class, 'MuiSelect-select') and @role='button' or @role='combobox'])[2]"));
            System.out.println("Currently selected standard: " + dropdownStandards.getText());

            WebElement listStandardAndUnits = null;
            boolean isElementFound = false;

            while (!isElementFound) {
                try {
                    listStandardAndUnits = wait.until(ExpectedConditions.visibilityOf(checkboxStandardAndUnits));
                    if (listStandardAndUnits.isDisplayed()) {
                        isElementFound = true;
                        System.out.println("checkbox Standard is displayed.");
                        TestRunner.getTest().log(Status.INFO, "checkbox Standard is displayed. ");
                    }
                } catch (TimeoutException e) {
                    System.out.println("checkbox Standard is not displayed, selecting a new standard.");
                    TestRunner.getTest().log(Status.INFO, "checkbox Standard is not displayed, selecting a new standard ");

                    dropdownStandards.click();
                    WebElement listStandard = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[@role='listbox']")));
                    List<WebElement> optionsStandards = listStandard.findElements(By.xpath(".//li"));

                    System.out.println("Courses list in standard dropdown: " + optionsStandards.size());

                    String selectedStandard = helper.selectValueFromDropdown(optionsStandards);
                    System.out.println("Selected standard: " + selectedStandard);
                    TestRunner.getTest().log(Status.INFO, "Selected standard: " + selectedStandard);
                }
            }

            System.out.println("Selecting the course...");
            TestRunner.getTest().log(Status.INFO, "I'm in Select Selecting the course");
            Thread.sleep(1000);

            WebElement checkboxContainer = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class, 'scrollbarWrapper')]")));
            List<WebElement> checkboxesStandards = checkboxContainer.findElements(By.xpath(".//span[@role='checkbox']"));

            int numOfCheckboxesToSelect = Math.min(3, checkboxesStandards.size());

            for (int i = 1; i <= numOfCheckboxesToSelect; i++) {
                WebElement checkbox = checkboxesStandards.get(i);
                if (!checkbox.isSelected()) {
                    checkbox.click();
                    System.out.println("Checkbox " + i + " selected.");
                    TestRunner.getTest().log(Status.INFO, "Checkbox " + i + " selected.");
                }
            }
            Thread.sleep(1000);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed   : New question Standard Selected successfully");
        }

        public void SaveStandardAndUnits() {
            TestRunner.getTest().log(Status.INFO, "I'm in Save Standards and Units");
            if (btnSaveStandardAndUnits.isEnabled() && btnSaveStandardAndUnits.isDisplayed()) {
                btnSaveStandardAndUnits.click();
                TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  New question save standard and units button successfully");
            } else {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed  : Save button is not Displayed/Enabled");
                throw new RuntimeException("Save button is not Displayed/Enabled");
            }
        }


        public void clickSaveAndValidateStandardSave() throws InterruptedException {
            TestRunner.getTest().log(Status.INFO, "I'm into click Save And Validate Standard Save");

            WebElement saveStepIII= driver.findElement(By.xpath("//button[@id='btn-saveNext']"));
            if (saveStepIII.isDisplayed()){
                saveStepIII.click();
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: Save button on Step III clicked successfully");
                verifySuccessMessage();
                verifyStandardSaveAfterSave();
            }
        }

        public void verifyStandardSaveAfterSave() throws InterruptedException {
            TestRunner.getTest().log(Status.INFO, "I'm into Verify that after save standards are still display");

            List<WebElement> standardChips = driver.findElements(
                    By.xpath("//label[normalize-space(text())='Standard(s)']/following::div[contains(@class,'MuiAutocomplete-inputRoot')][1]//div[contains(@class,'MuiAutocomplete-tag')]")
            );

            if (standardChips.isEmpty()) {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Standards are not saved after Save Button is clicked");
            } else {
                System.out.println("✅ Standards count: " + standardChips.size());
                for (WebElement chip : standardChips) {
                    System.out.println("Selected: " + chip.getText());
                    TestRunner.getTest().log(Status.INFO, "Selected: " + chip.getText());  // ✅ Fixed
                }
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: Standards are still saved after Save Button is clicked");
            }
        }

        public void UnitsAndChapterSelection() throws InterruptedException {
            TestRunner.getTest().log(Status.INFO, "I'm in Click Units and chapters button");
            wait.until(ExpectedConditions.elementToBeClickable(btnAddUnitAndChapter));
            if (btnAddUnitAndChapter.isDisplayed() && btnAddUnitAndChapter.isEnabled()) {
                btnAddUnitAndChapter.click();
                TestRunner.getTest().log(Status.PASS, "Test Case Passed   : Add Units and Chapters button clicked Successfully");
            } else {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed  : Add units and Chapters Button is not Displayed/Enabled");
                throw new RuntimeException("Add units and Chapters Button is not Displayed/Enabled");

            }
            TestRunner.getTest().log(Status.INFO, "I'm in Select Units and Chapters Selection Dialogue Box ");
            WebElement dialogBoxAddStandards = wait.until(ExpectedConditions.visibilityOf(customizedDialogTitle));
            System.out.println("Selecting Units and Chapter(s)");
            WebElement dropdownUnits = dialogBoxAddStandards.findElement(By.xpath("(.//div[contains(@class, 'MuiSelect-select') and @role='button' or @role='combobox'])[1]"));
            System.out.println("Currently selected unit: " + dropdownUnits.getText());

            WebElement listStandardAndUnits = null;
            boolean isElementFound = false;

            while (!isElementFound) {
                try {
                    listStandardAndUnits = wait.until(ExpectedConditions.visibilityOf(checkboxStandardAndUnits));
                    if (listStandardAndUnits.isDisplayed()) {
                        isElementFound = true;
                        System.out.println("checkbox Units is displayed.");
                        TestRunner.getTest().log(Status.INFO, "checkbox Units is displayed. ");
                    }
                } catch (TimeoutException e) {
                    System.out.println("checkbox Units is not displayed, selecting a new standard.");
                    TestRunner.getTest().log(Status.INFO, "checkbox Units is not displayed, selecting a new standard. ");

                    dropdownUnits.click();
                    WebElement listStandard = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[@role='listbox']")));
                    List<WebElement> optionsStandards = listStandard.findElements(By.xpath(".//li"));

                    System.out.println("Courses list in standard dropdown: " + optionsStandards.size());

                    String selectedStandard = helper.selectValueFromDropdown(optionsStandards);
                    System.out.println("Selected standard: " + selectedStandard);
                    TestRunner.getTest().log(Status.INFO, "Selected standard: " + selectedStandard);
                }
            }

            TestRunner.getTest().log(Status.INFO, "I'm in Select Selecting the course");
            System.out.println("Selecting the course...");
            Thread.sleep(1000);

            WebElement checkboxContainer = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class, 'scrollbarWrapper')]")));
            List<WebElement> checkboxesStandards = checkboxContainer.findElements(By.xpath(".//span[@role='checkbox']"));

            int numOfCheckboxesToSelect = Math.min(3, checkboxesStandards.size());

            for (int i = 1; i <= numOfCheckboxesToSelect; i++) {
                WebElement checkbox = checkboxesStandards.get(i);
                if (!checkbox.isSelected()) {
                    checkbox.click();
                    System.out.println("Checkbox " + i + " selected.");
                    TestRunner.getTest().log(Status.INFO, "Checkbox " + i + " selected.");
                }
            }
            Thread.sleep(1000);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed   : New question units Selected successfully");
        }

        public void AddTopicsKeywords() {
            TestRunner.getTest().log(Status.INFO, "I'm in Add Topics KeyWords");
            if (topicsKeywordInput.isDisplayed() && topicsKeywordInput.isEnabled()) {
                topicsKeywordInput.click();

                JavascriptExecutor js = (JavascriptExecutor) driver;
                js.executeScript("arguments[0].click();", topicsKeywordInput);

                System.out.println("Topic keyword");
                topicsKeywordInput.sendKeys("Automation keyword");

                actions.sendKeys(Keys.ENTER).build().perform();
                TestRunner.getTest().log(Status.PASS, "Test Case Passed   : New question topics keyword enter successfully");

            } else {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Add topics keywords input is not Displayed/Enabled");
                throw new RuntimeException("Keyword is not set");

            }
        }

        public void clickOnNewQuestionSaveButton() {
            wait.until(ExpectedConditions.elementToBeClickable(btnSaveNewQuestion));
            btnSaveNewQuestion.click();
            System.out.println("New question save button clicked");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  New question saved successfully");
        }

    public void verifySuccessMessage() {
        wait.pollingEvery(Duration.ofMillis(20));

        try {
            WebElement toastContainer = wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("toastr")));

            try {
                if (toastContainer.isDisplayed()) {
                    toastContainer = driver.findElement(By.className("toastr"));
                    String actualBackgroundColor = toastContainer.getCssValue("background-color");

                    String expectedBackgroundColor = "rgb(96, 187, 113)";
                    String expectedBackgroundColorWithAlpha = "rgba(96, 187, 113, 1)";

                    System.out.println("Captured Background Color: " + actualBackgroundColor);

                    if (actualBackgroundColor.equals(expectedBackgroundColor) || actualBackgroundColor.equals(expectedBackgroundColorWithAlpha)) {
                        System.out.println("Test case Passed: Background color is as expected (" + actualBackgroundColor + ").");

                        String messageTitle = toastContainer.findElement(By.className("rrt-title")).getText();
                        String messageText = toastContainer.findElement(By.className("rrt-text")).getText();

                        System.out.println("Message Title: " + messageTitle);
                        TestRunner.getTest().log(Status.INFO, "Success toast title is: " + messageTitle);
                        System.out.println("Message Text: " + messageText);
                        TestRunner.getTest().log(Status.INFO, "Success toast message is: " + messageText);

                        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Shows success message toast");

                    } else {
                        System.out.println("Test case Failed: Background color is not as expected. Actual: " + actualBackgroundColor);
                        TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Shows error toast with background color " + actualBackgroundColor);

                        String errorMessageTitle = toastContainer.findElement(By.className("rrt-title")).getText();
                        String errorMessageText = toastContainer.findElement(By.className("rrt-text")).getText();

                        System.out.println("Message Title: " + errorMessageTitle);
                        TestRunner.getTest().log(Status.INFO, "Error toast title is: " + errorMessageTitle);
                        System.out.println("Message Text: " + errorMessageText);
                        TestRunner.getTest().log(Status.INFO, "Error toast message is: " + errorMessageText);
                    }

                } else {
                    TestRunner.getTest().log(Status.FAIL, "Toast message is not displayed.");
                }
            } catch (StaleElementReferenceException staleEx) {
                TestRunner.getTest().log(Status.WARNING, "Toast element became stale. Retrying...");

                toastContainer = wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("toastr")));
                String retryBackgroundColor = toastContainer.getCssValue("background-color");

                System.out.println("Retried Background Color: " + retryBackgroundColor);
                TestRunner.getTest().log(Status.INFO, "Retried and captured background color: " + retryBackgroundColor);
            }

        } catch (TimeoutException e) {
            TestRunner.getTest().log(Status.FAIL, "Toast message did not appear in the expected time.");
        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "Unexpected error while verifying toast message: " + e.getMessage());
        }
    }

//    Negative scenarios

//    Missing Required Fields

        public void testMissingRequiredFields() {
            clickOnAddQuestionButton();

            clickOnNewQuestionNextButton();
            clickOnNewQuestionViewAllButton();

            // Verify error messages
            WebElement errorTitle = driver.findElement(By.xpath("//p[@id='textField-title-helper-text']"));
            Assert.assertTrue("Title required error not displayed", errorTitle.isDisplayed());

            WebElement errorPoints = driver.findElement(By.xpath("//p[@id='textField-points-helper-text']"));
            Assert.assertTrue("Points required error not displayed", errorPoints.isDisplayed());

            WebElement errorStatement = driver.findElement(By.xpath("//p[contains(text(), 'At least one course is required')]\n"));
            Assert.assertTrue("Question Statement required error not displayed", errorStatement.isDisplayed());
        }


//    Invalid Points/Weight Input

        public void testInvalidPointsInput() throws InterruptedException {
//            clickOnAddQuestionButton();
            EnterQuestionTitle();
            SelectQuestionCourse();
            SelectQuestionStatus();

            pointsInput.click();
            Thread.sleep(500);
            pointsInput.sendKeys("-");
            Thread.sleep(500); // Short delay to allow any JS validation (if needed)

            clickOnNewQuestionNextButton();
            clickOnNewQuestionViewAllButton();

            // Verify that the error message is displayed for points
//            WebElement errorPoints = driver.findElement(By.xpath("//p[@id='textField-points-helper-text']"));
//            Assert.assertTrue("Invalid points error not displayed", errorPoints.isDisplayed());
        }

//    Negative Points/Weight

        public void testNegativePointsInput() throws InterruptedException {
//            clickOnAddQuestionButton();

            EnterQuestionTitle();
            SelectQuestionCourse();
            SelectQuestionStatus();

            pointsInput.sendKeys("-10");

//            clickOnNewQuestionNextButton();
            clickOnNewQuestionViewAllButton();

            // Verify that the error message is displayed for points
//            WebElement errorPoints = driver.findElement(By.xpath("//p[@id='textField-points-helper-text']"));
//            Assert.assertTrue("Negative points error not displayed", errorPoints.isDisplayed());
        }

//    Invalid File Upload for Drawing Question Type

        public void testInvalidFileUploadForDrawingQuestion() throws InterruptedException {
//            clickOnAddQuestionButton();

            EnterQuestionTitle();
            SelectQuestionCourse();
            EnterQuestionPoints();
            SelectQuestionStatus();
            SelectQuestionCourse();
            SelectQuestionStudentHint();
            EnterQuestionHint();
            clickOnNewQuestionNextButton();
            SelectNewCustomQuestionType();
//            clickOnNewQuestionViewAllButton();
            clickOnNewQuestionNextButton();

            customQuestionsTypesPF.EnterNewQuestionTypeDrawingQuestionInvalid();

            WebElement fileUploadInput = driver.findElement(By.xpath("//input[@type='file']"));
            fileUploadInput.sendKeys("/path/to/invalid/file.txt");



            // Verify that an error message is displayed
//            WebElement fileErrorMessage = driver.findElement(By.xpath("//div[@class='file-upload-error']"));
//            Assert.assertTrue("Invalid file format error not displayed", fileErrorMessage.isDisplayed());
        }

        //    ********************************* Check Velidation ********************************************
        public void testMissingFieldsAndClickOnNextButton() throws InterruptedException {

            TestRunner.getTest().log(Status.INFO, "I'm into click on Next Button  with missing fields");
            System.out.println("I'm into click on Next Button  with missing fields");

            clickOnNewQuestionNextButton();

            WebElement errorPoints = driver.findElement(By.xpath("//p[@id='textField-points-helper-text']"));
            Assert.assertTrue("Points required error not displayed", errorPoints.isDisplayed());

            WebElement errorStatement = driver.findElement(By.xpath("//p[contains(text(), 'At least one course is required')]\n"));
            Assert.assertTrue("Question Statement required error not displayed", errorStatement.isDisplayed());
        }

        public void ClickStepIIIWithoutSelectingAnyQuestionType() throws InterruptedException {
            TestRunner.getTest().log(Status.INFO, "I'm clicking on Step III without selecting any Question Type");
            System.out.println("I'm clicking on Step III without selecting any Question Type");

            try {
                // Locate the Step III navigation element (the button)
                WebElement stepIIINavigation = driver.findElement(By.xpath("//div[contains(@class, 'MuiStepper-root')]//div[5]"));

                // Wait until the element is clickable
                WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
                wait.until(ExpectedConditions.elementToBeClickable(stepIIINavigation));

                // Click on Step III navigation
                stepIIINavigation.click();
                System.out.println("Step III button clicked");

                // Try to capture and verify the error message after clicking
                EmptyFieldMessage();

            } catch (NoSuchElementException e) {
                // If the Step III button or error message is not found
                System.out.println("Test Case Failed: Step III navigation button or error message not found.");
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Step III navigation button or error message not found.");
            }
        }

        public void EmptyFieldMessage() throws InterruptedException {
            TestRunner.getTest().log(Status.INFO, "Checking for error message when fields are empty.");
            System.out.println("Checking for error message when fields are empty.");

            try {
                // Locate the error message
                WebElement errorQuestionStatement = driver.findElement(By.xpath("//div[contains(text(), 'Question Statement is required!')]"));

                // Assert that the error message is displayed
                Assert.assertTrue("Question Statement required error not displayed", errorQuestionStatement.isDisplayed());

                // Log the pass message
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: Error message 'Question Statement is required!' is displayed.");
                System.out.println("Error message 'Question Statement is required!' is displayed as expected.");
            } catch (NoSuchElementException e) {
                // If the error message is not found, fail the test case
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Error message 'Question Statement is required!' not found.");
                System.out.println("Test Case Failed: Error message 'Question Statement is required!' not found.");
            }
        }


        public void EmptyFiledMessageStepIII() throws InterruptedException {
            TestRunner.getTest().log(Status.INFO, "I'm Trying to get message on any empty filed Step-III");
            System.out.println("I'm Trying to get message on any empty filed Step-III");

            try {
                // Locate the Step III navigation button
                WebElement stepIIINavigation = driver.findElement(By.xpath("//div[contains(@class, 'MuiStepper-root')]//div[5]"));

                // Wait until the Step III button is clickable
                WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
                wait.until(ExpectedConditions.elementToBeClickable(stepIIINavigation));

                // Click the Step III button
                stepIIINavigation.click();

                // Log the action for Step III navigation
                TestRunner.getTest().log(Status.INFO, "I'm Trying to get message on any empty field in Step-III");
                System.out.println("I'm Trying to get message on any empty field in Step-III");

                // Now, check if the error message is displayed for empty fields
                WebElement errorQuestionDetail = driver.findElement(By.xpath("//p[contains(text(), 'At least one standard is required')]"));

                // Assert that the error message is displayed
                Assert.assertTrue("Error: Question statement required error not displayed.", errorQuestionDetail.isDisplayed());

                // Log that the error message was successfully found
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: Error message 'At least one standard is required' is displayed as expected.");
                System.out.println("Error message 'At least one standard is required' is displayed as expected.");

            } catch (TimeoutException e) {
                // Handle if Step III button is not clickable within the timeout period
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Step III button was not clickable within the timeout.");
                System.out.println("Test Case Failed: Step III button was not clickable within the timeout.");
            } catch (NoSuchElementException e) {
                // Handle case where error message is not found
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Error message 'At least one standard is required' was not displayed.");
                System.out.println("Test Case Failed: Error message 'At least one standard is required' was not displayed.");
            } catch (AssertionError e) {
                // Handle assertion failure
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: " + e.getMessage());
                System.out.println("Test Case Failed: " + e.getMessage());
            }
        }

        public void WithOutStandardClickSaveShowRequiredMessage() throws InterruptedException {
            TestRunner.getTest().log(Status.INFO, "On Step III without selecting Standards Click on Save");
            System.out.println("On Step III without selecting Standards Click on Save");


            // Locate the Step III navigation button
            WebElement SaveStepIII = driver.findElement(By.xpath("//button[@id='btn-saveNext']"));

// Wait until the Step III button is clickable
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
            wait.until(ExpectedConditions.elementToBeClickable(SaveStepIII));

// Click the Step III button
            SaveStepIII.click();

// Log the action for Step III navigation
            TestRunner.getTest().log(Status.INFO, "Trying to get message on any empty field in Step-III");
            System.out.println("Trying to get message on any empty field in Step-III");

// Wait for the error message to be visible
            WebElement errorQuestionDetail = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//p[contains(text(), 'At least one standard is required')]")));

// Check if the error message is displayed
            if (errorQuestionDetail.isDisplayed()) {
                // Log that the error message was successfully found
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: Error message 'At least one standard is required' is displayed as expected.");
                System.out.println("Error message 'At least one standard is required' is displayed as expected.");
            } else {
                // Log that the error message was not found
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Error message 'At least one standard is required' is not displayed.");
                System.out.println("Test Case Failed: Error message 'At least one standard is required' is not displayed.");
            }


        }

        public void WithOutStandardClickSaveAndExitShowRequiredMessage() throws InterruptedException {
            TestRunner.getTest().log(Status.INFO, "On Step III without selecting Standards, Click on Save and Exit");
            System.out.println("On Step III without selecting Standards, Click on Save and Exit");

            WebElement SaveAndExitStepIII = driver.findElement(By.xpath("//button[@id='btn-publish']"));

            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            wait.until(ExpectedConditions.elementToBeClickable(SaveAndExitStepIII));

            SaveAndExitStepIII.click();

            TestRunner.getTest().log(Status.INFO, "I'm Trying to get message on any empty field in Step-III");
            System.out.println("I'm Trying to get message on any empty field in Step-III");

            List<WebElement> errorMessages = driver.findElements(By.xpath("//p[contains(text(), 'At least one standard is required')]"));

            if (!errorMessages.isEmpty() && errorMessages.get(0).isDisplayed()) {
                // Log that the error message was successfully found
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: Error message 'At least one standard is required' is displayed as expected.");
                System.out.println("Error message 'At least one standard is required' is displayed as expected.");
            } else {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Error message 'At least one standard is required' was not displayed when clicking on Save and Exit without selecting any standard.");
                System.out.println("Test Case Failed: Error message 'At least one standard is required' was not displayed.");
            }

        }

        public void clickOnStepIFromNavBar() throws InterruptedException {
            TestRunner.getTest().log(Status.INFO, "From StepII click on StepI From Nav Bar");
            System.out.println("From StepII click on StepI From Nav Bar");

            WebElement questionInformationStepI = driver.findElement(By.xpath("//div[contains(@class, 'MuiStepper-root')]//div[1]"));
            if (questionInformationStepI.isDisplayed() && questionInformationStepI.isEnabled()) {
                questionInformationStepI.click();
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: StepI click successfully from StepII from NavBar");
                System.out.println("Test Case Passed: StepI click successfully from StepII from NavBar");

            } else {
                TestRunner.getTest().log(Status.FAIL, "Test Case Passed: StepI Not clicked from StepII from NavBar");
                System.out.println("StepI Not clicked from StepII from NavBar");
                throw new RuntimeException("StepI Not clicked from StepII from NavBar");
            }

        }

        public void ValidateInformationIsSaveOnStepI() throws InterruptedException {
            TestRunner.getTest().log(Status.INFO, "Validate that Information is save on StepI when we Move From StepII to StepI");
            System.out.println("Validate that Information is save on StepI when we Move From StepII to StepI");

            validateTitleFromStepI();
            getAllMetaData();
            validatePointsWeightFromStepI();
            ValidateCourseFromStepI();
            validateStatusFromStepI();
            validateCheckboxStudentHint();
//        validateTextOfStudentHint();

        }

        public void validateTitleFromStepI() throws InterruptedException {
            TestRunner.getTest().log(Status.INFO, "Validate Title On stepI that Title is save when we Move From StepII to StepI");
            System.out.println("Validate Title On stepI that Title is save when we Move From StepII to StepI");

            //         for Title
            String retrievedTitleStepI = questionTitleInput.getAttribute("value");
            System.out.println("Retrieved Title is: " + retrievedTitleStepI);
            TestRunner.getTest().log(Status.INFO, "Retrieved Title is: " + retrievedTitleStepI);

            if (questionTitle.equals(retrievedTitleStepI)) {
                System.out.println("Test Case Passed: Step I Title information is retained.");
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: Step I information is retained.");
            } else {
                System.out.println("Test Case Failed: Step I Title information is not retained.");
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Step I Title information is not retained.");
                throw new RuntimeException("Step I Title information is not retained.");
            }

        }

        public void getAllMetaData() throws InterruptedException {
            TestRunner.getTest().log(Status.INFO, "I'm into get All Meta Data Information");
            System.out.println("I'm into get All Meta Data Information");

            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class, 'flex justify-between items-center')]")));

            // Locate the entire div block
            WebElement metadataContainer = driver.findElement(By.xpath("//div[contains(@class, 'flex justify-between items-center')]"));

            // Retrieve and print the text from the metadata container
            String metadataText = metadataContainer.getText();
            System.out.println("Metadata Text: \n" + metadataText);

            // Extract individual pieces of text for further use
            WebElement createdInfo = driver.findElement(By.xpath("//p[contains(text(), 'Created')]"));
            WebElement lastModifiedInfo = driver.findElement(By.xpath("//p[contains(text(), 'Last Modified')]"));
            WebElement systemIdInfo = driver.findElement(By.xpath("//p[contains(text(), 'System ID')]"));
//        WebElement sourceIdInfo = driver.findElement(By.xpath("//input[@id='FormikTextfield-8ZqMaAIUNgR2SDnc-O-IO']"));

            // Print each specific text
            System.out.println("Created Info: " + createdInfo.getText());
            System.out.println("Last Modified Info: " + lastModifiedInfo.getText());
            System.out.println("System ID: " + systemIdInfo.getText());
//        System.out.println("Source ID: " + sourceIdInfo.getAttribute("value"));
        }

        public void validatePointsWeightFromStepI() throws InterruptedException {
            TestRunner.getTest().log(Status.INFO, "Validate Points/Weight On stepI that Points/Weight is save when we Move From StepII to StepI");
            System.out.println("Validate Title On stepI that Points/Weight is save when we Move From StepII to StepI");

            String retrievedPointStepI = pointsInput.getAttribute("value");
            System.out.println("Retrieved Points/Weight is: " + retrievedPointStepI);
            TestRunner.getTest().log(Status.INFO, "Retrieved Points/Weight is: " + retrievedPointStepI);

            if (points.equals(retrievedPointStepI)) {
                System.out.println("Test Case Passed: Step I Points/Weight information is retained.");
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: Step I  Points/Weight information is retained.");
            } else {
                System.out.println("Test Case Failed: Step I Points/Weight information is not retained.");
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Step I  Points/Weight information is not retained.");
                throw new RuntimeException("Step I Points/Weight information is not retained.");
            }

        }

        public void ValidateCourseFromStepI() throws InterruptedException {
            TestRunner.getTest().log(Status.INFO, "Validate Course On stepI that Course is save when we Move From StepII to StepI");
            System.out.println("Validate Title On stepI that Course is save when we Move From StepII to StepI");

            WebElement selectedDropdownValue = driver.findElement(By.xpath("//div[contains(@class, 'MuiChip-root') and contains(@class, 'MuiAutocomplete-tag')]"));

            String currentSelectedValue = selectedDropdownValue.getText();
            System.out.println("Retrieved Course is: " + currentSelectedValue);
            TestRunner.getTest().log(Status.INFO, "Retrieved Course is: " + currentSelectedValue);

            if (selectedCourse.equals(currentSelectedValue)) {
                System.out.println("Test Case Passed: Correct course is selected: " + selectedCourse);
                TestRunner.getTest().log(Status.INFO, "Retried Correct course: " + selectedCourse);
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: Correct course is selected: " + selectedCourse);
            } else {
                System.out.println("Test Case Failed: Incorrect course selected. Expected: " + selectedCourse + ", but found: " + currentSelectedValue);
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Incorrect course selected. Expected: " + selectedCourse + ", but found: " + currentSelectedValue);
                throw new RuntimeException("Step I Course information is not retained.");
            }

        }

        public void validateStatusFromStepI() throws InterruptedException {
            TestRunner.getTest().log(Status.INFO, "Validate Status On stepI that Status is save when we Move From StepII to StepI");
            System.out.println("Validate Title On stepI that Status is save when we Move From StepII to StepI");

            WebElement statusInputElement = driver.findElement(By.xpath("(//input[contains(@class,'MuiSelect-nativeInput')])[2]"));

            // Retrieve the value from the input
            String selectedStatus = statusInputElement.getAttribute("value");

            System.out.println("Retrieved Status: " + selectedStatus);
            TestRunner.getTest().log(Status.INFO, "Retrieved Status: " + selectedStatus);

            // Compare the retrieved value with "Editing"
            if (selectedStatus.equalsIgnoreCase("Editing")) {
                System.out.println("The selected status is retained: " + selectedStatus);
                TestRunner.getTest().log(Status.PASS, "Status verification passed: The selected status is retained.");
            } else {
                System.out.println("The selected status is not retained. Current status: " + selectedStatus);
                TestRunner.getTest().log(Status.FAIL, "Status verification failed: The selected status is not retained.");
            }

        }

        public void validateCheckboxStudentHint() throws InterruptedException {
            TestRunner.getTest().log(Status.INFO, "Validate Display Student Hint is Checked On stepI  when we Move From StepII to StepI");
            System.out.println("Validate Display Student Hint is Checked On stepI  when we Move From StepII to StepI");

            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
            WebElement displayHint = driver.findElement(By.xpath("//input[contains(@id, 'SingleCheckBox-SingleCheckBox')]"));

            // Validate if the checkbox is still selected
            if (displayHint.isSelected()) {
                TestRunner.getTest().log(Status.PASS, "Test Case Passed   : The checkbox 'Student Hint' is still selected as expected after returning to Step I.");
                System.out.println("Validation Successful: 'Student Hint' checkbox is selected.");
            } else {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : The checkbox 'Student Hint' is not selected after returning to Step I.");
                System.out.println("Validation Failed: 'Student Hint' checkbox is not selected.");
                throw new RuntimeException("Checkbox state not retained after returning to Step I.");
            }

        }

        //    public void validateTextOfStudentHint() throws InterruptedException{
//        TestRunner.getTest().log(Status.INFO, "Validate Display Text Of Student Hint On stepI is save when we Move From StepII to StepI");
//        System.out.println("Validate Display Text Of Student Hint On stepI is save when we Move From StepII to StepI");
//
//        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
//        WebElement RichTextBoxBody = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='tox-edit-area']/iframe")));
//
//        driver.switchTo().frame(RichTextBoxBody);
//
//        // Retrieve the current text inside the rich text editor
//        WebElement editStudentHintTextBox = driver.findElement(By.xpath("//body[@id='tinymce']"));
//        String currentStudentHintText = editStudentHintTextBox.getText();
//
//        System.out.println("Previous Student Hint Text: " + randomStudentHintText);
//        TestRunner.getTest().log(Status.INFO, "Previous Student Hint Text: " + randomStudentHintText);
//
//        System.out.println("Retrieved Student Hint Text: " + currentStudentHintText);
//        TestRunner.getTest().log(Status.INFO, "Retrieved Student Hint Text: " + currentStudentHintText);
//
//
//        // Validate if the current text matches the previously entered text
//        if (currentStudentHintText.equals(randomStudentHintText)) {
//            TestRunner.getTest().log(Status.PASS, "Test Case Passed   : The Student Hint text is retained as expected.");
//            System.out.println("Validation Successful: The Student Hint text matches the expected value.");
//        } else {
//            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : The Student Hint text does not match the expected value.");
//            System.out.println("Validation Failed: The Student Hint text does not match.");
//            throw new RuntimeException("Student Hint text not retained after returning to Step I.");
//        }
//
//        // Switch back to the default content
//        driver.switchTo().defaultContent();
//        Thread.sleep(3000);
//    }
//
//    public void StepNextButton() throws InterruptedException{
//        System.out.println("I'm into Click on Next Button Step I");
//        TestRunner.getTest().log(Status.INFO, "I'm into Click on Next Button Step I");
//
//        WebElement nextButtonStepI= driver.findElement(By.xpath("//button[contains(@type,'button')][normalize-space()='Next']"));
//
//        helper.scrollToElement(driver,nextButtonStepI);
//        nextButtonStepI.click();
//        System.out.println("Test Case Passed: Successfully Click on Next Button Step I");
//        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Successfully Click on Next Button Step I");
//    }
//
//    public void ValidateInformationIsRetainedOnStepII() throws InterruptedException{TestRunner.getTest().log(Status.INFO, "Validating that information is saved on Step II when moving from Step I.");
//        System.out.println("Validating that information is saved on Step II when moving from Step I.");
//        TestRunner.getTest().log(Status.INFO, "Validating that information is saved on Step II when moving from Step I");
//
//        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
//
//        WebElement selectedTypeElement = driver.findElement(By.xpath("//div[@id='selectField-questionType']"));
//
//        String retainedQuestionType = selectedTypeElement.getText();
//        System.out.println("Retained Question Type is: " + retainedQuestionType);
//
//        if (retainedQuestionType.equalsIgnoreCase(selectedQuestionType)) {
//            System.out.println("The selected question type is retained: " + retainedQuestionType);
//            TestRunner.getTest().log(Status.PASS, "Question type verification passed: The selected question type is retained.");
//
//            // Use switch-case to determine the action based on the selected question type
//            switch (retainedQuestionType.toLowerCase()) {
//                case "multiple choice":
//                    ValidateQuestionTypeMultipleChoiceQuestion();
//                    break;
//                case "multiple select":
//                    ValidateQuestionTypeMultipleSelectQuestion();
//                    break;
//                case "sequencing":
//                    ValidateQuestionTypeSequenceQuestion();
//                    break;
//                case "open response":
//                    ValidateQuestionTypeOpenResponseQuestion();
//                    break;
//                case "spelling":
//                    ValidateQuestionTypeSpellingQuestion();
//                    break;
//                case "drawing":
//                    ValidateQuestionTypeDrawingQuestion();
//                    break;
//                default:
//                    System.out.println("No valid question type option selected.");
//                    TestRunner.getTest().log(Status.WARNING, "No valid question type option selected.");
//                    break;
//            }
//
//            // Use Actions to send the ESCAPE key
//            actions.sendKeys(Keys.ESCAPE).build().perform();
//
//            System.out.println("Selected Type Name: " + retainedQuestionType);
//            TestRunner.getTest().log(Status.INFO, "Selected Type Name: " + retainedQuestionType);
//            TestRunner.getTest().log(Status.PASS, "Test Case Passed: New question type " + retainedQuestionType + " selected successfully");
//        } else {
//            System.out.println("The selected question type is not retained. Current type: " + retainedQuestionType);
//            TestRunner.getTest().log(Status.FAIL, "Question type verification failed: The selected question type is not retained.");
//        }
//
//
//    }
//
//    public void ValidateQuestionTypeMultipleChoiceQuestion() throws InterruptedException{
//        TestRunner.getTest().log(Status.INFO, "I'm in Enter New Question Type Multiple Choice Question ");
//
//        WebElement totalMultipleChoiceOptions = wait.until(ExpectedConditions.elementToBeClickable(multipleChoiceTypeDropdown));
//        String totalMultipleChoiceOption = totalMultipleChoiceOptions.getText();
//        System.out.println("Total multiple choice options is: " + totalMultipleChoiceOption);
//        TestRunner.getTest().log(Status.INFO, "Total multiple choice options is: " + totalMultipleChoiceOption);
//
//        WebElement multipleChoiceHeaderBody = driver.findElement(By.xpath("(//div[contains(@class, 'tox-edit-area')]/iframe)[1]"));
//        driver.switchTo().frame(multipleChoiceHeaderBody);
//
//        WebElement editMultipleChoiceHeaderText = driver.findElement(By.xpath("//body[@id='tinymce']"));
//        System.out.println("Multiple Choice header text area is found");
//
//        String retainedMultipleChoiceHeader = editMultipleChoiceHeaderText.getText();
//
//        if (retainedMultipleChoiceHeader.contains(randomMultipleChoiceHeader)) {
//            System.out.println("Multiple Choice header text is retained: " + retainedMultipleChoiceHeader);
//            TestRunner.getTest().log(Status.PASS, "Multiple Choice header text verification passed: The entered header is retained.");
//        } else {
//            System.out.println("Multiple Choice header text is not retained. Current header: " + retainedMultipleChoiceHeader);
//            TestRunner.getTest().log(Status.FAIL, "Multiple Choice header text verification failed: The entered header is not retained.");
//        }
//
//        driver.switchTo().defaultContent();
//
//    }
//
//    public void ValidateQuestionTypeMultipleSelectQuestion() throws InterruptedException{
//
//        Thread.sleep(500);
//        System.out.println("I'm in to create Multiple Select Question");
//        TestRunner.getTest().log(Status.INFO, "I'm in to create Multiple Select Question");
//
//        WebElement multipleSelectHeaderBody = driver.findElement(By.xpath("(//div[contains(@class, 'tox-edit-area')]/iframe)[1]"));
//        driver.switchTo().frame(multipleSelectHeaderBody);
//
//        WebElement editMultipleSelectHeaderText = driver.findElement(By.xpath("//body[@id='tinymce']"));
//        System.out.println("Multiple Select header text area is found");
//
//        String retainedMultipleSelectQuestionHeader = editMultipleSelectHeaderText.getText();
//
//        if (retainedMultipleSelectQuestionHeader.contains(randomMultipleSelectHeader)) {
//            System.out.println("The Multiple Select header is retained: " + retainedMultipleSelectQuestionHeader);
//            TestRunner.getTest().log(Status.PASS, "Multiple Select header verification passed: The entered header is retained.");
//        } else {
//            System.out.println("The Multiple Select header is not retained. Current header: " + retainedMultipleSelectQuestionHeader);
//            TestRunner.getTest().log(Status.FAIL, "Multiple Select header verification failed: The entered header is not retained.");
//        }
//
//        driver.switchTo().defaultContent();
//
//    }
//
//
//    public void ValidateQuestionTypeSequenceQuestion() throws InterruptedException{
//        TestRunner.getTest().log(Status.INFO, "I'm in to validate sequence Question");
//        Thread.sleep(500);
//        System.out.println("I'm in to validate sequence Question");
//
//        WebElement sequenceHeaderBody = driver.findElement(By.xpath("(//div[contains(@class, 'tox-edit-area')]/iframe)[1]"));
//        driver.switchTo().frame(sequenceHeaderBody);
//
//        WebElement editSequenceHeaderText = driver.findElement(By.xpath("//body[@id='tinymce']"));
//        System.out.println("Sequence header text area is found");
//
//        String retainedSequenceHeader = editSequenceHeaderText.getText();
//
//
//        if (retainedSequenceHeader.contains(randomSequenceHeader)) {
//            System.out.println("The Sequence header text is retained: " + retainedSequenceHeader);
//            TestRunner.getTest().log(Status.PASS, "Sequence header text verification passed: The entered header is retained.");
//        } else {
//            System.out.println("The Sequence header text is not retained. Current header: " + retainedSequenceHeader);
//            TestRunner.getTest().log(Status.FAIL, "Sequence header text verification failed: The entered header is not retained.");
//        }
//
//        driver.switchTo().defaultContent();
//
//
//    }
//
//    public void ValidateQuestionTypeOpenResponseQuestion() throws InterruptedException{
//
//        TestRunner.getTest().log(Status.INFO, "I'm in to validate Open Response Question");
//        Thread.sleep(500);
//        System.out.println("I'm in to validate Open Response Question");
//
//        WebElement SpellingHeaderBody = driver.findElement(By.xpath("(//div[contains(@class, 'tox-edit-area')]/iframe)[1]"));
//        driver.switchTo().frame(SpellingHeaderBody);
//
//        WebElement editQuestionTypeOpenResponseHeaderText = driver.findElement(By.xpath("//body[@id='tinymce']"));
//        System.out.println("Open Response header text area is found");
//
//
//        String retainedOpenResponseHeader = editQuestionTypeOpenResponseHeaderText.getText();
//
//        if (retainedOpenResponseHeader.contains(randomOpenResponseHeader)) {
//            System.out.println("The Open Response header text is retained: " + retainedOpenResponseHeader);
//            TestRunner.getTest().log(Status.PASS, "Open Response header text verification passed: The entered header is retained.");
//        } else {
//            System.out.println("The Open Response header text is not retained. Current header: " + retainedOpenResponseHeader);
//            TestRunner.getTest().log(Status.FAIL, "Open Response header text verification failed: The entered header is not retained.");
//        }
//
//        driver.switchTo().defaultContent();
//
//
//    }
//
//    public void ValidateQuestionTypeSpellingQuestion() throws InterruptedException{
//        TestRunner.getTest().log(Status.INFO, "I'm in to Validate Spelling Question ");
//        Thread.sleep(500);
//        System.out.println("I'm in to Validate Spelling Question");
//
//        WebElement SpellingHeaderBody = driver.findElement(By.xpath("(//div[contains(@class, 'tox-edit-area')]/iframe)[1]"));
//        driver.switchTo().frame(SpellingHeaderBody);
//
//        WebElement editSpellingHeaderText = driver.findElement(By.xpath("//body[@id='tinymce']"));
//        System.out.println("Spelling header text area is found");
//
//
//        String retainedSpellingHeader = editSpellingHeaderText.getText(); // Use getText() for plain text
//
//        if (retainedSpellingHeader.contains(randomSpellingHeader)) {
//            System.out.println("The spelling header is retained: " + retainedSpellingHeader);
//            TestRunner.getTest().log(Status.PASS, "Spelling header verification passed: The entered header is retained.");
//        } else {
//            System.out.println("The spelling header is not retained. Current header: " + retainedSpellingHeader);
//            TestRunner.getTest().log(Status.FAIL, "Spelling header verification failed: The entered header is not retained.");
//        }
//
//        driver.switchTo().defaultContent();
//
//    }
//
//    public void ValidateQuestionTypeDrawingQuestion() throws InterruptedException {
//        TestRunner.getTest().log(Status.INFO, "I'm into validate Drawing Type Question");
//        System.out.println("I'm into validate Drawing Type Question");
//
//
//        WebElement drawingHeaderBody = driver.findElement(By.xpath("(//div[contains(@class, 'tox-edit-area')]/iframe)[1]"));
//        driver.switchTo().frame(drawingHeaderBody);
//
//        // Locate the header text area again
//        WebElement editDrawingHeaderText = driver.findElement(By.xpath("//body[@id='tinymce']"));
//
//        // Retrieve the actual header text value
//        String retainedHeaderText = editDrawingHeaderText.getText(); // or getAttribute("value") if needed
//
//        // Validate the retained header text
//        if (retainedHeaderText.equalsIgnoreCase(randomDrawingHeader)) {
//            System.out.println("The drawing question header is retained: " + retainedHeaderText);
//            TestRunner.getTest().log(Status.PASS, "Drawing question header verification passed: The value is retained.");
//        } else {
//            System.out.println("The drawing question header is not retained. Current header: " + retainedHeaderText);
//            TestRunner.getTest().log(Status.FAIL, "Drawing question header verification failed: The value is not retained.");
//        }
//
//        driver.switchTo().defaultContent();
//    }
//
        public void ClickOnNavigationStepII() throws InterruptedException {
            TestRunner.getTest().log(Status.INFO, "I'm into click onStep-II from Navigation with missing fields");
            System.out.println("I'm into click onStep-II from Navigation with missing fields");

            try {
                // Locate the step navigation element (the button)
                WebElement stepIINavigation = driver.findElement(By.xpath("//div[contains(@class, 'MuiStepper-root')]//div[3]"));

                // Create a WebDriverWait to wait for the button to be clickable
                WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10)); // Timeout set to 10 seconds

                // Try to wait until the element is clickable
                wait.until(ExpectedConditions.elementToBeClickable(stepIINavigation));

                // If it is clickable, fail the test case
                System.out.println("Test Case Failed: Step II Navigation is clickable with empty fields.");
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Step II Navigation is clickable with empty fields.");

            } catch (TimeoutException e) {
                // If TimeoutException is thrown, it means the element is not clickable within the time frame, so pass the test case
                System.out.println("Test Case Passed: Step II Navigation is not clickable as expected with empty fields.");
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: Step II Navigation is not clickable as expected with empty fields.");
            }

        }

        public void ClickOnNavigationStepIIFromStepIII() throws InterruptedException {
            TestRunner.getTest().log(Status.INFO, "I'm clicking on Step II From Step III");
            System.out.println("I'm clicking on Step II From Step III");

            try {
                // Locate the Step III navigation element (the button)
                WebElement stepIINavigation = driver.findElement(By.xpath("//div[contains(@class, 'MuiStepper-root')]//div[3]"));

                // Wait until the element is clickable
                WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
                wait.until(ExpectedConditions.elementToBeClickable(stepIINavigation));

                // Click on Step III navigation
                stepIINavigation.click();
                System.out.println("Step III button clicked");

            } catch (NoSuchElementException e) {
                // If the Step III button or error message is not found
                System.out.println("Test Case Failed: Step II navigation button or error message not found.");
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Step II navigation button or error message not found.");
            }

        }

//
    public void ValidateInformationIsRetainedOnStepIII() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Check, Validate Information is Retained on Step III when we move from Step II to Step III");
        System.out.println("Check, Validate Information is Retained on Step III when we move from Step II to Step III");

//// Retrieve selected standards values
        List<WebElement> selectedStandardsValues = driver.findElements(By.xpath("//div[contains(@class,'items-start')]//div[contains(@class,'MuiAutocomplete-inputRoot')]//div[contains(@class, 'MuiChip-root') and contains(@class, 'MuiAutocomplete-tag')]"));
//        List<String> standardsList = new ArrayList<>();
//
//// Store each standard in the list
////        for (WebElement standard : selectedStandardsValues) {
////            String currentSelectedValue = standard.getText();
////            standardsList.add(currentSelectedValue); // Add each value to the list
////            System.out.println("Retrieved Course: " + currentSelectedValue);
////            TestRunner.getTest().log(Status.INFO, "Retrieved Course: " + currentSelectedValue);
////        }
////
////        System.out.println("Retrieved Selected Standards List: " + standardsList);
////        TestRunner.getTest().log(Status.INFO, "Retrieved Selected Standards List:" + standardsList);
////
////        System.out.println("Previous Selected Standards are: " + selectedStandards);
////        TestRunner.getTest().log(Status.INFO, "Previous Selected Standards are " + selectedStandards);
////
////// Compare retrieved standards with selected standards
////        for (String standard : standardsList) {
////            if (standard.equals(selectedStandards)) {
////                System.out.println("The standard '" + standard + "' is present in the selected standards list.");
////                TestRunner.getTest().log(Status.PASS, "The standard '" + standard + "' is present in the selected standards list.");
////            } else {
////                System.out.println("The standard '" + standard + "' is NOT present in the selected standards list.");
////                TestRunner.getTest().log(Status.FAIL, "The standard '" + standard + "' is NOT present in the selected standards list.");
////            }
////        }
//
//
//        // Log step validation
//        TestRunner.getTest().log(Status.INFO, "Check, Validate Information is Retained on Step III when we move from Step II to Step III");
//        System.out.println("Check, Validate Information is Retained on Step III when we move from Step II to Step III");
//
//// Retrieve selected standards values
//        List<WebElement> selectedStandardsValues = driver.findElements(By.xpath("//div[contains(@class,'items-start')]//div[contains(@class,'MuiAutocomplete-inputRoot')]//div[contains(@class, 'MuiChip-root') and contains(@class, 'MuiAutocomplete-tag')]"));
//        List<String> standardsList = new ArrayList<>();
//
//// Store each standard in the list
//        for (WebElement standard : selectedStandardsValues) {
//            String currentSelectedValue = standard.getText().trim(); // Trim each value
//            standardsList.add(currentSelectedValue); // Add each trimmed value to the list
//            System.out.println("Retrieved Course: " + currentSelectedValue);
//            TestRunner.getTest().log(Status.INFO, "Retrieved Course: " + currentSelectedValue);
//        }
//
//// Log retrieved and previous selected standards
//        System.out.println("Retrieved Selected Standards List: " + standardsList);
//        TestRunner.getTest().log(Status.INFO, "Retrieved Selected Standards List:" + standardsList);
//
//        System.out.println("Previous Selected Standards are: " + selectedStandards);
//        TestRunner.getTest().log(Status.INFO, "Previous Selected Standards are: " + selectedStandards);
//
//// Compare retrieved standards with selected standards
//        for (String standard : standardsList) {
//            boolean matchFound = false;
//
//            // Compare each standard from the retrieved list with the previous list
//            for (String selectedStandard : selectedStandards) {
//                if (standard.equals(selectedStandard.trim())) { // Ensure both are trimmed
//                    matchFound = true;
//                    System.out.println("The standard '" + standard + "' is present in the selected standards list.");
//                    TestRunner.getTest().log(Status.PASS, "The standard '" + standard + "' is present in the selected standards list.");
//                    break;
//                }
//            }

//
//            if (!matchFound) {
//                System.out.println("The standard '" + standard + "' is NOT present in the selected standards list.");
//                TestRunner.getTes
// }

//        }


        // Log step validation
//        TestRunner.getTest().log(Status.INFO, "Check, Validate Information is Retained on Step III when we move from Step II to Step III");
//        System.out.println("Check, Validate Information is Retained on Step III when we move from Step II to Step III");

        // Retrieve selected standards values****************************************************************
//        List<WebElement> selectedQuestionStandardsValues = driver.findElements(By.xpath("//div[contains(@class,'items-start')]//div[contains(@class,'MuiAutocomplete-inputRoot')]//div[contains(@class, 'MuiChip-root') and contains(@class, 'MuiAutocomplete-tag')]"));
//        List<String> standardsList = new ArrayList<>();

    }
}

