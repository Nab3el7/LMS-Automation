package pageFactory.MyContent.QuestionsPF;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class CustomQuestionsTypes_PF {
    public WebDriverWait wait;
    WebDriver driver;
    Helper helper;
    Actions actions;

    @FindBy(xpath = "//div[.//label[normalize-space(text())='Number of Choices']]//input[@name='numofChoices']")
    WebElement multipleChoiceTypeDropdown;

    @FindBy(xpath = "//div[contains(@class, 'questionType')]")
    WebElement questionAnswersContainer;

    public static String randomDrawingHeader;
    public static String randomSpellingHeader;
    public static String randomSequenceHeader;
    public static String randomMultipleSelectHeader;
    public static String randomMultipleChoiceHeader;
    public static String randomOpenResponseHeader;

    public CustomQuestionsTypes_PF(WebDriver driver) {
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        actions = new Actions(driver);
        helper = new Helper();
    }

    public void EnterNewQuestionTypeMultipleChoiceQuestion() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm in Enter New Question Type Multiple Choice Question ");

        WebElement totalMultipleChoiceOptions = wait.until(ExpectedConditions.elementToBeClickable(multipleChoiceTypeDropdown));
        String totalMultipleChoiceOption = totalMultipleChoiceOptions.getText();
        System.out.println("Total multiple choice options is: " + totalMultipleChoiceOption);
        TestRunner.getTest().log(Status.INFO, "Total multiple choice options is: " + totalMultipleChoiceOption);

        WebElement multipleChoiceHeaderBody = driver.findElement(By.xpath("(//div[contains(@class, 'tox-edit-area')]/iframe)[1]"));
        driver.switchTo().frame(multipleChoiceHeaderBody);

        WebElement editMultipleChoiceHeaderText = driver.findElement(By.xpath("//body[contains(@data-mce-placeholder, 'Question Statement')]//p[contains(@source, 'Gallopade')]"));
        System.out.println("Multiple Choice header text area is found");

        editMultipleChoiceHeaderText.clear();
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].value='';", editMultipleChoiceHeaderText);

        randomMultipleChoiceHeader = helper.generateRandomText("Multiple Choice Header ");
        System.out.println(randomMultipleChoiceHeader);
        TestRunner.getTest().log(Status.INFO, "Multiple choice Header is: " + randomMultipleChoiceHeader);

        editMultipleChoiceHeaderText.sendKeys(randomMultipleChoiceHeader);
        driver.switchTo().defaultContent();

        for (int i = 2; i <= 5; i++) {
            WebElement multipleChoiceAnswer = driver.findElement(By.xpath("(//div[contains(@class, 'tox-edit-area')]/iframe)[" + i + "]"));
            driver.switchTo().frame(multipleChoiceAnswer);

            WebElement editMultipleChoiceAnswerText = driver.findElement(By.xpath("//body[contains(@data-mce-placeholder, ' - enter text')]//p[contains(@source, 'Gallopade')]"));
            System.out.println("Multiple Choice answer text area is found");

            helper.scrollToElement(driver, editMultipleChoiceAnswerText);
            Thread.sleep(1000);

            editMultipleChoiceAnswerText.clear();
            js.executeScript("arguments[0].value='';", editMultipleChoiceAnswerText);

            String randomMultipleChoiceAnswer = helper.generateRandomText("Multiple Choice Answer " + (i - 1) + " ");
            System.out.println(randomMultipleChoiceAnswer);
            TestRunner.getTest().log(Status.INFO, "Multiple choice Answer is: " + randomMultipleChoiceAnswer);

            editMultipleChoiceAnswerText.sendKeys(randomMultipleChoiceAnswer);
            driver.switchTo().defaultContent();
        }
        System.out.println("Test Case Passed    :  New question type multiple choice successfully");
        TestRunner.getTest().log(Status.PASS, "Test Case Passed   : New question type multiple choice successfully");

        SelectMultipleChoiceCorrectOption();
    }

    private void SelectMultipleChoiceCorrectOption() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Selecting the multiple choice correct answer option");
        Thread.sleep(2000);
        System.out.println("Selecting the multiple choice correct answer option ");
        WebElement multipleChoiceAnswers = wait.until(ExpectedConditions.visibilityOf(questionAnswersContainer));
        List<WebElement> totalMultipleChoiceCorrectOption = multipleChoiceAnswers.findElements(By.xpath(".//input[contains(@value, 'SingleCheckBox')]"));
        System.out.println("Total multiple choice options checkbox: " + totalMultipleChoiceCorrectOption.size());
        TestRunner.getTest().log(Status.INFO, "Total multiple choice options checkbox: " + totalMultipleChoiceCorrectOption.size());

        if (!totalMultipleChoiceCorrectOption.isEmpty()) {
            Random rand = new Random();
            int randomIndex = rand.nextInt(totalMultipleChoiceCorrectOption.size());

            WebElement correctAnswerCheckbox = totalMultipleChoiceCorrectOption.get(randomIndex);
            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript("arguments[0].click();", correctAnswerCheckbox);

            if (correctAnswerCheckbox.isSelected()) {
                System.out.println("Checkbox remains checked.");
                actions.sendKeys(Keys.ESCAPE).build().perform();
            } else {
                System.out.println("Checkbox unchecked after click.");
            }

            Thread.sleep(2000);
            System.out.println("Clicked on checkbox at index: " + randomIndex);
            TestRunner.getTest().log(Status.INFO, "Clicked on checkbox at index: " + randomIndex);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed   : New question type multiple choice correct option click successfully");

        } else {
            System.out.println("No checkboxes found.");
        }
    }

    public void EnterNewQuestionTypeMultipleSelectQuestion() throws InterruptedException {
        Thread.sleep(500);
        System.out.println("I'm in to create Multiple Select Question");
        TestRunner.getTest().log(Status.INFO, "I'm in to create Multiple Select Question");

        WebElement totalMultipleSelectOptions = wait.until(ExpectedConditions.elementToBeClickable(multipleChoiceTypeDropdown));
        String totalMultipleSelectOption = totalMultipleSelectOptions.getText();
        System.out.println("Total multiple select options is: " + totalMultipleSelectOption);
        TestRunner.getTest().log(Status.INFO, "Total multiple select options is: " + totalMultipleSelectOption);

        WebElement multipleSelectHeaderBody = driver.findElement(By.xpath("(//div[contains(@class, 'tox-edit-area')]/iframe)[1]"));
        driver.switchTo().frame(multipleSelectHeaderBody);

        WebElement editMultipleSelectHeaderText = driver.findElement(By.xpath("//body[contains(@data-mce-placeholder, 'Question Statement')]//p[contains(@source, 'Gallopade')]"));
        System.out.println("Multiple Select header text area is found");

        editMultipleSelectHeaderText.clear();
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].value='';", editMultipleSelectHeaderText);

        randomMultipleSelectHeader = helper.generateRandomText("Multiple Select Header ");
        System.out.println(randomMultipleSelectHeader);
        TestRunner.getTest().log(Status.INFO, "Multiple Select Header is: " + randomMultipleSelectHeader);

        editMultipleSelectHeaderText.sendKeys(randomMultipleSelectHeader);
        driver.switchTo().defaultContent();

        for (int i = 2; i <= 5; i++) {
            WebElement multipleSelectAnswer = driver.findElement(By.xpath("(//div[contains(@class, 'tox-edit-area')]/iframe)[" + i + "]"));
            driver.switchTo().frame(multipleSelectAnswer);

            WebElement editMultipleSelectAnswerText = driver.findElement(By.xpath("//body[contains(@data-mce-placeholder, ' - enter text')]//p[contains(@source, 'Gallopade')]"));
            System.out.println("Multiple Select answer text area is found");

            helper.scrollToElement(driver, editMultipleSelectAnswerText);
            Thread.sleep(1000);

            editMultipleSelectAnswerText.clear();
            js.executeScript("arguments[0].value='';", editMultipleSelectAnswerText);

            String randomMultipleSelectAnswer = helper.generateRandomText("Multiple Select Answer " + (i - 1) + " ");
            System.out.println(randomMultipleSelectAnswer);
            TestRunner.getTest().log(Status.INFO, "Multiple Select Answer is: " + randomMultipleSelectAnswer);

            editMultipleSelectAnswerText.sendKeys(randomMultipleSelectAnswer);
            driver.switchTo().defaultContent();
        }
        System.out.println("Test Case Passed    :  New question type multiple select successfully");
        TestRunner.getTest().log(Status.PASS, "Test Case Passed   : New question type multiple select successfully");

        SelectMultipleSelectCorrectOption();
    }

    private void SelectMultipleSelectCorrectOption() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Multiple Select Correct Answer Option ");
        Thread.sleep(2000);
        System.out.println("Selecting the multiple select correct answer option ");
        WebElement multipleChoiceAnswers = wait.until(ExpectedConditions.visibilityOf(questionAnswersContainer));
        List<WebElement> totalMultipleSelectCorrectOption = multipleChoiceAnswers.findElements(By.xpath(".//input[contains(@value, 'SingleCheckBox')]"));
        System.out.println("Total multiple select options checkbox: " + totalMultipleSelectCorrectOption.size());

        if (!totalMultipleSelectCorrectOption.isEmpty()) {
            Random rand = new Random();
            int numToSelect = Math.min(2 + rand.nextInt(2), totalMultipleSelectCorrectOption.size());
            Collections.shuffle(totalMultipleSelectCorrectOption);

            for (int i = 0; i < numToSelect; i++) {
                WebElement checkbox = totalMultipleSelectCorrectOption.get(i);
                JavascriptExecutor js = (JavascriptExecutor) driver;
                js.executeScript("arguments[0].click();", checkbox);

                if (checkbox.isSelected()) {
                    System.out.println("Checkbox at index " + i + " remains checked.");
                } else {
                    System.out.println("Checkbox at index " + i + " unchecked after click.");
                }
            }

            Thread.sleep(2000);
            System.out.println("Clicked on " + numToSelect + " checkboxes.");
            TestRunner.getTest().log(Status.INFO, "Clicked on " + numToSelect + " checkboxes");
            System.out.println("Test Case Passed: New question type multiple select correct option click successfully");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  New question type multiple select correct option click successfully");

            actions.sendKeys(Keys.ESCAPE).build().perform();
        } else {
            System.out.println("No checkboxes found.");
        }
    }

    public void EnterNewQuestionTypeSequenceQuestion() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Create New Question Type Sequence Question");
        Thread.sleep(500);
        System.out.println("I'm in to create Sequence Question");

        WebElement totalSequenceOptions = wait.until(ExpectedConditions.elementToBeClickable(multipleChoiceTypeDropdown));
        String totalSequenceOption = totalSequenceOptions.getText();
        System.out.println("Total sequence options is: " + totalSequenceOption);
        TestRunner.getTest().log(Status.INFO, "Total sequence options is: " + totalSequenceOption);

        WebElement sequenceHeaderBody = driver.findElement(By.xpath("(//div[contains(@class, 'tox-edit-area')]/iframe)[1]"));
        driver.switchTo().frame(sequenceHeaderBody);

        WebElement editSequenceHeaderText = driver.findElement(By.xpath("//body[contains(@data-mce-placeholder, 'Question Statement')]//p[contains(@source, 'Gallopade')]"));
        System.out.println("Sequence header text area is found");

        editSequenceHeaderText.clear();
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].value='';", editSequenceHeaderText);

        randomSequenceHeader = helper.generateRandomText("Sequence Header ");
        System.out.println(randomSequenceHeader);
        TestRunner.getTest().log(Status.INFO, "Sequence Question Header is: " + randomSequenceHeader);

        editSequenceHeaderText.sendKeys(randomSequenceHeader);
        driver.switchTo().defaultContent();

        for (int i = 2; i <= 5; i++) {
            WebElement sequenceAnswer = driver.findElement(By.xpath("(//div[contains(@class, 'tox-edit-area')]/iframe)[" + i + "]"));
            driver.switchTo().frame(sequenceAnswer);

            WebElement editSequenceAnswerText = driver.findElement(By.xpath("//body[contains(@data-mce-placeholder, ' - enter text')]//p[contains(@source, 'Gallopade')]"));
            System.out.println("Sequence answer text area is found");

            helper.scrollToElement(driver, editSequenceAnswerText);
            Thread.sleep(1000);

            editSequenceAnswerText.clear();
            js.executeScript("arguments[0].value='';", editSequenceAnswerText);

            String randomSequenceAnswer = helper.generateRandomText("Sequence Answer " + (i - 1) + " ");
            System.out.println(randomSequenceAnswer);
            TestRunner.getTest().log(Status.INFO, "Sequence Answer is: " + randomSequenceAnswer);

            editSequenceAnswerText.sendKeys(randomSequenceAnswer);
            driver.switchTo().defaultContent();
        }
        System.out.println("Test Case Passed    :  New question type sequence successfully");
        TestRunner.getTest().log(Status.PASS, "Test Case Passed : New question type sequence successfully");

        SetSequenceCorrectOption();
    }

    private void SetSequenceCorrectOption() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Selecting the sequence correct answer option");
        Thread.sleep(2000);
        System.out.println("Selecting the sequence correct answer option ");

        WebElement sequenceAnswers = wait.until(ExpectedConditions.visibilityOf(questionAnswersContainer));
        List<WebElement> totalSequenceCorrectOption = sequenceAnswers.findElements(By.xpath(".//td[contains(@role, 'button')]"));
        System.out.println("Total sequence options: " + totalSequenceCorrectOption.size());
        TestRunner.getTest().log(Status.INFO, "Total sequence options: " + totalSequenceCorrectOption.size());

        if (!totalSequenceCorrectOption.isEmpty()) {
            List<WebElement> shuffledOptions = new ArrayList<>(totalSequenceCorrectOption);
            Collections.shuffle(shuffledOptions);

            for (int i = 0; i < shuffledOptions.size(); i++) {
                WebElement source = shuffledOptions.get(i);
                WebElement target = i + 1 < shuffledOptions.size() ? shuffledOptions.get(i + 1) : source;

                actions.clickAndHold(source)
                        .moveToElement(target)
                        .release()
                        .build()
                        .perform();
                Thread.sleep(1000);
            }

            Thread.sleep(2000);
            System.out.println("Sequence options have been shuffled and reordered.");
            TestRunner.getTest().log(Status.INFO, "Sequence options have been shuffled and reordered");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed : New question type sequence correct options successfully");

            actions.sendKeys(Keys.ESCAPE).build().perform();
        } else {
            System.out.println("No sequence answer found.");
        }
    }


    public void EnterNewQuestionTypeOpenResponseQuestion() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm in to create Open Response Question");
        Thread.sleep(500);
        System.out.println("I'm in to create Open Response Question");

        WebElement toggleButton = driver.findElement(By.xpath("//input[@name='uploadDocumentCheck']/parent::span"));

        if (toggleButton.isEnabled() && toggleButton.isDisplayed()) {
            toggleButton.click();
            System.out.println("Toggle button clicked.");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed : Toggle button clicked");
        } else {
            System.out.println("Toggle button is not enabled or not clickable.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Toggle button is not enabled or not clickable.");
        }

        WebElement OpenResponseHeaderBody = driver.findElement(By.xpath("(//div[contains(@class, 'tox-edit-area')]/iframe)[1]"));
        driver.switchTo().frame(OpenResponseHeaderBody);

        WebElement editOpenResponseHeaderText = driver.findElement(By.xpath("//body[contains(@data-mce-placeholder, 'Question Statement')]//p[contains(@source, 'Gallopade')]"));
        System.out.println("Open Response header text area is found");

        editOpenResponseHeaderText.clear();
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].value='';", editOpenResponseHeaderText);

        randomOpenResponseHeader = helper.generateRandomText("Open Response Header ");
        System.out.println(randomOpenResponseHeader);
        TestRunner.getTest().log(Status.INFO, "Open response Header : " + randomOpenResponseHeader);

        editOpenResponseHeaderText.sendKeys(randomOpenResponseHeader);
        driver.switchTo().defaultContent();

        Thread.sleep(2000);
        TestRunner.getTest().log(Status.PASS, "Test Case Passed : New question type open response successfully");
    }

    public void EnterNewQuestionTypeSpellingQuestion() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm in to create Spelling Question ");
        Thread.sleep(500);
        System.out.println("I'm in to create Spelling Question");

        WebElement SpellingHeaderBody = driver.findElement(By.xpath("(//div[contains(@class, 'tox-edit-area')]/iframe)[1]"));
        driver.switchTo().frame(SpellingHeaderBody);

        WebElement editSpellingHeaderText = driver.findElement(By.xpath("//body[contains(@data-mce-placeholder, 'Question Statement')]//p[contains(@source, 'Gallopade')]"));
        System.out.println("Spelling header text area is found");

        editSpellingHeaderText.clear();
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].value='';", editSpellingHeaderText);

        randomSpellingHeader = helper.generateRandomText("Spelling Header ");
        System.out.println(randomSpellingHeader);
        TestRunner.getTest().log(Status.INFO, "Spelling Question Header is:  " + randomSpellingHeader);

        editSpellingHeaderText.sendKeys(randomSpellingHeader);
        driver.switchTo().defaultContent();

        WebElement txtSpellingWord = driver.findElement(By.xpath("//input[@name='spellingWord']"));

        txtSpellingWord.clear();
        js.executeScript("arguments[0].value='';", txtSpellingWord);

        txtSpellingWord.sendKeys("Automation");

        WebElement checkBoxCaseSensitive = driver.findElement(By.xpath("//span[@title='Case Sensitive']"));
        checkBoxCaseSensitive.click();

        Thread.sleep(2000);

        TestRunner.getTest().log(Status.PASS, "Test Case Passed : New question type spelling successfully");

    }

    public void EnterNewQuestionTypeDrawingQuestion() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm in to create Drawing Question ");
        Thread.sleep(500);
        System.out.println("I'm in to create Drawing Question");

        WebElement DrawingHeaderBody = driver.findElement(By.xpath("(//div[contains(@class, 'tox-edit-area')]/iframe)[1]"));
        driver.switchTo().frame(DrawingHeaderBody);

        WebElement editDrawingHeaderText = driver.findElement(By.xpath("//body[contains(@data-mce-placeholder, 'Question Statement')]//p[contains(@source, 'Gallopade')]"));
        System.out.println("Drawing header text area is found");

        editDrawingHeaderText.clear();
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].value='';", editDrawingHeaderText);

        randomDrawingHeader = helper.generateRandomText("Drawing Header ");
        System.out.println(randomDrawingHeader);
        TestRunner.getTest().log(Status.INFO, "Drawing Question Header is:  " + randomDrawingHeader);

        editDrawingHeaderText.sendKeys(randomDrawingHeader);
        driver.switchTo().defaultContent();

        WebElement inputFile = driver.findElement(By.xpath("//input[@type='file']"));

        js.executeScript("arguments[0].value='';", inputFile);

        String filePath = System.getProperty("user.dir") + "/src/test/resources/drivers/DummyImg.png";

        inputFile.sendKeys(filePath);

        Thread.sleep(2000);
        TestRunner.getTest().log(Status.PASS, "Test Case Passed : New question type Drawing successfully");
    }

    public void EnterNewQuestionTypeDrawingQuestionInvalid() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm in to create Drawing Question ");
        Thread.sleep(500);
        System.out.println("I'm in to create Drawing Question");

        WebElement DrawingHeaderBody = driver.findElement(By.xpath("(//div[contains(@class, 'tox-edit-area')]/iframe)[1]"));
        driver.switchTo().frame(DrawingHeaderBody);

        WebElement editDrawingHeaderText = driver.findElement(By.xpath("//body[contains(@data-mce-placeholder, 'Question Statement')]//p[contains(@source, 'Gallopade')]"));
        System.out.println("Drawing header text area is found");

        editDrawingHeaderText.clear();
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].value='';", editDrawingHeaderText);

        String randomDrawingHeader = helper.generateRandomText("Drawing Header ");
        System.out.println(randomDrawingHeader);
        TestRunner.getTest().log(Status.INFO, "Drawing Question Header is:  " + randomDrawingHeader);
        editDrawingHeaderText.sendKeys(randomDrawingHeader);
        driver.switchTo().defaultContent();

        WebElement inputFile = driver.findElement(By.xpath("//input[@type='file']"));

        js.executeScript("arguments[0].value='';", inputFile);

        String filePath = System.getProperty("user.dir") + "/src/test/resources/drivers/file.txt";

        inputFile.sendKeys(filePath);

        Thread.sleep(2000);
        
        TestRunner.getTest().log(Status.PASS, "Test Case Passed : New question type Drawing successfully");
    }

}
