package pageFactory.MyContent.QuestionsPF;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.MyContentModule.QuestionsSteps.QuestionFiltersSteps;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.ElementNotInteractableException;

import java.time.Duration;
import java.util.List;

public class FilterQuestion_PF {
    public WebDriverWait wait;
    WebDriver driver;

    CreateQuestion_PF createQuestionPF;
    Helper helper;

    String searchQuestionCourse;
    String selectedQuestionType;
    String searchQuestionByName;
    public static String questionName;

    @FindBy(xpath = "(//div[contains(@class, 'selectTextFieldsWrapper')])[1]")
    WebElement dropDownSelectCourse;

    @FindBy(xpath = "//button[normalize-space()='Apply Filter']")
    WebElement btnApplyFilter;

    @FindBy(xpath = "//div[contains(@class, 'QuestionDashboardContainer')]//tbody")
    WebElement questionsContainerTable;

    @FindBy(xpath = "//div[contains(@class, 'QuestionDashboardContainer')]//div[contains(@class, 'right-panel')]")
    WebElement questionsContainerRightPanel;

    public FilterQuestion_PF(WebDriver driver) {
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
        createQuestionPF = new CreateQuestion_PF(driver);
        helper = new Helper();
    }

    public void SelectCourseForCustomFilter() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Select Courses for Custom Filter");
        dropDownSelectCourse.click();
        Thread.sleep(1000);

        WebElement listCourse = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[@role='listbox']")));
        List<WebElement> optionsCourses = listCourse.findElements(By.xpath(".//li"));

        System.out.println("Courses List is: " + optionsCourses.size());

        if (optionsCourses.isEmpty()) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed  : No options found in the courses dropdown.");
            throw new RuntimeException("No options found in the courses dropdown.");

        } else {
            System.out.println("Courses:");

            for (WebElement course : optionsCourses) {
                System.out.println(course.getText());
            }
            if (!optionsCourses.isEmpty()) {
                searchQuestionCourse = createQuestionPF.getSelectedCourse();
                System.out.println("Search by question course: " + searchQuestionCourse);
                TestRunner.getTest().log(Status.INFO, "Search by question course: " + searchQuestionCourse);

                for (WebElement course : optionsCourses) {
                    if (course.getText().equalsIgnoreCase(searchQuestionCourse)) {
                        course.click();
                        System.out.println("Selected course: " + searchQuestionCourse);
                        TestRunner.getTest().log(Status.INFO, "Selected course: " + searchQuestionCourse);
                        TestRunner.getTest().log(Status.PASS, "Test Case Passed  :Course Select successfully ");
                        break;
                    }
                }

            }
        }
    }

    public void applyQuestionStandardFilters() throws InterruptedException {
        List<String> selectedStandardsApplied = CreateQuestion_PF.selectedStandards;
        System.out.println("Selected Standards List Applied: " + selectedStandardsApplied);
        Thread.sleep(2000);

        boolean isTestFailing = false;

        try {
//            WebElement checkboxContainer = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class, 'scrollbarWrapper')]")));
            WebElement checkboxContainer = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(@class, 'scrollbarWrapper')])[1]")));
            List<WebElement> checkboxesStandards = checkboxContainer.findElements(By.xpath(".//span[@role='checkbox']"));
            System.out.println("Total Standards: " + checkboxesStandards.size());

            for (WebElement checkbox : checkboxesStandards) {
                helper.scrollToElement(driver, checkbox);
                Thread.sleep(200);

                WebElement checkboxLabel;
                try {
                    checkboxLabel = checkbox.findElement(By.xpath("./following-sibling::span[@class='rct-title']"));
                } catch (Exception e) {
                    System.out.println("Error finding checkbox label for element: " + checkbox.getAttribute("outerHTML"));
                    continue;
                }

                String standardText = checkboxLabel.getText();

                if (standardText.isEmpty()) {
                    System.out.println("Empty standard text found for checkbox.");
                    continue;
                }

                System.out.println("Standard name: " + standardText);

                if (selectedStandardsApplied.contains(standardText)) {
                    if (!checkbox.getAttribute("aria-checked").equals("true")) {
                        checkbox.click();
                        System.out.println("Checkbox with standard " + standardText + " selected.");
                        TestRunner.getTest().log(Status.INFO, "Checkbox with standard " + standardText + " selected.");
                    }
                }
                else {
                    if (checkbox.getAttribute("aria-checked").equals("true")) {
                        checkbox.click();
                        System.out.println("Checkbox with standard " + standardText + " unselected.");
                        TestRunner.getTest().log(Status.INFO, "Checkbox with standard " + standardText + " unselected.");
                    }
                }
            }

            for (String selectedStandard : selectedStandardsApplied) {
                boolean isStandardPresent = checkboxesStandards.stream()
                        .map(checkbox -> {
                            try {
                                WebElement label = checkbox.findElement(By.xpath("./following-sibling::span[@class='rct-title']"));
                                return label.getText();
                            } catch (Exception e) {
                                return "";
                            }
                        })
                        .anyMatch(standardText -> standardText.equals(selectedStandard));

                if (!isStandardPresent) {
                    System.out.println("FAIL: Selected standard " + selectedStandard + " was not found.");
                    TestRunner.getTest().log(Status.FAIL, "Selected standard " + selectedStandard + " was not found.");
                    isTestFailing = true;
                }
            }

        } catch (Exception e) {
            System.out.println("An error occurred while applying standard filters: " + e.getMessage());
            TestRunner.getTest().log(Status.FAIL, "Error applying standard filters: " + e.getMessage());
            isTestFailing = true;
        }

        if (isTestFailing) {
//            throw new AssertionError("Test case failed due to mismatched or missing standards.");
            TestRunner.getTest().log(Status.FAIL, "Test case failed due to mismatched or missing standards. " );

        }
    }

    public void QuestionCustomFilter() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Select Question Custom Filter");
        Thread.sleep(2000);
        WebElement filterContainer = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@aria-labelledby='Questions-header']")));

        WebElement btnMyQuestions = filterContainer.findElement(By.xpath("//button[@value = 'myQuestions']"));
        wait.until(ExpectedConditions.elementToBeClickable(btnMyQuestions));
        btnMyQuestions.click();
        Thread.sleep(2000);

        WebElement typeMyQuestions = driver.findElement(By.xpath("(//div[@aria-labelledby='Questions-header']//div[contains(@class, 'treeViewCheckbox') and contains(@class, 'false')])[2]"));
        List<WebElement> totalQuestionTypes = typeMyQuestions.findElements(By.tagName("li"));

        System.out.println("Total questions types are: " + totalQuestionTypes.size());
        TestRunner.getTest().log(Status.INFO, "Total questions types are: " + totalQuestionTypes.size());

        boolean typeFound = false;

        for (WebElement questionTypeName : totalQuestionTypes) {
            String typeNameText = questionTypeName.findElement(By.xpath(".//span[@class='text']")).getText();
            System.out.println("Type name is: " + typeNameText);

            selectedQuestionType = createQuestionPF.getSelectedQuestionType();
            System.out.println("Want to select question type: " + selectedQuestionType);
            TestRunner.getTest().log(Status.INFO, "Want to selected question type: " + selectedQuestionType);

            if (typeNameText.equals(selectedQuestionType)) {
                typeFound = true;
                System.out.println("I'm in to selecting checkbox");
                WebElement checkBox = questionTypeName.findElement(By.xpath(".//span[@role='checkbox']"));

                wait.until(ExpectedConditions.elementToBeClickable(checkBox));

                boolean isChecked = checkBox.isSelected();

                if (isChecked) {
                    System.out.println("Checkbox for " + selectedQuestionType + " is already selected.");
                    TestRunner.getTest().log(Status.INFO, "Checkbox for " + selectedQuestionType + " is already selected.");
                } else {
                    checkBox.click();
                    Thread.sleep(2000);
                    System.out.println("Checkbox for " + selectedQuestionType + " is now selected.");
                    TestRunner.getTest().log(Status.INFO, "Checkbox for " + selectedQuestionType + " is now selected.");
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed  : Custom filter checkbox selected successfully");
                }
                break;
            } else {
                System.out.println("No checkbox found for: " + selectedQuestionType);
                TestRunner.getTest().log(Status.INFO, "No checkbox found for: " + selectedQuestionType);
            }
        }

        if (!typeFound) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed  : Created" + selectedQuestionType + " question type not found");
//            throw new RuntimeException("No checkbox found for:" + selectedQuestionType);
        }

    }

    public void questionFilterApply() {
        TestRunner.getTest().log(Status.INFO, "I'm in Apply question Apply Filter");
        wait.until(ExpectedConditions.elementToBeClickable(btnApplyFilter));
        btnApplyFilter.click();
        TestRunner.getTest().log(Status.PASS, "Test Case Passed  : Custom question filter applied successfully");
    }

    public void filterQuestionsByStatus() throws InterruptedException {
        String[] statusArray = {"Active", "Editing", "Locked"};

        for (String status : statusArray) {
            TestRunner.getTest().log(Status.INFO, "Filtering Questions By Status: " + status);

            try {
                WebElement statusDropdown = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(@class, 'MuiSelect-select') and @role='button' or @role='combobox'])[3]")));
                statusDropdown.click();

                List<WebElement> statusOptions = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//ul[@role='listbox']//li")));
                boolean statusFound = false;

                for (WebElement option : statusOptions) {
                    String optionText = option.getText().trim();
                    if (optionText.equalsIgnoreCase(status)) {
                        option.click();
                        statusFound = true;
                        TestRunner.getTest().log(Status.INFO, "Selected Status: " + optionText);
                        break;
                    }
                }

                if (!statusFound) {
                    TestRunner.getTest().log(Status.FAIL, "Status not found in the dropdown: " + status);
                    throw new RuntimeException("Status not found in the dropdown: " + status);
                }

                Thread.sleep(2000);
                waitForTableToRefresh();

                if (isNoDataFoundDisplayed()) {
                    TestRunner.getTest().log(Status.INFO, "No questions found for the status: " + status);
                    System.out.println("No questions found for the status: " + status);
                    continue;
                }

                WebElement questionsTable = wait.until(ExpectedConditions.visibilityOf(questionsContainerTable));
                List<WebElement> questionRows = questionsTable.findElements(By.xpath(".//tr"));

                boolean allRowsMatchStatus = true;

                for (WebElement row : questionRows) {
                    WebElement statusCell = row.findElement(By.xpath(".//td[contains(@class, 'cell-5')]"));
                    String rowStatus = statusCell.getText().trim();

                    if (!rowStatus.equalsIgnoreCase(status)) {
                        allRowsMatchStatus = false;
                        System.out.println("Row status is: " + rowStatus);
                        TestRunner.getTest().log(Status.FAIL, "Question with mismatched status found: " + rowStatus);
                    } else {
                        TestRunner.getTest().log(Status.INFO, "Question row with status: " + rowStatus);
                    }
                }

                if (allRowsMatchStatus) {
                    TestRunner.getTest().log(Status.PASS, "All questions match the selected status: " + status);
                } else {
                    TestRunner.getTest().log(Status.FAIL, "Some questions do not match the selected status: " + status);
                }

            } catch (NoSuchElementException | ElementNotInteractableException e) {
                TestRunner.getTest().log(Status.WARNING, "Table not load in current time frame");
            }
        }
    }

    private boolean isNoDataFoundDisplayed() {
        try {
            WebElement noDataFound = driver.findElement(By.xpath("//div[contains(@class, 'QuestionDashboardContainer')]//div[contains(text(),'No Detail Found')]"));
            return noDataFound.isDisplayed();
        } catch (NoSuchElementException e) {
            return false;
        }
    }

    public void showsQuestionsIntoTable() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm in Show Questions Into table");
        Thread.sleep(5000);
        try {
            WebElement questionsTable = wait.until(ExpectedConditions.visibilityOf(questionsContainerTable));

            if (questionsTable != null) {
                List<WebElement> questionRows = questionsTable.findElements(By.xpath(".//tr"));

                if (!questionRows.isEmpty()) {
                    System.out.println("Questions found in the table:");
                    TestRunner.getTest().log(Status.INFO, "Questions found in the table:");
                    Thread.sleep(5000);

                    boolean allRowsProcessedSuccessfully = true;

                    for (int i = 0; i < questionRows.size(); i++) {
                        WebElement questionRow = questionRows.get(i);

                        int retryCount = 0;
                        boolean success = false;

                        while (retryCount < 6) {
                            try {
                                WebElement questionNameElement = questionRow.findElement(By.xpath(".//td[contains(@class, 'cell-0')]"));
                                questionName = questionNameElement.getText();
                                System.out.println("Question Name: " + questionName);
                                TestRunner.getTest().log(Status.INFO, "Question Name: " + questionName);

                                List<WebElement> questionNameCells = questionRow.findElements(By.xpath(".//td"));
                                for (WebElement questionNameCell : questionNameCells) {
                                    System.out.print(questionNameCell.getText() + "\t");
                                }
                                System.out.println();

                                success = true;
                                break;

                            } catch (StaleElementReferenceException e) {
                                System.out.println("Stale element found, retrying...");

                                questionRows = questionsTable.findElements(By.xpath(".//tbody//tr"));

                                if (i >= questionRows.size()) {
                                    System.out.println("Row index " + i + " is out of bounds after refresh.");
                                    break;
                                }

                                questionRow = questionRows.get(i);
                                retryCount++;
                            } catch (NoSuchElementException e) {
                                System.out.println("Element not found in the row: " + e.getMessage());
                                break;
                            }
                        }

                        if (!success) {
                            System.out.println("Failed to retrieve question row after several attempts.");
                            allRowsProcessedSuccessfully = false;
                        }
                    }

                    if (allRowsProcessedSuccessfully) {
                        TestRunner.getTest().log(Status.PASS, "Test Case Passed  : Question Shows Into Table Successfully");
                    } else {
                        TestRunner.getTest().log(Status.FAIL, "Test Case Failed  : One or more questions could not be processed.");
                    }
                } else {
                    TestRunner.getTest().log(Status.FAIL, "Test Case Failed  : No questions found in the table.");
                    throw new RuntimeException("No questions found in the table");
                }
            } else {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Questions table is not visible.");
                throw new RuntimeException("Questions table is not visible");

            }
        } catch (TimeoutException e) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Timeout waiting for table to be visible or accessible. " + e.getMessage());
        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: An unexpected error occurred. " + e.getMessage());
        }
    }

    public void searchQuestionByName(){
        TestRunner.getTest().log(Status.INFO, "Search Question By Name");
        WebElement right_panel= wait.until(ExpectedConditions.elementToBeClickable(questionsContainerRightPanel));
        right_panel.isDisplayed();

        try {
            WebElement questionSearchBox = right_panel.findElement(By.xpath("//input[@placeholder='Search Questions']"));
            if (questionSearchBox.isDisplayed() && questionSearchBox.isEnabled()) {
                questionSearchBox.click();
                questionSearchBox.clear();
                ((JavascriptExecutor) driver).executeScript("arguments[0].value='';", questionSearchBox);
                searchQuestionByName = createQuestionPF.getQuestionTitle();
                System.out.println("Search by question name: " + searchQuestionByName);
                TestRunner.getTest().log(Status.INFO, "Search by question name: " + searchQuestionByName);
                questionSearchBox.sendKeys(searchQuestionByName);

                Actions actions = new Actions(driver);
                actions.sendKeys(Keys.ENTER).perform();

                waitForTableToRefresh();
                TestRunner.getTest().log(Status.PASS, "Test Case Passed  : Search question Successfully");
            } else {
                System.out.println("Search box is not displayed.");
            }
        } catch (Exception e) {
            System.out.println("Search box is not available: " + e.getMessage());
        }
    }

    private void waitForTableToRefresh() throws InterruptedException{
        try {
            WebElement questionsTable = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class, 'QuestionDashboardContainer')]//tbody")));

            List<WebElement> rowsBeforeRefresh = questionsTable.findElements(By.xpath(".//tr"));
            System.out.println("Number of rows before refresh: " + rowsBeforeRefresh.size());

            Thread.sleep(2000);

            List<WebElement> rowsAfterRefresh = questionsTable.findElements(By.xpath(".//tr"));
            System.out.println("Number of rows after refresh: " + rowsAfterRefresh.size());

            if (rowsBeforeRefresh.size() != rowsAfterRefresh.size()) {
                System.out.println("Table has refreshed. Number of rows before refresh: " + rowsBeforeRefresh.size() + ", after refresh: " + rowsAfterRefresh.size());
                TestRunner.getTest().log(Status.INFO, "Table has refreshed. Number of rows before refresh: " + rowsBeforeRefresh.size() + ", after refresh: " + rowsAfterRefresh.size());
            } else {
                System.out.println("Table did not refresh as expected. Rows before: " + rowsBeforeRefresh.size() + ", Rows after: " + rowsAfterRefresh.size());
            }

            for (WebElement row : rowsAfterRefresh) {
                System.out.println("Table Row: " + row.getText());
            }

        } catch (NoSuchElementException | TimeoutException e) {
            try {
                WebElement noDataFound = driver.findElement(By.xpath("//div[contains(@class, 'QuestionDashboardContainer')]//div[contains(text(),'No Detail Found')]"));
                String statusHaveNoData = noDataFound.getText();
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: 'No Detail Found' message is displayed as expected. " + statusHaveNoData);
                System.out.println("Test Case Passed: 'No Detail Found' message is displayed. " + statusHaveNoData);
            } catch (NoSuchElementException nestedException) {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Neither table data nor 'No Detail Found' message found.");
                System.out.println("Test Case Failed: Neither table data nor 'No Detail Found' message found.");
            }
        }
    }

//    private void waitForTableToRefresh() {
//        try {
//            wait.until(ExpectedConditions.elementToBeClickable(questionsContainerTable));
//
//            List<WebElement> rowsBeforeRefresh = driver.findElements(By.xpath("//div[contains(@class, 'QuestionDashboardContainer')]//tbody//tr"));
//
//            Thread.sleep(2000);
//
//            List<WebElement> rowsAfterRefresh = driver.findElements(By.xpath("//div[contains(@class, 'QuestionDashboardContainer')]//tbody//tr"));
//
//            if (rowsBeforeRefresh.size() != rowsAfterRefresh.size()) {
//                System.out.println("Table has refreshed. Number of rows before refresh: " + rowsBeforeRefresh.size() + ", after refresh: " + rowsAfterRefresh.size());
//                TestRunner.getTest().log(Status.INFO, "Table has refreshed. Number of rows before refresh: " + rowsBeforeRefresh.size() + ", after refresh: " + rowsAfterRefresh.size());
//            } else {
//                System.out.println("Table did not refresh as expected.");
//            }
//
//            for (WebElement row : rowsAfterRefresh) {
//                System.out.println("Table Row: " + row.getText());
//            }
//
//        } catch (Exception e) {
//            System.out.println("Error while waiting for table refresh: " + e.getMessage());
//        }
//    }

    public void verifySearchedQuestionByNameIntoTable(){
        if (questionName.contains(searchQuestionByName)){
            TestRunner.getTest().log(Status.INFO, "Search by question name into table: " + searchQuestionByName);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed  : Searched question found Successfully");
        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed  : Searched question not found and search filter not working");
        }
    }


}
