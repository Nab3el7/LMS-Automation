package pageFactory.MyContent;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;
import java.util.Random;

public class AssignAssessment_PF {

    WebDriverWait wait;
    WebDriver driver;
    Helper helper;
    public static String startDateTime;
    public static String endDateTime;
    public static String lateDateTime;

    public static String CategoryFromAssignment;

    @FindBy(xpath = "//div[contains(@class, 'AssessmentDashboardRightPanel')]")
    WebElement panel_AssessmentDashboard;

    @FindBy(xpath = "//input[@name='title']")
    WebElement edt_AssignmentTitle;

    @FindBy(xpath = "//label[contains(text(),'Assign to')]/parent::div")
    WebElement dropDown_AssignTo;

    @FindBy(xpath = "//input[@name='isOpenToAnyStudent']")
    WebElement input_OpenToAnyStudent;

    @FindBy(xpath = "//label[contains(text(),'Select Students')]/following-sibling::div")
    WebElement dropDown_SelectStudent;

    @FindBy(xpath = "//label[contains(text(),'Start Date & Time')]/following-sibling::div//input")
    WebElement calendar_StartDateTime;

    @FindBy(xpath = "//label[contains(text(),'End Date & Time')]/following-sibling::div//input")
    WebElement calendar_EndDateTime;

    @FindBy(xpath = "//input[@name='isLateSubmission']")
    WebElement checkBox_AllowLateSubmission;

    @FindBy(xpath = "//label[contains(text(),'Late Sub. Date & Time')]/following-sibling::div//input")
    WebElement calendar_LateSubDateTime;

    @FindBy(xpath = "//label[contains(text(),'Category')]/following-sibling::div")
    WebElement dropDown_Category;

    @FindBy(xpath = "(//div[@id='panel2bh-header'])[1]")
    WebElement panel_AdditionalSettings;

    @FindBy(xpath = "(//div[@id='panel2bh-content'])[1]")
    WebElement panel_AdditionalSettingsContent;

    @FindBy(xpath = "//input[@name='isRandomizeAnswers']")
    WebElement checkBox_RandomizeAnswer;

    @FindBy(xpath = "//input[@name='displayFuture']")
    WebElement checkBox_DisplayFutureStatus;

    @FindBy(xpath = "//input[@name='isDisplayGrades']")
    WebElement checkBox_DisplayGrades;

    @FindBy(xpath = "//div[@id='panel2bh-content']//div[@id='demo-simple-select']")
    WebElement dropDown_ReviewOptions;

    @FindBy(xpath = "//textarea[@id='outlined-multiline-flexible']")
    WebElement txtArea_AdditionalInstructions;

    @FindBy(xpath = "(//div[@id='panel2bh-header'])[2]")
    WebElement panel_ScoringOptions;

    @FindBy(xpath = "(//div[@id='panel2bh-content'])[2]")
    WebElement panel_ScoringOptionsContent;

    @FindBy(xpath = "//div[contains(@class, 'MetaDataWrapper')]")
    WebElement container_FinalizeQuestion;

    @FindBy(xpath = "//button[@name='btn-assign-assignment']")
    WebElement btn_AssignAssignment;

    @FindBy(xpath = "(//h2[contains(@class, 'MuiDialogTitle-root')])[2]")
    WebElement alert_success;

    public AssignAssessment_PF(WebDriver driver){
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        helper = new Helper();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
    }

    public void ClickOnAssignButton() throws InterruptedException {
        Thread.sleep(1000);
        panel_AssessmentDashboard.isDisplayed();

        WebElement btn_Assign = panel_AssessmentDashboard.findElement(By.xpath("(//button[normalize-space() = 'Assign'])[1]"));

        if (btn_Assign.isDisplayed() && btn_Assign.isEnabled()) {
            btn_Assign.click();
            System.out.println("Clicked on Assign button.");
            Thread.sleep(1000);

        } else {
            System.out.println("Assign button is not displayed or clickable.");
        }
    }

    public void ProcessAssignAssessments() throws InterruptedException{
        Thread.sleep(1000);
        panel_AssessmentDashboard.isDisplayed();

        List<WebElement> totalAssignments = panel_AssessmentDashboard.findElements(By.xpath("//button[normalize-space() = 'Assign']"));
        System.out.println("Total number on assessments: " + totalAssignments.size());

        for (WebElement assignment : totalAssignments) {
            processAssignment(assignment);
            break;
        }
    }

    private void processAssignment(WebElement assignment) throws InterruptedException {
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", assignment);
        System.out.println("Clicked on 'Assign' button: ");

        enterAssignmentDetails();
        selectAssignToAndStudentOptions();
        setDateTimeAndCategory();
        enterAdditionalSettings();
        enterWeightPercentage();
        assignAssignment();
        verifyDialogBox();
    }

    private void enterAssignmentDetails() throws InterruptedException {
        Thread.sleep(1000);
        EnterAssignmentTitle();
    }

    private void EnterAssignmentTitle(){
        edt_AssignmentTitle.click();
        ((JavascriptExecutor) driver).executeScript("arguments[0].value='';", edt_AssignmentTitle);
        String AssignmentTitle = generateAssignmentTitle("Automated Generated Assignment :: NAB - ");
        edt_AssignmentTitle.sendKeys(AssignmentTitle);
    }

    private void selectAssignToAndStudentOptions() throws InterruptedException {
        Thread.sleep(1000);
        select_AssignTo();
        Thread.sleep(1000);
        OpenToAnyStudentToggle();
        Thread.sleep(1000);
        select_Student();
    }

    private void select_AssignTo() throws InterruptedException{
        dropDown_AssignTo.click();
        List<WebElement> AssignToOptions = dropDown_AssignTo.findElements(By.xpath("//ul[@role='listbox']"));
        helper.selectValueFromDropdown(AssignToOptions);
        // Simulate pressing the ESC key
        Actions actions = new Actions(driver);
        actions.sendKeys(Keys.ESCAPE).build().perform();
    }

    private void OpenToAnyStudentToggle() {
        input_OpenToAnyStudent.click();
    }

    private void select_Student() throws InterruptedException{
        dropDown_SelectStudent.click();
        Thread.sleep(1000);
        List<WebElement> SelectStudentOptions = dropDown_SelectStudent.findElements(By.xpath("//ul[@role='listbox']//input"));

        if (SelectStudentOptions.isEmpty()) {
            System.out.println("No students found in the selected class. Changing class in AssignTo dropdown.");
            select_AssignTo();
        } else {
            helper.selectValueFromDropdown(SelectStudentOptions);
            // Pressing the ESC key
            Actions actions = new Actions(driver);
            actions.sendKeys(Keys.ESCAPE).build().perform();
        }
    }

    public void setDateTimeAndCategory() throws InterruptedException {
        Thread.sleep(1000);
        setDateTime();
        Thread.sleep(1000);
        select_category();
    }

    private void setDateTime() throws InterruptedException{
        WebElement girdDate = driver.findElement(By.xpath("//div[contains(@class, 'AssignmentReleaseSection')]"));
        girdDate.isDisplayed();

//        Set Start Date Time
        startDateTime = helper.generateStartDateTime();
        System.out.println("Generated Start DateTime: " + startDateTime);
        TestRunner.getTest().log(Status.INFO, "Set assignment start datetime: " + startDateTime);
        setDateTimeValueByJS(girdDate, "//label[contains(text(),'Start Date & Time')]/following-sibling::div//input", startDateTime);

//        Set End Date Time
        endDateTime = helper.generateEndDateTime(startDateTime);
        System.out.println("Generated End DateTime: " + endDateTime);
        TestRunner.getTest().log(Status.INFO, "Set assignment end datetime: " + endDateTime);
        setDateTimeValueByJS(girdDate, "//label[contains(text(),'End Date & Time')]/following-sibling::div//input", endDateTime);

//        Enable Late Submission Checkbox
        Thread.sleep(2000);
        WebElement checkBoxLateSub = girdDate.findElement(By.xpath("//input[@name='isLateSubmission']"));
        checkBoxLateSub.click();

//        Set Late Submission Date Time
        lateDateTime = helper.generateLateSubDateTime(endDateTime);
        System.out.println("Generated Late Sub DateTime: " + lateDateTime);
        TestRunner.getTest().log(Status.INFO, "Set assignment late submission datetime: " + lateDateTime);
        setDateTimeValueByJS(girdDate, "//label[contains(text(),'Late Sub. Date & Time')]/following-sibling::div//input", lateDateTime);
    }

    private void setDateTimeValueByJS(WebElement parentElement, String xpath, String value) {
        WebElement element = parentElement.findElement(By.xpath(xpath));
        JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
        jsExecutor.executeScript("arguments[0].value = arguments[1];", element, value);
    }

    public void select_category() throws InterruptedException{
        dropDown_Category.click();
        List<WebElement> AssignmentCategoryOptions = dropDown_Category.findElements(By.xpath("//ul[@role='listbox']/li"));
        TestRunner.getTest().log(Status.INFO, "Total categories: " + AssignmentCategoryOptions.size());
        CategoryFromAssignment = helper.selectValueFromDropdown(AssignmentCategoryOptions);
        System.out.println("Selected Category: " + CategoryFromAssignment);
        TestRunner.getTest().log(Status.PASS, "Category Selected: " + CategoryFromAssignment);
    }

    public void enterAdditionalSettings() throws InterruptedException {
        Thread.sleep(1000);
        select_ShowAdditionalSettings();
        checkBox_RandomizeAnswerChoices();
        checkBox_DisplayGradesToStudent();
        dropDown_ReviewOptions();
        txtArea_AdditionalInstructions();
    }

    public void enterAdditionalSettingsWithFutureStatus() throws InterruptedException {
        Thread.sleep(1000);
        select_ShowAdditionalSettings();
        checkBox_RandomizeAnswerChoices();
        checkBox_DisplayFutureStatusToStudent();
        checkBox_DisplayGradesToStudent();
        dropDown_ReviewOptions();
        txtArea_AdditionalInstructions();
    }

    public void select_ShowAdditionalSettings(){
        panel_AdditionalSettings.click();
        System.out.println("Click on Additional Settings");
        wait.until(ExpectedConditions.visibilityOf(panel_AdditionalSettingsContent));
    }

    public void checkBox_DisplayFutureStatusToStudent() {
        if (checkBox_DisplayFutureStatus.isEnabled()) {
            if (!checkBox_DisplayFutureStatus.isSelected()) {
                checkBox_DisplayFutureStatus.click();
                System.out.println("Click on DisplayFutureStatus Option");
                TestRunner.getTest().log(Status.PASS, "Selected DisplayFutureStatus Option");
            }
        } else {
            System.out.println("DisplayFutureStatus Option is already selected");
            TestRunner.getTest().log(Status.INFO, "Checkbox DisplayFutureStatus is already selected");
        }
    }

    public void checkBox_RandomizeAnswerChoices() {
        if (checkBox_RandomizeAnswer.isEnabled()) {
            if (!checkBox_RandomizeAnswer.isSelected()) {
                checkBox_RandomizeAnswer.click();
                System.out.println("Click on Random Answer Option");
                TestRunner.getTest().log(Status.PASS, "Selected Random Answer Option");
            }
        } else {
            System.out.println("Random Answer Option is already selected");
            TestRunner.getTest().log(Status.INFO, "Checkbox RandomizeAnswer is already selected");
        }
    }

    public void checkBox_DisplayGradesToStudent(){
        if (checkBox_DisplayGrades.isEnabled()) {
            if (!checkBox_DisplayGrades.isSelected()) {
                checkBox_DisplayGrades.click();
                System.out.println("Click on Display Grade Option");
                TestRunner.getTest().log(Status.PASS, "Selected Display Grade Option");
            }
        } else {
            System.out.println("Display Grade Option is already selected");
            TestRunner.getTest().log(Status.INFO, "Checkbox DisplayGrades is already selected");
        }
    }

    public void dropDown_ReviewOptions() {
        dropDown_ReviewOptions.click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[@role='listbox']")));
        WebElement listbox = driver.findElement(By.xpath("//ul[@role='listbox']"));
        List<WebElement> reviewOptions = listbox.findElements(By.tagName("li"));
        System.out.println("Total Review Options: " + reviewOptions.size());
        TestRunner.getTest().log(Status.INFO, "Total review options: " + reviewOptions.size());

        for (WebElement option : reviewOptions) {
            if (option.getText().contains("Review Graded Submission")) {
                System.out.println("Selected Review Option: " + option.getText());
                TestRunner.getTest().log(Status.PASS, "Selected Review Option: " + option.getText());
                option.click();
                break;
            }
        }
    }


    public void txtArea_AdditionalInstructions(){
        wait.until(ExpectedConditions.elementToBeClickable(txtArea_AdditionalInstructions));
        JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
        jsExecutor.executeScript("arguments[0].click();", txtArea_AdditionalInstructions);
//        txtArea_AdditionalInstructions.click();
        ((JavascriptExecutor) driver).executeScript("arguments[0].value='';", txtArea_AdditionalInstructions);
        String AdditionalInstructions = helper.generateRandomText("Instructions-NAB ");
        txtArea_AdditionalInstructions.sendKeys(AdditionalInstructions);
        System.out.println("Additional Instructions: " + AdditionalInstructions);
        TestRunner.getTest().log(Status.PASS, "Additional instructions: " + AdditionalInstructions);
    }

    public void enterWeightPercentage() throws InterruptedException{
        Thread.sleep(1000);
        select_ShowScoringOptions();
        wait.until(ExpectedConditions.visibilityOf(panel_ScoringOptionsContent));
        System.out.println("Click on Scoring Option");
        TestRunner.getTest().log(Status.INFO, "Selected Scoring Option");

        Thread.sleep(1000);
        container_FinalizeQuestion.isDisplayed();
        WebElement wrapperTable = container_FinalizeQuestion.findElement(By.xpath("//div[contains(@class, 'MetaDataWrapper')]//table"));

        List<WebElement> rows = wrapperTable.findElements(By.tagName("tr"));

        for (int i = 1; i < rows.size(); i++) {
            WebElement row = rows.get(i);
            List<WebElement> cells = row.findElements(By.tagName("td"));

            WebElement weightInput = cells.get(1).findElement(By.tagName("input"));
            WebElement percentageInput = cells.get(2).findElement(By.tagName("input"));

            if (weightInput.isEnabled() && percentageInput.isEnabled()) {
                weightInput.clear();
                percentageInput.clear();
//                Clear with JS
                clearInputWithJs(driver, weightInput);
                clearInputWithJs(driver, percentageInput);

                Random random = new Random();
                int randomWeight = random.nextInt(10) + 1;
                int randomPercentage = random.nextInt(100);

                weightInput.sendKeys(String.valueOf(randomWeight));
                percentageInput.sendKeys(String.valueOf(randomPercentage));
                System.out.println("Set weight " + randomWeight + " Set percentage " + randomPercentage);
                TestRunner.getTest().log(Status.PASS, "Set weight to " + randomWeight + " Set percentage to " + randomPercentage);
            }
        }
    }

    private void select_ShowScoringOptions(){
        panel_ScoringOptions.click();
    }

    private void clearInputWithJs(WebDriver driver, WebElement element) {
        JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
        jsExecutor.executeScript("arguments[0].value = '';", element);
    }

    public void assignAssignment() throws InterruptedException {
        wait.until(ExpectedConditions.elementToBeClickable(btn_AssignAssignment));
        if (btn_AssignAssignment.isEnabled() && btn_AssignAssignment.isDisplayed()) {
            btn_AssignAssignment.click();
            System.out.println("Assign New Assignment");
            TestRunner.getTest().log(Status.PASS, "Assign new Assignment");
            Thread.sleep(3000);
        } else {
            System.out.println("Assign button is not enabled and not assign the assignment");
            TestRunner.getTest().log(Status.INFO, "Assign button is not enabled and not assign the assignment");
        }
    }

    public void verifyDialogBox() throws InterruptedException {
        try {
            wait.until(ExpectedConditions.visibilityOf(alert_success));
            TestRunner.getTest().log(Status.INFO, "Waiting for success alert to be visible");

            WebElement popover = driver.findElement(By.xpath("(//h2[contains(@class, 'MuiDialogTitle-root')])[2]"));
            String headerMessage = popover.getText();
            System.out.println(headerMessage);
            TestRunner.getTest().log(Status.INFO, "Dialog header message: " + headerMessage);

            if (!headerMessage.equals("Assignment Successful !")) {
                TestRunner.getTest().log(Status.FAIL, "Assertion failed: Expected header message to be 'Assignment Successful !', but found '" + headerMessage + "'");
                throw new AssertionError("Header message not as expected: " + headerMessage);
            }

            TestRunner.getTest().log(Status.PASS, "Header message verified as: " + headerMessage);

            WebElement closeButton = popover.findElement(By.xpath(".//button[@aria-label='close']"));
            closeButton.click();
            TestRunner.getTest().log(Status.PASS, "Clicked on the close button");

            Thread.sleep(1000);
            TestRunner.getTest().log(Status.INFO, "Waited for dialog box to close");
        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "An error occurred while verifying the dialog box: " + e.getMessage());
            throw new RuntimeException("Assignment not released. " + e.getMessage());
        }
    }

    private String generateAssignmentTitle(String prefix) {
        String characters = "ABC123456789";
        StringBuilder randomTitle = new StringBuilder();
        Random random = new Random();
        int length = 4;
        randomTitle.append(prefix);
        for (int i = 0; i < length; i++) {
            randomTitle.append(characters.charAt(random.nextInt(characters.length())));
        }
        return randomTitle.toString();
    }
}
