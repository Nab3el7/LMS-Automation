package pageFactory.MyContent.Resources;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;
import java.util.Random;

import static org.openqa.selenium.By.tagName;

public class CopyResourceURL_PF {
    public WebDriverWait wait;
    WebDriver driver;
    Helper helper;


    @FindBy(xpath = "//input[@name='title']")
    WebElement ResourceTitle;
    @FindBy(xpath = "//div[@aria-labelledby='customized-dialog-title']")
    WebElement copyDialogTitle;

    @FindBy(xpath = "(//button[normalize-space()='Save'])[1]")
    WebElement save_edit_resource;

    @FindBy(xpath = "//div[@aria-label='Content Module']")
    WebElement link_MyContent;

    public static String NewCopyTitleUpdated;
    public static String titleForCopyRandomResource;

    public CopyResourceURL_PF(WebDriver driver) {
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
        helper = new Helper();
    }

    public void clickCopyButton() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "Click On Copy Button");

        Thread.sleep(2000);

        WebElement editDots= driver.findElement(By.xpath("//button[@aria-label='DropDownButtom']"));
        editDots.click();
        Thread.sleep(2000);

        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//ul[@role='menu']//li")));

        WebElement edit_btn= driver.findElement(By.xpath(".//span[normalize-space()='Copy']"));
        edit_btn.click();

        TestRunner.getTest().log(Status.PASS, "Test Case Passed : Copy button found and click successfully");

    }
    public void CopyResourceModalBox() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into Add title for Copy Resource");
        System.out.println("I'm into Add title for Copy Resource");

        // Wait for the promptCopyResource element to be clickable
        WebElement promptCopyResource = wait.until(ExpectedConditions.elementToBeClickable(copyDialogTitle));

        // Check if the element is displayed and enabled before interacting
        if (promptCopyResource.isDisplayed() && promptCopyResource.isEnabled()) {
            // Wait for the input field (TitleForCopyResource) to be visible
            WebElement TitleForCopyResource = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[contains(@value, 'Copy of')]")));

            // Check if the element is clickable
            if (TitleForCopyResource.isEnabled()) {
                TitleForCopyResource.click();

                Random random = new Random();
                int randomNumber = random.nextInt(1000);
                titleForCopyRandomResource = "Automated Copy Resource " + randomNumber;

                System.out.println("Generated Title: " + titleForCopyRandomResource);
                TitleForCopyResource.sendKeys(titleForCopyRandomResource);

                // Wait for the 'Save' button to be clickable before clicking it
                WebElement btnSaveYes = wait.until(ExpectedConditions.elementToBeClickable(promptCopyResource.findElement(By.xpath(".//button[normalize-space()='Save']"))));

                // Check if the 'Save' button is enabled
                if (btnSaveYes.isEnabled()) {
                    btnSaveYes.click();
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed: Copy Resource successfully");
                }
            } else {
                TestRunner.getTest().log(Status.FAIL, "Title field is not clickable");
            }
        } else {
            TestRunner.getTest().log(Status.FAIL, "Copy Resource prompt is not displayed or enabled");
        }
    }

    public void copyResourceInfo() throws InterruptedException{
        Thread.sleep(2000);
        System.out.println("I'm in Copy Resource Information Screen");
        TestRunner.getTest().log(Status.INFO, "I'm in Copy Resource Information Screen");

        wait.until(ExpectedConditions.elementToBeClickable(ResourceTitle));

        String existingResourceTitle = ResourceTitle.getAttribute("value");
        System.out.println("Existing Resource Title: " + existingResourceTitle);
        TestRunner.getTest().log(Status.INFO, "Existing Resource Title: " + existingResourceTitle);
        Actions actions = new Actions(driver);

        ResourceTitle.click();

        for (int i = 0; i < existingResourceTitle.length(); i++) {
            actions.sendKeys(Keys.BACK_SPACE).perform();
        }

        ((JavascriptExecutor) driver).executeScript("arguments[0].value='';", ResourceTitle);

        NewCopyTitleUpdated = generateStudentInfo("CopyResourceUrl-");

        ResourceTitle.sendKeys(NewCopyTitleUpdated);

        String updatedTitleURL = ResourceTitle.getAttribute("value");
        System.out.println("Updated Resource Title: " + updatedTitleURL);
        TestRunner.getTest().log(Status.INFO, "Updated Resource Title: " + updatedTitleURL);

        if (!existingResourceTitle.equals(updatedTitleURL)) {
            TestRunner.getTest().log(Status.PASS, "Test Case Passed : The Resource Title was successfully updated.");
        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed  : The Resource Title was not changed");
            throw new RuntimeException("The Resource Title was not changed");

        }

    }

    public void searchResourceByUpdatedCopyTitle() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "Search Resource By Updated Copy Title");
        WebElement right_panel= driver.findElement(By.xpath("//div[contains(@class, 'right-panel')]"));
        right_panel.isDisplayed();

        try {
            WebElement searchBox = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder='Search Resources']")));
            if (searchBox.isDisplayed()) {
                searchBox.click();
                searchBox.clear();
                ((JavascriptExecutor) driver).executeScript("arguments[0].value='';", searchBox);
                Thread.sleep(1000);
                System.out.println("Search by Resource By Updated Title: " + NewCopyTitleUpdated);
                TestRunner.getTest().log(Status.INFO, "Search by Resource By Updated Copy Title: " + NewCopyTitleUpdated);
                searchBox.sendKeys(NewCopyTitleUpdated);

                Actions actions = new Actions(driver);
                actions.sendKeys(Keys.ENTER).perform();

                waitForTableToRefreshAfterSearch();
                TestRunner.getTest().log(Status.PASS, "Test Case Passed : Search box display and search and table refresh Successfully");

            } else {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed  : Search box is not displayed.");
            }
        } catch (Exception e) {
            System.out.println("Search box is not available: " + e.getMessage());
        }
    }

    private void waitForTableToRefreshAfterSearch() throws InterruptedException {
        Thread.sleep(2000);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class, 'right-panel')]//tbody")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class, 'right-panel')]//tbody//tr")));

        System.out.println("Table has refreshed.");
        TestRunner.getTest().log(Status.INFO, "Table has refreshed.");
    }

    public void verifyUpdatedResourceCopyTitle() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "Verify Updated Resource  Copy Title in Table.");
        List<WebElement> rows = driver.findElements(By.xpath("//table[contains(@class,'MuiTable-root')]//tbody//tr"));

        boolean newTitleFound = false;
        for (WebElement row : rows) {
            String titleText = row.findElement(By.xpath(".//td[1]//div")).getText().trim();

            if (titleText.equals(NewCopyTitleUpdated)) {
                newTitleFound = true;
                break;
            }
        }

        if (newTitleFound) {
            System.out.println("The Resource Title has been updated to: " + NewCopyTitleUpdated);
            TestRunner.getTest().log(Status.INFO, "The Resource Title has been updated to:" + NewCopyTitleUpdated);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed : The Resource Title has been updated in table Successfully");
        } else {
            System.out.println("The Resource Title has not been updated or not found.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed  : The Resource Title has not been updated or not found");
            throw new RuntimeException("The Resource Title has not been updated or not found");
        }

    }

    public void clickOnSave()throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "Click on Save Button.");
        Thread.sleep(2000);
         if (save_edit_resource.isDisplayed()){
             save_edit_resource.click();
             TestRunner.getTest().log(Status.PASS, "Test Case Passed : Resource Successfully Updated");
         }else {
             TestRunner.getTest().log(Status.FAIL, "Test Case Failed  : Resource not Updated.");
         }

         Thread.sleep(2000);

        WebElement navBar = driver.findElement(By.xpath("//div[@class='navigation']"));

        List<WebElement> totalLinks = navBar.findElements(tagName("a"));

        for (WebElement link : totalLinks) {
            String hrefValue = link.getAttribute("href");
            System.out.println("Link is: " + hrefValue);

            if (hrefValue.contains("/content")) {
                link.click();
                TestRunner.getTest().log(Status.PASS, "Testcase Passed   :  Side navbar shows and clicked on My Content");
                break;
            }
        }
    }


    public String generateStudentInfo(String prefix) {
        String characters = "abcdefghijklmnopqrstuvwxyz";
        StringBuilder randomTitle = new StringBuilder();
        Random random = new Random();
        int length = 4;
        randomTitle.append(prefix);
        for (int i = 0; i < length; i++) {
            randomTitle.append(characters.charAt(random.nextInt(characters.length())));
        }
        return randomTitle.toString();
    }
}
