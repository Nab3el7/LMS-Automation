package pageFactory.MyContent.Resources;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class ResourceNegativeTests {

    WebDriverWait wait;
    WebDriver driver;
    Helper helper;

    ResourceTypeURL_PF resourcePage;

    public ResourceNegativeTests(WebDriver driver) {
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        resourcePage = new ResourceTypeURL_PF(driver);
    }

    public void testEmptyResourceTitle() throws InterruptedException {
        resourcePage.click_Resources();
        resourcePage.click_Add_new_btn();
        resourcePage.resource_Information();

        resourcePage.resource_title.clear();
        resourcePage.click_save();

        WebElement errorMessage = driver.findElement(By.xpath("//span[contains(text(),'Title is required')]"));
        Assert.assertTrue("Error message not displayed for empty title", errorMessage.isDisplayed());
    }

    public void testInvalidUrlFormat() throws InterruptedException {
        resourcePage.click_Resources();
        resourcePage.click_Add_new_btn();
        resourcePage.resource_Information();

        resourcePage.Resource_URL.clear();
        resourcePage.Resource_URL.sendKeys("invalid-url");

        resourcePage.click_save();

        WebElement errorMessage = driver.findElement(By.xpath("//span[contains(text(),'Please enter a valid URL')]"));
        Assert.assertTrue("Error message not displayed for invalid URL", errorMessage.isDisplayed());
    }

    public void testNoCourseSelected() throws InterruptedException {
        resourcePage.click_Resources();
        resourcePage.click_Add_new_btn();
        resourcePage.resource_Information();

        resourcePage.dropDown_SelectCourse.click();
        resourcePage.click_save();

        WebElement errorMessage = driver.findElement(By.xpath("//span[contains(text(),'Please select a course')]"));
        Assert.assertTrue("Error message not displayed for no course selected", errorMessage.isDisplayed());
    }

    public void testNoResourceTypeSelected() throws InterruptedException {
        resourcePage.click_Resources();
        resourcePage.click_Add_new_btn();
        resourcePage.resource_Information();

        resourcePage.resource_type_dropdown.click();
        resourcePage.click_save();

        WebElement errorMessage = driver.findElement(By.xpath("//span[contains(text(),'Resource type is required')]"));
        Assert.assertTrue("Error message not displayed for no resource type selected", errorMessage.isDisplayed());
    }

    public void testNoFileUploadedForDocumentOrImage() throws InterruptedException {
        resourcePage.click_Resources();
        resourcePage.click_Add_new_btn();
        resourcePage.resource_Information();

        resourcePage.resource_type_dropdown.click();
        resourcePage.selectResourceForNegative();

        resourcePage.click_save();

        WebElement errorMessage = driver.findElement(By.xpath("//span[contains(text(),'Please upload a file')]"));
        Assert.assertTrue("Error message not displayed for no file uploaded", errorMessage.isDisplayed());
    }
}
