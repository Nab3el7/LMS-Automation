package pageFactory.MyContent.Resources;

import StepDefinitions.Configurations;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.*;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Assignmment.CorrectAnswerExecutor_PF;
import pageFactory.Assignmment.ReleaseAssignment_PF;
import pageFactory.MyContent.AssignAssessment_PF;
import pageFactory.MyContent.CreateAssessment_PF;

import java.time.Duration;
import java.util.List;

import static pageFactory.MyContent.Resources.ResourceTypeURL_PF.NewResourceName;

public class AssignResource_PF {
    WebDriverWait wait;
    WebDriver driver;

    CreateAssessment_PF createAssessmentPF;
    ReleaseAssignment_PF releaseAssignment_PF;
    CorrectAnswerExecutor_PF correctAnswerExecutor_PF;
    AssignAssessment_PF assignAssessment_PF;

    // Constructor
    public AssignResource_PF(WebDriver driver) {
        this.driver = Configurations.getDriver();
        PageFactory.initElements(this.driver, this);
        wait = new WebDriverWait(this.driver, Duration.ofSeconds(10));
        createAssessmentPF = new CreateAssessment_PF(driver);
        releaseAssignment_PF = new ReleaseAssignment_PF(driver);
        correctAnswerExecutor_PF = new CorrectAnswerExecutor_PF(driver);
        assignAssessment_PF = new AssignAssessment_PF(driver);
    }

    public void ClickOnAssignAndProcessToAssignResource() {
        try {
            System.out.println("Waiting for resource dashboard to load...");
            TestRunner.getTest().log(Status.INFO, "Waiting for resource dashboard to load...");

            WebElement resourceDashboard = wait.until(ExpectedConditions.visibilityOfElementLocated(
                    By.xpath("//div[contains(@class,'ResourceDashboardContainer')]//tbody")));

            List<WebElement> totalSearchResources = resourceDashboard.findElements(By.xpath(".//tr"));
            System.out.println("Total Searched Resources: " + totalSearchResources.size());
            TestRunner.getTest().log(Status.INFO, "Total Searched Resources: " + totalSearchResources.size());

            String wantToSearchResource = NewResourceName.get();
            System.out.println("Want to search resource: " + wantToSearchResource);
            TestRunner.getTest().log(Status.INFO, "Want to search resource: " + wantToSearchResource);


            boolean found = false;

            for (WebElement searchResource : totalSearchResources) {
                ResourceTableInReadAble();

                WebElement nameElement = searchResource.findElement(By.xpath(".//td[1]//div"));
                String searchedResourceName = nameElement.getText().trim();

                System.out.println("Checking Resource: " + searchedResourceName);
                TestRunner.getTest().log(Status.INFO, "Checking Resource: " + searchedResourceName);

                if (searchedResourceName.equals(wantToSearchResource)) {
                    System.out.println("Matching Resource Found: " + wantToSearchResource);
                    TestRunner.getTest().log(Status.INFO, "Matching Resource Found: " + wantToSearchResource);

                    try {
                        WebElement assignDots = driver.findElement(By.xpath("//button[@aria-label='DropDownButtom']"));
                        assignDots.click();

                        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[@role='menu']")));

                        WebElement assignBtn = wait.until(ExpectedConditions.presenceOfElementLocated(
                                By.xpath("//li[@id='assign']//span[normalize-space()='Assign']")));

                        if (assignBtn.isDisplayed() && assignBtn.isEnabled()) {
                            assignBtn.click();
                            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Assign button found and clicked successfully");
                            found = true;
                            Thread.sleep(1000);

                            this.ReleaseCustomResource();

                            System.out.println("Resource assigned successfully.");
                            TestRunner.getTest().log(Status.PASS, "Resource assigned successfully.");
                            break;
                        } else {
                            TestRunner.getTest().log(Status.FAIL, "Assign button is not clickable (not displayed or not enabled)");
                        }
                    } catch (Exception e) {
                        System.out.println("Error clicking Assign button: " + e.getMessage());
                        TestRunner.getTest().log(Status.FAIL, "Error clicking Assign button: " + e.getMessage());
                    }
                }
            }

            if (!found) {
                System.out.println("No matching resource found with name: " + wantToSearchResource);
                TestRunner.getTest().log(Status.FAIL, "No matching resource found with name: " + wantToSearchResource);
            }

        } catch (Exception e) {
            System.out.println("Exception in ClickOnAssignAndProcessToAssignResource: " + e.getMessage());
            e.printStackTrace();
            TestRunner.getTest().log(Status.FAIL, "Exception in ClickOnAssignAndProcessToAssignResource: " + e.getMessage());
        }
    }

    public void ReleaseCustomResource() throws InterruptedException {
        TestRunner.startTest("Release custom resource that attempted for correct answer");

        WebElement dialogAssignment = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@role='dialog']")));
        dialogAssignment.isDisplayed();
        TestRunner.getTest().log(Status.INFO, "Release assignment prompt shows successfully");

        releaseAssignment_PF.getAssignmentTypeFromAssignment();
        correctAnswerExecutor_PF.EnterAssignmentTitleForCorrectAnswers();
        correctAnswerExecutor_PF.selectSpecificClasses();
        assignAssessment_PF.setDateTimeAndCategory();
        assignAssessment_PF.enterAdditionalSettings();
        assignAssessment_PF.enterWeightPercentage();
        assignAssessment_PF.assignAssignment();
        assignAssessment_PF.verifyDialogBox();
    }

    private void ResourceTableInReadAble() {
        try {
            List<WebElement> assessmentRows = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(
                    By.xpath("//div[contains(@class, 'ResourceDashboardContainer')]//tbody//tr")));
            System.out.println("Assessment dashboard loaded with " + assessmentRows.size() + " rows.");

            boolean rowsLoaded = false;
            int retryCount = 0;
            while (!rowsLoaded && retryCount < 3) {
                try {
                    for (WebElement row : assessmentRows) {
                        WebElement rowText = wait.until(ExpectedConditions.visibilityOf(
                                row.findElement(By.xpath(".//td[2]//div"))));
                        System.out.println("Row Content: " + rowText.getText());
                    }
                    rowsLoaded = true;
                } catch (StaleElementReferenceException e) {
                    retryCount++;
                    System.out.println("Stale element encountered, retrying... Attempt: " + retryCount);
                    assessmentRows = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(
                            By.xpath("//div[contains(@class, 'ResourceDashboardContainer')]//tbody//tr")));
                }
            }

            if (!rowsLoaded) {
                System.out.println("Failed to load all rows after retries.");
            } else {
                System.out.println("All rows are in readable mode.");
            }
        } catch (Exception e) {
            System.out.println("Error in ResourceTableInReadAble: " + e.getMessage());
        }
    }
}
