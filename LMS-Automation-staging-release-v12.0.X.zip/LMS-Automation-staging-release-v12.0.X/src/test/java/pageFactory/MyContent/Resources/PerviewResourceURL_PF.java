package pageFactory.MyContent.Resources;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

import static pageFactory.MyContent.Resources.EditResourceURL_PF.NewTitleUpdated;

public class PerviewResourceURL_PF {

    WebDriverWait wait;
    WebDriver driver;
    Helper helper;



    @FindBy(xpath = "//div[@class='rrt-middle-container']")
    WebElement toastContainer;

    public PerviewResourceURL_PF(WebDriver driver){
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        helper = new Helper();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
    }


    public void searchResourceForPerview()throws InterruptedException{

        TestRunner.getTest().log(Status.INFO, "Search resource for Perview");
        try {
            WebElement searchBox = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder='Search Resources']")));
            if (searchBox.isDisplayed()) {
                Actions actions = new Actions(driver);
                searchBox.click();
                Thread.sleep(2000);

                System.out.println("Search Resource By Updated Title For Perview: " + NewTitleUpdated);
                TestRunner.getTest().log(Status.INFO, "Search Resource By Updated Title For Perview: " + NewTitleUpdated);
                searchBox.sendKeys(NewTitleUpdated);

                actions.sendKeys(Keys.ENTER).perform();

                waitForTableToRefresh();
                TestRunner.getTest().log(Status.PASS, "Test Case Passed : Search box display and search and table refresh Successfully");

            } else {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed  : Search box is not displayed.");
            }
        } catch (Exception e) {
            System.out.println("Search box is not available: " + e.getMessage());
        }

    }

    private void waitForTableToRefresh() {
        TestRunner.getTest().log(Status.INFO, "Wait for table to Refresh");
        WebElement tableClasses = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class, 'right-panel')]//tbody")));

//        wait.until(ExpectedConditions.stalenessOf(tableClasses));

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class, 'right-panel')]//tbody//tr")));

        System.out.println("Table has refreshed.");
        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Table has refreshed.");
    }

    public void clickPerviewButton() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "Click On Perview Button");

        Thread.sleep(500);

        WebElement perviewDots= driver.findElement(By.xpath("//button[@aria-label='DropDownButtom']"));
        perviewDots.click();

        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//ul[@role='menu']//li")));

        WebElement perview_btn= driver.findElement(By.xpath(".//span[normalize-space()='Preview']"));
        perview_btn.click();

        TestRunner.getTest().log(Status.PASS, "Test Case Passed : Perview button found and click successfully");

    }

    public void clickCloseButton() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO,"Click on Close Button");
        Thread.sleep(500);
        WebElement Close_btn= driver.findElement(By.xpath(".//button[@aria-label='close']"));
        Close_btn.click();

        TestRunner.getTest().log(Status.PASS,"Test Case Passed : Close button found and click Successfully");
    }



}
