package pageFactory.MyContent.Resources;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.sl.In;
import org.openqa.selenium.*;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.NotificationModule.CreateNotificationByTeacher_PF;

import java.time.Duration;
import java.util.*;

public class ResourceTypeURL_PF {
    WebDriverWait wait;
    WebDriver driver;
    Helper helper;

    @FindBy(xpath = "//span[normalize-space()='Resources']")
    WebElement btn_resource;

    @FindBy(xpath = "//div[contains(@class, 'selectTextFieldsWrapper')]")
    WebElement dropDown_SelectCourse;

    @FindBy(xpath = "//button[normalize-space()='Add New']")
    WebElement add_new_btn;

    @FindBy(xpath = "(//div[contains(@class, 'ResourceAuthoring')])")
    WebElement resource_info;

    @FindBy(xpath = "//input[@name='title']")
    WebElement resource_title;

    @FindBy(xpath = "//label[text()='Status']/following-sibling::div//div[@role='button' or @role='combobox']")
    WebElement status_dropdown;

    @FindBy(xpath = "//label[text()='Select Course']/following-sibling::div//input[contains(@id, 'autocomplete-')]")
    WebElement courses_dropdown;

    @FindBy(xpath = "//div[@class='controls-container']//button[@id='btn-saveNext']")
    WebElement save_btn;

    @FindBy(xpath = "//div[@class='btn-group']//button[@id='btn-saveNext']")
    WebElement btn_next;

    @FindBy(xpath = "//label[text()='Resource Type']/following-sibling::div//div[@role='button' or @role='combobox']")
    WebElement resource_type_dropdown;

    @FindBy(xpath = "//input[@placeholder='Resource Url']")
    WebElement Resource_URL;

    public static String ResourceTitle;
    public static ThreadLocal<String> NewResourceName = ThreadLocal.withInitial(() -> "");
    public static String SelectedResourceType = "";

    public static String selectedCourseStandardWIndow;

    public static String selectedCourse;
    private static final String[] TAGS = {"div", "p", "h1", "span", "a"};
    private static final Random RANDOM = new Random();


    public ResourceTypeURL_PF(WebDriver driver){
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        helper = new Helper();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
    }

    public void click_Resources(){
        System.out.println("I'm in to click on the Resources Button");
        TestRunner.getTest().log(Status.INFO, "I'm in to click on the Resources Button");
        if (btn_resource.isDisplayed())
        {
            btn_resource.click();
            System.out.println("Resources Button Click");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed   : Resource Button Click Successfully");
        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  Resources Button is not found");
            throw new RuntimeException("Resources Button not found in My Content Dashboard");
        }
    }
    public void resources_dashboard() throws InterruptedException {
        System.out.println("I'm in My Content -- Resources dashboard");
        TestRunner.getTest().log(Status.INFO, "I'm in My Content -- Resources dashboard");
        Thread.sleep(1000);

        WebElement breadCrumbOfMyContent = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ol[contains(@class, 'MuiBreadcrumbs')]")));
        System.out.println("My Content Resources BreadCrumb is: " + breadCrumbOfMyContent.getText());

        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class, 'selectTextFieldsWrapper')]")));
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class, 'ResourceDashboardContainer')]")));
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class, 'ResourceDashboardLeftPanel')]")));
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class, 'right-panel')]")));

        TestRunner.getTest().log(Status.PASS, "Test Case Passed   : Resources Dashboard Load Successfully");
    }
    public void selected_Course() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm in to select Course from Resource Dashboard");
        dropDown_SelectCourse.click();

        Thread.sleep(1000);

        WebElement listCourse = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[@role='listbox']")));
        List<WebElement> optionsCourses = listCourse.findElements(By.xpath(".//li"));

        System.out.println("Courses List is: " + optionsCourses.size());
        TestRunner.getTest().log(Status.INFO, "Courses List is: " + optionsCourses.size());

        if (optionsCourses.isEmpty()) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  No options found in the courses dropdown");
            throw new RuntimeException("No options found in the courses dropdown");

        } else {
            System.out.println("Courses:");

            for (WebElement course : optionsCourses) {
                System.out.println(course.getText());
            }
            if (!optionsCourses.isEmpty()) {
                Random random = new Random();
                int randomCourse = random.nextInt(optionsCourses.size());
                WebElement selectedOption = optionsCourses.get(randomCourse);
                selectedCourse = selectedOption.getText();
                selectedOption.click();
                System.out.println("Selected Course: " + selectedCourse);
                TestRunner.getTest().log(Status.INFO, "Selected Course on resources dashboard: " + selectedCourse);
                TestRunner.getTest().log(Status.PASS, "Test Case Passed   : Course Select Successfully on Resources Dashboard");
            }
        }
    }

    public void click_Add_new_btn(){
        if (add_new_btn.isDisplayed() && add_new_btn.isEnabled()){
            add_new_btn.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed   : Add New Button clicked");
        }else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  Add New Button is not enabled");
            throw new RuntimeException("Button is not enabled");
        }
    }

    public void resource_Information() throws InterruptedException{
        Thread.sleep(100);
        if (resource_info.isDisplayed()){
            System.out.println("Resource Info Step-1 is Displayed");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed   : Resource Info Step-1 is Displayed");
            TestRunner.getTest().log(Status.INFO, "Fill Information for Resource Step-I");
            fill_step_info();
        }else {
            System.out.println("Resource Info Step-1 is not displayed");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : Resource Info Step-1 is not displayed");
            throw new RuntimeException("Resource Info Step-1 is not displayed");
        }
    }

    public void fill_step_info() throws InterruptedException {
        enter_Title();
//        select_status();
        select_courses_step_I();
        add_description_resource();
    }

    public void enter_Title() {
        TestRunner.getTest().log(Status.INFO, "Enter Title for Creation of New Resource");
        resource_title.click();
        resource_title.clear();
        ResourceTitle = generateStudentInfo("AutomatedResource ");
        resource_title.sendKeys(ResourceTitle);
        System.out.println("Resource Title entered Successfully: " + ResourceTitle);
        NewResourceName.set(ResourceTitle);
        TestRunner.getTest().log(Status.INFO, "Resource Title entered: " + ResourceTitle);
        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Title entered successfully" + NewResourceName.get());
    }

    public void select_courses_step_I() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Select Course in Step-I Resource");
        courses_dropdown.click();

        Thread.sleep(1000);
        List<WebElement> optionsClasses = driver.findElements(By.xpath("//ul[@role='listbox']//li"));

        System.out.println("Courses List is: " + optionsClasses.size());

        if (optionsClasses.isEmpty()) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed  : No options found in the Courses dropdown.");
            throw new RuntimeException("No options found in the Courses dropdown");

        } else {
            System.out.println("Courses:");

            for (WebElement classes : optionsClasses) {
//                System.out.println(classes.getText());
                if (classes.getText().equals(selectedCourse)) {
                    classes.click();
                    System.out.println("Clicked on Course: " + selectedCourse);
                    TestRunner.getTest().log(Status.INFO, "Clicked on Course: " + selectedCourse);
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed : Course Select Successfully");
                    break;
                }
            }
        }
        Actions actions = new Actions(driver);
        actions.sendKeys(Keys.ESCAPE).build().perform();
    }

    public void add_description_resource() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "Add Description for New Resource");

        System.out.println("Enter data into Resource Description text box");
        WebElement RichTextBoxBody = driver.findElement(By.xpath("//div[@class='tox-edit-area']/iframe"));

        driver.switchTo().frame(RichTextBoxBody);

        WebElement edt_RichTextBox = driver.findElement(By.xpath("//body[@id='tinymce']//p"));

        System.out.println("Edit text area is found");

        edt_RichTextBox.clear();

        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].value='';", edt_RichTextBox);

        String randomTextInteraction = generateRandomText("Description of Resource is ");
        System.out.println(randomTextInteraction);
        TestRunner.getTest().log(Status.INFO, "Description for New Resource: " + randomTextInteraction);

        edt_RichTextBox.sendKeys(randomTextInteraction);
        TestRunner.getTest().log(Status.PASS, "Test Case Passed : Description for Resource Added Successfully");

        helper.takeScreenshot(driver , Thread.currentThread().getStackTrace()[1].getMethodName() );
        driver.switchTo().defaultContent();
    }

    public void click_save(){
        TestRunner.getTest().log(Status.INFO, "Click on Save Button ");
        if (save_btn.isDisplayed() && save_btn.isEnabled()) {
            save_btn.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed : Save Button click successfully");
        }else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Save Button Not found/ is Disable");
        }

    }

    public void validateToastMessage()throws InterruptedException{
        wait.pollingEvery(Duration.ofMillis(20));
        try {
            WebElement toastContainer = wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("toastr")));
            if (toastContainer.isDisplayed()) {
                String messageTitle = toastContainer.findElement(By.className("rrt-title")).getText();
                String messageText = toastContainer.findElement(By.className("rrt-text")).getText();

                System.out.println("Message Title: " + messageTitle);
                System.out.println("Message Text: " + messageText);

            } else {
               System.out.println("Toast message is not displayed.");
            }
        } catch (TimeoutException e) {
            System.out.println("Toast message did not appear in the expected time.");
        }

    }

    public void click_next_btn(){
        TestRunner.getTest().log(Status.INFO, "Click on Next Button ");

        WebElement btn_next_step_1= driver.findElement(By.xpath("//button[@type='button'][normalize-space()='Next']"));
        if (btn_next_step_1.isDisplayed()) {
            btn_next_step_1.click();
            System.out.println("Next Button Click Successfully");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed : Next Button Click Successfully");
        }else {
            System.out.println("Next Button is not displayed. ");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Next Button is not displayed.");
            throw new RuntimeException("Next Button is Disable");
        }
    }

    public void ResourceType() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "Checking and validate And Fill Resource Step-II Resource Type Information");
        select_resource_type();
    }
    public void select_resource_type() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm in select Resource Type ");
        resource_type_dropdown.click();
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//ul[@role='listbox']")));

        List<WebElement> ResourceTypeOptions = driver.findElements(By.xpath("//ul[@role='listbox']//li"));
        System.out.println("Total types: " + ResourceTypeOptions.size());

        List<WebElement> clickableOptions = new ArrayList<>();
        for (WebElement option : ResourceTypeOptions) {
            System.out.println("Types: " + option.getText());
            if (option.isEnabled() && option.isDisplayed()) {
                clickableOptions.add(option);
            }
        }

        if (!clickableOptions.isEmpty()) {
            Random random = new Random();
            WebElement selectedOption = null;

            for (int attempts = 0; attempts < clickableOptions.size(); attempts++) {
                try {
                    int randomIndex = random.nextInt(clickableOptions.size());
                    selectedOption = clickableOptions.get(randomIndex);
                    SelectedResourceType = selectedOption.getText();
                    selectedOption.click();
                    System.out.println("Selected Resource Type: " + SelectedResourceType);
                    TestRunner.getTest().log(Status.INFO, "Selected Resource Type: " + SelectedResourceType);
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed : Resources Type select successfully");
                    break;
                } catch (ElementClickInterceptedException e) {
                    System.out.println("Option click intercepted, retrying...");
                }
            }
            if (selectedOption != null && selectedOption.isEnabled() && selectedOption.isDisplayed()) {
                switch (SelectedResourceType) {
                    case "Html":
                        add_description_resource_html();
                        break;
                    case "Text":
                        add_description_resource_Text();
                        break;
                    case "Url":
                        enter_resource_url();
                        break;
                    case "Document":
                        upload_document();
                        break;
                    case "Image":
                        upload_Image();
                        break;
                    default:
                        System.out.println("No specific function for option: " + SelectedResourceType);
                        TestRunner.getTest().log(Status.INFO, "No specific function for option: " + SelectedResourceType);
                        TestRunner.getTest().log(Status.FAIL, "Test Case Failed : No specific function for option");
                        break;
                }
            } else {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed : No clickable option found");
                System.out.println("No clickable option found.");
            }
        } else {
            System.out.println("No clickable options available.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : No clickable options available in resource Type Dropdown");
        }
    }

    public void enter_resource_url() {
        TestRunner.getTest().log(Status.INFO, "I am in Resource Type URL");
        if (Resource_URL.isDisplayed()) {
            Resource_URL.click();
            Resource_URL.sendKeys("www.google.com");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed : Resource URL added successfully");
        }else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Resource URL box not Displayed");
            throw new RuntimeException("Resource URL box not Displayed");

        }
    }

    public void upload_document(){
        System.out.println("I'm in Upload Document Resource Type");
        TestRunner.getTest().log(Status.INFO, "I'm in Upload Document Resource Type");

        WebElement btnUploadDocument = driver.findElement(By.xpath("//label[@role='button' or @role='combobox']"));
//        btnUploadDocument.click();

        WebElement fileInput = btnUploadDocument.findElement(By.xpath("//input[@type='file']"));

        // Get the absolute path of the file
        String filePath = System.getProperty("user.dir") + "/src/test/resources/drivers/DummyImg.png";

        // Provide the absolute path to the file input
        fileInput.sendKeys(filePath);

//        fileInput.sendKeys("src/test/resources/drivers/DummyImg.png");

//        Thread.sleep(2000);
        helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());

        TestRunner.getTest().log(Status.PASS, "Test Case Passed : Document upload Successfully");


    }

    public void upload_Image(){
        TestRunner.getTest().log(Status.INFO, "I'm in Upload Image Resource Type");
        System.out.println("I'm in Upload Image Resource Type");

        WebElement btnUploadDocument = driver.findElement(By.xpath("//label[@role='button' or @role='combobox']"));
//        btnUploadDocument.click();

        WebElement fileInput = btnUploadDocument.findElement(By.xpath("//input[@type='file']"));

        // Get the absolute path of the file
        String filePath = System.getProperty("user.dir") + "/src/test/resources/drivers/DummyImg.png";

        // Provide the absolute path to the file input
        fileInput.sendKeys(filePath);

//        fileInput.sendKeys("src/test/resources/drivers/DummyImg.png");

//        Thread.sleep(2000);
        helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
        TestRunner.getTest().log(Status.PASS, "Test Case Passed :  Image upload Successfully");
    }

    public void add_description_resource_html() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "Enter HTML data into text box");
        System.out.println("Enter HTML data into text box");
        WebElement RichTextBoxBody = driver.findElement(By.xpath("//div[@class='tox-edit-area']/iframe"));

        driver.switchTo().frame(RichTextBoxBody);

        WebElement edt_RichTextBox = driver.findElement(By.xpath("//body[@id='tinymce']//p"));

        System.out.println("Edit text area is found");

        edt_RichTextBox.clear();

        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].value='';", edt_RichTextBox);

        String randomTextInteraction =generateRandomHTML();
        System.out.println(randomTextInteraction);
        TestRunner.getTest().log(Status.INFO, "HTML Text: " + randomTextInteraction);
        edt_RichTextBox.sendKeys(randomTextInteraction);
        helper.takeScreenshot(driver , Thread.currentThread().getStackTrace()[1].getMethodName() );

        driver.switchTo().defaultContent();
        TestRunner.getTest().log(Status.PASS, "Test Case Passed :  HTML is added Successfully in Text Box");
    }

    public void add_description_resource_Text() throws InterruptedException{
        System.out.println("Enter data into Resource Description text box");
        TestRunner.getTest().log(Status.INFO, "Enter data into Resource Description text box");
        WebElement RichTextBoxBody = driver.findElement(By.xpath("//div[@class='tox-edit-area']/iframe"));

        driver.switchTo().frame(RichTextBoxBody);

        WebElement edt_RichTextBox = driver.findElement(By.xpath("//body[@id='tinymce']//p"));

        System.out.println("Edit text area is found");

        edt_RichTextBox.clear();

        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].value='';", edt_RichTextBox);

        String randomTextInteraction = helper.generateRandomText("Description of Resource is ");
        System.out.println(randomTextInteraction);
        TestRunner.getTest().log(Status.INFO, "Text in Text Box is: " + randomTextInteraction);

        edt_RichTextBox.sendKeys(randomTextInteraction);
        helper.takeScreenshot(driver , Thread.currentThread().getStackTrace()[1].getMethodName() );

        driver.switchTo().defaultContent();
        TestRunner.getTest().log(Status.PASS, "Test Case Passed : Text is added Successfully in Text Box");

    }


    public void click_next_step_2(){
        TestRunner.getTest().log(Status.INFO, "Click on Next Step of Step-II");
        WebElement step_2_next_btn= driver.findElement(By.xpath("//div[@class='btn-group']//button[@id='btn-saveNext']"));
        if (step_2_next_btn.isEnabled() && step_2_next_btn.isDisplayed()) {
            step_2_next_btn.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed : Next Button on Step-II clicked Successfully");
        }else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Next button on found on Step-II");
            throw new RuntimeException("Next button on found on Step-II");
        }

    }

    public String generateRandomHTML() {
        int numElements = RANDOM.nextInt(5) + 1; // Generate between 1 and 5 elements
        StringBuilder html = new StringBuilder("<!DOCTYPE html><html><body>");

        // Add random elements
        for (int i = 0; i < numElements; i++) {
            String tag = TAGS[RANDOM.nextInt(TAGS.length)];
            String content = "Random content " + (i + 1);
            html.append("<").append(tag).append(">").append(content).append("</").append(tag).append(">");
        }

        html.append("</body></html>");
        return html.toString();
    }

    public String selectRandomValueFromDropdown(List<WebElement> options) {
        if (options.isEmpty()) {
            throw new IllegalArgumentException("The options list must not be empty");
        }
        Random random = new Random();
        int index = random.nextInt(options.size());
        WebElement selectedOption = options.get(index);
        System.out.println("Selected value: " + selectedOption.getText());
        selectedOption.click();
//        System.out.println("Selected value: " + selectedOption.getText());
        return selectedOption.getText();
    }

    public String generateRandomText(String prefix) {
        String characters = "ABC123456789";
        StringBuilder randomText = new StringBuilder();
        Random random = new Random();
        int length = 6;
        randomText.append(prefix);
        for (int i = 0; i < length; i++) {
            randomText.append(characters.charAt(random.nextInt(characters.length())));
        }
        return randomText.toString();
    }

    public String generateStudentInfo(String prefix) {
        String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        StringBuilder randomTitle = new StringBuilder();
        Random random = new Random();
        int length = 4;
        randomTitle.append(prefix);
        for (int i = 0; i < length; i++) {
            randomTitle.append(characters.charAt(random.nextInt(characters.length())));
        }
        return randomTitle.toString();
    }

//    Negative Scenario

    public void selectResourceForNegative() throws InterruptedException{

        resource_type_dropdown.click();
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//ul[@role='listbox']")));

        // Fetch the list of all resource type options
        List<WebElement> ResourceTypeOptions = driver.findElements(By.xpath("//ul[@role='listbox']//li"));
        System.out.println("Total types: " + ResourceTypeOptions.size());

        // Filter the options to create a list of only enabled and visible options
        List<WebElement> clickableOptions = new ArrayList<>();
        for (WebElement option : ResourceTypeOptions) {
            System.out.println("Types: " + option.getText());
            if (option.isEnabled() && option.isDisplayed()) {
                clickableOptions.add(option);
            }
        }

        if (!clickableOptions.isEmpty()) {
            Random random = new Random();
            WebElement selectedOption = null;
//            String SelectedResourceType = "";

            for (int attempts = 0; attempts < clickableOptions.size(); attempts++) {
                try {
                    int randomIndex = random.nextInt(clickableOptions.size());
                    selectedOption = clickableOptions.get(randomIndex);
                    SelectedResourceType = selectedOption.getText();
                    selectedOption.click();
                    System.out.println("Selected Resource Type: " + SelectedResourceType);
                    break;
                } catch (ElementClickInterceptedException e) {
                    System.out.println("Option click intercepted, retrying...");
                }
            }
            if (selectedOption != null && selectedOption.isEnabled() && selectedOption.isDisplayed()) {
                switch (SelectedResourceType) {
                    case "Html":
                        add_description_resource_html();
                        break;
                    case "Text":
                        add_description_resource_Text();
                        break;
                    case "Url":
                        enter_resource_url();
                        break;
                    case "Document":
                        upload_document();
                        break;
                    case "Image":
                        upload_Image();
                        break;
                    default:
                        System.out.println("No specific function for option: " + SelectedResourceType);
                        break;
                }
            } else {
                System.out.println("No clickable option found.");
            }
        } else {
            System.out.println("No clickable options available.");
        }
    }
}
