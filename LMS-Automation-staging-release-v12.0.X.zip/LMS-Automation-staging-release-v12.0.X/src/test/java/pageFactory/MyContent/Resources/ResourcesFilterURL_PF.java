package pageFactory.MyContent.Resources;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.MyContentModule.Resources.ResourceTypeURLSteps;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

import static pageFactory.MyContent.Resources.ResourceTypeURL_PF.*;

public class ResourcesFilterURL_PF {
    WebDriverWait wait;
    WebDriver driver;
    Helper helper;
    ResourceTypeURL_PF resourceTypeURLPf;

    public ResourcesFilterURL_PF(WebDriver driver){
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        helper = new Helper();
        resourceTypeURLPf = new ResourceTypeURL_PF(driver);
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
    }


    @FindBy(xpath = "//div[contains(@class, 'selectTextFieldsWrapper')]")
    WebElement dropDown_SelectCourse;

    @FindBy(xpath = "//div[@aria-controls='Resources-content'] ")
    WebElement div_ResourceContent;

    @FindBy(xpath = "//button[normalize-space()='Apply Filter']")
    WebElement filter_apply_btn;

    @FindBy(xpath = "//div[contains(@class, 'right-panel')]")
    WebElement ResourcesTable;

    public static String ResourceTitleInTable;


    public void Course_selection_Dashboard() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm in Select Course ");
        dropDown_SelectCourse.click();

        Thread.sleep(1000);
        List<WebElement> optionsClasses = driver.findElements(By.xpath("//ul[@role='listbox']//li"));

        System.out.println("Courses List is: " + optionsClasses.size());

        if (optionsClasses.isEmpty()) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed  : No options found in the Classes dropdown.");
            throw new RuntimeException("No options found in the Classes dropdown");

        } else {
            System.out.println("Courses:");

            for (WebElement classes : optionsClasses) {
//                System.out.println(classes.getText());
                if (classes.getText().equals(selectedCourse)) {
                    classes.click();
                    System.out.println("Clicked on Course: " + selectedCourse);
                    TestRunner.getTest().log(Status.INFO, "Clicked on Course: " + selectedCourse);
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed : Course Clicked Successfully");
                    break;
                }
            }
        }
        Actions actions = new Actions(driver);
        actions.sendKeys(Keys.ESCAPE).build().perform();
    }

    public void left_panel_resources_section() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm Verify Left panel Resources Section");
        WebElement gridResourceContent = wait.until(ExpectedConditions.visibilityOf(div_ResourceContent));

        helper.scrollToElement(driver, gridResourceContent);

        WebElement btn_Resource = driver.findElement(By.xpath("//div[@aria-label='Platform']//button[.//span[contains(text(), 'My Resources')]]"));
        btn_Resource.click();

        WebElement typeResources = driver.findElement(By.xpath("(//div[@aria-labelledby='Resources-header']//div[contains(@class, 'treeViewCheckbox') and contains(@class, 'false')])[2]"));
        List<WebElement> totalTypes = typeResources.findElements(By.tagName("li"));

        System.out.println("Total types are: " + totalTypes.size());
        TestRunner.getTest().log(Status.INFO, "Total Resources types are: " + totalTypes.size());

        for (WebElement typeName : totalTypes) {
            String typeNameText = typeName.findElement(By.xpath(".//span[@class='text']")).getText();
            System.out.println("Type name is: " + typeNameText);

            if (typeNameText.contains(SelectedResourceType)) {
                WebElement checkBox = typeName.findElement(By.xpath(".//span[@role='checkbox']"));

                boolean isChecked = checkBox.isSelected();

                if (isChecked) {
                    System.out.println("Checkbox for " + SelectedResourceType + " is already selected.");
                    TestRunner.getTest().log(Status.INFO, "Checkbox for " + SelectedResourceType + " is already selected.");
                } else {
                    checkBox.click();
                    System.out.println("Checkbox for " + SelectedResourceType + " is now selected.");
                    TestRunner.getTest().log(Status.INFO, "Checkbox for " + SelectedResourceType + " is now selected.");
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed : Resource Type is selected successfully");
                }
            } else {
                TestRunner.getTest().log(Status.INFO, "No checkbox found for: " + SelectedResourceType);
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed  : No Resources Type is found.");
            }
            break;
        }
    }
    public void apply_filter_btn()
    {
        TestRunner.getTest().log(Status.INFO, "Click on Apply Filter Button");
        if (filter_apply_btn.isDisplayed() ) {
            filter_apply_btn.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed : Apply Filter button has been clicked.");
        }else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed  : Apply Filter button not found.");
            throw new RuntimeException("Apply Filter button not found");
        }

    }

    public void showsResourceIntoTable() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm to Show Resource into Table");
        Thread.sleep(3000);

        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class, 'right-panel')]")));

        List<WebElement> rows = ResourcesTable.findElements(By.xpath(".//tbody/tr"));

        if (!rows.isEmpty()) {
            System.out.println("Resources found in the table:");
            for (int i = 0; i < rows.size(); i++) {
                WebElement row = rows.get(i);

                try {
                    WebElement resourceNameElement = row.findElement(By.xpath(".//td//div"));
                    ResourceTitleInTable = resourceNameElement.getText();
                    System.out.println("Resource Name: " + ResourceTitleInTable);
                    TestRunner.getTest().log(Status.INFO, "Resource Name: " + ResourceTitleInTable);

                    List<WebElement> cells = row.findElements(By.xpath(".//td"));
                    for (WebElement cell : cells) {
                        System.out.print(cell.getText() + "\t");
                    }
                    System.out.println();
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed : Resource Shows Into Table Successfully.");

                } catch (StaleElementReferenceException e) {
                    System.out.println("Stale element found, retrying...");

                    rows = ResourcesTable.findElements(By.xpath(".//tbody/tr"));
                    row = rows.get(i);

                    WebElement classNameElement = row.findElement(By.xpath(".//td//div"));
                    String className = classNameElement.getText();
                    System.out.println("Resource Name: " + className);

                    List<WebElement> cells = row.findElements(By.xpath(".//td"));
                    for (WebElement cell : cells) {
                        System.out.print(cell.getText() + "\t");
                    }
                    System.out.println();
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed : Resource Shows Into Table Successfully.");

                }
            }
        } else {
            System.out.println("No Resource found in the table.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed  : Resources are not  Shown in Table");

        }
    }

    public void searchResourceByTitle() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "Search Resource By Title");
        WebElement right_panel= driver.findElement(By.xpath("//div[contains(@class, 'right-panel')]"));
        right_panel.isDisplayed();

        try {
            WebElement searchBox = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder='Search Resources']")));
            if (searchBox.isDisplayed()) {
                searchBox.click();
                searchBox.clear();
                ((JavascriptExecutor) driver).executeScript("arguments[0].value='';", searchBox);
                Thread.sleep(1000);
                System.out.println("Search by Resource By Title: " + ResourceTitle);
                TestRunner.getTest().log(Status.INFO, "SSearch by Resource By Title: " + ResourceTitle);
                searchBox.sendKeys(ResourceTitle);

                Actions actions = new Actions(driver);
                actions.sendKeys(Keys.ENTER).perform();

                waitForTableToRefresh();
                TestRunner.getTest().log(Status.PASS, "Test Case Passed : Search box display and search and table refresh Successfully.");

            } else {
//
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed  : Search box is not displayed.");
            }
        } catch (Exception e) {
            System.out.println("Search box is not available: " + e.getMessage());
        }
    }

    private void waitForTableToRefresh() throws InterruptedException {
        Thread.sleep(2000);
        WebElement tableClasses = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class, 'right-panel')]//tbody")));

//        wait.until(ExpectedConditions.stalenessOf(tableClasses));

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class, 'right-panel')]//tbody//tr")));

        System.out.println("Table has refreshed.");
        TestRunner.getTest().log(Status.INFO, "Table has refreshed.");
    }

    public void verifySearchedResourceByTitleIntoTable(){
        if (ResourceTitleInTable.contains(ResourceTitle)){
            TestRunner.getTest().log(Status.INFO, "Search by Resource Found: " + ResourceTitle);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed :  Searched resource found");

        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed  : Searched Resource not found and search filter not working");
            throw new RuntimeException("Searched Resource not found and search filter not working");

        }
    }
}
