package pageFactory.MyContent.Resources;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Assignmment.AdvancedGrading_PF;
import pageFactory.Assignmment.CorrectAnswerExecutor_PF;
import pageFactory.Assignmment.ReleaseAssignment_PF;
import pageFactory.Assignmment.StudentExecutor_PF;
import pageFactory.MyContent.AssignAssessment_PF;

import java.time.Duration;
import java.util.List;

public class ResourcesPreDefinedStatus_PF {


    WebDriverWait wait;
    WebDriver driver;
    Helper helper;
    StudentExecutor_PF studentExecutor;
    Actions actions;

    public String ResourceName;

    @FindBy(xpath = "//div[contains(@class, 'ResourceDashboardContainer')]//tbody")
    WebElement resourceContainerTable;

    public ResourcesPreDefinedStatus_PF(WebDriver driver) {
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        helper = new Helper();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        actions = new Actions(driver);

    }

    public void showsResourcesIntoTable() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm in Show Resources Into table");
        Thread.sleep(5000);
        try {
            WebElement questionsTable = wait.until(ExpectedConditions.visibilityOf(resourceContainerTable));

            if (questionsTable != null) {
                List<WebElement> questionRows = questionsTable.findElements(By.xpath(".//tr"));

                if (!questionRows.isEmpty()) {
                    System.out.println("Questions found in the table:");
                    TestRunner.getTest().log(Status.INFO, "Questions found in the table:");
                    Thread.sleep(5000);

                    boolean allRowsProcessedSuccessfully = true;

                    for (int i = 0; i < questionRows.size(); i++) {
                        WebElement questionRow = questionRows.get(i);

                        int retryCount = 0;
                        boolean success = false;

                        while (retryCount < 6) {
                            try {
                                WebElement questionNameElement = questionRow.findElement(By.xpath(".//td[contains(@class, 'cell-0')]"));
                                ResourceName = questionNameElement.getText();
                                System.out.println("Resources Name: " + ResourceName);
                                TestRunner.getTest().log(Status.INFO, "Resources Name: " + ResourceName);

                                List<WebElement> questionNameCells = questionRow.findElements(By.xpath(".//td"));
                                for (WebElement questionNameCell : questionNameCells) {
                                    System.out.print(questionNameCell.getText() + "\t");
                                }
                                System.out.println();

                                success = true;
                                break;

                            } catch (StaleElementReferenceException e) {
                                System.out.println("Stale element found, retrying...");

                                questionRows = questionsTable.findElements(By.xpath(".//tbody//tr"));

                                if (i >= questionRows.size()) {
                                    System.out.println("Row index " + i + " is out of bounds after refresh.");
                                    break;
                                }

                                questionRow = questionRows.get(i);
                                retryCount++;
                            } catch (NoSuchElementException e) {
                                System.out.println("Element not found in the row: " + e.getMessage());
                                break;
                            }
                        }

                        if (!success) {
                            System.out.println("Failed to retrieve question row after several attempts.");
                            allRowsProcessedSuccessfully = false;
                        }
                    }

                    if (allRowsProcessedSuccessfully) {
                        TestRunner.getTest().log(Status.PASS, "Test Case Passed  : Resources Shows Into Table Successfully");
                    } else {
                        TestRunner.getTest().log(Status.FAIL, "Test Case Failed  : One or more Resources could not be processed.");
                    }
                } else {
                    TestRunner.getTest().log(Status.FAIL, "Test Case Failed  : No Resources found in the table.");
                    throw new RuntimeException("No questions found in the table");
                }
            } else {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Resources table is not visible.");
                throw new RuntimeException("Resources table is not visible");

            }
        } catch (TimeoutException e) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Timeout waiting for table to be visible or accessible. " + e.getMessage());
        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: An unexpected error occurred. " + e.getMessage());
        }
    }

    public void filterResourcesByStatus() throws InterruptedException{
            String[] statusArray = {"Active", "Editing", "Locked"};

            for (String status : statusArray) {
                TestRunner.getTest().log(Status.INFO, "Filtering Resources By Status: " + status);

                try {
                    WebElement statusDropdown = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(@class, 'MuiSelect-select') and @role='button' or @role='combobox'])[3]")));
                    statusDropdown.click();

                    List<WebElement> statusOptions = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//ul[@role='listbox']//li")));
                    boolean statusFound = false;

                    for (WebElement option : statusOptions) {
                        String optionText = option.getText().trim();
                        if (optionText.equalsIgnoreCase(status)) {
                            option.click();
                            statusFound = true;
                            TestRunner.getTest().log(Status.INFO, "Selected Status: " + optionText);
                            break;
                        }
                    }

                    if (!statusFound) {
                        TestRunner.getTest().log(Status.FAIL, "Status not found in the dropdown: " + status);
                        throw new RuntimeException("Status not found in the dropdown: " + status);
                    }

                    Thread.sleep(2000);
                    waitForTableToRefresh();

                    if (isNoDataFoundDisplayed()) {
                        TestRunner.getTest().log(Status.INFO, "No Resource found for the status: " + status);
                        System.out.println("No Resource found for the status: " + status);
                        continue;
                    }

                    WebElement questionsTable = wait.until(ExpectedConditions.visibilityOf(resourceContainerTable));
                    List<WebElement> questionRows = questionsTable.findElements(By.xpath(".//tr"));

                    boolean allRowsMatchStatus = true;

                    for (WebElement row : questionRows) {
                        WebElement statusCell = row.findElement(By.xpath(".//td[contains(@class, 'cell-3')]"));
                        String rowStatus = statusCell.getText().trim();

                        if (!rowStatus.equalsIgnoreCase(status)) {
                            allRowsMatchStatus = false;
                            System.out.println("Row status is: " + rowStatus);
                            TestRunner.getTest().log(Status.FAIL, "Resource with mismatched status found: " + rowStatus);
                        } else {
                            TestRunner.getTest().log(Status.INFO, "Resource row with status: " + rowStatus);
                        }
                    }

                    if (allRowsMatchStatus) {
                        TestRunner.getTest().log(Status.PASS, "All Resource match the selected status: " + status);
                    } else {
                        TestRunner.getTest().log(Status.FAIL, "Some Resource do not match the selected status: " + status);
                    }

                } catch (NoSuchElementException | ElementNotInteractableException e) {
                    TestRunner.getTest().log(Status.WARNING, "Table not load in current time frame");
                }
            }
    }

    private boolean isNoDataFoundDisplayed() {
        try {
            WebElement noDataFound = driver.findElement(By.xpath("//div[contains(@class, 'ResourceDashboardContainer')]//div[contains(text(),'No Detail Found')]"));
            return noDataFound.isDisplayed();
        } catch (NoSuchElementException e) {
            return false;
        }
    }

    private void waitForTableToRefresh() throws InterruptedException{
        try {
            WebElement questionsTable = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class, 'ResourceDashboardContainer')]//tbody")));

            List<WebElement> rowsBeforeRefresh = questionsTable.findElements(By.xpath(".//tr"));
            System.out.println("Number of rows before refresh: " + rowsBeforeRefresh.size());

            Thread.sleep(2000);

            List<WebElement> rowsAfterRefresh = questionsTable.findElements(By.xpath(".//tr"));
            System.out.println("Number of rows after refresh: " + rowsAfterRefresh.size());

            if (rowsBeforeRefresh.size() != rowsAfterRefresh.size()) {
                System.out.println("Table has refreshed. Number of rows before refresh: " + rowsBeforeRefresh.size() + ", after refresh: " + rowsAfterRefresh.size());
                TestRunner.getTest().log(Status.INFO, "Table has refreshed. Number of rows before refresh: " + rowsBeforeRefresh.size() + ", after refresh: " + rowsAfterRefresh.size());
            } else {
                System.out.println("Table did not refresh as expected. Rows before: " + rowsBeforeRefresh.size() + ", Rows after: " + rowsAfterRefresh.size());
            }

            for (WebElement row : rowsAfterRefresh) {
                System.out.println("Table Row: " + row.getText());
            }

        } catch (NoSuchElementException | TimeoutException e) {
            try {
                WebElement noDataFound = driver.findElement(By.xpath("//div[contains(@class, 'ResourceDashboardContainer')]//div[contains(text(),'No Detail Found')]"));
                String statusHaveNoData = noDataFound.getText();
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: 'No Detail Found' message is displayed as expected. " + statusHaveNoData);
                System.out.println("Test Case Passed: 'No Detail Found' message is displayed. " + statusHaveNoData);
            } catch (NoSuchElementException nestedException) {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Neither table data nor 'No Detail Found' message found.");
                System.out.println("Test Case Failed: Neither table data nor 'No Detail Found' message found.");
            }
        }
    }


}
