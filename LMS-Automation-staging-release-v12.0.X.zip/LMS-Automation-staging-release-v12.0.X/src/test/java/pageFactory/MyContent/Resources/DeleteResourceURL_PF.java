package pageFactory.MyContent.Resources;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

import static pageFactory.MyContent.Resources.EditResourceURL_PF.NewTitleUpdated;
import static pageFactory.MyContent.Resources.ResourceTypeURL_PF.ResourceTitle;

public class DeleteResourceURL_PF {

    WebDriverWait wait;
    WebDriver driver;
    Helper helper;

    @FindBy(xpath = "//div[@role='dialog']")
    WebElement delete_dialogue;

    @FindBy(xpath = "//button[normalize-space()='Yes']")
    WebElement delete_yes;

    @FindBy(xpath = "//div[@class='rrt-middle-container']")
    WebElement toastContainer;

    public DeleteResourceURL_PF(WebDriver driver){
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        helper = new Helper();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
    }


    public void searchResourceForDelete()throws InterruptedException{

        TestRunner.getTest().log(Status.INFO, "Search resource for Delete");
        try {
            WebElement searchBox = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder='Search Resources']")));
            if (searchBox.isDisplayed()) {
                Actions actions = new Actions(driver);
                searchBox.click();
                Thread.sleep(2000);

                System.out.println("Search Resource By Updated Title For Delete: " + NewTitleUpdated);
                TestRunner.getTest().log(Status.INFO, "Search Resource By Updated Title For Delete: " + NewTitleUpdated);
                searchBox.sendKeys(NewTitleUpdated);

                actions.sendKeys(Keys.ENTER).perform();

                waitForTableToRefresh();
                TestRunner.getTest().log(Status.PASS, "Test Case Passed : Search box display and search and table refresh Successfully");

            } else {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed  : Search box is not displayed.");
            }
        } catch (Exception e) {
            System.out.println("Search box is not available: " + e.getMessage());
        }

    }

    private void waitForTableToRefresh() {
        TestRunner.getTest().log(Status.INFO, "Wait for table to Refresh");
        WebElement tableClasses = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class, 'right-panel')]//tbody")));

//        wait.until(ExpectedConditions.stalenessOf(tableClasses));

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class, 'right-panel')]//tbody//tr")));

        System.out.println("Table has refreshed.");
        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Table has refreshed.");
    }

    public void Delete_btn_url() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Click on Delete Button");
        Thread.sleep(500);

        WebElement editDots= driver.findElement(By.xpath("//button[@aria-label='DropDownButtom']"));
        editDots.click();

        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//ul[@role='menu']//li")));

        WebElement edit_btn= driver.findElement(By.xpath(".//span[normalize-space()='Delete']"));
        edit_btn.click();

        TestRunner.getTest().log(Status.PASS, "Test Case Passed : Delete button found and clicked");


    }

    public void DeleteResourceWindow() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "Delete Resource Window pop-up");

        WebElement dialogBoxDelete = wait.until(ExpectedConditions.visibilityOf(delete_dialogue));

        WebElement text_delete= dialogBoxDelete.findElement(By.xpath("//div[@class='deleteCard']//div"));

        String deleteCardText = text_delete.getText();
        System.out.println("Text at Delete Resource: " + deleteCardText);

        WebElement resourceNameElement = text_delete.findElement(By.className("assignmentName"));
        String resourceNameText = resourceNameElement.getText();

        System.out.println("Resource we want to delete: " + resourceNameText);
        TestRunner.getTest().log(Status.PASS, "Test Case Passed : Resource Delete Dialogue Window appears ang Get name successfully");
    }
    public  void clickYesToDelete() throws InterruptedException{

        TestRunner.getTest().log(Status.INFO, "Click on Yes To Delete Resource");

        if (delete_yes.isDisplayed()){
            delete_yes.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed : Resource Delete Successfully");
        }else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : delete Button is not displayed on Resource Delete Dialogue Window");
        }
    }

    public void verifySuccessMessage() {
        WebElement successMessageContainer = wait.until(ExpectedConditions.visibilityOf(toastContainer));
        if (successMessageContainer.isDisplayed()) {
            String messageTitle = successMessageContainer.findElement(By.className("rrt-title")).getText();
            String messageText = successMessageContainer.findElement(By.className("rrt-text")).getText();

            System.out.println("Message Title: " + messageTitle);
            System.out.println("Message Text: " + messageText);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed : Toast Message Get successfully");

        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Success message is not displayed.");
        }
    }

}
