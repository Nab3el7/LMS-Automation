package pageFactory.MyContent;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Classes.EditClass_PF;

import java.time.Duration;
import java.util.List;

import static pageFactory.MyContent.QuestionsPF.CreateQuestion_PF.questionTitle;
import static pageFactory.MyContent.QuestionsPF.CreateQuestion_PF.selectedQuestionType;

public class EditAssessment_PF {
    WebDriverWait wait;
    WebDriver driver;
    Helper helper;

    static String questionName;
    String searchQuestionByName;


    @FindBy(xpath = "//button[contains(@type,'button')][normalize-space()='Next']")
    WebElement nextButton;

    @FindBy(xpath = "//div[@class='screens-container']")
    WebElement container_NewQuestions;

    @FindBy(xpath = "//button[normalize-space()='Apply Filter']")
    WebElement btn_ApplyFilter;

    @FindBy(xpath = "(//div[@class='screens-container']//div[contains(@class, 'SelectQuestionsRightWrapper')]//table//tbody)[2]")
    WebElement questionsRightTable;

    @FindBy(xpath = "//div[contains(@class, 'editCustomAssessment')]//div[contains(@class, 'right-panel')]")
    WebElement editCustomAssessment;

    @FindBy(xpath = "(//div[contains(@class, 'editCustomAssessment')]//tbody)[2]")
    WebElement customAssessmentQuestionTable;

    @FindBy(xpath = "//div[@class='btn-group']//button[@id='btn-saveNext']")
    WebElement saveNextButton;

    public EditAssessment_PF(WebDriver driver) {
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        helper = new Helper();
    }

    public void clickAssessmentEditButton() throws InterruptedException{
        Thread.sleep(500);

        WebElement editDots= driver.findElement(By.xpath("//button[@aria-label='DropDownButtom']"));
        editDots.click();

        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//ul[@role='menu']//li")));

        WebElement edit_btn= driver.findElement(By.xpath(".//span[normalize-space()='Edit']"));

        helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());

        edit_btn.click();

        TestRunner.getTest().log(Status.PASS, " Test Case Passed :Test Case Passed   :  Edit button click successfully");
    }

    public void clickOnNextButtonInEditAssessment() {
        wait.until(ExpectedConditions.elementToBeClickable(nextButton));

        if (nextButton.isDisplayed() && nextButton.isEnabled()){
            nextButton.click();
            TestRunner.getTest().log(Status.PASS, " Test Case Passed :Test Case Passed   :  Next Button clicked successfully ");
        } else {
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed :Test Case Failed   :  Next Button is not clicked");
        }

    }

    public void selectCustomQuestionInEditAssessment() throws InterruptedException {
        Thread.sleep(2000);

        container_NewQuestions.isDisplayed();

        System.out.println(driver.getCurrentUrl());

        WebElement panelQuestions = container_NewQuestions.findElement(By.xpath("//div[contains(@class, 'SelectQuestionsRightWrapper')]"));
        WebElement panelHeaderTotalQuestions = panelQuestions.findElement(By.xpath("//div[contains(@class, 'leftQuestionHeader')]"));
        System.out.println("Header questions shows: " + panelHeaderTotalQuestions.getText());

        WebElement totalQuestions = panelHeaderTotalQuestions.findElement(By.xpath("//span[contains(@class, 'title-counter')]"));
        System.out.println("Total Questions found: " + totalQuestions.getText());
        TestRunner.getTest().log(Status.INFO, "Total Questions: " + totalQuestions.getText());

        WebElement btnClearAllFilters = panelQuestions.findElement(By.xpath("//button[normalize-space()='Clear all Filter']"));
        btnClearAllFilters.click();
        System.out.println("All filters cleared!");
        TestRunner.getTest().log(Status.INFO, "All filters cleared successfully");

        Thread.sleep(500);

        WebElement typeContainer = driver.findElement(By.xpath("(//div[@aria-labelledby='Questions-header']//div[contains(@class, 'treeViewCheckbox') and contains(@class, 'false')])[1]"));
        helper.scrollToElement(driver, typeContainer);
        Thread.sleep(2000);
        List<WebElement> totalGallopadeQuestionTypes = typeContainer.findElements(By.tagName("li"));

        System.out.println("Total question types are: " + totalGallopadeQuestionTypes.size());
        TestRunner.getTest().log(Status.INFO, "Total types of questions are: " + totalGallopadeQuestionTypes.size());

        if (typeContainer.isDisplayed() && typeContainer.isEnabled()) {
            WebElement btnMyQuestions = driver.findElement(By.xpath("//button[@value='myQuestions']"));
            if (btnMyQuestions.isEnabled()) {
                btnMyQuestions.click();

                WebElement typeMyQuestionContainer = driver.findElement(By.xpath("(//div[@aria-labelledby='Questions-header']//div[contains(@class, 'treeViewCheckbox') and contains(@class, 'false')])[2]"));
                helper.scrollToElement(driver, typeMyQuestionContainer);
                Thread.sleep(2000);
                List<WebElement> totalMyQuestionTypes = typeContainer.findElements(By.tagName("li"));

                System.out.println("Total question types are: " + totalMyQuestionTypes.size());
                TestRunner.getTest().log(Status.INFO, "Total types of questions are: " + totalMyQuestionTypes.size());
                boolean typeFound = false;
                for (WebElement type : totalMyQuestionTypes) {
                    String typeName = type.getText().trim();
                    if (typeName.equals(selectedQuestionType)) {
                        type.click();
                        TestRunner.getTest().log(Status.INFO, "Selected question type: {} " + selectedQuestionType );
                        typeFound = true;
                        break;
                    }
                }

                if (!typeFound) {
                    TestRunner.getTest().log(Status.FAIL, " Test Case Failed :Type '{}' not found in the list." +  selectedQuestionType);
                }

            } else {
                TestRunner.getTest().log(Status.FAIL, " Test Case Failed :The 'My Questions' button is not enabled.");
            }

            Thread.sleep(1000);
            btn_ApplyFilter.click();
        } else {
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed :Question container is not displayed or not enabled.");
        }
    }

    public void showsQuestionsIntoTable() throws InterruptedException {
        Thread.sleep(2000);
        try {
            WebElement questionsTable = wait.until(ExpectedConditions.visibilityOf(questionsRightTable));

            if (questionsTable != null) {
                List<WebElement> questionRows = questionsTable.findElements(By.xpath(".//tr"));

                if (!questionRows.isEmpty()) {
                    System.out.println("Questions found in the table:");

                    boolean allRowsProcessedSuccessfully = true;

                    for (int i = 0; i < questionRows.size(); i++) {
                        WebElement questionRow = questionRows.get(i);

                        int retryCount = 0;
                        boolean success = false;

                        while (retryCount < 3) {
                            try {
                                WebElement questionNameElement = questionRow.findElement(By.xpath(".//td[contains(@class, 'cell-0')]"));
                                questionName = questionNameElement.getText();
                                System.out.println("Questions Name: " + questionName);

                                List<WebElement> questionNameCells = questionRow.findElements(By.xpath(".//td"));
                                for (WebElement questionNameCell : questionNameCells) {
                                    System.out.print(questionNameCell.getText() + "\t");
                                }
                                System.out.println();

                                success = true;
                                break;

                            } catch (StaleElementReferenceException e) {
                                System.out.println("Stale element found, retrying...");

                                questionRows = questionsTable.findElements(By.xpath(".//tbody//tr"));

                                if (i >= questionRows.size()) {
                                    System.out.println("Row index " + i + " is out of bounds after refresh.");
                                    break;
                                }

                                questionRow = questionRows.get(i);
                                retryCount++;
                            } catch (NoSuchElementException e) {
                                System.out.println("Element not found in the row: " + e.getMessage());
                                break;
                            }
                        }

                        if (!success) {
                            System.out.println("Failed to retrieve question row after several attempts.");
                            allRowsProcessedSuccessfully = false;
                        }
                    }

                    if (allRowsProcessedSuccessfully) {
                        System.out.println("Test Case Passed: Question Shows Into Table Successfully");
                    } else {
                        System.out.println("Test Case Failed: One or more questions could not be processed.");
                    }
                } else {
                    System.out.println("Test Case Failed: No questions found in the table.");
                }
            } else {
                System.out.println("Test Case Failed: Questions table is not visible.");
            }
        } catch (TimeoutException e) {
            System.out.println("Test Case Failed: Timeout waiting for table to be visible or accessible. " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Test Case Failed: An unexpected error occurred. " + e.getMessage());
        }
    }

    public void searchQuestionByName(){
        WebElement right_panel= wait.until(ExpectedConditions.elementToBeClickable(editCustomAssessment));
        right_panel.isDisplayed();

        try {
            WebElement questionSearchBox = right_panel.findElement(By.xpath("//input[@placeholder='Search Question']"));
            if (questionSearchBox.isDisplayed() && questionSearchBox.isEnabled()) {
                questionSearchBox.click();
                questionSearchBox.clear();
                System.out.println("Looking for question name: " + questionTitle);
                ((JavascriptExecutor) driver).executeScript("arguments[0].value='';", questionSearchBox);
                searchQuestionByName = questionTitle;
                System.out.println("Searched question : " + searchQuestionByName);
                questionSearchBox.sendKeys(searchQuestionByName);

                Actions actions = new Actions(driver);
                actions.sendKeys(Keys.ENTER).perform();

                waitForTableToRefresh();
                TestRunner.getTest().log(Status.PASS, " Test Case Passed :Test Case Passed    : Search question Successfully");
            } else {
                System.out.println("Search box is not displayed.");
            }
        } catch (Exception e) {
            System.out.println("Search box is not available: " + e.getMessage());
        }
    }

    private void waitForTableToRefresh() {
        try {
            WebElement customQuestionTable = wait.until(ExpectedConditions.elementToBeClickable(customAssessmentQuestionTable));

            List<WebElement> rowsBeforeRefresh = customQuestionTable.findElements(By.xpath(".//tr"));

            Thread.sleep(2000);

            List<WebElement> rowsAfterRefresh = driver.findElements(By.xpath("(//div[contains(@class, 'editCustomAssessment')]//tbody)[2]//tr"));

            if (rowsBeforeRefresh.size() != rowsAfterRefresh.size()) {
                System.out.println("Table has refreshed. Number of rows before refresh: " + rowsBeforeRefresh.size() + ", after refresh: " + rowsAfterRefresh.size());
            } else {
                System.out.println("Table did not refresh as expected.");
            }

            for (WebElement row : rowsAfterRefresh) {
                System.out.println("Table Row: " + row.getText());
            }

        } catch (Exception e) {
            System.out.println("Error while waiting for table refresh: " + e.getMessage());
        }
    }

    public void verifySearchedQuestionByNameIntoTable(){
        if (questionName.contains(searchQuestionByName)){
            TestRunner.getTest().log(Status.PASS, " Test Case Passed :Test Case Passed    :    Searched question found Successfully");
        } else {
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed :Test Case Failed    :    Searched question not found and search filter not working");
        }
    }

    public void selectNewCustomQuestion() {
        WebElement checkbox = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(".//tbody//input[@type='checkbox']")));

        if (checkbox.isDisplayed() && checkbox.isEnabled()) {
            checkbox.click();
            TestRunner.getTest().log(Status.PASS, " Test Case Passed :Test Case Passed   :  Custom question checkbox selected successfully.");
        } else {
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed :Test Case Failed   :  Custom question checkbox is either not displayed or not enabled.");
        }
    }

    public void clickOnSaveNextButton() {
        if (saveNextButton.isDisplayed() && saveNextButton.isEnabled()) {
            saveNextButton.click();
            TestRunner.getTest().log(Status.PASS, " Test Case Passed :Test Case Passed    :  Custom question save button clicked");
        } else {
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed :Test Case Failed    :  Custom question save button is not displayed");
        }
    }

}
