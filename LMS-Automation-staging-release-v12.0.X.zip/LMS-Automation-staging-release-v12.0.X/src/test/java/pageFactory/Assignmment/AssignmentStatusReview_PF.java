package pageFactory.Assignmment;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.MyContent.AssignAssessment_PF;
import util.CommonUtil;
import util.ReleaseAssignmentInformation;

import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

import static util.CommonUtil.getDateConversion;

public class AssignmentStatusReview_PF {
    Helper helper;
    public WebDriverWait wait;
    WebDriver driver;

    TeacherAssignment_PF teacherAssignmentPF;
    AssignAssessment_PF assignAssessmentPF;
    ReleaseAssignment_PF releaseAssignmentPF;
    CorrectAnswerExecutor_PF correctAnswerExecutorPF;

    @FindBy(xpath = "//div[contains(@class, 'AssignmentWrapper')]")
    WebElement card_MyAssignment;

    String tab_AssignmentCard = "//div[@aria-label='wrapped label tabs example']";

    @FindBy(xpath = "//img[contains(@src, '/cardimage-vocabulary_quiz.png')]/ancestor::div[2]")
    WebElement rowCourseVQ;

    @FindBy(xpath = "//div[contains(@class, 'ScrollbarsCustom')]//div[contains(@class, 'ScrollbarsCustom-Content')]")
    WebElement scroll_Units;

    @FindBy(xpath = "//label[contains(text(),'Assign to')]/parent::div")
    WebElement dropDown_AssignTo;

    @FindBy(xpath = "//input[@name='isOpenToAnyStudent']")
    WebElement input_OpenToAnyStudent;

    @FindBy(xpath = "//label[contains(text(),'Select Students')]/following-sibling::div")
    WebElement dropDown_SelectStudent;

    @FindBy(xpath = "//div[@id='ContentPlayerMainPanel']")
    WebElement list_ContentPlayer;

    @FindBy(xpath = "//input[@name='title']")
    WebElement edt_AssignmentTitle;

    @FindBy(xpath = "//label[contains(text(),'Start Date & Time')]/following-sibling::div//input")
    WebElement calendar_StartDateTime;

    @FindBy(xpath = "//label[contains(text(),'End Date & Time')]/following-sibling::div//input")
    WebElement calendar_EndDateTime;


    public AssignmentStatusReview_PF(WebDriver driver) {
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        helper = new Helper();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        teacherAssignmentPF = new TeacherAssignment_PF(driver);
        assignAssessmentPF = new AssignAssessment_PF(driver);
        releaseAssignmentPF = new ReleaseAssignment_PF(driver);
        correctAnswerExecutorPF = new CorrectAnswerExecutor_PF(driver);
    }

    public void processAllUnitsAndAssignmentsForStatusVerification() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Release Assignment Type VQ For Status Verification");
        System.out.println("Release Assignment Type VQ For Status Verification");
        releaseAssignmentPF.selectUnitForReleaseAssignment();

        Thread.sleep(2000);
        WebElement listContentPlayer = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@id='ContentPlayerMainPanel']")));
        Thread.sleep(1000);

        if (listContentPlayer.isDisplayed() && listContentPlayer.isEnabled()) {
            WebElement btnAssignForSpecificAssignment = rowCourseVQ.findElement(By.xpath(".//button[normalize-space(text())='Assign']"));
            btnAssignForSpecificAssignment.click();

            WebElement dialogAssignment = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@role='dialog']")));
            if (dialogAssignment.isDisplayed()) {
                processAssignmentForRelease();
                TestRunner.getTest().log(Status.PASS,"Test Case Passed : Assignment Release Successfully");
            }
        }
    }

    public void processReleasedAssignmentFutureStatus() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Release Assignment Type VQ For Future Status Verification");
        System.out.println("Release Assignment Type VQ For Future Status Verification");
        releaseAssignmentPF.selectUnitForReleaseAssignment();

        Thread.sleep(2000);
        WebElement listContentPlayer = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@id='ContentPlayerMainPanel']")));
        Thread.sleep(1000);

        if (listContentPlayer.isDisplayed() && listContentPlayer.isEnabled()) {
            WebElement btnAssignForSpecificAssignment = rowCourseVQ.findElement(By.xpath(".//button[normalize-space(text())='Assign']"));
            btnAssignForSpecificAssignment.click();

            WebElement dialogAssignment = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@role='dialog']")));
            if (dialogAssignment.isDisplayed()) {
                processAssignmentReleaseForFutureStatus();
                TestRunner.getTest().log(Status.PASS,"Test Case Passed : Assignment Release Successfully");
            }
        }
    }

    private void processUnitToSelect(WebElement unit) throws InterruptedException{
        unit.click();
        System.out.println("Selected Unit: " + unit.getText());

        wait.until(ExpectedConditions.visibilityOf(list_ContentPlayer));
        List<WebElement> totalAssignments = list_ContentPlayer.findElements(By.xpath("//div[contains(@class, 'MuiBox-root')]//button[contains(text(), 'Assign')]"));

        if (!totalAssignments.isEmpty()) {
            for (WebElement assignment : totalAssignments) {
                processAssignmentForToday(assignment);
//                processAssignmentForRelease(assignment);
                break;
            }
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Assignment release for status verification successfully");

        }

//        for (WebElement assignment : totalAssignments) {
//            processAssignmentForRelease(assignment);
//            break;
//        }
    }

    private void processAssignmentForToday(WebElement assignment) throws InterruptedException {
        String assignmentButtonName = assignment.getText();
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", assignment);
        System.out.println("Clicked on 'Assign' button: " + assignmentButtonName);
        ReleaseAssignmentInformation releaseAssignmentInformation = new ReleaseAssignmentInformation();
        enterAssignmentDetailsForToday(releaseAssignmentInformation);
        selectAssignToAndStudentOptions();
        setDateTimeAndCategoryForToday(releaseAssignmentInformation);
        teacherAssignmentPF.enterAdditionalSettings();
        assignAssessmentPF.assignAssignment();
        assignAssessmentPF.verifyDialogBox();

        Date currentDate = new Date();
        Date startDate = releaseAssignmentInformation.getStart();
        Date endDate = releaseAssignmentInformation.getEnd();

        // Normalize dates to ignore time part
        Calendar calCurrent = Calendar.getInstance();
        calCurrent.setTime(currentDate);
        calCurrent.set(Calendar.HOUR_OF_DAY, 0);
        calCurrent.set(Calendar.MINUTE, 0);
        calCurrent.set(Calendar.SECOND, 0);
        calCurrent.set(Calendar.MILLISECOND, 0);
        Date normalizedCurrentDate = calCurrent.getTime();

        Calendar calStart = Calendar.getInstance();
        calStart.setTime(startDate);
        calStart.set(Calendar.HOUR_OF_DAY, 0);
        calStart.set(Calendar.MINUTE, 0);
        calStart.set(Calendar.SECOND, 0);
        calStart.set(Calendar.MILLISECOND, 0);
        Date normalizedStartDate = calStart.getTime();

        Calendar calEnd = Calendar.getInstance();
        calEnd.setTime(endDate);
        calEnd.set(Calendar.HOUR_OF_DAY, 0);
        calEnd.set(Calendar.MINUTE, 0);
        calEnd.set(Calendar.SECOND, 0);
        calEnd.set(Calendar.MILLISECOND, 0);
        Date normalizedEndDate = calEnd.getTime();

        // Set status based on normalized dates
        if (!normalizedCurrentDate.before(normalizedStartDate) && !normalizedCurrentDate.after(normalizedEndDate)) {
            releaseAssignmentInformation.setStatus("Start");
            releaseAssignmentInformation.setOpen(true);
            releaseAssignmentInformation.setToday(normalizedCurrentDate.equals(normalizedStartDate));
            releaseAssignmentInformation.setTomorrow(false);
            releaseAssignmentInformation.setClose(false);
        } else if (normalizedCurrentDate.after(normalizedEndDate)) {
            releaseAssignmentInformation.setStatus("LATE");
            releaseAssignmentInformation.setOpen(false);
            releaseAssignmentInformation.setToday(false);
            releaseAssignmentInformation.setTomorrow(false);
            releaseAssignmentInformation.setClose(true);
        } else {
            releaseAssignmentInformation.setStatus("FUTURE");
            releaseAssignmentInformation.setOpen(true);
            releaseAssignmentInformation.setToday(false);
            releaseAssignmentInformation.setTomorrow(true);
            releaseAssignmentInformation.setClose(false);
        }

        CommonUtil.writeJson(releaseAssignmentInformation);

    }

    private void enterAssignmentDetailsForToday(ReleaseAssignmentInformation releaseAssignmentInformation) throws InterruptedException {
        Thread.sleep(1000);
        EnterAssignmentTitleForToday(releaseAssignmentInformation);
    }

    private void EnterAssignmentTitleForToday(ReleaseAssignmentInformation releaseAssignmentInformation) {
        String existingAssignmentName = (String) ((JavascriptExecutor) driver).executeScript("return arguments[0].value;", edt_AssignmentTitle);
        System.out.println(" existing title " + existingAssignmentName);
        edt_AssignmentTitle.click();
        ((JavascriptExecutor) driver).executeScript("arguments[0].value='';", edt_AssignmentTitle);
        String assignmentTitle = generateAssignmentTitle(existingAssignmentName + "Automation Assignment ::" + new Date().getTime());
        System.out.println("Assignment name: " + assignmentTitle);
        Map<String, Long> assignmentNameMap = new HashMap<>();
        assignmentNameMap.put(assignmentTitle, new Date().getTime());
        releaseAssignmentInformation.setAssignmentId(assignmentTitle);
        releaseAssignmentInformation.setAssignmentName(assignmentTitle);
        edt_AssignmentTitle.sendKeys(assignmentTitle);
    }

    private void setDateTimeAndCategoryForToday(ReleaseAssignmentInformation releaseAssignmentInformation) throws InterruptedException {
        Thread.sleep(1000);
        String endDate = setEndDateAndTimeForToday(releaseAssignmentInformation);
        String startDate = setStartDateAndTimeForToday(releaseAssignmentInformation);


        Thread.sleep(1000);
        Date startConvertedDate = getDateConversion(startDate);
        Date endConvertedDate = getDateConversion(endDate);
        releaseAssignmentInformation.setEndDate(CommonUtil.convertToStudentWidgetDateFormate(endDate));
        releaseAssignmentInformation.setStartDate(CommonUtil.convertToStudentWidgetDateFormate(startDate));
        releaseAssignmentInformation.setStart(startConvertedDate);
        releaseAssignmentInformation.setEnd(endConvertedDate);
    }

    private String setStartDateAndTimeForToday(ReleaseAssignmentInformation releaseAssignmentInformation) {
        Calendar calendar = Calendar.getInstance();
        Date today = calendar.getTime(); // Get the current date and time

        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm");
        String startDateTime = dateFormat.format(today); // Format the current date and time
        System.out.println("Generated Start DateTime: " + startDateTime);

        calendar_StartDateTime.click();
        calendar_StartDateTime.sendKeys(startDateTime); // Set the current date and time
        return startDateTime;
    }

    private String setEndDateAndTimeForToday(ReleaseAssignmentInformation releaseAssignmentInformation) throws InterruptedException {
        LocalDateTime now = LocalDateTime.now();
        // Add 2 hours to the current date and time
        LocalDateTime endDateTime = now.plusHours(2);

        // Format the date and time as a string
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm");
        String formattedEndDateTime = endDateTime.format(formatter);

        System.out.println("Generated End DateTime: " + formattedEndDateTime);


        // Using JavaScript to clear and set the end date field and trigger change events
        JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
        String script = "var element = arguments[0];" +
                "var valueToSet = arguments[1];" +
                "element.value = valueToSet;" +
                "element.dispatchEvent(new Event('change'));" +
                "element.dispatchEvent(new Event('input', { bubbles: true }));";
        System.out.println(jsExecutor.executeScript(script, calendar_EndDateTime, formattedEndDateTime));

        String value = calendar_EndDateTime.getAttribute("value");
        System.out.println("Question ID is: " + value);

//        jsExecutor.executeScript("arguments[0].dispatchEvent(new Event('change', { bubbles: true }))", calendar_EndDateTime);

        return formattedEndDateTime;

    }

    private void processAssignmentForRelease() throws InterruptedException {
        ReleaseAssignmentInformation releaseAssignmentInformation = new ReleaseAssignmentInformation();
        enterAssignmentDetails(releaseAssignmentInformation);
        correctAnswerExecutorPF.selectSpecificClasses();
        setDateTimeAndCategory(releaseAssignmentInformation);
        assignAssessmentPF.enterAdditionalSettings();
        assignAssessmentPF.enterWeightPercentage();
        assignAssessmentPF.assignAssignment();
        Date currentDate = new Date();
        if(releaseAssignmentInformation.getStart().before(currentDate) && releaseAssignmentInformation.getEnd().after(currentDate)) {
            releaseAssignmentInformation.setStatus("Start");
            releaseAssignmentInformation.setOpen(true);
            releaseAssignmentInformation.setToday(false);
            releaseAssignmentInformation.setTomorrow(true);
            releaseAssignmentInformation.setClose(false);
        } else if(releaseAssignmentInformation.getEnd().before(currentDate)) {
            releaseAssignmentInformation.setStatus("LATE");
            releaseAssignmentInformation.setOpen(false);
            releaseAssignmentInformation.setToday(false);
            releaseAssignmentInformation.setTomorrow(false);
            releaseAssignmentInformation.setClose(true);
        }else if(releaseAssignmentInformation.getStart().after(currentDate)){
            releaseAssignmentInformation.setStatus("FUTURE");
            releaseAssignmentInformation.setOpen(true);
            releaseAssignmentInformation.setToday(false);
            releaseAssignmentInformation.setTomorrow(true);
            releaseAssignmentInformation.setClose(false);
        }
        CommonUtil.writeJson( releaseAssignmentInformation);
        assignAssessmentPF.verifyDialogBox();
        TestRunner.getTest().log(Status.PASS, "Test Case Passed: All Information write in File Successfully");
    }

    private void processAssignmentReleaseForFutureStatus() throws InterruptedException {
        ReleaseAssignmentInformation releaseAssignmentInformation = new ReleaseAssignmentInformation();
        enterAssignmentDetails(releaseAssignmentInformation);
        correctAnswerExecutorPF.selectSpecificClasses();
        setFutureDateTimeAndCategory(releaseAssignmentInformation);
        assignAssessmentPF.enterAdditionalSettingsWithFutureStatus();
        assignAssessmentPF.enterWeightPercentage();
        assignAssessmentPF.assignAssignment();
        Date currentDate = new Date();
        if(releaseAssignmentInformation.getStart().before(currentDate) && releaseAssignmentInformation.getEnd().after(currentDate)) {
            releaseAssignmentInformation.setStatus("Start");
            releaseAssignmentInformation.setOpen(true);
            releaseAssignmentInformation.setToday(false);
            releaseAssignmentInformation.setTomorrow(true);
            releaseAssignmentInformation.setClose(false);
        } else if(releaseAssignmentInformation.getEnd().before(currentDate)) {
            releaseAssignmentInformation.setStatus("LATE");
            releaseAssignmentInformation.setOpen(false);
            releaseAssignmentInformation.setToday(false);
            releaseAssignmentInformation.setTomorrow(false);
            releaseAssignmentInformation.setClose(true);
        }else if(releaseAssignmentInformation.getStart().after(currentDate)){
            releaseAssignmentInformation.setStatus("FUTURE");
            releaseAssignmentInformation.setOpen(true);
            releaseAssignmentInformation.setToday(false);
            releaseAssignmentInformation.setTomorrow(true);
            releaseAssignmentInformation.setClose(false);
        }
        CommonUtil.writeJson( releaseAssignmentInformation);
        assignAssessmentPF.verifyDialogBox();
        TestRunner.getTest().log(Status.PASS, "Test Case Passed: All Information write in File Successfully");
    }

    private void enterAssignmentDetails(ReleaseAssignmentInformation releaseAssignmentInformation) throws InterruptedException {
        Thread.sleep(1000);
        EnterAssignmentTitle(releaseAssignmentInformation);
    }

    public void selectAssignToAndStudentOptions() throws InterruptedException {
        Thread.sleep(1000);
        select_AssignTo();
//        Thread.sleep(1000);
//        teacherAssignmentPF.OpenToAnyStudentToggle();
//        Thread.sleep(1000);
//        select_Student();
    }

    private void select_AssignTo() {
        dropDown_AssignTo.click();

        WebElement assign_to = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[normalize-space()='FL Grade 5']")));
        helper.scrollToElement(driver, assign_to);

//        wait.until(ExpectedConditions.elementToBeClickable(assign_to));
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", assign_to);

        // Simulate pressing the ESC key
        Actions actions = new Actions(driver);
        actions.sendKeys(Keys.ESCAPE).build().perform();
    }

    private void select_Student() throws InterruptedException{
        dropDown_SelectStudent.click();
        Thread.sleep(1000);


        List<WebElement> SelectStudentOptions = dropDown_SelectStudent.findElements(By.xpath("//ul[@role='listbox']//input"));

        if (SelectStudentOptions.isEmpty()) {
            System.out.println("No students found in the selected class. Changing class in AssignTo dropdown.");
            select_AssignTo();
        } else {
            selectSpecificValuesFromDropdown(SelectStudentOptions);

            // Pressing the ESC key
            Actions actions = new Actions(driver);
            actions.sendKeys(Keys.ESCAPE).build().perform();
        }
    }

    private void selectSpecificValuesFromDropdown(List<WebElement> options) {
        if (options.size() >= 3) {
            WebElement thirdStudent = options.get(2);
            thirdStudent.click();
            System.out.println("Third student selected: " + thirdStudent.getText());
        } else {
            System.out.println("Not enough students in the dropdown to select the third student.");
        }
    }

    private void setDateTimeAndCategory(ReleaseAssignmentInformation releaseAssignmentInformation) throws InterruptedException {
        Thread.sleep(1000);
        String startDate = setStartDateAndTime(releaseAssignmentInformation);
        String endDate = setEndDateAndTime(releaseAssignmentInformation);

        Thread.sleep(1000);
        teacherAssignmentPF.checkBoxLateSub();
        Thread.sleep(1000);
        teacherAssignmentPF.select_category();
        Date startConvertedDate =getDateConversion(startDate);
        Date endConvertedDate =getDateConversion(endDate);
        releaseAssignmentInformation.setEndDate(CommonUtil.convertToStudentWidgetDateFormate(endDate));
        releaseAssignmentInformation.setStartDate(CommonUtil.convertToStudentWidgetDateFormate(startDate));
        releaseAssignmentInformation.setStart(startConvertedDate);
        releaseAssignmentInformation.setEnd(endConvertedDate);
    }

    private void setFutureDateTimeAndCategory(ReleaseAssignmentInformation releaseAssignmentInformation) throws InterruptedException {
        Thread.sleep(1000);
        String startDate = setFutureStartDateAndTime(releaseAssignmentInformation);
        String endDate = setEndDateAndTime(releaseAssignmentInformation);
        Thread.sleep(1000);
        teacherAssignmentPF.checkBoxLateSub();
        Thread.sleep(1000);
        teacherAssignmentPF.select_category();
        Date startConvertedDate =getDateConversion(startDate);
        Date endConvertedDate =getDateConversion(endDate);
        releaseAssignmentInformation.setEndDate(CommonUtil.convertToStudentWidgetDateFormate(endDate));
        releaseAssignmentInformation.setStartDate(CommonUtil.convertToStudentWidgetDateFormate(startDate));
        releaseAssignmentInformation.setStart(startConvertedDate);
        releaseAssignmentInformation.setEnd(endConvertedDate);
    }

    private void EnterAssignmentTitle(ReleaseAssignmentInformation releaseAssignmentInformation){
        String existingAssignmentName = (String) ((JavascriptExecutor) driver).executeScript("return arguments[0].value;", edt_AssignmentTitle);
        System.out.println(" existing title " + existingAssignmentName);
        edt_AssignmentTitle.click();
        ((JavascriptExecutor) driver).executeScript("arguments[0].value='';", edt_AssignmentTitle);
        String assignmentTitle = generateAssignmentTitle( existingAssignmentName + "Automation::" + new Date().getTime());
        System.out.println("Assignment name: " + assignmentTitle);
        Map<String, Long> assignmentNameMap = new HashMap<>();
        assignmentNameMap.put(assignmentTitle, new Date().getTime());
        releaseAssignmentInformation.setAssignmentId(assignmentTitle);
        releaseAssignmentInformation.setAssignmentName(assignmentTitle);
        edt_AssignmentTitle.sendKeys(assignmentTitle);
    }

    private String setStartDateAndTime(ReleaseAssignmentInformation releaseAssignmentInformation) {
        Calendar calendar = Calendar.getInstance();
        Date randomStartDate = calendar.getTime();

        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm");
        String startDateTime = dateFormat.format(randomStartDate);
        System.out.println("Generated Start DateTime: " + startDateTime);

        calendar_StartDateTime.click();
        calendar_StartDateTime.sendKeys(startDateTime);
        return startDateTime;
    }

    private String setFutureStartDateAndTime(ReleaseAssignmentInformation releaseAssignmentInformation) {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_YEAR, 1);
        Date futureStartDate = calendar.getTime();

        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm");
        String startDateTime = dateFormat.format(futureStartDate);
        System.out.println("Generated Start DateTime (Tomorrow): " + startDateTime);

        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].value = arguments[1];", calendar_StartDateTime, startDateTime);

        return startDateTime;
    }

    private String setEndDateAndTime(ReleaseAssignmentInformation releaseAssignmentInformation) {
        String startDateTime = setStartDateAndTime(releaseAssignmentInformation);
        String endDateTime = helper.generateEndDateTime(startDateTime);
        System.out.println("Generated End DateTime: " + endDateTime);

        calendar_EndDateTime.click();
        calendar_EndDateTime.sendKeys(endDateTime);
        return endDateTime;
    }

    private String generateAssignmentTitle(String prefix) {
        String characters = "ABC123456789";
        StringBuilder randomTitle = new StringBuilder();
        Random random = new Random();
        int length = 4;
        randomTitle.append(prefix);
        for (int i = 0; i < length; i++) {
            randomTitle.append(characters.charAt(random.nextInt(characters.length())));
        }
        return randomTitle.toString();
    }

    public void searchAssignmentInAllTabs() throws InterruptedException {
        ReleaseAssignmentInformation releaseAssignmentInformation = CommonUtil.readJsonFromFile();
        System.out.println(releaseAssignmentInformation.toString());

        card_MyAssignment.isDisplayed();
        WebElement tab_Assignment = card_MyAssignment.findElement(By.xpath(tab_AssignmentCard));
        tab_Assignment.click();

        String releaseAssignmentName = releaseAssignmentInformation.getAssignmentName().trim();
        String releaseAssignmentDate = releaseAssignmentInformation.getStartDate().trim();
        String expectedStatus = releaseAssignmentInformation.getStatus().trim();

        Boolean is_open = releaseAssignmentInformation.getOpen();
        Boolean in_today = releaseAssignmentInformation.getToday();
        Boolean in_tomorrow = releaseAssignmentInformation.getTomorrow();
        Boolean in_closed = releaseAssignmentInformation.getClose();

        System.out.println("Assignment is expected in Tab:\n" +
                "Open tab: " + is_open + "\n" +
                "Today Tab: " + in_today + "\n" +
                "Tomorrow Tab: " + in_tomorrow + "\n" +
                "Close Tab: " + in_closed);

        List<WebElement> AssignmentTabs = tab_Assignment.findElements(By.xpath(".//button"));

        for (WebElement AssignmentTab : AssignmentTabs) {
            String tabText = AssignmentTab.getText();
            TestRunner.getTest().log(Status.INFO, "Assignment Tab Text: " + tabText);
            System.out.println("Assignment Tab Text: " + tabText);

            AssignmentTab.click();
            Thread.sleep(5000);

            List<WebElement> totalAssignments = card_MyAssignment.findElements(By.xpath(".//div[contains(@class, 'MuiGrid-container')]"));
            System.out.println("Total Assignments: " + totalAssignments.size());
            Thread.sleep(5000);

            boolean assignmentFound = false;

            for (WebElement assignment : totalAssignments) {
                WebElement assignmentNameElement = assignment.findElement(By.xpath(".//div[contains(@class, 'notranslate')]"));
                String assignmentName = assignmentNameElement.getText().trim();

                if (assignmentName.equals(releaseAssignmentName)) {
                    System.out.println("Found assignment: " + assignmentName + " start date: " + releaseAssignmentDate +
                            " Assignment found in Tab: " + tabText);

                    TestRunner.getTest().log(Status.INFO, "Found assignment: " + assignmentName + " start date: " + releaseAssignmentDate +
                            " Assignment found in Tab: " + tabText);

                    WebElement fulldetails = assignment.findElement(By.xpath(".//div[contains(@class, 'dateContainer')]"));
                    String data = fulldetails.getText();
                    System.out.println("data is " + data);
                    TestRunner.getTest().log(Status.INFO, "Details of Assignment: " + data);

                    String startDate = extractStartDate(data); // e.g., "Start: 04:08 PM 2025-06-02"
                    String dateTimeString = startDate.split(": ", 2)[1].trim();

                    // Clean both strings before comparison
                    String cleanedDateTime = dateTimeString.toUpperCase().replaceAll("\\s+", " ").trim();
                    String cleanedReleaseDate = releaseAssignmentDate.toUpperCase().replaceAll("\\s+", " ").trim();

                    System.out.println("Cleaned DateTime from UI: [" + cleanedDateTime + "]");
                    System.out.println("Cleaned Release Date: [" + cleanedReleaseDate + "]");

                    TestRunner.getTest().log(Status.INFO, "DateTime: " + cleanedDateTime);
                    TestRunner.getTest().log(Status.INFO, "Date at Time Of Release: " + cleanedReleaseDate);

                    if (cleanedDateTime.equals(cleanedReleaseDate)) {
                        System.out.println("Date match");
                        TestRunner.getTest().log(Status.INFO, "Date match: " + cleanedReleaseDate);

                        WebElement startOrResumeButton = assignment.findElement(By.xpath(".//div[@statustype='START' or @statustype='RESUME']"));
                        String statusText = startOrResumeButton.getText().trim();

                        System.out.println("The expected status of the assignment is: " + expectedStatus);
                        TestRunner.getTest().log(Status.INFO, "The expected status of the assignment is: " + expectedStatus);

                        if (statusText.equalsIgnoreCase(expectedStatus)) {
                            System.out.println("Status match");
                            TestRunner.getTest().log(Status.INFO, "Assignment Status: " + statusText + " and expected status: " + expectedStatus);
                            TestRunner.getTest().log(Status.PASS, "Test Case Passed : Assignment Status Match Successfully");

                            // Optionally start the assignment
                            // startOrResumeButton.click();
                            Thread.sleep(3000);
                        } else {
                            System.out.println("Status not match");
                            TestRunner.getTest().log(Status.FAIL, "Status mismatch: Found - " + statusText + ", Expected - " + expectedStatus);
                        }
                    } else {
                        System.out.println("Date not match");
                        TestRunner.getTest().log(Status.FAIL, "Date mismatch: Found - " + cleanedDateTime + ", Expected - " + cleanedReleaseDate);
                    }
                    assignmentFound = true;
                    break;
                } else {
                    System.out.println("Assignment not found: " + assignmentName);
                }
            }

            if (assignmentFound) {
                break;
            }
        }
    }

    public static String extractStartDate(String data) {
        String searchString = "Start: ";
        int startIndex = data.indexOf(searchString);

        if (startIndex != -1) {
            int endIndex = data.indexOf("Due: ", startIndex);
            if (endIndex == -1) {
                endIndex = data.length();
            }
            return data.substring(startIndex, endIndex).trim();
        } else {
            return "Start date not found";
        }
    }

}
