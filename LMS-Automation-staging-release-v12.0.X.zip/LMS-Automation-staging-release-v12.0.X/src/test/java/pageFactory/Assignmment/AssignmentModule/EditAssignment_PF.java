package pageFactory.Assignmment.AssignmentModule;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import static pageFactory.Assignmment.ScenarioAdvanceGradings_PF.*;

public class EditAssignment_PF {
    public WebDriverWait wait;
    WebDriver driver;

    Helper helper;

    List<Double> currentWeights = new ArrayList<>();
    List<Double> currentPercentages = new ArrayList<>();

    public EditAssignment_PF(WebDriver driver) {
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(100));
        helper = new Helper();
    }

    public void editAssignmentScenarioGradeMainToggleButton() throws InterruptedException {
        Thread.sleep(2000);
        System.out.println("I'm in to verify and edit advanced gradings");
        TestRunner.getTest().log(Status.INFO, "Verify and edit advanced gradings");

        try {
            WebElement panelAdvanceGradings = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@id='panel2bh-header']")));
            if (panelAdvanceGradings.isDisplayed() && panelAdvanceGradings.isEnabled()) {
                panelAdvanceGradings.click();
            }

            WebElement panelContent = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("panel2bh-content")));

            WebElement mainGradeToggle = panelContent.findElement(By.xpath("//label[span//h6[contains(text(), 'GRADE')]]//input[@type='checkbox']"));

            // Verify the toggle state
            if (!mainGradeToggle.isSelected()) {
                System.out.println("Main Grade toggle is OFF as expected.");
                TestRunner.getTest().log(Status.PASS, "Main Grade toggle is OFF as expected in edit mode.");
            } else {
                System.out.println("Error: Main Grade toggle is ON, but it was set OFF during release.");
                TestRunner.getTest().log(Status.FAIL, "Main Grade toggle is ON in edit mode, but it should be OFF.");
            }

            WebElement wrapperTable = panelContent.findElement(By.xpath("//div[contains(@class, 'Wrapper')]//table//tbody"));
            List<WebElement> rows = wrapperTable.findElements(By.tagName("tr"));

            for (int i = 0; i < rows.size(); i++) {
                WebElement row = rows.get(i);
                List<WebElement> cells = row.findElements(By.tagName("td"));

                if (cells.size() >= 3) {
                    WebElement weightInput = cells.get(1).findElement(By.tagName("input"));
                    WebElement percentageInput = cells.get(2).findElement(By.tagName("input"));

                    double currentWeight = Double.parseDouble(weightInput.getAttribute("value"));
                    double currentPercentage = Double.parseDouble(percentageInput.getAttribute("value"));

                    currentWeights.add(currentWeight);
                    currentPercentages.add(currentPercentage);

                    // Verify Weight
                    if (currentWeight == updatedWeights.get().get(i)) {
                        System.out.println("Weight matches for row " + (i + 1));
                        TestRunner.getTest().log(Status.PASS, "Weight matches for row " + (i + 1));
                    } else {
                        System.out.println("Weight mismatch for row " + (i + 1) + ". Expected: " + updatedWeights.get().get(i) + ", Found: " + currentWeight);
                        TestRunner.getTest().log(Status.FAIL, "Weight mismatch for row " + (i + 1) + ". Expected: " + updatedWeights.get().get(i) + ", Found: " + currentWeight);
                    }

                    // Verify Percentage
                    if (currentPercentage == updatedPercentages.get().get(i)) {
                        System.out.println("Percentage matches for row " + (i + 1));
                        TestRunner.getTest().log(Status.PASS, "Percentage matches for row " + (i + 1));
                    } else {
                        System.out.println("Percentage mismatch for row " + (i + 1) + ". Expected: " + updatedPercentages.get().get(i) + ", Found: " + currentPercentage);
                        TestRunner.getTest().log(Status.FAIL, "Percentage mismatch for row " + (i + 1) + ". Expected: " + updatedPercentages.get().get(i) + ", Found: " + currentPercentage);
                    }
                } else {
                    System.out.println("Error: Row " + (i + 1) + " does not contain enough cells.");
                    TestRunner.getTest().log(Status.FAIL, "Row " + (i + 1) + " does not contain enough cells.");
                }
            }

            // Log the previous weights and percentages for comparison
            System.out.println("Stored Weights: " + updatedWeights);
            System.out.println("Stored Percentages: " + updatedPercentages);
            TestRunner.getTest().log(Status.INFO, "Stored Weights: " + updatedWeights.toString());
            TestRunner.getTest().log(Status.INFO, "Stored Percentages: " + updatedPercentages.toString());

            // Log the current weights and percentages
            System.out.println("Current Weights: " + currentWeights);
            System.out.println("Current Percentages: " + currentPercentages);
            TestRunner.getTest().log(Status.INFO, "Current Weights: " + currentWeights.toString());
            TestRunner.getTest().log(Status.INFO, "Current Percentages: " + currentPercentages.toString());

        } catch (Exception e) {
            e.printStackTrace();
            TestRunner.getTest().log(Status.FAIL, "Error encountered while verifying and editing advanced gradings.");
        }
    }

    public void editAssignmentScenarioParticularQuestionsToggleVerification() throws InterruptedException {
        Thread.sleep(2000);
        System.out.println("Verifying advanced gradings in edit assignment.");
        TestRunner.getTest().log(Status.INFO, "Verifying advanced gradings in edit assignment.");

        try {
            WebElement panelAdvanceGradings = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@id='panel2bh-header']")));
            if (panelAdvanceGradings.isDisplayed() && panelAdvanceGradings.isEnabled()) {
                panelAdvanceGradings.click();
            }

            WebElement panelContent = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("panel2bh-content")));

            WebElement wrapperTable = panelContent.findElement(By.xpath("//div[contains(@class, 'Wrapper')]//table//tbody"));
            List<WebElement> rows = wrapperTable.findElements(By.tagName("tr"));
            System.out.println("Total rows: " + rows.size());

            for (int i = 0; i < rows.size(); i++) {
                WebElement row = rows.get(i);
                List<WebElement> cells = row.findElements(By.tagName("td"));

                WebElement toggle = row.findElement(By.xpath(".//input[@type='checkbox']"));
                WebElement weightInput = cells.get(1).findElement(By.tagName("input"));
                WebElement percentageInput = cells.get(2).findElement(By.tagName("input"));

                double currentWeight = Double.parseDouble(weightInput.getAttribute("value"));
                double currentPercentage = Double.parseDouble(percentageInput.getAttribute("value"));

                currentWeights.add(currentWeight);
                currentPercentages.add(currentPercentage);

                String questionStatus;

                if (disabledIndices.get().contains(i + 1)) {
                    if (!toggle.isSelected()) {
                        questionStatus = "Toggle is correctly OFF for question " + (i + 1);
                        System.out.println(questionStatus);
                        TestRunner.getTest().log(Status.PASS, questionStatus);
                    } else {
                        questionStatus = "Error: Toggle is ON for question " + (i + 1) + " but should be OFF.";
                        System.out.println(questionStatus);
                        TestRunner.getTest().log(Status.FAIL, questionStatus);
                    }
                } else {
                    boolean weightMatches = currentWeight == updatedWeights.get().get(i);
                    boolean percentageMatches = currentPercentage == updatedPercentages.get().get(i);

                    if (weightMatches && percentageMatches) {
                        questionStatus = "Question " + (i + 1) + ": weight matches '" + currentWeight + "' : '" + updatedWeights.get().get(i) + "' and percentage matches '" + currentPercentage + "' : '" + updatedPercentages.get().get(i) + "'";
                        System.out.println(questionStatus);
                        TestRunner.getTest().log(Status.PASS, questionStatus);
                    } else {
                        if (!weightMatches) {
                            questionStatus = "Question " + (i + 1) + ": Weight mismatch. Expected: '" + updatedWeights.get().get(i) + "', Found: '" + currentWeight + "'";
                            System.out.println(questionStatus);
                            TestRunner.getTest().log(Status.FAIL, questionStatus);
                        }
                        if (!percentageMatches) {
                            questionStatus = "Question " + (i + 1) + ": Percentage mismatch. Expected: '" + updatedPercentages.get().get(i) + "', Found: '" + currentPercentage + "'";
                            System.out.println(questionStatus);
                            TestRunner.getTest().log(Status.FAIL, questionStatus);
                        }
                    }
                }
            }

            // Log the stored and current weights and percentages
            System.out.println("Stored Weights: " + updatedWeights);
            System.out.println("Stored Percentages: " + updatedPercentages);
            TestRunner.getTest().log(Status.INFO, "Stored Weights: " + updatedWeights.toString());
            TestRunner.getTest().log(Status.INFO, "Stored Percentages: " + updatedPercentages.toString());

            System.out.println("Current Weights: " + currentWeights);
            System.out.println("Current Percentages: " + currentPercentages);
            TestRunner.getTest().log(Status.INFO, "Current Weights: " + currentWeights.toString());
            TestRunner.getTest().log(Status.INFO, "Current Percentages: " + currentPercentages.toString());

        } catch (Exception e) {
            e.printStackTrace();
            TestRunner.getTest().log(Status.FAIL, "Error encountered while verifying and editing advanced gradings.");
        }
    }

    public void editAssignmentScenarioDistributeWeightEvenlyVerification() throws InterruptedException {
        Thread.sleep(2000);
        System.out.println("Verifying weights and percentages in the edit assignment.");
        TestRunner.getTest().log(Status.INFO, "Verifying weights and percentages in the edit assignment.");

        try {
            WebElement panelAdvanceGradings = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@id='panel2bh-header']")));
            if (panelAdvanceGradings.isDisplayed() && panelAdvanceGradings.isEnabled()) {
                panelAdvanceGradings.click();
            }

            WebElement panelContent = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("panel2bh-content")));

            WebElement wrapperTable = panelContent.findElement(By.xpath("//div[contains(@class, 'Wrapper')]//table//tbody"));
            List<WebElement> rows = wrapperTable.findElements(By.tagName("tr"));
            System.out.println("Total rows: " + rows.size());

            for (int i = 0; i < rows.size(); i++) {
                WebElement row = rows.get(i);
                List<WebElement> cells = row.findElements(By.tagName("td"));

                WebElement toggle = row.findElement(By.xpath(".//input[@type='checkbox']"));
                WebElement weightInput = cells.get(1).findElement(By.tagName("input"));
                WebElement percentageInput = cells.get(2).findElement(By.tagName("input"));

                double currentWeight = Double.parseDouble(weightInput.getAttribute("value"));
                double currentPercentage = Double.parseDouble(percentageInput.getAttribute("value"));

                currentWeights.add(currentWeight);
                currentPercentages.add(currentPercentage);

                boolean weightMatches = currentWeight == updatedWeights.get().get(i);
                boolean percentageMatches = currentPercentage == updatedPercentages.get().get(i);

                String questionStatus;

                if (disabledIndices.get().contains(i + 1)) {
                    if (!toggle.isSelected()) {
                        questionStatus = "Toggle is correctly OFF for question " + (i + 1);
                        System.out.println(questionStatus);
                        TestRunner.getTest().log(Status.PASS, questionStatus);
                    } else {
                        questionStatus = "Error: Toggle is ON for question " + (i + 1) + " but should be OFF.";
                        System.out.println(questionStatus);
                        TestRunner.getTest().log(Status.FAIL, questionStatus);
                    }
                } else {
                    if (weightMatches && percentageMatches) {
                        questionStatus = "Question " + (i + 1) + ": weight matches '" + currentWeight + "' : '" + updatedWeights.get().get(i) + "' and percentage matches '" + currentPercentage + "' : '" + updatedPercentages.get().get(i) + "'";
                        System.out.println(questionStatus);
                        TestRunner.getTest().log(Status.PASS, questionStatus);
                    } else {
                        if (!weightMatches) {
                            questionStatus = "Question " + (i + 1) + ": Weight mismatch. Expected: '" + updatedWeights.get().get(i) + "', Found: '" + currentWeight + "'";
                            System.out.println(questionStatus);
                            TestRunner.getTest().log(Status.FAIL, questionStatus);
                        }
                        if (!percentageMatches) {
                            questionStatus = "Question " + (i + 1) + ": Percentage mismatch. Expected: '" + updatedPercentages.get().get(i) + "', Found: '" + currentPercentage + "'";
                            System.out.println(questionStatus);
                            TestRunner.getTest().log(Status.FAIL, questionStatus);
                        }
                    }
                }
            }

            // Log the stored and current weights and percentages
            System.out.println("Stored Weights: " + updatedWeights);
            System.out.println("Stored Percentages: " + updatedPercentages);
            TestRunner.getTest().log(Status.INFO, "Stored Weights: " + updatedWeights.toString());
            TestRunner.getTest().log(Status.INFO, "Stored Percentages: " + updatedPercentages.toString());

            System.out.println("Current Weights: " + currentWeights);
            System.out.println("Current Percentages: " + currentPercentages);
            TestRunner.getTest().log(Status.INFO, "Current Weights: " + currentWeights.toString());
            TestRunner.getTest().log(Status.INFO, "Current Percentages: " + currentPercentages.toString());

        } catch (Exception e) {
            e.printStackTrace();
            TestRunner.getTest().log(Status.FAIL, "Error encountered while verifying weights and percentages in edit assignment.");
        }
    }

    public void verifyToggleButtonBehaviorInEditAssignment() throws InterruptedException {
        Thread.sleep(2000);
        TestRunner.getTest().log(Status.INFO, "Verifying toggle button behavior in Edit Assignment.");
        System.out.println("Verifying toggle button behavior in Edit Assignment.");

        try {

            WebElement panelAdvanceGradings = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@id='panel2bh-header']")));
            if (panelAdvanceGradings.isDisplayed() && panelAdvanceGradings.isEnabled()) {
                panelAdvanceGradings.click();
            }

            WebElement mainGradeToggle = driver.findElement(By.xpath("(//input[@name='isOpenToAnyStudent'])[2]"));

            List<WebElement> questionToggles = driver.findElements(By.xpath("//tbody//input[@type='checkbox']"));

            WebElement distributeWeightCheckbox = driver.findElement(By.xpath("//label[span[contains(text(), 'Distribute Weight evenly')]]//input[@type='checkbox']"));

            if (mainGradeToggle.isSelected()) {
                mainGradeToggle.click();
            }

            Thread.sleep(1000);

            boolean allQuestionTogglesOff = true;
            for (WebElement questionToggle : questionToggles) {
                if (questionToggle.isSelected()) {
                    allQuestionTogglesOff = false;
                    break;
                }
            }

            if (allQuestionTogglesOff) {
                System.out.println("Main Grade toggle is off, and all question toggles are off.");
                TestRunner.getTest().log(Status.PASS, "Main Grade toggle is off, and all question toggles are off.");
            } else {
                System.out.println("Error: Main Grade toggle is off, but some question toggles are still on.");
                TestRunner.getTest().log(Status.FAIL, "Main Grade toggle is off, but some question toggles are still on.");
            }

            WebElement firstQuestionToggle = questionToggles.get(0);
            firstQuestionToggle.click();

            Thread.sleep(1000);

            if (mainGradeToggle.isSelected()) {
                System.out.println("First question toggle turned on, and Main Grade toggle turned on automatically.");
                TestRunner.getTest().log(Status.PASS, "First question toggle turned on, and Main Grade toggle turned on automatically.");
            } else {
                System.out.println("Error: First question toggle turned on, but Main Grade toggle did not turn on.");
                TestRunner.getTest().log(Status.FAIL, "First question toggle turned on, but Main Grade toggle did not turn on.");
            }

            for (WebElement questionToggle : questionToggles) {
                if (questionToggle.isSelected()) {
                    questionToggle.click();
                }
            }

            Thread.sleep(1000);

            if (!mainGradeToggle.isSelected()) {
                System.out.println("All question toggles are off, and Main Grade toggle turned off automatically.");
                TestRunner.getTest().log(Status.PASS, "All question toggles are off, and Main Grade toggle turned off automatically.");
            } else {
                System.out.println("Error: All question toggles are off, but Main Grade toggle did not turn off.");
                TestRunner.getTest().log(Status.FAIL, "All question toggles are off, but Main Grade toggle did not turn off.");
            }

            if (!mainGradeToggle.isSelected() && !distributeWeightCheckbox.isEnabled()) {
                System.out.println("Main Grade toggle is off, and Distribute Weight Evenly checkbox is disabled.");
                TestRunner.getTest().log(Status.PASS, "Main Grade toggle is off, and Distribute Weight Evenly checkbox is disabled.");
            } else {
                System.out.println("Error: Main Grade toggle is off, but Distribute Weight Evenly checkbox is still enabled.");
                TestRunner.getTest().log(Status.FAIL, "Main Grade toggle is off, but Distribute Weight Evenly checkbox is still enabled.");
            }

        } catch (Exception e) {
            e.printStackTrace();
            TestRunner.getTest().log(Status.FAIL, "Error encountered while verifying toggle button behavior in Edit Assignment.");
        }
    }

}
