package pageFactory.Assignmment.AssignmentModule;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import lombok.Getter;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Assignmment.CorrectAnswerExecutor_PF;

import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import static pageFactory.Assignmment.CorrectAnswerExecutor_PF.BASE_NAME;
import static pageFactory.Assignmment.CorrectAnswerExecutor_PF.assignmentNameForCorrect;

public class AssignmentModuleEdit_PF {
    WebDriverWait wait;
    WebDriver driver;
    Helper helper;
    Actions actions;

    public String editStartDate;

    public String editDueDate;
    public String updatedStartDate;
    public String updatedStartDateForSpecificStudent;
    public String updatedEndDateForSpecificStudent;
    public static String selectedEditAssignmentSpecificCategory;
    public String updatedDueDate;

    final String selectedGroupName = Configurations.getDotEnv().get("SITE_SELECTED_GROUP");
    final String groupStudentName = Configurations.getDotEnv().get("SITE_SELECTED_GROUP_STUDENT");

    @FindBy(xpath = "//label[text()='Select Group']/following-sibling::div//div[@role='button' or @role='combobox']")
    WebElement dropDown_GroupInGradeBook;

    @FindBy(xpath = "//ul[@role='listbox']")
    WebElement list_Group;

    @FindBy(xpath = "//div[contains(@class, 'applyDataGrid')]")
    WebElement panel_EditSpecificStudentAssignment;

    public AssignmentModuleEdit_PF(WebDriver driver) {
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        helper = new Helper();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        actions = new Actions(driver);

    }

    public void SearchAssignmentByNameInAssignmentModuleForEdit() throws InterruptedException {
        System.out.println("Search Assignment is: " + CorrectAnswerExecutor_PF.assignmentNameForCorrect.get());

        WebElement right_panel = driver.findElement(By.xpath("//div[@class='right-panel']"));
        right_panel.isDisplayed();

        try {
            WebElement searchBox = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder='Search by name or keyword']")));
            if (searchBox.isDisplayed()) {
                searchBox.click();
                searchBox.clear();
                ((JavascriptExecutor) driver).executeScript("arguments[0].value='';", searchBox);
                Thread.sleep(2000);

                String assignmentNameForCorrect = CorrectAnswerExecutor_PF.assignmentNameForCorrect.get();
                System.out.println("Search by Assignment name: " + assignmentNameForCorrect);
                searchBox.sendKeys(assignmentNameForCorrect);

                TestRunner.getTest().log(Status.INFO, "Search Assignment is: " + assignmentNameForCorrect);
                System.out.println("Search Assignment is: " + assignmentNameForCorrect);
                Actions actions = new Actions(driver);
                actions.sendKeys(Keys.ENTER).perform();


                TestRunner.getTest().log(Status.PASS, "Testcase Passed   :   Enter Search Assignment keyword Successfully");

                waitForTableToRefresh();
            } else {
                System.out.println("Search box is not displayed.");
                TestRunner.getTest().log(Status.FAIL, "Testcase Failed   : Search box is not displayed.");
//                throw new RuntimeException("Search Box not  Found.");
            }
        } catch (Exception e) {
            System.out.println("Search box is not available: " + e.getMessage());
        }
    }

    private void waitForTableToRefresh() {

//        WebElement firstDiv = driver.findElement(By.xpath("//div[contains(@class, 'left-content-header')]/div[contains(@class, 'MuiBox-root')]/div[1]"));
//        System.out.println("TAssessment able has refreshed.");

        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class, 'left-content-header')]/div[contains(@class, 'MuiBox-root')]/div[1]")));

        System.out.println("Assessment Table has refreshed.");
        TestRunner.getTest().log(Status.PASS, "Testcase Passed : Assessment Table has refreshed");


    }

    @Getter
    private String AssignmentNameBeforeEdit; // Class-level variable to store the assignment name

    public void verifySearchedAssessmentInAssignmentModuleByNameIntoTableForEdit() {
//        String assignmentNameForCorrect = CorrectAnswerExecutor_PF.assignmentNameForCorrect.get();
        System.out.println("Want to search assignment into table: " + assignmentNameForCorrect.get());
        TestRunner.getTest().log(Status.INFO, "Want to search assignment into table: " + assignmentNameForCorrect.get());

        WebElement assignmentName = driver.findElement(By.xpath("//div[contains(@class, 'left-content-header')]/div[contains(@class, 'MuiBox-root')]//div"));
        System.out.println("After search Assignment size: " + assignmentName);
        TestRunner.getTest().log(Status.INFO, "After search Assignment size: " + assignmentName.getSize());

        String actualAssignmentName = assignmentName.getText();
        System.out.println("Assignment name in Table: " + actualAssignmentName);
        TestRunner.getTest().log(Status.INFO, "Assignment name in Table: " + actualAssignmentName);

        // Store the assignment name for later use
        AssignmentNameBeforeEdit = actualAssignmentName;
        TestRunner.getTest().log(Status.INFO, "Stored Assignment Name: " + AssignmentNameBeforeEdit);

        if (actualAssignmentName.equalsIgnoreCase(assignmentNameForCorrect.get())) {
            System.out.println("Searched Assessment found: " + actualAssignmentName + " matches with " + assignmentNameForCorrect.get());
            TestRunner.getTest().log(Status.INFO, "Searched Assessment found: " + actualAssignmentName + " matches with " + assignmentNameForCorrect.get());
            TestRunner.getTest().log(Status.PASS, "Testcase Passed: Search Assessment by keyword successfully.");
        } else {
            System.out.println("Searched Assessment not found, and the search filter is not working.");
            TestRunner.getTest().log(Status.FAIL, "Testcase Failed: Searched Assessment not found, and the search filter is not working.");
        }
    }

    private String storedStartDate;
    private String storedDueDate;

    public void GetStartAndDueDateOfAssignment() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into Get start and End Date of Assignment ");
        System.out.println("I'm into Get start and End Date of Assignment ");

        WebElement startDateElement = driver.findElement(By.xpath("//div[@class='startDate MuiBox-root css-coabys']"));
        String startDateBeforeEdit = startDateElement.getText().replace("Start:", "").trim(); // Remove the "Start:" label and trim spaces
        System.out.println("Start Date before Edit: " + startDateBeforeEdit);

        WebElement dueDateElement = driver.findElement(By.xpath("//div[@class='DueDate MuiBox-root css-0']/span"));
        String dueDateBeforeEdit = dueDateElement.getText().replace("Due:", "").trim(); // Remove the "Due:" label and trim spaces
        System.out.println("Due Date before Edit: " + dueDateBeforeEdit);

        storedStartDate = startDateBeforeEdit;
        storedDueDate = dueDateBeforeEdit;

        System.out.println("Stored Start Date: " + storedStartDate);
        System.out.println("Stored Due Date: " + storedDueDate);

        TestRunner.getTest().log(Status.INFO, "Stored Start Date: " + storedStartDate);
        TestRunner.getTest().log(Status.INFO, "Stored Due Date: " + storedDueDate);

    }

    public void ClickOnEditIconAssignmentModule() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into Click on Edit Button for Assignment:  " + assignmentNameForCorrect.get());
        System.out.println("I'm into Click on Edit Button for Assignment:  " + assignmentNameForCorrect.get());

        WebElement editIcon = driver.findElement(By.xpath("//div[contains(@class,'DueDate MuiBox-root')]//span[contains(@class, 'EditIcon')]"));

        if (editIcon.isDisplayed()) {
            editIcon.click();
            System.out.println("Clicked on the Edit icon successfully.");
            TestRunner.getTest().log(Status.INFO, "Clicked on the Edit icon successfully.");
            TestRunner.getTest().log(Status.PASS, "Clicked on the Edit icon successfully.");
        } else {
            TestRunner.getTest().log(Status.FAIL, "Edit Button not Display and not Clicked");
        }

    }

    public void EditScreenTitle() throws InterruptedException {
        System.out.println("I'm into Get Edit Screen Title  ");
        TestRunner.getTest().log(Status.INFO, "I'm into Get Edit Screen Title ");

        WebElement mainHeading = driver.findElement(By.xpath("//div[@class='header-container']//span[contains(@class, 'main-heading')]"));

        String headingText = mainHeading.getText();
        System.out.println("Main Heading: " + headingText);
        TestRunner.getTest().log(Status.INFO, "Main Heading: " + headingText);

        WebElement viewAllButton = driver.findElement(By.xpath("//div[@class='header-container']//button[contains(@class, 'view-all')]"));

        String buttonText = viewAllButton.getText();
        System.out.println("Button Text: " + buttonText);
        TestRunner.getTest().log(Status.INFO, "Button Text: " + buttonText);

    }

    private String EditAssignmentName;

    public void EditAssignmentTitleOnEditScreen() throws InterruptedException {
        System.out.println("I'm into Edit Assignment Title");
        TestRunner.getTest().log(Status.INFO, "I'm into Edit Assignment Title ");

        // Wait until the element is visible
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement edt_AssignmentTitle = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//label[text()='Assignment Title']/following-sibling::div//input[@type='text']")));

        Thread.sleep(3000);
        // Get the old title
        String oldTitle = edt_AssignmentTitle.getAttribute("value");
        System.out.println("Old Title: " + oldTitle);
        TestRunner.getTest().log(Status.INFO, "Assignment Previous Title: " + oldTitle);
        edt_AssignmentTitle.click();


        Actions actions = new Actions(driver);
        for (int i = 0; i < oldTitle.length(); i++) {
            actions.sendKeys(Keys.BACK_SPACE).perform();
        }

        ((JavascriptExecutor) driver).executeScript("arguments[0].value='';", edt_AssignmentTitle);
        Thread.sleep(1000);

        // Set the thread-local variable with a unique assignment name
        String newAssignmentName = BASE_NAME + "_Edt_" + new Date();
        EditAssignmentName = setAssignmentName(newAssignmentName);
        System.out.println("Edit Assignment name is: " + EditAssignmentName);

        // Enter the new title
        edt_AssignmentTitle.sendKeys(EditAssignmentName);

        System.out.println("Enter Assignment Title Successfully: " + EditAssignmentName);
        TestRunner.getTest().log(Status.INFO, "Assignment Title edit successfully: " + EditAssignmentName);
    }


    public static String setAssignmentName(String assignmentName) {
        assignmentNameForCorrect.set(assignmentName);
        return assignmentName;
    }


    public void OpenToAnyStudentUncheckCheckbox() throws InterruptedException {
        // Log the action
        System.out.println("I'm into Uncheck Open to Any Student Toggle");
        TestRunner.getTest().log(Status.INFO, "I'm into Uncheck Open to Any Student Toggle");

        WebElement openToAnyStudentToggle = driver.findElement(By.xpath("//div[contains(@class, 'editAssignment-main')]//input[@name='isOpenToAnyStudent'][1]"));

        openToAnyStudentToggle.click();
        Thread.sleep(2000);

    }

    public void verifyOpenToAnyStudentUncheckToggle() throws InterruptedException {
        System.out.println("Verifying 'Open to Any Student' toggle is Off and enabling it if needed");
        TestRunner.getTest().log(Status.INFO, "Verifying 'Open to Any Student' toggle is Off and enabling it if needed");

        WebElement openToAnyStudentToggle = driver.findElement(By.xpath("//div[contains(@class, 'editAssignment-main')]//input[@name='isOpenToAnyStudent'][1]"));

        boolean isSelected = openToAnyStudentToggle.isSelected();

        if (!isSelected) {
            System.out.println("Toggle is currently OFF. Turning it ON...");
            TestRunner.getTest().log(Status.INFO, "Toggle is currently OFF. Turning it ON...");

            openToAnyStudentToggle.click();

            try {
                WebElement modal = wait.until(ExpectedConditions.visibilityOfElementLocated(
                        By.xpath("//div[contains(@class, 'MuiDialog-paper') and @role='dialog']")
                ));

                WebElement messageElement = modal.findElement(By.xpath(".//h2[contains(@class,'MuiTypography-subtitle')]"));
                String modalMessage = messageElement.getText();

                System.out.println("Modal message: " + modalMessage);
                TestRunner.getTest().log(Status.INFO, "Modal message: " + modalMessage);

                WebElement yesButton = modal.findElement(By.xpath(".//button[normalize-space()='Yes']"));
                yesButton.click();

                Thread.sleep(2000);
            } catch (TimeoutException te) {
                System.out.println("Timeout waiting for the confirmation modal.");
                TestRunner.getTest().log(Status.WARNING, "Timeout waiting for the confirmation modal: " + te.getMessage());
            }
        } else {
            System.out.println("Toggle is already ON. No action needed.");
            TestRunner.getTest().log(Status.INFO, "Toggle is already ON. No action needed.");
        }
    }

    public void StartDateEdit() throws InterruptedException {
        System.out.println("I'm into Edit Start date");
        TestRunner.getTest().log(Status.INFO, "I'm into Edit Start Date");

        WebElement girdDate = driver.findElement(By.xpath("//div[contains(@class, 'editAssignment-top')]"));
        girdDate.isDisplayed();

        // Generate the start date-time value
        editStartDate = generateStartDateTime();
        System.out.println("Generated Start DateTime: " + editStartDate);
        TestRunner.getTest().log(Status.INFO, "Set assignment start datetime: " + editStartDate);

        // Simulate user input directly with the generated full date-time string
        simulateUserInput(girdDate, "//label[contains(text(),'Start Date & Time')]/following-sibling::div//input", editStartDate);

        // Wait for changes to reflect
        Thread.sleep(3000);

        // Verify updated value
        updatedStartDate = driver.findElement(By.xpath("//label[contains(text(),'Start Date & Time')]/following-sibling::div//input"))
                .getAttribute("value");
        System.out.println("Updated Start Date: " + updatedStartDate);
        TestRunner.getTest().log(Status.INFO, "Updated Start Date: " + updatedStartDate);

    }


    public void DueDateEdit() throws InterruptedException {
        System.out.println("I'm into Edit Due date");
        TestRunner.getTest().log(Status.INFO, "I'm into Edit Due Date");

        WebElement girdDate = driver.findElement(By.xpath("//div[contains(@class, 'editAssignment-top')]"));
        girdDate.isDisplayed();

        editDueDate = generateEndDateTime(editStartDate);
        System.out.println("Generated End DateTime: " + editDueDate);
        TestRunner.getTest().log(Status.INFO, "Set assignment end datetime: " + editDueDate);

        simulateUserInput(girdDate, "//label[contains(text(),'End Date & Time')]/following-sibling::div//input", editDueDate);

        // Wait for changes to reflect
        Thread.sleep(2000);

        // Verify updated value
        updatedDueDate = driver.findElement(By.xpath("//label[contains(text(),'End Date & Time')]/following-sibling::div//input"))
                .getAttribute("value");
        System.out.println("Updated Due Date: " + updatedDueDate);
        TestRunner.getTest().log(Status.INFO, "Updated Due Date: " + updatedDueDate);

    }

    public void uncheckAllowLateSubmission() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm Into Uncheck Allow Late Submission Checkbox");
        System.out.println("I'm Into Uncheck Allow Late Submission Checkbox");

        // Locate the checkbox element
        WebElement checkbox = driver.findElement(By.xpath("//span[@title='Allow late submission']/input"));

// Check if the checkbox is already unchecked
        if (!checkbox.isSelected()) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Allow Late Submission Checkbox is already unchecked");
        } else {
            // Uncheck the checkbox
            checkbox.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Allow Late Submission Checkbox Unchecked Successfully");
        }

    }

    public void VerifyStudentListingOnEditScreen() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm Into Validate That Student Listing is also Present on Edit Assignment");
        System.out.println("I'm Into Validate that Student Listing is also present on Edit Assignment");


        WebElement student_listing = driver.findElement(By.xpath("//div[contains(@class, 'paper') and contains(@class, 'editAssignment-bottom')]//div[contains(@class, 'header-container')]"));
        helper.scrollToElement(driver, student_listing);
        Thread.sleep(200);

        List<WebElement> rows = driver.findElements(By.xpath("//div[@role='row' and not(@aria-rowindex='1')]"));

        if (!rows.isEmpty()) {
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Student Listing Rows are displayed in the table.");
        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Student Listing Rows are not displayed in the table.");
        }
    }

    public void VerifyStudentListingOnEditScreenInGroup() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Validating that Student Listing is present on Edit Assignment in Group");
        System.out.println("Validating that Student Listing is present on Edit Assignment in Group");

        TestRunner.getTest().log(Status.INFO, "I'm in to select the group in 'GradeBook'");
        wait.until(ExpectedConditions.elementToBeClickable(dropDown_GroupInGradeBook));

        if (dropDown_GroupInGradeBook.isEnabled()) {
            dropDown_GroupInGradeBook.click();
            TestRunner.getTest().log(Status.INFO, "Groups dropdown clicked successfully");

            WebElement groupDropdown = wait.until(ExpectedConditions.elementToBeClickable(list_Group));
            List<WebElement> groupsList = groupDropdown.findElements(By.xpath(".//li"));

            if (groupsList.isEmpty()) {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : No group available in the dropdown list");
            } else {
                boolean groupsFound = false;
                TestRunner.getTest().log(Status.INFO, "Want to select the group " + selectedGroupName);
                for (WebElement groupList : groupsList) {
                    String groupText = groupList.getText().trim();
                    if (groupText.equalsIgnoreCase(selectedGroupName)) {
                        groupList.click();
                        TestRunner.getTest().log(Status.PASS, "Test Case Passed : Group selected " + groupText);
                        groupsFound = true;
                        this.waitForStudentTableIsRefreshed();
                        this.foundStudentInGroup();
                        break;
                    }
                }
                if (!groupsFound) {
                    TestRunner.getTest().log(Status.FAIL, "Test Case Failed : '" + selectedGroupName + "' not found in the dropdown list");
                }
            }

        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : Groups dropdown is not enabled.");
        }
    }

    public void foundStudentInGroup() throws InterruptedException {
        WebElement student_listing = driver.findElement(By.xpath("//div[contains(@class, 'paper') and contains(@class, 'editAssignment-bottom')]//div[contains(@class, 'header-container')]"));
        helper.scrollToElement(driver, student_listing);
        Thread.sleep(200);

        List<WebElement> rows = driver.findElements(By.xpath("//div[@role='row' and not(@aria-rowindex='1')]"));

        boolean foundStudent = false;
        List<String> allStudents = new ArrayList<>();

        for (WebElement row : rows) {
            try {
                WebElement studentNameElement = row.findElement(By.xpath(".//div[@data-field='name']//h6"));
                String studentName = studentNameElement.getText().trim();
                allStudents.add(studentName);
                System.out.println("Student: " + studentName);
                TestRunner.getTest().log(Status.INFO, "Student: " + studentName);
                if (studentName.equalsIgnoreCase(groupStudentName)) {
                    foundStudent = true;
                    WebElement checkbox = row.findElement(By.xpath(".//div[contains(@class,'MuiDataGrid-cellCheckbox')]//input[@type='checkbox']"));
                    ((JavascriptExecutor) driver).executeScript("arguments[0].click();", checkbox);
                    TestRunner.getTest().log(Status.PASS, "Checkbox selected for student: " + groupStudentName);
                    Thread.sleep(500);
                }
            } catch (NoSuchElementException e) {
                System.out.println("Student name not found in a row.");
            }
        }

        if (!rows.isEmpty()) {
            TestRunner.getTest().log(Status.PASS, "Student rows are displayed in the table.");
        } else {
            TestRunner.getTest().log(Status.FAIL, "No student rows are displayed in the table.");
        }

        if (foundStudent) {
            TestRunner.getTest().log(Status.PASS, groupStudentName + " is present in the student list and checkbox clicked.");

            WebElement selectedStudentUpdate = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class, 'applyDataGrid')]")));

            // Verify bulk edit panel enabled
            WebElement bulkEditPanel = selectedStudentUpdate.findElement(By.xpath(".//span[contains(text(),'Students Have been Selected')]"));
            if (bulkEditPanel.isDisplayed()) {
                TestRunner.getTest().log(Status.PASS, "Bulk edit panel enabled after selecting student checkbox.");
            } else {
                TestRunner.getTest().log(Status.FAIL, "Bulk edit panel NOT enabled after selecting student checkbox.");
            }

        } else {
            TestRunner.getTest().log(Status.FAIL, groupStudentName + " is NOT found in the student list.");
        }
    }

    public void editStartDateSpecificStudent() throws InterruptedException {
        System.out.println("I'm into Edit Start date for specific student");
        TestRunner.getTest().log(Status.INFO, "Edit Start Date for Specific Student");

        try {
            helper.scrollToElement(driver, panel_EditSpecificStudentAssignment);

            WebElement bulkEditPanelStartDate = driver.findElement(By.xpath("//div[contains(@class, 'applyDataGrid')]"));
            bulkEditPanelStartDate.isDisplayed();

            // Generate the start date-time value
            editStartDate = generateStartDateTime();
            System.out.println("Generated Start DateTime: " + editStartDate);
            TestRunner.getTest().log(Status.INFO, "Set assignment start datetime: " + editStartDate);

            // Simulate user input
            simulateUserInput(bulkEditPanelStartDate, "//div[contains(@class, 'applyDataGrid')]//div[@data-field = 'startDate']//input", editStartDate);

            // Wait for changes to reflect
            Thread.sleep(3000);

            // Verify updated value
            updatedStartDateForSpecificStudent = driver.findElement(By.xpath("//div[contains(@class, 'applyDataGrid')]//div[@data-field = 'startDate']//input"))
                    .getAttribute("value");
            System.out.println("Updated Start Date For Specific Student: " + updatedStartDateForSpecificStudent);
            TestRunner.getTest().log(Status.PASS, "Updated Start Date For Specific Student: " + updatedStartDateForSpecificStudent);
        } catch (Exception e) {
            System.out.println("Exception while editing start date: " + e.getMessage());
            TestRunner.getTest().log(Status.FAIL, "Exception while editing start date: " + e.getMessage());
        }
    }

    public void editEndDateSpecificStudent() throws InterruptedException {
        Thread.sleep(500);
        System.out.println("I'm into Edit End date for specific student");
        TestRunner.getTest().log(Status.INFO, "Edit End date for specific student");

        try {
            WebElement bulkEditPanelEndDate = driver.findElement(By.xpath("//div[contains(@class, 'applyDataGrid')]"));
            bulkEditPanelEndDate.isDisplayed();

            editDueDate = generateEndDateTime(editStartDate);
            System.out.println("Generated End DateTime: " + editDueDate);
            TestRunner.getTest().log(Status.INFO, "Set assignment end datetime: " + editDueDate);

            simulateUserInput(bulkEditPanelEndDate, "//div[contains(@class, 'applyDataGrid')]//div[@data-field = 'endDate']//input", editDueDate);

            // Wait for changes to reflect
            Thread.sleep(2000);

            // Verify updated value
            updatedEndDateForSpecificStudent = driver.findElement(By.xpath("//div[contains(@class, 'applyDataGrid')]//div[@data-field = 'endDate']//input"))
                    .getAttribute("value");
            System.out.println("Updated End Date For Specific Student: " + updatedEndDateForSpecificStudent);
            TestRunner.getTest().log(Status.PASS, "Updated End Date For Specific Student: " + updatedEndDateForSpecificStudent);
        } catch (Exception e) {
            System.out.println("Exception while editing end date: " + e.getMessage());
            TestRunner.getTest().log(Status.FAIL, "Exception while editing end date: " + e.getMessage());
        }
    }

    public void editCategorySpecificStudent() throws InterruptedException {
        Thread.sleep(500);
        System.out.println("I'm into Edit Category for specific student");
        TestRunner.getTest().log(Status.INFO, "Navigating to Edit Category for specific student");

        try {
            WebElement dropDownSelectCategorySpecificStudent = panel_EditSpecificStudentAssignment.findElement(By.xpath("//label[contains(text(),'SelectTextFields')]/following-sibling::div"));
            dropDownSelectCategorySpecificStudent.click();

            WebElement list_Categories = wait.until(
                    ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[@role='listbox']"))
            );

            if (list_Categories.isDisplayed()) {
                List<WebElement> assignmentCategoryOptions = list_Categories.findElements(By.xpath(".//li"));
                boolean categoryFound = false;

                for (WebElement option : assignmentCategoryOptions) {
                    String optionText = option.getText().trim();
                    if (optionText.equalsIgnoreCase("Review Graded Submission")) {
                        selectedEditAssignmentSpecificCategory = optionText;
                        option.click();
                        System.out.println("Selected Category: " + selectedEditAssignmentSpecificCategory);
                        TestRunner.getTest().log(Status.PASS, "Category Selected: " + selectedEditAssignmentSpecificCategory);
                        categoryFound = true;
                        break;
                    }
                }

                if (!categoryFound) {
                    System.out.println("Category 'Review Graded Submission' not found in the list.");
                    TestRunner.getTest().log(Status.FAIL, "Category 'Review Graded Submission' not found in the list.");
                }
            } else {
                System.out.println("Category list is not displayed.");
                TestRunner.getTest().log(Status.FAIL, "Category list is not displayed.");
            }
        } catch (Exception e) {
            System.out.println("Exception occurred while selecting category: " + e.getMessage());
            TestRunner.getTest().log(Status.FAIL, "Exception occurred while selecting category: " + e.getMessage());
        }
    }

    public void applyEditInfoSpecificStudent() throws InterruptedException {
        Thread.sleep(500);
        System.out.println("I'm into Click on ApplyEditInfoSpecificStudent Button on Edit Screen");
        TestRunner.getTest().log(Status.INFO, "I'm into Click on ApplyEditInfoSpecificStudent Button on Edit Screen");

        WebElement Apply_btn_On_Edit = panel_EditSpecificStudentAssignment.findElement(By.xpath("//button[normalize-space()='Apply']"));

        if (Apply_btn_On_Edit.isDisplayed()) {
            Apply_btn_On_Edit.click();
            System.out.println("Apply button click successfully");
            TestRunner.getTest().log(Status.PASS, "Apply button click successfully");
        } else {
            TestRunner.getTest().log(Status.FAIL, "Apply button Not found/Display");
        }
    }

    private void waitForStudentTableIsRefreshed() {
        try {
            WebElement tableStudents = wait.until(ExpectedConditions.presenceOfElementLocated(
                    By.xpath("//div[@role='row' and not(@aria-rowindex='1')]")));

            wait.until(ExpectedConditions.stalenessOf(tableStudents));

            // Wait for either data rows OR the "No student found" message
            WebDriverWait shortWait = new WebDriverWait(driver, Duration.ofSeconds(5));
            try {
                shortWait.until(ExpectedConditions.or(
                        ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[contains(text(), 'No student found')]"))
                ));

                System.out.println("Table has refreshed.");
                TestRunner.getTest().log(Status.INFO, "Table has refreshed.");
            } catch (TimeoutException e) {
                System.out.println("Table data not found.");
                TestRunner.getTest().log(Status.FAIL, "Table data not found.");
            }

        } catch (TimeoutException e) {
            System.out.println("Table did not refresh properly.");
            TestRunner.getTest().log(Status.FAIL, "Table did not refresh properly.");
        }
    }

    public void simulateUserInput(WebElement parentElement, String xpath, String value) {
        WebElement element = parentElement.findElement(By.xpath(xpath));

        // Clear any existing text and type the new value
        element.sendKeys(value);  // Directly send the new value
    }


    public String generateStartDateTime() {
        Calendar calendar = Calendar.getInstance();

        // Add 1 day to the current date
        calendar.add(Calendar.DAY_OF_MONTH, 1);

        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy, hh:mm a");
        return dateFormat.format(calendar.getTime());
    }

    public String generateEndDateTime(String startDateTime) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy, hh:mm a");

        try {
            Date startDate = dateFormat.parse(startDateTime);

            Calendar calendar = Calendar.getInstance();
            calendar.setTime(startDate);
            calendar.add(Calendar.MONTH, 1);

            return dateFormat.format(calendar.getTime());
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }

    public void SaveInfoForEdit() throws InterruptedException {
        System.out.println("I'm into Click on Save Button on Edit Screen");
        TestRunner.getTest().log(Status.INFO, "I'm into Click on Save Button on Edit Screen");

        WebElement Save_btn_On_Edit = driver.findElement(By.xpath("//button[normalize-space()='Save']"));
        helper.scrollToElement(driver, Save_btn_On_Edit);

        if (Save_btn_On_Edit.isDisplayed()) {
            Save_btn_On_Edit.click();
            System.out.println("Save button click successfully");
            TestRunner.getTest().log(Status.PASS, "Save button click successfully");
        } else {
            TestRunner.getTest().log(Status.FAIL, "Save button Not found/Display");
        }
    }

    public void ScrollToViewAll() throws InterruptedException {
        System.out.println("I'm into Scroll to ViewAll");
        TestRunner.getTest().log(Status.INFO, "I'm into Scroll to ViewAll");

        WebElement View_All = driver.findElement(By.xpath("//button[normalize-space()='View All']"));
        helper.scrollToElement(driver, View_All);
        Thread.sleep(5000);
    }

    public void SearchAssignmetAfterEditWithPreviousTitle() throws InterruptedException {
        System.out.println("Validate and Search Assignment In Assignments Module for After Edit with Previous Title: " + AssignmentNameBeforeEdit);
        TestRunner.getTest().log(Status.INFO, "Validate and Search Assignment In Assignments Module for After Edit with Previous Title: " + AssignmentNameBeforeEdit);


        WebElement right_panel = driver.findElement(By.xpath("//div[@class='right-panel']"));
        right_panel.isDisplayed();

        try {
            WebElement searchBox = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder='Search by name or keyword']")));
            if (searchBox.isDisplayed()) {
                searchBox.click();
                searchBox.clear();
                ((JavascriptExecutor) driver).executeScript("arguments[0].value='';", searchBox);
                Thread.sleep(2000);

                String PreviousAssignmentName = AssignmentNameBeforeEdit;
                System.out.println("Search by Assignment name: " + PreviousAssignmentName);
                searchBox.sendKeys(PreviousAssignmentName);

                TestRunner.getTest().log(Status.INFO, "Search Assignment With Previous Title is: " + PreviousAssignmentName);
                System.out.println("Search Assignment With Previous Title is:: " + PreviousAssignmentName);
                Actions actions = new Actions(driver);
                actions.sendKeys(Keys.ENTER).perform();


                TestRunner.getTest().log(Status.PASS, "Testcase Passed   :   Enter Search Assignment keyword Successfully");

                WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(60));  // 30 seconds wait

                WebElement endOfListMessage = wait.until(ExpectedConditions.visibilityOfElementLocated(
                        By.xpath("//p[contains(text(), 'There are no assignments for the selected class.')]")
                ));

                if (endOfListMessage.isDisplayed()) {
                    System.out.println("Previous Title " + PreviousAssignmentName + " change successful, There are no assignments for the selected class.");
                    TestRunner.getTest().log(Status.PASS, "Previous Title " + PreviousAssignmentName + " change successful, There are no assignments for the selected class.");
                } else {
                    System.out.println("Title Not change " + PreviousAssignmentName + ", assignment still found in the list.");
                    TestRunner.getTest().log(Status.FAIL, "Title Not change " + PreviousAssignmentName + ", assignment still found in the list.");
                }

            } else {
                System.out.println("Search box is not displayed.");
                TestRunner.getTest().log(Status.FAIL, "Testcase Failed   : Search box is not displayed.");
//                throw new RuntimeException("Search Box not  Found.");
            }
        } catch (Exception e) {
            System.out.println("Search box is not available: " + e.getMessage());
        }
    }

    public void SearchAssignmentWithEditTitle() throws InterruptedException {
        System.out.println("Validate and Search Assignment In Assignments Module for After Edit with Edit Title: " + EditAssignmentName);
        TestRunner.getTest().log(Status.INFO, "Validate and Search Assignment In Assignments Module for After Edit with Edit Title: " + EditAssignmentName);

        System.out.println("Search Assignment is: " + EditAssignmentName);

        WebElement right_panel = driver.findElement(By.xpath("//div[@class='right-panel']"));
        right_panel.isDisplayed();

        try {
            WebElement searchBox = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder='Search by name or keyword']")));
            if (searchBox.isDisplayed()) {
                searchBox.click();
                searchBox.clear();
                ((JavascriptExecutor) driver).executeScript("arguments[0].value='';", searchBox);
                Thread.sleep(2000);

                String assignmentNameForCorrect = EditAssignmentName;
                System.out.println("Search by Assignment name: " + assignmentNameForCorrect);
                searchBox.sendKeys(assignmentNameForCorrect);

                TestRunner.getTest().log(Status.INFO, "Search Assignment is: " + assignmentNameForCorrect);
                System.out.println("Search Assignment is: " + assignmentNameForCorrect);
                Actions actions = new Actions(driver);
                actions.sendKeys(Keys.ENTER).perform();


                TestRunner.getTest().log(Status.PASS, "Testcase Passed   :   Enter Search Assignment keyword Successfully");

                waitForTableToRefresh();
            } else {
                System.out.println("Search box is not displayed.");
                TestRunner.getTest().log(Status.FAIL, "Testcase Failed   : Search box is not displayed.");
//                throw new RuntimeException("Search Box not  Found.");
            }
        } catch (Exception e) {
            System.out.println("Search box is not available: " + e.getMessage());
        }

    }

    public void ValidateEditTitleExist() throws InterruptedException {
        System.out.println("Want to search assignment with edit title into table: " + EditAssignmentName);
        TestRunner.getTest().log(Status.INFO, "Want to search assignment with edit title into table: " + EditAssignmentName);

        WebElement assignmentName = driver.findElement(By.xpath("//div[contains(@class, 'left-content-header')]/div[contains(@class, 'MuiBox-root')]//div"));
        System.out.println("After search Assignment size: " + assignmentName);
        TestRunner.getTest().log(Status.INFO, "After search Assignment size: " + assignmentName.getSize());

        String actualAssignmentName = assignmentName.getText();
        System.out.println("Assignment name in Table: " + actualAssignmentName);
        TestRunner.getTest().log(Status.INFO, "Assignment name in Table: " + actualAssignmentName);

        if (actualAssignmentName.equalsIgnoreCase(EditAssignmentName)) {
            System.out.println("Searched Assessment found: " + actualAssignmentName + " matches with " + EditAssignmentName);
            TestRunner.getTest().log(Status.INFO, "Searched Assessment found: " + actualAssignmentName + " matches with " + EditAssignmentName);
            TestRunner.getTest().log(Status.PASS, "Testcase Passed: Search Assessment by keyword successfully.");
        } else {
            System.out.println("Searched Assessment not found, and the search filter is not working.");
            TestRunner.getTest().log(Status.FAIL, "Testcase Failed: Searched Assessment not found, and the search filter is not working.");
        }
    }


    public void OpenToAnyStudentOnAssignmentDisable() throws InterruptedException {
        System.out.println("I'm into Validate Open to Any Student Toggle is Uncheck on Assignment Module");
        TestRunner.getTest().log(Status.INFO, "I'm into Validate Open to Any Student Toggle is Uncheck on Assignment Module");


        // Wait for the checkbox to be visible on the other screen
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
        WebElement checkboxOnOtherScreen = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("(//label[contains(@for, 'SingleCheckBox-SingleCheckBox')]//span[contains(@title, 'Open to any Students')])[2]")
        ));

        boolean isDisabled = checkboxOnOtherScreen.getAttribute("disabled") != null ||
                checkboxOnOtherScreen.getAttribute("aria-disabled").equalsIgnoreCase("true");

        if (isDisabled) {
            System.out.println("Checkbox is disabled on the Assignment Module.");
            TestRunner.getTest().log(Status.PASS, "Checkbox is disabled on the Assignment Module.");
        } else {
            System.out.println("Checkbox is NOT disabled on the Assignment Module.");
            TestRunner.getTest().log(Status.FAIL, "Checkbox is NOT disabled on the Assignment Module.");
        }

    }

    public void VerifyStartDatAlsoUpdateOnAssignment() throws InterruptedException {
        System.out.println("I'm into Validate Start Date Also Update on Assignment Module");
        TestRunner.getTest().log(Status.INFO, "I'm into Validate Start Date Also Update on Assignment Module");


        List<WebElement> assignmentNameStartDate = driver.findElements(By.xpath("//div[contains(@class, 'content-footer-left')]//div[contains(@class,'startDate')]"));

        if (assignmentNameStartDate.isEmpty()) {
            System.out.println("Start date element not found on the page.");
            return;
        }

        String extractedText = assignmentNameStartDate.get(0).getText();
        System.out.println("Extracted Text: " + extractedText);

// Extract the date portion (remove "Start: " and any extra spaces)
        String extractedStartDate = extractedText.replace("Start: ", "").trim();
        System.out.println("Extracted Start Date: " + extractedStartDate);

// Format the extracted start date to match the format of editStartDate
        String formattedExtractedDate = formatExtractedDate(extractedStartDate);
        System.out.println("Formatted Extracted Start Date: " + formattedExtractedDate);

// Reformat updatedStartDate to match the extracted start date's format
        String formattedUpdatedDate = formatUpdatedStartDate(updatedStartDate);
        System.out.println("Formatted Updated Start Date: " + formattedUpdatedDate);

        TestRunner.getTest().log(Status.INFO, "Edit start Date is: " + formattedUpdatedDate);
        System.out.println("Edit start Date is: " + formattedUpdatedDate);
        TestRunner.getTest().log(Status.INFO, "Date On Assignment Module After Edit start Date is: " + formattedExtractedDate);
        System.out.println("Date On Assignment Module After Edit start Date is: " + formattedExtractedDate);

// Now compare with the previously generated editStartDate
        if (formattedExtractedDate.equals(formattedUpdatedDate)) {
            System.out.println("Start dates match!");
            TestRunner.getTest().log(Status.INFO, "Start dates match! " + formattedUpdatedDate + " " + formattedExtractedDate);
        } else {
            System.out.println("Start dates do not match!");
            TestRunner.getTest().log(Status.FAIL, "Start dates do not match! " + formattedUpdatedDate + " " + formattedExtractedDate);
        }

    }

    private String formatExtractedDate(String extractedDate) {
        try {
            // Parse the extracted date (e.g., "2024-11-15 12:41 PM") into a Date object
            SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm a");
            Date parsedDate = inputFormat.parse(extractedDate);

            // Format it into the desired output format (e.g., "15/11/2024, 12:41 PM")
            SimpleDateFormat outputFormat = new SimpleDateFormat("dd/MM/yyyy, hh:mm a");
            return outputFormat.format(parsedDate);
        } catch (Exception e) {
            System.out.println("Error while formatting extracted date: " + e.getMessage());
            return null;
        }
    }

    private String formatUpdatedStartDate(String updatedDate) {
        try {
            // Parse the updated date (ISO format: "2024-11-21T15:17") into a Date object
            SimpleDateFormat isoFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm");
            Date parsedDate = isoFormat.parse(updatedDate);

            // Format it into the desired output format (e.g., "15/11/2024, 03:17 PM")
            SimpleDateFormat outputFormat = new SimpleDateFormat("dd/MM/yyyy, hh:mm a");
            return outputFormat.format(parsedDate);
        } catch (Exception e) {
            System.out.println("Error while formatting updated date: " + e.getMessage());
            return null;


        }
    }

    public void VerifyDueDateAlsoUpdateOnAssignment() throws InterruptedException{
        System.out.println("I'm into Validate Due Date Also Update on Assignment Module");
        TestRunner.getTest().log(Status.INFO, "I'm into Validate Due Date Also Update on Assignment Module");


        List<WebElement> assignmentNameDueDate = driver.findElements(By.xpath("//div[contains(@class, 'content-footer-left')]//div[contains(@class,'DueDate')]"));

        if (assignmentNameDueDate.isEmpty()) {
            System.out.println("Due date element not found on the page.");
            return;
        }

        String extractedText = assignmentNameDueDate.get(0).getText();
        System.out.println("Extracted Text: " + extractedText);

// Extract the date portion (remove "Due: " and any extra spaces)
        String extractedDueDate = extractedText.replace("Due: ", "").trim();
        System.out.println("Extracted Due Date: " + extractedDueDate);

// Format the extracted Due date to match the format of editDueDate
        String formattedExtractedDueDate = formatExtractedDate(extractedDueDate);
        System.out.println("Formatted Extracted Due Date: " + formattedExtractedDueDate);

// Reformat updatedDueDate to match the extracted Due date's format
        String formattedUpdatedDueDate = formatUpdatedStartDate(updatedDueDate);
        System.out.println("Formatted Updated Due Date: " + formattedUpdatedDueDate);

        TestRunner.getTest().log(Status.INFO, "Edit Due Date is: " + formattedUpdatedDueDate);
        System.out.println("Edit Due Date is: " + formattedUpdatedDueDate);
        TestRunner.getTest().log(Status.INFO, "Date On Assignment Module After Edit Due Date is: " + formattedExtractedDueDate);
        System.out.println("Date On Assignment Module After Edit Due Date is: " + formattedExtractedDueDate);

// Now compare with the previously generated editDueDate
        if (formattedExtractedDueDate.equals(formattedUpdatedDueDate)) {
            System.out.println("Due dates match!");
            TestRunner.getTest().log(Status.INFO, "Due dates match! " + formattedUpdatedDueDate + " " + formattedExtractedDueDate);
        } else {
            System.out.println("Due dates do not match!");
            TestRunner.getTest().log(Status.FAIL, "Due dates do not match! " + formattedUpdatedDueDate + " " + formattedExtractedDueDate);
        }


    }

    @FindBy(xpath = "//div[contains(@class, 'StudentListingAndTableWrapper')]")
    WebElement studentAssignmentTable;

    public void searchAssignmentInGradeBookAfterEditWithPreviousTitle() throws InterruptedException {

        System.out.println("Validate and Search Assignment In Grade Book Module for After Edit with Previous Title: " + assignmentNameForCorrect.get());
        TestRunner.getTest().log(Status.INFO, "Validate and Search Assignment In Grade Book Module for After Edit with Previous Title: " + assignmentNameForCorrect.get());

        // Wait for the gradebook table to be visible
        WebElement assignmentTable = wait.until(ExpectedConditions.visibilityOf(studentAssignmentTable));

        // Get all column headers (th) within thead
        List<WebElement> assignmentContainers = assignmentTable.findElements(By.xpath(".//thead//tr//th"));
        System.out.println("Total Assignment Names are: " + assignmentContainers.size());
        TestRunner.getTest().log(Status.INFO, "Total Assignment Names are: " + assignmentContainers.size());

        boolean isAssignmentFound = false;

        for (WebElement assignment : assignmentContainers) {
            String assignmentText = assignment.getText().trim();
            if (assignmentText.equalsIgnoreCase(assignmentNameForCorrect.get())) {
                isAssignmentFound = true;
                System.out.println("Assignment found with previous title: " + assignmentText);
                TestRunner.getTest().log(Status.PASS, "Assignment found with previous title: " + assignmentText);
                break;
            }
        }

        if (!isAssignmentFound) {
            System.out.println("Assignment NOT found with previous title : " + assignmentNameForCorrect.get());
            TestRunner.getTest().log(Status.FAIL, "Assignment NOT found with previous title:   " +  assignmentNameForCorrect.get());
            // You can also capture a screenshot or throw an exception here if needed
            // throw new AssertionError("Assignment not found: " + assignmentNameForCorrect);
        }
    }


    public void searchAssignmentInGradeBookAfterEditWithEditedTitle() throws InterruptedException {

        System.out.println("Validate and Search Assignment In Grade Book Module for with Edited Title: " + EditAssignmentName);
        TestRunner.getTest().log(Status.INFO, "Validate and Search Assignment In Grade Book Module for with Edited Title: " + EditAssignmentName);

        String assignmentNameForCorrect = EditAssignmentName;
        System.out.println("Want to search assignment With Edited Title: " + assignmentNameForCorrect);
        TestRunner.getTest().log(Status.INFO, "Want to search assignment With Edited Title: " + assignmentNameForCorrect);

        // Wait for the gradebook table to be visible
        WebElement assignmentTable = wait.until(ExpectedConditions.visibilityOf(studentAssignmentTable));

        // Get all column headers (th) within thead
        List<WebElement> assignmentContainers = assignmentTable.findElements(By.xpath(".//thead//tr//th"));
        System.out.println("Total Assignment Names are: " + assignmentContainers.size());
        TestRunner.getTest().log(Status.INFO, "Total Assignment Names are: " + assignmentContainers.size());

        boolean isAssignmentFound = false;

        for (WebElement assignment : assignmentContainers) {
            String assignmentsName = assignment.getText().trim();
            System.out.println("Assignment Name: " + assignmentsName);

            if (assignmentsName.equalsIgnoreCase(assignmentNameForCorrect)) {
                isAssignmentFound = true;
                assignment.click();
                System.out.println("Test Case Passed : Assignment with Edited title FOUND in Grade Book: " + assignmentsName);
                TestRunner.getTest().log(Status.PASS, "Test Case Failed: Assignment with Edited title FOUND in Grade Book: " + assignmentsName);

                verifyDisableButtonsInGradeBook();
                break;
            }
        }

        if (!isAssignmentFound) {
            System.out.println("Test Case Failed : Assignment with Edited title NOT found in Grade Book." + assignmentNameForCorrect);
            TestRunner.getTest().log(Status.FAIL, "Test Case Passed : Assignment with Edited title NOT found in Grade Book." + assignmentNameForCorrect);
        }

    }


    public void verifyDisableButtonsInGradeBook() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm verifying Grade, View, and UnSubmit buttons before Student attempts the Assignment");
        System.out.println("I'm verifying Grade, View, and UnSubmit buttons before Student attempts the Assignment");

        Thread.sleep(2000);

        List<WebElement> listAssignment = driver.findElements(By.xpath("//ul[@role='menu']"));
        boolean gradeButtonFound = false;
        boolean viewButtonFound = false;
        boolean unsubmitButtonFound = false;

        for (WebElement option : listAssignment) {
            List<WebElement> menuItems = option.findElements(By.tagName("li"));

            for (WebElement menuItem : menuItems) {
                // Check if the <li> contains the "Grade", "View", or "UnSubmit" button
                String menuItemText = menuItem.getText().trim();
                System.out.println("Menu Items Are: "  + menuItemText);
                TestRunner.getTest().log(Status.INFO, "Menu Items Are: "  + menuItemText);

                if (menuItemText.equals("Grade") || menuItemText.equals("View") || menuItemText.equals("Unsubmit")) {
                    // Set flags when buttons are found
                    if (menuItemText.equals("Grade")) gradeButtonFound = true;
                    if (menuItemText.equals("View")) viewButtonFound = true;
                    if (menuItemText.equals("Unsubmit")) unsubmitButtonFound = true;

                    // Check if the button has the 'Mui-disabled' class or 'aria-disabled="true"'
                    String classAttribute = menuItem.getAttribute("class");
                    String ariaDisabled = menuItem.getAttribute("aria-disabled");

                    if (classAttribute.contains("Mui-disabled") && "true".equals(ariaDisabled)) {
                        System.out.println(menuItemText + " button is disabled as expected.");
                        TestRunner.getTest().log(Status.PASS, "Test Case Passed: " + menuItemText + " button is correctly disabled.");
                    } else {
                        // Fail if the button is not disabled
                        System.out.println(menuItemText + " button is enabled but it should be disabled.");
                        TestRunner.getTest().log(Status.FAIL, "Test Case Failed: " + menuItemText + " button is enabled, but it should be disabled.");
                        throw new AssertionError("Test Case Failed: " + menuItemText + " button is enabled, but it should be disabled.");
                    }
                }
            }
        }

// Fail the test if any button was not found in the menu
        if (!gradeButtonFound) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Grade button not found.");

        }
        if (!viewButtonFound) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: View button not found.");

        }
        if (!unsubmitButtonFound) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Unsubmit button not found.");

        }

    }



}
