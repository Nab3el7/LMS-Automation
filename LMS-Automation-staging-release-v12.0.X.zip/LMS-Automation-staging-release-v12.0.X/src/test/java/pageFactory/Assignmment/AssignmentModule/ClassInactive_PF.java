package pageFactory.Assignmment.AssignmentModule;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Classes.AddClass_PF;

import java.time.Duration;
import java.util.List;

public class ClassInactive_PF {
    WebDriverWait wait;
    WebDriver driver;
    Helper helper;
    Actions actions;

    @FindBy(xpath = "//label[text()='Status']/following-sibling::div//div[@role='button' or @role='combobox']")
    WebElement dropDown_SchoolStatus;

    @FindBy (xpath = "(//input[contains(@name,'activeStatus')])[1]")
    WebElement Toggle_SelectClasses;

    public  ClassInactive_PF(WebDriver driver){
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        helper = new Helper();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        actions = new Actions(driver);
        addClassPF = new AddClass_PF(driver);

    }

    public void SelectActiveStatus() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm into selecting Status For Class");
        System.out.println("I'm into selecting Status For Class");

        dropDown_SchoolStatus.click();

        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//ul[@role='listbox']//li")));
        List<WebElement> ClassStatusOptions = driver.findElements(By.xpath("//ul[@role='listbox']//li"));

        System.out.println("Available Status Options For Class:");
        for (WebElement option : ClassStatusOptions) {
            System.out.println(option.getText());
        }

        for (WebElement option : ClassStatusOptions) {
            if (option.getText().equalsIgnoreCase("Active")) {
                option.click();
                System.out.println("Selected " + option.getText() + " status");
                break;
            }
        }
        TestRunner.getTest().log(Status.PASS, "Test Case Passed   : New Active status selected successfully for class");


    }

    public void DisplayInactiveToggle() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm into Turn Off Display Inactive Toggle");
        System.out.println("I'm into Turn Off Display Inactive Toggle");

        boolean isClassesToggleButtonEnabled = Toggle_SelectClasses.isSelected();

        if (isClassesToggleButtonEnabled) {
            // If the toggle button is on, click to turn it off
            Toggle_SelectClasses.click();
            System.out.println("Classes toggle button was enabled, now it is disabled.");
            TestRunner.getTest().log(Status.PASS, "Testcase Passed: Classes toggle button turned off successfully.");
        } else {
            // If the toggle button is already off, no action is needed
            System.out.println("Classes toggle button is already disabled.");
            TestRunner.getTest().log(Status.INFO, "No action needed: Classes toggle button is already off.");
        }

    }


    public void SelectNewlyCreatedClassFromList(String ActiveClassName) throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm into selecting Newly Created Class from List: " + ActiveClassName);
        System.out.println("I'm into selecting Newly Created Class from List: " + ActiveClassName);

        try {
            TestRunner.getTest().log(Status.INFO, "Attempting to select class in class dropdown");
//            Thread.sleep(5000);

            // Wait for the dropdown to appear
            WebElement classDropdown = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class,'SelectTextFieldsWrapper')]")));

            if (classDropdown.isDisplayed() && classDropdown.isEnabled()) {
                System.out.println("Class dropdown is enabled and clickable");
                TestRunner.getTest().log(Status.INFO, "Class dropdown is enabled and clickable");
                classDropdown.click();
                Thread.sleep(2000);

                // Wait for the listbox to appear
                WebElement listBox = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//ul[@role='listbox']")));
                List<WebElement> totalClasses = listBox.findElements(By.tagName("li"));
                System.out.println("Total Classes in the dropdown: " + totalClasses.size());
                TestRunner.getTest().log(Status.INFO, "Total Classes in the dropdown: " + totalClasses.size());

                boolean isClassFound = false; // Flag to track if the class is found
                for (WebElement classElement : totalClasses) {
                    String className = classElement.getText().trim(); // Get and trim the text of the element
                    System.out.println("Class in dropdown: " + className);

                    if (className.equals(ActiveClassName)) {
                        System.out.println("Newly Created Class Found: " + ActiveClassName);
                        TestRunner.getTest().log(Status.PASS, "Newly Created Class Found: " + ActiveClassName);
                        classElement.click();
                        isClassFound = true; // Update flag
                        break;
                    }
                }

                // Log a message if the class is not found
                if (!isClassFound) {
                    System.out.println("Newly Created Class Not Found: " + ActiveClassName);
                    TestRunner.getTest().log(Status.FAIL, "Newly Created Class Not Found: " + ActiveClassName);
                }
            } else {
                TestRunner.getTest().log(Status.FAIL, "Class dropdown is not visible or enabled.");
                System.out.println("Class dropdown is not visible or enabled.");
            }
        } catch (Exception e) {
            System.out.println("An error occurred: " + e.getMessage());
            TestRunner.getTest().log(Status.FAIL, "An error occurred while selecting a class: " + e.getMessage());
        }

    }

    public void ChangeSchoolStatusToInactive() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "Change Status of class to Inactive Class " );
        System.out.println("Change Status of class to Inactive Class  " );

        dropDown_SchoolStatus.click();
//        Thread.sleep(3000);

        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//ul[@role='listbox']//li")));
        List<WebElement> ClassStatusOptions = driver.findElements(By.xpath("//ul[@role='listbox']//li"));

        System.out.println("Available Status Options For Class:");
        for (WebElement option : ClassStatusOptions) {
            System.out.println(option.getText());
        }

        for (WebElement option : ClassStatusOptions) {
            if (option.getText().equalsIgnoreCase("InActive")) {
                option.click();
                System.out.println("Selected " + option.getText() + " status");
                break;
            }
        }
        
        // Close the dropdown after selection
        try {
            Thread.sleep(500);
            actions.sendKeys(Keys.ESCAPE).build().perform();
            System.out.println("Dropdown closed successfully");
            TestRunner.getTest().log(Status.INFO, "Dropdown closed successfully");
        } catch (Exception e) {
            System.out.println("Could not close dropdown: " + e.getMessage());
        }
        
        TestRunner.getTest().log(Status.PASS, "Test Case Passed   : New InActive status selected successfully fro class");

    }
    AddClass_PF addClassPF;
    String searchInactiveClassByKeyword;

    public void searchInactiveClassByName() throws InterruptedException {

        TestRunner.getTest().log(Status.INFO, "I'm in search Class By Name");
        WebElement right_panel = driver.findElement(By.xpath("//div[@class='right-panel']"));
        right_panel.isDisplayed();

        try {
            WebElement searchBox = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder='Search Class by keyword']")));
            if (searchBox.isDisplayed()) {
                searchBox.click();
                searchBox.clear();
                ((JavascriptExecutor) driver).executeScript("arguments[0].value='';", searchBox);
                searchInactiveClassByKeyword = addClassPF.getClassName();
                System.out.println("Search by class name: " + searchInactiveClassByKeyword);
                TestRunner.getTest().log(Status.INFO, "Search by class name: " + searchInactiveClassByKeyword);
                searchBox.sendKeys(searchInactiveClassByKeyword);

                Actions actions = new Actions(driver);
                actions.sendKeys(Keys.ENTER).perform();
                TestRunner.getTest().log(Status.PASS, "Testcase Passed   : Enter Search Student keyword Successfully");

                waitForTableToRefreshForInactiveClass();
            } else {
                System.out.println("Search box is not displayed.");
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : Search box is not displayed");
//                throw new RuntimeException("Search Box not  Found.");
            }
        } catch (Exception e) {
            System.out.println("Search box is not available: " + e.getMessage());
        }

    }

    public void waitForTableToRefreshForInactiveClass() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into verify that Inactive Class is not Present in Active CLass list");
        TestRunner.startTest("Validate Inactive Class Not Present in Active Class List");

        try {
            WebElement tableClasses = wait.until(ExpectedConditions.presenceOfElementLocated(
                    By.xpath("//div[contains(@class, 'ClassesDashboardRightPanel')]//div[@class='tabelbodydata']")));

            wait.until(ExpectedConditions.stalenessOf(tableClasses));

            WebElement noDetailFoundElement = driver.findElement(By.xpath("//div[@class='textstyling']//div[contains(text(), 'No Detail Found')]"));

            if (noDetailFoundElement.isDisplayed()) {
                System.out.println("No Detail Found - Inactive class is not in the Active Class List.");
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: Inactive class is not in the Active Class List.");
            } else {
                System.out.println("Inactive class is still present in the Active Class List.");
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Inactive class is still present in the Active Class List.");
            }
        } catch (NoSuchElementException e) {
            System.out.println("Inactive class is still present in the Active Class List.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Inactive class is still present in the Active Class List.");
            }
    }

    public void ValidateInactiveClassIsNotInList(String InActiveClassName) throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm into verifying that Inactive class is not in Active Class List: " + InActiveClassName);
        TestRunner.startTest("Verify that Inactive class is not in Active Class List: " + InActiveClassName);

        try {
            // Wait for the dropdown to be present
            WebElement classDropdown = wait.until(ExpectedConditions.presenceOfElementLocated(
                    By.xpath("//div[contains(@class,'SelectTextFieldsWrapper')]")));

            if (classDropdown.isDisplayed() && classDropdown.isEnabled()) {
                System.out.println("Class dropdown is enabled and clickable");
                TestRunner.getTest().log(Status.INFO, "Class dropdown is enabled and clickable");
                classDropdown.click();
                Thread.sleep(2000);

                // Locate the listbox containing the classes
                WebElement listBox = wait.until(ExpectedConditions.presenceOfElementLocated(
                        By.xpath("//ul[@role='listbox']")));
                List<WebElement> totalClasses = listBox.findElements(By.tagName("li"));
                System.out.println("Total Classes in the dropdown: " + totalClasses.size());
                TestRunner.getTest().log(Status.INFO, "Total Classes in the dropdown: " + totalClasses.size());

                boolean isClassFound = false;

                // Iterate through the dropdown items
                for (WebElement classElement : totalClasses) {
                    String className = classElement.getText().trim();
                    System.out.println("Class in dropdown: " + className);

                    if (className.equals(InActiveClassName)) {
                        System.out.println("Inactive Class Found in active class list: " + InActiveClassName);
                        TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Inactive Class Found in active class list dropdown: " + InActiveClassName);
                        isClassFound = true;
                        break;
                    }
                }

                if (!isClassFound) {
                    System.out.println("Inactive Class Not Found in active class list: " + InActiveClassName);
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed: Inactive Class Not Found in active class list dropdown: " + InActiveClassName);
                }

                // Close the dropdown
                WebElement closeDropdownArea = wait.until(ExpectedConditions.presenceOfElementLocated(
                        By.xpath("//body"))); // Clicking outside the dropdown
                closeDropdownArea.click();
                Thread.sleep(1000);
                System.out.println("Dropdown closed successfully.");
                TestRunner.getTest().log(Status.INFO, "Dropdown closed successfully.");
            } else {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Class dropdown is not visible or enabled.");
                System.out.println("Class dropdown is not visible or enabled.");
            }
        } catch (Exception e) {
            // Handle exceptions
            TestRunner.getTest().log(Status.FAIL, "An unexpected error occurred: " + e.getMessage());
            System.out.println("An error occurred: " + e.getMessage());
        }

    }

    public void ValidateInactiveClassIsFoundInInactiveClassesDropdown(String InactiveClass) throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm into verifying that Inactive class found in Inactive Class dropdown: " + InactiveClass);
        TestRunner.startTest("I'm into verifying that Inactive class found in Inactive Class dropdown: " + InactiveClass);

        try {
            TestRunner.getTest().log(Status.INFO, "Attempting to select Inactive class in class dropdown");

            WebElement classDropdown = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class,'SelectTextFieldsWrapper')]")));

            if (classDropdown.isDisplayed() && classDropdown.isEnabled()) {
                System.out.println("Class dropdown is enabled and clickable");
                TestRunner.getTest().log(Status.INFO, "Class dropdown is enabled and clickable");
                classDropdown.click();
                Thread.sleep(2000);

                WebElement listBox = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//ul[@role='listbox']")));
                List<WebElement> totalClasses = listBox.findElements(By.tagName("li"));
                System.out.println("Total Classes in the dropdown: " + totalClasses.size());
                TestRunner.getTest().log(Status.INFO, "Total Classes in the dropdown: " + totalClasses.size());

                boolean isClassFound = false; // Flag to track if the class is found
                for (WebElement classElement : totalClasses) {
                    String className = classElement.getText().trim(); // Get and trim the text of the element
                    System.out.println("Class in dropdown: " + className);

                    if (className.equals(InactiveClass)) {
                        System.out.println("Inactive class found in Inactive classes dropdown: " + InactiveClass);
                        TestRunner.getTest().log(Status.PASS, "Inactive class found in Inactive classes dropdown: " + InactiveClass);
                        classElement.click();
                        isClassFound = true; // Update flag
                        break;
                    }
                }

                // Log a message if the class is not found
                if (!isClassFound) {
                    System.out.println("Inactive class Not found in Inactive classes dropdown: " + InactiveClass);
                    TestRunner.getTest().log(Status.FAIL, "Inactive class Not found in Inactive classes dropdown: " + InactiveClass);
                }
            } else {
                TestRunner.getTest().log(Status.FAIL, "Class dropdown is not visible or enabled.");
                System.out.println("Class dropdown is not visible or enabled.");
            }
        } catch (Exception e) {
            System.out.println("An error occurred: " + e.getMessage());
            TestRunner.getTest().log(Status.FAIL, "An error occurred while selecting a class: " + e.getMessage());
        }


    }
}
