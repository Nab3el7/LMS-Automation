package pageFactory.Assignmment;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Gradebook.AssignmentScoreVerification_PF;
import pageFactory.MyContent.AssignAssessment_PF;
import org.openqa.selenium.ElementNotInteractableException;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

public class ScenarioAdvanceGradings_PF {

    public WebDriverWait wait;
    WebDriver driver;
    private int temp= 0;

    public static ThreadLocal<Double> assignInitialWeight = ThreadLocal.withInitial(() -> 0.0);

//    public static ThreadLocal<Integer> temp = ThreadLocal.withInitial(() -> 0);

//    public static List<Double> previousWeights = new ArrayList<>();
//    public static List<Double> previousPercentages = new ArrayList<>();
//    public static List<Double> updatedWeights = new ArrayList<>();
//    public static List<Double> updatedPercentages = new ArrayList<>();
//    public static List<Double> disabledIndices = new ArrayList<>();

    public static ThreadLocal<List<Double>> previousWeights = ThreadLocal.withInitial(ArrayList::new);
    public static ThreadLocal<List<Double>> previousPercentages = ThreadLocal.withInitial(ArrayList::new);
    public static ThreadLocal<List<Double>> updatedWeights = ThreadLocal.withInitial(ArrayList::new);
    public static ThreadLocal<List<Double>> updatedPercentages = ThreadLocal.withInitial(ArrayList::new);
    public static ThreadLocal<List<Double>> disabledIndices = ThreadLocal.withInitial(ArrayList::new);


    Helper helper;
    ReleaseAssignment_PF releaseAssignment_pf;
    CorrectAnswerExecutor_PF correctAnswerExecutor_pf;
    AssignAssessment_PF assignAssessment_pf;

    @FindBy(xpath = "//div[contains(@class, 'MetaDataWrapper')]")
    WebElement container_FinalizeQuestion;

    @FindBy(xpath = "//nav[@aria-label='pagination navigation']")
    WebElement nav_Pagination;

    @FindBy(xpath = "//button[@aria-label='Go to next page']")
    WebElement btn_NavNextPage;

    String questionID = null;


    public ScenarioAdvanceGradings_PF(WebDriver driver) {
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(100));
        helper = new Helper();
        releaseAssignment_pf = new ReleaseAssignment_PF(driver);
        correctAnswerExecutor_pf = new CorrectAnswerExecutor_PF(driver);
        assignAssessment_pf = new AssignAssessment_PF(driver);
    }

//    Release Assignment with advance gradings for Main Grade toggle button off

    public void releaseAssignmentDSBScenarioGradeMainToggleButton() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Release Assignment Type DSB Handle Scenario Grade Main Toggle Button");
        System.out.println("Release Assignment Type DSB Handle Grade Main Toggle Button");

        releaseAssignment_pf.selectUnitReleaseAssignmentDSB();

        Thread.sleep(2000);
        WebElement listContentPlayer2 = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@id='ContentPlayerMainPanel']")));
        helper.scrollToElement(driver,listContentPlayer2);
        Thread.sleep(1000);


        if (listContentPlayer2.isDisplayed() && listContentPlayer2.isEnabled()) {
            WebElement btnAssignForSpecificAssignment = listContentPlayer2.findElement(By.xpath("(//div[contains(@class, 'MuiBox-root')]//button[contains(text(), 'Assign')])[1]"));
            btnAssignForSpecificAssignment.click();

            WebElement dialogAssignment = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@role='dialog']")));
            if (dialogAssignment.isDisplayed()) {
                correctAnswerExecutor_pf.EnterAssignmentTitleForCorrectAnswers();
                correctAnswerExecutor_pf.selectSpecificClasses();
                assignAssessment_pf.setDateTimeAndCategory();
                assignAssessment_pf.enterAdditionalSettings();
                releaseAssignment_pf.select_ShowScoringOptions();
                scenarioMainGradeToggleButton();
                assignAssessment_pf.assignAssignment();
                assignAssessment_pf.verifyDialogBox();
                TestRunner.getTest().log(Status.PASS, "Test Case Passed : Scenario Advance Grading Main Grade Toggle Button DSB Released Successfully");
            }
        }
    }

    public void releaseAssignmentETScenarioGradeMainToggleButton() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Release Assignment Type Expert Track Handle Scenario Grade Main Toggle Button");
        System.out.println("Release Assignment Type ET Handle Grade Main Toggle Button");
        releaseAssignment_pf.selectUnitForReleaseAssignment();

        Thread.sleep(2000);
        WebElement listContentPlayer = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@id='ContentPlayerMainPanel']")));

        if (listContentPlayer.isDisplayed() && listContentPlayer.isEnabled()) {
            WebElement btnAssignForSpecificAssignment = listContentPlayer.findElement(By.xpath("(//div[contains(@class, 'MuiBox-root')]//button[contains(text(), 'Assign')])[5]"));
            btnAssignForSpecificAssignment.click();

            WebElement dialogAssignment = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@role='dialog']")));
            if (dialogAssignment.isDisplayed()) {
                correctAnswerExecutor_pf.EnterAssignmentTitleForCorrectAnswers();
                correctAnswerExecutor_pf.selectSpecificClasses();
                assignAssessment_pf.setDateTimeAndCategory();
                assignAssessment_pf.enterAdditionalSettings();
                releaseAssignment_pf.select_ShowScoringOptions();
                scenarioMainGradeToggleButton();
                assignAssessment_pf.assignAssignment();
                assignAssessment_pf.verifyDialogBox();
                TestRunner.getTest().log(Status.PASS, "Test Case Passed : Scenario Advance Grading Main Grade Toggle Button ET Released Successfully");
            }
        }
    }

    public void releaseAssignmentVBScenarioGradeMainToggleButton() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Release Assignment Type Vocabulary Builder Handle Scenario Grade Main Toggle Button");
        System.out.println("Release Assignment Type VB Handle Grade Main Toggle Button");
        releaseAssignment_pf.selectUnitForReleaseAssignment();

        Thread.sleep(2000);
        WebElement listContentPlayer = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@id='ContentPlayerMainPanel']")));

        if (listContentPlayer.isDisplayed() && listContentPlayer.isEnabled()) {
            WebElement btnAssignForSpecificAssignment = listContentPlayer.findElement(By.xpath("(//div[contains(@class, 'MuiBox-root')]//button[contains(text(), 'Assign')])[3]"));
            btnAssignForSpecificAssignment.click();

            WebElement dialogAssignment = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@role='dialog']")));
            if (dialogAssignment.isDisplayed()) {
                correctAnswerExecutor_pf.EnterAssignmentTitleForCorrectAnswers();
                correctAnswerExecutor_pf.selectSpecificClasses();
                assignAssessment_pf.setDateTimeAndCategory();
                assignAssessment_pf.enterAdditionalSettings();
                releaseAssignment_pf.select_ShowScoringOptions();
                scenarioMainGradeToggleButton();
                assignAssessment_pf.assignAssignment();
                assignAssessment_pf.verifyDialogBox();
                TestRunner.getTest().log(Status.PASS, "Test Case Passed : Scenario Advance Grading Main Grade Toggle Button VB Released Successfully");
            }
        }
    }

    public void releaseAssignmentVQScenarioGradeMainToggleButton() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Release Assignment Type Vocabulary Quiz Handle Scenario Grade Main Toggle Button");
        System.out.println("Release Assignment Type VQ Handle Grade Main Toggle Button");
        releaseAssignment_pf.selectUnitForReleaseAssignment();

        Thread.sleep(2000);
        WebElement listContentPlayer = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@id='ContentPlayerMainPanel']")));

        if (listContentPlayer.isDisplayed() && listContentPlayer.isEnabled()) {
            WebElement btnAssignForSpecificAssignment = listContentPlayer.findElement(By.xpath("(//div[contains(@class, 'MuiBox-root')]//button[contains(text(), 'Assign')])[4]"));
            btnAssignForSpecificAssignment.click();

            WebElement dialogAssignment = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@role='dialog']")));
            if (dialogAssignment.isDisplayed()) {
                correctAnswerExecutor_pf.EnterAssignmentTitleForCorrectAnswers();
                correctAnswerExecutor_pf.selectSpecificClasses();
                assignAssessment_pf.setDateTimeAndCategory();
                assignAssessment_pf.enterAdditionalSettings();
                releaseAssignment_pf.select_ShowScoringOptions();
                scenarioMainGradeToggleButton();
                assignAssessment_pf.assignAssignment();
                assignAssessment_pf.verifyDialogBox();
                TestRunner.getTest().log(Status.PASS, "Test Case Passed : Scenario Advance Grading Main Grade Toggle Button VQ Released Successfully");
            }
        }
    }

//    All toggle On

    public void releaseAssignmentScenarioAllQuestionGradeToggleButton() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Release Assignment Handle Scenario All Question Toggle Button");
        System.out.println("Release Assignment Handle Scenario All Question Toggle Button");
        releaseAssignment_pf.selectUnitForReleaseAssignment();

        Thread.sleep(2000);
        WebElement listContentPlayer = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@id='ContentPlayerMainPanel']")));

        if (listContentPlayer.isDisplayed() && listContentPlayer.isEnabled()) {
            WebElement btnAssignForSpecificAssignment = listContentPlayer.findElement(By.xpath("(//div[contains(@class, 'MuiBox-root')]//button[contains(text(), 'Assign')])[5]"));
            btnAssignForSpecificAssignment.click();

            WebElement dialogAssignment = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@role='dialog']")));
            if (dialogAssignment.isDisplayed()) {
                correctAnswerExecutor_pf.EnterAssignmentTitleForCorrectAnswers();
                correctAnswerExecutor_pf.selectSpecificClasses();
                assignAssessment_pf.setDateTimeAndCategory();
                assignAssessment_pf.enterAdditionalSettings();
                releaseAssignment_pf.select_ShowScoringOptions();
                scenarioQuestionsGradeToggleButton();
                assignAssessment_pf.assignAssignment();
                assignAssessment_pf.verifyDialogBox();
                TestRunner.getTest().log(Status.PASS, "Test Case Passed : Scenario Advance Grading Particular Question Toggle Button ET Released Successfully");
            }
        }
    }

//    Release Assignment with advance gradings for Particular Questions toggle button off

    public void releaseAssignmentDSBScenarioParticularQuestionGradeToggleButton() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Release Assignment Type DSB Handle Scenario Particular Question Toggle Button");
        System.out.println("Release Assignment Type DSB Handle Particular Question Toggle Button");

        releaseAssignment_pf.selectUnitReleaseAssignmentDSB();

        Thread.sleep(2000);
        WebElement listContentPlayer2 = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@id='ContentPlayerMainPanel']")));
        helper.scrollToElement(driver,listContentPlayer2);
        Thread.sleep(1000);

        if (listContentPlayer2.isDisplayed() && listContentPlayer2.isEnabled()) {
            WebElement btnAssignForSpecificAssignment = listContentPlayer2.findElement(By.xpath("(//div[contains(@class, 'MuiBox-root')]//button[contains(text(), 'Assign')])[1]"));
            btnAssignForSpecificAssignment.click();

            WebElement dialogAssignment = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@role='dialog']")));
            if (dialogAssignment.isDisplayed()) {
                correctAnswerExecutor_pf.EnterAssignmentTitleForCorrectAnswers();
                correctAnswerExecutor_pf.selectSpecificClasses();
                assignAssessment_pf.setDateTimeAndCategory();
                assignAssessment_pf.enterAdditionalSettings();
                releaseAssignment_pf.select_ShowScoringOptions();
                scenarioParticularQuestionsGradeToggleButton();
                assignAssessment_pf.assignAssignment();
                assignAssessment_pf.verifyDialogBox();
                TestRunner.getTest().log(Status.PASS, "Test Case Passed : Scenario Advance Grading Particular Question Toggle Button DSB Released Successfully");
            }
        }
    }

    public void releaseAssignmentETScenarioParticularQuestionGradeToggleButton() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Release Assignment Type Expert Track Handle Scenario Particular Question Toggle Button");
        System.out.println("Release Assignment Type ET Handle Scenario Particular Question Toggle Button");
        releaseAssignment_pf.selectUnitForReleaseAssignment();

        Thread.sleep(2000);
        WebElement listContentPlayer = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@id='ContentPlayerMainPanel']")));

        if (listContentPlayer.isDisplayed() && listContentPlayer.isEnabled()) {
            WebElement btnAssignForSpecificAssignment = listContentPlayer.findElement(By.xpath("(//div[contains(@class, 'MuiBox-root')]//button[contains(text(), 'Assign')])[5]"));
            btnAssignForSpecificAssignment.click();

            WebElement dialogAssignment = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@role='dialog']")));
            if (dialogAssignment.isDisplayed()) {
                correctAnswerExecutor_pf.EnterAssignmentTitleForCorrectAnswers();
                correctAnswerExecutor_pf.selectSpecificClasses();
                assignAssessment_pf.setDateTimeAndCategory();
                assignAssessment_pf.enterAdditionalSettings();
                releaseAssignment_pf.select_ShowScoringOptions();
                scenarioParticularQuestionsGradeToggleButton();
                assignAssessment_pf.assignAssignment();
                assignAssessment_pf.verifyDialogBox();
                TestRunner.getTest().log(Status.PASS, "Test Case Passed : Scenario Advance Grading Particular Question Toggle Button ET Released Successfully");
            }
        }
    }

    public void releaseAssignmentVBScenarioParticularQuestionGradeToggleButton() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Release Assignment Type Vocabulary Builder Handle Scenario Particular Question Toggle Button");
        System.out.println("Release Assignment Type VB Handle Scenario Particular Question Toggle Button");
        releaseAssignment_pf.selectUnitForReleaseAssignment();

        Thread.sleep(2000);
        WebElement listContentPlayer = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@id='ContentPlayerMainPanel']")));

        if (listContentPlayer.isDisplayed() && listContentPlayer.isEnabled()) {
            WebElement btnAssignForSpecificAssignment = listContentPlayer.findElement(By.xpath("(//div[contains(@class, 'MuiBox-root')]//button[contains(text(), 'Assign')])[3]"));
            btnAssignForSpecificAssignment.click();

            WebElement dialogAssignment = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@role='dialog']")));
            if (dialogAssignment.isDisplayed()) {
                correctAnswerExecutor_pf.EnterAssignmentTitleForCorrectAnswers();
                correctAnswerExecutor_pf.selectSpecificClasses();
                assignAssessment_pf.setDateTimeAndCategory();
                assignAssessment_pf.enterAdditionalSettings();
                releaseAssignment_pf.select_ShowScoringOptions();
                scenarioParticularQuestionsGradeToggleButton();
                assignAssessment_pf.assignAssignment();
                assignAssessment_pf.verifyDialogBox();
                TestRunner.getTest().log(Status.PASS, "Test Case Passed : Scenario Advance Grading Particular Question Toggle Button VB Released Successfully");
            }
        }
    }

    public void releaseAssignmentVQScenarioParticularQuestionGradeToggleButton() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Release Assignment Type Vocabulary Quiz Handle Scenario Particular Question Toggle Button");
        System.out.println("Release Assignment Type VQ Handle Scenario Particular Question Toggle Button");
        releaseAssignment_pf.selectUnitForReleaseAssignment();

        Thread.sleep(2000);
        WebElement listContentPlayer = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@id='ContentPlayerMainPanel']")));

        if (listContentPlayer.isDisplayed() && listContentPlayer.isEnabled()) {
            WebElement btnAssignForSpecificAssignment = listContentPlayer.findElement(By.xpath("(//div[contains(@class, 'MuiBox-root')]//button[contains(text(), 'Assign')])[4]"));
            btnAssignForSpecificAssignment.click();

            WebElement dialogAssignment = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@role='dialog']")));
            if (dialogAssignment.isDisplayed()) {
                correctAnswerExecutor_pf.EnterAssignmentTitleForCorrectAnswers();
                correctAnswerExecutor_pf.selectSpecificClasses();
                assignAssessment_pf.setDateTimeAndCategory();
                assignAssessment_pf.enterAdditionalSettings();
                releaseAssignment_pf.select_ShowScoringOptions();
                scenarioParticularQuestionsGradeToggleButton();
                assignAssessment_pf.assignAssignment();
                assignAssessment_pf.verifyDialogBox();
                TestRunner.getTest().log(Status.PASS, "Test Case Passed : Scenario Advance Grading Particular Question Toggle Button VQ Released Successfully");
            }
        }
    }

//    Release Assignment with advance gradings for Distribute Weight Evenly

    public void releaseAssignmentDSBScenarioDistributeWeightEvenly() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Release Assignment Type DSB Handle Scenario Distribute Weight Evenly");
        System.out.println("Release Assignment Type DSB Handle Scenario Distribute Weight Evenly");

        releaseAssignment_pf.selectUnitReleaseAssignmentDSB();

        Thread.sleep(2000);
        WebElement listContentPlayer2 = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@id='ContentPlayerMainPanel']")));
        helper.scrollToElement(driver,listContentPlayer2);
        Thread.sleep(1000);

        if (listContentPlayer2.isDisplayed() && listContentPlayer2.isEnabled()) {
            WebElement btnAssignForSpecificAssignment = listContentPlayer2.findElement(By.xpath("(//div[contains(@class, 'MuiBox-root')]//button[contains(text(), 'Assign')])[1]"));
            btnAssignForSpecificAssignment.click();

            WebElement dialogAssignment = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@role='dialog']")));
            if (dialogAssignment.isDisplayed()) {
                correctAnswerExecutor_pf.EnterAssignmentTitleForCorrectAnswers();
                correctAnswerExecutor_pf.selectSpecificClasses();
                assignAssessment_pf.setDateTimeAndCategory();
                assignAssessment_pf.enterAdditionalSettings();
                releaseAssignment_pf.select_ShowScoringOptions();
                scenarioDistributeWeightEvenlyButton();
                assignAssessment_pf.assignAssignment();
                assignAssessment_pf.verifyDialogBox();
                TestRunner.getTest().log(Status.PASS, "Test Case Passed : Scenario Advance Grading Distributed Weight Evenly DSB Released Successfully");
            }
        }
    }

    public void releaseAssignmentETScenarioDistributeWeightEvenly() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Release Assignment Type Expert Track Handle Scenario Distribute Weight Evenly");
        System.out.println("Release Assignment Type ET Handle Scenario Distribute Weight Evenly");
        releaseAssignment_pf.selectUnitForReleaseAssignment();

        Thread.sleep(2000);
        WebElement listContentPlayer = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@id='ContentPlayerMainPanel']")));

        if (listContentPlayer.isDisplayed() && listContentPlayer.isEnabled()) {
            WebElement btnAssignForSpecificAssignment = listContentPlayer.findElement(By.xpath("(//div[contains(@class, 'MuiBox-root')]//button[contains(text(), 'Assign')])[5]"));
            btnAssignForSpecificAssignment.click();

            WebElement dialogAssignment = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@role='dialog']")));
            if (dialogAssignment.isDisplayed()) {
                correctAnswerExecutor_pf.EnterAssignmentTitleForCorrectAnswers();
                correctAnswerExecutor_pf.selectSpecificClasses();
                assignAssessment_pf.setDateTimeAndCategory();
                assignAssessment_pf.enterAdditionalSettings();
                releaseAssignment_pf.select_ShowScoringOptions();
                scenarioDistributeWeightEvenlyButton();
                assignAssessment_pf.assignAssignment();
                assignAssessment_pf.verifyDialogBox();
                TestRunner.getTest().log(Status.PASS, "Test Case Passed : Scenario Advance Grading Distribute Weight Evenly ET Released Successfully");
            }
        }
    }

    public void releaseAssignmentVBScenarioDistributeWeightEvenly() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Release Assignment Type Vocabulary Builder Handle Scenario Distribute Weight Evenly");
        System.out.println("Release Assignment Type VB Handle Scenario Distribute Weight Evenly");
        releaseAssignment_pf.selectUnitForReleaseAssignment();

        Thread.sleep(2000);
        WebElement listContentPlayer = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@id='ContentPlayerMainPanel']")));

        if (listContentPlayer.isDisplayed() && listContentPlayer.isEnabled()) {
            WebElement btnAssignForSpecificAssignment = listContentPlayer.findElement(By.xpath("(//div[contains(@class, 'MuiBox-root')]//button[contains(text(), 'Assign')])[3]"));
            btnAssignForSpecificAssignment.click();

            WebElement dialogAssignment = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@role='dialog']")));
            if (dialogAssignment.isDisplayed()) {
                correctAnswerExecutor_pf.EnterAssignmentTitleForCorrectAnswers();
                correctAnswerExecutor_pf.selectSpecificClasses();
                assignAssessment_pf.setDateTimeAndCategory();
                assignAssessment_pf.enterAdditionalSettings();
                releaseAssignment_pf.select_ShowScoringOptions();
                scenarioDistributeWeightEvenlyButton();
                assignAssessment_pf.assignAssignment();
                assignAssessment_pf.verifyDialogBox();
                TestRunner.getTest().log(Status.PASS, "Test Case Passed : Scenario Advance Grading Distribute Weight Evenly VB Released Successfully");
            }
        }
    }

    public void releaseAssignmentVQScenarioDistributeWeightEvenly() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Release Assignment Type Vocabulary Quiz Handle Scenario Distribute Weight Evenly");
        System.out.println("Release Assignment Type VQ Handle Scenario Distribute Weight Evenly");
        releaseAssignment_pf.selectUnitForReleaseAssignment();

        Thread.sleep(2000);
        WebElement listContentPlayer = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@id='ContentPlayerMainPanel']")));

        if (listContentPlayer.isDisplayed() && listContentPlayer.isEnabled()) {
            WebElement btnAssignForSpecificAssignment = listContentPlayer.findElement(By.xpath("(//div[contains(@class, 'MuiBox-root')]//button[contains(text(), 'Assign')])[4]"));
            btnAssignForSpecificAssignment.click();

            WebElement dialogAssignment = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@role='dialog']")));
            if (dialogAssignment.isDisplayed()) {
                correctAnswerExecutor_pf.EnterAssignmentTitleForCorrectAnswers();
                correctAnswerExecutor_pf.selectSpecificClasses();
                assignAssessment_pf.setDateTimeAndCategory();
                assignAssessment_pf.enterAdditionalSettings();
                releaseAssignment_pf.select_ShowScoringOptions();
                scenarioDistributeWeightEvenlyButton();
                assignAssessment_pf.assignAssignment();
                assignAssessment_pf.verifyDialogBox();
                TestRunner.getTest().log(Status.PASS, "Test Case Passed : Scenario Advance Grading Distribute Weight Evenly VQ Released Successfully");
            }
        }
    }

    public void releaseAssignmentScenarioAdvanceGradingsUIBehavior() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Release Assignment Scenario Verify UI Behavior");
        System.out.println("Release Assignment Scenario Verify UI Behavior");
        releaseAssignment_pf.selectUnitForReleaseAssignment();

        Thread.sleep(2000);
        WebElement listContentPlayer = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@id='ContentPlayerMainPanel']")));

        if (listContentPlayer.isDisplayed() && listContentPlayer.isEnabled()) {
            WebElement btnAssignForSpecificAssignment = listContentPlayer.findElement(By.xpath("(//div[contains(@class, 'MuiBox-root')]//button[contains(text(), 'Assign')])[5]"));
            btnAssignForSpecificAssignment.click();

            WebElement dialogAssignment = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@role='dialog']")));
            if (dialogAssignment.isDisplayed()) {
                correctAnswerExecutor_pf.EnterAssignmentTitleForCorrectAnswers();
                correctAnswerExecutor_pf.selectSpecificClasses();
                assignAssessment_pf.setDateTimeAndCategory();
                assignAssessment_pf.enterAdditionalSettings();
                releaseAssignment_pf.select_ShowScoringOptions();
                verifyToggleButtonBehavior();
                assignAssessment_pf.assignAssignment();
                assignAssessment_pf.verifyDialogBox();
                TestRunner.getTest().log(Status.PASS, "Test Case Passed : Scenario Advance Grading Scenario Verify UI Behavior");
            }
        }
    }

    public void verifyToggleButtonBehavior() throws InterruptedException {
        Thread.sleep(2000);

        System.out.println("Verifying toggle button behavior.");
        TestRunner.getTest().log(Status.INFO, "Verifying toggle button behavior.");

        try {
            WebElement mainGradeToggle = driver.findElement(By.xpath("(//input[@name='isOpenToAnyStudent'])[2]"));

            List<WebElement> questionToggles = driver.findElements(By.xpath("//tbody//input[@type='checkbox']"));

            WebElement distributeWeightCheckbox = driver.findElement(By.xpath("//label[span[contains(text(), 'Distribute Weight evenly')]]//input[@type='checkbox']"));

            if (mainGradeToggle.isSelected()) {
                mainGradeToggle.click();
            }

            Thread.sleep(1000);

            boolean allQuestionTogglesOff = true;
            for (WebElement questionToggle : questionToggles) {
                if (questionToggle.isSelected()) {
                    allQuestionTogglesOff = false;
                    break;
                }
            }

            if (allQuestionTogglesOff) {
                System.out.println("Main Grade toggle is off, and all question toggles are off.");
                TestRunner.getTest().log(Status.PASS, "Main Grade toggle is off, and all question toggles are off.");
            } else {
                System.out.println("Error: Main Grade toggle is off, but some question toggles are still on.");
                TestRunner.getTest().log(Status.FAIL, "Main Grade toggle is off, but some question toggles are still on.");
            }

            WebElement firstQuestionToggle = questionToggles.get(0);
            firstQuestionToggle.click();

            Thread.sleep(1000);

            if (mainGradeToggle.isSelected()) {
                System.out.println("First question toggle turned on, and Main Grade toggle turned on automatically.");
                TestRunner.getTest().log(Status.PASS, "First question toggle turned on, and Main Grade toggle turned on automatically.");
            } else {
                System.out.println("Error: First question toggle turned on, but Main Grade toggle did not turn on.");
                TestRunner.getTest().log(Status.FAIL, "First question toggle turned on, but Main Grade toggle did not turn on.");
            }

            for (WebElement questionToggle : questionToggles) {
                if (questionToggle.isSelected()) {
                    questionToggle.click();
                }
            }

            Thread.sleep(1000);

            if (!mainGradeToggle.isSelected()) {
                System.out.println("All question toggles are off, and Main Grade toggle turned off automatically.");
                TestRunner.getTest().log(Status.PASS, "All question toggles are off, and Main Grade toggle turned off automatically.");
            } else {
                System.out.println("Error: All question toggles are off, but Main Grade toggle did not turn off.");
                TestRunner.getTest().log(Status.FAIL, "All question toggles are off, but Main Grade toggle did not turn off.");
            }

            if (!mainGradeToggle.isSelected() && !distributeWeightCheckbox.isEnabled()) {
                System.out.println("Main Grade toggle is off, and Distribute Weight Evenly checkbox is disabled.");
                TestRunner.getTest().log(Status.PASS, "Main Grade toggle is off, and Distribute Weight Evenly checkbox is disabled.");
            } else {
                System.out.println("Error: Main Grade toggle is off, but Distribute Weight Evenly checkbox is still enabled.");
                TestRunner.getTest().log(Status.FAIL, "Main Grade toggle is off, but Distribute Weight Evenly checkbox is still enabled.");
            }

        } catch (Exception e) {
            e.printStackTrace();
            TestRunner.getTest().log(Status.FAIL, "Error encountered while verifying toggle button behavior.");
        }
    }


    private void scenarioMainGradeToggleButton() throws InterruptedException {
        Thread.sleep(2000);
        WebElement mainGradeToggle = driver.findElement(By.xpath("(//input[@name='isOpenToAnyStudent'])[2]"));

        previousWeights.get().clear();
        previousPercentages.get().clear();
        updatedWeights.get().clear();
        updatedPercentages.get().clear();

        WebElement wrapperTable = container_FinalizeQuestion.findElement(By.xpath("//div[contains(@class, 'MetaDataWrapper')]//table//tbody"));
        List<WebElement> rows = wrapperTable.findElements(By.tagName("tr"));
        List<Boolean> rowsDisabledBeforeToggle = new ArrayList<>();

        int validRowIndex = 0;

        for (int i = 0; i < rows.size(); i++) {
            WebElement row = rows.get(i);
            List<WebElement> cells = row.findElements(By.tagName("td"));

            WebElement typeCell = cells.get(4);
            String questionType = typeCell.getText().trim();

            if (questionType.equalsIgnoreCase("Content")) {
                System.out.println("Row " + (i + 1) + " is of type 'Content'. Ignoring it.");
                continue;
            }

            WebElement weightInput = cells.get(1).findElement(By.tagName("input"));
            WebElement percentageInput = cells.get(2).findElement(By.tagName("input"));

            if (!weightInput.isEnabled() && !percentageInput.isEnabled()) {
                previousWeights.get().add(Double.valueOf(-2));
                previousPercentages.get().add(Double.valueOf(-2));
                updatedWeights.get().add(Double.valueOf(-2));
                updatedPercentages.get().add(Double.valueOf(-2));
                rowsDisabledBeforeToggle.add(true);
                System.out.println("Row " + (i + 1) + " is already disabled. Stored -2 in both previous and updated arrays.");
            } else {
                String previousWeightStr = weightInput.getAttribute("value");
                String previousPercentageStr = percentageInput.getAttribute("value");

                double previousWeight = previousWeightStr.isEmpty() ? 0 : Integer.parseInt(previousWeightStr);
                double previousPercentage = previousPercentageStr.isEmpty() ? 0 : Integer.parseInt(previousPercentageStr);

                previousWeights.get().add(previousWeight);
                previousPercentages.get().add(previousPercentage);
                rowsDisabledBeforeToggle.add(false);
                updatedWeights.get().add(previousWeight);
                updatedPercentages.get().add(previousPercentage);

                System.out.println("Row " + (i + 1) + " - Previous Weight: " + previousWeight + ", Previous Percentage: " + previousPercentage);
            }

            validRowIndex++;
        }

        System.out.println("Previous Weights: " + previousWeights);
        System.out.println("Previous Percentages: " + previousPercentages);
        TestRunner.getTest().log(Status.INFO, "Previous Weights: " + previousWeights.toString());
        TestRunner.getTest().log(Status.INFO, "Previous Percentages: " + previousPercentages.toString());

        if (mainGradeToggle.isEnabled()) {
            mainGradeToggle.click();
            System.out.println("Main Grade Toggle clicked off");
            TestRunner.getTest().log(Status.PASS, "Main Grade Toggle Clicked Off");

            Thread.sleep(1000);

            validRowIndex = 0;

            for (int i = 0; i < rows.size(); i++) {
                WebElement row = rows.get(i);
                List<WebElement> cells = row.findElements(By.tagName("td"));

                WebElement typeCell = cells.get(4);
                String questionType = typeCell.getText().trim();

                if (questionType.equalsIgnoreCase("Content")) {
                    System.out.println("Row " + (i + 1) + " is of type 'Content'. Ignoring it.");
                    continue;
                }

                WebElement weightInput = cells.get(1).findElement(By.tagName("input"));
                WebElement percentageInput = cells.get(2).findElement(By.tagName("input"));

                String updatedWeightStr = weightInput.getAttribute("value");
                String updatedPercentageStr = percentageInput.getAttribute("value");

                double updatedWeight = updatedWeightStr.isEmpty() ? 0 : Integer.parseInt(updatedWeightStr);
                double updatedPercentage = updatedPercentageStr.isEmpty() ? 0 : Integer.parseInt(updatedPercentageStr);

                updatedWeights.get().set(validRowIndex, updatedWeight);
                updatedPercentages.get().set(validRowIndex, updatedPercentage);

                if (updatedWeight != 0 || updatedPercentage != 0) {
                    System.out.println("Error: Row " + (i + 1) + " - Weight or Percentage is not 0 after toggle off. Weight: " + updatedWeight + ", Percentage: " + updatedPercentage);
                    TestRunner.getTest().log(Status.FAIL, "Row " + (i + 1) + " - Weight or Percentage is not 0 after toggle off. Weight: " + updatedWeight + ", Percentage: " + updatedPercentage);
                } else {
                    System.out.println("Row " + (i + 1) + " - Weight and Percentage are correctly set to 0 after toggle off.");
                    TestRunner.getTest().log(Status.PASS, "Row " + (i + 1) + " - Weight and Percentage are correctly set to 0 after toggle off.");
                }

                validRowIndex++;
            }

            System.out.println("Updated Weights: " + updatedWeights);
            System.out.println("Updated Percentages: " + updatedPercentages);
            TestRunner.getTest().log(Status.INFO, "Updated Weights: " + updatedWeights.toString());
            TestRunner.getTest().log(Status.INFO, "Updated Percentages: " + updatedPercentages.toString());

        } else {
            System.out.println("Main Grade Toggle is not enabled or not displayed.");
            TestRunner.getTest().log(Status.FAIL, "Main Grade Toggle is not enabled or not displayed.");
        }
    }

    public void scenarioQuestionsGradeToggleButton() throws InterruptedException {
        Thread.sleep(2000);

        previousWeights.get().clear();
        previousPercentages.get().clear();
        updatedWeights.get().clear();
        updatedPercentages.get().clear();
        disabledIndices.get().clear();

        WebElement wrapperTable = container_FinalizeQuestion.findElement(By.xpath("//div[contains(@class, 'MetaDataWrapper')]//table//tbody"));
        List<WebElement> rows = wrapperTable.findElements(By.tagName("tr"));

        Random random = new Random();
        List<Double> tempUpdatedWeights = new ArrayList<>();
        List<Double> tempUpdatedPercentages = new ArrayList<>();
        List<Double> tempPreviousWeights = new ArrayList<>();
        List<Double> tempPreviousPercentages = new ArrayList<>();

        for (int i = 0; i < rows.size(); i++) {
            WebElement row = rows.get(i);
            List<WebElement> cells = row.findElements(By.tagName("td"));

            WebElement typeCell = cells.get(4); // Assuming column 4 is the type
            String questionType = typeCell.getText().trim();

            if (questionType.equalsIgnoreCase("Content")) {
                tempPreviousWeights.add(Double.valueOf(-2));
                tempPreviousPercentages.add(Double.valueOf(-2));
                tempUpdatedWeights.add(Double.valueOf(-2));
                tempUpdatedPercentages.add(Double.valueOf(-2));
                System.out.println("Row " + (i + 1) + " is of type 'Content'. Ignoring it and storing -2 in arrays.");
                continue;
            }

            WebElement weightInput = cells.get(1).findElement(By.tagName("input"));
            WebElement percentageInput = cells.get(2).findElement(By.tagName("input"));

            String previousWeightStr = weightInput.getAttribute("value");
            String previousPercentageStr = percentageInput.getAttribute("value");

            int previousWeight = previousWeightStr.isEmpty() ? 0 : Integer.parseInt(previousWeightStr);
            int previousPercentage = previousPercentageStr.isEmpty() ? 0 : Integer.parseInt(previousPercentageStr);

            tempPreviousWeights.add(Double.valueOf(previousWeight));
            tempPreviousPercentages.add(Double.valueOf(previousPercentage));

            System.out.println("Question " + i + " - Previous Weight: " + previousWeight + ", Previous Percentage: " + previousPercentage);
        }

        if (disabledIndices.get().isEmpty()) {
            for (int i = 0; i < rows.size(); i++) {
                WebElement row = rows.get(i);
                List<WebElement> cells = row.findElements(By.tagName("td"));

                WebElement typeCell = cells.get(4);
                String questionType = typeCell.getText().trim();

                if (!questionType.equalsIgnoreCase("Content")) {
                    WebElement toggle = rows.get(i).findElement(By.xpath(".//input[@type='checkbox']"));
                    if (toggle.isSelected()) {
                        toggle.click(); // Disable the question
                        disabledIndices.get().add(Double.valueOf(i)); // Save the disabled question index
                        System.out.println("Minimum requirement met: Grading disabled for question: " + i);
                        break;
                    }
                }
            }
        }

        Thread.sleep(1000);

        for (int i = 0; i < rows.size(); i++) {
            WebElement row = rows.get(i);
            List<WebElement> cells = row.findElements(By.tagName("td"));

            WebElement typeCell = cells.get(4);
            String questionType = typeCell.getText().trim();

            if (questionType.equalsIgnoreCase("Content")) {
                System.out.println("Row " + (i + 1) + " is of type 'Content'. Ignoring it.");
                continue;
            }

            WebElement weightInput = cells.get(1).findElement(By.tagName("input"));
            WebElement percentageInput = cells.get(2).findElement(By.tagName("input"));

            if (disabledIndices.get().contains(Double.valueOf(i))) {
                String updatedWeightStr = weightInput.getAttribute("value");
                String updatedPercentageStr = percentageInput.getAttribute("value");

                int updatedWeight = updatedWeightStr.isEmpty() ? 0 : Integer.parseInt(updatedWeightStr);
                int updatedPercentage = updatedPercentageStr.isEmpty() ? 0 : Integer.parseInt(updatedPercentageStr);

                tempUpdatedWeights.add(Double.valueOf(updatedWeight));
                tempUpdatedPercentages.add(Double.valueOf(updatedPercentage));

                System.out.println("Grading was disabled for question " + i + " but inputs were saved.");
                TestRunner.getTest().log(Status.PASS, "Saved weight " + updatedWeight + " and percentage " + updatedPercentage + " for disabled question " + i);
            } else {
                if (weightInput.isEnabled() && percentageInput.isEnabled()) {
                    weightInput.clear();
                    percentageInput.clear();

                    clearInputWithJs(driver, weightInput);
                    clearInputWithJs(driver, percentageInput);
                    weightInput.clear();

                    int randomWeight = random.nextInt(9) + 2;
                    int randomPercentage = random.nextInt(100);

                    weightInput.sendKeys(String.valueOf(randomWeight));
                    percentageInput.sendKeys(String.valueOf(randomPercentage));

                    tempUpdatedWeights.add(Double.valueOf(randomWeight));
                    tempUpdatedPercentages.add(Double.valueOf(randomPercentage));

                    System.out.println("Updated weight for question " + i + ": " + randomWeight);
                    System.out.println("Updated percentage for question " + i + ": " + randomPercentage);

                    TestRunner.getTest().log(Status.PASS, "Updated weight for question " + i + ": " + randomWeight);
                    TestRunner.getTest().log(Status.PASS, "Updated percentage for question " + i + ": " + randomPercentage);
                } else {
                    tempUpdatedWeights.add(previousWeights.get().get(i));
                    tempUpdatedPercentages.add(previousPercentages.get().get(i));

                    System.out.println("Question " + i + " is disabled, saving previous values.");
                    TestRunner.getTest().log(Status.PASS, "Saved previous weight and percentage for disabled question " + i);
                }
            }
        }

        int minSize = Math.min(Math.min(tempPreviousWeights.size(), tempUpdatedWeights.size()), Math.min(tempPreviousPercentages.size(), tempUpdatedPercentages.size()));

        for (int i = 0; i < minSize; i++) {
            if (tempPreviousWeights.get(i) != -2) {
                previousWeights.get().add(tempPreviousWeights.get(i));
                previousPercentages.get().add(tempPreviousPercentages.get(i));
            }
            if (tempUpdatedWeights.get(i) != -2) {
                updatedWeights.get().add(tempUpdatedWeights.get(i));
                updatedPercentages.get().add(tempUpdatedPercentages.get(i));
            }
        }

        Thread.sleep(2000);
        WebElement totalWeight = driver.findElement(By.xpath("(//input[@name='questionWeight'])[2]"));
        String totalInitialWeight = totalWeight.getAttribute("value");
        System.out.println("Weight in assign time: " + totalInitialWeight);

        assignInitialWeight.set(Double.parseDouble(totalInitialWeight));
        System.out.println("Weight in assign time shows: " + assignInitialWeight.get());

        // Log all the values
        System.out.println("Previous Weights: " + previousWeights);
        System.out.println("Previous Percentages: " + previousPercentages);
        TestRunner.getTest().log(Status.INFO, "Previous Weights: " + previousWeights.toString());
        TestRunner.getTest().log(Status.INFO, "Previous Percentages: " + previousPercentages.toString());

        System.out.println("Disabled question toggle: " + disabledIndices.toString());
        TestRunner.getTest().log(Status.INFO, "Disabled question toggle: " + disabledIndices.toString());

        System.out.println("Updated Weights: " + updatedWeights);
        System.out.println("Updated Percentages: " + updatedPercentages);
        TestRunner.getTest().log(Status.INFO, "Updated Weights: " + updatedWeights.toString());
        TestRunner.getTest().log(Status.INFO, "Updated Percentages: " + updatedPercentages.toString());
    }

    public void scenarioParticularQuestionsGradeToggleButton() throws InterruptedException {
        Thread.sleep(2000);

        previousWeights.get().clear();
        previousPercentages.get().clear();
        updatedWeights.get().clear();
        updatedPercentages.get().clear();
        disabledIndices.get().clear();

        WebElement wrapperTable = container_FinalizeQuestion.findElement(By.xpath("//div[contains(@class, 'MetaDataWrapper')]//table//tbody"));
        List<WebElement> rows = wrapperTable.findElements(By.tagName("tr"));

        Random random = new Random();
        List<Double> tempUpdatedWeights = new ArrayList<>();
        List<Double> tempUpdatedPercentages = new ArrayList<>();
        List<Double> tempPreviousWeights = new ArrayList<>();
        List<Double> tempPreviousPercentages = new ArrayList<>();

        for (int i = 0; i < rows.size(); i++) {
            WebElement row = rows.get(i);
            List<WebElement> cells = row.findElements(By.tagName("td"));

            WebElement typeCell = cells.get(4); // Assuming column 4 is the type
            String questionType = typeCell.getText().trim();

            if (questionType.equalsIgnoreCase("Content")) {
                tempPreviousWeights.add(Double.valueOf(-2));
                tempPreviousPercentages.add(Double.valueOf(-2));
                tempUpdatedWeights.add(Double.valueOf(-2));
                tempUpdatedPercentages.add(Double.valueOf(-2));
                System.out.println("Row " + (i + 1) + " is of type 'Content'. Ignoring it and storing -2 in arrays.");
                continue;
            }

            WebElement weightInput = cells.get(1).findElement(By.tagName("input"));
            WebElement percentageInput = cells.get(2).findElement(By.tagName("input"));

            String previousWeightStr = weightInput.getAttribute("value");
            String previousPercentageStr = percentageInput.getAttribute("value");

            int previousWeight = previousWeightStr.isEmpty() ? 0 : Integer.parseInt(previousWeightStr);
            int previousPercentage = previousPercentageStr.isEmpty() ? 0 : Integer.parseInt(previousPercentageStr);

            tempPreviousWeights.add(Double.valueOf(previousWeight));
            tempPreviousPercentages.add(Double.valueOf(previousPercentage));

            System.out.println("Question " + i + " - Previous Weight: " + previousWeight + ", Previous Percentage: " + previousPercentage);
        }

        for (int i = 0; i < rows.size(); i++) {
            WebElement row = rows.get(i);
            List<WebElement> cells = row.findElements(By.tagName("td"));

            WebElement typeCell = cells.get(4);
            String questionType = typeCell.getText().trim();

            if (!questionType.equalsIgnoreCase("Content") && random.nextBoolean()) {
                WebElement toggle = rows.get(i).findElement(By.xpath(".//input[@type='checkbox']"));
                if (toggle.isSelected()) {
                    toggle.click(); // Disable the question
                    disabledIndices.get().add(Double.valueOf(i)); // Save the disabled question index
                    System.out.println("Grading disabled for question: " + i);
                }
            }
        }

        if (disabledIndices.get().isEmpty()) {
            for (int i = 0; i < rows.size(); i++) {
                WebElement row = rows.get(i);
                List<WebElement> cells = row.findElements(By.tagName("td"));

                WebElement typeCell = cells.get(4);
                String questionType = typeCell.getText().trim();

                if (!questionType.equalsIgnoreCase("Content")) {
                    WebElement toggle = rows.get(i).findElement(By.xpath(".//input[@type='checkbox']"));
                    if (toggle.isSelected()) {
                        toggle.click(); // Disable the question
                        disabledIndices.get().add(Double.valueOf(i)); // Save the disabled question index
                        System.out.println("Minimum requirement met: Grading disabled for question: " + i);
                        break;
                    }
                }
            }
        }

        Thread.sleep(1000);

        for (int i = 0; i < rows.size(); i++) {
            WebElement row = rows.get(i);
            List<WebElement> cells = row.findElements(By.tagName("td"));

            WebElement typeCell = cells.get(4);
            String questionType = typeCell.getText().trim();

            if (questionType.equalsIgnoreCase("Content")) {
                System.out.println("Row " + (i + 1) + " is of type 'Content'. Ignoring it.");
                continue;
            }

            WebElement weightInput = cells.get(1).findElement(By.tagName("input"));
            WebElement percentageInput = cells.get(2).findElement(By.tagName("input"));

            if (disabledIndices.get().contains(Double.valueOf(i))) {
                String updatedWeightStr = weightInput.getAttribute("value");
                String updatedPercentageStr = percentageInput.getAttribute("value");

                int updatedWeight = updatedWeightStr.isEmpty() ? 0 : Integer.parseInt(updatedWeightStr);
                int updatedPercentage = updatedPercentageStr.isEmpty() ? 0 : Integer.parseInt(updatedPercentageStr);

                tempUpdatedWeights.add(Double.valueOf(updatedWeight));
                tempUpdatedPercentages.add(Double.valueOf(updatedPercentage));

                System.out.println("Grading was disabled for question " + i + " but inputs were saved.");
                TestRunner.getTest().log(Status.PASS, "Saved weight " + updatedWeight + " and percentage " + updatedPercentage + " for disabled question " + i);
            } else {
                if (weightInput.isEnabled() && percentageInput.isEnabled()) {
                    weightInput.clear();
                    percentageInput.clear();

                    clearInputWithJs(driver, weightInput);
                    clearInputWithJs(driver, percentageInput);

                    int randomWeight = random.nextInt(9) + 2;
                    int randomPercentage = random.nextInt(100);

                    weightInput.sendKeys(String.valueOf(randomWeight));
                    percentageInput.sendKeys(String.valueOf(randomPercentage));

                    tempUpdatedWeights.add(Double.valueOf(randomWeight));
                    tempUpdatedPercentages.add(Double.valueOf(randomPercentage));

                    System.out.println("Updated weight for question " + i + ": " + randomWeight);
                    System.out.println("Updated percentage for question " + i + ": " + randomPercentage);

                    TestRunner.getTest().log(Status.PASS, "Updated weight for question " + i + ": " + randomWeight);
                    TestRunner.getTest().log(Status.PASS, "Updated percentage for question " + i + ": " + randomPercentage);
                } else {
                    tempUpdatedWeights.add(previousWeights.get().get(i));
                    tempUpdatedPercentages.add(previousPercentages.get().get(i));

                    System.out.println("Question " + i + " is disabled, saving previous values.");
                    TestRunner.getTest().log(Status.PASS, "Saved previous weight and percentage for disabled question " + i);
                }
            }
        }

        int minSize = Math.min(Math.min(tempPreviousWeights.size(), tempUpdatedWeights.size()), Math.min(tempPreviousPercentages.size(), tempUpdatedPercentages.size()));

        for (int i = 0; i < minSize; i++) {
            if (tempPreviousWeights.get(i) != -2) {
                previousWeights.get().add(Double.valueOf(tempPreviousWeights.get(i)));
                previousPercentages.get().add(Double.valueOf(tempPreviousPercentages.get(i)));
            }
            if (tempUpdatedWeights.get(i) != -2) {
                updatedWeights.get().add(Double.valueOf(tempUpdatedWeights.get(i)));
                updatedPercentages.get().add(Double.valueOf(tempUpdatedPercentages.get(i)));
            }
        }

        // Log all the values
        System.out.println("Previous Weights: " + previousWeights);
        System.out.println("Previous Percentages: " + previousPercentages);
        TestRunner.getTest().log(Status.INFO, "Previous Weights: " + previousWeights.toString());
        TestRunner.getTest().log(Status.INFO, "Previous Percentages: " + previousPercentages.toString());

        System.out.println("Disabled question toggle: " + disabledIndices.toString());
        TestRunner.getTest().log(Status.INFO, "Disabled question toggle: " + disabledIndices.toString());

        System.out.println("Updated Weights: " + updatedWeights);
        System.out.println("Updated Percentages: " + updatedPercentages);
        TestRunner.getTest().log(Status.INFO, "Updated Weights: " + updatedWeights.toString());
        TestRunner.getTest().log(Status.INFO, "Updated Percentages: " + updatedPercentages.toString());
    }

    private void clearInputWithJs(WebDriver driver, WebElement element) {
        JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
        jsExecutor.executeScript("arguments[0].value = '';", element);
    }

    public void scenarioDistributeWeightEvenlyButton() throws InterruptedException {
        Thread.sleep(2000);

        previousWeights.get().clear();
        previousPercentages.get().clear();
        updatedWeights.get().clear();
        updatedPercentages.get().clear();
        disabledIndices.get().clear();

        WebElement distributeWeightCheckbox = driver.findElement(By.xpath("//label[span[contains(text(), 'Distribute Weight evenly')]]//input[@type='checkbox']"));

        if (distributeWeightCheckbox.isEnabled()) {
            distributeWeightCheckbox.click();
            System.out.println("Distributed Weight Evenly Selected");
            TestRunner.getTest().log(Status.PASS, "Distributed Weight Evenly Option Selected");

            Thread.sleep(1000);

            WebElement wrapperTable = container_FinalizeQuestion.findElement(By.xpath("//div[contains(@class, 'MetaDataWrapper')]//table"));
            List<WebElement> rows = wrapperTable.findElements(By.tagName("tr"));

            for (int i = 1; i < rows.size(); i++) {
                WebElement row = rows.get(i);
                List<WebElement> cells = row.findElements(By.tagName("td"));

                WebElement typeCell = cells.get(4);
                String questionType = typeCell.getText().trim();

                WebElement weightInput = cells.get(1).findElement(By.tagName("input"));
                WebElement percentageInput = cells.get(2).findElement(By.tagName("input"));

                WebElement toggle = cells.get(6).findElement(By.xpath(".//input[@type='checkbox']"));

                if (questionType.equalsIgnoreCase("Content")) {
                    previousWeights.get().add(-2.0);
                    previousPercentages.get().add(-2.0);
                    System.out.println("Question " + i + " is of type 'Content'. Saving -2 for previous values.");
                    continue;
                }

                double previousWeight = Double.parseDouble(weightInput.getAttribute("value"));
                double previousPercentage = Double.parseDouble(percentageInput.getAttribute("value"));

                previousWeights.get().add(previousWeight);
                previousPercentages.get().add(previousPercentage);

                if (!toggle.isSelected()) {
                    updatedWeights.get().add(0.0);
                    updatedPercentages.get().add(0.0);
                    System.out.println("Question " + i + " toggle is off. Saving 0 in updated arrays.");
                } else {
                    double updatedWeight = Double.parseDouble(weightInput.getAttribute("value"));
                    double updatedPercentage = Double.parseDouble(percentageInput.getAttribute("value"));

                    updatedWeights.get().add(updatedWeight);
                    updatedPercentages.get().add(updatedPercentage);

                    System.out.println("Updated Weight for question " + i + ": " + updatedWeight);
                    TestRunner.getTest().log(Status.PASS, "Updated Weight for question " + i + ": " + updatedWeight);

                    System.out.println("Updated Percentage for question " + i + ": " + updatedPercentage);
                    TestRunner.getTest().log(Status.PASS, "Updated Percentage for question " + i + ": " + updatedPercentage);
                }
            }

            // Log the final values
            System.out.println("Previous Weights: " + previousWeights);
            System.out.println("Updated Weights: " + updatedWeights);
            System.out.println("Previous Percentages: " + previousPercentages);
            System.out.println("Updated Percentages: " + updatedPercentages);

            TestRunner.getTest().log(Status.PASS, "Weights and Percentages distributed evenly across all questions.");
        } else {
            System.out.println("Distribute Weight Evenly option is not enabled.");
            TestRunner.getTest().log(Status.FAIL, "Distribute Weight Evenly option is not enabled.");
        }
    }

    public void verifyTotalGradings() throws InterruptedException {
        try {
            WebElement pointsWrapper = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='pointWrapper']")));

            String assignmentTotalScore = AssignmentScoreVerification_PF.totalScore.get();
            System.out.println("Assignment total score: " + assignmentTotalScore);
            TestRunner.getTest().log(Status.INFO, "Assignment total score: " + assignmentTotalScore);

            if (pointsWrapper.isDisplayed()){
                WebElement totalPoints = driver.findElement(By.xpath("(//div[@class='pointWrapper']//span)[3]"));
                double totalPointDouble = Double.parseDouble(totalPoints.getText());
                System.out.println("Total Points: " + totalPointDouble);

                if (totalPointDouble == assignInitialWeight.get()){
                    System.out.println("Total weight is equal to total weight initial " + assignInitialWeight.get() + " = " + totalPointDouble);
                    TestRunner.getTest().log(Status.PASS, "Total weight is equal to total weight initial " + assignInitialWeight.get() + "." + totalPointDouble);

                    WebElement getPoints = driver.findElement(By.xpath("(//div[@class='pointWrapper']//span)[1]"));
                    double getPointDouble = Double.parseDouble(getPoints.getText());

                    String percentage = (getPointDouble / totalPointDouble) * 100 + "%";
                    System.out.println("Percentage: " + percentage);
                    System.out.println("Total Score: " + assignmentTotalScore);

                    // Remove '%' symbols, convert to Double, and then compare
                    double percentageValue = Double.parseDouble(percentage.replace("%", "").trim());
                    System.out.println("Value of percentage after we remove %: " + percentageValue);
                    TestRunner.getTest().log(Status.INFO, "Value of percentage: " + percentageValue);

                    double totalScoreValue = Double.parseDouble(assignmentTotalScore.replace("%", "").trim());
                    System.out.println("Total Scores after we remove %: " + totalScoreValue);
                    TestRunner.getTest().log(Status.INFO, "Total Scores: " + totalScoreValue);

                    if (percentageValue == totalScoreValue) {
                        System.out.println("Total percentage is equal to total score: " + assignmentTotalScore);
                        TestRunner.getTest().log(Status.PASS, "Total percentage is equal to total score: " + assignmentTotalScore);
                    } else {
                        System.out.println("Total percentage is not equal to total score: " + assignmentTotalScore);
                        TestRunner.getTest().log(Status.FAIL, "Total percentage is not equal to total score: " + assignmentTotalScore);
                    }

                } else {
                    System.out.println("Total weight is not equal to total weight initial " + assignInitialWeight.get() +" != " + totalPointDouble);
                    TestRunner.getTest().log(Status.FAIL, "Total weight is not equal to total weight initial " + assignInitialWeight.get() +" != " + totalPointDouble);
                }
            } else {
                System.out.println("This assessment is Set To Not Graded");
            }

        } catch (NoSuchElementException | TimeoutException e) {
            System.out.println("Assignment not found in close tab so that marks not get on Close review");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Assignment not found in close tab so that marks not get on Close review");
        } catch (Exception e) {
            System.out.println("Error in verifyTotalGradings: " + e.getMessage());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Error in verifyTotalGradings: " + e.getMessage());
        }
    }

    public void verifyAdvancedGradingScenarios() throws InterruptedException {
        WebElement overviewWrapper = driver.findElement(By.xpath("//div[contains(@class, 'OverviewScreenWrapper')]"));
//        WebElement answer_element = overviewWrapper.findElement(By.xpath(".//div[@class='ScrollbarsCustom-Content']"));
        List<WebElement> button_answers = overviewWrapper.findElements(By.xpath(".//button[@isCorrectAnswer]"));
        System.out.println("Total Answer: " + button_answers.size());
        if (!button_answers.isEmpty()) {
            WebElement button = button_answers.get(0);
            if (button.isDisplayed()) {
                System.out.println("Button was clicked: " + button.getText());
                button.click();
                System.out.println("Answer is clicked.");
                isGradingExist();
            } else {
                System.out.println("Button is not displayed.");
            }
        } else {
            System.out.println("No answer buttons found.");
        }
    }

    public void isGradingExist() throws InterruptedException {
        driver.switchTo().defaultContent();
        temp= 0;
        List<WebElement> questionButtons = nav_Pagination.findElements(By.xpath("//button[contains(@aria-label, 'Go to page')]"));
        for (WebElement questionButton : questionButtons) {
            String questionText = questionButton.getText();
            System.out.println("Question: " + questionText);
        }

        while (btn_NavNextPage.isEnabled()) {
            Thread.sleep(2000);
            verifyGradePercentage();
            btn_NavNextPage.click();
            Thread.sleep(2000);
        }

        Thread.sleep(2000);
        WebElement btn_CloseReview = driver.findElement(By.xpath("//button[@id='closeReview-btn']"));
        helper.scrollToElement(driver, btn_CloseReview);
        Thread.sleep(1000);
        System.out.println("Clicked on close review");
        btn_CloseReview.click();
    }

    private void verifyGradePercentage() {
        System.out.println("Starting Advanced Grading verification for index " + temp);
        TestRunner.getTest().log(Status.INFO, "Starting Advanced Grading verification for index " + temp);

        wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        WebElement questionPlayer = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("lesson-player-ifram")));
        driver.switchTo().frame(questionPlayer);

        try {
            if (temp < updatedWeights.get().size()) {
                System.out.println("Temp value is: " + temp);
                Double correspondingWeight = updatedWeights.get().get(temp);
                System.out.println("Corresponding weight at index " + temp + ": " + correspondingWeight);
                TestRunner.getTest().log(Status.INFO, "Corresponding weight at index " + temp + ": " + correspondingWeight);

                if (correspondingWeight == 0) {
                    verifySetToNotGradeQuestions();
                } else {
                    verifyAutoGradeQuestions();
                }

            } else {
                System.out.println("Invalid index: " + temp);
                TestRunner.getTest().log(Status.FAIL, "Invalid index " + temp);
            }

        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println("Set to not grade element not found. " + e.getMessage());
            TestRunner.getTest().log(Status.FAIL, "Neither 'Set to not grade' element nor graded element found.");
        } finally {
            driver.switchTo().defaultContent();
        }

        temp++;
        System.out.println("Finished verification for index " + temp);
        TestRunner.getTest().log(Status.INFO, "Finished verification for index " + temp);
    }

    private void verifySetToNotGradeQuestions() {
        System.out.println("Verifying 'Set to not grade' question at index " + temp);
        TestRunner.getTest().log(Status.INFO, "Verifying 'Set to not grade' question at index " + temp);

        WebElement textSetToNotGrade = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[contains(@class,'setNotGrade')]")));
        String setToNotGrade = textSetToNotGrade.getText();
        System.out.println("Attempted question not grade text: " + setToNotGrade);
        TestRunner.getTest().log(Status.INFO, "Attempted question not grade text: " + setToNotGrade);

        if (setToNotGrade.equals("Set to not grade")) {
            System.out.println("Text on assignment matches 'Set to not grade' at index " + temp);
            TestRunner.getTest().log(Status.PASS, "Verified 'Set to not grade' at index " + temp);
        } else {
            System.out.println("Text mismatch at index " + temp + ": Assignment text is " + setToNotGrade + " but expected 'Set to not grade'");
            TestRunner.getTest().log(Status.FAIL, "Text mismatch at index " + temp + ": Assignment text is " + setToNotGrade + " but expected 'Set to not grade'");
        }
    }

    private void verifyAutoGradeQuestions() {
        System.out.println("Verifying auto-graded question at index " + temp);
        TestRunner.getTest().log(Status.INFO, "Verifying auto-graded question at index " + temp);

        WebElement points = driver.findElement(By.xpath("//div[@class='pointWrapper']//span[3]"));
        String weightOnAssignmentAttemptStr = points.getText();
        System.out.println("Weight on Assignment: " + weightOnAssignmentAttemptStr);
        TestRunner.getTest().log(Status.INFO, "Weight on Assignment: " + weightOnAssignmentAttemptStr);

        double weightOnAssignmentAttempt = Double.parseDouble(weightOnAssignmentAttemptStr);
        System.out.println("Comparing Assignment Attempt Weight with Corresponding Weight at index " + temp);
        TestRunner.getTest().log(Status.INFO, "Comparing Assignment Attempt Weight with Corresponding Weight at index " + temp);

        if (temp < updatedWeights.get().size()) {
            Double correspondingWeight = updatedWeights.get().get(temp);
            System.out.println("Weight on Assignment Attempt: " + weightOnAssignmentAttempt + ", Corresponding weight: " + correspondingWeight);
            TestRunner.getTest().log(Status.INFO, "Weight on Assignment Attempt: " + weightOnAssignmentAttempt + ", Corresponding weight: " + correspondingWeight);

            if (weightOnAssignmentAttempt == correspondingWeight) {
                System.out.println("Weight matches at index " + temp + ": " + weightOnAssignmentAttempt);
                TestRunner.getTest().log(Status.PASS, "Verified weight matches at index " + temp);
            } else {
                System.out.println("Weight mismatch at index " + temp + ": Assignment weight is " + weightOnAssignmentAttempt + " but expected " + correspondingWeight);
                TestRunner.getTest().log(Status.FAIL, "Weight mismatch at index " + temp + ": Assignment weight is " + weightOnAssignmentAttempt + " but expected " + correspondingWeight);
            }
        } else {
            System.out.println("Invalid index: " + temp);
            TestRunner.getTest().log(Status.FAIL, "Invalid index " + temp);
        }
    }

    public void ValidateAdvancedGradingPointsWeightsInSelectedStudentTab() throws InterruptedException{

        if (!isPaginationDisplayed()) {
//            studentExecutor.AssignmentSubmitAsCompleted();
            return;
        }

        try {
        List<WebElement> questionButtons = nav_Pagination.findElements(By.xpath("//button[contains(@aria-label, 'Go to page')]"));

        for (WebElement questionButton : questionButtons) {
            String questionText = questionButton.getText();
            System.out.println("Question: " + questionText);
            TestRunner.getTest().log(Status.INFO, "Total Questions: " + questionText);
        }
        temp=0;


        System.out.println("I'm into Verify Advanced Grading At Teacher Side in Selected Student Tab");
        TestRunner.startTest("I'm into Verify Advanced Grading At Teacher Side in Selected Student Tab");
        while (btn_NavNextPage.isEnabled()) {
            Thread.sleep(2000);
            VerifyQuestionsInSelectedStudentTabForAdvancedGrading();
            VerifyAdvancedGradingWithPointsInGradeAssignment();
            Thread.sleep(2000);
            helper.scrollToElement(driver, btn_NavNextPage);
            Thread.sleep(2000);
            btn_NavNextPage.click();
            Thread.sleep(2000);
        }
        VerifyAdvancedGradingWithPointsInGradeAssignment();

        System.out.println("Advanced Grading Verify Successfully in Selected Student tab Points/Weight ");
        TestRunner.getTest().log(Status.PASS, "Test Case Passed:Advanced Grading Verify Successfully in Selected Student tab Points/Weight");
//            studentExecutor.AssignmentSubmitAsCompleted();
        } catch (NoSuchElementException | ElementNotInteractableException | TimeoutException e) {
            System.out.println("No Question found.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : No Question found or Question not visible");
        }
    }

    public void VerifyAdvancedGradingWithPointsInGradeAssignment() throws InterruptedException{

            System.out.println("I'm in to verify Advanced Grading in selected Student tab with Points/Weights ");
            TestRunner.getTest().log(Status.INFO, "I'm in to verify Advanced Grading in selected Student tab with Points/Weights");

            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(60));
        try {
            System.out.println("Temp value is : " + temp);
            // Locate the points input field and retrieve its value
            WebElement points = driver.findElement(By.xpath("(//input[@name='pointWeight '])"));
            String weightOnSelectedStudentTab = points.getAttribute("value"); // Get the value of the input field
            System.out.println("Points At Selected Student tab in Grade Assignment : " + weightOnSelectedStudentTab);
            helper.scrollToElement(driver, points);

            double weightOnGradeAssignment = Double.parseDouble(weightOnSelectedStudentTab); // Convert the value to double
            System.out.println("Size of Updated Weights at assign at time of Release Assignment: " + updatedWeights.get().size());
            TestRunner.getTest().log(Status.INFO, "Updated Weights at assign at time of Release Assignment: " + updatedWeights);
            System.out.println("Updated Weights at assign at time of Release Assignment: " + updatedWeights);

            if (temp < updatedWeights.get().size()) {
                Double correspondingWeight = updatedWeights.get().get(temp);
                System.out.println("Points/Weight on Grade Assignment: " + weightOnGradeAssignment);
                TestRunner.getTest().log(Status.INFO, "Points/Weight on Grade Assignment: " + weightOnGradeAssignment);
                System.out.println("Updated Weight from release Assignment: " + correspondingWeight);
                TestRunner.getTest().log(Status.INFO, "Updated Weight from release Assignment: " + correspondingWeight);

                if (weightOnGradeAssignment == correspondingWeight) {
                    System.out.println("Point/Weight in Grade Assignment match at question " + temp + ": " + weightOnGradeAssignment);
                    TestRunner.getTest().log(Status.INFO, "Point/Weight in Grade Assignment match at question " + temp + ": " + weightOnGradeAssignment);
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed: Verified Point matches at question index " + temp + " Point: " + weightOnGradeAssignment);
                } else {
                    TestRunner.getTest().log(Status.INFO, "Point/Weight mismatch at question index " + temp + ": Point in Grade Assignment " + weightOnGradeAssignment + " but expected " + correspondingWeight);
                    System.out.println("Point/Weight mismatch at question index " + temp + ": Point in Grade Assignment " + weightOnGradeAssignment + " but expected " + correspondingWeight);
                    TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Points/Weight mismatch at question " + temp);
                }
            } else {
                System.out.println("Invalid index: " + temp);
                TestRunner.getTest().log(Status.FAIL, "Invalid index " + temp);
            }

            temp++;

        } catch (NoSuchElementException e) {
            // Handle the case where the points field is not found
            System.out.println("Content Type Question Have not Grade Assignment Points");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Content Type Question Have not Grade Assignment Points ");
            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
        }

    }

    private boolean isPaginationDisplayed() {
        try {
            return nav_Pagination.isDisplayed();
        } catch (NoSuchElementException | ElementNotInteractableException | TimeoutException e) {
            return false;
        }
    }

    public void VerifyQuestionsInSelectedStudentTabForAdvancedGrading() throws InterruptedException{
        System.out.println("I'm in attempting all questions with correct answers");
        Thread.sleep(1000);

        WebElement questionPlayer = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("lesson-player-ifram")));
        driver.switchTo().frame(questionPlayer);
        WebElement QuestionBody = driver.findElement(By.xpath("//div[contains(@class, 'LessonPlayerRoot')]"));

        WebElement QuestionPlayer = null;

        try {
            List<WebElement> MultiParts = QuestionBody.findElements(By.xpath("//div[contains(@class, 'planComponentQuestion')]"));
            System.out.println("Total number of multi-part on this page: " + MultiParts.size());
            TestRunner.getTest().log(Status.INFO, "Total part of question (if multipart question exists): " + MultiParts.size());

            for (WebElement part : MultiParts) {
                QuestionPlayer = part.findElement(By.xpath(".//div[contains(@class, 'QuestionPlayer')]"));

                System.out.println("Question is found");
                String questionType = QuestionPlayer.getAttribute("data-type");
                System.out.println("Question Type is: " + questionType);
                TestRunner.getTest().log(Status.INFO, "Attempted question type is: " + questionType);

                WebElement questionRoot = QuestionPlayer.findElement(By.xpath(".//div[contains(@class, 'question-root')]"));
                questionID = questionRoot.getAttribute("data-question-id");
                System.out.println("Question ID is: " + questionID);
                TestRunner.getTest().log(Status.INFO, "Attempted question ID is: " + questionID);

            }
        } catch (NoSuchElementException e) {
            System.out.println("This is a content player question and have no any data type question");
            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
        } finally {
            driver.switchTo().defaultContent();
        }
    }
}
