package pageFactory.Assignmment.AssignmentModuleStudentSide;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Assignmment.AdvancedGrading_PF;
import pageFactory.Assignmment.CorrectAnswerExecutor_PF;
import pageFactory.Assignmment.ReleaseAssignment_PF;
import pageFactory.Assignmment.StudentExecutor_PF;
import pageFactory.MyContent.AssignAssessment_PF;

import java.awt.*;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import static pageFactory.Assignmment.CorrectAnswerExecutor_PF.assignmentNameForCorrect;

public class AssignmentModuleReleaseToAttempt_PF {


    WebDriverWait wait;
    WebDriver driver;
    Helper helper;
    StudentExecutor_PF studentExecutor;
    Actions actions;

    String baseUrl = Configurations.App_url;

    @FindBy(xpath = "//div[contains(@class, 'AssignmentWrapper')]")
    WebElement card_MyAssignment;

    String tab_AssignmentCard = "//div[@aria-label='wrapped label tabs example']";

    CorrectAnswerExecutor_PF correctAnswerExecutor_pf;
    AssignAssessment_PF assignAssessment_pf;
    ReleaseAssignment_PF releaseAssignment_pf;

    AdvancedGrading_PF advancedGrading_pf;

    public AssignmentModuleReleaseToAttempt_PF(WebDriver driver) {
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        helper = new Helper();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        actions = new Actions(driver);
        correctAnswerExecutor_pf = new CorrectAnswerExecutor_PF(driver);
        assignAssessment_pf = new AssignAssessment_PF(driver);
        releaseAssignment_pf = new ReleaseAssignment_PF(driver);
        studentExecutor = new StudentExecutor_PF(driver);
        advancedGrading_pf = new AdvancedGrading_PF(driver);
    }

    public void searchAssignmentByKeyWordInAssignmentModule() throws InterruptedException{

        String assignmentNameForCorrect = CorrectAnswerExecutor_PF.assignmentNameForCorrect.get();
        System.out.println("Want to search Assignment In Assignment Module: " + assignmentNameForCorrect);
        TestRunner.getTest().log(Status.INFO, "Want to search Assignment In Assignment Module: " + assignmentNameForCorrect);

        System.out.println("I'm into Search Assignment By Keyword in Assignment Module" + assignmentNameForCorrect);
        TestRunner.getTest().log(Status.INFO, "I'm into Search Assignment By Keyword in Assignment Module" + assignmentNameForCorrect);


        // Search for the assignment by keyword
        WebElement searchBar = driver.findElement(By.xpath("//input[@placeholder='Search Assignment by Keyword']"));
        searchBar.clear();
        searchBar.click();
        searchBar.sendKeys(assignmentNameForCorrect); // Enter assignment name
        searchBar.sendKeys(Keys.ENTER);
        Thread.sleep(3000);

        System.out.println("Search Button Click Successfully");
        Thread.sleep(3000);
    }

    public void SelectAssignmentForCorrectAnswersInAssignmentModule() throws InterruptedException, AWTException {
        System.out.println("I'm into Click On Assignment In Assignment Module" + assignmentNameForCorrect.get());
        TestRunner.getTest().log(Status.INFO, "I'm into Click On Assignment In Assignment Module" + assignmentNameForCorrect.get());

        TestRunner.getTest().log(Status.INFO, "Now Validate that Specific Assignments is present ");

        List<WebElement> totalAssignments = driver.findElements(By.xpath(".//div[contains(@class, 'StudentAssignmentCard')]//div[contains(@class, 'cardActions StudentAssignmentCardActions')]"));
        System.out.println("Total Assignments: " + totalAssignments.size());
        TestRunner.getTest().log(Status.INFO, "Total Assignments: " + totalAssignments.size());

        boolean assignmentFound = false;


        for (WebElement assignment : totalAssignments) {
            WebElement assignmentNameElement = assignment.findElement(By.xpath(".//h6"));
            String assignmentName = assignmentNameElement.getText();
            System.out.println("Assignment Name: " + assignmentName);

            if (assignmentName.equals(assignmentNameForCorrect.get())) {
                System.out.println("Found assignment: " + assignmentName);
                TestRunner.getTest().log(Status.INFO, "Specific Assignment Found: " + assignmentNameForCorrect.get());

                assignmentFound = true;
                try {
                    WebElement startOrResumeButton = assignment.findElement(By.xpath("//button/span[@type='START' or @type='RESUME']"));
                    String statusType = startOrResumeButton.getAttribute("type");
                    System.out.println("Assignment have Status: " + statusType);
                    TestRunner.getTest().log(Status.INFO, "Assignment have Status: " + statusType);
                    startOrResumeButton.click();
                    TestRunner.getTest().log(Status.PASS, "Successfully started assignment: " + assignmentName);
                    System.out.println("Assignment started");
                    Thread.sleep(3000);
                    studentExecutor.handleTeacherInstructionsDialog();
                    correctAnswerExecutor_pf.AttemptAndSubmitWithCorrectAnswers();
                    Thread.sleep(2000);

                } catch (NoSuchElementException e) {
                    System.out.println("START/RESUME button not found for assignment: " + assignmentName);
                    return;
                }

                refreshPage();
                Thread.sleep(3000);
                studentExecutor.dialogBox_ImpAnnouncement();

            }
        }

        if (!assignmentFound) {
            System.out.println("Assignment not found : " + assignmentNameForCorrect.get());
            TestRunner.getTest().log(Status.FAIL, "Assignment not found in the list By Using Custom Date Range Filter: " + assignmentNameForCorrect.get());
        }

    }

    private void refreshPage() {
        driver.navigate().to(baseUrl);
    }

    public void ReviewAttemptedCorrectAnswersAssignmentInAssignmentModule() throws InterruptedException{
        System.out.println("I'm into Validate Attempt Assignment In Assignment Module" + assignmentNameForCorrect.get());
        TestRunner.getTest().log(Status.INFO, "I'm into Validate Attempt Assignment In Assignment Module" + assignmentNameForCorrect.get());

        List<WebElement> totalAssignments = driver.findElements(By.xpath(".//div[contains(@class, 'StudentAssignmentCard')]//div[contains(@class, 'cardActions StudentAssignmentCardActions')]"));
        System.out.println("Total Assignments: " + totalAssignments.size());
        TestRunner.getTest().log(Status.INFO, "Total Assignments: " + totalAssignments.size());

        boolean assignmentFound = false;


        for (WebElement assignment : totalAssignments) {
            WebElement assignmentNameElement = assignment.findElement(By.xpath(".//h6"));
            String assignmentName = assignmentNameElement.getText();
            System.out.println("Assignment Name: " + assignmentName);

            if (assignmentName.equals(assignmentNameForCorrect.get())) {
                System.out.println("Found assignment: " + assignmentName);
                TestRunner.getTest().log(Status.INFO, "Assignment name in close tab: " + assignmentName);
                assignmentFound = true;
                try {
                    WebElement reviewButton = assignment.findElement(By.xpath(".//button[.//span[contains(text(), 'Review')] and not(@disabled)]"));
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed : Review button found and click on " + reviewButton.getText());
                    reviewButton.click();
                    System.out.println("Assignment open");
                    Thread.sleep(3000);
                    studentExecutor.handleTeacherInstructionsDialog();
                    advancedGrading_pf.getGradingsSummaryForAdvancedGrading();
                } catch (NoSuchElementException e) {
                    TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Review button not found for assignment: " + assignmentNameForCorrect.get());
                    return;
                }
                break;
            } else {
                System.out.println("Assignment not found: " + assignmentName);
            }
        }

        if (!assignmentFound) {
            System.out.println("Assignment not found : " + assignmentNameForCorrect.get());
            TestRunner.getTest().log(Status.FAIL, "Assignment not found in the list By Using Custom Date Range Filter: " + assignmentNameForCorrect.get());
        }

    }


    public void ValidateOpenFilterCheckbox() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm into Click on Open checkBox " );
        System.out.println("I'm into Click on Open checkBox ");


        Thread.sleep(1000);

        WebElement allCheckBox = driver.findElement(By.xpath("//input[contains(@class, 'PrivateSwitchBase-input') and @name='3' and @type='checkbox']"));

        if (allCheckBox.getAttribute("disabled") != null) {
            System.out.println("Checkbox is disabled. No assignments available.");
            TestRunner.getTest().log(Status.PASS, "Checkbox is disabled. No assignments available.");
        } else {
            // Checkbox is enabled, proceed to click
            System.out.println("Checkbox is enabled. Clicking the checkbox.");
            TestRunner.getTest().log(Status.PASS, "Checkbox is enabled. Clicking the checkbox.");
            allCheckBox.click();
        }
    }

    public void SubmittedAssignmentIsNotUnderInOpenFilter() throws InterruptedException{
        System.out.println("I'm into Validate That Submitted/Attempt Assignment is Not in Open In Assignment Module" + assignmentNameForCorrect.get());
        TestRunner.getTest().log(Status.INFO, "I'm into Validate That Submitted/Attempt Assignment is Not in Open In Assignment Module" + assignmentNameForCorrect.get());


        TestRunner.getTest().log(Status.INFO, "I'm into Validate That Submitted Assignment is Not in Open ");

        WebElement noAssignmentMessageElement;
        try {
            noAssignmentMessageElement = driver.findElement(By.xpath(".//div[contains(@class, 'MuiAlertTitle-root') and text()='No Assignment found!']"));
            String noAssessmentMessage = noAssignmentMessageElement.getText();
            System.out.println("No Assignment found message is displayed.");
            TestRunner.getTest().log(Status.INFO, "No Assignment found message is displayed. " + noAssessmentMessage);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: " + assignmentNameForCorrect.get() + " Is Not  found in Open tab.");
            return; // Exit the function since test case is passed.
        } catch (NoSuchElementException e) {
            // If the message is not found, continue checking assignments.
            System.out.println("No 'No Assignment found!' message. Checking assignment list...");
        }

        List<WebElement> totalAssignments = driver.findElements(By.xpath(".//div[contains(@class, 'StudentAssignmentCard')]//div[contains(@class, 'cardActions StudentAssignmentCardActions')]"));
        System.out.println("Total Assignments: " + totalAssignments.size());
        TestRunner.getTest().log(Status.INFO, "Total Assignments: " + totalAssignments.size());

        boolean assignmentFound = false;

        for (WebElement assignment : totalAssignments) {
            WebElement assignmentNameElement = assignment.findElement(By.xpath(".//h6"));
            String assignmentName = assignmentNameElement.getText();
            System.out.println("Assignment Name: " + assignmentName);

            if (assignmentName.equals(assignmentNameForCorrect.get())) {
                System.out.println("Found assignment: " + assignmentName);
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Submitted Assignment still found in Open tab: " + assignmentName);
                assignmentFound = true;
                break; // Exit the loop as we found the assignment.
            }
        }

        if (!assignmentFound) {
            System.out.println("Assignment not found : " + assignmentNameForCorrect.get());
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: No submitted assignments found in Open tab.");
        }

    }

    public void ValidateClosedFilterCheckbox() throws InterruptedException{

        TestRunner.getTest().log(Status.INFO, "I'm into Click on Closed checkBox " );
        System.out.println("I'm into Click on Closed checkBox ");

        Thread.sleep(1000);

        WebElement allCheckBox = driver.findElement(By.xpath("//input[contains(@class, 'PrivateSwitchBase-input') and @name='2' and @type='checkbox']"));

        if (allCheckBox.getAttribute("disabled") != null) {
            System.out.println("Checkbox is disabled. No assignments available.");
            TestRunner.getTest().log(Status.PASS, "Checkbox is disabled. No assignments available.");
        } else {
            // Checkbox is enabled, proceed to click
            System.out.println("Checkbox is enabled. Clicking the checkbox.");
            TestRunner.getTest().log(Status.PASS, "Checkbox is enabled. Clicking the checkbox.");
            allCheckBox.click();

        }

    }

    public void SubmittedAssignmentIsNotUnderInClosedFilter() throws InterruptedException{
        System.out.println("I'm into Validate That Submitted/Attempt Assignment is Not in Closed In Assignment Module" + assignmentNameForCorrect.get());
        TestRunner.getTest().log(Status.INFO, "I'm into Validate That Submitted/Attempt Assignment is Not in Closed In Assignment Module" + assignmentNameForCorrect.get());


        TestRunner.getTest().log(Status.INFO, "I'm into Validate That Submitted Assignment is Not in Closed ");

        WebElement noAssignmentMessageElement;
        try {
            noAssignmentMessageElement = driver.findElement(By.xpath(".//div[contains(@class, 'MuiAlertTitle-root') and text()='No Assignment found!']"));
            String noAssessmentMessage = noAssignmentMessageElement.getText();
            System.out.println("No Assignment found message is displayed.");
            TestRunner.getTest().log(Status.INFO, "No Assignment found message is displayed. " + noAssessmentMessage);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: " + assignmentNameForCorrect.get() + " Is Not  found in Closed tab.");
            return; // Exit the function since test case is passed.
        } catch (NoSuchElementException e) {
            // If the message is not found, continue checking assignments.
            System.out.println("No 'No Assignment found!' message. Checking assignment list...");
        }

        List<WebElement> totalAssignments = driver.findElements(By.xpath(".//div[contains(@class, 'StudentAssignmentCard')]//div[contains(@class, 'cardActions StudentAssignmentCardActions')]"));
        System.out.println("Total Assignments: " + totalAssignments.size());
        TestRunner.getTest().log(Status.INFO, "Total Assignments: " + totalAssignments.size());

        boolean assignmentFound = false;

        for (WebElement assignment : totalAssignments) {
            WebElement assignmentNameElement = assignment.findElement(By.xpath(".//h6"));
            String assignmentName = assignmentNameElement.getText();
            System.out.println("Assignment Name: " + assignmentName);

            if (assignmentName.equals(assignmentNameForCorrect.get())) {
                System.out.println("Found assignment: " + assignmentName);
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Submitted Assignment still found in Closed tab: " + assignmentName);
                assignmentFound = true;
                break; // Exit the loop as we found the assignment.
            }
        }

        if (!assignmentFound) {
            System.out.println("Assignment not found : " + assignmentNameForCorrect.get());
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: No submitted assignments found in Closed tab.");
        }
    }

    public void ValidateGradedFilterCheckbox() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm into Click on Graded checkBox " );
        System.out.println("I'm into Click on Graded checkBox ");


        Thread.sleep(1000);

        WebElement allCheckBox = driver.findElement(By.xpath("//input[contains(@class, 'PrivateSwitchBase-input') and @name='5' and @type='checkbox']"));

        // Check if the checkbox is disabled
        if (allCheckBox.getAttribute("disabled") != null) {
            System.out.println("Checkbox is disabled. No assignments available.");
            TestRunner.getTest().log(Status.PASS, "Checkbox is disabled. No assignments available.");
        } else {
            // Checkbox is enabled, proceed to click
            System.out.println("Checkbox is enabled. Clicking the checkbox.");
            TestRunner.getTest().log(Status.PASS, "Checkbox is enabled. Clicking the checkbox.");
            allCheckBox.click();

        }
    }

    public void GradedAssignmentIsUnderInGradedFilter() throws InterruptedException{
        System.out.println("I'm into Validate That Graded Assignment is in Graded filter In Assignment Module" + assignmentNameForCorrect.get());
        TestRunner.getTest().log(Status.INFO, "I'm into Validate That Graded Assignment is in Graded filter In Assignment Module" + assignmentNameForCorrect.get());


        TestRunner.getTest().log(Status.INFO, "I'm into Validate That Graded Assignment is in Graded Filter ");

        List<WebElement> totalAssignments = driver.findElements(By.xpath(".//div[contains(@class, 'StudentAssignmentCard')]//div[contains(@class, 'cardActions StudentAssignmentCardActions')]"));
        System.out.println("Total Assignments: " + totalAssignments.size());
        TestRunner.getTest().log(Status.INFO, "Total Assignments: " + totalAssignments.size());

        boolean assignmentFound = false;


        for (WebElement assignment : totalAssignments) {
            WebElement assignmentNameElement = assignment.findElement(By.xpath(".//h6"));
            String assignmentName = assignmentNameElement.getText().trim();
            System.out.println("Assignment Name: " + assignmentName);

            if (assignmentName.equals(assignmentNameForCorrect.get())) {
                System.out.println("Found assignment: " + assignmentName);
                TestRunner.getTest().log(Status.INFO, "Specific Assignment Found: " + assignmentNameForCorrect.get());

                assignmentFound = true;

                try {
                    // Locate the score element
                    WebElement scoreElement = assignment.findElement(By.xpath(".//span[text()='Score']/following-sibling::div"));
                    String score = scoreElement.getText().trim(); // Retrieve the score value

                    if (!score.isEmpty()) {
                        System.out.println("Graded Assignment: " + assignmentName + " | Score: " + score);
                        TestRunner.getTest().log(Status.PASS, "Graded Assignment Found: " + assignmentName + " | Score: " + score);
                    } else {
                        System.out.println("Ungraded Assignment: " + assignmentName);
                        TestRunner.getTest().log(Status.FAIL, "Ungraded Assignment: " + assignmentName);
                    }
                } catch (NoSuchElementException e) {
                    System.out.println("Score element not found for assignment: " + assignmentName);
                    TestRunner.getTest().log(Status.FAIL, "Score element not found for assignment: " + assignmentName);
                }
                break; // Exit the loop after finding the specific assignment
            }
        }

        if (!assignmentFound) {
            System.out.println("Graded Assignment not found in the list: : " + assignmentNameForCorrect.get());
            TestRunner.getTest().log(Status.FAIL, "Graded Assignment not found in the list: " + assignmentNameForCorrect.get());
        }

    }


    public void UncheckOpenCheckBoxAssignmentModule() throws InterruptedException {
        System.out.println("I'm Into Uncheck Open CheckBox In Assignment Module");
        TestRunner.getTest().log(Status.INFO, "I'm Into Uncheck Open CheckBox In Assignment Module");

        WebElement openCheckbox = driver.findElement(By.xpath("//input[contains(@class, 'PrivateSwitchBase-input') and @name='3' and @type='checkbox']"));

        if (openCheckbox.isSelected()) {
            System.out.println("'Open' checkbox is checked by default.");
            TestRunner.getTest().log(Status.INFO, "'Open' checkbox is checked by default And Now I'm unchecking it.");
            openCheckbox.click();
            TestRunner.getTest().log(Status.PASS, "'Open' checkbox is Now Unchecked");
        } else {
            System.out.println("Test Failed: 'Open' checkbox is NOT Display/Found.");
            TestRunner.getTest().log(Status.FAIL, "'Open' checkbox is NOT Display/Found");
        }
    }
}
