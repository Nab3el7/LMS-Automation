package pageFactory.Assignmment.AssignmentModuleStudentSide;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

public class AssignmentsModuleStudentSideFilters_PF {
    WebDriverWait wait;
    WebDriver driver;
    Helper helper;
    Actions actions;

    @FindBy(xpath = "//div[contains(@class, 'AssignmentWrapper')]")
    WebElement card_MyAssignment;

    String tab_AssignmentCard = "//div[@aria-label='wrapped label tabs example']";

    public AssignmentsModuleStudentSideFilters_PF(WebDriver driver) {
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        helper = new Helper();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        actions = new Actions(driver);
    }

    int totalAssignments = 0;
    public void GetAssignmentsCountFromDashboard() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm into Get Total Count of Assignments From Open And Close tab ");
        System.out.println("I'm into Get Total Count of Assignments From Open And Close tab ");

        card_MyAssignment.isDisplayed();
        WebElement tab_Assignment = card_MyAssignment.findElement(By.xpath(tab_AssignmentCard));
        TestRunner.getTest().log(Status.PASS, "Test Case Passed : My Assignment grid shows successfully");
        tab_Assignment.click();

        List<WebElement> AssignmentTabs = tab_Assignment.findElements(By.xpath(".//button"));
        TestRunner.getTest().log(Status.INFO, "Total assignment tabs are: " + AssignmentTabs.size());


        for (WebElement AssignmentTab : AssignmentTabs) {
            String tabText = AssignmentTab.getText();

            if (tabText.startsWith("Open") || tabText.startsWith("Closed")) {
                TestRunner.getTest().log(Status.INFO, "Processing tab: " + tabText);

                String[] parts = tabText.split(":");
                String numberStr = parts.length > 1 ? parts[1].trim() : "0";

                int number = Integer.parseInt(numberStr);

                TestRunner.getTest().log(Status.INFO, "Number of assignments in " + tabText.split(":")[0] + " tab: " + number);

                totalAssignments += number;

                AssignmentTab.click();
                Thread.sleep(1000);
            } else {
                TestRunner.getTest().log(Status.INFO, "Skipping tab: " + tabText);
            }
        }

        TestRunner.getTest().log(Status.INFO, "Total number of assignments in Open and Close tabs: " + totalAssignments);
        System.out.println("Total number of assignments in Open and Close tabs: " + totalAssignments);
    }

    @FindBy(xpath = "//div[@aria-label='Student Assignments']")
    WebElement link_student_Assignments_Module;


    public void ValidateClickStudentAssignmentsModule() throws InterruptedException{
        System.out.println("I'm in checking the side navbar");
        TestRunner.getTest().log(Status.INFO, "I'm in checking the side navbar");

        Thread.sleep(1000);

        WebElement navBar = driver.findElement(By.xpath("//div[@class='navigation']"));

        List<WebElement> totalLinks = navBar.findElements(By.tagName("a"));

        for (WebElement link : totalLinks) {
            String hrefValue = link.getAttribute("href");
            System.out.println("Link is: " + hrefValue);
        }

        if (link_student_Assignments_Module.isDisplayed()) {
            link_student_Assignments_Module.click();
            TestRunner.getTest().log(Status.PASS, "Testcase Passed   :  Side Navbar Shows and Clicked on Assignments Module Successfully");
        } else {
            TestRunner.getTest().log(Status.FAIL, "Testcase Failed   :  Side navbar and not shows and not clicked on Assignment Module");
        }
    }

    public void ValidateByDefaultWeekButtonIsPressed() throws InterruptedException{
        System.out.println("I'm Into Validate that By Default Week is Checked/Pressed");
        TestRunner.getTest().log(Status.INFO, "I'm Into Validate that By Default Week is Checked/Pressed");

        WebElement weekButton = driver.findElement(By.xpath("//button[contains(., 'Week') and @aria-pressed='true']"));

        boolean isWeekSelected = weekButton.getAttribute("aria-pressed").equals("true");

        if (isWeekSelected) {
            TestRunner.getTest().log(Status.PASS, "The 'Week' button is pressed by default.");
            System.out.println("The 'Week' button is pressed by default.");
        } else {
            TestRunner.getTest().log(Status.FAIL, "The 'Week' button is not pressed by default.");
            System.out.println("The 'Week' button is not pressed by default.");
        }

    }

    public void SelectShowAllClasses() throws InterruptedException{
        System.out.println("I'm Into Select Show All Classes From DropDown");
        TestRunner.getTest().log(Status.INFO, "I'm Into Select Show All Classes From DropDown");

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        WebElement classDropdown = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(@class,'MuiSelect')]")));

        if (classDropdown.isDisplayed() && classDropdown.isEnabled()) {
            System.out.println("Class dropdown enabled and clicking");
            TestRunner.getTest().log(Status.INFO, "Class dropdown enabled and clicking");

            classDropdown.click();
            Thread.sleep(5000);

            WebElement listBox = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//ul[@role='listbox']")));

            List<WebElement> totalClasses = listBox.findElements(By.tagName("li"));
            System.out.println("Total Classes: " + totalClasses.size());
            TestRunner.getTest().log(Status.INFO, "Total Classes: " + totalClasses.size());

            boolean classFound = false;
            for (WebElement classElement : totalClasses) {
                String classText = classElement.getText().trim();
                System.out.println("CLass in Dropdown: " + classText);

                if (classText.equals("Show All Classes")) {
                    System.out.println("Selected class: Show All Classes");
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed: Selected class: Show All Classes");
                    classElement.click();
                    classFound = true;
                    break;
                }
            }

            // If "Show All Classes" was not found, log an error
            if (!classFound) {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: 'Show All Classes' not found.");
            }
        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Class dropdown is not visible or enabled.");
        }

    }

    public void ValidateAndClickAllTime() throws InterruptedException{
        System.out.println("I'm Into Click On All Time");
        TestRunner.getTest().log(Status.INFO, "I'm Into Click On All Time");
        Thread.sleep(1000);

        WebElement AllTimesButton = driver.findElement(By.xpath("//button[contains(., 'All Time')]"));

        if (AllTimesButton.isDisplayed()){
            AllTimesButton.click();
            System.out.println("All Time Click Successfully");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: All Time Click Successfully");
        }
        else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: All Time not Display");
        }
    }

    public void CLickAllCheckBox() throws InterruptedException{
        System.out.println("I'm Into Click On All CheckBox");
        TestRunner.getTest().log(Status.INFO, "I'm Into Click On All CheckBox");

        Thread.sleep(1000);

        WebElement allCheckBox = driver.findElement(By.xpath("//input[contains(@class, 'PrivateSwitchBase-input') and @name='1' and @type='checkbox']"));

        allCheckBox.click();  // Click the checkbox to check it

        System.out.println("Test Passed: Checkbox is displayed and clicked.");

    }



    public void verifyAssignmentsCountMatchesInAssignmentModule() throws InterruptedException {
        System.out.println("Verifying that the number of assignments In All Checkbox Filter matches the count on the Dashboard.");
        TestRunner.getTest().log(Status.INFO, "Verifying that the number of assignments In All Checkbox Filter matches the count on the Dashboard.");

       System.out.println("Total Assignment Count From Dashboard: " + totalAssignments);
        TestRunner.getTest().log(Status.INFO, "Total Assignment Count From Dashboard: " + totalAssignments);

//        List<WebElement> allAssignments = getAllAssignmentsByScrolling();
//
//        int assignmentCountAfterScrolling = allAssignments.size();
//        System.out.println("Total assignments collected after scrolling From All: " + assignmentCountAfterScrolling);
//        TestRunner.getTest().log(Status.INFO, "Total assignments collected after scrolling From All: " + assignmentCountAfterScrolling);
//
//
//        if (assignmentCountAfterScrolling == totalAssignments) {
//            TestRunner.getTest().log(Status.PASS, "Assignment count matches the Open tab count. Assignment Module All Count: " + assignmentCountAfterScrolling);
//            System.out.println("Assignment count matches the Open tab count.Assignment Module All Count: " + assignmentCountAfterScrolling);
//        } else {
//            TestRunner.getTest().log(Status.FAIL, "Assignment count does not match. Collected: " + assignmentCountAfterScrolling + ", Expected: " + totalAssignments);
//            System.out.println("Assignment count does not match. Collected: " + assignmentCountAfterScrolling + ", Expected: " + totalAssignments);
//        }

        int finalAssignmentCount = getAllAssignmentCountFromMyAssignments();

        if (finalAssignmentCount == totalAssignments) {
            TestRunner.getTest().log(Status.PASS, "Assignment count matches the Open tab count. Assignment Module All Count: " + finalAssignmentCount);
            System.out.println("Assignment count matches the Open tab count.Assignment Module All Count: " + finalAssignmentCount);
        } else {
            TestRunner.getTest().log(Status.FAIL, "Assignment count does not match. Collected: " + finalAssignmentCount + ", Expected: " + totalAssignments);
            System.out.println("Assignment count does not match. Collected: " + finalAssignmentCount + ", Expected: " + totalAssignments);
        }


        List<WebElement> allAssignments = getAllAssignmentsByScrolling();

        int assignmentCountAfterScrolling = allAssignments.size();
        System.out.println("Total assignments collected after scrolling From All: " + assignmentCountAfterScrolling);
        TestRunner.getTest().log(Status.INFO, "Total assignments collected after scrolling From All: " + assignmentCountAfterScrolling);

    }

    public int getAllAssignmentCountFromMyAssignments() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO,"I'm Into Get All Assignment Count From My Assignments");
        System.out.println("I'm Into Get All Assignment Count From My Assignments");

        Thread.sleep(200);

        WebElement resultElement = driver.findElement(By.xpath("//div[contains(@class, 'search-result')]"));

        String text = resultElement.getText(); // e.g., "43 Results found according to your search criteria"
        String totalAssignmentCountOnAssignments = text.replaceAll("\\D+", "");

        System.out.println("Total Assignment Count From Assignment Module : " + totalAssignmentCountOnAssignments);

        return Integer.parseInt(totalAssignmentCountOnAssignments); // return it as an int
    }

    private List<WebElement> getAllAssignmentsByScrolling() throws InterruptedException {
        List<WebElement> allAssignments = new ArrayList<>();
        allAssignments.clear();

        WebElement assignmentPanel = driver.findElement(By.xpath("//div[@class='infinite-scroll-component ']"));
        wait.until(ExpectedConditions.visibilityOf(assignmentPanel));

        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollTo(0, 0);", assignmentPanel);
        Thread.sleep(1000);

        boolean endOfListReached = false;
        int previousCount = 0;
        int sameCountThreshold = 3;

        int stagnantCount = 0;

        while (!endOfListReached) {
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollTo(0, arguments[0].scrollHeight);", assignmentPanel);
            Thread.sleep(2000);

            List<WebElement> currentAssignments = assignmentPanel.findElements(By.xpath(".//div[contains(@class, 'StudentAssignmentCard')]//div[contains(@class, 'AvatarsWithDescriptionExtendWrapper')]"));
            int currentCount = currentAssignments.size();

            System.out.println("Current assignment count In Assignment Module All: " + currentCount);
            TestRunner.getTest().log(Status.INFO, "Current assignment count In Assignment Module All: " + currentCount);

            if (currentCount == previousCount) {
                stagnantCount++;
            } else {
                stagnantCount = 0;
                previousCount = currentCount;
                allAssignments = currentAssignments;
            }

            if (stagnantCount >= sameCountThreshold) {
                try {
                    WebElement endOfListMessage = assignmentPanel.findElement(By.xpath(".//p[contains(text(), 'End of List')]"));
                    if (endOfListMessage.isDisplayed()) {
                        System.out.println("Reached the end of the assignment list.");
                        TestRunner.getTest().log(Status.INFO, "Reached the end of the assignment list.");
                        endOfListReached = true;
                    }
                } catch (NoSuchElementException e) {
                    System.out.println("End of list not reached yet; continuing to scroll.");
                }
            }
        }

        return allAssignments;
    }

    public void UncheckAllCheckBox() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm into uncheck All checkBox " );
        System.out.println("I'm into uncheck All checkBox ");

        Thread.sleep(1000);

        WebElement allCheckBox = driver.findElement(By.xpath("//input[contains(@class, 'PrivateSwitchBase-input') and @name='1' and @type='checkbox']"));

        if (allCheckBox.isSelected()) {  // Check if the checkbox is already checked
            allCheckBox.click();  // Click the checkbox to uncheck it
            System.out.println("Test Passed: Checkbox is unchecked.");
            TestRunner.getTest().log(Status.PASS, "Checkbox All is unchecked " );
        } else {
            System.out.println("Checkbox was already unchecked.");
        }

    }

    public void ClickOpenCheckbox() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm into Click on Open checkBox " );
        System.out.println("I'm into Click on Open checkBox ");


        Thread.sleep(1000);

        WebElement allCheckBox = driver.findElement(By.xpath("//input[contains(@class, 'PrivateSwitchBase-input') and @name='3' and @type='checkbox']"));

        if (allCheckBox.getAttribute("disabled") != null) {
            System.out.println("Checkbox is disabled. No assignments available.");
            TestRunner.getTest().log(Status.PASS, "Checkbox is disabled. No assignments available.");
        } else {
            // Checkbox is enabled, proceed to click
            System.out.println("Checkbox is enabled. Clicking the checkbox.");
            TestRunner.getTest().log(Status.PASS, "Checkbox is enabled. Clicking the checkbox.");
            allCheckBox.click();

            Thread.sleep(3000);
            TestRunner.getTest().log(Status.INFO, "I'm into Validate Open Filter Assignments Have Started and Resume Assignments" );
            GetAllAssignmentsFromOpenFilter();
        }

    }

    public void GetAllAssignmentsFromOpenFilter() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm into Validate Open Filter " );
        System.out.println("I'm into Validate Open Filter  ");

        List<WebElement> allAssignmentsOpen = getAllAssignmentsByScrolling();

        int assignmentCountAfterScrolling = allAssignmentsOpen.size();
        System.out.println("Total assignments collected after scrolling From Open: " + assignmentCountAfterScrolling);
        TestRunner.getTest().log(Status.INFO, "Total assignments collected after scrolling From Open: " + assignmentCountAfterScrolling);

        TestRunner.getTest().log(Status.INFO, "Now Validate that Open Filter Have Start And Resume Assignments " );

        List<WebElement> totalAssignments = driver.findElements(By.xpath(".//div[contains(@class, 'StudentAssignmentCard')]//div[contains(@class, 'cardActions StudentAssignmentCardActions')]"));
        System.out.println("Total Assignments: " + totalAssignments.size());
        TestRunner.getTest().log(Status.INFO, "Total Assignments: " + totalAssignments.size());

        boolean allAssignmentsValid = true;

// Loop through all assignments to validate their status
        for (WebElement assignment : totalAssignments) {
            WebElement assignmentNameElement = assignment.findElement(By.xpath(".//h6")); // Get the assignment name
            String assignmentName = assignmentNameElement.getText();
            System.out.println("Assignment Name: " + assignmentName);

            try {
                // Locate the button with type 'START' or 'RESUME'
                WebElement startOrResumeButton = assignment.findElement(By.xpath("//button/span[@type='START' or @type='RESUME']"));
                String statusType = startOrResumeButton.getAttribute("type"); // Extract the 'type' attribute

                if (!"START".equals(statusType) && !"RESUME".equals(statusType)) {
                    System.out.println("Invalid status type found: " + statusType + " for assignment: " + assignmentName);
                    TestRunner.getTest().log(Status.FAIL, "Invalid status type: " + statusType + " for assignment: " + assignmentName);
                    allAssignmentsValid = false;
                } else {
                    System.out.println("Valid status (" + statusType + ") for assignment: " + assignmentName);
                    TestRunner.getTest().log(Status.INFO, "Valid status (" + statusType + ") for assignment: " + assignmentName);
                }

            } catch (NoSuchElementException e) {
                // If the button is not found
                System.out.println("No 'START' or 'RESUME' button found for assignment: " + assignmentName);
                TestRunner.getTest().log(Status.FAIL, "No 'START' or 'RESUME' button found for assignment: " + assignmentName);
                allAssignmentsValid = false;
            }
        }

// Final validation result
        if (allAssignmentsValid) {
            System.out.println("All assignments have valid 'START' or 'RESUME' status.");
            TestRunner.getTest().log(Status.PASS, "All assignments have valid 'START' or 'RESUME' status.");
        } else {
            System.out.println("Some assignments have invalid status or missing 'START'/'RESUME' button.");
            TestRunner.getTest().log(Status.FAIL, "Some assignments have invalid status or missing 'START'/'RESUME' button.");
        }
    }

    public void UncheckOpenCheckBox() throws InterruptedException{

        TestRunner.getTest().log(Status.INFO, "I'm into uncheck Open checkBox " );
        System.out.println("I'm into uncheck Open checkBox ");

        Thread.sleep(1000);

        WebElement allCheckBox = driver.findElement(By.xpath("//input[contains(@class, 'PrivateSwitchBase-input') and @name='3' and @type='checkbox']"));

        if (allCheckBox.isSelected()) {  // Check if the checkbox is already checked
            allCheckBox.click();  // Click the checkbox to uncheck it
            System.out.println("Test Passed: Checkbox Open is unchecked.");
            TestRunner.getTest().log(Status.PASS, "Checkbox Open is unchecked " );
        } else {
            System.out.println("Checkbox Open was already unchecked.");
        }

    }

    public void ClickClosedCheckbox() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm into Click on Closed checkBox " );
        System.out.println("I'm into Click on Closed checkBox ");


        Thread.sleep(1000);

        WebElement allCheckBox = driver.findElement(By.xpath("//input[contains(@class, 'PrivateSwitchBase-input') and @name='2' and @type='checkbox']"));

        if (allCheckBox.getAttribute("disabled") != null) {
            System.out.println("Checkbox is disabled. No assignments available.");
            TestRunner.getTest().log(Status.PASS, "Checkbox is disabled. No assignments available.");
        } else {
            // Checkbox is enabled, proceed to click
            System.out.println("Checkbox is enabled. Clicking the checkbox.");
            TestRunner.getTest().log(Status.PASS, "Checkbox is enabled. Clicking the checkbox.");
            allCheckBox.click();

            Thread.sleep(3000);
            TestRunner.getTest().log(Status.INFO, "I'm into Validate Closed Filter Assignments Have Closed and Submitted Assignments" );
            ValidateGetAllAssignmentsFromClosedFilter();
        }
    }

    public void ValidateGetAllAssignmentsFromClosedFilter() throws InterruptedException{

        TestRunner.getTest().log(Status.INFO, "I'm into Validate Closed Filter " );
        System.out.println("I'm into Validate Closed Filter  ");

        List<WebElement> allAssignmentsOpen = getAllAssignmentsByScrolling();

        int assignmentCountAfterScrolling = allAssignmentsOpen.size();
        System.out.println("Total assignments collected after scrolling From Closed: " + assignmentCountAfterScrolling);
        TestRunner.getTest().log(Status.INFO, "Total assignments collected after scrolling From Closed: " + assignmentCountAfterScrolling);

        TestRunner.getTest().log(Status.INFO, "Now Validate that Open Filter Have CLOSED And SUBMITTED Assignments " );

        List<WebElement> totalAssignments = driver.findElements(By.xpath(".//div[contains(@class, 'StudentAssignmentCard')]//div[contains(@class, 'cardActions StudentAssignmentCardActions')]"));
        System.out.println("Total Assignments: " + totalAssignments.size());
        TestRunner.getTest().log(Status.INFO, "Total Assignments: " + totalAssignments.size());

        boolean allAssignmentsValid = true;

// Loop through all assignments to validate their status
        for (WebElement assignment : totalAssignments) {
            WebElement assignmentNameElement = assignment.findElement(By.xpath(".//h6")); // Get the assignment name
            String assignmentName = assignmentNameElement.getText();
            System.out.println("Assignment Name: " + assignmentName);

            try {
                Thread.sleep(2000);
                WebElement closeOrSubmittedButton = assignment.findElement(By.xpath(".//span[@type='CLOSED' or @type='SUBMITTED']"));
                String statusType = closeOrSubmittedButton.getAttribute("type"); // Extract the 'type' attribute

                // Log the button details for debugging
                System.out.println("Retrieved statusType: " + statusType + " for assignment: " + assignmentName);
                String outerHTML = closeOrSubmittedButton.getAttribute("outerHTML");
                System.out.println("Button HTML: " + outerHTML);

                if (!"CLOSED".equals(statusType) && !"SUBMITTED".equals(statusType)) {
                    System.out.println("Invalid status type found: " + statusType + " for assignment: " + assignmentName);
                    TestRunner.getTest().log(Status.FAIL, "Invalid status type: " + statusType + " for assignment: " + assignmentName);
                    allAssignmentsValid = false;
                } else {
                    System.out.println("Valid status (" + statusType + ") for assignment: " + assignmentName);
                    TestRunner.getTest().log(Status.INFO, "Valid status (" + statusType + ") for assignment: " + assignmentName);
                }

            } catch (NoSuchElementException e) {
                // If the button is not found
                System.out.println("No 'CLOSED' or 'SUBMITTED' Status found for assignment: " + assignmentName);
                TestRunner.getTest().log(Status.FAIL, "No 'CLOSED' or 'SUBMITTED' Status found for assignment: " + assignmentName);
                allAssignmentsValid = false;
            }
        }

// Final validation result
        if (allAssignmentsValid) {
            System.out.println("All assignments have valid 'CLOSED' or 'SUBMITTED' status.");
            TestRunner.getTest().log(Status.PASS, "All assignments have valid 'CLOSED' or 'SUBMITTED' status.");
        } else {
            System.out.println("Some assignments have invalid status or missing 'CLOSED'/'SUBMITTED' button.");
            TestRunner.getTest().log(Status.FAIL, "Some assignments have invalid status or missing 'CLOSED'/'SUBMITTED' button.");
        }
    }

    public void UncheckClosedCheckbox() throws InterruptedException{

        TestRunner.getTest().log(Status.INFO, "I'm into uncheck Closed checkBox " );
        System.out.println("I'm into uncheck Closed checkBox ");

        Thread.sleep(1000);

        WebElement allCheckBox = driver.findElement(By.xpath("//input[contains(@class, 'PrivateSwitchBase-input') and @name='2' and @type='checkbox']"));

        if (allCheckBox.isSelected()) {  // Check if the checkbox is already checked
            allCheckBox.click();  // Click the checkbox to uncheck it
            System.out.println("Test Passed: Checkbox Closed is unchecked.");
            TestRunner.getTest().log(Status.PASS, "Checkbox Closed is unchecked " );
        } else {
            System.out.println("Checkbox Closed was already unchecked.");
        }

    }

    public void ClickGradedCheckbox() throws InterruptedException{

        TestRunner.getTest().log(Status.INFO, "I'm into Click on Graded checkBox " );
        System.out.println("I'm into Click on Graded checkBox ");


        Thread.sleep(1000);

        WebElement allCheckBox = driver.findElement(By.xpath("//input[contains(@class, 'PrivateSwitchBase-input') and @name='5' and @type='checkbox']"));

        // Check if the checkbox is disabled
        if (allCheckBox.getAttribute("disabled") != null) {
            System.out.println("Checkbox is disabled. No assignments available.");
            TestRunner.getTest().log(Status.PASS, "Checkbox is disabled. No assignments available.");
        } else {
            // Checkbox is enabled, proceed to click
            System.out.println("Checkbox is enabled. Clicking the checkbox.");
            TestRunner.getTest().log(Status.PASS, "Checkbox is enabled. Clicking the checkbox.");
            allCheckBox.click();
            Thread.sleep(3000);

            TestRunner.getTest().log(Status.INFO, "I'm into Validate Graded Filter Assignments Have Scores" );
            ValidateAllGradedFilterAssignmentHaveScores();
        }
    }

    public void ValidateAllGradedFilterAssignmentHaveScores() throws InterruptedException{

        TestRunner.getTest().log(Status.INFO, "I'm into Validate Graded Filter Assignments Have Scores " );
        System.out.println("I'm into Validate Graded Filter Assignments Have Scores ");

        List<WebElement> allAssignmentsOpen = getAllAssignmentsByScrolling();

        int assignmentCountAfterScrolling = allAssignmentsOpen.size();
        System.out.println("Total assignments collected after scrolling From Graded: " + assignmentCountAfterScrolling);
        TestRunner.getTest().log(Status.INFO, "Total assignments collected after scrolling From Graded: " + assignmentCountAfterScrolling);

        TestRunner.getTest().log(Status.INFO, "Now Validate that Open Filter Have Scores " );

        List<WebElement> totalAssignments = driver.findElements(By.xpath(".//div[contains(@class, 'StudentAssignmentCardActions')]"));
        System.out.println("Total Assignments: " + totalAssignments.size());
        TestRunner.getTest().log(Status.INFO, "Total Assignments: " + totalAssignments.size());

        boolean allAssignmentsGraded = true;

        for (WebElement assignment : totalAssignments) {
            WebElement assignmentNameElement = assignment.findElement(By.xpath(".//h6/span")); // Get the assignment name
            String assignmentName = assignmentNameElement.getText();
            System.out.println("Assignment Name: " + assignmentName);

            try {
                // Check if the assignment contains a Score field
                List<WebElement> scoreElements = assignment.findElements(By.xpath(".//span[text()='Score']/following-sibling::div"));
                if (!scoreElements.isEmpty()) {
                    String score = scoreElements.get(0).getText().trim(); // Retrieve the score value
                    System.out.println("Graded Assignment: " + assignmentName + " | Score: " + score);
                    TestRunner.getTest().log(Status.INFO, "Graded Assignment: " + assignmentName + " | Score: " + score);
                } else {
                    System.out.println("Ungraded Assignment: " + assignmentName);
                    TestRunner.getTest().log(Status.FAIL, "Ungraded Assignment: " + assignmentName);
                    allAssignmentsGraded = false;
                }
            } catch (NoSuchElementException e) {
                // Handle cases where elements are not found
                System.out.println("No Score information found for assignment: " + assignmentName);
                TestRunner.getTest().log(Status.FAIL, "No Score information found for assignment: " + assignmentName);
                allAssignmentsGraded = false;
            }
        }

        if (allAssignmentsGraded) {
            System.out.println("All assignments are Graded.");
            TestRunner.getTest().log(Status.PASS, "All assignments are Graded.");
        } else {
            System.out.println("Some assignments are ungraded or missing score details.");
            TestRunner.getTest().log(Status.FAIL, "Some assignments are ungraded or missing score details.");
        }
    }

    public void UncheckGradedCheckbox() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm into uncheck Graded checkBox " );
        System.out.println("I'm into uncheck Graded checkBox ");

        Thread.sleep(1000);

        WebElement allCheckBox = driver.findElement(By.xpath("//input[contains(@class, 'PrivateSwitchBase-input') and @name='5' and @type='checkbox']"));

        if (allCheckBox.isSelected()) {  // Check if the checkbox is already checked
            allCheckBox.click();  // Click the checkbox to uncheck it
            System.out.println("Test Passed: Checkbox Graded is unchecked.");
            TestRunner.getTest().log(Status.PASS, "Checkbox Graded is unchecked " );
        } else {
            System.out.println("Checkbox Graded was already unchecked.");
        }
    }

    public void ValidateClickFutureCheckBox() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm into Click on  Future checkBox " );
        System.out.println("I'm into Click on  Future checkBox  ");

        Thread.sleep(1000);

        WebElement futureCheckbox = driver.findElement(By.xpath("//input[@name='4' and @type='checkbox']"));

// Check if the checkbox is disabled
        if (futureCheckbox.getAttribute("disabled") != null) {
            System.out.println("Checkbox is disabled. No assignments available.");
            TestRunner.getTest().log(Status.PASS, "Checkbox is disabled. No assignments available.");
        } else {
            // Checkbox is enabled, proceed to click
            System.out.println("Checkbox is enabled. Clicking the checkbox.");
            TestRunner.getTest().log(Status.PASS, "Checkbox is enabled. Clicking the checkbox.");
            futureCheckbox.click();

            Thread.sleep(3000);
            TestRunner.getTest().log(Status.INFO, "I'm into Validate That Future Assignments have Future Status" );
            ValidateFutureAssignments();
        }

    }

    public void ValidateFutureAssignments() throws InterruptedException{

        TestRunner.getTest().log(Status.INFO, "I'm into Validate Future Filter " );
        System.out.println("I'm into Validate Future Filter  ");

        List<WebElement> allAssignmentsOpen = getAllAssignmentsByScrolling();

        int assignmentCountAfterScrolling = allAssignmentsOpen.size();
        System.out.println("Total assignments collected after scrolling From Future: " + assignmentCountAfterScrolling);
        TestRunner.getTest().log(Status.INFO, "Total assignments collected after scrolling From Future: " + assignmentCountAfterScrolling);

        TestRunner.getTest().log(Status.INFO, "Now Validate that Open Filter Have Future Assignments " );

        List<WebElement> totalAssignments = driver.findElements(By.xpath(".//div[contains(@class, 'StudentAssignmentCard')]//div[contains(@class, 'cardActions StudentAssignmentCardActions')]"));
        System.out.println("Total Assignments: " + totalAssignments.size());
        TestRunner.getTest().log(Status.INFO, "Total Assignments: " + totalAssignments.size());

        boolean allAssignmentsValid = true;

// Loop through all assignments to validate their status
        for (WebElement assignment : totalAssignments) {
            WebElement assignmentNameElement = assignment.findElement(By.xpath(".//h6")); // Get the assignment name
            String assignmentName = assignmentNameElement.getText();
            System.out.println("Assignment Name: " + assignmentName);

            try {
                Thread.sleep(2000);
                WebElement futureButton = assignment.findElement(By.xpath(".//span[@type='FUTURE']"));
                String statusType = futureButton.getAttribute("type"); // Extract the 'type' attribute

                // Log the button details for debugging
                System.out.println("Retrieved statusType: " + statusType + " for assignment: " + assignmentName);
                String outerHTML = futureButton.getAttribute("outerHTML");
                System.out.println("Button HTML: " + outerHTML);

                if (!"FUTURE".equals(statusType)) {
                    System.out.println("Invalid status type found: " + statusType + " for assignment: " + assignmentName);
                    TestRunner.getTest().log(Status.FAIL, "Invalid status type: " + statusType + " for assignment: " + assignmentName);
                    allAssignmentsValid = false;
                } else {
                    System.out.println("Valid status (" + statusType + ") for assignment: " + assignmentName);
                    TestRunner.getTest().log(Status.INFO, "Valid status (" + statusType + ") for assignment: " + assignmentName);
                }

            } catch (NoSuchElementException e) {
                // If the button is not found
                System.out.println("No 'FUTURE' Status found for assignment: " + assignmentName);
                TestRunner.getTest().log(Status.FAIL, "No 'FUTURE' Status found for assignment: " + assignmentName);
                allAssignmentsValid = false;
            }
        }

// Final validation result
        if (allAssignmentsValid) {
            System.out.println("All assignments have valid 'FUTURE' status.");
            TestRunner.getTest().log(Status.PASS, "All assignments have valid 'FUTURE' status.");
        } else {
            System.out.println("Some assignments have invalid status or missing 'FUTURE' button.");
            TestRunner.getTest().log(Status.FAIL, "Some assignments have invalid status or missing 'FUTURE' button.");
        }
    }


    public void UncheckFutureCheckbox() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm into uncheck Future checkBox " );
        System.out.println("I'm into uncheck Future checkBox ");

        Thread.sleep(1000);

        WebElement allCheckBox = driver.findElement(By.xpath("//input[contains(@class, 'PrivateSwitchBase-input') and @name='4' and @type='checkbox']"));

        if (allCheckBox.isSelected()) {  // Check if the checkbox is already checked
            allCheckBox.click();  // Click the checkbox to uncheck it
            System.out.println("Test Passed: Checkbox Future is unchecked.");
            TestRunner.getTest().log(Status.PASS, "Checkbox Future is unchecked " );
        } else {
            System.out.println("Checkbox Future was already unchecked.");
        }
    }


    public void SelectClasses() throws InterruptedException{
        System.out.println("I'm Into Select Classes From DropDown");
        TestRunner.getTest().log(Status.INFO, "I'm Into Select Classes From DropDown");

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        WebElement classDropdown = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(@class,'MuiSelect')]")));

        if (classDropdown.isDisplayed() && classDropdown.isEnabled()) {
            System.out.println("Class dropdown enabled and clicking");
            TestRunner.getTest().log(Status.INFO, "Class dropdown enabled and clicking");

            classDropdown.click();
            Thread.sleep(5000);

            WebElement listBox = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//ul[@role='listbox']")));

            List<WebElement> totalClasses = listBox.findElements(By.tagName("li"));
            System.out.println("Total Classes: " + totalClasses.size());
            TestRunner.getTest().log(Status.INFO, "Total Classes: " + totalClasses.size());

            boolean classFound = false;
            for (WebElement classElement : totalClasses) {
                String classText = classElement.getText().trim();
                System.out.println("CLass in Dropdown: " + classText);

                if (classText.equals("FL Grade 5")) {
                    System.out.println("Selected class: FL Grade 5");
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed: Selected class: FL Grade 5");
                    classElement.click();
                    classFound = true;
                    break;
                }
            }

            // If "Show All Classes" was not found, log an error
            if (!classFound) {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: 'FL Grade 5' not found.");
            }
        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Class dropdown is not visible or enabled.");
        }

    }

}
