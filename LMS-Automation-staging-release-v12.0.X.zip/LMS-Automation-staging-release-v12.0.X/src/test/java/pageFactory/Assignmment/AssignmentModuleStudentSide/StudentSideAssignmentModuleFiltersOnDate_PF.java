package pageFactory.Assignmment.AssignmentModuleStudentSide;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Assignmment.CorrectAnswerExecutor_PF;
import pageFactory.Assignmment.InCorrectAnswerExecutor_PF;
import pageFactory.Assignmment.ReleaseAssignment_PF;
import pageFactory.MyContent.AssignAssessment_PF;

import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class StudentSideAssignmentModuleFiltersOnDate_PF {

    WebDriverWait wait;
    WebDriver driver;
    Helper helper;
    Actions actions;

    @FindBy(xpath = "//div[contains(@class, 'AssignmentWrapper')]")
    WebElement card_MyAssignment;

    String tab_AssignmentCard = "//div[@aria-label='wrapped label tabs example']";

    CorrectAnswerExecutor_PF correctAnswerExecutor_pf;
    AssignAssessment_PF assignAssessment_pf;
    ReleaseAssignment_PF releaseAssignment_pf;

    public StudentSideAssignmentModuleFiltersOnDate_PF(WebDriver driver) {
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        helper = new Helper();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        actions = new Actions(driver);
        correctAnswerExecutor_pf = new CorrectAnswerExecutor_PF(driver);
        assignAssessment_pf = new AssignAssessment_PF(driver);
        releaseAssignment_pf = new ReleaseAssignment_PF(driver);
    }

    int allTotalAssignments = 0;
    public void GetAssignmentsFromDashboard() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm into Get Total Count of Assignments From Open And Close tab ");
        System.out.println("I'm into Get Total Count of Assignments From Open And Close tab ");

        card_MyAssignment.isDisplayed();
        WebElement tab_Assignment = card_MyAssignment.findElement(By.xpath(tab_AssignmentCard));
        TestRunner.getTest().log(Status.PASS, "Test Case Passed : My Assignment grid shows successfully");
        tab_Assignment.click();

        List<WebElement> AssignmentTabs = tab_Assignment.findElements(By.xpath(".//button"));
        TestRunner.getTest().log(Status.INFO, "Total assignment tabs are: " + AssignmentTabs.size());


        for (WebElement AssignmentTab : AssignmentTabs) {
            String tabText = AssignmentTab.getText();

            if (tabText.startsWith("Open") || tabText.startsWith("Closed")) {
                TestRunner.getTest().log(Status.INFO, "Processing tab: " + tabText);

                String[] parts = tabText.split(":");
                String numberStr = parts.length > 1 ? parts[1].trim() : "0";

                int number = Integer.parseInt(numberStr);

                TestRunner.getTest().log(Status.INFO, "Number of assignments in " + tabText.split(":")[0] + " tab: " + number);

                allTotalAssignments += number;

                AssignmentTab.click();
                Thread.sleep(1000);
            } else {
                TestRunner.getTest().log(Status.INFO, "Skipping tab: " + tabText);
            }
        }

        TestRunner.getTest().log(Status.INFO, "Total number of assignments in Open and Close tabs: " + allTotalAssignments);
        System.out.println("Total number of assignments in Open and Close tabs: " + allTotalAssignments);
    }


    public void validateAssignmentsCountMatchesAllTimeAssignment() throws InterruptedException {
        System.out.println("Verifying that the number of assignments In All Checkbox Filter matches the count on the Dashboard.");
        TestRunner.getTest().log(Status.INFO, "Verifying that the number of assignments In All Checkbox Filter matches the count on the Dashboard.");
//
//        System.out.println("Total Assignment Count From Dashboard: " + allTotalAssignments);
//        TestRunner.getTest().log(Status.INFO, "Total Assignment Count From Dashboard: " + allTotalAssignments);

        List<WebElement> allAssignments = getAllAssignmentsByScrolling();

        int assignmentCountAfterScrolling = allAssignments.size();
        System.out.println("Total assignments collected after scrolling From All Time: " + assignmentCountAfterScrolling);
        TestRunner.getTest().log(Status.INFO, "Total assignments collected after scrolling From All Time: " + assignmentCountAfterScrolling);

        int finalAssignmentCount = getAllAssignmentCountFromMyAssignments();


        if (assignmentCountAfterScrolling == finalAssignmentCount) {
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Assignment count matches. Assignment Module All Count: " + assignmentCountAfterScrolling);
            System.out.println("Assignment count matches.Assignment Module All Count: " + assignmentCountAfterScrolling);
        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Assignment count does not match. Collected: " + assignmentCountAfterScrolling + ", Expected: " + finalAssignmentCount);
            System.out.println("Assignment count does not match. Collected: " + assignmentCountAfterScrolling + ", Expected: " + finalAssignmentCount);
        }


    }

    public int getAllAssignmentCountFromMyAssignments() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO,"I'm Into Get All Assignment Count From My Assignments");
        System.out.println("I'm Into Get All Assignment Count From My Assignments");

        Thread.sleep(200);

        WebElement resultElement = driver.findElement(By.xpath("//div[contains(@class, 'search-result')]"));

        String text = resultElement.getText(); // e.g., "43 Results found according to your search criteria"
        String totalAssignmentCountOnAssignments = text.replaceAll("\\D+", "");

        System.out.println("Total Assignment Count From Assignment Module : " + totalAssignmentCountOnAssignments);

        return Integer.parseInt(totalAssignmentCountOnAssignments); // return it as an int
    }

    public void ValidateClickTodayButton() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm Validate and Click on Today Button ");
        System.out.println("I'm Validate and Click on Today Button ");

        Thread.sleep(1000);

        WebElement AllTodayButton = driver.findElement(By.xpath("//button[span[text()='Today']]"));

        if (AllTodayButton.isDisplayed()){
            AllTodayButton.click();
            System.out.println("Week Button Click Successfully");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Week Button Click Successfully");
        }
        else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Week Button not Display");
        }

    }

    public void ValidateTodayAssignmentDueDate() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm Validate All Assignments Under Today Filter Have Today's Due");
        System.out.println("I'm Validate All Assignments Under Today Filter Have Today's Due ");

        List<WebElement> allAssignments = getAllAssignmentsByScrolling();

        int assignmentCountAfterScrollingForToday = allAssignments.size();
        System.out.println("Total assignments collected after scrolling From Open: " + assignmentCountAfterScrollingForToday);
        TestRunner.getTest().log(Status.INFO, "Total assignments collected after scrolling From Open: " + assignmentCountAfterScrollingForToday);

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String todayDate = sdf.format(new Date());

        TestRunner.getTest().log(Status.INFO, "Now Validate that Assignments In Today Have Today's Due Date");

        List<WebElement> totalAssignments = driver.findElements(By.xpath(".//div[contains(@class, 'StudentAssignmentCard')]//div[contains(@class, 'cardActions StudentAssignmentCardActions')]"));
        System.out.println("Total Assignments: " + totalAssignments.size());
        TestRunner.getTest().log(Status.INFO, "Total Assignments: " + totalAssignments.size());

        for (WebElement assignment : totalAssignments) {
            WebElement assignmentNameElement = assignment.findElement(By.xpath(".//h6")); // Get the assignment name
            String assignmentName = assignmentNameElement.getText();
            System.out.println("Assignment Name: " + assignmentName);

            try {
                // Extract the due date from the assignment element
                WebElement dueDateElement = assignment.findElement(By.xpath(".//span[contains(text(),'Due:')]"));
                String dueDateText = dueDateElement.getText();

                // The due date is in format "Due: yyyy-MM-dd hh:mm a"
                String dueDate = dueDateText.split(" ")[1]; // Extract the date part, e.g., "2024-11-21"

                // Compare the extracted due date with today's date
                if (todayDate.equals(dueDate)) {
                    System.out.println("Assignment '" + assignmentName + "' has today's due date: " + dueDate);
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed: Assignment:  '" + assignmentName + "' has today's due date: " + dueDate);
                } else {
                    System.out.println("Assignment '" + assignmentName + "' has an incorrect due date: " + dueDate);
                    TestRunner.getTest().log(Status.FAIL, "Assignment '" + assignmentName + "' has an incorrect due date: " + dueDate);
                }
            } catch (Exception e) {
                // Handle cases where due date is not found or other issues
                System.out.println("Error finding due date for assignment: " + assignmentName);
                TestRunner.getTest().log(Status.FAIL, "Error finding due date for assignment: " + assignmentName);
            }
        }


    }

    private List<WebElement> getAllAssignmentsByScrolling() throws InterruptedException {
        List<WebElement> allAssignments = new ArrayList<>();
        allAssignments.clear();

        WebElement assignmentPanel = driver.findElement(By.xpath("//div[@class='infinite-scroll-component ']"));
        wait.until(ExpectedConditions.visibilityOf(assignmentPanel));

        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollTo(0, 0);", assignmentPanel);
        Thread.sleep(1000);

        boolean endOfListReached = false;
        int previousCount = 0;
        int sameCountThreshold = 3;

        int stagnantCount = 0;

        while (!endOfListReached) {
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollTo(0, arguments[0].scrollHeight);", assignmentPanel);
            Thread.sleep(2000);

            List<WebElement> currentAssignments = assignmentPanel.findElements(By.xpath(".//div[contains(@class, 'StudentAssignmentCard')]//div[contains(@class, 'AvatarsWithDescriptionExtendWrapper')]"));
            int currentCount = currentAssignments.size();

            System.out.println("Current assignment count In Assignment Module All: " + currentCount);
            TestRunner.getTest().log(Status.INFO, "Current assignment count In Assignment Module All: " + currentCount);

            if (currentCount == previousCount) {
                stagnantCount++;
            } else {
                stagnantCount = 0;
                previousCount = currentCount;
                allAssignments = currentAssignments;
            }

            if (stagnantCount >= sameCountThreshold) {
                try {
                    WebElement endOfListMessage = assignmentPanel.findElement(By.xpath(".//p[contains(text(), 'End of List')]"));
                    if (endOfListMessage.isDisplayed()) {
                        System.out.println("Reached the end of the assignment list.");
                        TestRunner.getTest().log(Status.INFO, "Reached the end of the assignment list.");
                        endOfListReached = true;
                    }
                } catch (NoSuchElementException e) {
                    System.out.println("End of list not reached yet; continuing to scroll.");
                }
            }
        }

        return allAssignments;
    }

    public void ValidateAndClickMonthButton() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm Validate and Click on Month Button ");
        System.out.println("I'm Validate and Click on Month Button ");

        Thread.sleep(1000);

        WebElement MonthButton = driver.findElement(By.xpath("//button[span[text()='Month']]"));

        if (MonthButton.isDisplayed()){
            MonthButton.click();
            System.out.println("Month Button Click Successfully");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Month Button Click Successfully");
        }
        else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Month Button not Display");
        }
    }

    public void AllAssignmentAreInCurrentMonthDate() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm Validate All Assignments Under Month Filter Have This Month Start and Due Date");
        System.out.println("I'm Validate All Assignments Under Month Filter Have This Month Start and Due Date ");

        List<WebElement> allAssignments = getAllAssignmentsByScrolling();

        int assignmentCountAfterScrollingForToday = allAssignments.size();
        System.out.println("Total assignments collected after scrolling From Month: " + assignmentCountAfterScrollingForToday);
        TestRunner.getTest().log(Status.INFO, "Total assignments collected after scrolling From Month: " + assignmentCountAfterScrollingForToday);
        SimpleDateFormat monthFormat = new SimpleDateFormat("yyyy-MM");
        String currentMonth = monthFormat.format(new Date());

        TestRunner.getTest().log(Status.INFO, "Now Validate that Assignments In Month Have This Month Start and Due Date");

        List<WebElement> totalAssignments = driver.findElements(By.xpath(".//div[contains(@class, 'StudentAssignmentCard')]//div[contains(@class, 'cardActions StudentAssignmentCardActions')]"));
        System.out.println("Total Assignments: " + totalAssignments.size());
        TestRunner.getTest().log(Status.INFO, "Total Assignments: " + totalAssignments.size());

        for (WebElement assignment : totalAssignments) {
            WebElement assignmentNameElement = assignment.findElement(By.xpath(".//h6")); // Get the assignment name
            String assignmentName = assignmentNameElement.getText();
            System.out.println("Assignment Name: " + assignmentName);

            try {
                WebElement startDateElement = assignment.findElement(By.xpath(".//span[contains(text(),'Start:')]"));
                String startDateText = startDateElement.getText();
                String startDate = startDateText.split(" ")[1]; // Extract the date part, e.g., "2024-11-21"

                WebElement dueDateElement = assignment.findElement(By.xpath(".//span[contains(text(),'Due:')]"));
                String dueDateText = dueDateElement.getText();
                String dueDate = dueDateText.split(" ")[1]; // Extract the date part, e.g., "2024-11-21"

                // Check if start date is in this month
                String startMonth = startDate.split("-")[0] + "-" + startDate.split("-")[1];
                String dueMonth = dueDate.split("-")[0] + "-" + dueDate.split("-")[1];

                // Validate if both start and due dates are in the current month
                if (currentMonth.equals(startMonth) && currentMonth.equals(dueMonth)) {
                    System.out.println("Assignment '" + assignmentName + "' has both start and due dates in the current month: " + startDate + " / " + dueDate);
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed: Assignment '" + assignmentName + "' has both start and due dates in the current month: " + startDate + " / " + dueDate);
                } else {
                    System.out.println("Assignment '" + assignmentName + "' has dates outside the current month. Start: " + startDate + " / Due: " + dueDate);
                    TestRunner.getTest().log(Status.FAIL, "Assignment '" + assignmentName + "' has dates outside the current month. Start: " + startDate + " / Due: " + dueDate);
                }

            } catch (Exception e) {
                System.out.println("Error finding start or due date for assignment: " + assignmentName);
                TestRunner.getTest().log(Status.FAIL, "Error finding start or due date for assignment: " + assignmentName);
            }
        }
    }

    public void ValidateAndClickWeekButton() throws InterruptedException{

        TestRunner.getTest().log(Status.INFO, "I'm Validate and Click on Week Button ");
        System.out.println("I'm Validate and Click on Week Button  ");

        Thread.sleep(1000);

        WebElement weekButton = driver.findElement(By.xpath("//button[span[text()='Week']]"));

        if (weekButton.isDisplayed()){
            weekButton.click();
            System.out.println("Week Button Click Successfully");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Week Button Click Successfully");
        }
        else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Week Button not Display");
        }
    }

    public void AllAssignmentAreInCurrentWeekDate() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm Validate All Assignments Under Week Filter Have This Week Due Date");
        System.out.println("I'm Validate All Assignments Under Week Filter Have This Week Due Date ");

        List<WebElement> allAssignments = getAllAssignmentsByScrolling();

        int assignmentCountAfterScrollingForToday = allAssignments.size();
        System.out.println("Total assignments collected after scrolling From Week: " + assignmentCountAfterScrollingForToday);
        TestRunner.getTest().log(Status.INFO, "Total assignments collected after scrolling From Week: " + assignmentCountAfterScrollingForToday);

        Calendar calendar = Calendar.getInstance();
        calendar.setFirstDayOfWeek(Calendar.MONDAY);
        calendar.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);

        Date startOfWeek = calendar.getTime();
        calendar.add(Calendar.DATE, 6);
        Date endOfWeek = calendar.getTime();

        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String startOfWeekFormatted = dateFormat.format(startOfWeek);
        String endOfWeekFormatted = dateFormat.format(endOfWeek);


        TestRunner.getTest().log(Status.INFO, "Now Validate that Assignments In Week Filter Have This Week Due Date");


        List<WebElement> totalAssignments = driver.findElements(By.xpath(".//div[contains(@class, 'StudentAssignmentCard')]//div[contains(@class, 'cardActions StudentAssignmentCardActions')]"));
        System.out.println("Total Assignments: " + totalAssignments.size());
        TestRunner.getTest().log(Status.INFO, "Total Assignments: " + totalAssignments.size());


        for (WebElement assignment : totalAssignments) {
            WebElement assignmentNameElement = assignment.findElement(By.xpath(".//h6")); // Get the assignment name
            String assignmentName = assignmentNameElement.getText();
            System.out.println("Assignment Name: " + assignmentName);

            try {

                WebElement dueDateElement = assignment.findElement(By.xpath(".//span[contains(text(),'Due:')]"));
                String dueDateText = dueDateElement.getText();
                String dueDate = dueDateText.split(" ")[1];

                // Convert MM/dd/yyyy format to yyyy-MM-dd format
                String dueDateFormatted = convertDateFormat(dueDate, "MM/dd/yyyy", "yyyy-MM-dd");

                boolean isDueInWeek = isDateInRange(dueDateFormatted, startOfWeekFormatted, endOfWeekFormatted);


                if (isDueInWeek) {
                    System.out.println("Assignment '" + assignmentName + "' has a due date in the current week: Due: " + dueDate);
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed: Assignment '" + assignmentName + "' has a due date in the current week: Due: " + dueDate);
                } else {
                    System.out.println("Assignment '" + assignmentName + "' has due date outside the current week. Due: " + dueDate);
                    TestRunner.getTest().log(Status.FAIL, "Assignment '" + assignmentName + "' has due date outside the current week. Due: " + dueDate);
                }

            } catch (Exception e) {

                System.out.println("Error finding due date for assignment: " + assignmentName);
                TestRunner.getTest().log(Status.FAIL, "Error finding due date for assignment: " + assignmentName);
            }
        }
    }

    public boolean isDateInRange(String date, String startDate, String endDate) {
        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            Date dateToCheck = dateFormat.parse(date);
            Date start = dateFormat.parse(startDate);
            Date end = dateFormat.parse(endDate);

            // Check if the date is between start and end
            return !dateToCheck.before(start) && !dateToCheck.after(end);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    private String convertDateFormat(String dateString, String inputFormat, String outputFormat) {
        try {
            SimpleDateFormat inputFormatter = new SimpleDateFormat(inputFormat);
            SimpleDateFormat outputFormatter = new SimpleDateFormat(outputFormat);
            Date date = inputFormatter.parse(dateString);
            return outputFormatter.format(date);
        } catch (Exception e) {
            System.out.println("Error converting date format: " + e.getMessage());
            e.printStackTrace();
            return dateString; // Return original string if conversion fails
        }
    }


    public void ClickOnSortByDueDateDescendingOrder() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm Validate and Click on Sort By Due Date Descending Order");
        System.out.println("I'm Validate and Click on Sort By Due Date Descending Order");

        WebElement SortByDueDate= driver.findElement(By.xpath("//img[@aria-label='Ascending Order']"));
        if (SortByDueDate.isDisplayed()){
            SortByDueDate.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Sort By Due Date Click Successfully");
            System.out.println("Sort By Due Date Click Successfully");
        }
        else {
            TestRunner.getTest().log(Status.FAIL, "Sort By Due Date Click Successfully");
            System.out.println("Sort By Due Date Click Successfully");
        }
    }

    public void ValidateAllAssignmentsAreInDescendingOrder() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm Validate All Assignments Due Date is in Descending Order");
        System.out.println("I'm Validate All Assignments Due Date is in Descending Order");

        List<WebElement> allAssignments = getAllAssignmentsByScrolling();

        int assignmentCountAfterScrollingForToday = allAssignments.size();
        System.out.println("Total assignments collected after scrolling: " + assignmentCountAfterScrollingForToday);
        TestRunner.getTest().log(Status.INFO, "Total assignments collected after scrolling: " + assignmentCountAfterScrollingForToday);

        TestRunner.getTest().log(Status.INFO, "Now Validate that Assignments Due Dates Are in Descending Order");

        // Find all assignments
        List<WebElement> totalAssignments = driver.findElements(By.xpath(".//div[contains(@class, 'StudentAssignmentCard')]//div[contains(@class, 'cardActions StudentAssignmentCardActions')]"));
        System.out.println("Total Assignments: " + totalAssignments.size());
        TestRunner.getTest().log(Status.INFO, "Total Assignments: " + totalAssignments.size());

        // List to store due dates
        List<Date> dueDates = new ArrayList<>();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm a");

        // Extract due dates
        for (WebElement assignment : totalAssignments) {
            try {
                // Extract due date text
                WebElement dueDateElement = assignment.findElement(By.xpath(".//span[contains(text(),'Due:')]"));
                String dueDateText = dueDateElement.getText(); // e.g., "Due: 2024-11-21 02:27 PM"
                String dueDateString = dueDateText.replace("Due: ", "").trim();

                // Convert due date string to Date object
                Date dueDate = dateFormat.parse(dueDateString);
                dueDates.add(dueDate);

                // Log each due date
                TestRunner.getTest().log(Status.INFO, "Extracted Due Date: " + dateFormat.format(dueDate));
                System.out.println("Extracted Due Date: " + dateFormat.format(dueDate));

            } catch (Exception e) {
                TestRunner.getTest().log(Status.FAIL, "Error processing due date: " + e.getMessage());
                System.out.println("Error processing due date: " + e.getMessage());
            }
        }

        // Validate descending order
        boolean isDescending = true;
        for (int i = 0; i < dueDates.size() - 1; i++) {
            if (dueDates.get(i).before(dueDates.get(i + 1))) {
                isDescending = false;
                break;
            }
        }

        // Print and log result
        if (isDescending) {
            TestRunner.getTest().log(Status.PASS, "Due dates are in descending order.");
            System.out.println("Due dates are in descending order.");
        } else {
            TestRunner.getTest().log(Status.FAIL, "Due dates are NOT in descending order.");
            System.out.println("Due dates are NOT in descending order.");
        }

        // Optional: Print all extracted dates for reference
        TestRunner.getTest().log(Status.INFO, "All Extracted Due Dates:");
        System.out.println("All Extracted Due Dates:");
        for (Date date : dueDates) {
            String formattedDate = dateFormat.format(date);
            TestRunner.getTest().log(Status.INFO, formattedDate);
            System.out.println(formattedDate);
            TestRunner.getTest().log(Status.INFO, "Due Dates In Descending Order:" + formattedDate);

        }
    }

    @FindBy(xpath = "//div[contains(text(),'Unit 1 Vocabulary Quiz')]/ancestor::div[4] | //img[contains(@src,'cardimage-vocabulary_quiz.png')]/ancestor::div[2]")
    public WebElement rowCourseVQ;

    public void AssignAssignmentForAssignmentModuleStudentSide() throws InterruptedException{
            TestRunner.getTest().log(Status.INFO, "Release Assignment Type Expert Track For Correct Answer");
            System.out.println("Release Assignment Type ET for Correct Answer");
            selectUnitForReleaseAssignment();

            Thread.sleep(2000);
            WebElement listContentPlayer = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@id='ContentPlayerMainPanel']")));

            if (listContentPlayer.isDisplayed() && listContentPlayer.isEnabled()) {
                WebElement btnAssignForSpecificAssignment = rowCourseVQ.findElement(By.xpath(".//button[normalize-space(text())='Assign']"));
                btnAssignForSpecificAssignment.click();

                WebElement dialogAssignment = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@role='dialog']")));
                if (dialogAssignment.isDisplayed()) {
                    correctAnswerExecutor_pf.EnterAssignmentTitleForCorrectAnswers();
                    correctAnswerExecutor_pf.selectSpecificClasses();
//                    assignAssessment_pf.setDateTimeAndCategory();
                    StartDateEdit();
                    DueDateEdit();
                    assignAssessment_pf.enterAdditionalSettings();
                    releaseAssignment_pf.AdvancedGradingOptions();
                    assignAssessment_pf.assignAssignment();
                    assignAssessment_pf.verifyDialogBox();
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed : Specific Assignment Type ET Released Successfully");
                }
            }

    }

    public static String StartDateAssignmentModule;

    public static String DueDateAssignmentModule;

    public void StartDateEdit() throws InterruptedException {
        System.out.println("I'm into Add Start date");
        TestRunner.getTest().log(Status.INFO, "I'm into Add Start Date");

        WebElement girdDate = driver.findElement(By.xpath("//div[contains(@class, 'AssignmentReleaseSection')]"));
        girdDate.isDisplayed();

        StartDateAssignmentModule = generateStartDateTime();
        System.out.println("Generated Start DateTime: " + StartDateAssignmentModule);
        TestRunner.getTest().log(Status.INFO, "Set assignment start datetime: " + StartDateAssignmentModule);

        simulateUserInput(girdDate, "//label[contains(text(),'Start Date & Time')]/following-sibling::div//input", StartDateAssignmentModule);

        Thread.sleep(3000);

    }


    public void DueDateEdit() throws InterruptedException {
        System.out.println("I'm into Add Due date");
        TestRunner.getTest().log(Status.INFO, "I'm into Add Due Date");

        WebElement girdDate = driver.findElement(By.xpath("//div[contains(@class, 'AssignmentReleaseSection')]"));
        girdDate.isDisplayed();

        DueDateAssignmentModule = generateEndDateTime(StartDateAssignmentModule);
        System.out.println("Generated End DateTime: " + DueDateAssignmentModule);
        TestRunner.getTest().log(Status.INFO, "Set assignment end datetime: " + DueDateAssignmentModule);

        simulateUserInput(girdDate, "//label[contains(text(),'End Date & Time')]/following-sibling::div//input", DueDateAssignmentModule);
        Thread.sleep(2000);

    }


    public void simulateUserInput(WebElement parentElement, String xpath, String value) {
        WebElement element = parentElement.findElement(By.xpath(xpath));

        // Clear any existing text and type the new value
        element.sendKeys(value);  // Directly send the new value
    }

    public String generateStartDateTime() {
        Calendar calendar = Calendar.getInstance(); // Get the current date and time

        // Format the date and time
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy, hh:mm a");
        return dateFormat.format(calendar.getTime());
    }

//    public String generateStartDateTime() {
//        Calendar calendar = Calendar.getInstance();
//
//        // Add 1 day to the current date
//        calendar.add(Calendar.DAY_OF_MONTH, 1);
//
//        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy, hh:mm a");
//        return dateFormat.format(calendar.getTime());
//    }

    public String generateEndDateTime(String startDateTime) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy, hh:mm a");

        try {
            Date startDate = dateFormat.parse(startDateTime);

            Calendar calendar = Calendar.getInstance();
            calendar.setTime(startDate);
            calendar.add(Calendar.MONTH, 1);

            return dateFormat.format(calendar.getTime());
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }
    public void selectUnitForReleaseAssignment() throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        // Find all units (even hidden)
        List<WebElement> totalUnits = driver.findElements(
                By.xpath("(//div[contains(@class, 'navigation')])[2]//a//span[contains(text(),'Unit 1')]")
        );

        String totalUnitName = null;

        for (WebElement unit : totalUnits) {
            // Get textContent instead of getText()
            totalUnitName = unit.getAttribute("textContent").trim();
            System.out.println("Unit Name: " + totalUnitName);

            if (totalUnitName.contains("Unit 1")) {
                // Expand parent panels if needed
                ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", unit);
                ((JavascriptExecutor) driver).executeScript("arguments[0].click();", unit); // JS click works even if hidden

                break;
            }
        }

        TestRunner.getTest().log(Status.PASS, "Test Case passed: " + totalUnitName + " selected successfully");

    }

    public void SelectStartDateOnAssignmentModule(String StartDate) throws InterruptedException {
        Thread.sleep(1000);
        System.out.println("Start Date From Assignment Release: " + StartDate);
        TestRunner.getTest().log(Status.INFO, "Start Date From Assignment Release: " + StartDate);

        // Locate the Start Date input field
        WebElement edt_StartDate = driver.findElement(By.xpath("//label[contains(text(),'Start')]/following-sibling::div//input"));

        try {
            System.out.println("Now Remove Time from Start Date and change format");

            // Define the input date format that matches the provided date
            DateTimeFormatter inputFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy, hh:mm a");
            LocalDateTime dateTime = LocalDateTime.parse(StartDate, inputFormatter);

            // Define the desired output format
            DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");

            // Format the date
            String formattedDate = dateTime.format(outputFormatter);

            // Log and send the formatted date to the input field
            System.out.println("Formatted Date: " + formattedDate);
            TestRunner.getTest().log(Status.INFO, "Formatted Start Date: " + formattedDate);
            edt_StartDate.sendKeys(formattedDate);

            System.out.println("Start date entered: " + formattedDate);
            TestRunner.getTest().log(Status.PASS, "Start date entered successfully: " + formattedDate);

        } catch (DateTimeParseException e) {
            System.out.println("Error parsing Start Date: " + e.getMessage());
            TestRunner.getTest().log(Status.FAIL, "Error parsing Start Date: " + e.getMessage());
        }
    }


    public void SelectEndDateOnAssignmentModule(String EndDate) throws InterruptedException {
        Thread.sleep(1000);

        System.out.println("End Date From Assignment Release: " + EndDate);
        TestRunner.getTest().log(Status.INFO, "End Date From Assignment Release: " + EndDate);

        WebElement edt_EndDate = driver.findElement(By.xpath("//label[contains(text(),'End')]/following-sibling::div//input"));

        try {
            System.out.println("Now Remove Time from End Date and change format");

            // Define the input date format that matches the provided date
            DateTimeFormatter inputFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy, hh:mm a");
            LocalDateTime dateTime = LocalDateTime.parse(EndDate, inputFormatter);

            // Define the desired output format
            DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");

            // Format the date
            String formattedDate = dateTime.format(outputFormatter);

            // Log and send the formatted date to the input field
            System.out.println("Formatted Date: " + formattedDate);
            TestRunner.getTest().log(Status.INFO, "Formatted End Date: " + formattedDate);
            edt_EndDate.sendKeys(formattedDate);

            System.out.println("End date entered: " + formattedDate);
            TestRunner.getTest().log(Status.PASS, "End date entered successfully: " + formattedDate);

        } catch (DateTimeParseException e) {
            System.out.println("Error parsing End Date: " + e.getMessage());
            TestRunner.getTest().log(Status.FAIL, "Error parsing End Date: " + e.getMessage());
        }
    }



    public void ValidateAssignmentAfterCustomDateRangeFilter() throws InterruptedException{
        String assignmentNameForCorrect = CorrectAnswerExecutor_PF.assignmentNameForCorrect.get();
        System.out.println("Want to search Assignment In Assignment Module: " + assignmentNameForCorrect);
        TestRunner.getTest().log(Status.INFO, "Want to search Assignment In Assignment Module: " + assignmentNameForCorrect);

        TestRunner.getTest().log(Status.INFO, "I'm Validate That Assignment "+  assignmentNameForCorrect + " is  Present In List after Date Range Filter Apply" ) ;
        System.out.println("I'm Validate That Assignment "+  assignmentNameForCorrect + " is  Present In List after Date Range Filter Apply");

        List<WebElement> allAssignments = getAllAssignmentsByScrolling();

        int assignmentCountAfterScrollingForToday = allAssignments.size();
        System.out.println("Total assignments collected after scrolling: " + assignmentCountAfterScrollingForToday);
        TestRunner.getTest().log(Status.INFO, "Total assignments collected after scrolling: " + assignmentCountAfterScrollingForToday);

        TestRunner.getTest().log(Status.INFO, "Now Validate that Specific Assignments is present ");

        List<WebElement> totalAssignments = driver.findElements(By.xpath(".//div[contains(@class, 'StudentAssignmentCard')]//div[contains(@class, 'cardActions StudentAssignmentCardActions')]"));
        System.out.println("Total Assignments: " + totalAssignments.size());
        TestRunner.getTest().log(Status.INFO, "Total Assignments: " + totalAssignments.size());

        boolean assignmentFound = false;


        for (WebElement assignment : totalAssignments) {
            WebElement assignmentNameElement = assignment.findElement(By.xpath(".//h6"));
            String assignmentName = assignmentNameElement.getText();
            System.out.println("Assignment Name: " + assignmentName);

            if (assignmentName.equals(assignmentNameForCorrect)) {
                System.out.println("Found assignment: " + assignmentName);
                TestRunner.getTest().log(Status.INFO, "Specific Assignment Found: " + assignmentNameForCorrect);

                assignmentFound = true;
                try {
                    WebElement startOrResumeButton = assignment.findElement(By.xpath("//button/span[@type='START' or @type='RESUME']"));
                    String statusType = startOrResumeButton.getAttribute("type");

                    TestRunner.getTest().log(Status.PASS, "Successfully Find assignment: " + assignmentName + " Under Select Specific Date Range Filter with Status: " + statusType) ;
                    Thread.sleep(2000);
                } catch (NoSuchElementException e) {
                    System.out.println("START/RESUME button not found for assignment: " + assignmentName);
                    return;
                }

            }
        }

        if (!assignmentFound) {
            System.out.println("Assignment not found : " + assignmentNameForCorrect);
            TestRunner.getTest().log(Status.FAIL, "Assignment not found in the list By Using Custom Date Range Filter: " + assignmentNameForCorrect);
        }
    }


    public void validateOpenCheckBoxIsChecked() throws InterruptedException {
        System.out.println("I'm Into Validate Open CheckBox is Checked By Default");
        TestRunner.getTest().log(Status.INFO,"I'm Into Validate Open CheckBox is Checked By Default");

        Thread.sleep(1000); // Optional delay if the checkbox takes time to load

        WebElement openCheckbox = driver.findElement(By.xpath("//input[contains(@class, 'PrivateSwitchBase-input') and @name='3' and @type='checkbox']"));

        if (openCheckbox.isSelected()) {
            System.out.println("Test Passed: 'Open' checkbox is checked by default.");
            TestRunner.getTest().log(Status.PASS, "'Open' checkbox is checked by default");
        } else {
            System.out.println("Test Failed: 'Open' checkbox is NOT checked by default.");
            TestRunner.getTest().log(Status.FAIL, "'Open' checkbox is NOT checked by default");
        }
    }

}
