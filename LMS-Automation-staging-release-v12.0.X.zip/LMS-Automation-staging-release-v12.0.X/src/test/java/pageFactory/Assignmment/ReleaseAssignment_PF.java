package pageFactory.Assignmment;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.IndividualAssignmentReport.IndividualAssignmentReport_PF;
import pageFactory.MyContent.AssignAssessment_PF;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static pageFactory.Assignmment.ScenarioAdvanceGradings_PF.assignInitialWeight;

public class ReleaseAssignment_PF {

    public WebDriverWait wait;
    WebDriver driver;

    Helper helper;

    CorrectAnswerExecutor_PF correctAnswerExecutor_pf;
    InCorrectAnswerExecutor_PF inCorrectAnswerExecutor_pf;
    AssignAssessment_PF assignAssessment_pf;
    IndividualAssignmentReport_PF individualAssignmentReport_pf;
//    int temp;

    public static ThreadLocal<Integer> temp = ThreadLocal.withInitial(() -> 0);

    public static ThreadLocal<List<Integer>> previousWeights = ThreadLocal.withInitial(ArrayList::new);
    public static ThreadLocal<List<Integer>> updatedWeights = ThreadLocal.withInitial(ArrayList::new);
    public static ThreadLocal<List<String>> referenceArray = ThreadLocal.withInitial(ArrayList::new);

    public static String assignmentTypeFromAssignment;
    public static ThreadLocal<String> assignmentTypeName = ThreadLocal.withInitial(() -> "");

    public ReleaseAssignment_PF(WebDriver driver) {
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(30));
        correctAnswerExecutor_pf = new CorrectAnswerExecutor_PF(driver);
        inCorrectAnswerExecutor_pf = new InCorrectAnswerExecutor_PF(driver);
        assignAssessment_pf = new AssignAssessment_PF(driver);
        individualAssignmentReport_pf = new IndividualAssignmentReport_PF(driver);
        helper = new Helper();
    }

    @FindBy(xpath = "(//div[@id='panel2bh-header'])[2]")
    WebElement panel_ScoringOptions;

    @FindBy(xpath = "(//div[@id='panel2bh-content'])[2]")
    WebElement panel_ScoringOptionsContent;

    @FindBy(xpath = "//div[contains(text(),'Unit 1 Vocabulary Quiz')]/ancestor::div[4] | //img[contains(@src,'cardimage-vocabulary_quiz.png')]/ancestor::div[2]")
    public WebElement rowCourseVQ;

    @FindBy(xpath = "//div[contains(text(),'Checkpoint 01')]/ancestor::div[5] |//img[contains(@src,'cardimage-expertrack.png')]/ancestor::div[3]")
    public WebElement rowCourseET;

    @FindBy(xpath = "//div[contains(@class, 'MetaDataWrapper')]")
    WebElement container_FinalizeQuestion;

    //    Select Unit To Release Assignments: State Florida
    public void selectUnitForReleaseAssignment() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        // Find all units (even hidden)
        List<WebElement> totalUnits = driver.findElements(
                By.xpath("(//div[contains(@class, 'navigation')])[2]//a//span[contains(text(),'Unit 1')]")
        );

        String totalUnitName = null;

        for (WebElement unit : totalUnits) {
            // Get textContent instead of getText()
            totalUnitName = unit.getAttribute("textContent").trim();
            System.out.println("Unit Name: " + totalUnitName);

            if (totalUnitName.contains("Unit 1")) {
                // Expand parent panels if needed
                ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", unit);
                ((JavascriptExecutor) driver).executeScript("arguments[0].click();", unit); // JS click works even if hidden

                break;
            }
        }

        TestRunner.getTest().log(Status.PASS, "Test Case passed: " + totalUnitName + " selected successfully");

    }


//    Release Expert Track Assignment

    public void ReleaseAssignmentTypeETForCorrectAnswer() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Release Assignment Type Expert Track For Correct Answer");
        System.out.println("Release Assignment Type ET for Correct Answer");
        selectUnitForReleaseAssignment();

        Thread.sleep(2000);
        WebElement listContentPlayer = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@id='ContentPlayerMainPanel']")));

        getAssignmentStandards();
        Thread.sleep(1000);

        if (listContentPlayer.isDisplayed() && listContentPlayer.isEnabled()) {
            WebElement btnAssignForSpecificAssignment = rowCourseVQ.findElement(By.xpath(".//button[normalize-space(text())='Assign']"));
            btnAssignForSpecificAssignment.click();

            WebElement dialogAssignment = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@role='dialog']")));
            if (dialogAssignment.isDisplayed()) {
                validateAssignmentDialogData();
                getAssignmentTypeFromAssignment();
                correctAnswerExecutor_pf.EnterAssignmentTitleForCorrectAnswers();
                correctAnswerExecutor_pf.selectSpecificClasses();
                assignAssessment_pf.setDateTimeAndCategory();
                assignAssessment_pf.enterAdditionalSettings();
//                assignAssessment_pf.enterWeightPercentage();
                AdvancedGradingOptions();
                assignAssessment_pf.assignAssignment();
                assignAssessment_pf.verifyDialogBox();
                TestRunner.getTest().log(Status.PASS, "Test Case Passed : Specific Assignment Type ET Released Successfully");
            }
        }
    }

    public void ReleaseAssignmentForIndividualAssignmentReport() throws InterruptedException {

        TestRunner.getTest().log(Status.INFO, "Release Assignment Type Expert Track For Testing Individual Assignment Report");
        System.out.println("Release Assignment Type Expert Track For Testing Individual Assignment Report");
        selectUnitForReleaseAssignment();

        Thread.sleep(2000);
        WebElement listContentPlayer = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@id='ContentPlayerMainPanel']")));

        individualAssignmentReport_pf.getAssignmentStandardsFromContent();
        Thread.sleep(1000);

        if (listContentPlayer.isDisplayed() && listContentPlayer.isEnabled()) {
            WebElement btnAssignForSpecificAssignment = rowCourseET.findElement(By.xpath(".//button[normalize-space(text())='Assign']"));
            btnAssignForSpecificAssignment.click();

            WebElement dialogAssignment = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@role='dialog']")));
            if (dialogAssignment.isDisplayed()) {
                validateAssignmentDialogData();
                getAssignmentTypeFromAssignment();
                correctAnswerExecutor_pf.EnterAssignmentTitleForCorrectAnswers();
                correctAnswerExecutor_pf.selectSpecificClasses();
                assignAssessment_pf.setDateTimeAndCategory();
                assignAssessment_pf.enterAdditionalSettings();
//                assignAssessment_pf.enterWeightPercentage();
                AdvancedGradingOptions();
                assignAssessment_pf.assignAssignment();
                assignAssessment_pf.verifyDialogBox();
                TestRunner.getTest().log(Status.PASS, "Test Case Passed : Specific Assignment Type ET Released Successfully");
            }
        }
    }

    public void getAssignmentStandards() {
        TestRunner.getTest().log(Status.INFO, "Get Assignment Standards");
        System.out.println("Get Assignment Standards");

        try {
            WebElement btnStandardsSpecificAssignment = rowCourseVQ.findElement(By.xpath(".//span[@aria-label='attach standard']"));
            btnStandardsSpecificAssignment.click();

            WebElement dialogAssignment = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@role='dialog']")));

            if (dialogAssignment.isDisplayed()) {

                List<WebElement> references = dialogAssignment.findElements(By.xpath("//table//tr//td[1]"));

                if (references.isEmpty()) {
                    System.out.println("No references found. Empty row data.");
                    TestRunner.getTest().log(Status.FAIL, "No references found. Empty row data.");
                    Thread.sleep(3000);
                    helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());

                    WebElement closeButton = dialogAssignment.findElement(By.xpath(".//button[@aria-label='close']"));
                    closeButton.click();
                    TestRunner.getTest().log(Status.PASS, "Dialog box closed successfully after failed attempt.");
                    return;
                }

                for (WebElement reference : references) {
                    referenceArray.get().add(reference.getText().trim());
                }

                for (String reference : referenceArray.get()) {
                    System.out.println("Reference: " + reference);
                    TestRunner.getTest().log(Status.INFO, "Reference: " + reference);
                }
                Thread.sleep(3000);
                helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());

                WebElement closeButton = dialogAssignment.findElement(By.xpath(".//button[@aria-label='close']"));
                closeButton.click();
                System.out.println("Dialog box closed successfully.");
                TestRunner.getTest().log(Status.PASS, "Dialog box closed successfully.");

            } else {
                TestRunner.getTest().log(Status.FAIL, "Dialog box not displayed.");
            }

        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "An error occurred while getting assignment standards.");
            e.printStackTrace();
        }
    }

    public void ReleaseGroupAssignmentTypeETForCorrectAnswer() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Release Group Assignment Type Expert Track For Correct Answer");
        System.out.println("Release Group Assignment Type ET for Correct Answer");
        selectUnitForReleaseAssignment();

        Thread.sleep(2000);
        WebElement listContentPlayer = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@id='ContentPlayerMainPanel']")));

        if (listContentPlayer.isDisplayed() && listContentPlayer.isEnabled()) {
            WebElement btnAssignForSpecificAssignment = listContentPlayer.findElement(By.xpath("(//div[contains(@class, 'MuiBox-root')]//button[contains(text(), 'Assign')])[5]"));
            btnAssignForSpecificAssignment.click();

            WebElement dialogAssignment = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@role='dialog']")));
            if (dialogAssignment.isDisplayed()) {
                getAssignmentTypeFromAssignment();
                correctAnswerExecutor_pf.EnterAssignmentTitleForCorrectAnswers();
                correctAnswerExecutor_pf.selectSpecificGroup();
                assignAssessment_pf.setDateTimeAndCategory();
                assignAssessment_pf.enterAdditionalSettings();
//                assignAssessment_pf.enterWeightPercentage();
                AdvancedGradingOptions();
                assignAssessment_pf.assignAssignment();
                assignAssessment_pf.verifyDialogBox();
                TestRunner.getTest().log(Status.PASS, "Test Case Passed : Specific Assignment Type ET Released Successfully");
            }
        }
    }

    public void ReleaseAssignmentTypeETForInCorrectAnswer() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Release Assignment Type Expert Track For InCorrect Answer");
        System.out.println("Release Assignment Type ET for InCorrect Answer");
        selectUnitForReleaseAssignment();

        Thread.sleep(2000);
        WebElement listContentPlayer = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@id='ContentPlayerMainPanel']")));

        if (listContentPlayer.isDisplayed() && listContentPlayer.isEnabled()) {
            WebElement btnAssignForSpecificAssignment = listContentPlayer.findElement(By.xpath("(//div[contains(@class, 'MuiBox-root')]//button[contains(text(), 'Assign')])[5]"));
            btnAssignForSpecificAssignment.click();

            WebElement dialogAssignment = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@role='dialog']")));
            if (dialogAssignment.isDisplayed()) {
                inCorrectAnswerExecutor_pf.EnterAssignmentTitleForInCorrectAnswers();
                inCorrectAnswerExecutor_pf.selectSpecificClasses();
                assignAssessment_pf.setDateTimeAndCategory();
                assignAssessment_pf.enterAdditionalSettings();
//                assignAssessment_pf.enterWeightPercentage();
                AdvancedGradingOptions();
                assignAssessment_pf.assignAssignment();
                assignAssessment_pf.verifyDialogBox();
                TestRunner.getTest().log(Status.PASS, "Test Case Passed : Specific Assignment Type ET Released Successfully");
            }
        }
    }

//    Release Vocabulary Builder Assignment

    public void ReleaseAssignmentTypeVBForCorrectAnswer() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Release Assignment Type Vocabulary Builder For Correct Answer");
        System.out.println("Release Assignment Type VB for Correct Answer");
        selectUnitForReleaseAssignment();

        Thread.sleep(2000);
        WebElement listContentPlayer = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@id='ContentPlayerMainPanel']")));

        if (listContentPlayer.isDisplayed() && listContentPlayer.isEnabled()) {
            WebElement btnAssignForSpecificAssignment = listContentPlayer.findElement(By.xpath("(//div[contains(@class, 'MuiBox-root')]//button[contains(text(), 'Assign')])[4]"));
            btnAssignForSpecificAssignment.click();

            WebElement dialogAssignment = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@role='dialog']")));
            if (dialogAssignment.isDisplayed()) {
                getAssignmentTypeFromAssignment();
                correctAnswerExecutor_pf.EnterAssignmentTitleForCorrectAnswers();
                correctAnswerExecutor_pf.selectSpecificClasses();
                assignAssessment_pf.setDateTimeAndCategory();
                assignAssessment_pf.enterAdditionalSettings();
//                assignAssessment_pf.enterWeightPercentage();
                AdvancedGradingOptions();
                assignAssessment_pf.assignAssignment();
                assignAssessment_pf.verifyDialogBox();
                TestRunner.getTest().log(Status.PASS, "Test Case Passed : Specific Assignment Type VB Released Successfully");
            }
        }
    }

    public void ReleaseAssignmentTypeVBForInCorrectAnswer() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Release Assignment Type Vocabulary Builder For InCorrect Answer");
        System.out.println("Release Assignment Type VB for InCorrect Answer");
        selectUnitForReleaseAssignment();

        Thread.sleep(2000);
        WebElement listContentPlayer = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@id='ContentPlayerMainPanel']")));

        if (listContentPlayer.isDisplayed() && listContentPlayer.isEnabled()) {
            WebElement btnAssignForSpecificAssignment = listContentPlayer.findElement(By.xpath("(//div[contains(@class, 'MuiBox-root')]//button[contains(text(), 'Assign')])[3]"));
            btnAssignForSpecificAssignment.click();

            WebElement dialogAssignment = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@role='dialog']")));
            if (dialogAssignment.isDisplayed()) {
                inCorrectAnswerExecutor_pf.EnterAssignmentTitleForInCorrectAnswers();
                inCorrectAnswerExecutor_pf.selectSpecificClasses();
                assignAssessment_pf.setDateTimeAndCategory();
                assignAssessment_pf.enterAdditionalSettings();
//                assignAssessment_pf.enterWeightPercentage();
                AdvancedGradingOptions();
                assignAssessment_pf.assignAssignment();
                assignAssessment_pf.verifyDialogBox();
                TestRunner.getTest().log(Status.PASS, "Test Case Passed : Specific Assignment Type VB Released Successfully");
            }
        }
    }

//    Release Vocabulary Quiz Assignment

    public void ReleaseAssignmentTypeVQForCorrectAnswer() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Release Assignment Type VQ For Correct Answer");
        System.out.println("Release Assignment Type VQ for Correct Answer");
        selectUnitForReleaseAssignment();

        Thread.sleep(2000);
        WebElement listContentPlayer = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@id='ContentPlayerMainPanel']")));

        getAssignmentStandards();
        Thread.sleep(1000);

        if (listContentPlayer.isDisplayed() && listContentPlayer.isEnabled()) {
            WebElement btnAssignForSpecificAssignment = rowCourseVQ.findElement(By.xpath(".//button[normalize-space(text())='Assign']"));
            btnAssignForSpecificAssignment.click();

            WebElement dialogAssignment = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@role='dialog']")));
            if (dialogAssignment.isDisplayed()) {
                getAssignmentTypeFromAssignment();
                correctAnswerExecutor_pf.EnterAssignmentTitleForCorrectAnswers();
                correctAnswerExecutor_pf.selectSpecificClasses();
                assignAssessment_pf.setDateTimeAndCategory();
                assignAssessment_pf.enterAdditionalSettings();
//                assignAssessment_pf.enterWeightPercentage();
                AdvancedGradingOptions();
                assignAssessment_pf.assignAssignment();
                assignAssessment_pf.verifyDialogBox();
                TestRunner.getTest().log(Status.PASS, "Test Case Passed : Specific Assignment Type VQ Released Successfully");
            }
        }
    }

    public void validateAssignmentDialogData() throws InterruptedException {
        System.out.println(">>> Starting: Validate Assignment Dialog Box");

        try {
            WebElement assignmentImageElement = driver.findElement(By.xpath("//div[@role='dialog']//img[contains(@src, 'cardimage')]"));

            if (assignmentImageElement.isDisplayed()) {
                String imageSrc = assignmentImageElement.getAttribute("src");
                System.out.println(">>> Assignment Image src: " + imageSrc);
                TestRunner.getTest().log(Status.PASS, "Assignment Image src: " + imageSrc);
                Pattern pattern = Pattern.compile("(?<=cardimage-)([a-zA-Z0-9_-]+)(?=\\.png$)");
                Matcher matcher = pattern.matcher(imageSrc);

                if (matcher.find()) {
                    assignmentTypeName.set(matcher.group(1));
                    System.out.println(">>> Extracted Assignment Type Name: " + assignmentTypeName.get());
                    TestRunner.getTest().log(Status.PASS, "Extracted Assignment Type Name: " + assignmentTypeName.get());
                } else {
                    System.out.println(">>> Failed to extract image name.");
                    TestRunner.getTest().log(Status.FAIL, "Failed to extract image name.");
                }
            } else {
                System.out.println(">>> Assignment Image not found.");
                TestRunner.getTest().log(Status.FAIL, "Assignment Image not found.");
            }

        } catch (Exception e) {
            System.out.println(">>> Error occurred: " + e.getMessage());
            TestRunner.getTest().log(Status.FAIL, "Error occurred: " + e.getMessage());
        }
    }

    public void getAssignmentTypeFromAssignment() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into Get Assignment type From Assignment");
        System.out.println("I'm into Get Assignment type From Assignment");

        WebElement Assignment_type_From_Assignment = driver.findElement(By.xpath("//div[contains(@class, 'MuiBox-root')]//span[contains(@class, 'css-di0a22')]"));

        assignmentTypeFromAssignment = Assignment_type_From_Assignment.getText();
        System.out.println("Assignment Type from Release Assignment is: " + assignmentTypeFromAssignment);

        TestRunner.getTest().log(Status.INFO, "Assignment Type from Release Assignment is: " + assignmentTypeFromAssignment);
        TestRunner.getTest().log(Status.PASS, "Test Case Passed : Assignment Type from Release Assignment is: " + assignmentTypeFromAssignment);


    }

    public void ReleaseAssignmentTypeVQForInCorrectAnswer() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Release Assignment Type VQ For InCorrect Answer");
        System.out.println("Release Assignment Type VQ for InCorrect Answer");
        selectUnitForReleaseAssignment();

        Thread.sleep(2000);
        WebElement listContentPlayer = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@id='ContentPlayerMainPanel']")));

        if (listContentPlayer.isDisplayed() && listContentPlayer.isEnabled()) {
            WebElement btnAssignForSpecificAssignment = listContentPlayer.findElement(By.xpath("(//div[contains(@class, 'MuiBox-root')]//button[contains(text(), 'Assign')])[4]"));
            btnAssignForSpecificAssignment.click();

            WebElement dialogAssignment = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@role='dialog']")));
            if (dialogAssignment.isDisplayed()) {
                inCorrectAnswerExecutor_pf.EnterAssignmentTitleForInCorrectAnswers();
                inCorrectAnswerExecutor_pf.selectSpecificClasses();
                assignAssessment_pf.setDateTimeAndCategory();
                assignAssessment_pf.enterAdditionalSettings();
//                assignAssessment_pf.enterWeightPercentage();
                AdvancedGradingOptions();
                assignAssessment_pf.assignAssignment();
                assignAssessment_pf.verifyDialogBox();
                TestRunner.getTest().log(Status.PASS, "Test Case Passed : Specific Assignment Type VQ Released Successfully");
            }
        }
    }

//    Release Digital Student Book Assignment

    public void ReleaseAssignmentTypeDSBForCorrectAnswer() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Release Assignment Type DSB For Correct Answer");
        System.out.println("Release Assignment Type DSB for Correct Answer");
        selectUnitReleaseAssignmentDSB();

        Thread.sleep(2000);
        WebElement listContentPlayer2 = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@id='ContentPlayerMainPanel']")));
        helper.scrollToElement(driver, listContentPlayer2);
        Thread.sleep(1000);
        if (listContentPlayer2.isDisplayed() && listContentPlayer2.isEnabled()) {
            WebElement btnAssignForSpecificAssignment = listContentPlayer2.findElement(By.xpath("(//div[contains(@class, 'MuiBox-root')]//button[contains(text(), 'Assign')])[1]"));
//            helper.scrollToElement(driver,btnAssignForSpecificAssignment);
            btnAssignForSpecificAssignment.click();

            WebElement dialogAssignment = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@role='dialog']")));
            if (dialogAssignment.isDisplayed()) {
                getAssignmentTypeFromAssignment();
                correctAnswerExecutor_pf.EnterAssignmentTitleForCorrectAnswers();
                correctAnswerExecutor_pf.selectSpecificClasses();
                assignAssessment_pf.setDateTimeAndCategory();
                assignAssessment_pf.enterAdditionalSettings();
//                assignAssessment_pf.enterWeightPercentage();
                AdvancedGradingOptions();
                assignAssessment_pf.assignAssignment();
                assignAssessment_pf.verifyDialogBox();
                TestRunner.getTest().log(Status.PASS, "Test Case Passed : Specific Assignment Type DSB Released Successfully");
            }
        }
    }

    public void ReleaseAssignmentTypeDSBForInCorrectAnswer() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Release Assignment Type DSB For InCorrect Answer");
        System.out.println("Release Assignment Type DSB for InCorrect Answer");
        selectUnitReleaseAssignmentDSB();

        Thread.sleep(2000);
        WebElement listContentPlayer2 = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@id='ContentPlayerMainPanel']")));

        if (listContentPlayer2.isDisplayed() && listContentPlayer2.isEnabled()) {
            WebElement btnAssignForSpecificAssignment = listContentPlayer2.findElement(By.xpath("(//div[contains(@class, 'MuiBox-root')]//button[contains(text(), 'Assign')])[1]"));
            btnAssignForSpecificAssignment.click();

            WebElement dialogAssignment = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@role='dialog']")));
            if (dialogAssignment.isDisplayed()) {
                inCorrectAnswerExecutor_pf.EnterAssignmentTitleForInCorrectAnswers();
                inCorrectAnswerExecutor_pf.selectSpecificClasses();
                assignAssessment_pf.setDateTimeAndCategory();
                assignAssessment_pf.enterAdditionalSettings();
//                assignAssessment_pf.enterWeightPercentage();
                AdvancedGradingOptions();
                assignAssessment_pf.assignAssignment();
                assignAssessment_pf.verifyDialogBox();
                TestRunner.getTest().log(Status.PASS, "Test Case Passed : Specific Assignment Type DSB Released Successfully");
            }
        }
    }

    public void selectUnitReleaseAssignmentDSB() throws InterruptedException {
        Thread.sleep(2000);
        List<WebElement> totalUnits = driver.findElements(By.xpath("(//div[contains(@class, 'navigation')])[2]//a//span[contains(text(),'Unit 1')]"));

        String totalUnitName = null;
        for (WebElement unit : totalUnits) {
            totalUnitName = unit.getAttribute("textContent").trim();
            System.out.println("Unit Name: " + totalUnitName);

            if (totalUnitName.contains("Unit 1")) {
                ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", unit);
                ((JavascriptExecutor) driver).executeScript("arguments[0].click();", unit);

                System.out.println("Unit click successfully");
                WebElement listContentPlayer = driver.findElement(By.xpath("//div[@id='ContentPlayerMainPanel']"));
                if (listContentPlayer.isDisplayed() && listContentPlayer.isEnabled()) {
                    WebElement btnOpenForSpecificAssignment = listContentPlayer.findElement(By.xpath("(//div[contains(@class, 'MuiBox-root')]//button[contains(text(), 'Open')])[7]"));
                    btnOpenForSpecificAssignment.click();
                }
                break;
            }
        }
        System.out.println("Test Case passed : " + totalUnitName + " Select Successfully");
        TestRunner.getTest().log(Status.PASS, "Test Case passed : " + totalUnitName + " Select Successfully");
    }

    public void AdvancedGradingOptions() throws InterruptedException {
        previousWeights.get().clear();
        updatedWeights.get().clear();

        System.out.println("Previous Weights after clearing: " + previousWeights.get());
        System.out.println("Updated Weights after clearing: " + updatedWeights.get());

        select_ShowScoringOptions();
        Thread.sleep(1000);
        container_FinalizeQuestion.isDisplayed();
        WebElement wrapperTable = container_FinalizeQuestion.findElement(By.xpath("//div[contains(@class, 'MetaDataWrapper')]//table"));
        List<WebElement> rows = wrapperTable.findElements(By.tagName("tr"));

        for (int i = 1; i < rows.size(); i++) {
            WebElement row = rows.get(i);
            List<WebElement> cells = row.findElements(By.tagName("td"));

            WebElement weightInput = cells.get(1).findElement(By.tagName("input"));
            WebElement percentageInput = cells.get(2).findElement(By.tagName("input"));

            if (weightInput.isEnabled() && percentageInput.isEnabled()) {

                String previousWeightStr = weightInput.getAttribute("value");
                int previousWeight = previousWeightStr.isEmpty() ? 0 : Integer.parseInt(previousWeightStr);

                weightInput.clear();
                percentageInput.clear();

                clearInputWithJs(driver, weightInput);
                clearInputWithJs(driver, percentageInput);

                Random random = new Random();
                int randomWeight = random.nextInt(9) + 1;
                int randomPercentage = random.nextInt(100);

                weightInput.sendKeys(String.valueOf(randomWeight));
                percentageInput.sendKeys(String.valueOf(randomPercentage));
                System.out.println("Set weight " + randomWeight + " Set percentage " + randomPercentage);
                TestRunner.getTest().log(Status.PASS, "Set weight to " + randomWeight + " Set percentage to " + randomPercentage);

                previousWeights.get().add(previousWeight);
                updatedWeights.get().add(randomWeight);
            }
        }

        System.out.println("Previous Weights: " + previousWeights.get());
        System.out.println("Updated Weights: " + updatedWeights.get());
        System.out.println("updated weight array size: " + updatedWeights.get().size());

        TestRunner.getTest().log(Status.INFO, "Previous Weights: " + previousWeights.get());
        TestRunner.getTest().log(Status.INFO, "Updated Weights: " + updatedWeights.get());
        TestRunner.getTest().log(Status.INFO, "updated weight array size: " + updatedWeights.get().size());

        Thread.sleep(2000);
        WebElement totalWeight = driver.findElement(By.xpath("(//input[@name='questionWeight'])[2]"));
        String totalInitialWeight = totalWeight.getAttribute("value");
        System.out.println("Weight in assign time: " + totalInitialWeight);


        assignInitialWeight.set(Double.parseDouble(totalInitialWeight));
        System.out.println("Weight in assign time shows: " + assignInitialWeight.get());
        TestRunner.getTest().log(Status.INFO, "Total weight in assign time: " + assignInitialWeight.get());

    }

    public void select_ShowScoringOptions() {
        if (panel_ScoringOptions.isDisplayed() && panel_ScoringOptions.isEnabled()) {
            TestRunner.getTest().log(Status.INFO, "Click on Scoring Option");
            panel_ScoringOptions.click();
            wait.until(ExpectedConditions.visibilityOf(panel_ScoringOptionsContent));
            System.out.println("Click on Scoring Option");
            TestRunner.getTest().log(Status.PASS, "Selected Scoring Option");
        } else {
            TestRunner.getTest().log(Status.FAIL, "Scoring Option not found");
        }
    }

    private void clearInputWithJs(WebDriver driver, WebElement element) {
        JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
        jsExecutor.executeScript("arguments[0].value = '';", element);
    }

    public void VerifyGradingWithWeightAtAssign() throws InterruptedException {
        System.out.println("I'm in to verify Advanced Grading");

        WebElement questionPlayer = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("lesson-player-ifram")));
        driver.switchTo().frame(questionPlayer);

        WebElement points = driver.findElement(By.xpath("//div[@class='pointWrapper']//span[3]"));
        String weightOnAssignmentAttemptStr = points.getText();
        System.out.println("Weight on Assignment : " + weightOnAssignmentAttemptStr);
        int weightOnAssignmentAttempt = Integer.parseInt(weightOnAssignmentAttemptStr);
        List<Integer> weightsList = updatedWeights.get();

        System.out.println("Size of weight Array: " + weightsList.size());
        System.out.println("Array of weight: " + weightsList);
        System.out.println("Value of Temp: " + temp.get());


        if (temp.get() < weightsList.size()) {
            int correspondingWeight = weightsList.get(temp.get());
            System.out.println("Weight on Assignment Attempt: " + weightOnAssignmentAttempt);
            System.out.println("correspondingWeight: " + correspondingWeight);
            if (weightOnAssignmentAttempt == correspondingWeight) {
                System.out.println("Weight on assignment attempt matches the weight at index " + temp.get() + ": " + weightOnAssignmentAttempt);
                TestRunner.getTest().log(Status.PASS, "Verified weight matches at index " + temp.get());
            } else {
                System.out.println("Weight mismatch at index " + temp.get() + ": Assignment weight is " + weightOnAssignmentAttempt + " but expected " + correspondingWeight);
                TestRunner.getTest().log(Status.FAIL, "Weight mismatch at index " + temp.get());
            }
        } else {
            System.out.println("Invalid index: " + temp.get());
            TestRunner.getTest().log(Status.FAIL, "Invalid index " + temp.get());
        }

        temp.set(temp.get() + 1);
        driver.switchTo().defaultContent();
    }

    public void ReleaseAssignmentTypeVQFromDistrict() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Release Assignment Type VQ For Correct Answer");
        System.out.println("Release Assignment Type VQ for Correct Answer");
        selectUnitForReleaseAssignment();

        Thread.sleep(2000);
        WebElement listContentPlayer = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@id='ContentPlayerMainPanel']")));

        if (listContentPlayer.isDisplayed() && listContentPlayer.isEnabled()) {
            WebElement btnAssignForSpecificAssignment = listContentPlayer.findElement(By.xpath("(//div[contains(@class, 'MuiBox-root')]//button[contains(text(), 'Assign')])[5]"));
            btnAssignForSpecificAssignment.click();

            WebElement dialogAssignment = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@role='dialog']")));
            if (dialogAssignment.isDisplayed()) {
                getAssignmentTypeFromAssignment();
                correctAnswerExecutor_pf.EnterAssignmentTitleForCorrectAnswers();
//                correctAnswerExecutor_pf.selectSpecificClasses();
                selectSpecificClassesFromDistrict();
                assignAssessment_pf.setDateTimeAndCategory();
                assignAssessment_pf.enterAdditionalSettings();
//                assignAssessment_pf.enterWeightPercentage();
                AdvancedGradingOptions();
                assignAssessment_pf.assignAssignment();
                assignAssessment_pf.verifyDialogBox();
                TestRunner.getTest().log(Status.PASS, "Test Case Passed : Specific Assignment Type VQ Released Successfully");
            }
        }
    }


    @FindBy(xpath = "//label[contains(text(),'Assign to')]/parent::div")
    WebElement dropDown_AssignTo;

    String[] specificClasses = {"QA Testing"};

    public void selectSpecificClassesFromDistrict() throws InterruptedException {
        dropDown_AssignTo.click();

        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//ul[@role='listbox']//li")));

        WebElement assignToOptions = dropDown_AssignTo.findElement(By.xpath("//ul[@role='listbox']"));
        Thread.sleep(2000);

        List<WebElement> totalClasses = assignToOptions.findElements(By.tagName("li"));
        System.out.println("Total Classes: " + totalClasses.size());
        TestRunner.getTest().log(Status.INFO, "Total Classes: " + totalClasses.size());

        for (WebElement totalClass : totalClasses) {
            String totalClassName = totalClass.findElement(By.xpath(".//span[contains(@class, 'MuiListItemText-primary')]")).getText();
            WebElement checkBoxClass = totalClass.findElement(By.xpath(".//input"));
            System.out.println("Total Class: " + totalClassName);
            for (String className : specificClasses) {
                if (totalClassName.equals(className)) {
                    System.out.println("Selected Class: " + totalClassName);
                    TestRunner.getTest().log(Status.INFO, "Selected class name: " + totalClassName);
                    checkBoxClass.click();
                    break;
                }
            }
        }

        // Close the dropdown by simulating pressing the ESC key
        Actions actions = new Actions(driver);
        actions.sendKeys(Keys.ESCAPE).build().perform();
    }

}
