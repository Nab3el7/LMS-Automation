package pageFactory.Assignmment;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.sl.In;
import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Assignmment.AssessmentReview.ReviewGradedSubmissionWithCorrectAnswers_PF;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.awt.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.*;
import java.util.List;

public class TeacherAssignment_PF {

    Helper helper;
    public WebDriverWait wait;
    WebDriver driver;
    @FindBy(xpath = "//div[contains(@class, 'select-class')]")
    WebElement dropDown_SelectClass;

    @FindBy(xpath = "//div[contains(@class, 'CoursesWrapper')]")
    WebElement card_MyCourse;

    @FindBy(xpath = "//div[contains(@class, 'CourseContainer')]")
    WebElement list_MyCourses;

    @FindBy(xpath = "//div[@class='ScrollbarsCustom']//div[@class='ScrollbarsCustom-Content']")
    WebElement scroll_Units;

    @FindBy(xpath = "//div[@id='ContentPlayerMainPanel']")
    WebElement list_ContentPlayer;

    @FindBy(xpath = "//div[@role='dialog']")
    WebElement popup_AssignAssignment;

    @FindBy(xpath = "//button[@aria-label='close']")
    WebElement btn_CloseModal;

    @FindBy(xpath = "//input[@name='title']")
    WebElement edt_AssignmentTitle;

    @FindBy(xpath = "//label[contains(text(),'Assign to')]/parent::div")
    WebElement dropDown_AssignTo;

    @FindBy(xpath = "//input[@name='isOpenToAnyStudent']")
    WebElement input_OpenToAnyStudent;

    @FindBy(xpath = "//label[contains(text(),'Select Students')]/following-sibling::div")
    WebElement dropDown_SelectStudent;

    @FindBy(xpath = "//label[contains(text(),'Start Date & Time')]/following-sibling::div//input")
    WebElement calendar_StartDateTime;

    @FindBy(xpath = "//label[contains(text(),'End Date & Time')]/following-sibling::div//input")
    WebElement calendar_EndDateTime;

    @FindBy(xpath = "//input[@name='isLateSubmission']")
    WebElement checkBox_AllowLateSubmission;

    @FindBy(xpath = "//label[contains(text(),'Late Sub. Date & Time')]/following-sibling::div//input")
    WebElement calendar_LateSubDateTime;

    @FindBy(xpath = "//label[contains(text(),'Category')]/following-sibling::div")
    WebElement dropDown_Category;

    @FindBy(xpath = "//div[@id='panel2bh-header']")
    WebElement panel_AdditionalSettings;

    @FindBy(xpath = "//div[@id='panel2bh-content']")
    WebElement panel_AdditionalSettingsContent;

    @FindBy(xpath = "//input[@name='isRandomizeAnswers']")
    WebElement checkBox_RandomizeAnswer;

    @FindBy(xpath = "//input[@name='isDisplayGrades']")
    WebElement checkBox_DisplayGrades;

    @FindBy(xpath = "//div[@id='panel2bh-content']//div[@id='demo-simple-select']")
    WebElement dropDown_ReviewOptions;

    @FindBy(xpath = "//textarea[@id='outlined-multiline-flexible']")
    WebElement txtArea_AdditionalInstructions;

    @FindBy(xpath = "//button[@name='btn-assign-assignment']")
    WebElement btn_AssignAssignment;

    @FindBy(xpath = "(//h2[contains(@class, 'MuiDialogTitle-root')])[2]")
    WebElement alert_success;



    public TeacherAssignment_PF(WebDriver driver) {
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        helper = new Helper();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    public void selectClassAndCourse() throws InterruptedException {
        while (true) {
            SelectClass();

            if (coursesFound()) {
                SelectCourse();
                break;
            } else {
                System.out.println("No courses found. Trying again...");
            }
        }
    }

    public boolean coursesFound() {
        wait.until(ExpectedConditions.visibilityOf(list_MyCourses));
        WebElement courseContainer = list_MyCourses;
        List<WebElement> courseLinks = courseContainer.findElements(By.xpath(".//a"));
        return !courseLinks.isEmpty();
    }

    public void SelectClass() throws InterruptedException {
        dropDown_SelectClass.click();
        Thread.sleep(1000);
        List<WebElement> SchoolStatusOptions = dropDown_SelectClass.findElements(By.xpath("//ul[@role='listbox']"));
        helper.selectValueFromDropdown(SchoolStatusOptions);
    }

    public void SelectCourse() {
        TestRunner.getTest().log(Status.INFO, "I am in to select Course ");
        wait.until(ExpectedConditions.visibilityOf(list_MyCourses));

        WebElement courseContainer = list_MyCourses;
        List<WebElement> courseLinks = courseContainer.findElements(By.xpath(".//div[contains(@class, 'CourseRoot')]"));

        for (WebElement courseLink : courseLinks) {
            System.out.println("Course Name: " + courseLink.getText());
        }

        if (!courseLinks.isEmpty()) {
            WebElement firstCourse = courseLinks.get(0);
//            WebElement firstCourse = courseLinks.get(1);
            System.out.println("Selected Course: " + firstCourse.getText());
            firstCourse.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed : Course Select Successfully");
        } else {
            System.out.println("No courses found");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : No courses found");
            throw new RuntimeException("No Course Found.");
        }

    }

    public void SelectSpecificUnit() {
        scroll_Units.isDisplayed();

        List<WebElement> unitButtons = scroll_Units.findElements(By.xpath("//button[contains(@aria-label,'Unit ')]"));
        for (WebElement unitButton : unitButtons) {
            System.out.println("Unit Names: " + unitButton.getText());
        }

        if (!unitButtons.isEmpty()) {
            WebElement firstUnit = unitButtons.get(0);
            firstUnit.click();
            System.out.println("Selected Unit: " + firstUnit.getText());
        } else {
            System.out.println("No units found");
//            throw new RuntimeException("No Unit Found.");

        }
    }

    public void SelectSpecificAssignments() throws InterruptedException, IOException, NoSuchAlgorithmException, KeyManagementException {
        wait.until(ExpectedConditions.visibilityOf(list_ContentPlayer));
        list_ContentPlayer.isDisplayed();

        List<WebElement> assignmentDivsWithAssignButton = list_ContentPlayer.findElements(By.xpath("(//div[contains(@class, 'MuiBox-root')]//button[contains(text(), 'Open')])[2]"));

        for (WebElement assignmentDiv : assignmentDivsWithAssignButton) {
            String assignmentName = assignmentDiv.getText();
            System.out.println("Assignment Name: " + assignmentName);
            assignmentDiv.click();
            System.out.println("Clicked on 'Assign' button for: " + assignmentName);
//            Thread.sleep(3000);
//            btn_CloseModal.click();
            
            Thread.sleep(2000);
        }
    }

    public void processAllUnitsAndAssignments() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOf(scroll_Units));

        List<WebElement> totalUnits = scroll_Units.findElements(By.xpath("//button[contains(@aria-label,'Unit ')]"));
        for (WebElement unit : totalUnits) {
            processUnit(unit);
            break;
        }
    }

    public void processUnit(WebElement unit) throws InterruptedException{
        unit.click();
        System.out.println("Selected Unit: " + unit.getText());

        wait.until(ExpectedConditions.visibilityOf(list_ContentPlayer));
        List<WebElement> totalAssignments = list_ContentPlayer.findElements(By.xpath("//div[contains(@class, 'MuiBox-root')]//button[contains(text(), 'Assign')]"));

        for (WebElement assignment : totalAssignments) {
            processAssignment(assignment);
            break;
        }
    }

    public void processAssignment(WebElement assignment) throws InterruptedException {
        String assignmentButtonName = assignment.getText();
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", assignment);
        System.out.println("Clicked on 'Assign' button: " + assignmentButtonName);

        enterAssignmentDetails();
        selectAssignToAndStudentOptions();
        setDateTimeAndCategory();
        enterAdditionalSettings();
        assignAssignment();
        verifyDialogBox();
    }

    public void enterAssignmentDetails() throws InterruptedException {
        Thread.sleep(1000);
        EnterAssignmentTitle();
    }

    public void selectAssignToAndStudentOptions() throws InterruptedException {
        Thread.sleep(1000);
        select_AssignTo();
        Thread.sleep(1000);
        OpenToAnyStudentToggle();
        Thread.sleep(1000);
        select_Student();
    }

    public void setDateTimeAndCategory() throws InterruptedException {
        Thread.sleep(1000);
        setStartDateAndTime();
        setEndDateAndTime();
        Thread.sleep(1000);
        checkBoxLateSub();
//        Thread.sleep(1000);
//        setLateSubDateAndTime();
        Thread.sleep(1000);
        select_category();
    }

    public void enterAdditionalSettings() throws InterruptedException {
        Thread.sleep(1000);
        select_ShowAdditionalSettings();
        wait.until(ExpectedConditions.visibilityOf(panel_AdditionalSettingsContent));
        checkBox_RandomizeAnswerChoices();
        checkBox_DisplayGradesToStudent();
        dropDown_ReviewOptions();
        txtArea_AdditionalInstructions();
    }

    public void assignAssignment() throws InterruptedException {
        Thread.sleep(1000);
        AssignAssignmentButton();
        Thread.sleep(3000);
    }

    public void verifyDialogBox() throws InterruptedException {
        VerifyDialogBox();
        Thread.sleep(1000);
    }

    public void EnterAssignmentTitle(){
        edt_AssignmentTitle.click();
        ((JavascriptExecutor) driver).executeScript("arguments[0].value='';", edt_AssignmentTitle);
        String AssignmentTitle = generateAssignmentTitle("AutomatedAssignment-NAB ");
        edt_AssignmentTitle.sendKeys(AssignmentTitle);
    }

    public void select_AssignTo() throws InterruptedException {
        dropDown_AssignTo.click();
        List<WebElement> AssignToOptions = dropDown_AssignTo.findElements(By.xpath("//ul[@role='listbox']"));
        helper.selectValueFromDropdown(AssignToOptions);
        // Simulate pressing the ESC key
        Actions actions = new Actions(driver);
        actions.sendKeys(Keys.ESCAPE).build().perform();
    }

    public void OpenToAnyStudentToggle() {
        input_OpenToAnyStudent.click();
    }

    public void select_Student() throws InterruptedException{
        dropDown_SelectStudent.click();
        Thread.sleep(1000);
        List<WebElement> SelectStudentOptions = dropDown_SelectStudent.findElements(By.xpath("//ul[@role='listbox']//input"));

        if (SelectStudentOptions.isEmpty()) {
            System.out.println("No students found in the selected class. Changing class in AssignTo dropdown.");
            select_AssignTo();
        } else {
            helper.selectValueFromDropdown(SelectStudentOptions);
            // Pressing the ESC key
            Actions actions = new Actions(driver);
            actions.sendKeys(Keys.ESCAPE).build().perform();
        }
    }


    public void setStartDateAndTime() {
        String startDateTime = generateStartDateTime();
        System.out.println("Generated Start DateTime: " + startDateTime);

        calendar_StartDateTime.click();

//        JavascriptExecutor js = (JavascriptExecutor) driver;
//        js.executeScript("arguments[0].value='';", calendar_StartDateTime);

        calendar_StartDateTime.sendKeys(startDateTime);
    }

    public void setEndDateAndTime() {
        String startDateTime = generateStartDateTime();
        System.out.println("Generated Start DateTime 1: " + startDateTime);
        String endDateTime = generateEndDateTime(startDateTime);
        System.out.println("Generated End DateTime: " + endDateTime);

        calendar_EndDateTime.click();
        calendar_EndDateTime.sendKeys(endDateTime);
    }

    public void checkBoxLateSub() {
        checkBox_AllowLateSubmission.click();
    }

    public void setLateSubDateAndTime() {
        String startDateTime = generateStartDateTime();
        System.out.println("Start DateTime 2: " + startDateTime);
        String endDateTime = generateEndDateTime(startDateTime);
        System.out.println("End DateTime 2: " + endDateTime);
        String lateDateTime = generateLateSubDateTime(endDateTime);
        System.out.println("Generated Late Sub DateTime: " + lateDateTime);

        calendar_LateSubDateTime.click();
        calendar_LateSubDateTime.sendKeys(lateDateTime);
    }

    public void select_category() throws InterruptedException{
        dropDown_Category.click();
        List<WebElement> AssignmentCategoryOptions = dropDown_Category.findElements(By.xpath("//ul[@role='listbox']"));
        helper.selectValueFromDropdown(AssignmentCategoryOptions);
    }

    public void select_ShowAdditionalSettings(){
        panel_AdditionalSettings.click();
    }

    public void checkBox_RandomizeAnswerChoices(){
        if (checkBox_RandomizeAnswer.isDisplayed() && checkBox_RandomizeAnswer.isEnabled()){
            checkBox_RandomizeAnswer.click();
        }
    }

    public void checkBox_DisplayGradesToStudent(){
        checkBox_DisplayGrades.click();
    }

    public void dropDown_ReviewOptions() throws InterruptedException{
        dropDown_ReviewOptions.click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[@role='listbox']")));
        List<WebElement> ReviewOptions = dropDown_ReviewOptions.findElements(By.xpath("//ul[@role='listbox']"));
        helper.selectValueFromDropdown(ReviewOptions);
    }

    public void txtArea_AdditionalInstructions(){
        txtArea_AdditionalInstructions.click();
        ((JavascriptExecutor) driver).executeScript("arguments[0].value='';", txtArea_AdditionalInstructions);
        String AdditionalInstructions = helper.generateRandomText("Instructions-NAB ");
        txtArea_AdditionalInstructions.sendKeys(AdditionalInstructions);
    }


    public void AssignAssignmentButton() {
        btn_AssignAssignment.click();
    }

    public void VerifyDialogBox(){
        wait.until(ExpectedConditions.visibilityOf(alert_success));
        WebElement popover = driver.findElement(By.xpath("(//h2[contains(@class, 'MuiDialogTitle-root')])[2]"));
        String headerMessage = popover.getText();

        assert headerMessage.equals("Assignment Successful !") : "Assertion failed: Header message not as expected";
        WebElement closeButton = popover.findElement(By.xpath(".//button[@aria-label='close']"));
        closeButton.click();
    }

    private String generateStartDateTime() {
        Calendar calendar = Calendar.getInstance();
        Date currentDate = calendar.getTime();

        Random random = new Random();
        int randomDays = random.nextInt(30);
        calendar.add(Calendar.DAY_OF_MONTH, randomDays);
        Date randomStartDate = calendar.getTime();

        SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
        return dateFormat.format(randomStartDate);
    }

    private String generateEndDateTime(String startDateTime) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");

        try {
            Date startDate = dateFormat.parse(startDateTime);

            Calendar calendar = Calendar.getInstance();
            calendar.setTime(startDate);
            calendar.add(Calendar.MONTH, 1);

            SimpleDateFormat endDateFormat = new SimpleDateFormat("MM/dd/yyyy");
            return endDateFormat.format(calendar.getTime());
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }

    private String generateLateSubDateTime(String endDateTime) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");

        try {
            Date startDate = dateFormat.parse(endDateTime);

            Calendar calendar = Calendar.getInstance();
            calendar.setTime(startDate);
            calendar.add(Calendar.MONTH, 1);

            SimpleDateFormat lateSubDateFormat = new SimpleDateFormat("MM/dd/yyyy");
            return lateSubDateFormat.format(calendar.getTime());
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }

    public String generateAssignmentTitle(String prefix) {
        String characters = "ABC123456789";
        StringBuilder randomTitle = new StringBuilder();
        Random random = new Random();
        int length = 4;
        randomTitle.append(prefix);
        for (int i = 0; i < length; i++) {
            randomTitle.append(characters.charAt(random.nextInt(characters.length())));
        }
        return randomTitle.toString();
    }
}
