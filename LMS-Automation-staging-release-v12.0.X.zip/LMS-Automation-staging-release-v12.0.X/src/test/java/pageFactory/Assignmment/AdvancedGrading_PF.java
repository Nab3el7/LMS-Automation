package pageFactory.Assignmment;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Gradebook.AssignmentScoreVerification_PF;
import pageFactory.MyContent.AssignAssessment_PF;

import java.time.Duration;
import java.util.List;

import static pageFactory.Gradebook.AssignmentScoreVerification_PF.totalScore;

public class AdvancedGrading_PF {
    public WebDriverWait wait;
    WebDriver driver;
    StudentExecutor_PF studentExecutor;
    Helper helper;

    @FindBy(xpath = "//div[@aria-labelledby='simple-tab-2']")
    WebElement panel_Assignments;

    CorrectAnswerExecutor_PF correctAnswerExecutor_pf;
    InCorrectAnswerExecutor_PF inCorrectAnswerExecutor_pf;
    AssignAssessment_PF assignAssessment_pf;
    ReleaseAssignment_PF releaseAssignment_pf;


    public AdvancedGrading_PF(WebDriver driver) {
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        correctAnswerExecutor_pf = new CorrectAnswerExecutor_PF(driver);
        inCorrectAnswerExecutor_pf = new InCorrectAnswerExecutor_PF(driver);
        assignAssessment_pf = new AssignAssessment_PF(driver);
        studentExecutor = new StudentExecutor_PF(driver);
        helper = new Helper();
        releaseAssignment_pf = new ReleaseAssignment_PF(driver);
    }

    @FindBy(xpath = "//nav[@aria-label='pagination navigation']")
    WebElement nav_Pagination;

    @FindBy(xpath = "//button[@aria-label='Go to next page']")
    WebElement btn_NavNextPage;


    public void ReviewAttemptedCorrectAnswersAssignmentIntoClosedTab() throws InterruptedException {
        // Access the assignmentNameForCorrect value from CorrectAnswerExecutor_PF directly
        String assignmentNameForCorrect = CorrectAnswerExecutor_PF.assignmentNameForCorrect.get();
        System.out.println("Want to search assessment in closed tab: " + assignmentNameForCorrect);
        System.out.println("Another method" + CorrectAnswerExecutor_PF.getAssignmentName());


        TestRunner.getTest().log(Status.INFO, "Want to search assessment in closed tab: " + assignmentNameForCorrect);
        WebElement searchBar = driver.findElement(By.xpath("//input[@placeholder='Search Assignment by Title']"));  // Locate search bar
        searchBar.clear();
        searchBar.click();
        searchBar.sendKeys(assignmentNameForCorrect);  // Enter the assignment name in the search bar
        searchBar.sendKeys(Keys.ENTER);
        Thread.sleep(3000);

        WebElement searchBtn= driver.findElement(By.xpath("//button[contains(@class,'MuiButtonBase-root MuiIconButton-root MuiIconButton-edgeStart')]"));
        searchBtn.click();

        Thread.sleep(3000);


        WebElement myAssignmentGrid = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@aria-labelledby='simple-tab-2']")));
        boolean assignmentFound = false;

        if (myAssignmentGrid.isDisplayed() && myAssignmentGrid.isEnabled()) {
            WebElement btnClosed = driver.findElement(By.xpath("//button[@id='simple-tab-3']"));
            btnClosed.click();

            WebElement panelTabClosed = driver.findElement(By.xpath("//div[@id='simple-tabpanel-3']"));

            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='simple-tabpanel-3']")));
            Thread.sleep(3000);

            String textClosedAssignments = panelTabClosed.getText();
            System.out.println("Closed Assignments are");
            System.out.println(textClosedAssignments);

            List<WebElement> totalAssignments = driver.findElements(By.xpath(".//div[contains(@class, 'MuiGrid-container')]"));
            System.out.println("Total Closed Assignments: " + totalAssignments.size());

            for (WebElement assignment : totalAssignments) {
                try {
                    WebElement assignmentNameElement = assignment.findElement(By.xpath(".//div[contains(@class, 'notranslate')]"));
                    String assignmentsName = assignmentNameElement.getText();

                    if (assignmentsName.equals(assignmentNameForCorrect)) {
                        System.out.println("Found assignment: " + assignmentsName);
                        TestRunner.getTest().log(Status.INFO, "Assignment name in close tab: " + assignmentsName);
                        assignmentFound = true;
                        try {
                            WebElement reviewButton = assignment.findElement(By.xpath(".//button[.//span[contains(text(), 'Review')] and not(@disabled)]"));
                            TestRunner.getTest().log(Status.PASS, "Test Case Passed : Review button found and click on " + reviewButton.getText());
                            reviewButton.click();
                            System.out.println("Assignment open");
                            Thread.sleep(3000);
                            studentExecutor.handleTeacherInstructionsDialog();
                            getGradingsSummaryForAdvancedGrading();
                        } catch (NoSuchElementException e) {
                            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Review button not found for assignment: " + assignmentNameForCorrect);
                            return;
                        }
                        break;
                    } else {
                        System.out.println("Assignment not found: " + assignmentsName);
                    }
                } catch (NoSuchElementException e) {
                    // Assignment name element not found, skip this assignment and continue
                    continue;
                }
            }

        }else {

            System.out.println("Student dashboard not loaded");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Student dashboard not loaded");
        }

        if (!assignmentFound) {
            System.out.println("Assignment not found: " + assignmentNameForCorrect);
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Assignment not found: " + assignmentNameForCorrect);
        }

    }

    public static ThreadLocal<String> correctQuestions = ThreadLocal.withInitial(() -> "");
    public static ThreadLocal<String> totalQuestionInCloseAssignment = ThreadLocal.withInitial(() -> "");
    public static ThreadLocal<String> pointsFromCloseAssignment = ThreadLocal.withInitial(() -> "");

    public void getGradingsSummaryForAdvancedGrading() throws InterruptedException {
        TestRunner.startTest("Grading Summary in Closed Assignment");

        String assignmentTotalScore = totalScore.get();
        System.out.println("Assignment total score: " + assignmentTotalScore);
        TestRunner.getTest().log(Status.INFO, "Assignment total score: " + assignmentTotalScore);

        try {
            WebElement questionPlayer = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("lesson-player-ifram")));
            driver.switchTo().frame(questionPlayer);

            WebElement overviewWrapper = driver.findElement(By.className("OverviewScreenWrapper"));

            String totalQuestions = getElementTextByType(overviewWrapper, "totalquestion");
            totalQuestionInCloseAssignment.set(getElementTextByType(overviewWrapper, "totalquestion"));
            String answered = getElementTextByType(overviewWrapper, "answered");
            String unanswered = getElementTextByType(overviewWrapper, "unanswered");
            String flagged = getElementTextByType(overviewWrapper, "flagged");
            correctQuestions.set(getElementTextByType(overviewWrapper, "correct"));
            String correct = getElementTextByType(overviewWrapper, "correct");
            String incorrect = getElementTextByType(overviewWrapper, "Incorrect");
            String partial = getElementTextByType(overviewWrapper, "partial");

            System.out.println("Review Summary:");
            System.out.println("Total Questions: " + totalQuestions);
            System.out.println("Total Questions: " + totalQuestionInCloseAssignment.get());
            System.out.println("Answered: " + answered);
            System.out.println("Unanswered: " + unanswered);
            System.out.println("Flagged: " + flagged);
            System.out.println("Correct Questions: " + correctQuestions.get());
            System.out.println("Correct: " + correct);
            System.out.println("Incorrect: " + incorrect);
            System.out.println("Partial: " + partial);

            TestRunner.getTest().log(Status.INFO, "Total Questions: " + totalQuestions +
                    "Total Questions: " + totalQuestionInCloseAssignment.get() +
                    "Correct Questions: " + correctQuestions.get() +
                    ", Answered: " + answered + ", Unanswered: " + unanswered +
                    ", Flagged: " + flagged +
                    ", Correct: " + correct + ", Incorrect: " + incorrect +
                    ", Partial: " + partial);

            TestRunner.getTest().log(Status.INFO, "Getting Points From Close Assignment");

            By pointsContainer = By.xpath(
                    "//div[contains(@class,'commentContainer')]//div[contains(@class,'Container')]"
            );

            WebElement container = driver.findElement(pointsContainer);

            pointsFromCloseAssignment.set(
                    container.getText().replaceAll("\\s+", "")
            );

            TestRunner.getTest().log(
                    Status.INFO,
                    "Captured Points: " + pointsFromCloseAssignment.get()
            );

            try {
                assignmentTotalScore = overviewWrapper.findElement(By.xpath(".//div[@class='score']")).getText();
                assignmentTotalScore.replaceAll("%", "").trim();
                System.out.println("Total Score: " + assignmentTotalScore);

                //Set score in totalScore
                setAssignmentScore(assignmentTotalScore);

                TestRunner.getTest().log(Status.INFO, "Total Score: " + totalScore.get());
                TestRunner.getTest().log(Status.PASS, "Test Case Passed : Grading summary available");
            } catch (Exception e) {
                System.out.println(e);
                TestRunner.getTest().log(Status.INFO, "Grades not available");
            }

        } catch (NoSuchElementException e) {
            System.out.println("Error retrieving data: Element not found. " + e.getMessage());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Review Button Not Available");
        }
    }

    public static void setAssignmentScore(String assignmentScore) {
        totalScore.set(assignmentScore);
    }

    private String getElementTextByType(WebElement parent, String type) {
        try {
            return parent.findElement(By.xpath(".//div[@type='" + type + "']")).getText();
        } catch (NoSuchElementException e) {
            System.out.println("Element not found for type: " + type);
            return "N/A";
        }
    }

    public void VerifyAdvancedGradingInAssignment() throws InterruptedException {
        try {
            WebElement overviewWrapper = driver.findElement(By.xpath("//div[contains(@class, 'OverviewScreenWrapper')]"));
//            WebElement answer_element = overviewWrapper.findElement(By.xpath(".//div[@class='ScrollbarsCustom-Content']"));
//            List<WebElement> button_answers = answer_element.findElements(By.tagName("button"));
            List<WebElement> button_answers = overviewWrapper.findElements(By.xpath(".//button[@isCorrectAnswer]"));
            System.out.println("Total Answer: " + button_answers.size());
            if (!button_answers.isEmpty()) {
                WebElement button = button_answers.get(0);

                String numberDiv = button.getText();
                System.out.println("Button text: " + numberDiv);

                if (numberDiv.contains("1")) {
                    System.out.println("The button text is correct and is set to '1' ");
                    TestRunner.getTest().log(Status.PASS, "The button text is correct and is set to '1' ");
                } else {
                    System.out.println("The button text is not '1'. It is: " + numberDiv);
                    TestRunner.getTest().log(Status.FAIL, "The button text is not '1' . It is: " + numberDiv);
                }

                if (button.isDisplayed()) {
                    System.out.println("Button was clicked: " + button.getText());
                    button.click();
                    System.out.println("Answer is clicked.");
                    isGradingExist();
                } else {
                    System.out.println("Button is not displayed.");
                }
            } else {
                System.out.println("No answer buttons found.");
            }
        } catch (NoSuchElementException e) {
            System.out.println("Assignment not found in close tab so we did not review assignment");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Assignment not found in close tab so we did not review assignment");
        }
    }

    public void isGradingExist() throws InterruptedException {

        driver.switchTo().defaultContent();
        ReleaseAssignment_PF.temp.set(0);
        List<WebElement> questionButtons = nav_Pagination.findElements(By.xpath("//button[contains(@aria-label, 'Go to page')]"));
        for (WebElement questionButton : questionButtons) {
            String questionText = questionButton.getText();
            System.out.println("Question: " + questionText);
        }
        while (btn_NavNextPage.isEnabled()) {
            Thread.sleep(2000);
            releaseAssignment_pf.VerifyGradingWithWeightAtAssign();
            btn_NavNextPage.click();
            Thread.sleep(2000);
        }

        Thread.sleep(2000);
        WebElement btn_CloseReview = driver.findElement(By.xpath("//button[@id='closeReview-btn']"));
        helper.scrollToElement(driver, btn_CloseReview);
//        Thread.sleep(1000);
        System.out.println("Clicked on close review");
        btn_CloseReview.click();
    }

}
