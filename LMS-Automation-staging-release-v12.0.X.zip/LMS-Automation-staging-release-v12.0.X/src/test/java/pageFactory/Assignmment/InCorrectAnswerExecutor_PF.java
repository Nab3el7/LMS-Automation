package pageFactory.Assignmment;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import apiHandler.GetAPIHandler;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.*;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.MyContent.AssignAssessment_PF;
import org.openqa.selenium.ElementNotInteractableException;

import java.awt.*;
import java.time.Duration;
import java.util.*;
import java.util.List;
import java.util.stream.Collectors;

public class InCorrectAnswerExecutor_PF {

    String baseUrl = Configurations.App_url;

    Helper helper;
    GetAPIHandler getAPIHandler;
    StudentExecutor_PF studentExecutor;
    AssignAssessment_PF assignAssessment;
    public WebDriverWait wait;
    WebDriver driver;
    //    String[] specificClasses = {"FL Grade 1", "FL Grade 2"};
    String[] specificClasses = {"FL Grade 5"};
    String questionID = null;

    public static final String BASE_NAME = Configurations.getDotEnv().get("SITE_ASSIGNMENT_NAME_FOR_INCORRECT_ANSWER");
    public static String AssignmentNameForInCorrect;

    @FindBy(xpath = "//input[@name='title']")
    WebElement edt_AssignmentTitle;

    @FindBy(xpath = "//label[contains(text(),'Assign to')]/parent::div")
    WebElement dropDown_AssignTo;

    @FindBy(xpath = "(//div[@class='ScrollbarsCustom-Content'])[2]")
    WebElement panel_Assignments;

    @FindBy(xpath = "//nav[@aria-label='pagination navigation']")
    WebElement nav_Pagination;

    @FindBy(xpath = "//button[@aria-label='Go to next page']")
    WebElement btn_NavNextPage;

    public InCorrectAnswerExecutor_PF(WebDriver driver) {
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        helper = new Helper();
        getAPIHandler = new GetAPIHandler();
        studentExecutor = new StudentExecutor_PF(driver);
        assignAssessment = new AssignAssessment_PF(driver);
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    public void ReleaseSpecificAssignmentForInCorrectAnswers() throws InterruptedException {
        System.out.println("Release Assignment For InCorrect Answers");

        Thread.sleep(2000);
        WebElement listContentPlayer = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@id='ContentPlayerMainPanel']")));

        if (listContentPlayer.isDisplayed() && listContentPlayer.isEnabled()) {
            WebElement btnAssignForSpecificAssignment = listContentPlayer.findElement(By.xpath("(//div[contains(@class, 'MuiBox-root')]//button[contains(text(), 'Assign')])[1]"));
            btnAssignForSpecificAssignment.click();

            WebElement dialogAssignment = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@role='dialog']")));
            if (dialogAssignment.isDisplayed()) {
                EnterAssignmentTitleForInCorrectAnswers();
                selectSpecificClasses();
                assignAssessment.setDateTimeAndCategory();
                assignAssessment.enterAdditionalSettings();
                assignAssessment.enterWeightPercentage();
                assignAssessment.assignAssignment();
                assignAssessment.verifyDialogBox();
                TestRunner.getTest().log(Status.PASS, "Test Case Passed : Specific Assignment Release For In-Correct Answers Successfully");
            }
        }
    }

    public void EnterAssignmentTitleForInCorrectAnswers() throws InterruptedException{

        String oldTitle = edt_AssignmentTitle.getAttribute("value");
        System.out.println("Old Title: " + oldTitle);
        edt_AssignmentTitle.click();

        Actions actions = new Actions(driver);
        for (int i = 0; i < oldTitle.length(); i++) {
            actions.sendKeys(Keys.BACK_SPACE).perform();
        }

        ((JavascriptExecutor) driver).executeScript("arguments[0].value='';", edt_AssignmentTitle);
        Thread.sleep(2000);
        AssignmentNameForInCorrect = BASE_NAME + "_" + new Date();
        System.out.println("Enter Assignment Title Successfully " + AssignmentNameForInCorrect);
        edt_AssignmentTitle.sendKeys(AssignmentNameForInCorrect);
        TestRunner.getTest().log(Status.PASS, "Released assignment title that attempted with incorrect answer: " + AssignmentNameForInCorrect);
    }

    public void selectSpecificClasses() throws InterruptedException {
        dropDown_AssignTo.click();

        WebElement assignToOptions = dropDown_AssignTo.findElement(By.xpath("//ul[@role='listbox']"));
        Thread.sleep(2000);

        List<WebElement> totalClasses = assignToOptions.findElements(By.tagName("li"));
        System.out.println("Total Classes: " + totalClasses.size());
        TestRunner.getTest().log(Status.INFO, "Total Classes: " + totalClasses.size());

        for (WebElement totalClass : totalClasses) {
            String totalClassName = totalClass.findElement(By.xpath(".//span[contains(@class, 'MuiListItemText-primary')]")).getText();
            WebElement checkBoxClass = totalClass.findElement(By.xpath(".//input"));
            System.out.println("Total Class: " + totalClassName);
            for (String className : specificClasses) {
                if (totalClassName.equals(className)) {
                    System.out.println("Selected Class: " + totalClassName);
                    TestRunner.getTest().log(Status.INFO, "Selected class name: " + totalClassName);
                    totalClass.click();
                    checkBoxClass.click();
                    break;
                }
            }
        }

        // Close the dropdown by simulating pressing the ESC key
        Actions actions = new Actions(driver);
        actions.sendKeys(Keys.ESCAPE).build().perform();
    }

    public void SelectAssignmentForInCorrectAnswers() throws InterruptedException, AWTException {
        if (!panel_Assignments.isDisplayed()) {
            throw new NoSuchElementException("Assignments panel is not displayed");
        }

        WebElement panelTabOpen = panel_Assignments.findElement(By.xpath(".//div[@id='simple-tabpanel-2']"));
        wait.until(ExpectedConditions.visibilityOf(panelTabOpen));
        Thread.sleep(2000);
        List<WebElement> totalAssignments = panel_Assignments.findElements(By.xpath(".//div[contains(@class, 'MuiGrid-container')]"));
        System.out.println("Total Assignments: " + totalAssignments.size());
        System.out.println("Attempting to find assignment: " + AssignmentNameForInCorrect);
        TestRunner.getTest().log(Status.INFO, "Looking for assignment: " + AssignmentNameForInCorrect);

        boolean assignmentFound = false; // Flag to track if assignment is found

        for (WebElement assignment : totalAssignments) {
            WebElement assignmentNameElement = assignment.findElement(By.xpath(".//div[contains(@class, 'notranslate')]"));
            String assignmentName = assignmentNameElement.getText();
            System.out.println("Assignment Name: " + assignmentName);

            if (assignmentName.equals(AssignmentNameForInCorrect)) {
                System.out.println("Found assignment: " + assignmentName);
                try {
                    WebElement startOrResumeButton = assignment.findElement(By.xpath(".//div[@statustype='START' or @statustype='RESUME']"));
                    startOrResumeButton.click();
                    TestRunner.getTest().log(Status.PASS, "Successfully started assignment: " + assignmentName);
                    System.out.println("Assignment started");
                    Thread.sleep(3000);
                    studentExecutor.handleTeacherInstructionsDialog();
                    AttemptAndSubmitWithInCorrectAnswers();
                    Thread.sleep(2000);

                    assignmentFound = true;  // Set assignment found to true
                } catch (NoSuchElementException e) {
                    System.out.println("START/RESUME button not found for assignment: " + assignmentName);
                }

                // Call the refresh function after completing the assignment
                refreshAndLoadAssignments();
                break;
            } else {
                System.out.println("Assignment not found: " + assignmentName);
            }
        }

        // If assignment was not found, use the search bar logic
        if (!assignmentFound) {
            System.out.println("Assignment not found in the list. Using search bar to find: " + AssignmentNameForInCorrect);
            TestRunner.getTest().log(Status.WARNING, "Assignment not found in the list. Using search bar to find: " + AssignmentNameForInCorrect);

            try {
                WebElement searchBar = driver.findElement(By.xpath("//input[@placeholder='Search Assignment by Keyword']"));  // Locate search bar
                searchBar.clear();
                searchBar.click();
                searchBar.sendKeys(AssignmentNameForInCorrect);  // Enter the assignment name in the search bar
                searchBar.sendKeys(Keys.ENTER);  // Trigger the search

                // Wait for the search results to load
                WebDriverWait searchWait = new WebDriverWait(driver, Duration.ofSeconds(10));
                List<WebElement> searchResults = searchWait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(
                        By.xpath("//div[contains(@class, 'notranslate')]")  // Adjust XPath to fit your app's search result structure
                ));

                boolean assignmentFoundInSearch = false;

                for (WebElement result : searchResults) {
                    String foundAssignmentName = result.getText();  // Extract the assignment name

                    if (foundAssignmentName.contains(AssignmentNameForInCorrect)) {
                        // Assignment found in search results, click it
                        result.click();
                        TestRunner.getTest().log(Status.PASS, "Assignment found and selected via search: " + AssignmentNameForInCorrect);
                        System.out.println("Assignment found via search and clicked: " + AssignmentNameForInCorrect);

                        // Locate and click the START/RESUME button after search
                        try {
                            WebElement startOrResumeButton = driver.findElement(By.xpath(".//div[@statustype='START' or @statustype='RESUME']"));
                            startOrResumeButton.click();
                            TestRunner.getTest().log(Status.PASS, "Successfully started assignment after search: " + AssignmentNameForInCorrect);
                            System.out.println("Assignment started after search");
                            Thread.sleep(3000);

                            studentExecutor.handleTeacherInstructionsDialog();
                            AttemptAndSubmitWithInCorrectAnswers();
                            Thread.sleep(2000);

                            // Call the refresh function after the assignment is started through search
                            refreshAndLoadAssignments();

                        } catch (NoSuchElementException startResumeException) {
                            System.out.println("START/RESUME button not found after search for assignment: " + AssignmentNameForInCorrect);
                            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: START/RESUME button not found after search: " + AssignmentNameForInCorrect);
                        }

                        assignmentFoundInSearch = true;
                        break;
                    }
                }

                if (!assignmentFoundInSearch) {
                    System.out.println("Assignment not found in search results: " + AssignmentNameForInCorrect);
                    TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Assignment not found in search results: " + AssignmentNameForInCorrect);
                }

            } catch (NoSuchElementException e) {
                System.out.println("Search bar not found.");
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Search bar not found.");
            }
        }
    }

    public void refreshAndLoadAssignments() {
        try {
            // Refresh the page
            refreshPage();
            Thread.sleep(3000);

            // Handle any dialog box or announcements
            studentExecutor.dialogBox_ImpAnnouncement();

            // Locate the panel containing the assignments
            WebElement tabOpenPanel = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[@class='ScrollbarsCustom-Content'])[2]")));
            WebElement tabOpenAssignments = tabOpenPanel.findElement(By.xpath(".//div[@id='simple-tabpanel-2']"));

            // Get the total assignments after refresh
            List<WebElement> totalAssignments = tabOpenAssignments.findElements(By.xpath(".//div[contains(@class, 'notranslate')]"));
            System.out.println("Total Assignments after refresh: " + totalAssignments.size());

            // Check if there are any assignments and print their text
            if (!totalAssignments.isEmpty()) {
                for (WebElement assignmentText : totalAssignments) {
                    System.out.println("Assignment Text: " + assignmentText.getText());
                }
            }
        } catch (TimeoutException te) {
            System.out.println("Failed to load assignments after refresh. Retrying...");
        } catch (InterruptedException e) {
            System.out.println("Thread was interrupted.");
        }
    }

    private void refreshPage() {
        driver.navigate().to(baseUrl);
    }

    public void AttemptAndSubmitWithInCorrectAnswers() throws InterruptedException, AWTException {
        TestRunner.startTest("Attempt assignment with all incorrect answers");
        if (!isPaginationDisplayed()) {
            studentExecutor.AssignmentSubmitAsCompleted();
            return;
        }

        try {
            List<WebElement> questionButtons = nav_Pagination.findElements(By.xpath("//button[contains(@aria-label, 'Go to page')]"));

            for (WebElement questionButton : questionButtons) {
                String questionText = questionButton.getText();
                System.out.println("Question: " + questionText);
                TestRunner.getTest().log(Status.INFO, "Total Questions: " + questionText);
            }

            TestRunner.startTest("Attempt assignment with all incorrect answers");
            while (btn_NavNextPage.isEnabled()) {
                Thread.sleep(2000);
                AttemptAssignmentWithInCorrectAnswers();
                btn_NavNextPage.click();
                Thread.sleep(2000);
            }

            studentExecutor.AssignmentSubmitAsCompleted();
        } catch (NoSuchElementException | ElementNotInteractableException | TimeoutException e) {
            System.out.println("No Question found.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : No Question found or Question not visible");
        }
    }

    private boolean isPaginationDisplayed() {
        try {
            return nav_Pagination.isDisplayed();
        } catch (NoSuchElementException | ElementNotInteractableException | TimeoutException e) {
            return false;
        }
    }

    public void AttemptAssignmentWithInCorrectAnswers() throws InterruptedException, AWTException {
        System.out.println("I'm in attempting all questions with incorrect answers");
        Thread.sleep(1000);

        WebElement questionPlayer = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("lesson-player-ifram")));
        driver.switchTo().frame(questionPlayer);
        WebElement QuestionBody = driver.findElement(By.xpath("//div[contains(@class, 'LessonPlayerRoot')]"));

        WebElement QuestionPlayer = null;

        try {
            List<WebElement> MultiParts = QuestionBody.findElements(By.xpath("//div[contains(@class, 'planComponentQuestion')]"));
            System.out.println("Total number of multi-part on this page: " + MultiParts.size());
            TestRunner.getTest().log(Status.INFO, "Total part of question (if multipart question exists): " + MultiParts.size());

            for (WebElement part : MultiParts) {
                QuestionPlayer = part.findElement(By.xpath(".//div[contains(@class, 'QuestionPlayer')]"));

                System.out.println("Question is found");
                String questionType = QuestionPlayer.getAttribute("data-type");
                System.out.println("Question Type is: " + questionType);
                TestRunner.getTest().log(Status.INFO, "Attempted question type is: " + questionType);

                WebElement questionRoot = QuestionPlayer.findElement(By.xpath(".//div[contains(@class, 'question-root')]"));
                questionID = questionRoot.getAttribute("data-question-id");
                System.out.println("Question ID is: " + questionID);
                TestRunner.getTest().log(Status.INFO, "Attempted question ID is: " + questionID);

                switch (questionType) {
                    case "extended-text-interaction" -> studentExecutor.QuestionExtendedTextInteraction();
                    case "choice-interaction-single" -> QuestionChoiceInteractionSingleInAccurate(questionRoot);
                    case "choice-interaction" -> QuestionChoiceInteractionsInAccurate(questionRoot);
                    case "match-dragdrop-interaction" -> QuestionMatchDragdropInteractionInAccurate(questionRoot);
                    case "inline-choice-select-interaction" -> QuestionInlineChoiceSelectInteractionInAccurate();
                    case "gap-match-interaction" -> QuestionGapMatchInteractionInAccurate();
                    case "choice-imagelabel-select-interaction" -> QuestionChoiceImageLabelSelectInteractionInAccurate();
                    case "inline-choice-text-interaction" -> studentExecutor.QuestionInlineChoiceTextInteraction();
                    case "inline-choice-spelling-interaction" -> QuestionInlineChoiceSpellingInteractionInAccurate();
                    case "graphic-gap-match-interaction" -> QuestionGraphicGapMatchInteractionInAccurate();
                    case "drawing-interaction" -> studentExecutor.QuestionDrawingInteraction();
                    case "match-interaction" -> QuestionMatchInteractionInAccurate();
                    case "order-interaction" -> QuestionOrderInteractionWithIncorrectAnswers();
                    case "upload-interaction" -> studentExecutor.QuestionUploadInteraction();
                    default -> {
                    }
                }
            }
        } catch (NoSuchElementException e) {
            System.out.println("This is a content player question and have no any data type question");
            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
        } finally {
            driver.switchTo().defaultContent();
        }
    }
    public void QuestionOrderInteractionWithIncorrectAnswers() throws InterruptedException {
        TestRunner.startTest("Question: Order Interaction Attempt with Incorrect Answer");
        System.out.println("Attempting Order Interaction question with Incorrect answers for questionID: " + questionID);
        Thread.sleep(1000);

        try {
            WebElement QuestionComponentBody = driver.findElement(By.xpath("//div[@class='planComponentQuestion']"));
            WebElement QuestionContainer = QuestionComponentBody.findElement(By.xpath(".//div[@class='column-options-container']"));
            List<WebElement> values_Drag = QuestionContainer.findElements(By.xpath(".//div[contains(@class, 'task-container task-container-draging-off')]"));

            System.out.println("Found " + values_Drag.size() + " draggable elements");
            TestRunner.getTest().log(Status.INFO, "Dragable items " + values_Drag.size());

            if (!values_Drag.isEmpty()) {

                String correctQuestionResponse = getAPIHandler.getCorrectAnswerSource(questionID).toString();
                System.out.println("Question Source: ");
                System.out.println(correctQuestionResponse);
                TestRunner.getTest().log(Status.INFO, "Question Source: " + correctQuestionResponse);

                List<String> correctKeys = getAPIHandler.getCorrectAnswerResponseForChoiceInteraction(questionID);
                System.out.println("Fetched correct keys: " + correctKeys);
                TestRunner.getTest().log(Status.INFO, "Fetched correct keys: " + correctKeys);

                while (true) {
                    // Shuffle the order of draggable elements to simulate incorrect answers
                    Collections.shuffle(values_Drag);

                    Map<String, WebElement> elementsMap = new HashMap<>();
                    for (WebElement valueDrag : values_Drag) {
                        String draggableId = valueDrag.getAttribute("data-rbd-draggable-id").substring(correctQuestionResponse.equals("[learnosity]") ? "choice-".length() : 0);
                        elementsMap.put(draggableId, valueDrag);
                    }

                    System.out.println("Mapped draggable elements: " + elementsMap.keySet());
                    TestRunner.getTest().log(Status.INFO, "Mapped keys: " + elementsMap.keySet());

                    List<WebElement> shuffledElements = correctKeys.stream().map(elementsMap::get).collect(Collectors.toList());
                    Actions action = new Actions(driver);

                    for (int i = 0; i < shuffledElements.size(); i++) {
                        WebElement element = shuffledElements.get(i);
                        wait.until(ExpectedConditions.elementToBeClickable(element));

                        action.clickAndHold(element).moveByOffset(5, 0).perform();
                        if (i == 0) {
                            action.moveToElement(element, -50, 0).release().perform();
                        } else {
                            action.moveToElement(shuffledElements.get(i - 1), correctQuestionResponse.equals("[learnosity]") ? -50 : 100, 0).release().perform();
                        }

                        action.build().perform();
                        String draggableKey = element.getAttribute("data-rbd-draggable-id");
                        System.out.println("Moved element with key: " + draggableKey + " (" + element.getText() + ") to the new position: " + (i + 1));
                        TestRunner.getTest().log(Status.INFO, "Moved element with key: " + draggableKey + " (" + element.getText() + ") to the new position: " + (i + 1));
                        Thread.sleep(2000); // Preferably replace with WebDriverWait
                    }

                    System.out.println("Verifying the current order of elements...");
                    Thread.sleep(100); // Preferably replace with WebDriverWait
                    boolean isIncorrectOrder = !correctQuestionResponse.equals("[learnosity]") ? verifyOrderFromUIForC2C(correctKeys) : verifyOrderFromUI(correctKeys);

                    if (isIncorrectOrder) {
                        System.out.println("Incorrect order detected, retrying...");
                        TestRunner.getTest().log(Status.INFO, "Incorrect order detected, retrying...");
                    } else {
                        TestRunner.getTest().log(Status.PASS, "Test case Passed : Question attempted successfully");
                        break;
                    }
                }
            } else {
                TestRunner.getTest().log(Status.FAIL, "Test case Failed : No options found");
            }
        } catch (Exception e) {
            System.out.println("Exception encountered: " + e.getMessage());
            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
        }

        Thread.sleep(2000);
        helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
    }
    

    private boolean verifyOrderFromUIForC2C(List<String> correctKeys) {
        // Replace ".task-container[data-rbd-draggable-id]" with the actual CSS selector of your draggable elements
        List<WebElement> currentOrderElements = driver.findElements(By.cssSelector(".task-container[data-rbd-draggable-id]"));
        for (int i = 0; i < currentOrderElements.size(); i++) {
            String actualKey = currentOrderElements.get(i).getAttribute("data-rbd-draggable-id");
            if (!correctKeys.get(i).equals(actualKey)) {
                return false;
            }
        }
        return true;
    }
    private boolean verifyOrderFromUI(List<String> correctKeys) {
        // Replace ".task-container[data-rbd-draggable-id]" with the actual CSS selector of your draggable elements
        List<WebElement> currentOrderElements = driver.findElements(By.cssSelector(".task-container[data-rbd-draggable-id]"));
        for (int i = 0; i < currentOrderElements.size(); i++) {
            String actualKey = currentOrderElements.get(i).getAttribute("data-rbd-draggable-id").substring("choice-".length());
            if (!correctKeys.get(i).equals(actualKey)) {
                return false;
            }
        }
        return true;
    }

    public void QuestionChoiceInteractionSingleInAccurate(WebElement questionPart) throws InterruptedException {
        TestRunner.startTest("Question: Choice Interaction Single Attempt with Incorrect Answer");
        System.out.println("Click on Incorrect 1 option");
        Thread.sleep(1000);

        try {
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(".//div[contains(@class,'SingleSelectWrapper')]")));

            WebElement inputOptions = questionPart.findElement(By.xpath(".//div[contains(@class,'SingleSelectWrapper')]"));
            List<WebElement> listOptions = inputOptions.findElements(By.tagName("li"));
            int totalInputElements = listOptions.size();
            System.out.println("Total inputElements: " + totalInputElements);
            TestRunner.getTest().log(Status.INFO, "Total options: " + totalInputElements);

            if (!listOptions.isEmpty()) {
                List<String> correctKeys = getAPIHandler.getCorrectAnswerResponseIdentifier(questionID);
                System.out.println("Correct Keys ID's of Question: ");
                for (String key : correctKeys) {
                    System.out.println(key);
                    TestRunner.getTest().log(Status.INFO, "Correct Key(s): " + key);
                }

                for (WebElement option : listOptions) {
                    WebElement radioBtn = option.findElement(By.tagName("input"));
                    String id = radioBtn.getAttribute("aria-labelledby").substring("checkbox-list-label-".length());

                    System.out.println("Option ID for Matching: " + id);

                    if (!correctKeys.contains(id)) {
                        System.out.println("InCorrect option found");
                        radioBtn.click();
                        TestRunner.getTest().log(Status.INFO, "Incorrect option clicked");
                        break;
                    }
                }
                TestRunner.getTest().log(Status.PASS, "Test case Passed : Question attempted successfully");
            } else {
                TestRunner.getTest().log(Status.FAIL, "Test case Failed : No options found");
            }
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
        }
        Thread.sleep(2000);
        helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
    }

    public void QuestionChoiceInteractionsInAccurate(WebElement questionPart) throws InterruptedException {
        TestRunner.startTest("Question: Choice Interaction Attempt with Incorrect Answer");
        System.out.println("I'm in Select In-accurate Choice Interaction question");
        Thread.sleep(1000);
        try {
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(".//div[contains(@class,'MultiselectList')]")));

            WebElement inputElement = questionPart.findElement(By.xpath(".//div[contains(@class,'MultiselectList')]"));
            List<WebElement> listOptions = inputElement.findElements(By.tagName("li"));
            List<WebElement> listAvatarOptions = inputElement.findElements(By.tagName("p"));
            int totalInputElements = listOptions.size();
            System.out.println("Total inputElements: " + totalInputElements);
            TestRunner.getTest().log(Status.INFO, "Total options: " + totalInputElements);

            if (!listOptions.isEmpty()) {
                List<String> correctKeys = getAPIHandler.getCorrectAnswer(questionID);
                System.out.println("correct Keys of Question: ");
                for (String key : correctKeys) {
                    System.out.println(key);
                    TestRunner.getTest().log(Status.INFO, "Correct Key(s): " + key);
                }
                for (WebElement option : listOptions) {
                    WebElement checkbox = option.findElement(By.xpath(".//input[@type='checkbox']"));
                    if (checkbox.isSelected()) {
                        checkbox.click();
                    }
                }
                for (int i = 0; i < listAvatarOptions.size(); i++) {
                    WebElement avatarElement = listAvatarOptions.get(i);
                    String avatarValue = avatarElement.getAttribute("innerText");
                    // Check if the avatarValue is not present in correctKeys
                    if (!correctKeys.contains(avatarValue)) {
                        System.out.println("Option '" + avatarValue + "' is incorrect.");
                        if (i < listOptions.size()) {
                            WebElement option = listOptions.get(i);
                            WebElement checkbox = option.findElement(By.xpath(".//input[@type='checkbox']"));
                            if (!checkbox.isSelected()) {
                                checkbox.click();
                                TestRunner.getTest().log(Status.PASS, "Test Case Passed : Incorrect option clicked");
                                System.out.println("Option '" + avatarValue + "' selected.");
                            }
                        }
                    }
                }
                TestRunner.getTest().log(Status.PASS, "Test case Passed : Question attempted successfully");
            } else {
                TestRunner.getTest().log(Status.FAIL, "Test case Failed : No options found");
            }
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
        }
        helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
    }

    private int generateRandomNumber(int max, int min, int givenNumber) {
        Random random = new Random();
        int randomNumber;
        do {
            randomNumber = random.nextInt(max - min) + min;
        } while (randomNumber == givenNumber);
        return randomNumber;
    }

    public void QuestionChoiceImageLabelSelectInteractionInAccurate() throws InterruptedException {
        TestRunner.startTest("Question: Choice Image Label Attempt with Incorrect Answer");
        System.out.println("I'm in Select InAccurate Choice Image Label Select Interaction");

        WebElement ItemAnswerContainer = driver.findElement(By.xpath("//div[contains(@class, 'imageBodyContainer')]"));
        List<WebElement> answersDropdowns = ItemAnswerContainer.findElements(By.xpath(".//div[contains(@class, 'correct-container')]"));
        System.out.println("Total options dropdown:" + answersDropdowns.size());
        TestRunner.getTest().log(Status.INFO, "Total options dropdown: " + answersDropdowns.size());

        if (answersDropdowns.isEmpty()) {
            System.out.println("No answer dropdowns found.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : No answer dropdowns found.");
            return;
        }

        String correctQuestionResponse = getAPIHandler.getCorrectAnswerSource(questionID).toString();
        System.out.println("Question Source: " + correctQuestionResponse);
        TestRunner.getTest().log(Status.INFO, "Question Source: " + correctQuestionResponse);

        List<String> correctKeys;
        if (correctQuestionResponse.equals("[C2C]")) {
            correctKeys = getAPIHandler.getCorrectAnswerResponseGapIdentifier(questionID);
        } else if (correctQuestionResponse.equals("[learnosity]")) {
            correctKeys = getAPIHandler.getCorrectAnswerResponseIdentifier(questionID);
        } else {
            System.out.println("Unknown question source.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Unknown question source.");
            return;
        }
        Set<String> correctKeysSet = new HashSet<>(correctKeys);
        System.out.println("Correct Keys: " + correctKeysSet);
        TestRunner.getTest().log(Status.INFO, "Correct Answers Keys: " + correctKeysSet);

        for (WebElement dropdown : answersDropdowns) {
            dropdown.click();
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.tagName("option")));
            List<WebElement> options = dropdown.findElements(By.tagName("option"));
            for (WebElement option : options) {
                String id = option.getAttribute("value");
                String optionText = option.getText();
                if (!correctKeysSet.contains(id) && !optionText.equals("choose")) {
                    option.click();
                    System.out.println("Clicked correct option with ID: " + id);
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed : Incorrect Option Clicked " + id);
                    Thread.sleep(500);
                    break;
                }
            }
        }

        Thread.sleep(2000);
        helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
    }

    public void QuestionMatchInteractionInAccurate() throws InterruptedException {
        TestRunner.startTest("Question: Match Interaction Attempt with Incorrect Answer");
        System.out.println("I'm in Match Interaction Inaccurate question");
        WebElement QuestionPlayer = driver.findElement(By.xpath("//div[contains(@class, 'QuestionPlayer')]"));
        // MI = Match Interactions
        WebElement ItemQuestionContainerMI = QuestionPlayer.findElement(By.xpath("//div[contains(@class, 'questionTextContainer')]"));
        System.out.println("Question heading is: " + ItemQuestionContainerMI.getText());
        TestRunner.getTest().log(Status.INFO, "Question heading is: " + ItemQuestionContainerMI.getText());

        WebElement ItemAnswerContainerMI = QuestionPlayer.findElement(By.xpath("//div[contains(@class, 'testItemAnswersContainer')]"));
        List<WebElement> totalRowsQuestionMatchInteraction = ItemAnswerContainerMI.findElements(By.xpath("//table/tbody/tr"));
        List<String> correctKeysResponse = getAPIHandler.getCorrectAnswerResponse(questionID);

        System.out.println("Correct Keys Response of Question: ");
        for (String keyResponse : correctKeysResponse) {
            System.out.println(keyResponse);
            TestRunner.getTest().log(Status.INFO, "Correct Keys Response: " + keyResponse);
        }

        int rowIndex = 1;
        for (String keyResponse : correctKeysResponse) {

            WebElement rowQuestionChoice = totalRowsQuestionMatchInteraction.get(rowIndex);
            List<WebElement> inputChoice = rowQuestionChoice.findElements(By.tagName("input"));

            int columnIndex = generateRandomNumber(inputChoice.size(), 0, Integer.parseInt(keyResponse));
            System.out.println("Choice question for row " + rowIndex + " is: " + rowQuestionChoice.getText());
//            inputChoice.get(columnIndex).click();

            WebElement choice = inputChoice.get(columnIndex);
            if (choice.isSelected()) {
                choice.click();
                TestRunner.getTest().log(Status.PASS, "Test Case Passed : Incorrect Choice Match Interaction Selected");
            } else {
                choice.click();
                System.out.println("Inaccurate option selected " + columnIndex + " for row " + rowIndex);
                TestRunner.getTest().log(Status.PASS, "Test Case Passed : Incorrect Choice Match Interaction Selected");
            }
            rowIndex++;
        }

        Thread.sleep(2000);
        helper.takeScreenshot(driver , Thread.currentThread().getStackTrace()[1].getMethodName() );
    }

    public void QuestionInlineChoiceSelectInteractionInAccurate() throws InterruptedException {
        TestRunner.startTest("Question: Inline Choice Select Interaction Attempt with Correct Answer");
        System.out.println("I'm in Select InAccurate Inline Choice Select Interaction question");

        WebElement itemAnswerContainer = driver.findElement(By.xpath("//div[contains(@class, 'testItemAnswersContainer')]"));
        List<WebElement> answersDropdowns = itemAnswerContainer.findElements(By.xpath(".//div[contains(@class, 'correct-container')]"));
        System.out.println("Total options dropdown:" + answersDropdowns.size());
        TestRunner.getTest().log(Status.INFO, "Total options dropdown: " + answersDropdowns.size());

        if (answersDropdowns.isEmpty()) {
            System.out.println("No answer dropdowns found.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : No answer dropdowns found.");
            return;
        }

        String correctQuestionResponse = getAPIHandler.getCorrectAnswerSource(questionID).toString();
        System.out.println("Question Source: " + correctQuestionResponse);
        TestRunner.getTest().log(Status.INFO, "Question Source: " + correctQuestionResponse);

        List<String> correctKeys;
        if (correctQuestionResponse.equals("[C2C]")) {
            correctKeys = getAPIHandler.getCorrectAnswerResponseGapIdentifier(questionID);
            Set<String> correctKeysSet = new HashSet<>(correctKeys);
            System.out.println("Correct Keys: " + correctKeysSet);
            TestRunner.getTest().log(Status.INFO, "Correct Keys: " + correctKeysSet.size());

            for (WebElement dropdown : answersDropdowns) {
//            dropdown.click();
                wait.until(ExpectedConditions.elementToBeClickable(dropdown));
                ((JavascriptExecutor) driver).executeScript("arguments[0].click();", dropdown);

                wait.until(ExpectedConditions.visibilityOfElementLocated(By.tagName("option")));

                List<WebElement> options = dropdown.findElements(By.tagName("option"));
                System.out.println("Options: " + options.size());
                TestRunner.getTest().log(Status.INFO, "Options: " + options.size());

                for (WebElement option : options) {
                    String id = option.getAttribute("value");
                    if (!correctKeysSet.contains(id) & !option.getText().equals("choose")) {
                        option.click();
                        System.out.println("Clicked incorrect option with ID: " + id);
                        TestRunner.getTest().log(Status.PASS, "Test Case Passed : Clicked incorrect option with ID: " + id);
                        Thread.sleep(500);
                        break;
                    }
                }
            }
        } else if (correctQuestionResponse.equals("[learnosity]")) {
            correctKeys = getAPIHandler.getCorrectAnswerResponseForChoiceInteraction(questionID);
            Set<String> correctKeysSet = new HashSet<>(correctKeys);
            System.out.println("Correct Keys: " + correctKeysSet);
            TestRunner.getTest().log(Status.INFO, "Correct Keys: " + correctKeysSet.size());

            List<WebElement> ptags = driver.findElements(By.xpath("//div[contains(@class, 'testItemAnswersContainer')]//p"));
            for (WebElement ptag : ptags) {
                try {
                    List<WebElement> temp = ptag.findElements(By.xpath(".//div[contains(@class, 'correct-container')]"));
                    System.out.println("inside Ptag: " + temp.size());

                    for (WebElement dropdown : temp) {
                        try {
                            System.out.println("Attempting to click a dropdown.");

                            wait.until(ExpectedConditions.elementToBeClickable(dropdown));
                            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", dropdown);
                            Thread.sleep(500);
                            dropdown.click();

                            System.out.println("Dropdown clicked.");

                            wait.until(ExpectedConditions.visibilityOfElementLocated(By.tagName("option")));
                            List<WebElement> options = dropdown.findElements(By.tagName("option"));
                            System.out.println("Options found: " + options.size());
                            TestRunner.getTest().log(Status.INFO, "Options: " + options.size());

                            for (WebElement option : options) {
                                String id = option.getAttribute("value");
                                if (!correctKeysSet.contains(id) && !option.getText().equals("choose")) {
                                    option.click();
                                    System.out.println("Clicked incorrect option with ID: " + id);
                                    TestRunner.getTest().log(Status.PASS, "Test Case Passed : Clicked incorrect option with ID: " + id);
                                    Thread.sleep(500);
                                    break;
                                }
                            }
                        } catch (StaleElementReferenceException e) {
                            // Retry locating the dropdown
                            System.err.println("Stale element reference encountered, retrying...");
                            temp = ptag.findElements(By.xpath(".//div[contains(@class, 'correct-container')]"));
                        } catch (Exception e) {
                            System.err.println("Error while interacting with dropdown: " + e.getMessage());
                            TestRunner.getTest().log(Status.WARNING, "Error while interacting with dropdown: " + e.getMessage());
                        }
                    }
                } catch (Exception ex) {
                    System.err.println("Error while interacting with dropdown: " + ex.getMessage());
                    TestRunner.getTest().log(Status.WARNING, "Error while interacting with dropdown: " + ex.getMessage());
                }
            }
        } else {
            System.out.println("Unknown question source.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Unknown question source.");
            return;
        }

        Thread.sleep(2000);
        helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
    }

//    public void QuestionInlineChoiceSelectInteractionInAccurate() throws InterruptedException {
//        System.out.println("I'm in Select Inaccurate Inline Choice Select Interaction question");
//
//        WebElement ItemAnswerContainer = driver.findElement(By.xpath("//div[contains(@class, 'testItemAnswersContainer')]"));
//        List<WebElement> answersDropdowns = ItemAnswerContainer.findElements(By.xpath(".//div[contains(@class, 'correct-container')]"));
//        System.out.println("Total options dropdown:" + answersDropdowns.size());
//
//        if (answersDropdowns.isEmpty()) {
//            System.out.println("No answer dropdowns found.");
//            return;
//        }
//
//        String correctQuestionResponse = getAPIHandler.getCorrectAnswerSource(questionID).toString();
//        System.out.println("Question Source: " + correctQuestionResponse);
//
//        List<String> correctKeys;
//        if (correctQuestionResponse.equals("[C2C]")) {
//            correctKeys = getAPIHandler.getCorrectAnswerResponseGapIdentifier(questionID);
//        } else if (correctQuestionResponse.equals("[learnosity]")) {
//            correctKeys = getAPIHandler.getCorrectAnswerResponseIdentifier(questionID);
//        } else {
//            System.out.println("Unknown question source.");
//            return;
//        }
//        Set<String> correctKeysSet = new HashSet<>(correctKeys);
//        System.out.println("Correct Keys: " + correctKeysSet);
//
//        for (WebElement dropdown : answersDropdowns) {
//            dropdown.click();
//            wait.until(ExpectedConditions.visibilityOfElementLocated(By.tagName("option")));
//            List<WebElement> options = dropdown.findElements(By.tagName("option"));
//            for (WebElement option : options) {
//                String id = option.getAttribute("value");
//                String optionText = option.getText();
//                if (!correctKeysSet.contains(id) && !optionText.equals("choose")) {
//                    option.click();
//                    System.out.println("Clicked correct option with ID: " + id);
//                    Thread.sleep(500);
//                    break;
//                }
//            }
//        }
//
//        Thread.sleep(2000);
//        helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
//
//    }

    public void QuestionInlineChoiceSpellingInteractionInAccurate() throws InterruptedException {
        TestRunner.startTest("Question: Inline Choice Spelling Interaction Attempt with Incorrect Answer");
        System.out.println("I'm in Enter In-accurate Inline Choice Spelling Interaction");
        try {
            WebElement QuestionPlayer = driver.findElement(By.xpath("//div[contains(@class, 'QuestionPlayer')]"));
            //SI = Spelling Interactions
            WebElement ItemQuestionContainerSI = QuestionPlayer.findElement(By.xpath("//div[contains(@class, 'questionTextContainer')]"));
            String questionText = ItemQuestionContainerSI.getText();
            System.out.println("Question Text: " + questionText);
            TestRunner.getTest().log(Status.INFO, "Question Text: " + questionText);

            WebElement ItemAnswerContainerSI = QuestionPlayer.findElement(By.xpath("//div[contains(@class, 'testItemAnswersContainer')]"));
            List<WebElement> AnswersInputsSI = ItemAnswerContainerSI.findElements(By.tagName("input"));

            int numberOfInputs = AnswersInputsSI.size();
            System.out.println("Number of inputs: " + numberOfInputs);
            TestRunner.getTest().log(Status.INFO, "Number of inputs: " + numberOfInputs);

            List<String> correctTextResponse = getAPIHandler.getCorrectAnswerResponseForSpellingInteraction(questionID);
            System.out.println("Correct Text Response of Question: ");
            for (String textResponse : correctTextResponse) {
                System.out.println(textResponse);
                TestRunner.getTest().log(Status.INFO, "Correct Text: " + textResponse);
            }
            shuffle(correctTextResponse);
            for (int i = 0; i < Math.min(correctTextResponse.size(), numberOfInputs); i++) {
                WebElement inputSI = AnswersInputsSI.get(i);
                JavascriptExecutor js = (JavascriptExecutor) driver;
                js.executeScript("arguments[0].value='';", inputSI);
                String wordToType = correctTextResponse.get(i);
                // Type the word into the input field
                inputSI.sendKeys(wordToType);
                System.out.println("Shuffled Input: " + wordToType);
                TestRunner.getTest().log(Status.PASS, "Test Case Passed : Correct text entered successfully" + wordToType);
            }
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
            TestRunner.getTest().log(Status.FAIL, "Exception is found    :   Question text is not visible");
        }
        Thread.sleep(2000);
        helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
    }

    private void shuffle(List<String> list) {
        Random random = new Random();
        for (int i = list.size() - 1; i > 0; i--) {
            int j = random.nextInt(i + 1);
            Collections.swap(list, i, j);
        }
    }



    public void QuestionMatchDragdropInteractionInAccurate(WebElement qs) throws InterruptedException {
        TestRunner.startTest("Question: Match Dragdrop Interaction Attempt with Incorrect Answer");
        System.out.println("I'm in Match Dragdrop Interaction question InAccurate");
        Thread.sleep(1000);
        try {
            WebElement QuestionContainer = qs.findElement(By.xpath(".//div[contains(@class,'column-options-container')]"));
            List<WebElement> values_Drag = QuestionContainer.findElements(By.xpath(".//div[contains(@class, 'task-container task-container-draging-off')]"));
            System.out.println("values_Drag: " + values_Drag.size());
            TestRunner.getTest().log(Status.INFO, "values_Drag: " + values_Drag.size());

            WebElement AnswerContainer = QuestionContainer.findElement(By.xpath("//div[contains(@class,'column-answers-container')]"));
            List<WebElement> values_Drop = AnswerContainer.findElements(By.xpath(".//div[contains(@class, 'column-tasks-container')]"));
            System.out.println("values_Drop: " + values_Drop.size());
            TestRunner.getTest().log(Status.INFO, "values_Drop: " + values_Drop.size());

            if (!values_Drag.isEmpty() && !values_Drop.isEmpty()) {
                for (WebElement valueDrag : values_Drag) {
                    String dragableid = valueDrag.getAttribute("data-rbd-draggable-id");
                    System.out.println("Drag able drag ID for Matching: " + dragableid);
                    System.out.println("Drag able choice text is: " + valueDrag.getText());
                }
                for (WebElement valueDrop : values_Drop) {
                    String dropableid = valueDrop.getAttribute("data-rbd-droppable-id");
                    System.out.println("Drop able drop ID for Matching: " + dropableid);
                }
                String correctQuestionResponse = getAPIHandler.getCorrectAnswerSource(questionID).toString();
                System.out.println("Question Source: ");
                System.out.println(correctQuestionResponse);
                TestRunner.getTest().log(Status.INFO, "Question Source: " + correctQuestionResponse);

                if (correctQuestionResponse.equals("[C2C]")) {
                    // Get the correct keys from the API for [C2C]
                    List<Map<String, String>> correctKeys = getAPIHandler.getCorrectAnswerResponseChoiceAndGapIdentifier(questionID);
                    System.out.println("Correct Identifiers of Question (C2C): ");
                    for (Map<String, String> key : correctKeys) {
                        System.out.println("Choice Identifier: " + key.get("choiceIdentifier") + ", Gap Identifier: " + key.get("gapIdentifier"));
                        TestRunner.getTest().log(Status.INFO, "Choice Identifier: " + key.get("choiceIdentifier") + ", Gap Identifier: " + key.get("gapIdentifier"));
                    }
                    try {
                        for (WebElement valueDrag : values_Drag) {
                            String dragableid = valueDrag.getAttribute("data-rbd-draggable-id");
                            System.out.println("Drag able drag ID for Matching: " + dragableid);
                            System.out.println("Drag able choice text is: " + valueDrag.getText());
                            for (WebElement valueDrop : values_Drop) {
                                String dropableid = valueDrop.getAttribute("data-rbd-droppable-id");
                                boolean isIncorrect = true;
                                for (Map<String, String> key : correctKeys) {
                                    if (key.get("choiceIdentifier").equals(dropableid) && key.get("gapIdentifier").equals(dragableid)) {
                                        isIncorrect = false;
                                        break;
                                    }
                                }
                                if (isIncorrect) {
                                    System.out.println("Attempting drag and drop for incorrect combination:");
                                    System.out.println("Drag ID: " + dragableid + ", Drop ID: " + dropableid);
                                    TestRunner.getTest().log(Status.INFO, "Performing drag and drop: Drag ID: " + dragableid + ", Drop ID: " + dropableid);
                                    Actions action = new Actions(driver);
                                    try {
                                        action.clickAndHold(valueDrag).perform();
                                        int steps = 8;
                                        int stepX = (valueDrop.getLocation().getX() - valueDrag.getLocation().getX()) / steps;
                                        int stepY = (valueDrop.getLocation().getY() - valueDrag.getLocation().getY()) / steps;
                                        for (int i = 1; i <= steps; i++) {
                                            action.moveByOffset(stepX, stepY).perform();
                                            Thread.sleep(300);
                                        }
                                        action.moveToElement(valueDrop).release().perform();
                                        System.out.println("Source Location: " + valueDrag.getLocation());
                                        System.out.println("Destination Location: " + valueDrop.getLocation());
                                    } catch (Exception e) {
                                        System.out.println(e);
                                        TestRunner.getTest().log(Status.WARNING, "Error during drag and drop: " + e.getMessage());
                                    }
                                }
                                TestRunner.getTest().log(Status.PASS, "Test case Passed    :   Question attempted successfully");
                            }
                        }
                    } catch (Exception e) {
                        System.out.println(e);
                        System.out.println("Error during drag and drop: " + e.getMessage());
                        TestRunner.getTest().log(Status.FAIL, "Error during drag and drop: " + e.getMessage());
                    }
                }
                if (correctQuestionResponse.equals("[learnosity]")) {
                    // Get the correct keys from the API for [learnosity]
                    List<Map<String, String>> correctKeys = getAPIHandler.getCorrectAnswerResponseChoiceAndGapIdentifier(questionID);
                    System.out.println("Correct Identifiers of Question (learnosity): ");
                    for (Map<String, String> key : correctKeys) {
                        System.out.println("Choice Identifier: " + key.get("choiceIdentifier") + ", Gap Identifier: " + key.get("gapIdentifier"));
                        TestRunner.getTest().log(Status.INFO, "Choice Identifier: " + key.get("choiceIdentifier") + ", Gap Identifier: " + key.get("gapIdentifier"));
                    }
                    try {

                        for (WebElement valueDrag : values_Drag) {
                            String dragableid = valueDrag.getAttribute("data-rbd-draggable-id").substring("choice-".length());
                            System.out.println("Drag able drag ID for Matching: " + dragableid);
                            System.out.println("Drag able choice text is: " + valueDrag.getText());
                            try {
                                for (WebElement valueDrop : values_Drop) {
                                    String dropableid = valueDrop.getAttribute("data-rbd-droppable-id");
                                    boolean isIncorrect = true;
                                    for (Map<String, String> key : correctKeys) {
                                        if (key.get("choiceIdentifier").equals(dragableid) && key.get("gapIdentifier").equals(dropableid)) {
                                            isIncorrect = false;
                                            break;
                                        }
                                    }
                                    if (isIncorrect) {
                                        System.out.println("Attempting drag and drop for incorrect combination:");
                                        System.out.println("Drag ID: " + dragableid + ", Drop ID: " + dropableid);
                                        TestRunner.getTest().log(Status.INFO, "Drag ID: " + dragableid + ", Drop ID: " + dropableid);
                                        Actions action = new Actions(driver);
                                        try {
                                            action.clickAndHold(valueDrag).perform();
                                            int steps = 8;
                                            int stepX = (valueDrop.getLocation().getX() - valueDrag.getLocation().getX()) / steps;
                                            int stepY = (valueDrop.getLocation().getY() - valueDrag.getLocation().getY()) / steps;
                                            for (int i = 1; i <= steps; i++) {
                                                action.moveByOffset(stepX, stepY).perform();
                                                Thread.sleep(300);
                                            }
                                            action.moveToElement(valueDrop).release().perform();
                                            System.out.println("Source Location: " + valueDrag.getLocation());
                                            System.out.println("Destination Location: " + valueDrop.getLocation());
                                        } catch (Exception e) {
                                            System.out.println(e);
                                            TestRunner.getTest().log(Status.WARNING, "Error during drag and drop: " + e.getMessage());
                                        }
                                    }
                                    TestRunner.getTest().log(Status.PASS, "Test case Passed    :   Question attempted successfully");
                                }
                            } catch (Exception e) {
                                System.out.println(e);
                                TestRunner.getTest().log(Status.WARNING, "Error during drag and drop: " + e.getMessage());
                            }
                        }
                    } catch (Exception e) {
                        System.out.println(e);
                        TestRunner.getTest().log(Status.FAIL, "Error during drag and drop: " + e.getMessage());
                    }
                } else {
                    TestRunner.getTest().log(Status.FAIL, "Test case Failed    :   No options found");
                }
            }
        }catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed    :   Exception is found");
        }
        Thread.sleep(2000);
        helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
    }

    public void QuestionGapMatchInteractionInAccurate() throws InterruptedException {
        TestRunner.startTest("Question: Gap Match Interaction Attempt with Incorrect Answer");
        System.out.println("I'm in Gap Match Interaction question attempt with InAccurate");
        Thread.sleep(1000);
        try {
            WebElement QuestionComponentBody = driver.findElement(By.xpath("//div[@class = 'planComponentQuestion']"));
            WebElement QuestionContainer = QuestionComponentBody.findElement(By.xpath(".//div[contains(@class,'column-options-container')]"));
            List<WebElement> values_Drag = QuestionContainer.findElements(By.xpath(".//div[contains(@class, 'task-container task-container-draging-off')]"));
            System.out.println("values_Drag: " + values_Drag.size());

            WebElement AnswerContainer = QuestionComponentBody.findElement(By.xpath(".//div[contains(@class,'column-answers-container')]"));
            List<WebElement> values_Drop = AnswerContainer.findElements(By.xpath(".//div[contains(@class, 'column-tasks-container')]"));
            System.out.println("values_Drop: " + values_Drop.size());

            TestRunner.getTest().log(Status.INFO, "values_Drag: " + values_Drag.size() + ", values_Drop: " + values_Drop.size());

            if (!values_Drag.isEmpty() && !values_Drop.isEmpty()) {
                for (WebElement valueDrag : values_Drag) {
                    String dragableid = valueDrag.getAttribute("data-rbd-draggable-id");
                    System.out.println("Drag able drag ID for Matching: " + dragableid);
                    System.out.println("Drag able choice text is: " + valueDrag.getText());
                }
                for (WebElement valueDrop : values_Drop) {
                    String dropableid = valueDrop.getAttribute("data-rbd-droppable-id");
                    System.out.println("Drop able drop ID for Matching: " + dropableid);
                }
                String correctQuestionResponse = getAPIHandler.getCorrectAnswerSource(questionID).toString();
                System.out.println("Question Source: ");
                System.out.println(correctQuestionResponse);
                if (correctQuestionResponse.equals("[C2C]")) {
                    // Get the correct keys from the API
                    List<Map<String, String>> correctKeys = getAPIHandler.getCorrectAnswerResponseChoiceAndGapIdentifier(questionID);
                    System.out.println("Correct Identifiers of Question: ");
                    for (Map<String, String> key : correctKeys) {
                        System.out.println("Choice Identifier: " + key.get("choiceIdentifier") + ", Gap Identifier: " + key.get("gapIdentifier"));
                    }

                    for (WebElement valueDrag : values_Drag) {

                        String dragableid = valueDrag.getAttribute("data-rbd-draggable-id");
                        System.out.println("Drag able drag ID for Matching: " + dragableid);
                        System.out.println("Drag able choice text is: " + valueDrag.getText());

                        for (WebElement valueDrop : values_Drop) {

                            String dropableid = valueDrop.getAttribute("data-rbd-droppable-id");

                            boolean isIncorrect = true;

                            for (Map<String, String> key : correctKeys) {

                                if (key.get("choiceIdentifier").equals(dropableid) && key.get("gapIdentifier").equals(dragableid)) {
                                    isIncorrect = false;
                                    break;
                                }
                            }
                            if (isIncorrect) {
                                System.out.println("Attempting drag and drop for incorrect combination:");
                                System.out.println("Drag ID: " + dragableid + ", Drop ID: " + dropableid);
                                TestRunner.getTest().log(Status.INFO, "Drag ID: " + dragableid + ", Drop ID: " + dropableid);

                                Actions action = new Actions(driver);
                                try {
                                    action.clickAndHold(valueDrag).perform();
                                    Thread.sleep(1000);

                                    int steps = 20;
                                    int stepX = (valueDrop.getLocation().getX() - valueDrag.getLocation().getX()) / steps;
                                    int stepY = (valueDrop.getLocation().getY() - valueDrag.getLocation().getY()) / steps;

                                    for (int i = 1; i <= steps; i++) {

                                        action.moveByOffset(stepX, stepY).perform();
                                        Thread.sleep(200);
                                    }

                                    action.moveToElement(valueDrop).release().perform();
                                    Thread.sleep(200);

                                    System.out.println("Source Location: " + valueDrag.getLocation());
                                    System.out.println("Destination Location: " + valueDrop.getLocation());
                                } catch (Exception e) {
                                    System.out.println(e);
                                    TestRunner.getTest().log(Status.WARNING, "Error during drag and drop: " + e.getMessage());
                                }
                            }
                        }
                        TestRunner.getTest().log(Status.PASS, "Test case Passed    :   Question attempted successfully");
                    }
                }
                if (correctQuestionResponse.equals("[learnosity]")) {

                    System.out.println("Question type is: " + correctQuestionResponse);
                    // Get the correct keys from the API
                    List<Map<String, String>> correctKeys = getAPIHandler.getCorrectAnswerResponseChoiceAndGapIdentifier(questionID);
                    System.out.println("Correct Identifiers of Question: ");
                    for (Map<String, String> key : correctKeys) {
                        System.out.println("Choice Identifier: " + key.get("choiceIdentifier") + ", Gap Identifier: " + key.get("gapIdentifier"));
                    }

                    for (WebElement valueDrag : values_Drag) {

                        String dragableid = valueDrag.getAttribute("data-rbd-draggable-id").substring("choice-".length());
                        System.out.println("Drag able drag ID for Matching: " + dragableid);
                        System.out.println("Drag able choice text is: " + valueDrag.getText());

                        for (WebElement valueDrop : values_Drop) {

                            String dropableid = valueDrop.getAttribute("data-rbd-droppable-id");
                            boolean isIncorrect = true;

                            for (Map<String, String> key : correctKeys) {
                                if (key.get("choiceIdentifier").equals(dragableid) && key.get("gapIdentifier").equals(dropableid)) {
                                    isIncorrect = false;
                                    break;
                                }
                            }
                            if (isIncorrect) {
                                System.out.println("Performing drag and drop:");
                                System.out.println("Drag ID: " + dragableid + ", Drop ID: " + dropableid);
                                TestRunner.getTest().log(Status.INFO, "Drag ID: " + dragableid + ", Drop ID: " + dropableid);

                                Actions action = new Actions(driver);
                                try {
                                    action.clickAndHold(valueDrag).perform();
                                    Thread.sleep(1000);

                                    int steps = 20;
                                    int stepX = (valueDrop.getLocation().getX() - valueDrag.getLocation().getX()) / steps;
                                    int stepY = (valueDrop.getLocation().getY() - valueDrag.getLocation().getY()) / steps;

                                    for (int i = 1; i <= steps; i++) {
                                        action.moveByOffset(stepX, stepY).build().perform();
                                        Thread.sleep(200);
                                    }

                                    action.moveToElement(valueDrop).release().perform();
                                    System.out.println("Source Location: " + valueDrag.getLocation());
                                    System.out.println("Destination Location: " + valueDrop.getLocation());
                                } catch (Exception e) {
                                    System.out.println(e);
                                    TestRunner.getTest().log(Status.WARNING, "Error during drag and drop: " + e.getMessage());
                                }
                            }
                        }
                        TestRunner.getTest().log(Status.PASS, "Test case Passed    :   Question attempted successfully");
                    }
                } else {
                    TestRunner.getTest().log(Status.FAIL, "Test case Failed : No options found");
                }
            }
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Exception is found");
        }
        Thread.sleep(2000);
        helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
    }


    public void QuestionGraphicGapMatchInteractionInAccurate() throws InterruptedException {
        TestRunner.startTest("Question: Graphic Gap Match Interaction Attempt with Incorrect Answer");
        System.out.println("I'm in Graphic Gap Match Interaction question InAccurate");
        Thread.sleep(1000);

        try {
            WebElement QuestionComponentBody = driver.findElement(By.xpath("//div[@class = 'planComponentQuestion']"));

            WebElement QuestionContainer = QuestionComponentBody.findElement(By.xpath(".//div[contains(@class, 'column-options-container')]"));
            List<WebElement> values_Drag = QuestionContainer.findElements(By.xpath(".//div[contains(@class, 'task-container task-container-draging-off')]"));
            System.out.println("values_Drag: " + values_Drag.size());

            WebElement AnswerContainer = QuestionComponentBody.findElement(By.xpath(".//div[contains(@class, 'column-answers-container')]"));
            List<WebElement> values_Drop = AnswerContainer.findElements(By.xpath(".//div[contains(@class, 'column-tasks-container')]"));
            System.out.println("values_Drop: " + values_Drop.size());

            TestRunner.getTest().log(Status.INFO, "values_Drag: " + values_Drag.size() + ", values_Drop: " + values_Drop.size());

            String correctQuestionResponse = null;
            if (!values_Drag.isEmpty() && !values_Drop.isEmpty()) {
                for (WebElement valueDrag : values_Drag) {
                    String dragableid = valueDrag.getAttribute("data-rbd-draggable-id");
                    System.out.println("Draggable drag ID for Matching: " + dragableid);
                    System.out.println("Draggable choice text is: " + valueDrag.getText());
                }

                for (WebElement valueDrop : values_Drop) {
                    String dropableid = valueDrop.getAttribute("data-rbd-droppable-id");
                    System.out.println("Droppable drop ID for Matching: " + dropableid);
                }

                correctQuestionResponse = getAPIHandler.getCorrectAnswerSource(questionID).toString();
                System.out.println("Question Source: ");
                System.out.println(correctQuestionResponse);
                TestRunner.getTest().log(Status.INFO, "Question Source: " + correctQuestionResponse);

                if (correctQuestionResponse.equals("[C2C]")) {
                    // Get the correct keys from the API
                    List<Map<String, String>> correctKeys = getAPIHandler.getCorrectAnswerResponseChoiceAndGapIdentifier(questionID);
                    System.out.println("Correct Identifiers of Question: ");
                    for (Map<String, String> key : correctKeys) {
                        System.out.println("Choice Identifier: " + key.get("choiceIdentifier") + ", Gap Identifier: " + key.get("gapIdentifier"));
                    }

                    Set<String> usedDropIds = new HashSet<>();
                    for (WebElement valueDrag : values_Drag) {
                        String dragableid = valueDrag.getAttribute("data-rbd-draggable-id");
                        System.out.println("Draggable drag ID for Matching: " + dragableid);
                        System.out.println("Draggable choice text is: " + valueDrag.getText());

                        for (WebElement valueDrop : values_Drop) {
                            String dropableid = valueDrop.getAttribute("data-rbd-droppable-id");
                            boolean isIncorrect = true;
                            for (Map<String, String> key : correctKeys) {
                                if (key.get("choiceIdentifier").equals(dropableid) && key.get("gapIdentifier").equals(dragableid)) {
                                    isIncorrect = false;
                                    break;
                                }
                            }

                            if (isIncorrect && !usedDropIds.contains(dropableid)) {
                                System.out.println("Performing drag and drop:");
                                System.out.println("Drag ID: " + dragableid + ", Drop ID: " + dropableid);
                                TestRunner.getTest().log(Status.INFO, "Drag ID: " + dragableid + ", Drop ID: " + dropableid);

                                Actions action = new Actions(driver);
                                try {
                                    action.clickAndHold(valueDrag).perform();
                                    Thread.sleep(3000);

                                    // Gradually move towards the destination
                                    int steps = 20;
                                    int stepX = (valueDrop.getLocation().getX() - valueDrag.getLocation().getX()) / steps;
                                    int stepY = (valueDrop.getLocation().getY() - valueDrag.getLocation().getY()) / steps;

                                    for (int i = 1; i <= steps; i++) {
                                        action.moveByOffset(stepX, stepY).perform();
                                        Thread.sleep(200);
                                    }

                                    // Finish by moving directly on the element
                                    action.moveToElement(valueDrop).release().perform();
                                    System.out.println("Source Location: " + valueDrag.getLocation());
                                    System.out.println("Destination Location: " + valueDrop.getLocation());
                                    TestRunner.getTest().log(Status.PASS, "Test Case Passed : Drag and Drop performed successfully");
                                } catch (Exception e) {
                                    System.out.println(e);
                                    TestRunner.getTest().log(Status.WARNING, "Drag and Drop performed: " + e.getMessage());
                                }

                                usedDropIds.add(dropableid);
                                break;
                            }
                        }
                    }
                    TestRunner.getTest().log(Status.PASS, "Test case Passed    :   Question attempted successfully");

                } else if (correctQuestionResponse.equals("[learnosity]")) {
                    System.out.println("Question type is: " + correctQuestionResponse);
                    // Get the incorrect keys from the API
                    List<Map<String, String>> correctKeys = getAPIHandler.getCorrectAnswerResponseChoiceAndGapIdentifier(questionID);
                    System.out.println("Correct Identifiers of Question: ");
                    for (Map<String, String> key : correctKeys) {
                        System.out.println("Choice Identifier: " + key.get("choiceIdentifier") + ", Gap Identifier: " + key.get("gapIdentifier"));
                    }

                    Set<String> usedDropIds = new HashSet<>();
                    for (WebElement valueDrag : values_Drag) {
                        String dragableid = valueDrag.getAttribute("data-rbd-draggable-id").substring("choice-".length());
                        System.out.println("Draggable drag ID for Matching: " + dragableid);
                        System.out.println("Draggable choice text is: " + valueDrag.getText());

                        for (WebElement valueDrop : values_Drop) {
                            String dropableid = valueDrop.getAttribute("data-rbd-droppable-id");
                            boolean isIncorrect = true;
                            for (Map<String, String> key : correctKeys) {
                                if (key.get("choiceIdentifier").equals(dragableid) && key.get("gapIdentifier").equals(dropableid)) {
                                    isIncorrect = false;
                                    break;
                                }
                            }

                            if (isIncorrect && !usedDropIds.contains(dropableid)) {
                                System.out.println("Performing drag and drop:");
                                System.out.println("Drag ID: " + dragableid + ", Drop ID: " + dropableid);
                                TestRunner.getTest().log(Status.INFO, "Drag ID: " + dragableid + ", Drop ID: " + dropableid);

                                Actions action = new Actions(driver);

                                try {
                                    action.clickAndHold(valueDrag).perform();

                                    // Gradually move towards the destination
                                    int steps = 20;
                                    int stepX = (valueDrop.getLocation().getX() - valueDrag.getLocation().getX()) / steps;
                                    int stepY = (valueDrop.getLocation().getY() - valueDrag.getLocation().getY()) / steps;

                                    for (int i = 1; i <= steps; i++) {
                                        action.moveByOffset(stepX, stepY).build().perform();
                                        Thread.sleep(200);
                                    }

                                    action.moveToElement(valueDrop).release().perform();
                                    System.out.println("Source Location: " + valueDrag.getLocation());
                                    System.out.println("Destination Location: " + valueDrop.getLocation());
                                    TestRunner.getTest().log(Status.PASS, "Test Case Passed : Drag and Drop performed successfully");
                                } catch (Exception e) {
                                    System.out.println(e);
                                    TestRunner.getTest().log(Status.WARNING, "Drag and Drop performed: " + e.getMessage());
                                }

                                usedDropIds.add(dropableid);
                                break;
                            }
                        }
                    }
                    TestRunner.getTest().log(Status.PASS, "Test case Passed    :   Question attempted successfully");
                } else {
                    TestRunner.getTest().log(Status.FAIL, "Test case Failed : No options found");
                }
            }
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed : Exception is found");
        }

        Thread.sleep(2000);
        helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
    }


}
