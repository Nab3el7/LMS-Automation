package pageFactory.Assignmment;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.*;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.Wait;
import pageFactory.Gradebook.AssignmentVerification_PF;
import pageFactory.MyContent.AssignAssessment_PF;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.openqa.selenium.ElementNotInteractableException;

import static pageFactory.Assignmment.CorrectAnswerExecutor_PF.assignmentNameForCorrect;
import static pageFactory.MyContent.Resources.ResourceTypeURL_PF.SelectedResourceType;

public class AssignmentModuleAssignNew_PF {
    WebDriverWait wait;
    WebDriver driver;
    Helper helper;
    JavascriptExecutor js;
    AssignAssessment_PF assignAssessment;
    CorrectAnswerExecutor_PF correctAnswerExecutor;
    AssignmentVerification_PF assignmentVerificationPf;
    Actions actions;

    public AssignmentModuleAssignNew_PF(WebDriver driver) {
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        helper = new Helper();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        js = (JavascriptExecutor) driver;
        assignAssessment = new AssignAssessment_PF(driver);
        correctAnswerExecutor = new CorrectAnswerExecutor_PF(driver);
        assignmentVerificationPf = new AssignmentVerification_PF(driver);
        actions = new Actions(driver);
    }

    public static final String BASE_NAME = Configurations.getDotEnv().get("SITE_ASSIGNMENT_NAME_FOR_Assignment_Module");
    public static final String AssignmentName;

    static {
        Random random = new Random();
        StringBuilder sb = new StringBuilder(6);
        String charSet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

        for (int i = 0; i < 6; i++) {
            int randomIndex = random.nextInt(charSet.length());
            sb.append(charSet.charAt(randomIndex));
        }

        String randomString = sb.toString();
        AssignmentName = BASE_NAME + " " + randomString;
    }

    public static String Assignment_Title;

    @FindBy(xpath = "//input[@name='title']")
    WebElement edt_AssignmentTitle;

    @FindBy(xpath = "//div[@aria-label='Assignments Module']")
    WebElement link_Assignments_Module;

    @FindBy(xpath = "//a[normalize-space()='Assign New']")
    WebElement btn_AssignNew;

    @FindBy(xpath = "//div[contains(@class, 'flex justify-end')]")
    WebElement end_page;

    @FindBy(xpath = "(//h2[contains(@class, 'MuiDialogTitle-root')])")
    WebElement alert_success;

    @FindBy(xpath = "//div[@aria-labelledby='customized-dialog-title']")
    WebElement customizedDialogTitle;

    @FindBy(xpath = "//*[contains(@class, 'assignBtn') and normalize-space()='Assign New']")
    WebElement buttonAssignNew;


    @FindBy(xpath = "//div[@class='rrt-middle-container']")
    WebElement toastContainer;

    public void SideNavBarAndClickOnAssignmentsModule() throws InterruptedException {
        System.out.println("I'm in checking the side navbar");
        TestRunner.getTest().log(Status.INFO, "I'm in checking the side navbar");

        Thread.sleep(1000);

        WebElement navBar = driver.findElement(By.xpath("//div[@class='navigation']"));

        List<WebElement> totalLinks = navBar.findElements(By.tagName("a"));

        for (WebElement link : totalLinks) {
            String hrefValue = link.getAttribute("href");
            System.out.println("Link is: " + hrefValue);
        }

        if (link_Assignments_Module.isDisplayed()) {
            link_Assignments_Module.click();
            TestRunner.getTest().log(Status.PASS, "Testcase Passed   :  Side Navbar Shows and Clicked on Assignments Module Successfully");
        } else {
            TestRunner.getTest().log(Status.FAIL, "Testcase Failed   :  Side navbar and not shows and not clicked on Assignment Module");
        }

    }

    public void VerifyAssignmentModuleDashboard() throws InterruptedException {
        System.out.println("I'm in Assignments Module dashboard");
        TestRunner.getTest().log(Status.INFO, "I'm in Assignments Module dashboard");
        Thread.sleep(1000);
        WebElement breadCrumb = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ol[contains(@class, 'MuiBreadcrumbs')]")));
        System.out.println("BreadCrumb is: " + breadCrumb.getText());

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class, 'cleasses-container')]")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class, 'grades-container')]")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class, 'selectTextFieldsWrapper')]")));

        TestRunner.getTest().log(Status.PASS, "Testcase Passed   :   Assignments Module dashboard all element visible");
    }

    public void ClickOnAssignNewButton() {
        wait.until(ExpectedConditions.elementToBeClickable(btn_AssignNew));
        btn_AssignNew.click();
        TestRunner.getTest().log(Status.PASS, "Testcase Passed   :  Assign New button Clicked Successfully");


    }

    public void SelectAssignmentStep() {
        List<WebElement> selectCheckBox = driver.findElements(By.xpath("//div[@class='tabelbodydata-Container']//table//tbody//td[contains(@class,'checkboxSelectionTableCell')]//input"));

        System.out.println("Total Checkboxes Are: " + selectCheckBox.size());

        for (WebElement checkbox : selectCheckBox) {
            js.executeScript("arguments[0].click();", checkbox);
            System.out.println("A visible checkbox has been selected.");
            TestRunner.getTest().log(Status.PASS, "Testcase Passed   :  Assignment Select Successfully");
            break;
        }
    }

    public void NextButton() throws InterruptedException {

        end_page.isDisplayed();
        helper.scrollToElement(driver, end_page);

        WebElement btn_Next = end_page.findElement(By.xpath("//button[normalize-space()='Next']"));
        Thread.sleep(1000);

        if (btn_Next.isDisplayed()) {
            btn_Next.click();
            TestRunner.getTest().log(Status.PASS, "Testcase Passed   :  Next button clicked successfully");
        } else {
            TestRunner.getTest().log(Status.FAIL, "Testcase Failed   : Next Button not Display or clickable ");

        }
    }

    public void AssignmentInfo() throws InterruptedException {
        correctAnswerExecutor.EnterAssignmentTitleForCorrectAnswers();
        correctAnswerExecutor.selectSpecificClasses();
        assignAssessment.setDateTimeAndCategory();
        assignAssessment.enterAdditionalSettings();
        assignAssessment.enterWeightPercentage();
        assignAssessment.assignAssignment();
        verifyDialogBox();
        TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  Specific Assignment Release from Assignment Module Successfully");

    }

    public void AssignmentInfoForGradeBookAssignment() throws InterruptedException {
        EnterAssignmentTitle();
        correctAnswerExecutor.selectSpecificClasses();
        assignAssessment.setDateTimeAndCategory();
        assignAssessment.enterAdditionalSettings();
        assignAssessment.enterWeightPercentage();
        assignAssessment.assignAssignment();
        verifyDialogBox();
        TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  Specific Assignment Release from Assignment Module Successfully");

    }

    public void EnterAssignmentTitle() throws InterruptedException {
        edt_AssignmentTitle.click();
        ((JavascriptExecutor) driver).executeScript("arguments[0].value='';", edt_AssignmentTitle);
        edt_AssignmentTitle.sendKeys(AssignmentName);
        System.out.println("Enter Assignment Title Successfully " + AssignmentName);
        TestRunner.getTest().log(Status.INFO, "Assignment Name is: " + AssignmentName);

    }

    public void verifyDialogBox() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOf(alert_success));
        WebElement popover = driver.findElement(By.xpath("(//h2[contains(@class, 'MuiDialogTitle-root')])"));
        String headerMessage = popover.getText();

        assert headerMessage.equals("Assignment Successful !") : "Assertion failed: Header message not as expected";
        WebElement closeButton = popover.findElement(By.xpath(".//button[@aria-label='close']"));
        closeButton.click();
    }

    public void selectSpecificClass() throws InterruptedException {
        assignmentVerificationPf.Select_Class();
    }

    public void ClickShowAllFilters() {
        WebElement showAllFilters = driver.findElement(By.xpath("//button[@aria-label='delete']"));

        if (showAllFilters.isDisplayed()) {
            // Scroll into view
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", showAllFilters);

            // Use JS click
            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", showAllFilters);

            TestRunner.getTest().log(Status.INFO, "Test Case Passed : Show All Filter Clicked Successfully");
            TestRunner.getTest().log(Status.PASS, "Testcase Passed : Show All Filter Clicked Successfully");

        } else {
            TestRunner.getTest().log(Status.FAIL, "Testcase Failed : Show All Filter is not Display.");
//        throw new RuntimeException("Show All Filter is not Display.");
        }
    }


    public void SelectAssignmentType() {
        List<WebElement> checkboxes = driver.findElements(By.xpath("//div[contains(@class,'scrollbarWrapper')]//ul//li//span//input"));

        for (int i = 0; i < checkboxes.size(); i++) {
            try {
                WebElement checkbox = checkboxes.get(i);
                if (!checkbox.isSelected()) {
                    checkbox.click();
                }
            } catch (StaleElementReferenceException e) {
                checkboxes = driver.findElements(By.xpath("//div[contains(@class,'scrollbarWrapper')]//ul//li//span//input"));
                WebElement checkbox = checkboxes.get(i);
                if (!checkbox.isSelected()) {
                    checkbox.click();
                }
            }
        }
    }

    public void SelectAssignmentTypeFilters() throws InterruptedException {
        String selectedAssignmentType = "Vocabulary Quiz";
        
        TestRunner.getTest().log(Status.INFO, "I'm in to select Assignment Type From Assignment Module");
        TestRunner.getTest().log(Status.INFO, " I'm in to select Assignment Type From Assignment Module: " + selectedAssignmentType);
        System.out.println("I'm in to select Assignment Type From Assignment Module: " + selectedAssignmentType);

        Thread.sleep(2000);
        // Locate the Assignment Type Filter list container
        WebElement assignmentTypeFilter = driver.findElement(By.xpath("//div[contains(@class,'FilterOptions')]//div[contains(@class, 'scrollbarWrapper')]//ul"));
        List<WebElement> totalTypes = assignmentTypeFilter.findElements(By.tagName("li"));

        System.out.println("Total types are: " + totalTypes.size());
        TestRunner.getTest().log(Status.INFO, "Total Assignment types are: " + totalTypes.size());

        boolean typeFound = false;

        for (WebElement typeElement : totalTypes) {
            // Get the text of the assignment type within the current `li` element
            String typeNameText = typeElement.findElement(By.xpath(".//span[contains(@class, 'MuiFormControlLabel-label')]//h6")).getText();
            System.out.println("Type name is: " + typeNameText);

            // Check if this is the desired assignment type to select
            if (typeNameText.equalsIgnoreCase(selectedAssignmentType)) {
                typeFound = true;
                WebElement checkBox = typeElement.findElement(By.xpath(".//input[@type='checkbox']"));

                boolean isChecked = checkBox.isSelected();

                if (isChecked) {
                    System.out.println("Checkbox for " + selectedAssignmentType + " is already selected.");
                    TestRunner.getTest().log(Status.INFO, "Checkbox for " + selectedAssignmentType + " is already selected.");
                } else {
                    checkBox.click();
                    System.out.println("Checkbox for " + selectedAssignmentType + " is now selected.");
                    TestRunner.getTest().log(Status.INFO, "Checkbox for " + selectedAssignmentType + " is now selected.");
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed: Assignment Type is selected successfully");
                }
                break;
            }
        }

        if (!typeFound) {
            TestRunner.getTest().log(Status.INFO, "No checkbox found for: " + selectedAssignmentType);
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: No Resources Type is found.");
        }


    }

    public void SearchAssignmentByName() {

        WebElement right_panel = driver.findElement(By.xpath("//div[@class='right-panel']"));
        right_panel.isDisplayed();

        try {
            WebElement searchBox = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder='Search by name or keyword']")));
            if (searchBox.isDisplayed()) {
                searchBox.click();
                searchBox.clear();
                ((JavascriptExecutor) driver).executeScript("arguments[0].value='';", searchBox);

                String assignmentNameForCorrect = CorrectAnswerExecutor_PF.assignmentNameForCorrect.get();
                System.out.println("Search by Assignment name: " + assignmentNameForCorrect);
                searchBox.sendKeys(assignmentNameForCorrect);

                TestRunner.getTest().log(Status.INFO, "Search Assignment is: " + assignmentNameForCorrect);

                Actions actions = new Actions(driver);
                actions.sendKeys(Keys.ENTER).perform();


                TestRunner.getTest().log(Status.PASS, "Testcase Passed   :   Enter Search Assignment keyword Successfully");

                waitForTableToRefresh();
            } else {
                System.out.println("Search box is not displayed.");
                TestRunner.getTest().log(Status.FAIL, "Testcase Failed   : Search box is not displayed.");
//                throw new RuntimeException("Search Box not  Found.");
            }
        } catch (Exception e) {
            System.out.println("Search box is not available: " + e.getMessage());
        }

    }

    private void waitForTableToRefresh() {

//        WebElement firstDiv = driver.findElement(By.xpath("//div[contains(@class, 'left-content-header')]/div[contains(@class, 'MuiBox-root')]/div[1]"));
//        System.out.println("TAssessment able has refreshed.");

        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class, 'left-content-header')]/div[contains(@class, 'MuiBox-root')]/div[1]")));

        System.out.println("Assessment Table has refreshed.");
        TestRunner.getTest().log(Status.PASS, "Testcase Passed : Assessment Table has refreshed");


    }

    public void verifyAssignments() {
        waitForTableToRefresh();
        List<WebElement> assignmentNameDivs = driver.findElements(By.xpath("//div[contains(@class, 'left-content-header')]/div[contains(@class, 'MuiBox-root')]/div[1]"));

        System.out.println("Total Assignments : " + assignmentNameDivs.size());

        if (!assignmentNameDivs.isEmpty()) {

            for (WebElement assignmentNameDiv : assignmentNameDivs) {
                Assignment_Title = assignmentNameDiv.getText();
                System.out.println("Assignment Name: " + Assignment_Title);
            }
            TestRunner.getTest().log(Status.PASS, "Testcase Passed : All Assessments Table shows");

        } else {
            System.out.println("No Assessment found in the table.");
            TestRunner.getTest().log(Status.FAIL, "Testcase Failed : No Assessment found in the table.");
//            throw new RuntimeException("No Assessments Found.");
        }
    }

    public void verifySearchedAssessmentByNameIntoTable() {
        String assignmentNameForCorrect = CorrectAnswerExecutor_PF.assignmentNameForCorrect.get();
        System.out.println("Want to search assignment into table: " + assignmentNameForCorrect);
        TestRunner.getTest().log(Status.INFO, "Want to search assignment into table: " + assignmentNameForCorrect);

        if (Assignment_Title.contains(assignmentNameForCorrect)) {
            System.out.println("Searched Assessment found" + Assignment_Title + " is match with " + assignmentNameForCorrect);
            TestRunner.getTest().log(Status.INFO, "Searched Assessment found" + Assignment_Title + " is match with " + assignmentNameForCorrect);
            TestRunner.getTest().log(Status.PASS, "Testcase Passed : Search Assessment by keyword Successfully");


        } else {
            System.out.println("Searched Assessment not found and search filter not working");
            TestRunner.getTest().log(Status.FAIL, "Testcase Failed : Searched Assessment not found and search filter not working");
//            throw new RuntimeException("No Assessment is found table .");
        }
    }

    public void clickOnEditAssignmentButton() {
        WebElement btnAssignmentEdit = driver.findElement(By.xpath("//span[contains(@class, 'EditIcon') and @role='button' or @role='combobox']"));
        TestRunner.getTest().log(Status.INFO, "Clicking on Edit Assignment button");
        if (btnAssignmentEdit.isDisplayed() && btnAssignmentEdit.isEnabled()) {
            btnAssignmentEdit.click();
            TestRunner.getTest().log(Status.PASS, "Testcase Passed : Edit button is found and clicked successfully");

        } else {
            TestRunner.getTest().log(Status.FAIL, "Testcase Failed : No Edit button is found in the table.");
//            throw new RuntimeException("Edit button is not displayed. ");
        }
    }

    public void clickDeleteButton() {
        WebElement deleteAssignmentBtn = driver.findElement(By.xpath("//span[@aria-label='delete assignment']"));

        if (deleteAssignmentBtn.isDisplayed() && deleteAssignmentBtn.isEnabled()) {
            deleteAssignmentBtn.click();
            TestRunner.getTest().log(Status.PASS, "Testcase Passed : Delete button is found and clicked successfully\"");

        } else {
            TestRunner.getTest().log(Status.FAIL, "Testcase Failed : No Delete button is  found in the table.");
//            throw new RuntimeException(" Delete button is not displayed. ");
        }

    }

    public void DeleteAssignmentPrompt() throws InterruptedException {

        Thread.sleep(500);

        WebElement promptDelete = wait.until(ExpectedConditions.elementToBeClickable(customizedDialogTitle));

        if (promptDelete.isDisplayed() && promptDelete.isEnabled()) {
            WebElement deletePromptText = promptDelete.findElement(By.xpath("//div[contains(@class,'DeleteAssignmentModel delete')]/div[4]"));
            System.out.println("Deleted Assessment is: " + deletePromptText.getText());

            WebElement btnDeleteYes = promptDelete.findElement(By.xpath("//button[normalize-space()='Yes']"));

            if (btnDeleteYes.isEnabled()) {
                btnDeleteYes.click();
                TestRunner.getTest().log(Status.PASS, "Testcase Passed : Assignment deleted successfully");

            } else {
                TestRunner.getTest().log(Status.FAIL, "Testcase Failed : Yes button not found.");
            }
        }
//        actions.sendKeys(Keys.ESCAPE).build().perform();

    }

    public void showsAssessmentIntoTable() throws InterruptedException {

        Thread.sleep(2000);
        try {
            WebElement assessmentTableContainer = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class='right-panel']")));

            if (assessmentTableContainer != null) {
                WebElement divAssessment = assessmentTableContainer.findElement(By.xpath("//p[normalize-space()='There are no assignments for the selected class.']"));
                String expectedSearchedAssessmentNotFount = divAssessment.getText();
                System.out.println(expectedSearchedAssessmentNotFount);

                if (expectedSearchedAssessmentNotFount.equalsIgnoreCase("There are no assignments for the selected class.")) {
                    TestRunner.getTest().log(Status.PASS, "Test case Passed :  Deleted Assessment not found successfully");
                }

            }
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println("Test Case Failed: An unexpected error occurred. " + e.getMessage());
        }
    }

    public void verifyToastMessage() {

        WebElement successMessageContainer = wait.until(ExpectedConditions.visibilityOf(toastContainer));
        if (successMessageContainer.isDisplayed()) {
            String messageTitle = successMessageContainer.findElement(By.className("rrt-title")).getText();
            String messageText = successMessageContainer.findElement(By.className("rrt-text")).getText();

            System.out.println("Message Title: " + messageTitle);
            System.out.println("Message Text: " + messageText);
            System.out.println("Test Case Passed : Toast Message Display successfully");

        } else {
            System.out.println("Success message is not displayed.");
        }
    }

    public void DataAccordingToAssignmentTypeFilter() throws InterruptedException {

        String assignment = "Vocabulary Quiz";
        TestRunner.getTest().log(Status.INFO, "I'm into verify data According to Assignment Type Filter");
        TestRunner.getTest().log(Status.INFO, "Assignment Type Filter we have assignment" + assignment + " in Table");

        System.out.println("Assignment Type Filter we have assignment" + assignment + " in Table");

        Thread.sleep(2000);
//        waitForTableToRefresh();
        List<WebElement> assignmentNameDivs = driver.findElements(By.xpath("//div[contains(@class, 'left-content-header')]/div[contains(@class, 'MuiBox-root')]//span//span"));
        System.out.println("Total Assignments : " + assignmentNameDivs.size());

        boolean containsFilter = false;

        if (!assignmentNameDivs.isEmpty()) {
            for (WebElement assignmentNameDiv : assignmentNameDivs) {
                Assignment_Title = assignmentNameDiv.getText();
                System.out.println("Assignment Name: " + Assignment_Title);
                TestRunner.getTest().log(Status.INFO, "Assignment Name: " + Assignment_Title);

                if (Assignment_Title.contains(assignment)) {
                    containsFilter = true;
                }
            }

            if (containsFilter) {
                TestRunner.getTest().log(Status.PASS, "Testcase Passed: All Assessments Table shows assignments containing " + assignment);
            } else {
                TestRunner.getTest().log(Status.FAIL, "Testcase Failed: No assignment contains" + assignment + " in the title.");
            }
        } else {
            System.out.println("No Assessment found in the table.");
            TestRunner.getTest().log(Status.FAIL, "Testcase Failed: No Assessment found in the table.");

        }

    }

    public void VerifyAllDSBIsPresentInTable(String assignmentDSB) throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into verify data According to Assignment Type Filter");
        TestRunner.getTest().log(Status.INFO, "Assignment Type Filter we have assignment" + assignmentDSB + " in Table");

        System.out.println("Assignment Type Filter we have assignment" + assignmentDSB + " in Table");

        Thread.sleep(2000);
//        waitForTableToRefresh();
        List<WebElement> assignmentNameDivs = driver.findElements(By.xpath("//div[contains(@class, 'left-content-header')]/div[contains(@class, 'MuiBox-root')]//span//span"));
        System.out.println("Total Assignments : " + assignmentNameDivs.size());

        boolean containsFilter = false;

        if (!assignmentNameDivs.isEmpty()) {
            for (WebElement assignmentNameDiv : assignmentNameDivs) {
                Assignment_Title = assignmentNameDiv.getText();
                System.out.println("Assignment Name: " + Assignment_Title);
                TestRunner.getTest().log(Status.INFO, "Assignment Name: " + Assignment_Title);

                if (Assignment_Title.contains("Student Book")) {
                    containsFilter = true;
                }
            }

            if (containsFilter) {
                TestRunner.getTest().log(Status.PASS, "Testcase Passed: All Assessments Table shows assignments containing " + assignmentDSB);
            } else {
                TestRunner.getTest().log(Status.FAIL, "Testcase Failed: No assignment contains " + assignmentDSB + "  in the title.");
            }
        } else {
            System.out.println("No Assessment found in the table.");
            TestRunner.getTest().log(Status.FAIL, "Testcase Failed: No Assessment found in the table.");

        }
    }

    public void VerifyAllCustomTypeAssessmentIsPresentInTable(String customAssessment) throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into verify data According to Assignment Type Filter");
        TestRunner.getTest().log(Status.INFO, "Assignment Type Filter we have assignment" + customAssessment + " in Table");

        System.out.println("Assignment Type Filter we have assignment" + customAssessment + " in Table");

        Thread.sleep(2000);
//        waitForTableToRefresh();
        List<WebElement> assignmentNameDivs = driver.findElements(By.xpath("//div[contains(@class, 'left-content-header')]/div[contains(@class, 'MuiBox-root')]//span//span"));
        System.out.println("Total Assignments : " + assignmentNameDivs.size());

        boolean containsFilter = false;

        if (!assignmentNameDivs.isEmpty()) {
            for (WebElement assignmentNameDiv : assignmentNameDivs) {
                Thread.sleep(2000);
                Assignment_Title = assignmentNameDiv.getText();
                System.out.println("Assignment Name: " + Assignment_Title);
                TestRunner.getTest().log(Status.INFO, "Assignment Name: " + Assignment_Title);

                if (Assignment_Title.contains("CustomAssignment")) {
                    containsFilter = true;
                }
            }

            if (containsFilter) {
                TestRunner.getTest().log(Status.PASS, "Testcase Passed: All Assessments Table shows assignments containing " + customAssessment);
            } else {
                TestRunner.getTest().log(Status.FAIL, "Testcase Failed: No assignment contains " + customAssessment + "  in the title.");
            }
        } else {
            System.out.println("No Assessment found in the table.");
            TestRunner.getTest().log(Status.FAIL, "Testcase Failed: No Assessment found in the table.");

        }
    }

    public void filtersAssignmentsByStatus() throws InterruptedException {
        String[] statusArray = {"Not Started", "Started", "Needs Grading", "Completed", "Future"};

        for (String status : statusArray) {
            TestRunner.getTest().log(Status.INFO, "Filtering Assignments By Status: " + status);

            try {
                WebElement statusDropdown = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(@class, 'MuiSelect-select') and @role='button' or @role='combobox'])[2]")));
                statusDropdown.click();

                List<WebElement> statusOptions = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//ul[@role='listbox']//li")));
                boolean statusFound = false;

                for (WebElement option : statusOptions) {
                    String optionText = option.getText().trim();
                    if (optionText.equalsIgnoreCase(status)) {
                        option.click();
                        statusFound = true;
                        TestRunner.getTest().log(Status.INFO, "Selected Status: " + optionText);
                        break;
                    }
                }

                if (!statusFound) {
                    TestRunner.getTest().log(Status.FAIL, "Status not found in the dropdown: " + status);
//                    throw new RuntimeException("Status not found in the dropdown: " + status);
                }

                Thread.sleep(2000);
                waitForTableToRefreshForAssignments(status);

            } catch (NoSuchElementException | ElementNotInteractableException e) {
                TestRunner.getTest().log(Status.WARNING, "Table not loaded within the expected time frame.");
            }
        }
    }


    private void waitForTableToRefreshForAssignments(String status) throws InterruptedException {
        Thread.sleep(3000);
        List<WebElement> assignmentNameDivs = driver.findElements(By.xpath("//div[contains(@class, 'left-content-header')]/div[contains(@class, 'MuiBox-root')]/div[1]"));
        System.out.println("Total Assignments with Status '" + status + "': " + assignmentNameDivs.size());
        TestRunner.getTest().log(Status.INFO, "Total Assignments with Status '" + status + "': " + assignmentNameDivs.size());

        if (!assignmentNameDivs.isEmpty()) {
            // If assignments are found, log their names
            for (WebElement assignmentNameDiv : assignmentNameDivs) {
                Assignment_Title = assignmentNameDiv.getText();
                System.out.println("Assignment Name: " + Assignment_Title);
                TestRunner.getTest().log(Status.INFO, "Assignment Name: " + Assignment_Title);
            }
            TestRunner.getTest().log(Status.PASS, "Testcase Passed: All Assessments Table shows assignments for Status: " + status);
        } else {
            // If no assignments are found, check for "End of List" message
            System.out.println("No Assessment found in the table for Status: " + status);
            TestRunner.getTest().log(Status.INFO, "No assignments found for Status: " + status);

            try {
                WebElement noDataFound = driver.findElement(By.xpath("//div[@class='right-panel']//p[normalize-space()='End of List']"));
                if (noDataFound.isDisplayed()) {
                    TestRunner.getTest().log(Status.PASS, "Testcase Passed: No Assessment found for Status: " + status + ", 'End of List' message is displayed.");
                } else {
                    TestRunner.getTest().log(Status.FAIL, "Testcase Failed: No Assessment found for Status: " + status + ", but 'End of List' message is not displayed.");
                }
            } catch (NoSuchElementException e) {
                TestRunner.getTest().log(Status.FAIL, "Testcase Failed: No Assessment found for Status: " + status + " and 'End of List' message is not displayed.");
            }
        }

    }

    String baseUrl = Configurations.App_url;

    @FindBy(xpath = "//div[@aria-label='Dashboard']")
    WebElement user_dashboard;

    public void ClickOnDashboard() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Click on User's Dashboard");
        user_dashboard.click();
        TestRunner.getTest().log(Status.PASS, "Test Case Passed : Clicked on User Dashboard Successfully");
        refreshPage();
        Thread.sleep(2000);
    }

    private void refreshPage() {
        driver.navigate().to(baseUrl);
    }

    public void NotStartedFilter() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into Validate that Not Started Assignment is under Not Started Status");
        System.out.println("I'm into Validate that Not Started Assignment is under Not Started Status");

        String[] statusArray = {"Not Started"};

        for (String status : statusArray) {
            TestRunner.getTest().log(Status.INFO, "Filtering Assignments By Status: " + status);

            try {
                WebElement statusDropdown = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(@class, 'MuiSelect-select') and @role='button' or @role='combobox'])[2]")));
                statusDropdown.click();

                List<WebElement> statusOptions = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//ul[@role='listbox']//li")));
                boolean statusFound = false;

                for (WebElement option : statusOptions) {
                    String optionText = option.getText().trim();
                    if (optionText.equalsIgnoreCase(status)) {
                        option.click();
                        statusFound = true;
                        TestRunner.getTest().log(Status.INFO, "Selected Status: " + optionText);
                        break;
                    }
                }

                if (!statusFound) {
                    TestRunner.getTest().log(Status.FAIL, "Status not found in the dropdown: " + status);
//                    throw new RuntimeException("Status not found in the dropdown: " + status);
                }

//                Thread.sleep(2000);
                VerifyAssignmentIsPresentInDefinedStartedAssignments(status);

            } catch (NoSuchElementException | ElementNotInteractableException e) {
                TestRunner.getTest().log(Status.WARNING, "Table not loaded within the expected time frame.");
            }
        }

    }

    private void VerifyAssignmentIsPresentInDefinedStartedAssignments(String status) throws InterruptedException {

        Thread.sleep(2000);
        WebElement for_scroll = driver.findElement(By.xpath("//a[normalize-space()='Assign New']"));
        helper.scrollToElement(driver, for_scroll);

        WebElement searchBox = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder='Search by name or keyword']")));
//        helper.scrollToElement(driver,searchBox);
        Thread.sleep(1000);
        if (searchBox.isDisplayed()) {
            searchBox.click();
            searchBox.clear();
            ((JavascriptExecutor) driver).executeScript("arguments[0].value='';", searchBox);

            String assignmentNameForCorrect = CorrectAnswerExecutor_PF.assignmentNameForCorrect.get();
            System.out.println("Search by Assignment name: " + assignmentNameForCorrect);
            searchBox.sendKeys(assignmentNameForCorrect);
            TestRunner.getTest().log(Status.INFO, "Search Assignment is: " + assignmentNameForCorrect);

            Actions actions = new Actions(driver);
            actions.sendKeys(Keys.ENTER).perform();

            TestRunner.getTest().log(Status.PASS, "Testcase Passed: Entered Search Assignment keyword successfully");

            // Wait for the table to refresh and show search results
            Thread.sleep(3000);

            List<WebElement> assignmentNameDivs = driver.findElements(By.xpath("//div[contains(@class, 'left-content-header')]/div[contains(@class, 'MuiBox-root')]/div[1]"));
            System.out.println("Total Assignments with Status '" + status + "': " + assignmentNameDivs.size());
            TestRunner.getTest().log(Status.INFO, "Total Assignments with Status '" + status + "': " + assignmentNameDivs.size());

            boolean assignmentFound = false;

            if (!assignmentNameDivs.isEmpty()) {
                for (WebElement assignmentNameDiv : assignmentNameDivs) {
                    Assignment_Title = assignmentNameDiv.getText().trim();
                    System.out.println("Assignment Name: " + Assignment_Title);
                    TestRunner.getTest().log(Status.INFO, "Assignment Name: " + Assignment_Title);

                    if (Assignment_Title.equalsIgnoreCase(assignmentNameForCorrect)) {
                        assignmentFound = true;
                    }
                }

                if (assignmentFound) {
                    TestRunner.getTest().log(Status.PASS, "Testcase Passed: Assignment '" + assignmentNameForCorrect + "' found in the list for Status: " + status);
                } else {
                    TestRunner.getTest().log(Status.FAIL, "Testcase Failed: Assignment '" + assignmentNameForCorrect + "' not found in the list for Status: " + status);
                }
            } else {
                // If no assignments are found, log the search result as not found
                System.out.println("No Assessment found in the table for Status: " + status);
                TestRunner.getTest().log(Status.FAIL, "Assignment '" + assignmentNameForCorrect + "' not found under Status: " + status);

            }
        }

    }

    public void VerifyThatAssignmentIsNotPresentInOtherStatus() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into Validate that Not Started Assignment is not in Other Assignment status");
        System.out.println("I'm into Validate that Not Started Assignment is not in Other Assignment status");

        String[] statusArray = {"Started", "Needs Grading", "Completed", "Future"};

        for (String status : statusArray) {
            TestRunner.getTest().log(Status.INFO, "Filtering Assignments By Status: " + status);

            try {
                WebElement statusDropdown = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(@class, 'MuiSelect-select') and @role='button' or @role='combobox'])[2]")));
                statusDropdown.click();

                List<WebElement> statusOptions = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//ul[@role='listbox']//li")));
                boolean statusFound = false;

                for (WebElement option : statusOptions) {
                    String optionText = option.getText().trim();
                    if (optionText.equalsIgnoreCase(status)) {
                        option.click();
                        statusFound = true;
                        TestRunner.getTest().log(Status.INFO, "Selected Status: " + optionText);
                        break;
                    }
                }

                if (!statusFound) {
                    TestRunner.getTest().log(Status.FAIL, "Status not found in the dropdown: " + status);
//                    throw new RuntimeException("Status not found in the dropdown: " + status);
                }

//                Thread.sleep(2000);
                ValidateAssignmentIsNotPresentInOtherStatus(status);

            } catch (NoSuchElementException | ElementNotInteractableException e) {
                TestRunner.getTest().log(Status.WARNING, "Table not loaded within the expected time frame.");
            }
        }

    }

    public void ValidateAssignmentIsNotPresentInOtherStatus(String status) throws InterruptedException {

        // Wait for the search results to load and show up in the DOM
//        Thread.sleep(3000);
        String assignmentNameForCorrect = CorrectAnswerExecutor_PF.assignmentNameForCorrect.get();
        System.out.println("Search by Assignment name: " + assignmentNameForCorrect);

// Find assignment name divs based on the specified status
        List<WebElement> assignmentNameDivs = driver.findElements(By.xpath("//div[contains(@class, 'left-content-header')]/div[contains(@class, 'MuiBox-root')]/div[1]"));
        System.out.println("Total Assignments with Status '" + status + "': " + assignmentNameDivs.size());
        TestRunner.getTest().log(Status.INFO, "Total Assignments with Status '" + status + "': " + assignmentNameDivs.size());

        boolean assignmentFound = false;

        if (!assignmentNameDivs.isEmpty()) {
            for (WebElement assignmentNameDiv : assignmentNameDivs) {
                Assignment_Title = assignmentNameDiv.getText().trim();
                System.out.println("Assignment Name: " + Assignment_Title);
                TestRunner.getTest().log(Status.INFO, "Assignment Name: " + Assignment_Title);

                // If the assignment name matches, mark it as found
                if (Assignment_Title.equalsIgnoreCase(assignmentNameForCorrect)) {
                    assignmentFound = true;
                    break;
                }
            }

            // Check if assignment was found
            if (assignmentFound) {
                // Fail if the assignment is found (it shouldn't be under this status)
                TestRunner.getTest().log(Status.FAIL, "Testcase Failed: Assignment '" + assignmentNameForCorrect + "' should not be found under Status: " + status);
            } else {
                // Pass if the assignment is not found
                TestRunner.getTest().log(Status.PASS, "Testcase Passed: Assignment '" + assignmentNameForCorrect + "' is correctly not found under Status: " + status);
            }
        } else {
            // If no assignments are found, check for the "End of List" message
            System.out.println("No Assessment found in the table for Status: " + status);
            TestRunner.getTest().log(Status.INFO, "No assignments found under Status: " + status);

            try {
                WebElement noDataFound = driver.findElement(By.xpath("//div[@class='right-panel']//p[normalize-space()='There are no assignments for the selected class.']"));
                if (noDataFound.isDisplayed()) {
                    TestRunner.getTest().log(Status.PASS, "Testcase Passed: No Assessment found for Status: " + status + ", 'There are no assignments for the selected class' message is displayed.");
                } else {
                    TestRunner.getTest().log(Status.FAIL, "Testcase Failed: No Assessment found for Status: " + status + ", but 'There are no assignments for the selected class' message is not displayed.");
                }
            } catch (NoSuchElementException e) {
                TestRunner.getTest().log(Status.FAIL, "Testcase Failed: No Assessment found for Status: " + status + " and 'There are no assignments for the selected class' message is not displayed.");
            }
        }

    }

    public void VerifyResumeAssignmentIsInStartedStatus() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into Validate that Started Assignment is under Started Status");
        System.out.println("I'm into Validate that Started Assignment is under Started Status");

        String[] statusArray = {"Started"};

        for (String status : statusArray) {
            TestRunner.getTest().log(Status.INFO, "Filtering Assignments By Status: " + status);

            try {
                WebElement statusDropdown = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(@class, 'MuiSelect-select') and @role='button' or @role='combobox'])[2]")));
                statusDropdown.click();

                List<WebElement> statusOptions = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//ul[@role='listbox']//li")));
                boolean statusFound = false;

                for (WebElement option : statusOptions) {
                    String optionText = option.getText().trim();
                    if (optionText.equalsIgnoreCase(status)) {
                        option.click();
                        statusFound = true;
                        TestRunner.getTest().log(Status.INFO, "Selected Status: " + optionText);
                        break;
                    }
                }

                if (!statusFound) {
                    TestRunner.getTest().log(Status.FAIL, "Status not found in the dropdown: " + status);
//                    throw new RuntimeException("Status not found in the dropdown: " + status);
                }

//                Thread.sleep(2000);
                VerifyAssignmentIsPresentInDefinedStartedAssignments(status);

            } catch (NoSuchElementException | ElementNotInteractableException e) {
                TestRunner.getTest().log(Status.WARNING, "Table not loaded within the expected time frame.");
            }
        }
    }

    public void ResumeAssignmentIsNotInOtherStatusAssignment() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into Validate that Started Assignment is not in Other Assignment status");
        System.out.println("I'm into Validate that Started Assignment is not in Other Assignment status");

        String[] statusArray = {"Not Started", "Needs Grading", "Completed", "Future"};

        for (String status : statusArray) {
            TestRunner.getTest().log(Status.INFO, "Filtering Assignments By Status: " + status);

            try {
                WebElement statusDropdown = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(@class, 'MuiSelect-select') and @role='button' or @role='combobox'])[2]")));
                statusDropdown.click();

                List<WebElement> statusOptions = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//ul[@role='listbox']//li")));
                boolean statusFound = false;

                for (WebElement option : statusOptions) {
                    String optionText = option.getText().trim();
                    if (optionText.equalsIgnoreCase(status)) {
                        option.click();
                        statusFound = true;
                        TestRunner.getTest().log(Status.INFO, "Selected Status: " + optionText);
                        break;
                    }
                }

                if (!statusFound) {
                    TestRunner.getTest().log(Status.FAIL, "Status not found in the dropdown: " + status);
//                    throw new RuntimeException("Status not found in the dropdown: " + status);
                }

//                Thread.sleep(2000);
                ValidateAssignmentIsNotPresentInOtherStatus(status);

            } catch (NoSuchElementException | ElementNotInteractableException e) {
                TestRunner.getTest().log(Status.WARNING, "Table not loaded within the expected time frame.");
            }
        }
    }

    public void VerifyCompletedAssignmentStatus() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into Validate that Completed Assignment is under Completed Status");
        System.out.println("I'm into Validate that Completed Assignment is under Completed Status ");

        String[] statusArray = {"Completed"};

        for (String status : statusArray) {
            TestRunner.getTest().log(Status.INFO, "Filtering Assignments By Status: " + status);

            try {
                WebElement statusDropdown = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(@class, 'MuiSelect-select') and @role='button' or @role='combobox'])[2]")));
                statusDropdown.click();

                List<WebElement> statusOptions = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//ul[@role='listbox']//li")));
                boolean statusFound = false;

                for (WebElement option : statusOptions) {
                    String optionText = option.getText().trim();
                    if (optionText.equalsIgnoreCase(status)) {
                        option.click();
                        statusFound = true;
                        TestRunner.getTest().log(Status.INFO, "Selected Status: " + optionText);
                        break;
                    }
                }

                if (!statusFound) {
                    TestRunner.getTest().log(Status.FAIL, "Status not found in the dropdown: " + status);
//                    throw new RuntimeException("Status not found in the dropdown: " + status);
                }

//                Thread.sleep(2000);
                VerifyAssignmentIsPresentInDefinedStartedAssignments(status);

            } catch (NoSuchElementException | ElementNotInteractableException e) {
                TestRunner.getTest().log(Status.WARNING, "Table not loaded within the expected time frame.");
            }
        }

    }

    public void ValidateCompletedAssignmentIsNotInOtherStatusOfAssignment() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into Validate that Completed Assignment is not in Other Assignment status");
        System.out.println("I'm into Validate that Completed Assignment is not in Other Assignment status ");

        String[] statusArray = {"Not Started", "Needs Grading", "Started", "Future"};

        for (String status : statusArray) {
            TestRunner.getTest().log(Status.INFO, "Filtering Assignments By Status: " + status);

            try {
                WebElement statusDropdown = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(@class, 'MuiSelect-select') and @role='button' or @role='combobox'])[2]")));
                statusDropdown.click();

                List<WebElement> statusOptions = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//ul[@role='listbox']//li")));
                boolean statusFound = false;

                for (WebElement option : statusOptions) {
                    String optionText = option.getText().trim();
                    if (optionText.equalsIgnoreCase(status)) {
                        option.click();
                        statusFound = true;
                        TestRunner.getTest().log(Status.INFO, "Selected Status: " + optionText);
                        break;
                    }
                }

                if (!statusFound) {
                    TestRunner.getTest().log(Status.FAIL, "Status not found in the dropdown: " + status);
//                    throw new RuntimeException("Status not found in the dropdown: " + status);
                }

//                Thread.sleep(2000);
                ValidateAssignmentIsNotPresentInOtherStatus(status);

            } catch (NoSuchElementException | ElementNotInteractableException e) {
                TestRunner.getTest().log(Status.WARNING, "Table not loaded within the expected time frame.");
            }
        }

    }

    public void VerifyNeedsGradingAssignmentStatus() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into Validate that Needs Grading Assignment is under Needs Grading  Status");
        System.out.println("I'm into Validate that Needs Grading  Assignment is under Needs Grading  Status ");

        String[] statusArray = {"Needs Grading"};

        for (String status : statusArray) {
            TestRunner.getTest().log(Status.INFO, "Filtering Assignments By Status: " + status);

            try {
                WebElement statusDropdown = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(@class, 'MuiSelect-select') and @role='button' or @role='combobox'])[2]")));
                statusDropdown.click();

                List<WebElement> statusOptions = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//ul[@role='listbox']//li")));
                boolean statusFound = false;

                for (WebElement option : statusOptions) {
                    String optionText = option.getText().trim();
                    if (optionText.equalsIgnoreCase(status)) {
                        option.click();
                        statusFound = true;
                        TestRunner.getTest().log(Status.INFO, "Selected Status: " + optionText);
                        break;
                    }
                }

                if (!statusFound) {
                    TestRunner.getTest().log(Status.FAIL, "Status not found in the dropdown: " + status);
//                    throw new RuntimeException("Status not found in the dropdown: " + status);
                }

//                Thread.sleep(2000);
                VerifyAssignmentIsPresentInDefinedStartedAssignments(status);

            } catch (NoSuchElementException | ElementNotInteractableException e) {
                TestRunner.getTest().log(Status.WARNING, "Table not loaded within the expected time frame.");
            }
        }
    }

    public void ValidateNeedsGradingAssignmentInOtherStatus() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into Validate that Needs Grading Assignment is not in Other Assignment status");
        System.out.println("I'm into Validate that Needs Grading Assignment is not in Other Assignment status ");

        String[] statusArray = {"Not Started", "Started", "Completed", "Future"};

        for (String status : statusArray) {
            TestRunner.getTest().log(Status.INFO, "Filtering Assignments By Status: " + status);

            try {
                WebElement statusDropdown = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(@class, 'MuiSelect-select') and @role='button' or @role='combobox'])[2]")));
                statusDropdown.click();

                List<WebElement> statusOptions = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//ul[@role='listbox']//li")));
                boolean statusFound = false;

                for (WebElement option : statusOptions) {
                    String optionText = option.getText().trim();
                    if (optionText.equalsIgnoreCase(status)) {
                        option.click();
                        statusFound = true;
                        TestRunner.getTest().log(Status.INFO, "Selected Status: " + optionText);
                        break;
                    }
                }

                if (!statusFound) {
                    TestRunner.getTest().log(Status.FAIL, "Status not found in the dropdown: " + status);
//                    throw new RuntimeException("Status not found in the dropdown: " + status);
                }

//                Thread.sleep(2000);
                ValidateAssignmentIsNotPresentInOtherStatus(status);

            } catch (NoSuchElementException | ElementNotInteractableException e) {
                TestRunner.getTest().log(Status.WARNING, "Table not loaded within the expected time frame.");
            }
        }

    }

    public void ValidateAssignmentForFutureStatus() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into Validate that Future Assignment is under Future Status");
        System.out.println("I'm into Validate that Future Assignment is under Future Status ");

        String[] statusArray = {"Not Started", "Future"};

        for (String status : statusArray) {
            TestRunner.getTest().log(Status.INFO, "Filtering Assignments By Status: " + status);

            try {
                WebElement statusDropdown = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(@class, 'MuiSelect-select') and @role='button' or @role='combobox'])[2]")));
                statusDropdown.click();

                List<WebElement> statusOptions = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//ul[@role='listbox']//li")));
                boolean statusFound = false;

                for (WebElement option : statusOptions) {
                    String optionText = option.getText().trim();
                    if (optionText.equalsIgnoreCase(status)) {
                        option.click();
                        statusFound = true;
                        TestRunner.getTest().log(Status.INFO, "Selected Status: " + optionText);
                        break;
                    }
                }

                if (!statusFound) {
                    TestRunner.getTest().log(Status.FAIL, "Status not found in the dropdown: " + status);
//                    throw new RuntimeException("Status not found in the dropdown: " + status);
                }

//                Thread.sleep(2000);
                SearchFutureStatusAssignment(status);

                WebElement cross_button = driver.findElement(By.xpath("//*[@data-testid='CloseIcon']"));
                if (cross_button.isDisplayed()) {
                    cross_button.click();
                }

            } catch (NoSuchElementException | ElementNotInteractableException e) {
                TestRunner.getTest().log(Status.WARNING, "Table not loaded within the expected time frame.");
            }
        }

    }

    public void SearchFutureStatusAssignment(String status) throws InterruptedException {
        Thread.sleep(2000);
//        Thread.sleep(2000);
        WebElement for_scroll = driver.findElement(By.xpath("//a[normalize-space()='Assign New']"));
        helper.scrollToElement(driver, for_scroll);

        WebElement searchBox = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder='Search by name or keyword']")));
//        helper.scrollToElement(driver,searchBox);
        Thread.sleep(1000);
        if (searchBox.isDisplayed()) {
            searchBox.click();
            searchBox.clear();
            ((JavascriptExecutor) driver).executeScript("arguments[0].value='';", searchBox);

            String assignmentNameForCorrect = "AttemptAssignment::VQ";
            System.out.println("Search by Assignment name: " + assignmentNameForCorrect);
            searchBox.sendKeys(assignmentNameForCorrect);
            TestRunner.getTest().log(Status.INFO, "Search Assignment is: " + assignmentNameForCorrect);

            Actions actions = new Actions(driver);
            actions.sendKeys(Keys.ENTER).perform();

            TestRunner.getTest().log(Status.PASS, "Testcase Passed: Entered Search Assignment keyword successfully");

            // Wait for the table to refresh and show search results
            Thread.sleep(3000);

            List<WebElement> assignmentNameDivs = driver.findElements(By.xpath("//div[contains(@class, 'left-content-header')]/div[contains(@class, 'MuiBox-root')]/div[1]"));
            System.out.println("Total Assignments with Status '" + status + "': " + assignmentNameDivs.size());
            TestRunner.getTest().log(Status.INFO, "Total Assignments with Status '" + status + "': " + assignmentNameDivs.size());

            boolean assignmentFound = false;

            if (!assignmentNameDivs.isEmpty()) {
                for (WebElement assignmentNameDiv : assignmentNameDivs) {
                    Assignment_Title = assignmentNameDiv.getText().trim();
                    System.out.println("Assignment Name: " + Assignment_Title);
                    TestRunner.getTest().log(Status.INFO, "Assignment Name: " + Assignment_Title);

                    if (Assignment_Title.equalsIgnoreCase(assignmentNameForCorrect)) {
                        assignmentFound = true;
                    }
                }

                if (assignmentFound) {
                    TestRunner.getTest().log(Status.PASS, "Testcase Passed: Assignment '" + assignmentNameForCorrect + "' found in the list for Status: " + status);
                } else {
                    TestRunner.getTest().log(Status.FAIL, "Testcase Failed: Assignment '" + assignmentNameForCorrect + "' not found in the list for Status: " + status);
                }
            } else {
                // If no assignments are found, log the search result as not found
                System.out.println("No Assessment found in the table for Status: " + status);
                TestRunner.getTest().log(Status.FAIL, "Assignment '" + assignmentNameForCorrect + "' not found under Status: " + status);

            }
        }


    }

    public void ValidateFutureStatusAssignmentInOthStatus() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into Validate that Future Assignment is not in Other Assignment status");
        System.out.println("I'm into Validate that Future Assignment is not in Other Assignment status ");

        String[] statusArray = {"Started", "Needs Grading", "Completed"};

        for (String status : statusArray) {
            TestRunner.getTest().log(Status.INFO, "Filtering Assignments By Status: " + status);

            try {
                WebElement statusDropdown = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(@class, 'MuiSelect-select') and @role='button' or @role='combobox'])[2]")));
                statusDropdown.click();

                List<WebElement> statusOptions = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//ul[@role='listbox']//li")));
                boolean statusFound = false;

                for (WebElement option : statusOptions) {
                    String optionText = option.getText().trim();
                    if (optionText.equalsIgnoreCase(status)) {
                        option.click();
                        statusFound = true;
                        TestRunner.getTest().log(Status.INFO, "Selected Status: " + optionText);
                        break;
                    }
                }

                if (!statusFound) {
                    TestRunner.getTest().log(Status.FAIL, "Status not found in the dropdown: " + status);
//                    throw new RuntimeException("Status not found in the dropdown: " + status);
                }

//                Thread.sleep(2000);
                ValidateAssignmentIsNotPresentInOtherStatus(status);

            } catch (NoSuchElementException | ElementNotInteractableException e) {
                TestRunner.getTest().log(Status.WARNING, "Table not loaded within the expected time frame.");
            }
        }
    }




public void SelectStatusByTitle() throws InterruptedException {
    TestRunner.getTest().log(Status.INFO, "I'm into Click on Sort by Filter and Select Title From DropDown");
    System.out.println("I'm into Click on Sort by Filter and Select Title From DropDown");

    String[] sortByArray = {"Title"};

    for (String status : sortByArray) {
        TestRunner.getTest().log(Status.INFO, "Filtering Assignments Sort By : " + status);


        try {
            WebElement sortByDropdown = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(@class, 'MuiSelect-select') and @role='button' or @role='combobox'])[3]")));
            sortByDropdown.click();

            List<WebElement> sortByOptions = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//ul[@role='listbox']//li")));
            boolean sortByFound = false;

            for (WebElement option : sortByOptions) {
                String optionText = option.getText().trim();
                if (optionText.equalsIgnoreCase(status)) {
                    option.click();
                    sortByFound = true;
                    TestRunner.getTest().log(Status.INFO, "Selected Sort By Option: " + optionText);
                    break;
                }
            }

            if (!sortByFound) {
                TestRunner.getTest().log(Status.FAIL, "Sort By not found in the dropdown: " + status);
            }
            Thread.sleep(2000);
            GetAllAssignmentsByTitle(status);

        } catch (NoSuchElementException | ElementNotInteractableException e) {
            TestRunner.getTest().log(Status.WARNING, "Table not loaded within the expected time frame.");
        }
    }
}

    public void GetAllAssignmentsByTitle(String status) throws InterruptedException {

        // Log that the title filter has been applied

        TestRunner.getTest().log(Status.INFO, "I'm into Get All Assignment Name After Title Filter Applied");
        System.out.println("I'm into Get All Assignment Name After Title Filter Applied");

        Thread.sleep(3000);
        List<WebElement> assignmentNameDivs = driver.findElements(By.xpath("//div[contains(@class, 'left-content-header')]/div[contains(@class, 'MuiBox-root')]/div[1]"));
        System.out.println("Total Assignments with Sort By Filter '" + status + "': " + assignmentNameDivs.size());
        TestRunner.getTest().log(Status.INFO, "Total Assignments with Sort By Filter '" + status + "': " + assignmentNameDivs.size());

        List<String> assignmentNames = new ArrayList<>();
        if (!assignmentNameDivs.isEmpty()) {
            for (WebElement assignmentNameDiv : assignmentNameDivs) {
                String assignmentTitle = assignmentNameDiv.getText().trim();
                assignmentNames.add(assignmentTitle);
                System.out.println("Assignment Name: " + assignmentTitle);
                TestRunner.getTest().log(Status.INFO, "Assignment Name: " + assignmentTitle);
            }

            // Create a copy of the list and apply Natural/Alphanumeric Sorting
            List<String> sortedAssignmentNames = new ArrayList<>(assignmentNames);
            Collections.sort(sortedAssignmentNames, new NaturalOrderComparator());

            // Compare UI list with locally sorted list
            if (assignmentNames.equals(sortedAssignmentNames)) {
                System.out.println("Assignments are sorted correctly by: " + status);
                TestRunner.getTest().log(Status.PASS, "Testcase Passed: Assignments are sorted correctly for Sort By: " + status);
            } else {
                System.out.println("Assignments are not sorted correctly by: " + status);
                TestRunner.getTest().log(Status.FAIL, "Testcase Failed: Assignments are not sorted correctly for Sort By: " + status);

                // Debugging: Print actual and expected orders
                System.out.println("Actual Order: " + assignmentNames);
                System.out.println("Expected Order: " + sortedAssignmentNames);
                
                // Print first few differences for debugging
                int maxDiff = Math.min(10, Math.min(assignmentNames.size(), sortedAssignmentNames.size()));
                for (int i = 0; i < maxDiff; i++) {
                    if (!assignmentNames.get(i).equals(sortedAssignmentNames.get(i))) {
                        System.out.println("Position " + i + " - Actual: " + assignmentNames.get(i) + " | Expected: " + sortedAssignmentNames.get(i));
                        TestRunner.getTest().log(Status.INFO, "Position " + i + " - Actual: " + assignmentNames.get(i) + " | Expected: " + sortedAssignmentNames.get(i));
                    }
                }
            }
        } else {
            System.out.println("No Assessment found in the table for Sort By: " + status);
            TestRunner.getTest().log(Status.FAIL, "No assignments found for Sort By: " + status);
        }
    }

    // Natural Order Comparator for Alphanumeric Sorting
    private static class NaturalOrderComparator implements Comparator<String> {
        @Override
        public int compare(String s1, String s2) {
            if (s1 == null && s2 == null) return 0;
            if (s1 == null) return -1;
            if (s2 == null) return 1;
            
            // Convert to lowercase for case-insensitive comparison
            String str1 = s1.toLowerCase();
            String str2 = s2.toLowerCase();
            
            int len1 = str1.length();
            int len2 = str2.length();
            int i = 0, j = 0;
            
            while (i < len1 && j < len2) {
                char c1 = str1.charAt(i);
                char c2 = str2.charAt(j);
                
                // If both are digits, parse the whole number
                if (Character.isDigit(c1) && Character.isDigit(c2)) {
                    int num1 = 0, num2 = 0;
                    
                    // Parse number from str1
                    while (i < len1 && Character.isDigit(str1.charAt(i))) {
                        num1 = num1 * 10 + (str1.charAt(i) - '0');
                        i++;
                    }
                    
                    // Parse number from str2
                    while (j < len2 && Character.isDigit(str2.charAt(j))) {
                        num2 = num2 * 10 + (str2.charAt(j) - '0');
                        j++;
                    }
                    
                    // Compare numbers numerically
                    if (num1 != num2) {
                        return Integer.compare(num1, num2);
                    }
                } else {
                    // Compare characters lexicographically
                    if (c1 != c2) {
                        return Character.compare(c1, c2);
                    }
                    i++;
                    j++;
                }
            }
            
            // If one string is shorter, it comes first
            return Integer.compare(len1, len2);
        }
    }

    public void SelectStatusByDueDate() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into Click on Sort by DueDate and Select DueDate From DropDown");
        System.out.println("I'm into Click on Sort by DueDate and Select DueDate From DropDown");

        String[] sortByArray = {"DueDate"};

        for (String status : sortByArray) {
            TestRunner.getTest().log(Status.INFO, "Filtering Assignments Sort By : " + status);

            try {
                WebElement sortByDropdown = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(@class, 'MuiSelect-select') and @role='button' or @role='combobox'])[3]")));
                sortByDropdown.click();

                List<WebElement> sortByOptions = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//ul[@role='listbox']//li")));
                boolean sortByFound = false;

                for (WebElement option : sortByOptions) {
                    String optionText = option.getText().trim();
                    if (optionText.equalsIgnoreCase(status)) {
                        option.click();
                        sortByFound = true;
                        TestRunner.getTest().log(Status.INFO, "Selected Sort By Option: " + optionText);
                        break;
                    }
                }

                if (!sortByFound) {
                    TestRunner.getTest().log(Status.FAIL, "Sort By not found in the dropdown: " + status);
//                    throw new RuntimeException("Status not found in the dropdown: " + status);
                }
                Thread.sleep(2000);
                GetAllAssignmentsDueDate(status);

            } catch (NoSuchElementException | ElementNotInteractableException e) {
                TestRunner.getTest().log(Status.WARNING, "Table not loaded within the expected time frame.");
            }
        }
    }

    public void GetAllAssignmentsDueDate(String status) throws InterruptedException {

        // Wait for the elements to be visible
        Thread.sleep(3000);

        List<WebElement> assignmentNameDivs = driver.findElements(By.xpath("//div[contains(@class, 'content-footer-left')]//div[contains(@class,'DueDate')]"));
        System.out.println("Total Assignments with Sort By Filter '" + status + "': " + assignmentNameDivs.size());
        TestRunner.getTest().log(Status.INFO, "Total Assignments with Sort By Filter '" + status + "': " + assignmentNameDivs.size());

        List<LocalDate> dueDates = new ArrayList<>();

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

        for (WebElement element : assignmentNameDivs) {
            String dateText = element.getText().replace("Due: ", "").trim();
            // Keep only the date portion (first 10 characters in yyyy-MM-dd format)
            String dateOnlyText = dateText.substring(0, 10);
            LocalDate dueDate = LocalDate.parse(dateOnlyText, formatter);
            dueDates.add(dueDate);

            System.out.println("Assignment DueDate: " + dueDate);
            TestRunner.getTest().log(Status.INFO, "Assignment DueDate: " + dueDate);
        }

        List<LocalDate> sortedDueDates = new ArrayList<>(dueDates);
        Collections.sort(sortedDueDates);

        if (dueDates.equals(sortedDueDates)) {
            System.out.println("Assignments are displayed in ascending order of due date. Status: " + status);
            TestRunner.getTest().log(Status.PASS, "Assignments are displayed in ascending order of due date. Status: " + status);
        } else {
            System.out.println("Assignments are not displayed in ascending order of due date. Status: " + status);
            TestRunner.getTest().log(Status.FAIL, "Assignments are not displayed in ascending order of due date. Status: " + status);
        }


    }

    public void SelectStatusByStartDate() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into Click on Sort by StartDate and Select StartDate From DropDown");
        System.out.println("I'm into Click on Sort by StartDate and Select StartDate From DropDown");

        String[] sortByArray = {"StartDate"};

        for (String status : sortByArray) {
            TestRunner.getTest().log(Status.INFO, "Filtering Assignments Sort By : " + status);

            try {
                WebElement sortByDropdown = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(@class, 'MuiSelect-select') and @role='button' or @role='combobox'])[3]")));
                sortByDropdown.click();

                List<WebElement> sortByOptions = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//ul[@role='listbox']//li")));
                boolean sortByFound = false;

                for (WebElement option : sortByOptions) {
                    String optionText = option.getText().trim();
                    if (optionText.equalsIgnoreCase(status)) {
                        option.click();
                        sortByFound = true;
                        TestRunner.getTest().log(Status.INFO, "Selected Sort By Option: " + optionText);
                        break;
                    }
                }

                if (!sortByFound) {
                    TestRunner.getTest().log(Status.FAIL, "Sort By not found in the dropdown: " + status);
//                    throw new RuntimeException("Status not found in the dropdown: " + status);
                }
                Thread.sleep(2000);
                GetAllAssignmentsStartDate(status);

            } catch (NoSuchElementException | ElementNotInteractableException e) {
                TestRunner.getTest().log(Status.WARNING, "Table not loaded within the expected time frame.");
            }
        }
    }

    public void GetAllAssignmentsStartDate(String status) throws InterruptedException {

        // Wait for the elements to be visible
        Thread.sleep(3000);

        List<WebElement> assignmentNameDivs = driver.findElements(By.xpath("//div[contains(@class, 'content-footer-left')]//div[contains(@class,'startDate')]"));
        System.out.println("Total Assignments with Sort By Filter '" + status + "': " + assignmentNameDivs.size());
        TestRunner.getTest().log(Status.INFO, "Total Assignments with Sort By Filter '" + status + "': " + assignmentNameDivs.size());

        List<LocalDateTime> startDates = new ArrayList<>();

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

        for (WebElement element : assignmentNameDivs) {
            String dateText = element.getText().replace("Start: ", "").trim();
            LocalDateTime dueDate = convertToDateTime(dateText);
            System.out.println("Date: " + dueDate.toLocalDate());  // 2024-11-12
            System.out.println("Time: " + dueDate.toLocalTime());
            startDates.add(dueDate);

            System.out.println("Assignment StartDate: " + dueDate);
            TestRunner.getTest().log(Status.INFO, "Assignment StartDate: " + dueDate);
        }
        System.out.println("All Assignments startDate Display successfully ");

        TestRunner.getTest().log(Status.PASS, "All Assignment Display StartDate Successfully");
    }

//    public static LocalDateTime convertToDateTime(String dateTimeStr) {
//        // Split the input string into date and time parts
//        String[] dateTimeParts = dateTimeStr.split(" ", 2);
//
//        // Extract the date and time parts
//        String datePart = dateTimeParts[0];  // "2024-11-12"
//        String timePart = dateTimeParts[1];  // "04:47 PM"
//        String[] parts = timePart.split(" ");
//        String timeStr = parts[0];  // "04:47"
//        String amPm = parts[1];  // "PM"
//
//        // Define the formatter for 24-hour time
//        DateTimeFormatter formatter24Hour = DateTimeFormatter.ofPattern("HH:mm");
//
//        // Parse the input time string (12-hour format) to a LocalTime object
//        LocalTime parsedTime = LocalTime.parse(timeStr, formatter24Hour);
//
//        // Handle AM/PM adjustments
//        if (amPm.equals("PM") && parsedTime.getHour() != 12) {
//            parsedTime = parsedTime.plusHours(12);  // Convert PM to 24-hour time
//        }
//        // If it's AM and the hour is 12, set it to 0 (midnight)
//        if (amPm.equals("AM") && parsedTime.getHour() == 12) {
//            parsedTime = parsedTime.minusHours(12);  // Convert 12 AM to 00:00
//        }
//
//        // Define the formatter for the date part
//        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
//
//        // Parse the date part to LocalDate
//        LocalDate parsedDate = LocalDate.parse(datePart, dateFormatter);
//
//        // Combine the date and time to create a LocalDateTime object
//        return LocalDateTime.of(parsedDate, parsedTime);
//    }

    public static LocalDateTime convertToDateTime(String dateTimeStr) {
        // Remove known labels
        dateTimeStr = dateTimeStr
                .replace("Start:", "")
                .replace("Date:", "")
                .replace("Late", "")
                .trim();

        DateTimeFormatter formatter =
                DateTimeFormatter.ofPattern("yyyy-MM-dd hh:mm a", Locale.ENGLISH);

        return LocalDateTime.parse(dateTimeStr, formatter);
    }


    public void SearchAssignmentByNameInAssignmentModule() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Search Assignment is: " + assignmentNameForCorrect.get());
        System.out.println("Search Assignment is: " + assignmentNameForCorrect.get());

        WebElement right_panel = driver.findElement(By.xpath("//div[@class='right-panel']"));
        right_panel.isDisplayed();

        try {
            WebElement searchBox = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder='Search by name or keyword']")));
            if (searchBox.isDisplayed()) {
                searchBox.click();
                searchBox.clear();
                ((JavascriptExecutor) driver).executeScript("arguments[0].value='';", searchBox);
                Thread.sleep(2000);

//                String assignmentNameForCorrect = CorrectAnswerExecutor_PF.assignmentNameForCorrect.get();
//                System.out.println("Search by Assignment name: " + assignmentNameForCorrect);
                searchBox.sendKeys(assignmentNameForCorrect.get());

                TestRunner.getTest().log(Status.INFO, "Search Assignment is: " + assignmentNameForCorrect.get());
                System.out.println("Search Assignment is: " + assignmentNameForCorrect.get());
                Actions actions = new Actions(driver);
                actions.sendKeys(Keys.ENTER).perform();


                TestRunner.getTest().log(Status.PASS, "Testcase Passed   :   Enter Search Assignment keyword Successfully");

                waitForTableToRefresh();
            } else {
                System.out.println("Search box is not displayed.");
                TestRunner.getTest().log(Status.FAIL, "Testcase Failed   : Search box is not displayed.");
//                throw new RuntimeException("Search Box not  Found.");
            }
        } catch (Exception e) {
            System.out.println("Search box is not available: " + e.getMessage());
        }
    }

    public void verifySearchedAssessmentInAssignmentModuleByNameIntoTable() {
//        String assignmentNameForCorrect = CorrectAnswerExecutor_PF.assignmentNameForCorrect.get();
        System.out.println("Want to search assignment into table: " + assignmentNameForCorrect.get());
        TestRunner.getTest().log(Status.INFO, "Want to search assignment into table: " + assignmentNameForCorrect.get());

        WebElement assignmentName = driver.findElement(By.xpath("//div[contains(@class, 'left-content-header')]/div[contains(@class, 'MuiBox-root')]//div"));
        System.out.println("After search Assignment size: " + assignmentName);
        TestRunner.getTest().log(Status.INFO, "After search Assignment size: " + assignmentName);

        String actualAssignmentName = assignmentName.getText();
        System.out.println("Assignment name in Table: " + actualAssignmentName);
        TestRunner.getTest().log(Status.INFO, "Assignment name in Table: " + actualAssignmentName);


        if (actualAssignmentName.equalsIgnoreCase(assignmentNameForCorrect.get())) {
            System.out.println("Searched Assessment found: " + actualAssignmentName + " matches with " + assignmentNameForCorrect.get());
            TestRunner.getTest().log(Status.INFO, "Searched Assessment found: " + actualAssignmentName + " matches with " + assignmentNameForCorrect.get());
            TestRunner.getTest().log(Status.PASS, "Testcase Passed: Search Assessment by keyword successfully.");
        } else {
            System.out.println("Searched Assessment not found, and the search filter is not working.");
            TestRunner.getTest().log(Status.FAIL, "Testcase Failed: Searched Assessment not found, and the search filter is not working.");
        }

    }

    public void ValidateOpenButtonDisplay() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into Validate and Click on Open Button");
        System.out.println("I'm into Validate and Click on Open Button");

        Thread.sleep(1000);

        WebElement contentFooter = driver.findElement(By.cssSelector(".content-footer-right"));

        List<WebElement> allButtonsAndLinks = contentFooter.findElements(By.xpath(".//a | .//button"));

        boolean isOpenButtonPresent = false;

        for (WebElement element : allButtonsAndLinks) {
            String elementText = element.getText();
            TestRunner.getTest().log(Status.INFO, "Button On Assignment Module: " + elementText);
            System.out.println("Button On Assignment Module: " + elementText);

            if (elementText.equalsIgnoreCase("Preview")) {
                isOpenButtonPresent = true;
                element.click();
                System.out.println("Clicked on the Preview button.");
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: Clicked on the Open button.");
                break;
            }
        }

// Log if the "Open" button is not found
        if (!isOpenButtonPresent) {
            System.out.println("Open button is not displayed.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: 'Open' button is not displayed.");
        }


    }

    public void ValidateSummaryButtonDisplay() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into Validate and Click on Summary Button");
        System.out.println("I'm into Validate and Click on Summary Button");

        Thread.sleep(1000);

        WebElement contentFooter = driver.findElement(By.cssSelector(".content-footer-right"));

        List<WebElement> allButtonsAndLinks = contentFooter.findElements(By.xpath(".//a | .//button"));

        boolean isSummaryButtonPresent = false;

        for (WebElement element : allButtonsAndLinks) {
            String elementText = element.getText();
            TestRunner.getTest().log(Status.INFO, "Button On Assignment Module: " + elementText);
            System.out.println("Button On Assignment Module: " + elementText);

            if (elementText.equalsIgnoreCase("Summary")) {
                isSummaryButtonPresent = true;
                element.click();
                System.out.println("Clicked on the Summary button.");
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: Clicked on the Summary button.");
                break;
            }
        }

// Log if the "Open" button is not found
        if (!isSummaryButtonPresent) {
            System.out.println("Summary button is not displayed.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: 'Summary' button is not displayed.");
        }
    }

    public void ValidateSummaryButtonRedirectToSummaryPage() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into Validate That Summary Button Redirect correctly to summary page ");
        System.out.println("I'm into Validate That Summary Button Redirect correctly to summary page");

        Thread.sleep(1000);

//        WebElement breadCrumb = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ol[contains(@class, 'MuiBreadcrumbs')]")));
//        System.out.println("BreadCrumb is: " + breadCrumb.getText());

        List<WebElement> breadcrumbElements = driver.findElements(By.cssSelector(".MuiBreadcrumbs-ol .MuiBreadcrumbs-li"));

        // Build the actual breadcrumb text
        StringBuilder actualBreadcrumb = new StringBuilder();
        for (WebElement breadcrumb : breadcrumbElements) {
            String breadcrumbText = breadcrumb.getText().trim();
            if (!breadcrumbText.isEmpty()) {
                if (actualBreadcrumb.length() > 0) {
                    actualBreadcrumb.append(" / ");
                }
                actualBreadcrumb.append(breadcrumbText);
            }
        }

        // Define the expected breadcrumb
        String expectedBreadcrumb = "Home / Assignments / FL Grade 5 /";

        // Compare the actual breadcrumb with the expected breadcrumb
        if (actualBreadcrumb.toString().equals(expectedBreadcrumb)) {
            System.out.println("Breadcrumb matches the expected value.");
            TestRunner.getTest().log(Status.INFO, "Actual Breadcrumb: " + actualBreadcrumb + " Breadcrumb of Summary page Match with expected value." + expectedBreadcrumb);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Summary Button is Correctly Redirect to Summary Page.");

        } else {
            System.out.println("Breadcrumb does not match.");
            TestRunner.getTest().log(Status.INFO, "Breadcrumb of Summary Page does not match.");
            System.out.println("Actual: " + actualBreadcrumb);
            TestRunner.getTest().log(Status.INFO, "Actual: " + actualBreadcrumb);
            System.out.println("Expected: " + expectedBreadcrumb);
            TestRunner.getTest().log(Status.INFO, "Expected: " + expectedBreadcrumb);
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Summary Button is not Redirect to Summary Page.");
        }

    }

    public void ValidateSelectedButtonDisplay() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into Validate and Click on By Student Button");
        System.out.println("I'm into Validate and Click on Selected Button");

        Thread.sleep(1000);

        WebElement contentFooter = driver.findElement(By.cssSelector(".content-footer-right"));

        List<WebElement> allButtonsAndLinks = contentFooter.findElements(By.xpath(".//a | .//button"));

        boolean isSelectedButtonPresent = false;

        for (WebElement element : allButtonsAndLinks) {
            String elementText = element.getText();
            TestRunner.getTest().log(Status.INFO, "Button On Assignment Module: " + elementText);
            System.out.println("Button On Assignment Module: " + elementText);

            if (elementText.equalsIgnoreCase("By Student")) {
                isSelectedButtonPresent = true;
                element.click();
                System.out.println("Clicked on the By Student button.");
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: Clicked on the By Student button.");
                break;
            }
        }

// Log if the "Open" button is not found
        if (!isSelectedButtonPresent) {
            System.out.println("By Student button is not displayed.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: 'By Student' button is not displayed.");
        }
    }

    public void ValidateSelectedButtonRedirectToSelectedPage() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into Validate That By Student Button Redirect correctly to Selected page ");
        System.out.println("I'm into Validate That By Student Button Redirect correctly to Selected page");

        Thread.sleep(1000);

//        WebElement breadCrumb = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ol[contains(@class, 'MuiBreadcrumbs')]")));
//        System.out.println("BreadCrumb is: " + breadCrumb.getText());

        List<WebElement> breadcrumbElements = driver.findElements(By.cssSelector(".MuiBreadcrumbs-ol .MuiBreadcrumbs-li"));

        // Build the actual breadcrumb text
        StringBuilder actualBreadcrumb = new StringBuilder();
        for (WebElement breadcrumb : breadcrumbElements) {
            String breadcrumbText = breadcrumb.getText().trim();
            if (!breadcrumbText.isEmpty()) {
                if (actualBreadcrumb.length() > 0) {
                    actualBreadcrumb.append(" / ");
                }
                actualBreadcrumb.append(breadcrumbText);
            }
        }

        // Define the expected breadcrumb
        String expectedBreadcrumb = "Home / Assignments / FL Grade 5 /";

        // Compare the actual breadcrumb with the expected breadcrumb
        if (actualBreadcrumb.toString().equals(expectedBreadcrumb)) {
            System.out.println("Breadcrumb matches the expected value.");
            TestRunner.getTest().log(Status.INFO, "Actual Breadcrumb: " + actualBreadcrumb + " Breadcrumb of Selected page Match with expected value." + expectedBreadcrumb);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Selected Button is Correctly Redirect to Selected Page.");

        } else {
            System.out.println("Breadcrumb does not match.");
            TestRunner.getTest().log(Status.INFO, "Breadcrumb of Selected Page does not match.");
            System.out.println("Actual: " + actualBreadcrumb);
            TestRunner.getTest().log(Status.INFO, "Actual: " + actualBreadcrumb);
            System.out.println("Expected: " + expectedBreadcrumb);
            TestRunner.getTest().log(Status.INFO, "Expected: " + expectedBreadcrumb);
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Selected Button is not Redirect to Selected Page.");
        }
    }

    public void ValidatePrintButtonDisplay() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into Validate and Click on Print Button");
        System.out.println("I'm into Validate and Click on Print Button");

        Thread.sleep(1000);

        WebElement contentFooter = driver.findElement(By.cssSelector(".content-footer-right"));

        List<WebElement> allButtonsAndLinks = contentFooter.findElements(By.xpath(".//a | .//button"));

        boolean isPrintButtonPresent = false;

        for (WebElement element : allButtonsAndLinks) {
            String elementText = element.getText();
            TestRunner.getTest().log(Status.INFO, "Button On Assignment Module: " + elementText);
            System.out.println("Button On Assignment Module: " + elementText);

            if (elementText.equalsIgnoreCase("Print")) {
                isPrintButtonPresent = true;
                element.click();
                System.out.println("Clicked on the Print button.");
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: Clicked on the Print button.");
                break;
            }
        }

// Log if the "Open" button is not found
        if (!isPrintButtonPresent) {
            System.out.println("Print button is not displayed.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: 'Print' button is not displayed.");
        }
    }

    public void ValidatePrintLoading() throws InterruptedException {
//        Thread.sleep(2000);
        WebElement loader = driver.findElement(By.xpath("//span[@class=\"BackdropLoader-title\"]"));
        wait.until(ExpectedConditions.invisibilityOf(loader));
        TestRunner.getTest().log(Status.PASS, "Testcase Passed   :  Printing Action Perform successfully");
    }

    public void ValidateAssignedToButtonDisplay() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into Validate and Click on Assigned To Button");
        System.out.println("I'm into Validate and Click on Assigned To Button");

        Thread.sleep(1000);

        WebElement assignedToButton = driver.findElement(By.xpath("//div[contains(@class,'right-content MuiBox-root')]//button[@name='btn-assigned']"));

        if (assignedToButton.isDisplayed()) {
            assignedToButton.click();
            System.out.println("Clicked on the Assigned To button.");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Clicked on the Assigned To button.");
        } else {

            System.out.println("Assigned To button is not displayed.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: 'Assigned To' button is not displayed.");
        }
    }

    public void ValidateAssignedToButtonRedirectToGradeBookDashboard() throws InterruptedException {

        TestRunner.getTest().log(Status.INFO, "I'm into Validate That Assigned To Button Redirect correctly to GradeBook Dashboard ");
        System.out.println("I'm into Validate That Assigned To Button Redirect correctly to GradeBook Dashboard");

        Thread.sleep(1000);


        List<WebElement> breadcrumbElements = driver.findElements(By.cssSelector(".MuiBreadcrumbs-ol .MuiBreadcrumbs-li"));

        // Build the actual breadcrumb text
        StringBuilder actualBreadcrumb = new StringBuilder();
        for (WebElement breadcrumb : breadcrumbElements) {
            String breadcrumbText = breadcrumb.getText().trim();
            if (!breadcrumbText.isEmpty()) {
                if (actualBreadcrumb.length() > 0) {
                    actualBreadcrumb.append(" / ");
                }
                actualBreadcrumb.append(breadcrumbText);
            }
        }

        // Define the expected breadcrumb
        String expectedBreadcrumb = "Home / Gradebook / FL Grade 5";

        // Compare the actual breadcrumb with the expected breadcrumb
        if (actualBreadcrumb.toString().equals(expectedBreadcrumb)) {
            System.out.println("Breadcrumb matches the expected value.");
            TestRunner.getTest().log(Status.INFO, "Actual Breadcrumb: " + actualBreadcrumb + " Breadcrumb of GradeBook  Match with expected value." + expectedBreadcrumb);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Assigned To Button is Correctly Redirect to Gradebook Page.");

        } else {
            System.out.println("Breadcrumb does not match.");
            TestRunner.getTest().log(Status.INFO, "Breadcrumb of Gradebook Page does not match.");
            System.out.println("Actual: " + actualBreadcrumb);
            TestRunner.getTest().log(Status.INFO, "Actual: " + actualBreadcrumb);
            System.out.println("Expected: " + expectedBreadcrumb);
            TestRunner.getTest().log(Status.INFO, "Expected: " + expectedBreadcrumb);
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Assigned To Button is not Redirect to Gradebook Page.");
        }
    }

    public void ValidateGradeButtonDisplay() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into Validate and Click on Grade Button");
        System.out.println("I'm into Validate and Click on Grade Button");

        Thread.sleep(1000);

        WebElement contentFooter = driver.findElement(By.cssSelector(".content-footer-right"));

        List<WebElement> allButtonsAndLinks = contentFooter.findElements(By.xpath(".//a | .//button"));

        boolean isGradeButtonPresent = false;

        for (WebElement element : allButtonsAndLinks) {
            String elementText = element.getText();
            TestRunner.getTest().log(Status.INFO, "Button On Assignment Module: " + elementText);
            System.out.println("Button On Assignment Module: " + elementText);

            if (elementText.equalsIgnoreCase("Grade")) {
                isGradeButtonPresent = true;
                element.click();
                System.out.println("Clicked on the Grade button.");
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: Clicked on the Grade button.");
                break;
            }
        }

// Log if the "Open" button is not found
        if (!isGradeButtonPresent) {
            System.out.println("Grade button is not displayed.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: 'Grade' button is not displayed.");
        }
    }

    public void ValidateGradeButtonRedirectToGradingTab() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into Validate That Grade Button Redirect correctly to Grading Tab ");
        System.out.println("I'm into Validate That Grade Button Redirect correctly to Grading Tab");

        Thread.sleep(1000);


        List<WebElement> breadcrumbElements = driver.findElements(By.cssSelector(".MuiBreadcrumbs-ol .MuiBreadcrumbs-li"));

        // Build the actual breadcrumb text
        StringBuilder actualBreadcrumb = new StringBuilder();
        for (WebElement breadcrumb : breadcrumbElements) {
            String breadcrumbText = breadcrumb.getText().trim();
            if (!breadcrumbText.isEmpty()) {
                if (actualBreadcrumb.length() > 0) {
                    actualBreadcrumb.append(" / ");
                }
                actualBreadcrumb.append(breadcrumbText);
            }
        }

        // Define the expected breadcrumb
        String expectedBreadcrumb = "Home / Assignments / FL Grade 5 / Grade";

        // Compare the actual breadcrumb with the expected breadcrumb
        if (actualBreadcrumb.toString().equals(expectedBreadcrumb)) {
            System.out.println("Breadcrumb matches the expected value.");
            TestRunner.getTest().log(Status.INFO, "Actual Breadcrumb: " + actualBreadcrumb + " Breadcrumb of Grading Tab  Match with expected value." + expectedBreadcrumb);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Grade Button is Correctly Redirect to Grading Tab.");

        } else {
            System.out.println("Breadcrumb does not match.");
            TestRunner.getTest().log(Status.INFO, "Breadcrumb of Grading Tab does not match.");
            System.out.println("Actual: " + actualBreadcrumb);
            TestRunner.getTest().log(Status.INFO, "Actual: " + actualBreadcrumb);
            System.out.println("Expected: " + expectedBreadcrumb);
            TestRunner.getTest().log(Status.INFO, "Expected: " + expectedBreadcrumb);
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Grade Button is not Redirect to Grading Tab.");
        }
    }

    public void clickAssignNewButton() throws InterruptedException {
        System.out.println("I'm into click on Assign New Button");
        TestRunner.getTest().log(Status.INFO, "I'm into click on Assign New Button");
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[contains(@class, 'assignBtn') and normalize-space()='Assign New']")));
        js.executeScript("arguments[0].click();", buttonAssignNew);

        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Assign New button clicked successfully");
    }


    @FindBy(xpath = "//div[@class='SelectAssignmentTableWrapper']//tbody")
    WebElement assignmentContainerTable;

    public void filterAssignmentsByStatuses() throws InterruptedException {
        String[] statusArray = {"Locked", "Active", "Editing"};

        // Process only the first status (no loop over all statuses)

        String status = statusArray[0];
        TestRunner.getTest().log(Status.INFO, "Filtering Assignments By Status: " + status);

        try {
            WebElement statusDropdown = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(@class, 'MuiSelect-select') and @role='button' or @role='combobox'])[1]")));
            statusDropdown.click();

            List<WebElement> statusOptions = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//ul[@role='listbox']//li")));
            boolean statusFound = false;

            for (WebElement option : statusOptions) {
                String optionText = option.getText().trim();
                if (optionText.equalsIgnoreCase(status)) {
                    option.click();
                    statusFound = true;
                    TestRunner.getTest().log(Status.INFO, "Selected Status: " + optionText);
                    break;
                }
            }

            if (!statusFound) {
                TestRunner.getTest().log(Status.FAIL, "Status not found in the dropdown: " + status);
                throw new RuntimeException("Status not found in the dropdown: " + status);
            }

            Thread.sleep(2000);
            waitForTableToRefreshForAssignments();

            if (isNoDataFoundDisplayed()) {
                TestRunner.getTest().log(Status.INFO, "No Assignments found for the status: " + status);
                System.out.println("No Assignments found for the status: " + status);
                return;
            }

            // Wait until table rows reflect the newly selected status to avoid stale state (e.g., switching Locked -> Active)
            boolean statusAligned = waitUntilRowsMatchStatus(status);
            if (!statusAligned) {
                TestRunner.getTest().log(Status.FAIL, "Assignments did not update to status: " + status + " within timeout.");
                return;
            }

            WebElement questionsTable = wait.until(ExpectedConditions.visibilityOf(assignmentContainerTable));
            List<WebElement> questionRows = questionsTable.findElements(By.xpath(".//tr"));

            boolean allRowsMatchStatus = true;

            for (WebElement row : questionRows) {
                WebElement statusCell = row.findElement(By.xpath(".//td[contains(@class, 'cell-3')]"));
                String rowStatus = statusCell.getText().trim();

                if (!rowStatus.equalsIgnoreCase(status)) {
                    allRowsMatchStatus = false;
                    System.out.println("Row status is: " + rowStatus);
                    TestRunner.getTest().log(Status.FAIL, "Assignment with mismatched status found: " + rowStatus);
                } else {
                    TestRunner.getTest().log(Status.INFO, "Assignment row with status: " + rowStatus);
                }
            }

            if (allRowsMatchStatus) {
                TestRunner.getTest().log(Status.PASS, "All Assignments match the selected status: " + status);
            } else {
                TestRunner.getTest().log(Status.FAIL, "Some Assignments do not match the selected status: " + status);
            }

        } catch (NoSuchElementException | ElementNotInteractableException e) {
            TestRunner.getTest().log(Status.WARNING, "Table not load in current time frame");
        }
    }

    /**
     * Waits until all visible assignment rows show the expected status.
     * Helps when switching filters (e.g., Locked -> Active) where UI needs time to refresh.
     */
    private boolean waitUntilRowsMatchStatus(String expectedStatus) {
        Wait<WebDriver> statusWait = new FluentWait<>(driver)
                .withTimeout(Duration.ofSeconds(15))
                .pollingEvery(Duration.ofMillis(500))
                .ignoring(StaleElementReferenceException.class)
                .ignoring(NoSuchElementException.class);

        try {
            return statusWait.until(webDriver -> {
                List<WebElement> rows = webDriver.findElements(By.xpath("//div[@class='SelectAssignmentTableWrapper']//table//tbody//tr"));
                // If no rows, consider it aligned for the current filter
                if (rows.isEmpty()) {
                    return true;
                }

                for (WebElement row : rows) {
                    WebElement statusCell = row.findElement(By.xpath(".//td[contains(@class, 'cell-3')]"));
                    String rowStatus = statusCell.getText().trim();
                    if (!rowStatus.equalsIgnoreCase(expectedStatus)) {
                        return null; // keep waiting
                    }
                }
                return true;
            });
        } catch (TimeoutException e) {
            return false;
        }
    }

    private boolean isNoDataFoundDisplayed() {
        try {
            WebElement noDataFound = driver.findElement(By.xpath("//div[contains(@class, 'SelectAssignmentTableWrapper')]//div[contains(text(),'No Detail Found')]"));
            return noDataFound.isDisplayed();
        } catch (NoSuchElementException e) {
            return false;
        }
    }

    private void waitForTableToRefreshForAssignments() throws InterruptedException {
        try {
            WebElement questionsTable = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='SelectAssignmentTableWrapper']//tbody")));

            List<WebElement> rowsBeforeRefresh = questionsTable.findElements(By.xpath(".//tr"));
            System.out.println("Number of rows before refresh: " + rowsBeforeRefresh.size());

            Thread.sleep(2000);

            List<WebElement> rowsAfterRefresh = questionsTable.findElements(By.xpath(".//tr"));
            System.out.println("Number of rows after refresh: " + rowsAfterRefresh.size());

            if (rowsBeforeRefresh.size() != rowsAfterRefresh.size()) {
                System.out.println("Table has refreshed. Number of rows before refresh: " + rowsBeforeRefresh.size() + ", after refresh: " + rowsAfterRefresh.size());
                TestRunner.getTest().log(Status.INFO, "Table has refreshed. Number of rows before refresh: " + rowsBeforeRefresh.size() + ", after refresh: " + rowsAfterRefresh.size());
            } else {
                System.out.println("Table did not refresh as expected. Rows before: " + rowsBeforeRefresh.size() + ", Rows after: " + rowsAfterRefresh.size());
            }

            for (WebElement row : rowsAfterRefresh) {
                System.out.println("Table Row: " + row.getText());
            }

        } catch (NoSuchElementException | TimeoutException e) {
            try {
                WebElement noDataFound = driver.findElement(By.xpath("//div[contains(@class, 'SelectAssignmentTableWrapper')]//div[contains(text(),'No Detail Found')]"));
                String statusHaveNoData = noDataFound.getText();
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: 'No Detail Found' message is displayed as expected. " + statusHaveNoData);
                System.out.println("Test Case Passed: 'No Detail Found' message is displayed. " + statusHaveNoData);
            } catch (NoSuchElementException nestedException) {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Neither table data nor 'No Detail Found' message found.");
                System.out.println("Test Case Failed: Neither table data nor 'No Detail Found' message found.");
            }
        }
    }

    public void refresh_Page() {
        driver.navigate().refresh();
    }

    public void filterAssignmentByType() throws InterruptedException {
        System.out.println("I'm filtering assignments based on Type");
        TestRunner.getTest().log(Status.INFO, "I'm filtering assignments based on Type");

        Thread.sleep(2000);

        String[] statusArray = {
                "Artistic Expression", "Digital Student Book", "ExperTrack",
                "Let's Practice", "Primary Source Analysis", "Vocabulary Quiz", "Writing Prompt"
        };

        for (String status : statusArray) {
            TestRunner.getTest().log(Status.INFO, "Filtering Assignments By Type: " + status);

            try {

                wait.until(ExpectedConditions.invisibilityOfElementLocated(
                        By.cssSelector(".MuiBackdrop-root")));

                By statusDropdownLocator = By.xpath("(//div[(contains(@class, 'MuiSelect-select') and @role='button') or @role='combobox'])[2]");
                By listBoxOptionsLocator = By.xpath("//ul[@role='listbox']//li");

                Wait<WebDriver> fluentWait = new FluentWait<>(driver)
                        .withTimeout(Duration.ofSeconds(20))
                        .pollingEvery(Duration.ofMillis(500))
                        .ignoring(StaleElementReferenceException.class)
                        .ignoring(NoSuchElementException.class);

                WebElement statusDropdown = fluentWait.until(webDriver -> {
                    WebElement dropdown = webDriver.findElement(statusDropdownLocator);
                    return (dropdown.isDisplayed() && dropdown.isEnabled()) ? dropdown : null;
                });

                statusDropdown.click();

                Thread.sleep(1000);
                List<WebElement> statusOptions = fluentWait.until(webDriver -> {
                    List<WebElement> options = webDriver.findElements(listBoxOptionsLocator);
                    return options.isEmpty() ? null : options;
                });

                boolean statusFound = false;

                for (WebElement option : statusOptions) {
                    String optionText = option.getText().trim();
                    if (optionText.equalsIgnoreCase(status)) {
                        option.click();
                        statusFound = true;
                        TestRunner.getTest().log(Status.INFO, "Selected Type: " + optionText);
                        break;
                    }
                }

                if (!statusFound) {
                    // If status is not found in dropdown, log and skip silently
                    TestRunner.getTest().log(Status.INFO, "Type not found in dropdown, skipping: " + status);
                    System.out.println("Type not found in dropdown, skipping: " + status);

                    Actions actions = new Actions(driver);
                    actions.sendKeys(Keys.ESCAPE).perform();

                    Thread.sleep(2000);

                    // Close dropdown if still open (optional, depends on your UI)
                    statusDropdown.click();  // click again to close dropdown
                    continue;  // go to next status
                }

                Thread.sleep(2000);
                waitForTableToRefreshForAssignments();

                if (isNoDataFoundDisplayed()) {
                    TestRunner.getTest().log(Status.INFO, "No Assignments found for the Type: " + status);
                    System.out.println("No Assignments found for the Type: " + status);
                    continue;
                }

                WebElement questionsTable = wait.until(ExpectedConditions.visibilityOf(assignmentContainerTable));
                List<WebElement> questionRows = questionsTable.findElements(By.xpath(".//tr"));

                boolean allRowsMatchStatus = true;

                for (WebElement row : questionRows) {
                    WebElement statusCell = row.findElement(By.xpath(".//td[contains(@class, 'cell-1')]"));
                    String rowStatus = statusCell.getText().trim();

                    if (!rowStatus.equalsIgnoreCase(status)) {
                        allRowsMatchStatus = false;
                        System.out.println("Row Type is: " + rowStatus);
                        TestRunner.getTest().log(Status.FAIL, "Assignment with mismatched Type found: " + rowStatus);
                    } else {
                        TestRunner.getTest().log(Status.INFO, "Assignment row with Type: " + rowStatus);
                    }
                }

                if (allRowsMatchStatus) {
                    TestRunner.getTest().log(Status.PASS, "All Assignments match the selected Type: " + status);
                } else {
                    TestRunner.getTest().log(Status.FAIL, "Some Assignments do not match the selected Type: " + status);
                }

            } catch (NoSuchElementException | ElementNotInteractableException e) {
                TestRunner.getTest().log(Status.WARNING, "Table not load in current time frame");
            }
        }
    }


    @FindBy(xpath = "(//div[contains(@class, 'MuiSelect-select') and @role='button' or @role='combobox'])[3]")
    WebElement dropDown_SelectCourse;

    public void selected_Course_Assign_New() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm in to select Course from Assign New");

        try {
            // Wait for page to be fully loaded
            helper.waitForPageToLoad();
            
            // Wait for any loading backdrops/spinners to disappear
            try {
                wait.until(ExpectedConditions.invisibilityOfElementLocated(By.className("MuiBackdrop-root")));
            } catch (Exception e) {
                // If no backdrop found, continue
                System.out.println("No loading backdrop found or already disappeared");
            }
            
            // Wait for any progress indicators to disappear
            try {
                wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//span[@role='progressbar']")));
            } catch (Exception e) {
                // If no progressbar found, continue
                System.out.println("No progress indicator found or already disappeared");
            }
            
            // Now wait for the dropdown to be clickable
            wait.until(ExpectedConditions.elementToBeClickable(dropDown_SelectCourse));

            dropDown_SelectCourse.click();

            Thread.sleep(1000);

            WebElement listCourse = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[@role='listbox']")));
            List<WebElement> optionsCourses = listCourse.findElements(By.xpath(".//li"));

            System.out.println("Courses List is: " + optionsCourses.size());
            TestRunner.getTest().log(Status.INFO, "Courses List is: " + optionsCourses.size());

            if (optionsCourses.isEmpty()) {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: No options found in the courses dropdown");
                throw new RuntimeException("No options found in the courses dropdown");
            } else {
                System.out.println("Courses:");
                for (WebElement course : optionsCourses) {
                    System.out.println(course.getText());
                }

                if (!optionsCourses.isEmpty()) {
                    Random random = new Random();
                    int randomCourse = random.nextInt(optionsCourses.size());
                    WebElement selectedOption = optionsCourses.get(randomCourse);
                    selectedOption.click();
                    String selectedCourse = selectedOption.getText();
                    System.out.println("Selected Course: " + selectedCourse);
                    TestRunner.getTest().log(Status.INFO, "Selected Course on Assign New : " + selectedCourse);
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed   : Course Select Successfully on Assign New");
                }
            }

        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Unable to click the course dropdown. It may not be present due to UI break.");
        }


    }


    public String randomAssignmentNameAssignScreen;

    public void getRandomAssignmentName() throws InterruptedException {
        System.out.println("I'm into get Random Assignment Name From Table");
        TestRunner.getTest().log(Status.INFO, "I'm into get Random Assignment Name From Table");
        Thread.sleep(2000);

        List<WebElement> assignmentElements = driver.findElements(By.xpath("//div[@class='tabelbodydata-Container']//table//tbody//td[contains(@class, 'cell-0')]//div"));

        if (!assignmentElements.isEmpty()) {
            Random random = new Random();
            int randomIndex = random.nextInt(assignmentElements.size());
            randomAssignmentNameAssignScreen = assignmentElements.get(randomIndex).getText();

            System.out.println("Random Assignment Name: " + randomAssignmentNameAssignScreen);
            TestRunner.getTest().log(Status.INFO, " Random Assignment Name From Table is: " + randomAssignmentNameAssignScreen);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Assignment Name Get Successfully From Table");

        } else {
            System.out.println("No assignments found in the column.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: No Assignment Found on Assign Screen");
        }

    }

    public void searchAssignmentAndValidate()  throws InterruptedException{

        System.out.println("I'm Into Search Assignment Name In SearchBox: " + randomAssignmentNameAssignScreen);
        TestRunner.getTest().log(Status.INFO, "I'm Into Search Assignment Name In SearchBox: " + randomAssignmentNameAssignScreen);

        if (randomAssignmentNameAssignScreen == null || randomAssignmentNameAssignScreen.trim().isEmpty()) {
            TestRunner.getTest().log(Status.FAIL, "Assignment name is null or empty. Cannot perform search.");

        }

        try {
            WebElement searchBox = driver.findElement(By.xpath("//input[@placeholder='Search Assignment']"));

            if (searchBox.isDisplayed()) {

                String searchedName = randomAssignmentNameAssignScreen;
                searchBox.sendKeys(searchedName);
                searchBox.sendKeys(Keys.ENTER);
                TestRunner.getTest().log(Status.PASS, "Assignment name entered successfully in the search box: " + searchedName);

                Thread.sleep(2000);

                System.out.println("Check, Validate That Assignment In Search and Assignment In Table Match");
                TestRunner.getTest().log(Status.INFO,"Check, Validate That Assignment In Search and Assignment In Table Match");

                WebElement resultNameElement = driver.findElement(
                        By.xpath("//div[@class='SelectAssignmentTableWrapper']//table//tbody//tr/td[2]/div")
                );
                String resultName = resultNameElement.getText();

                // Step 3: Compare
                if (resultName.equalsIgnoreCase(searchedName)) {
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed: Searched Assignment matched successfully: " + resultName);
                } else {
                    TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Searched Assignment did not match. Expected: " + searchedName + ", Actual: " + resultName);

                }
            } else {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Search box is not displayed.");
            }
        } catch (NoSuchElementException e) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Search box or result element not found.");
        }
    }



    public void refreshingPageForReloadData() {
        driver.navigate().refresh();
    }

    @FindBy(xpath = "//div[@class='SelectAssignmentTableWrapper']//table//tbody")
    WebElement tableAssignNew;

    Random random = new Random();

    public void SelectAssignmentInShowAllTabAssignScreen() {
        By tableLocator = By.xpath("//div[@class='SelectAssignmentTableWrapper']//table//tbody");
        By checkboxLocator = By.xpath(".//td[contains(@class,'checkboxSelectionTableCell')]//input");

        Wait<WebDriver> fluentWait = new FluentWait<>(driver)
                .withTimeout(Duration.ofSeconds(20))
                .pollingEvery(Duration.ofMillis(500))
                .ignoring(StaleElementReferenceException.class)
                .ignoring(NoSuchElementException.class);

        List<WebElement> selectAssignmentCheckBoxes = fluentWait.until(webDriver -> {
            WebElement tableNewAssignment = webDriver.findElement(tableLocator);
            List<WebElement> checkBoxes = tableNewAssignment.findElements(checkboxLocator);
            if (checkBoxes.isEmpty()) {
                throw new NoSuchElementException("No Assignment checkbox found");
            }
            return checkBoxes;
        });

        System.out.println("Total assignments are: " + selectAssignmentCheckBoxes.size());

        int randomAssignment = random.nextInt(selectAssignmentCheckBoxes.size());

        fluentWait.until(webDriver -> {
            WebElement tableNewAssignment = webDriver.findElement(tableLocator);
            List<WebElement> checkBoxes = tableNewAssignment.findElements(checkboxLocator);
            if (checkBoxes.size() <= randomAssignment) {
                return null;
            }
            WebElement randomCheckbox = checkBoxes.get(randomAssignment);
            js.executeScript("arguments[0].scrollIntoView({block: 'center'});", randomCheckbox);
            js.executeScript("arguments[0].click();", randomCheckbox);
            return true;
        });

        System.out.println("A random checkbox has been selected.");
        TestRunner.getTest().log(Status.PASS, "Test Case Passed   :   Assignment Select Successfully ");
    }


    @FindBy(xpath = "//button[normalize-space()='Next']")
    WebElement buttonNext;

    public void ClickOnNextButtonAssignScreen() {

        wait.until(ExpectedConditions.elementToBeClickable(buttonNext));
        if (buttonNext.isDisplayed() && buttonNext.isEnabled()) {
            buttonNext.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  Next button clicked successfully");

        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  Next Button not Display or clickable ");

        }
    }

    public void clickMyAssessmentSection() throws InterruptedException {
        System.out.println("I'm Into Validate and Click on My Assessment Section");
        TestRunner.getTest().log(Status.INFO, "I'm Into Validate and Click on My Assessment Section");
        Thread.sleep(1000);

        WebElement my_assessment = driver.findElement(By.xpath("//span[normalize-space()='My Assessments']"));

        if (my_assessment.isDisplayed()){
            my_assessment.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed : My Assessment Button Click successfully");
        }else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : My Assessment Button Not Found on Assign Screen");

        }

    }


    public void ValidateByQuestionButtonDisplay() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into Validate and Click on By Question Button");
        System.out.println("I'm into Validate and Click on By Question Button");

        Thread.sleep(1000);

        WebElement contentFooter = driver.findElement(By.cssSelector(".content-footer-right"));

        List<WebElement> allButtonsAndLinks = contentFooter.findElements(By.xpath(".//a | .//button"));

        boolean isSelectedButtonPresent = false;

        for (WebElement element : allButtonsAndLinks) {
            String elementText = element.getText();
            TestRunner.getTest().log(Status.INFO, "Button On Assignment Module: " + elementText);
            System.out.println("Button On Assignment Module: " + elementText);

            if (elementText.equalsIgnoreCase("By Question")) {
                isSelectedButtonPresent = true;
                element.click();
                System.out.println("Clicked on the By Student button.");
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: Clicked on the By Question button.");
                break;
            }
        }

// Log if the "Open" button is not found
        if (!isSelectedButtonPresent) {
            System.out.println("By Question button is not displayed.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: 'By Question' button is not displayed.");
        }
    }


    public void ValidateByQuestionButtonRedirectToByQuestionPage() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into Validate That By Question Button Redirect correctly to By Question ");
        System.out.println("I'm into Validate That By Question Button Redirect correctly to By Question");

        Thread.sleep(2000);

//        WebElement breadCrumb = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ol[contains(@class, 'MuiBreadcrumbs')]")));
//        System.out.println("BreadCrumb is: " + breadCrumb.getText());

        List<WebElement> breadcrumbElements = driver.findElements(By.cssSelector(".MuiBreadcrumbs-ol .MuiBreadcrumbs-li"));

        // Build the actual breadcrumb text
        StringBuilder actualBreadcrumb = new StringBuilder();
        for (WebElement breadcrumb : breadcrumbElements) {
            String breadcrumbText = breadcrumb.getText().trim();
            if (!breadcrumbText.isEmpty()) {
                if (actualBreadcrumb.length() > 0) {
                    actualBreadcrumb.append(" / ");
                }
                actualBreadcrumb.append(breadcrumbText);
            }
        }

        // Define the expected breadcrumb
        String expectedBreadcrumb = "Home / Assignments / FL Grade 5 /";

        // Compare the actual breadcrumb with the expected breadcrumb
        if (actualBreadcrumb.toString().equals(expectedBreadcrumb)) {
            System.out.println("Breadcrumb matches the expected value.");
            TestRunner.getTest().log(Status.INFO, "Actual Breadcrumb: " + actualBreadcrumb + " Breadcrumb of Selected page Match with expected value." + expectedBreadcrumb);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Selected Button is Correctly Redirect to Selected Page.");

        } else {
            System.out.println("Breadcrumb does not match.");
            TestRunner.getTest().log(Status.INFO, "Breadcrumb of Selected Page does not match.");
            System.out.println("Actual: " + actualBreadcrumb);
            TestRunner.getTest().log(Status.INFO, "Actual: " + actualBreadcrumb);
            System.out.println("Expected: " + expectedBreadcrumb);
            TestRunner.getTest().log(Status.INFO, "Expected: " + expectedBreadcrumb);
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Selected Button is not Redirect to Selected Page.");
        }
    }

}

