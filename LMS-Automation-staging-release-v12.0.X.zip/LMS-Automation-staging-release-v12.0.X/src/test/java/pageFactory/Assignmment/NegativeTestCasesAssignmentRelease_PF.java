package pageFactory.Assignmment;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.en.And;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

public class NegativeTestCasesAssignmentRelease_PF {
    WebDriverWait wait;
    WebDriver driver;
    Helper helper;


    public  NegativeTestCasesAssignmentRelease_PF(WebDriver driver){
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        helper = new Helper();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
    }


    @FindBy(xpath = "//input[@name='isOpenToAnyStudent']")
    WebElement input_OpenToAnyStudent;

    @FindBy(xpath = "//input[@name='title']")
    WebElement edt_AssignmentTitle;

    @FindBy(xpath = "//button[@name='btn-assign-assignment']")
    WebElement btn_AssignAssignment;

    @FindBy(xpath = "//label[contains(text(),'Assign to')]/parent::div")
    WebElement dropDown_AssignTo;

    @FindBy(xpath = "//label[contains(text(),'Select Students')]/following-sibling::div")
    WebElement dropDown_SelectStudent;

    @FindBy(xpath = "(//h2[contains(@class, 'MuiDialogTitle-root')])[2]")
    WebElement alert_success;

    public void SelectUnitAndAssignment() throws InterruptedException {
       System.out.println(" Selecting Unit ");

       Thread.sleep(2000);
       List<WebElement> totalUnits = driver.findElements(By.xpath("(//div[contains(@class, 'navigation')])[2]//a"));

       String totalUnitName = null;
       for (WebElement totalUnit : totalUnits) {
           totalUnitName = totalUnit.getText();
           System.out.println("Unit Name: " + totalUnitName);

           if (totalUnitName.contains("End of Year Resources")) {
               totalUnit.click();
               break;
           }
       }
        TestRunner.getTest().log(Status.PASS, "Test Case passed : " + totalUnitName + " Select Successfully");


    }
   public void SelectAssignment() throws InterruptedException{
       System.out.println("Selecting Assignment ");

       Thread.sleep(2000);
       WebElement listContentPlayer = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@id='ContentPlayerMainPanel']")));

       if (listContentPlayer.isDisplayed() && listContentPlayer.isEnabled()) {
           WebElement btnAssignForSpecificAssignment = listContentPlayer.findElement(By.xpath("(//div[contains(@class, 'MuiBox-root')]//button[contains(text(), 'Assign')])[1]"));
           btnAssignForSpecificAssignment.click();
           TestRunner.getTest().log(Status.PASS, "Test Case Passed : Assign Button click for Assignment");

       }else {
           TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Right Panel not Display");
//           throw new RuntimeException("Right Panel not Display.");

       }
   }

   public void AssignmentDialogueBox() throws InterruptedException{
       WebElement dialogAssignment = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@role='dialog']")));
       if (dialogAssignment.isDisplayed()) {
           TestRunner.getTest().log(Status.PASS, "Test case Passed : Assign Dialogue Box Display");
       }else {
           TestRunner.getTest().log(Status.FAIL, "Test Case failed: Assign Dialogue box not Display");
//           throw new RuntimeException("Assign Dialogue box not Display.");

       }
   }

   public void BlankAssignmentTitle() throws InterruptedException{
       edt_AssignmentTitle.click();
       ((JavascriptExecutor) driver).executeScript("arguments[0].value='';", edt_AssignmentTitle);
       edt_AssignmentTitle.clear();
   }

   public void AssignButton() throws InterruptedException{
       if (btn_AssignAssignment.isDisplayed() && btn_AssignAssignment.isEnabled()){
           TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Assign Button should be disable because some fields are empty");
           btn_AssignAssignment.click();
           VerifyDialogueBox();
           helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
       }else {
           TestRunner.getTest().log(Status.PASS, "Test case Passed: Assign button is disable");
           helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
       }
   }

   public void AssignToField() throws InterruptedException{

       dropDown_AssignTo.click();

       WebElement assignToOptions = dropDown_AssignTo.findElement(By.xpath("//ul[@role='listbox']"));
       Thread.sleep(2000);

       List<WebElement> totalClasses = assignToOptions.findElements(By.tagName("li"));
       System.out.println("Total Classes: " + totalClasses.size());

       for (WebElement totalClass : totalClasses) {
           String totalClassName = totalClass.findElement(By.xpath(".//span[contains(@class, 'MuiListItemText-primary')]")).getText();
           System.out.println("Total Class: " + totalClassName);
           System.out.println("Skipping selection for negative test case.");
       }
       Actions actions = new Actions(driver);
       actions.sendKeys(Keys.ESCAPE).build().perform();
   }

   public void ToggleButton() throws InterruptedException{
       input_OpenToAnyStudent.click();
   }

   public void SelectStudentFiled() throws InterruptedException{
       dropDown_SelectStudent.click();
       Thread.sleep(1000);

       List<WebElement> SelectStudentOptions = dropDown_SelectStudent.findElements(By.xpath("//ul[@role='listbox']//input"));

       if (SelectStudentOptions.isEmpty()) {
           System.out.println("No students found in the selected class. Changing class in AssignTo dropdown.");
       } else {
           System.out.println("No student will be selected for this negative test.");

           Actions actions = new Actions(driver);
           actions.sendKeys(Keys.ESCAPE).build().perform();
       }
   }

   public void VerifyDialogueBox()  {
        try {

           WebElement popover = driver.findElement(By.xpath("(//h2[contains(@class, 'MuiDialogTitle-root')])[2]"));
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Select Student Field is empty. But Success Dialogue Box Appear");

        }catch (NoSuchElementException e){
            TestRunner.getTest().log(Status.PASS, "Test Case Passed : Success Dialogue not appear Because some fields are empty");

        }
    }

}
