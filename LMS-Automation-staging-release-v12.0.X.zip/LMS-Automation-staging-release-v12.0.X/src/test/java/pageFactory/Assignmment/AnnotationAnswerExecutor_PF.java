package pageFactory.Assignmment;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.ElementNotInteractableException;

import java.awt.*;
import java.time.Duration;
import java.util.List;
import java.util.*;

import static pageFactory.Assignmment.CorrectAnswerExecutor_PF.assignmentNameForCorrect;
import static pageFactory.Assignmment.CorrectAnswerExecutor_PF.questionIDs;

public class AnnotationAnswerExecutor_PF {

    String baseUrl = Configurations.App_url;

    Helper helper;
    StudentExecutor_PF studentExecutor;
    CorrectAnswerExecutor_PF correctAnswerExecutor_pf;
    Actions actions;
    public WebDriverWait wait;
    WebDriver driver;
    String questionID = null;

    @FindBy(xpath = "//div[@aria-labelledby='simple-tab-2']")
    WebElement panel_Assignments;

    @FindBy(xpath = "//nav[@aria-label='pagination navigation']")
    WebElement nav_Pagination;

    @FindBy(xpath = "//button[@aria-label='Go to next page']")
    WebElement btn_NavNextPage;

    public AnnotationAnswerExecutor_PF(WebDriver driver) {
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        helper = new Helper();
        studentExecutor = new StudentExecutor_PF(driver);
        correctAnswerExecutor_pf = new CorrectAnswerExecutor_PF(driver);
        actions = new Actions(driver);
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(30));
    }

    public void SelectAssignmentForAnnotationCorrectAnswers() throws InterruptedException, AWTException {
        TestRunner.getTest().log(Status.INFO, "Verifying assignment annotation in student assignment attempt");
        if (!panel_Assignments.isDisplayed()) {
            TestRunner.getTest().log(Status.FAIL, "Assignments panel is not displayed");
            throw new NoSuchElementException("Assignments panel is not displayed");
        }

        // Search for the assignment by keyword
        WebElement searchBar = driver.findElement(By.xpath("//input[@placeholder='Search Assignment by Title']"));
        searchBar.clear();
        searchBar.click();
        searchBar.sendKeys(assignmentNameForCorrect.get()); // Enter assignment name
        searchBar.sendKeys(Keys.ENTER);
        Thread.sleep(3000);

        WebElement searchBtn= driver.findElement(By.xpath("//button[contains(@class,'MuiButtonBase-root MuiIconButton-root MuiIconButton-edgeStart')]"));
        searchBtn.click();
        System.out.println("Search Button Click Successfully");
        Thread.sleep(3000);

        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@aria-labelledby='simple-tab-2']")));
        Thread.sleep(2000);
        List<WebElement> totalAssignments = panel_Assignments.findElements(By.xpath(".//div[contains(@class, 'MuiGrid-container')]"));
        System.out.println("Total Assignments: " + totalAssignments.size());
        System.out.println("Attempting to find assignment: " + assignmentNameForCorrect.get());
        TestRunner.getTest().log(Status.INFO, "Looking for assignment: " + assignmentNameForCorrect.get());

        boolean assignmentFound = false;
        for (WebElement assignment : totalAssignments) {
            WebElement assignmentNameElement = assignment.findElement(By.xpath(".//div[contains(@class, 'notranslate')]"));
            String assignmentName = assignmentNameElement.getText();
            System.out.println("Assignment Name: " + assignmentName);

            if (assignmentName.equals(assignmentNameForCorrect.get())) {
                System.out.println("Found assignment: " + assignmentName);
                assignmentFound = true;
                try {
                    WebElement startOrResumeButton = assignment.findElement(By.xpath(".//div[@statustype='START' or @statustype='RESUME']"));
                    startOrResumeButton.click();
                    TestRunner.getTest().log(Status.PASS, "Successfully started assignment: " + assignmentName);
                    System.out.println("Assignment started");
                    Thread.sleep(3000);
                    studentExecutor.handleTeacherInstructionsDialog();
                    AttemptAndSubmitAssignmentWithCorrectAnswersAppliedAnnotation();
                    Thread.sleep(2000);
                } catch (NoSuchElementException e) {
                    System.out.println("START/RESUME button not found for assignment: " + assignmentName);
                    return;
                }

                refreshPage();
                Thread.sleep(3000);
                studentExecutor.dialogBox_ImpAnnouncement();


                try {
                    WebElement tabOpenAssignments = driver.findElement(By.xpath("//div[@aria-labelledby='simple-tab-2']"));

                    List<WebElement> totalAssignment = tabOpenAssignments.findElements(By.xpath(".//div[contains(@class, 'notranslate')]"));
                    System.out.println("Total Assignments after refresh: " + totalAssignment.size());

                    if (!totalAssignment.isEmpty()) {
                        for (WebElement assignmentText : totalAssignment) {
                            System.out.println("Assignment Text: " + assignmentText.getText());

                        }
                    }
                } catch (TimeoutException e) {
                    System.out.println("Failed to load assignments after refresh. Retrying...");
                }

                break;
            } else {
                System.out.println("Assignment not found: " + assignmentName);

            }
        }

        if (!assignmentFound) {
            System.out.println("Assignment not found : " + assignmentNameForCorrect.get());
            TestRunner.getTest().log(Status.FAIL, "Assignment not found in the list. Using search bar to find: " + assignmentNameForCorrect.get());
        }
    }

    private void refreshPage() {
        driver.navigate().to(baseUrl);
    }

    public void AttemptAndSubmitAssignmentWithCorrectAnswersAppliedAnnotation() throws InterruptedException, AWTException {
        TestRunner.getTest().log(Status.INFO, "Attempting and submit the assignment with all applied annotations");
        if (!isPaginationDisplayed()) {
            studentExecutor.AssignmentSubmitAsCompleted();
            return;
        }

        try {
            List<WebElement> questionButtons = nav_Pagination.findElements(By.xpath("//button[contains(@aria-label, 'Go to page')]"));

            for (WebElement questionButton : questionButtons) {
                String questionText = questionButton.getText();
                System.out.println("Question: " + questionText);
                TestRunner.getTest().log(Status.INFO, "Total Questions: " + questionText);
            }

            // Clear the thread-specific question IDs list
            questionIDs.get().clear();

            TestRunner.startTest("Attempt assignment with all correct answers");
            while (btn_NavNextPage.isEnabled()) {
                Thread.sleep(2000);
                AttemptAssignmentWithCorrectAnswers();
                btn_NavNextPage.click();
                Thread.sleep(2000);
            }

            System.out.println("Assignment attempted with all correct answers. Now submit the assignment");
            TestRunner.getTest().log(Status.INFO, "Assignment submitted with all correct answers. Now submit the assignment");
            studentExecutor.AssignmentSubmitAsCompleted();
        } catch (NoSuchElementException | ElementNotInteractableException | TimeoutException e) {
            System.out.println("No Question found.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : No Question found or Question not visible");
        }
    }

    private boolean isPaginationDisplayed() {
        try {
            return nav_Pagination.isDisplayed();
        } catch (NoSuchElementException | ElementNotInteractableException | TimeoutException e) {
            return false;
        }
    }

    public void AttemptAssignmentWithCorrectAnswers() throws InterruptedException, AWTException {
        TestRunner.getTest().log(Status.INFO, "Attempting all questions with correct answers applied all annotations");
        System.out.println("I'm in attempting all questions with correct answers");
        Thread.sleep(1000);

        checkHighlighterOfAssignment();
        Thread.sleep(2000);
        checkAnnotateTextOfAssignment();

        WebElement questionPlayer = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("lesson-player-ifram")));
        driver.switchTo().frame(questionPlayer);
        WebElement QuestionBody = driver.findElement(By.xpath("//div[contains(@class, 'LessonPlayerRoot')]"));

        WebElement QuestionPlayer = null;

        try {
            List<WebElement> MultiParts = QuestionBody.findElements(By.xpath("//div[contains(@class, 'planComponentQuestion')]"));
            System.out.println("Total number of multi-part on this page: " + MultiParts.size());
            TestRunner.getTest().log(Status.INFO, "Total part of question (if multipart question exists): " + MultiParts.size());

            for (WebElement part : MultiParts) {
                QuestionPlayer = part.findElement(By.xpath(".//div[contains(@class, 'QuestionPlayer')]"));

                System.out.println("Question is found");
                String questionType = QuestionPlayer.getAttribute("data-type");
                System.out.println("Question Type is: " + questionType);
                TestRunner.getTest().log(Status.INFO, "Attempted question type is: " + questionType);

                WebElement questionRoot = QuestionPlayer.findElement(By.xpath(".//div[contains(@class, 'question-root')]"));
                questionID = questionRoot.getAttribute("data-question-id");
                System.out.println("Question ID is: " + questionID);
                TestRunner.getTest().log(Status.INFO, "Attempted question ID is: " + questionID);

                System.out.println("I'm in to store Question ID's For Verify sequence : " + questionID);
                TestRunner.getTest().log(Status.INFO, "I'm in to store Question ID's For Verify sequence : " + questionID);

                // Retrieve the thread-specific list and add the question ID
                questionIDs.get().add(questionID);
                System.out.println("Question ID's: " + questionIDs.get());

                switch (questionType) {
                    case "extended-text-interaction" -> studentExecutor.QuestionExtendedTextInteraction();
                    case "choice-interaction-single" -> correctAnswerExecutor_pf.QuestionChoiceInteractionSingleAccurate(questionRoot, questionID);
                    case "choice-interaction" -> correctAnswerExecutor_pf.QuestionChoiceInteractionsAccurate(questionRoot,questionID);
                    case "match-dragdrop-interaction" -> correctAnswerExecutor_pf.QuestionMatchDragdropInteractionAccurate(questionRoot,questionID);
                    case "inline-choice-select-interaction" -> correctAnswerExecutor_pf.QuestionInlineChoiceSelectInteractionAccurate(questionRoot,questionID);
                    case "gap-match-interaction" -> correctAnswerExecutor_pf.QuestionGapMatchInteractionAccurate(questionID);
                    case "choice-imagelabel-select-interaction" -> correctAnswerExecutor_pf.QuestionChoiceImageLabelSelectInteractionAccurate(questionRoot,questionID);
                    case "inline-choice-text-interaction" -> studentExecutor.QuestionInlineChoiceTextInteraction();
                    case "inline-choice-spelling-interaction" -> correctAnswerExecutor_pf.QuestionInlineChoiceSpellingInteractionAccurate(questionRoot,questionID);
                    case "graphic-gap-match-interaction" -> correctAnswerExecutor_pf.QuestionGraphicGapMatchInteractionAccurate(questionID);
                    case "order-interaction" -> correctAnswerExecutor_pf.QuestionOrderInteractionAccurate(questionID);
                    case "drawing-interaction" -> studentExecutor.QuestionDrawingInteraction();
                    case "match-interaction" -> correctAnswerExecutor_pf.QuestionMatchInteractionAccurate(questionRoot,questionID);
                    case "upload-interaction" -> studentExecutor.QuestionUploadInteraction();
                    default -> {
                    }
                }

            }
        } catch (NoSuchElementException e) {
            System.out.println("This is a content player question and have no any data type question");
            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
        } finally {
            driver.switchTo().defaultContent();
        }
    }

    public void checkAnnotateTextOfAssignment() {
        TestRunner.getTest().log(Status.INFO, "Check shows annotate text of each assignment");

        try {
            // Wait for Annotate Text button - try multiple locators
            WebElement btnAnnotateText = wait.until(ExpectedConditions.elementToBeClickable(
                    By.xpath("//div[@class='button-group annotationTool']//button[@aria-label='Annotate Text']")));
            helper.scrollToElement(driver, btnAnnotateText);

            String classBeforeClick = btnAnnotateText.getAttribute("class");
            TestRunner.getTest().log(Status.INFO, "Class before click: " + classBeforeClick);

            if (classBeforeClick.contains("inactive-tool")) {
                btnAnnotateText.click();
                TestRunner.getTest().log(Status.PASS, "Annotate Text button clicked successfully");
                Thread.sleep(1000);

                String classAfterClick = btnAnnotateText.getAttribute("class");
                TestRunner.getTest().log(Status.INFO, "Class after click: " + classAfterClick);

                if (classAfterClick.contains("active-tool")) {
                    TestRunner.getTest().log(Status.PASS, "'Annotate Text' button is now active.");

                    WebElement annotateTextMenu = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@data-popper-placement='bottom-start']")));
                    if (annotateTextMenu.isDisplayed()) {
                        TestRunner.getTest().log(Status.PASS, "'Annotate Text' menu is now visible.");

                        List<WebElement> annotateTextOptions = annotateTextMenu.findElements(By.xpath(".//li"));
                        TestRunner.getTest().log(Status.INFO, "Total number of menu items (li): " + annotateTextOptions.size());
                        System.out.println("Total number of menu items (li): " + annotateTextOptions.size());

                        List<WebElement> validOptions = new ArrayList<>();

                        for (WebElement option : annotateTextOptions) {
                            String optionAriaLabel = option.getAttribute("aria-label");
                            System.out.println("Main menu lists: " + optionAriaLabel);

                            if (optionAriaLabel != null &&
                                    (optionAriaLabel.contains("pencil") || optionAriaLabel.contains("brush paint") || optionAriaLabel.contains("add shapes")
                                            || optionAriaLabel.contains("edge width") || optionAriaLabel.contains("add graph elements"))) {
                                validOptions.add(option);
                            }
                        }

                        if (!validOptions.isEmpty()) {
                            Random rand = new Random();
                            WebElement selectedOption = validOptions.get(rand.nextInt(validOptions.size()));

                            String selectedOptionText = selectedOption.getAttribute("aria-label");
                            TestRunner.getTest().log(Status.INFO, "Selected option: " + selectedOptionText);

                            selectedOption.click();
                            TestRunner.getTest().log(Status.PASS, "Annotate option selected: " + selectedOptionText);
                            System.out.println("Annotate option selected: " + selectedOptionText);

                            if (selectedOptionText.contains("add shapes") || selectedOptionText.contains("edge width") || selectedOptionText.contains("add graph elements")) {
                                Thread.sleep(2000);
                                WebElement submenu = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@data-popper-placement='left']")));
                                List<WebElement> submenuItems = submenu.findElements(By.xpath(".//li//div"));

                                WebElement selectedSubmenuItem = submenuItems.get(rand.nextInt(submenuItems.size()));

                                String submenuItemAriaLabel = selectedSubmenuItem.getAttribute("aria-label");
                                System.out.println("Selected submenu item: " + submenuItemAriaLabel);

                                selectedSubmenuItem.click();

                                TestRunner.getTest().log(Status.PASS, "Selected submenu item: " + submenuItemAriaLabel);

                                if (submenuItemAriaLabel.equalsIgnoreCase("add graph elements")) {
                                    TestRunner.getTest().log(Status.INFO, "Drawing a random line in the iframe.");
                                    System.out.println("Drawing a random line in the iframe.");

                                    WebElement questionPlayerIFrame = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("lesson-player-ifram")));
                                    driver.switchTo().frame(questionPlayerIFrame);

                                    WebElement iframeBody = driver.findElement(By.xpath("//div[@class='canvas-container']"));

                                    Random random = new Random();
                                    int startX = random.nextInt(iframeBody.getSize().width);
                                    int startY = random.nextInt(iframeBody.getSize().height);
                                    int endX = random.nextInt(iframeBody.getSize().width);
                                    int endY = random.nextInt(iframeBody.getSize().height);

                                    actions.moveToElement(iframeBody, startX, startY).clickAndHold()
                                            .moveByOffset(endX - startX, endY - startY)
                                            .release().perform();

                                    TestRunner.getTest().log(Status.PASS, "Random line drawn in the iframe.");
                                }

                                WebElement closeSubMenu = submenu.findElement(By.xpath("//button[contains(@class, 'close-btn')]"));
                                closeSubMenu.click();
                                TestRunner.getTest().log(Status.PASS, "Submenu closed.");
                            }

                            if (selectedOptionText.contains("pencil") || selectedOptionText.contains("brush paint")) {
                                TestRunner.getTest().log(Status.INFO, "Drawing a random line in the iframe.");
                                System.out.println("Drawing a random line in the iframe.");

                                WebElement iframeBody = driver.findElement(By.xpath("//div[@class='canvas-container']"));

                                Random random = new Random();
                                int startX = random.nextInt(iframeBody.getSize().width);
                                int startY = random.nextInt(iframeBody.getSize().height);
                                int endX = random.nextInt(iframeBody.getSize().width);
                                int endY = random.nextInt(iframeBody.getSize().height);

                                actions.moveToElement(iframeBody, startX, startY).clickAndHold()
                                        .moveByOffset(endX - startX, endY - startY)
                                        .release().perform();
                                TestRunner.getTest().log(Status.PASS, "Random line drawn in the iframe.");
                                System.out.println("Random line drawn in the iframe.");
                            }

                            WebElement closeMainMenu = annotateTextMenu.findElement(By.xpath("//button[contains(@class, 'close-btn')]"));
                            closeMainMenu.click();
                            TestRunner.getTest().log(Status.PASS, "Main menu closed.");

                            checkCanvasValue();

                        } else {
                            TestRunner.getTest().log(Status.FAIL, "No valid annotate options found.");
                        }
                    } else {
                        TestRunner.getTest().log(Status.FAIL, "'Annotate Text' menu did not appear.");
                    }
                } else {
                    TestRunner.getTest().log(Status.FAIL, "'Annotate Text' button did not become active.");
                }
            } else {
                TestRunner.getTest().log(Status.INFO, "'Annotate Text' button is already active.");
            }
        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "Failed to check or click 'Annotate Text' button.");
            e.printStackTrace();
        }
    }

    public void checkCanvasValue() {
        TestRunner.getTest().log(Status.INFO, "Checking the canvas value");
        System.out.println("Checking the canvas value");

        try {
            WebElement questionPlayerIFrame = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("lesson-player-ifram")));
            driver.switchTo().frame(questionPlayerIFrame);

            // Locate the canvas element
            WebElement canvasElement = driver.findElement(By.cssSelector("canvas.lower-canvas"));
            JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;

            // Use JavaScript to extract canvas image data
            String canvasDataScript = "return arguments[0].toDataURL();"; // This returns base64 data of the canvas image
            String canvasData = (String) jsExecutor.executeScript(canvasDataScript, canvasElement);

            TestRunner.getTest().log(Status.INFO, "Canvas data (base64 image): " + canvasData);
            System.out.println("Canvas data (base64 image): " + canvasData);

            // Optionally, check the canvas pixel data
            String getPixelDataScript = "var canvas = arguments[0];" +
                    "var ctx = canvas.getContext('2d');" +
                    "return ctx.getImageData(0, 0, canvas.width, canvas.height).data;"; // This will return the raw pixel data
            List<Object> pixelData = (List<Object>) jsExecutor.executeScript(getPixelDataScript, canvasElement);

            if (!pixelData.isEmpty()) {
                TestRunner.getTest().log(Status.PASS, "Canvas contains drawing or data.");
            } else {
                TestRunner.getTest().log(Status.INFO, "Canvas is empty, no drawing exists.");
            }

            driver.switchTo().defaultContent();
        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "Failed to retrieve canvas value.");
            e.printStackTrace();
        }
    }

    public void checkHighlighterOfAssignment() {
        TestRunner.getTest().log(Status.INFO, "Check highlighter of each assignment");

        try {
            // Wait for the Highlighter button using aria-label
            WebElement btnHighlighter = wait.until(ExpectedConditions.elementToBeClickable(
                    By.xpath("//div[@class='button-group annotationTool']//button[@aria-label='Highlight Text']")));
            helper.scrollToElement(driver, btnHighlighter);

            String classBeforeClick = btnHighlighter.getAttribute("class");
            TestRunner.getTest().log(Status.INFO, "Class before click: " + classBeforeClick);

            if (classBeforeClick.contains("inactive-tool")) {
                btnHighlighter.click();
                TestRunner.getTest().log(Status.PASS, "Highlighter button clicked successfully");
                Thread.sleep(1000);

                String classAfterClick = btnHighlighter.getAttribute("class");
                TestRunner.getTest().log(Status.INFO, "Class after click: " + classAfterClick);

                if (classAfterClick.contains("active-tool")) {
                    TestRunner.getTest().log(Status.PASS, "'Highlighter' button is now active.");

                    WebElement questionPlayerIFrame = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("lesson-player-ifram")));
                    driver.switchTo().frame(questionPlayerIFrame);

                    WebElement QuestionBody = driver.findElement(By.xpath("//div[contains(@class, 'LessonPlayerRoot')]"));
                    wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//div[contains(@class, 'planComponentQuestion')]")));

                    WebElement questionRoots = QuestionBody.findElement(By.xpath("//div[contains(@class, 'planComponentQuestion')]//div[contains(@class, 'QuestionPlayer')]//div[contains(@class, 'question-root')]"));

                    WebElement questionText = questionRoots.findElement(By.xpath(".//div[contains(@class, 'questionTextContainer')]"));
                    Thread.sleep(1000);
                    actions.doubleClick(questionText).perform();

                    Thread.sleep(2000);

                    WebElement colorBar = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class, 'textSelectionPopover')]")));
                    if (colorBar != null && colorBar.isDisplayed()) {
                        TestRunner.getTest().log(Status.PASS, "'Color Bar' is displayed.");
                        System.out.println("'Color Bar' is displayed.");

                        List<WebElement> colorButtons = colorBar.findElements(By.xpath(".//button"));
                        Random rand = new Random();
                        WebElement selectedColorButton = colorButtons.get(rand.nextInt(colorButtons.size()));

                        String selectedColor = selectedColorButton.getAttribute("aria-label");
                        selectedColorButton.click();
                        TestRunner.getTest().log(Status.PASS, "Color applied successfully");

                        String copiedTextContent = questionText.getText().trim();
                        TestRunner.getTest().log(Status.INFO, "Copied text: " + copiedTextContent);

                        WebElement appliedTextStyle = questionRoots.findElement(By.tagName("mark"));
                        String appliedStyle = appliedTextStyle.getAttribute("class");
                        TestRunner.getTest().log(Status.INFO, "Get color: " + appliedStyle);
                        TestRunner.getTest().log(Status.PASS, "The selected highlight color is applied to the text.");

                        driver.switchTo().defaultContent();

                        Thread.sleep(2000);
                        btnHighlighter.click();

                    } else {
                        TestRunner.getTest().log(Status.FAIL, "'Color Bar' is not displayed.");
                    }
                } else {
                    TestRunner.getTest().log(Status.FAIL, "'Highlighter' button did not become active.");
                }
            } else {
                TestRunner.getTest().log(Status.INFO, "Highlighter button is already active.");
            }
        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "Failed to check or click Highlighter button.");
            e.printStackTrace();
        }
    }

    public void validateAnnotationInClosedAssignment() throws InterruptedException {
        WebElement overviewWrapper = driver.findElement(By.xpath("//div[contains(@class, 'OverviewScreenWrapper')]"));
        WebElement answer_element = overviewWrapper.findElement(By.xpath(".//div[@class='ScrollbarsCustom-Content']"));
        List<WebElement> button_answers = answer_element.findElements(By.tagName("button"));
        System.out.println("Total Answer: " + button_answers.size());
        if (!button_answers.isEmpty()) {
            WebElement button = button_answers.get(0);

            if (button.isDisplayed()) {
                System.out.println("Button was clicked: " + button.getText());
                button.click();
                System.out.println("Answer is clicked.");
                validateQuestionsButtonForAnnotation();
            } else {
                System.out.println("Button is not displayed.");
            }
        } else {
            System.out.println("No answer buttons found.");
        }
    }

    public void validateQuestionsButtonForAnnotation() throws InterruptedException {
        driver.switchTo().defaultContent();
        ReleaseAssignment_PF.temp.set(0);
        List<WebElement> questionButtons = nav_Pagination.findElements(By.xpath("//button[contains(@aria-label, 'Go to page')]"));
        for (WebElement questionButton : questionButtons) {
            String questionText = questionButton.getText();
            System.out.println("Question: " + questionText);
        }
        while (btn_NavNextPage.isEnabled()) {
            Thread.sleep(2000);
            validateAnnotations();
            btn_NavNextPage.click();
            Thread.sleep(2000);
        }

        Thread.sleep(2000);
        WebElement btn_CloseReview = driver.findElement(By.xpath("//button[@id='closeReview-btn']"));
        helper.scrollToElement(driver, btn_CloseReview);
        System.out.println("Clicked on close review");
        btn_CloseReview.click();
    }

    public void validateAnnotations() throws InterruptedException{
        System.out.println("I'm in to verify annotations");

        WebElement questionPlayerIFrame = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("lesson-player-ifram")));
        driver.switchTo().frame(questionPlayerIFrame);

        WebElement QuestionBody = driver.findElement(By.xpath("//div[contains(@class, 'LessonPlayerRoot')]"));
        wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//div[contains(@class, 'planComponentQuestion')]")));

        WebElement questionRoots = QuestionBody.findElement(By.xpath("//div[contains(@class, 'planComponentQuestion')]//div[contains(@class, 'QuestionPlayer')]//div[contains(@class, 'question-root')]"));

        try {
            WebElement appliedTextStyle = questionRoots.findElement(By.tagName("mark"));
            String appliedStyle = appliedTextStyle.getAttribute("class");
            TestRunner.getTest().log(Status.INFO, "Get color: " + appliedStyle);
            TestRunner.getTest().log(Status.PASS, "The selected highlight color is shown on the text.");
        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "Failed to find <mark> tag or extract style: " + e.getMessage());
            e.printStackTrace();
        }

        driver.switchTo().defaultContent();
    }
}