package pageFactory.Assignmment.AssessmentReview;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import apiHandler.GetAPIHandler;
import com.aventstack.extentreports.Status;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Assignmment.CorrectAnswerExecutor_PF;
import pageFactory.Assignmment.StudentExecutor_PF;
import pageFactory.Login_PF;
import pageFactory.MyContent.AssignAssessment_PF;

import java.awt.*;
import java.time.Duration;
import java.util.List;
import java.util.Random;

public class ReviewNotAvailable_PF {

    Helper helper;
    GetAPIHandler getAPIHandler;
    StudentExecutor_PF studentExecutor;
    AssignAssessment_PF assignAssessment;
    CorrectAnswerExecutor_PF correctAnswerExecutorPf;
    public WebDriverWait wait;
    WebDriver driver;
//    public static String AssignmentNameForNoReview = Configurations.getDotEnv().get("SITE_ASSIGNMENT_NAME_NO_REVIEW_AVAILABLE");
    String[] specificClasses = {"FL Grade 5"};
    String ReviewNotAvailable = "Review Not Available";
    String questionID = null;

    public static final String BASE_NAME = Configurations.getDotEnv().get("SITE_ASSIGNMENT_NAME_NO_REVIEW_AVAILABLE");
    public static final String AssignmentNameForNoReview;

    static {
        Random random = new Random();
        StringBuilder sb = new StringBuilder(6);
        String charSet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

        for (int i = 0; i < 6; i++) {
            int randomIndex = random.nextInt(charSet.length());
            sb.append(charSet.charAt(randomIndex));
        }

        String randomString = sb.toString();
        AssignmentNameForNoReview = BASE_NAME + " " + randomString;
    }





    @FindBy(xpath = "//div[@class='ScrollbarsCustom']//div[@class='ScrollbarsCustom-Content']")
    WebElement scroll_Units;

    @FindBy(xpath = "//div[@id='ContentPlayerMainPanel']")
    WebElement list_ContentPlayer;

    @FindBy(xpath = "//input[@name='title']")
    WebElement edt_AssignmentTitle;

    @FindBy(xpath = "//label[contains(text(),'Assign to')]/parent::div")
    WebElement dropDown_AssignTo;

    @FindBy(xpath = "//nav[@aria-label='pagination navigation']")
    WebElement nav_Pagination;

    @FindBy(xpath = "//button[@aria-label='Go to next page']")
    WebElement btn_NavNextPage;

    String baseUrl = Configurations.App_url;

    public ReviewNotAvailable_PF(WebDriver driver) {
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        helper = new Helper();
        getAPIHandler = new GetAPIHandler();
        correctAnswerExecutorPf = new CorrectAnswerExecutor_PF(driver);
        studentExecutor = new StudentExecutor_PF(driver);
        assignAssessment = new AssignAssessment_PF(driver);
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    public void ReleaseAssignmentForNoReviewVerification() throws InterruptedException {
        System.out.println("Release Assignment For No Review Verification");
        try {
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(@class, 'ScrollbarsCustom')]//div[@class='ScrollbarsCustom-Content'])[2]")));

            WebElement UnitEOYR = scroll_Units.findElement(By.xpath("//button[contains(@aria-label,'End of Year Resources')]"));
            UnitEOYR.click();

            wait.until(ExpectedConditions.visibilityOf(list_ContentPlayer));

            list_ContentPlayer.isDisplayed();

            WebElement btnAssignAssignment = list_ContentPlayer.findElement(By.xpath("(//div[contains(@class, 'MuiBox-root')]//button[contains(text(), 'Assign')])[2]"));
            btnAssignAssignment.click();

            WebElement dialogAssignment = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@role='dialog']")));
            dialogAssignment.isDisplayed();

            EnterAssignmentTitleForNoReview();
            selectSpecificClasses();
            assignAssessment.setDateTimeAndCategory();
            assignAssessment.select_ShowAdditionalSettings();
            assignAssessment.checkBox_RandomizeAnswerChoices();
            assignAssessment.checkBox_DisplayGradesToStudent();
            helper.selectReviewOption(ReviewNotAvailable);
            assignAssessment.txtArea_AdditionalInstructions();
            assignAssessment.enterWeightPercentage();
            assignAssessment.assignAssignment();
            assignAssessment.verifyDialogBox();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed   :   Assignment Released Successfully for Review Not Available");

        } catch (NoSuchElementException | ElementNotInteractableException | TimeoutException e){
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :   Assignment Not Released");
            System.out.println(e);
        }
    }

    public void EnterAssignmentTitleForNoReview() {
        edt_AssignmentTitle.click();
        ((JavascriptExecutor) driver).executeScript("arguments[0].value='';", edt_AssignmentTitle);
        edt_AssignmentTitle.sendKeys(AssignmentNameForNoReview);
    }

    public void selectSpecificClasses() throws InterruptedException {
        dropDown_AssignTo.click();

        WebElement assignToOptions = dropDown_AssignTo.findElement(By.xpath("//ul[@role='listbox']"));
        Thread.sleep(2000);

        List<WebElement> totalClasses = assignToOptions.findElements(By.tagName("li"));
        System.out.println("Total Classes: " + totalClasses.size());

        for (WebElement totalClass : totalClasses) {
            String totalClassName = totalClass.findElement(By.xpath(".//span[contains(@class, 'MuiListItemText-primary')]")).getText();
            WebElement checkBoxClass = totalClass.findElement(By.xpath(".//input"));
            System.out.println("Total Class: " + totalClassName);
            for (String className : specificClasses) {
                if (totalClassName.equals(className)) {
                    System.out.println("Selected Class: " + totalClassName);
                    TestRunner.getTest().log(Status.INFO, "Selected class name: " + totalClassName);
                    totalClass.click();
                    checkBoxClass.click();
                    break;
                }
            }
        }
        Actions actions = new Actions(driver);
        actions.sendKeys(Keys.ESCAPE).build().perform();
    }

    public void SelectAssignmentForNoReview() throws InterruptedException, AWTException {
        System.out.println("I'm into to search Assignment For No Review Status");
        TestRunner.getTest().log(Status.INFO, "I'm into to search Assignment For No Review Status" + AssignmentNameForNoReview);

        WebElement searchBar = driver.findElement(By.xpath("//input[@placeholder='Search Assignment by Title']"));
        searchBar.clear();
        searchBar.click();
        searchBar.sendKeys(AssignmentNameForNoReview); // Enter assignment name
        searchBar.sendKeys(Keys.ENTER); // Trigger search

        Thread.sleep(3000);
        WebElement searchBtn= driver.findElement(By.xpath("//button[contains(@class,'MuiButtonBase-root MuiIconButton-root MuiIconButton-edgeStart')]"));
        searchBtn.click();

        Thread.sleep(3000);

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='simple-tabpanel-2']")));
        WebElement openAssignments = driver.findElement(By.xpath("(//div[contains(@class, 'MuiGrid-container')])[2]"));

        List<WebElement> totalAssignments = openAssignments.findElements(By.xpath(".//div[contains(@class, 'MuiGrid-container')]"));
        System.out.println("Total Open Assignments: " + totalAssignments.size());

        boolean assignment_found= false;

        for (WebElement assignment : totalAssignments) {
            WebElement assignmentNameElement = assignment.findElement(By.xpath(".//div[contains(@class, 'notranslate')]"));
            String assignmentName = assignmentNameElement.getText();

            if (assignmentName.equals(AssignmentNameForNoReview)) {
                System.out.println("Found assignment: " + assignmentName);
                assignment_found= true;
                try {
                    WebElement startOrResumeButton = assignment.findElement(By.xpath(".//div[@statustype='START' or @statustype='RESUME']"));
                    startOrResumeButton.click();

                    System.out.println("Assignment started");
                    Thread.sleep(3000);
                    studentExecutor.handleTeacherInstructionsDialog();

                    AttemptAndSubmitAssignmentForNoReview();
                    Thread.sleep(2000);
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed   :   Assignment Attempted Successfully for Review Not Available");

                } catch (NoSuchElementException e) {
                    System.out.println("START/RESUME button not found for assignment: " + assignmentName);
                    TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :   START/RESUME Button Not Found");
                    return;
                }
                refreshPage();
                Thread.sleep(3000);
                studentExecutor.dialogBox_ImpAnnouncement();

                break;

            } else {
                System.out.println("Assignment not found: " + assignmentName);
            }
        }
        if(!assignment_found) {
            TestRunner.getTest().log(Status.INFO, "Assignment   " + AssignmentNameForNoReview + " Is not Found At student Side In Open tab");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Assignment not found in Open Tab");
        }
    }

    private void refreshPage() {
        driver.navigate().to(baseUrl);
    }

    public void AttemptAndSubmitAssignmentForNoReview() throws InterruptedException, AWTException {
        if (!isPaginationDisplayed()) {
            verifyAssignmentSubmitForNoReview();
            return;
        }

        try {
            List<WebElement> questionButtons = nav_Pagination.findElements(By.xpath("//button[contains(@aria-label, 'Go to page')]"));

            for (WebElement questionButton : questionButtons) {
                String questionText = questionButton.getText();
                System.out.println("Question: " + questionText);
            }

            while (btn_NavNextPage.isEnabled()) {
                Thread.sleep(2000);
                AttemptAssignmentForNoReview();
                btn_NavNextPage.click();
                Thread.sleep(2000);
            }

            verifyAssignmentSubmitForNoReview();
        } catch (NoSuchElementException | ElementNotInteractableException | TimeoutException e) {
            System.out.println("No Question found.");
        }
    }

    private boolean isPaginationDisplayed() {
        try {
            return nav_Pagination.isDisplayed();
        } catch (NoSuchElementException | ElementNotInteractableException | TimeoutException e) {
            return false;
        }
    }

    public void AttemptAssignmentForNoReview() throws InterruptedException, AWTException {
        System.out.println("I'm in attempting all questions with correct answers");
        Thread.sleep(1000);

        WebElement questionPlayer = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("lesson-player-ifram")));
        driver.switchTo().frame(questionPlayer);
        WebElement QuestionBody = driver.findElement(By.xpath("//div[contains(@class, 'LessonPlayerRoot')]"));

        WebElement QuestionPlayer = null;

        try {
            List<WebElement> MultiParts = QuestionBody.findElements(By.xpath("//div[contains(@class, 'planComponentQuestion')]"));
            System.out.println("Total number of multi-part on this page: " + MultiParts.size());

            for (WebElement part : MultiParts) {
                QuestionPlayer = part.findElement(By.xpath(".//div[contains(@class, 'QuestionPlayer')]"));

                System.out.println("Question is found");
                String questionType = QuestionPlayer.getAttribute("data-type");
                System.out.println("Question Type is: " + questionType);

                WebElement questionRoot = QuestionPlayer.findElement(By.xpath(".//div[contains(@class, 'question-root')]"));
                questionID = questionRoot.getAttribute("data-question-id");
                System.out.println("Question ID is: " + questionID);

                switch (questionType) {
                    case "extended-text-interaction" -> studentExecutor.QuestionExtendedTextInteraction();
                    case "choice-interaction-single" -> correctAnswerExecutorPf.QuestionChoiceInteractionSingleAccurate(questionRoot, questionID);
                    case "choice-interaction" -> correctAnswerExecutorPf.QuestionChoiceInteractionsAccurate(questionRoot, questionID);
                    case "match-dragdrop-interaction" -> correctAnswerExecutorPf.QuestionMatchDragdropInteractionAccurate(questionRoot, questionID);
                    case "inline-choice-select-interaction" -> correctAnswerExecutorPf.QuestionInlineChoiceSelectInteractionAccurate(questionRoot,questionID);
                    case "gap-match-interaction" -> correctAnswerExecutorPf.QuestionGapMatchInteractionAccurate(questionID);
                    case "choice-imagelabel-select-interaction" -> correctAnswerExecutorPf.QuestionChoiceImageLabelSelectInteractionAccurate(questionRoot,questionID);
                    case "inline-choice-text-interaction" -> studentExecutor.QuestionInlineChoiceTextInteraction();
                    case "inline-choice-spelling-interaction" -> correctAnswerExecutorPf.QuestionInlineChoiceSpellingInteractionAccurate(questionRoot,questionID);
                    case "graphic-gap-match-interaction" -> correctAnswerExecutorPf.QuestionGraphicGapMatchInteractionAccurate(questionID);
                    case "order-interaction" -> correctAnswerExecutorPf.QuestionOrderInteractionAccurate(questionID);
                    case "drawing-interaction" -> studentExecutor.QuestionDrawingInteraction();
                    case "match-interaction" -> correctAnswerExecutorPf.QuestionMatchInteractionAccurate(questionRoot,questionID);
                    case "upload-interaction" -> studentExecutor.QuestionUploadInteraction();
                    default -> {
                    }
                }

            }
        } catch (NoSuchElementException e) {
            System.out.println("This is a content player question and have no any data type question");
            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
        } finally {
            driver.switchTo().defaultContent();
        }
    }

    public void verifyAssignmentSubmitForNoReview() throws InterruptedException{
        System.out.println("I'm in to submit the assignment");
        Thread.sleep(2000);

        WebElement headerBar = driver.findElement(By.xpath("//div[@id='ContentPlayerMainPanel']"));

        WebElement btnSubmitAsCompleted = headerBar.findElement(By.xpath("//button[normalize-space()='Submit as Completed']"));
        btnSubmitAsCompleted.click();

        WebElement dialogIframe = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("lesson-player-ifram")));
        driver.switchTo().frame(dialogIframe);

        WebElement promptSubmit = driver.findElement(By.xpath("//div[@aria-labelledby='customized-dialog-title']"));

        WebElement btnSubmit = promptSubmit.findElement(By.xpath("//button[@id='btn-save']"));
        btnSubmit.click();

        Thread.sleep(2000);

        reviewNotAvailable();

        // Pressing the ESC key
        Actions actions = new Actions(driver);
        actions.sendKeys(Keys.ESCAPE).build().perform();

        driver.switchTo().defaultContent();

        WebElement loader = driver.findElement(By.xpath("//span[@role='progressbar']"));
        wait.until(ExpectedConditions.invisibilityOf(loader));

        By[] elementsToWaitFor = {
                By.xpath("//div[contains(@class,'navigation')]"),
                By.xpath("//div[contains(@class,'studentPortal-header')]"),
                By.xpath("//div[contains(@class,'AssignmentWrapper')]"),
                By.xpath("//div[contains(@class,'CoursesList')]")
        };
        try {
            for (By element : elementsToWaitFor) {
                wait.until(ExpectedConditions.visibilityOfElementLocated(element));
            }
            Thread.sleep(1000);
            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
        } catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            helper.takeScreenshot(driver , Thread.currentThread().getStackTrace()[1].getMethodName() );
            System.out.println("Exception is found    :   Dashboard is not shows");
            Assert.fail();
        }
    }

    private void reviewNotAvailable(){
        System.out.println("Successfully redirected to Dashboard Review button not available");
    }

    public void VerifyNoReviewButtonInClosedAssignment() throws InterruptedException {

        TestRunner.getTest().log(Status.INFO, "Want to search assessment in closed tab: " + AssignmentNameForNoReview);

        WebElement searchBar = driver.findElement(By.xpath("//input[@placeholder='Search Assignment by Title']"));  // Locate search bar
        searchBar.clear();
        searchBar.click();
        searchBar.sendKeys(AssignmentNameForNoReview);  // Enter the assignment name in the search bar
        searchBar.sendKeys(Keys.ENTER);
        Thread.sleep(2000);

        WebElement searchBtn= driver.findElement(By.xpath("//button[contains(@class,'MuiButtonBase-root MuiIconButton-root MuiIconButton-edgeStart')]"));
        searchBtn.click();

        Thread.sleep(3000);

        WebElement myAssignmentGrid = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@aria-labelledby='simple-tab-2']")));

        if (myAssignmentGrid.isDisplayed() && myAssignmentGrid.isEnabled()) {
            WebElement btnClosed = driver.findElement(By.xpath("//button[@id='simple-tab-3']"));
            btnClosed.click();

            WebElement panelTabClosed = driver.findElement(By.xpath("//div[@id='simple-tabpanel-3']"));

            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='simple-tabpanel-3']")));
            Thread.sleep(3000);

            String textClosedAssignments = panelTabClosed.getText();
            System.out.println("Closed Assignments are");
            System.out.println(textClosedAssignments);

            List<WebElement> totalAssignments = driver.findElements(By.xpath(".//div[contains(@class, 'MuiGrid-container')]"));
            System.out.println("Total Closed Assignments: " + totalAssignments.size());
            boolean assignment_found = false;

            for (WebElement assignment : totalAssignments) {
                WebElement assignmentNameElement = assignment.findElement(By.xpath(".//div[contains(@class, 'notranslate')]"));
                String assignmentsName = assignmentNameElement.getText();
                System.out.println("Assignment Name : " + assignmentsName);

                if (assignmentsName.equals(AssignmentNameForNoReview)) {
                    System.out.println("Found assignment: " + AssignmentNameForNoReview);
                    assignment_found = true;
                    try {
                        assignment.findElement(By.xpath(".//button[.//span[contains(text(), 'Review')] and not(@disabled)]"));
                        System.out.println("Review button available for assignment: " + AssignmentNameForNoReview);
                        TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :   Review Button Available");
                    } catch (NoSuchElementException e) {
                        System.out.println("Review button not found for assignment: " + AssignmentNameForNoReview);
                        TestRunner.getTest().log(Status.PASS, "est Case Passed   :   Review Button Not Available");
                        return;
                    }
                    break;
                } else {
                    System.out.println("Assignment not found: " + AssignmentNameForNoReview);
                }
            }
            if (!assignment_found) {
                TestRunner.getTest().log(Status.INFO, "Assignment   " + AssignmentNameForNoReview + " that is Attempt successfully but not Visible in Close tab.");
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Assignment not found in close Tab");
            }
        }
    }
}
