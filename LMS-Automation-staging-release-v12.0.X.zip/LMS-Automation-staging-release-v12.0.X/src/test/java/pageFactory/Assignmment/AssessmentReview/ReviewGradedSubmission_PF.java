package pageFactory.Assignmment.AssessmentReview;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import apiHandler.GetAPIHandler;
import com.aventstack.extentreports.Status;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Assignmment.CorrectAnswerExecutor_PF;
import pageFactory.Assignmment.ReleaseAssignment_PF;
import pageFactory.Assignmment.StudentExecutor_PF;
import pageFactory.MyContent.AssignAssessment_PF;

import java.awt.*;
import java.time.Duration;
import java.util.List;
import java.util.Random;


public class ReviewGradedSubmission_PF {

    Helper helper;
    GetAPIHandler getAPIHandler;
    StudentExecutor_PF studentExecutor;
    AssignAssessment_PF assignAssessment;
    CorrectAnswerExecutor_PF correctAnswerExecutorPf;
    ReleaseAssignment_PF releaseAssignmentPf;
    public WebDriverWait wait;
    WebDriver driver;
//    public static String AssignmentNameForReviewGradedSubmission = Configurations.getDotEnv().get("SITE_ASSIGNMENT_NAME_REVIEW_GRADED_SUBMISSION");
    String[] specificClasses = {"FL Grade 5"};
    String ReviewGradedSubmission = "Review Graded Submission";
    String questionID = null;

    public static final String BASE_NAME = Configurations.getDotEnv().get("SITE_ASSIGNMENT_NAME_REVIEW_GRADED_SUBMISSION");
    public static final String AssignmentNameForReviewGradedSubmission;

    static {
        Random random = new Random();
        StringBuilder sb = new StringBuilder(6);
        String charSet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

        for (int i = 0; i < 6; i++) {
            int randomIndex = random.nextInt(charSet.length());
            sb.append(charSet.charAt(randomIndex));
        }

        String randomString = sb.toString();
        AssignmentNameForReviewGradedSubmission = BASE_NAME + " " + randomString;
    }

    @FindBy(xpath = "//input[@name='title']")
    WebElement edt_AssignmentTitle;

    @FindBy(xpath = "//label[contains(text(),'Assign to')]/parent::div")
    WebElement dropDown_AssignTo;

    @FindBy(xpath = "//nav[@aria-label='pagination navigation']")
    WebElement nav_Pagination;

    @FindBy(xpath = "//button[@aria-label='Go to next page']")
    WebElement btn_NavNextPage;

    String baseUrl = Configurations.App_url;

    public ReviewGradedSubmission_PF(WebDriver driver) {
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        helper = new Helper();
        getAPIHandler = new GetAPIHandler();
        studentExecutor = new StudentExecutor_PF(driver);
        assignAssessment = new AssignAssessment_PF(driver);
        correctAnswerExecutorPf = new CorrectAnswerExecutor_PF(driver);
        releaseAssignmentPf = new ReleaseAssignment_PF(driver);
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    public void ReleaseAssignmentForReviewGradedSubmissionVerification() throws InterruptedException {
        System.out.println("Release Assignment For Review Graded Submission Verification");
        TestRunner.getTest().log(Status.INFO, "Release Assignment For Review Graded Submission Verification");
        releaseAssignmentPf.selectUnitForReleaseAssignment();

        Thread.sleep(2000);
        WebElement listContentPlayer = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@id='ContentPlayerMainPanel']")));

        if (listContentPlayer.isDisplayed() && listContentPlayer.isEnabled()) {
            WebElement btnAssignForSpecificAssignment = listContentPlayer.findElement(By.xpath("(//div[contains(@class, 'MuiBox-root')]//button[contains(text(), 'Assign')])[5]"));
            btnAssignForSpecificAssignment.click();

            WebElement dialogAssignment = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@role='dialog']")));
            if (dialogAssignment.isDisplayed()) {
                EnterAssignmentTitleForReviewGradedSubmission();
                selectSpecificClasses();
                assignAssessment.setDateTimeAndCategory();
                assignAssessment.select_ShowAdditionalSettings();
                assignAssessment.checkBox_RandomizeAnswerChoices();
                assignAssessment.checkBox_DisplayGradesToStudent();
                helper.selectReviewOption(ReviewGradedSubmission);
                assignAssessment.txtArea_AdditionalInstructions();
                assignAssessment.enterWeightPercentage();
                assignAssessment.assignAssignment();
                assignAssessment.verifyDialogBox();
                TestRunner.getTest().log(Status.PASS, "Test Case Passed   :   Assignment Release Successfully for Review Graded Submission **********");
            }
        }
    }

    public void EnterAssignmentTitleForReviewGradedSubmission() {
        edt_AssignmentTitle.click();
        ((JavascriptExecutor) driver).executeScript("arguments[0].value='';", edt_AssignmentTitle);
        edt_AssignmentTitle.sendKeys(AssignmentNameForReviewGradedSubmission);
        System.out.println("Release Assignment For Review graded Submission: " + AssignmentNameForReviewGradedSubmission);
        TestRunner.getTest().log(Status.INFO, "Release Assignment For Review graded Submission: " + AssignmentNameForReviewGradedSubmission);
    }

    public void selectSpecificClasses() throws InterruptedException {
        dropDown_AssignTo.click();

        WebElement assignToOptions = dropDown_AssignTo.findElement(By.xpath("//ul[@role='listbox']"));
        Thread.sleep(2000);

        List<WebElement> totalClasses = assignToOptions.findElements(By.tagName("li"));
        System.out.println("Total Classes: " + totalClasses.size());

        for (WebElement totalClass : totalClasses) {
            String totalClassName = totalClass.findElement(By.xpath(".//span[contains(@class, 'MuiListItemText-primary')]")).getText();
            WebElement checkBoxClass = totalClass.findElement(By.xpath(".//input"));
            System.out.println("Total Class: " + totalClassName);
            for (String className : specificClasses) {
                if (totalClassName.equals(className)) {
                    System.out.println("Selected Class: " + totalClassName);
                    TestRunner.getTest().log(Status.INFO, "Selected class name: " + totalClassName);
                    totalClass.click();
                    checkBoxClass.click();
                    break;
                }
            }
        }
        Actions actions = new Actions(driver);
        actions.sendKeys(Keys.ESCAPE).build().perform();
    }

    public void SelectAssignmentForReviewGradedSubmission() throws AWTException, InterruptedException {
        System.out.println("I'm into search Assignment For Review Graded Submission Status");
        TestRunner.getTest().log(Status.INFO, "I'm into search Assignment For Review Graded Submission Status");

        WebElement searchBar = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@placeholder='Search Assignment by Title']")));
        searchBar.clear();
        searchBar.click();
        searchBar.sendKeys(AssignmentNameForReviewGradedSubmission);
        searchBar.sendKeys(Keys.ENTER);

        WebElement searchBtn = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//input[contains(@placeholder, 'Search Assignment by Title')]/parent::div//button")));
        searchBtn.click();

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='simple-tabpanel-2']")));

        boolean assignment_found = false;

        List<WebElement> assignmentContainers = wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(
                By.xpath("(//div[contains(@class, 'MuiGrid-container')])[2]//div[contains(@class, 'MuiGrid-container')]")));

        for (int i = 0; i < assignmentContainers.size(); i++) {
            assignmentContainers = driver.findElements(By.xpath("(//div[contains(@class, 'MuiGrid-container')])[2]//div[contains(@class, 'MuiGrid-container')]"));
            WebElement assignment = assignmentContainers.get(i);

            try {
                WebElement assignmentNameElement = assignment.findElement(By.xpath(".//div[contains(@class, 'notranslate')]"));
                String assignmentName = assignmentNameElement.getText();

                if (assignmentName.equals(AssignmentNameForReviewGradedSubmission)) {
                    System.out.println("Found assignment: " + assignmentName);
                    assignment_found = true;

                    try {
                        WebElement startOrResumeButton = assignment.findElement(By.xpath(".//div[@statustype='START' or @statustype='RESUME']"));
                        wait.until(ExpectedConditions.elementToBeClickable(startOrResumeButton)).click();

                        System.out.println("Assignment started");
                        wait.until(ExpectedConditions.invisibilityOf(startOrResumeButton));
                        studentExecutor.handleTeacherInstructionsDialog();

                        AttemptAndSubmitAssignmentForReviewGradedSubmission();
                        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Assignment Attempted Successfully for Review Graded Submission");

                    } catch (NoSuchElementException e) {
                        System.out.println("START/RESUME button not found for assignment: " + assignmentName);
                        TestRunner.getTest().log(Status.FAIL, "Test Case Failed: START/RESUME Button Not Found");
                        return;
                    }

                    refreshPage();
                    studentExecutor.dialogBox_ImpAnnouncement();

                    try {
                        WebElement tabOpenAssignments = wait.until(ExpectedConditions.presenceOfElementLocated(
                                By.xpath("//div[@aria-labelledby='simple-tab-2']")));

                        List<WebElement> totalAssignment = tabOpenAssignments.findElements(By.xpath(".//div[contains(@class, 'notranslate')]"));
                        System.out.println("Total Assignments after refresh: " + totalAssignment.size());

                        for (WebElement assignmentText : totalAssignment) {
                            System.out.println("Assignment Text: " + assignmentText.getText());
                        }
                    } catch (TimeoutException e) {
                        System.out.println("Failed to load assignments after refresh. Retrying...");
                    }
                    break;
                } else {
                    System.out.println("Assignment not matched: " + assignmentName);
                }

            } catch (StaleElementReferenceException staleEx) {
                System.out.println("Stale element encountered. Retrying assignment index: " + i);
                i--; // Retry the same index
            }
        }

        if (!assignment_found) {
            TestRunner.getTest().log(Status.INFO, "Assignment '" + AssignmentNameForReviewGradedSubmission + "' is not found at student side in Open tab");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Assignment not found in Open Tab");
        }
    }

    private void refreshPage() {
        driver.navigate().to(baseUrl);
    }


    public void AttemptAndSubmitAssignmentForReviewGradedSubmission() throws AWTException, InterruptedException {
        if (!isPaginationDisplayed()) {
            verifyAssignmentSubmitForReviewGradedSubmission();
            return;
        }

        try {
            List<WebElement> questionButtons = nav_Pagination.findElements(By.xpath("//button[contains(@aria-label, 'Go to page')]"));
            for (WebElement questionButton : questionButtons) {
                System.out.println("Question: " + questionButton.getText());
            }

            while (btn_NavNextPage.isEnabled()) {
                AttemptAssignmentForReviewGradedSubmission();
                btn_NavNextPage.click();
                wait.until(ExpectedConditions.stalenessOf(questionButtons.get(0)));
                wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[contains(@aria-label, 'Go to page')]")));
            }

            verifyAssignmentSubmitForReviewGradedSubmission();

        } catch (NoSuchElementException | ElementNotInteractableException | TimeoutException | InterruptedException e) {
            System.out.println("No questions found or issue during attempt: " + e.getMessage());
        }
    }

    private boolean isPaginationDisplayed() {
        try {
            return nav_Pagination.isDisplayed();
        } catch (NoSuchElementException | ElementNotInteractableException | TimeoutException e) {
            return false;
        }
    }

    public void AttemptAssignmentForReviewGradedSubmission() throws InterruptedException, AWTException {
        System.out.println("I'm in attempting all questions with correct answers");
        Thread.sleep(1000);

        WebElement questionPlayer = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("lesson-player-ifram")));
        driver.switchTo().frame(questionPlayer);
        WebElement QuestionBody = driver.findElement(By.xpath("//div[contains(@class, 'LessonPlayerRoot')]"));

        WebElement QuestionPlayer = null;

        try {
            List<WebElement> MultiParts = QuestionBody.findElements(By.xpath("//div[contains(@class, 'planComponentQuestion')]"));
            System.out.println("Total number of multi-part on this page: " + MultiParts.size());

            for (WebElement part : MultiParts) {
                QuestionPlayer = part.findElement(By.xpath(".//div[contains(@class, 'QuestionPlayer')]"));

                System.out.println("Question is found");
                String questionType = QuestionPlayer.getAttribute("data-type");
                System.out.println("Question Type is: " + questionType);

                WebElement questionRoot = QuestionPlayer.findElement(By.xpath(".//div[contains(@class, 'question-root')]"));
                questionID = questionRoot.getAttribute("data-question-id");
                System.out.println("Question ID is: " + questionID);

                switch (questionType) {
                    case "extended-text-interaction" -> studentExecutor.QuestionExtendedTextInteraction();
                    case "choice-interaction-single" -> correctAnswerExecutorPf.QuestionChoiceInteractionSingleAccurate(questionRoot, questionID);
                    case "choice-interaction" -> correctAnswerExecutorPf.QuestionChoiceInteractionsAccurate(questionRoot,questionID);
                    case "match-dragdrop-interaction" -> correctAnswerExecutorPf.QuestionMatchDragdropInteractionAccurate(questionRoot,questionID);
                    case "inline-choice-select-interaction" -> correctAnswerExecutorPf.QuestionInlineChoiceSelectInteractionAccurate(questionRoot,questionID);
                    case "gap-match-interaction" -> correctAnswerExecutorPf.QuestionGapMatchInteractionAccurate(questionID);
                    case "choice-imagelabel-select-interaction" -> correctAnswerExecutorPf.QuestionChoiceImageLabelSelectInteractionAccurate(questionRoot,questionID);
                    case "inline-choice-text-interaction" -> studentExecutor.QuestionInlineChoiceTextInteraction();
                    case "inline-choice-spelling-interaction" -> correctAnswerExecutorPf.QuestionInlineChoiceSpellingInteractionAccurate(questionRoot,questionID);
                    case "graphic-gap-match-interaction" -> correctAnswerExecutorPf.QuestionGraphicGapMatchInteractionAccurate(questionID);
                    case "order-interaction" -> correctAnswerExecutorPf.QuestionOrderInteractionAccurate(questionID);
                    case "drawing-interaction" -> studentExecutor.QuestionDrawingInteraction();
                    case "match-interaction" -> correctAnswerExecutorPf.QuestionMatchInteractionAccurate(questionRoot,questionID);
                    case "upload-interaction" -> studentExecutor.QuestionUploadInteraction();
                    default -> {
                    }
                }

            }
        } catch (NoSuchElementException e) {
            System.out.println("This is a content player question and have no any data type question");
            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
        } finally {
            driver.switchTo().defaultContent();
        }
    }

    public void verifyAssignmentSubmitForReviewGradedSubmission() {
        System.out.println("I'm in to submit the assignment");

        try {
            WebElement headerBar = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@id='ContentPlayerMainPanel']")));

            WebElement btnSubmitAsCompleted = headerBar.findElement(By.xpath("//button[normalize-space()='Submit as Completed']"));
            wait.until(ExpectedConditions.elementToBeClickable(btnSubmitAsCompleted)).click();

            WebElement dialogIframe = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("lesson-player-ifram")));
            driver.switchTo().frame(dialogIframe);

            WebElement promptSubmit = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@aria-labelledby='customized-dialog-title']")));

            WebElement btnSubmit = promptSubmit.findElement(By.xpath("//button[@id='btn-save']"));
            wait.until(ExpectedConditions.elementToBeClickable(btnSubmit)).click();

            driver.switchTo().defaultContent();

            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//span[@role='progressbar']")));

            reviewOptionGradedSubmission();

            new Actions(driver).sendKeys(Keys.ESCAPE).perform();

            By[] elementsToWaitFor = {
                    By.xpath("//div[contains(@class,'navigation')]"),
                    By.xpath("//div[contains(@class,'studentPortal-header')]"),
                    By.xpath("//div[contains(@class,'AssignmentWrapper')]"),
                    By.xpath("//div[contains(@class,'CoursesList')]")
            };

            for (By locator : elementsToWaitFor) {
                wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
            }

            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());

        } catch (NoSuchElementException | ElementNotInteractableException | TimeoutException | InterruptedException e) {
            System.out.println("Exception: " + e.getMessage());
            System.out.println("Line number: " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
            System.out.println("Exception is found    :   Dashboard is not shown");
            Assert.fail("Dashboard did not load properly after submission.");
        }
    }

    public void ClosedAssignmentReviewGradedSubmission() throws InterruptedException {

        TestRunner.getTest().log(Status.INFO, "Want to search assessment in closed tab: " + AssignmentNameForReviewGradedSubmission);

        WebElement searchBar = driver.findElement(By.xpath("//input[@placeholder='Search Assignment by Title']"));  // Locate search bar
        searchBar.clear();
        searchBar.click();
        searchBar.sendKeys(AssignmentNameForReviewGradedSubmission);  // Enter the assignment name in the search bar
        searchBar.sendKeys(Keys.ENTER);
        Thread.sleep(2000);

        WebElement searchBtn= driver.findElement(By.xpath("//button[contains(@class,'MuiButtonBase-root MuiIconButton-root MuiIconButton-edgeStart')]"));
        searchBtn.click();

        Thread.sleep(3000);

        System.out.println("Want to search assessment in closed tab: " + AssignmentNameForReviewGradedSubmission);
        TestRunner.getTest().log(Status.INFO, "Want to search assessment in closed tab: " + AssignmentNameForReviewGradedSubmission);

        WebElement myAssignmentGrid = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@aria-labelledby='simple-tab-2']")));

        if (myAssignmentGrid.isDisplayed() && myAssignmentGrid.isEnabled()) {
            WebElement btnClosed = driver.findElement(By.xpath("//button[@id='simple-tab-3']"));
            btnClosed.click();

            WebElement panelTabClosed = driver.findElement(By.xpath("//div[@id='simple-tabpanel-3']"));

            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='simple-tabpanel-3']")));
            Thread.sleep(3000);

            String textClosedAssignments = panelTabClosed.getText();
            System.out.println("Closed Assignments are");
            System.out.println(textClosedAssignments);

            List<WebElement> totalAssignments = driver.findElements(By.xpath(".//div[contains(@class, 'MuiGrid-container')]"));
            System.out.println("Total Closed Assignments: " + totalAssignments.size());

            boolean assignment_found = false;
            for (WebElement assignment : totalAssignments) {
                WebElement assignmentNameElement = assignment.findElement(By.xpath(".//div[contains(@class, 'notranslate')]"));
                String assignmentsName = assignmentNameElement.getText();
                System.out.println("Assignment Name : " + assignmentsName);

                if (assignmentsName.equals(AssignmentNameForReviewGradedSubmission)) {
                    System.out.println("Found assignment: " + AssignmentNameForReviewGradedSubmission);
                    assignment_found = true;
                    try {
                        WebElement reviewButton = assignment.findElement(By.xpath(".//button[.//span[contains(text(), 'Review')] and not(@disabled)]"));
                        System.out.println("Review button available for assignment: " + AssignmentNameForReviewGradedSubmission);
                        TestRunner.getTest().log(Status.INFO, "Review button available for assignment: " + AssignmentNameForReviewGradedSubmission);
                        reviewButton.click();
                        System.out.println("Assignment open");
                        Thread.sleep(3000);
                        studentExecutor.handleTeacherInstructionsDialog();
                        reviewGradedSubmission();
                        TestRunner.getTest().log(Status.PASS, "Test Case Passed   :   Review Button Available  **********");
                    } catch (NoSuchElementException e) {
                        System.out.println("Review button not found for assignment: " + AssignmentNameForReviewGradedSubmission);
                        TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Review Button Not Available  **********");
                        return;
                    }
                    break;
                } else {
                    System.out.println("Assignment not found: " + AssignmentNameForReviewGradedSubmission);
                }
            }
            if (!assignment_found) {
                TestRunner.getTest().log(Status.INFO, "Assignment   " + AssignmentNameForReviewGradedSubmission + " that is Attempt successfully but not Visible in Close tab.");
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Assignment not found in close Tab");
            }
        }
    }

    public void reviewOptionGradedSubmission() throws InterruptedException {
        try {
            WebElement button = driver.findElement(By.id("btn-saveNext"));

            if (button.isDisplayed()) {
                button.click();
                System.out.println("Review Button found and clicked.");
                TestRunner.getTest().log(Status.PASS, "Test Case Passed   :   Review Button Clicked  **********");
                reviewGradedSubmission();
            } else {
                System.out.println("Review Button is not displayed.");
            }
        } catch (NoSuchElementException e) {
            System.out.println("Review Button not found: " + e.getMessage());
            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());

        }
    }

    public void reviewGradedSubmission() throws InterruptedException {
        Actions actions = new Actions(driver);
        actions.sendKeys(Keys.ESCAPE).build().perform();

        driver.switchTo().defaultContent();
        Thread.sleep(2000);

        WebElement questionPlayer = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("lesson-player-ifram")));

        if (questionPlayer.isDisplayed() && questionPlayer.isEnabled()){
            driver.switchTo().frame(questionPlayer);

            WebElement overviewWrapper = driver.findElement(By.xpath("//div[contains(@class, 'OverviewScreenWrapper')]"));
            WebElement answer_element = overviewWrapper.findElement(By.xpath(".//div[@class='ScrollbarsCustom-Content']"));

            List<WebElement> button_answers = answer_element.findElements(By.tagName("button"));
            System.out.println("Total Answer: " + button_answers.size());

                if (!button_answers.isEmpty()) {
                    WebElement button = button_answers.get(0);

                    if (button.isDisplayed()) {
                            System.out.println("Button was clicked: " + button.getText());
                            button.click();
                            System.out.println("Answer is clicked.");
                            CorrectAnswerExist();
                    } else {
                        System.out.println("Button is not displayed.");
                    }
                } else {
                    System.out.println("No answer buttons found.");
                    TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   No Answer Button found");
                }

        } else {
            System.out.println("Question buttons is not displayed.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed    :   Question Button Not Available");
            WebElement btnCloseReview = driver.findElement(By.xpath("//button[@id='closeReview-btn']"));
            if (btnCloseReview.isDisplayed() && btnCloseReview.isEnabled()){
                btnCloseReview.click();
            } else {
                System.out.println("Button is not displayed: " + btnCloseReview.getText());
            }
        }

    }

    public void CorrectAnswerExist() {
        driver.switchTo().defaultContent();

        List<WebElement> questionButtons = nav_Pagination.findElements(By.xpath("//button[contains(@aria-label, 'Go to page')]"));
        for (WebElement questionButton : questionButtons) {
            System.out.println("Question: " + questionButton.getText());
        }

        while (btn_NavNextPage.isEnabled()) {
            verifyCorrectAnswerNotDisplayed();
            btn_NavNextPage.click();
            wait.until(ExpectedConditions.stalenessOf(questionButtons.get(0)));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[contains(@aria-label, 'Go to page')]")));
        }

        WebElement btn_CloseReview = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@id='closeReview-btn']")));
        helper.scrollToElement(driver, btn_CloseReview);
        System.out.println("Clicked on close review");
        TestRunner.getTest().log(Status.INFO, "Clicked on close review");
        btn_CloseReview.click();
    }

    public void verifyCorrectAnswerNotDisplayed() {
        TestRunner.getTest().log(Status.INFO, "I'm into verify Review Graded Submission");
        try {
            WebElement element = wait.until(ExpectedConditions.presenceOfElementLocated(
                    By.xpath("//div[contains(@class,'ListItemWrapper Correct') or contains(@class,'correct-answer-icon') or contains(@class,'ListItemWrapper   Correct')]")
            ));

            if (!element.isDisplayed()) {
                System.out.println("Correct Answer is not displayed.");
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: Correct Answer is NOT displayed as expected.");
            } else {
                System.out.println("Correct Answer is displayed.");
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Correct Answer IS displayed.");
            }

        } catch (TimeoutException e) {
            // If the element isn't found within wait time, treat it as "not displayed"
            System.out.println("Element not found within the timeout - treating as not displayed.");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Correct Answer element not present as expected.");
        } catch (Exception e) {
            System.out.println("An unexpected error occurred: " + e.getMessage());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception in verifying Correct Answer.");
            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
        } finally {
            driver.switchTo().defaultContent();
        }
    }
}
