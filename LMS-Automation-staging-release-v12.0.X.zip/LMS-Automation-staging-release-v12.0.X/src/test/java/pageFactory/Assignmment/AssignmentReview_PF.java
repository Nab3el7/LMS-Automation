package pageFactory.Assignmment;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import apiHandler.GetAPIHandler;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.MyContent.AssignAssessment_PF;

import java.awt.*;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

//import static StepDefinitions.Configurations.driver;


public class AssignmentReview_PF {
    Helper helper;
    GetAPIHandler getAPIHandler;
    StudentExecutor_PF studentExecutor;
    CorrectAnswerExecutor_PF correctAnswerExecutor_pf;
    AssignAssessment_PF assignAssessment;
    AssignmentReview_PF assignmentReview_pf;
    public WebDriverWait wait;
    WebDriver driver;

    public static String answerReview;
    public static String answerOverview; // Declare a class-level variable


//    public static String AssignmentNameForCorrect = Configurations.getDotEnv().get("SITE_ASSIGNMENT_NAME_FOR_CORRECT_ANSWER");
    //    public static String AssignmentName = Configurations.getDotEnv().get("SITE_ASSIGNMENT_NAME");
//    String[] specificClasses = {"FL Grade 1", "FL Grade 2"};
    String[] specificClasses = {"FL Grade 5"};
    String questionID = null;
    WebElement panelTabOpen;
    boolean isCorrectOrder = false;

    public static final String BASE_NAME = Configurations.getDotEnv().get("SITE_ASSIGNMENT_NAME_FOR_CORRECT_ANSWER");
    public static final String AssignmentNameForCorrect;

    static {
        Random random = new Random();
        StringBuilder sb = new StringBuilder(6);
        String charSet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

        for (int i = 0; i < 6; i++) {
            int randomIndex = random.nextInt(charSet.length());
            sb.append(charSet.charAt(randomIndex));
        }

        String randomString = sb.toString();
        AssignmentNameForCorrect = BASE_NAME + " " + randomString;
    }


    @FindBy(xpath = "//div[@class='ScrollbarsCustom']//div[@class='ScrollbarsCustom-Content']")
    WebElement scroll_Units;

    @FindBy(xpath = "//div[@id='ContentPlayerMainPanel']")
    WebElement list_ContentPlayer;

    @FindBy(xpath = "//input[@name='title']")
    WebElement edt_AssignmentTitle;

    @FindBy(xpath = "//label[contains(text(),'Assign to')]/parent::div")
    WebElement dropDown_AssignTo;

    @FindBy(xpath = "(//div[@class='ScrollbarsCustom-Content'])[2]")
    WebElement panel_Assignments;

    @FindBy(xpath = "//nav[@aria-label='pagination navigation']")
    WebElement nav_Pagination;

    @FindBy(xpath = "//button[@aria-label='Go to next page']")
    WebElement btn_NavNextPage;

    public AssignmentReview_PF(WebDriver driver) {
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        helper = new Helper();
        getAPIHandler = new GetAPIHandler();
        studentExecutor = new StudentExecutor_PF(driver);
        correctAnswerExecutor_pf = new CorrectAnswerExecutor_PF(driver);
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }


    public void SelectAssignmentForCorrectAnswers() throws InterruptedException, AWTException {

        panel_Assignments.isDisplayed();

        WebElement panelTabOpen = panel_Assignments.findElement(By.xpath(".//div[@id='simple-tabpanel-2']"));

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='simple-tabpanel-2']")));
        Thread.sleep(2000);

        String textOpenAssignments = panelTabOpen.getText();
        System.out.println("Open Assignments are");
        System.out.println(textOpenAssignments);

        List<WebElement> totalAssignments = panel_Assignments.findElements(By.xpath(".//div[contains(@class, 'MuiGrid-container')]"));
        System.out.println("Total Assignments: " + totalAssignments.size());

        for (WebElement assignment : totalAssignments) {
            WebElement assignmentNameElement = assignment.findElement(By.xpath(".//div[contains(@class, 'notranslate')]"));
            String assignmentName = assignmentNameElement.getText();

            if (assignmentName.equals(AssignmentNameForCorrect)) {
                System.out.println("Found assignment: " + assignmentName);
                try {
                    WebElement startOrResumeButton = assignment.findElement(By.xpath(".//div[@statustype='START' or @statustype='RESUME']"));
                    startOrResumeButton.click();
                    System.out.println("Assignment started");
                    Thread.sleep(3000);
                    studentExecutor.handleTeacherInstructionsDialog();
                    AttemptAndSubmitWithCorrectAnswers();
                    Thread.sleep(2000);
                } catch (NoSuchElementException e) {
                    System.out.println("START/RESUME button not found for assignment: " + assignmentName);
                    return;
                }

                refreshPage();
                Thread.sleep(3000);
                studentExecutor.dialogBox_ImpAnnouncement();

                WebElement tabOpenPanel = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[@class='ScrollbarsCustom-Content'])[2]")));
                WebElement tabOpenAssignments = tabOpenPanel.findElement(By.xpath(".//div[@id='simple-tabpanel-2']"));

                List<WebElement> totalAssignment = tabOpenAssignments.findElements(By.xpath(".//div[contains(@class, 'notranslate')]"));
                System.out.println("Total Assignments: " + totalAssignment.size());
                if (!totalAssignment.isEmpty()) {
                    for (WebElement assignmentText : totalAssignment) {
                        System.out.println("Assignment Text: " + assignmentText.getText());
                    }
//                    Apply Recursive Function
//                    SelectAssignment();
                }
                break;
            } else {
                System.out.println("Assignment not found: " + assignmentName);
            }
        }
    }

    private void refreshPage() {
        driver.navigate().refresh();
    }

    public void AttemptAndSubmitWithCorrectAnswers() throws InterruptedException, AWTException {
        if (!isPaginationDisplayed()) {
            studentExecutor.AssignmentSubmitAsCompleted();
            return;
        }

        try {
            List<WebElement> questionButtons = nav_Pagination.findElements(By.xpath("//button[contains(@aria-label, 'Go to page')]"));

            for (WebElement questionButton : questionButtons) {
                String questionText = questionButton.getText();
                System.out.println("Question: " + questionText);
            }

            while (btn_NavNextPage.isEnabled()) {
                Thread.sleep(2000);
                AttemptAssignmentWithCorrectAnswers();
                btn_NavNextPage.click();
                Thread.sleep(2000);
            }

            getAnswersInOverviewPage();
            studentExecutor.AssignmentSubmitAsCompleted();
        } catch (NoSuchElementException | ElementNotInteractableException | TimeoutException e) {
            System.out.println("No Question found.");
        }
    }

    private boolean isPaginationDisplayed() {
        try {
            return nav_Pagination.isDisplayed();
        } catch (NoSuchElementException | ElementNotInteractableException | TimeoutException e) {
            return false;
        }
    }

    public void AttemptAssignmentWithCorrectAnswers() throws InterruptedException, AWTException {
        System.out.println("I'm in attempting all questions with correct answers");
        Thread.sleep(1000);

        WebElement questionPlayer = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("lesson-player-ifram")));
        driver.switchTo().frame(questionPlayer);
        WebElement QuestionBody = driver.findElement(By.xpath("//div[contains(@class, 'LessonPlayerRoot')]"));

        WebElement QuestionPlayer = null;

        try {
            List<WebElement> MultiParts = QuestionBody.findElements(By.xpath("//div[contains(@class, 'planComponentQuestion')]"));
            System.out.println("Total number of multi-part on this page: " + MultiParts.size());

            for (WebElement part : MultiParts) {
                QuestionPlayer = part.findElement(By.xpath(".//div[contains(@class, 'QuestionPlayer')]"));

                System.out.println("Question is found");
                String questionType = QuestionPlayer.getAttribute("data-type");
                System.out.println("Question Type is: " + questionType);

                WebElement questionRoot = QuestionPlayer.findElement(By.xpath(".//div[contains(@class, 'question-root')]"));
                questionID = questionRoot.getAttribute("data-question-id");
                System.out.println("Question ID is: " + questionID);

                switch (questionType) {
                    case "extended-text-interaction" -> studentExecutor.QuestionExtendedTextInteraction();
                    case "choice-interaction-single" -> QuestionChoiceInteractionSingleAccurate(questionRoot);
                    case "choice-interaction" -> QuestionChoiceInteractionsAccurate(questionRoot);
                    case "inline-choice-text-interaction" -> studentExecutor.QuestionInlineChoiceTextInteraction();
                    case "inline-choice-spelling-interaction" -> QuestionInlineChoiceSpellingInteractionAccurate(questionRoot);
                    case "drawing-interaction" -> studentExecutor.QuestionDrawingInteraction();
                    case "upload-interaction" -> studentExecutor.QuestionUploadInteraction();
                    default -> {
                    }
                }

            }
        } catch (NoSuchElementException e) {
            System.out.println("This is a content player question and have no any data type question");
            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
        } finally {
            driver.switchTo().defaultContent();
        }
    }


    public void getAnswersInOverviewPage() throws InterruptedException {
        driver.switchTo().frame("lesson-player-ifram");
        WebElement overviewWrapper = driver.findElement(By.xpath("//div[@class='OverviewScreenWrapper MuiBox-root css-0']"));

        Thread.sleep(1000);
        answerOverview = overviewWrapper.findElement(By.xpath(".//div[@type='answered']")).getText();
        System.out.println("Total answers on Overview page is: " + answerOverview);
        driver.switchTo().defaultContent();

    }


    public void getAnswersInReviewPage() throws InterruptedException {
        driver.switchTo().frame("lesson-player-ifram");
        WebElement overviewWrapper = driver.findElement(By.xpath("//div[@class='OverviewScreenWrapper MuiBox-root css-0']"));

        Thread.sleep(1000);
        answerReview = overviewWrapper.findElement(By.xpath(".//div[@type='answered']")).getText();
        System.out.println("Total answers on Overview page is: " + answerReview);
        driver.switchTo().defaultContent();

        if (answerReview.equals(answerOverview)){
            System.out.println("Answer is matching in overview and review page");
        }else {
            System.out.println("Answer is not matching in overview and review page");
        }
    }


    public void ReviewAttemptedCorrectAnswersAssignmentIntoClosedTab() throws InterruptedException {

        panel_Assignments.isDisplayed();

        WebElement btnClosed = driver.findElement(By.xpath("//button[@id='simple-tab-3']"));
        btnClosed.click();

        WebElement panelTabClosed = panel_Assignments.findElement(By.xpath("//div[@id='simple-tabpanel-3']"));

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='simple-tabpanel-3']")));
        Thread.sleep(5000);

        String textClosedAssignments = panelTabClosed.getText();
        System.out.println("Closed Assignments are");
        System.out.println(textClosedAssignments);

        List<WebElement> totalAssignments = panel_Assignments.findElements(By.xpath(".//div[contains(@class, 'MuiGrid-container')]"));
        System.out.println("Total Assignments: " + totalAssignments.size());

        for (WebElement assignment : totalAssignments) {
            WebElement assignmentNameElement = assignment.findElement(By.xpath(".//div[contains(@class, 'notranslate')]"));
            String assignmentsName = assignmentNameElement.getText();

            if (assignmentsName.equals(AssignmentNameForCorrect)) {
                System.out.println("Found assignment: " + AssignmentNameForCorrect);
                try {
                    WebElement reviewButton = assignment.findElement(By.xpath(".//button[.//span[contains(text(), 'Review')] and not(@disabled)]"));
                    reviewButton.click();
                    System.out.println("Assignment open");
                    Thread.sleep(3000);
                    studentExecutor.handleTeacherInstructionsDialog();
                    getAnswersInReviewPage();
                    Thread.sleep(1000);
                } catch (NoSuchElementException e) {
                    System.out.println("Review button not found for assignment: " + AssignmentNameForCorrect);
                    return;
                }
                break;
            } else {
                System.out.println("Assignment not found: " + AssignmentNameForCorrect);
            }
        }
    }


    public void QuestionChoiceInteractionSingleAccurate(WebElement questionPart) throws InterruptedException {
        System.out.println("Click on correct 1 option");
        Thread.sleep(1000);

        try {
//            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(".//div[contains(@class,'SingleSelectWrapper')]")));

            WebElement inputOptions = questionPart.findElement(By.xpath(".//div[contains(@class,'SingleSelectWrapper')]"));
            List<WebElement> listOptions = inputOptions.findElements(By.tagName("li"));
            int totalInputElements = listOptions.size();
            System.out.println("Total inputElements: " + totalInputElements);

            if (!listOptions.isEmpty()) {
                List<String> correctKeys = getAPIHandler.getCorrectAnswerResponseIdentifier(questionID);
                System.out.println("Correct Keys ID's of Question: ");
                for (String key : correctKeys) {
                    System.out.println(key);
                }

                for (WebElement option : listOptions) {
                    WebElement radioBtn = option.findElement(By.tagName("input"));
                    String id = radioBtn.getAttribute("aria-labelledby").substring("checkbox-list-label-".length());

                    System.out.println("Option ID for Matching: " + id);

                    if (correctKeys.contains(id)) {
                        System.out.println("Correct option found");
                        radioBtn.click();
                        break;
                    }
                }
                System.out.println("Test case Passed    :   Question attempted successfully");
            } else {
                System.out.println("Test case Failed    :   No options found");
            }
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
            System.out.println("Test Case Failed    :   Exception is found");
        }
        Thread.sleep(2000);
        helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
    }
    public void QuestionChoiceInteractionsAccurate(WebElement questionPart) throws InterruptedException {
        System.out.println("I'm in Select Accurate Choice Interaction question");
        Thread.sleep(1000);
        try {
//            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class,'MultiselectList')]")));

            WebElement inputOptions = questionPart.findElement(By.xpath(".//div[contains(@class,'MultiselectList')]"));
            List<WebElement> listOptions = inputOptions.findElements(By.tagName("li"));
            List<WebElement> listIDs = inputOptions.findElements(By.xpath(".//div[contains(@class,'MuiListItemText')]"));

            int totalInputOptions = listOptions.size();
            System.out.println("Total options: " + totalInputOptions);

            List<String> correctKeys = getAPIHandler.getCorrectAnswerResponseForChoiceInteraction(questionID);
            System.out.println("Correct Keys of Question: ");
            for (String key : correctKeys) {
                System.out.println(key);
            }

            if (!listOptions.isEmpty()) {
                // Uncheck all checkboxes if already checked
                for (WebElement option : listOptions) {
                    WebElement checkbox = option.findElement(By.xpath(".//input[@type='checkbox']"));
                    if (checkbox.isSelected()) {
                        checkbox.click();
                    }
                }

                for (WebElement option : listIDs) {
                    String id = option.getAttribute("id");
                    id = id.substring("checkbox-list-label-".length());
                    System.out.println("Option ID for Matching: " + id);
                    for (String correctKey : correctKeys) {
                        if (correctKey.equals(id)) {
//                            WebElement checkbox = option.findElement(By.xpath(".//input[@type='checkbox']"));
                            option.click();
                            System.out.println("Correct option clicked");
                        }
                    }
                }
                System.out.println("Test case Passed    :   Question attempted successfully");
            } else {
                System.out.println("Test case Failed    :   No options found");
            }
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
            System.out.println("Test Case Failed    :   Exception is found");
        }
        Thread.sleep(2000);
        helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
    }


    public void QuestionInlineChoiceSpellingInteractionAccurate(WebElement questionPart) throws InterruptedException {
        System.out.println("I'm in Enter Accurate Inline Choice Spelling Interaction");
        try {
//            WebElement QuestionPlayer = driver.findElement(By.xpath("//div[contains(@class, 'QuestionPlayer')]"));

            //SI = Spelling Interactions
            WebElement ItemQuestionContainerSI = questionPart.findElement(By.xpath(".//div[contains(@class, 'questionTextContainer')]"));
            String questionText = ItemQuestionContainerSI.getText();
            System.out.println("Question Text: " + questionText);

            WebElement ItemAnswerContainerSI = questionPart.findElement(By.xpath(".//div[contains(@class, 'testItemAnswersContainer')]"));
            List<WebElement> AnswersInputsSI = ItemAnswerContainerSI.findElements(By.tagName("input"));

            int numberOfInputs = AnswersInputsSI.size();
            System.out.println("Number of inputs: " + numberOfInputs);

            List<String> correctTextResponse = getAPIHandler.getCorrectAnswerResponseForSpellingInteraction(questionID);
            System.out.println("Correct Text Response of Question: ");
            for (String textResponse : correctTextResponse) {
                System.out.println(textResponse);
            }

            for (int i = 0; i < Math.min(correctTextResponse.size(), numberOfInputs); i++) {
                WebElement inputSI = AnswersInputsSI.get(i);

                JavascriptExecutor js = (JavascriptExecutor) driver;
                js.executeScript("arguments[0].value='';", inputSI);

                String wordToType = correctTextResponse.get(i);
                char character = wordToType.charAt(0);

                inputSI.sendKeys(String.valueOf(character));
            }

        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
            System.out.println("Exception is found    :   Question text is not visible");
        }

        helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
    }

}
