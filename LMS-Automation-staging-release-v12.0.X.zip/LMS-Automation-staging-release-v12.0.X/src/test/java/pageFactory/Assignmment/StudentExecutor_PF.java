package pageFactory.Assignmment;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.StudentsModule.AddNewStudentSteps;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.ElementNotInteractableException;

import java.awt.*;
import java.awt.event.InputEvent;
import java.time.Duration;
import java.util.List;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static pageFactory.Gradebook.AssignmentScoreVerification_PF.totalQuestions;
import static pageFactory.Gradebook.AssignmentScoreVerification_PF.totalScore;

public class StudentExecutor_PF {
    Helper helper;
    public WebDriverWait wait;
    WebDriver driver;

    WebElement dialogReview = null;

    @FindBy(xpath = "//div[contains(@class, 'AssignmentWrapper')]")
    WebElement card_MyAssignment;

    String tab_AssignmentCard = "//div[@aria-label='wrapped label tabs example']";

    @FindBy(xpath = "//span[@role='progressbar']")
    WebElement loader;
//    WebElement loader = driver.findElement(By.xpath("//span[@role='progressbar']"));

    @FindBy(xpath = "(//div[@class='ScrollbarsCustom-Content'])[2]")
    WebElement panel_Assignments;

    @FindBy(xpath = "//nav[@aria-label='pagination navigation']")
    WebElement nav_Pagination;

    @FindBy(xpath = "//button[@aria-label='Go to next page']")
    WebElement btn_NavNextPage;

    @FindBy(xpath = "//div[contains(@class,'correctionType')]//input")
    WebElement btnRadio_Choose;

    @FindBy(xpath = "//div[@data-rbd-droppable-id='column-choices']")
    WebElement container_DragdropValues;

    @FindBy(xpath = "//span[@role='progressbar']")
    WebElement progressBar;

    public static String boxTitle;
    public static String messageAnnouncement;

    public StudentExecutor_PF(WebDriver driver) {
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        helper = new Helper();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    public void selectAssignmentTabs() throws InterruptedException{
        card_MyAssignment.isDisplayed();
        WebElement tab_Assignment = card_MyAssignment.findElement(By.xpath(tab_AssignmentCard));
        TestRunner.getTest().log(Status.PASS, "Test Case Passed : My Assignment grid shows successfully");
        tab_Assignment.click();

        List<WebElement> AssignmentTabs = tab_Assignment.findElements(By.xpath(".//button"));
        TestRunner.getTest().log(Status.INFO, "Total assignment tabs is : "+ AssignmentTabs.size());

        for (WebElement AssignmentTab : AssignmentTabs) {
            String tabText = AssignmentTab.getText();
            TestRunner.getTest().log(Status.INFO, "Assignment tab(s) name is: " +tabText);
            AssignmentTab.click();
            Thread.sleep(1000);
        }

        WebElement openTab = tab_Assignment.findElement(By.xpath(".//button[contains(text(), 'Open')]"));
        System.out.println("Click on Open tab " + openTab.getText());
        TestRunner.getTest().log(Status.PASS, "Test Case Passed : Open tab is selected successfully");
        openTab.click();
        Thread.sleep(1000);
    }

    public void selectAssignmentIntoPanel() throws InterruptedException, AWTException {
        if (panel_Assignments.isDisplayed()) {
            List<WebElement> tabPanels = panel_Assignments.findElements(By.xpath(".//div[@id='simple-tabpanel-2']"));

            int totalAssignments = tabPanels.size();
            System.out.println("Total Assignments: " + totalAssignments);

            for (WebElement tabPanel : tabPanels) {
                processAssignmentPanel(tabPanel);
            }
        }
    }

    private void processAssignmentPanel(WebElement tabPanel) throws InterruptedException, AWTException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[@class='ScrollbarsCustom-Content'])[2]")));
        Thread.sleep(2000);
        String panelText = tabPanel.getText();
        System.out.println("Panel Text: " + panelText);

        String[] AssignmentInfo = panelText.split("\\n");

        for (String info : AssignmentInfo) {
            if (info.contains("INFO:") || info.contains("Start:") || info.contains("Due:")) {
                TestRunner.getTest().log(Status.INFO, "Open Assignments are: ");
                TestRunner.getTest().log(Status.INFO,  info.trim());
            }
        }

        try {
            WebElement btn_Start = tabPanel.findElement(By.xpath("//div[@statustype='START' or @statustype='RESUME']"));
//            WebElement btn_Start = tabPanel.findElement(By.xpath("(//div[@statustype='RESUME'])[3]"));
            btn_Start.click();
            Thread.sleep(3000);
            handleTeacherInstructionsDialog();
//            AssignmentSubmitAsCompleted();
            attemptAllQuestionsAndSubmit();
//            get_TotalQuestions();
            Thread.sleep(2000);
        } catch (NoSuchElementException e) {
            return;
        }
        refreshPage();
        Thread.sleep(3000);
        dialogBox_ImpAnnouncement();

        tabPanel = driver.findElement(By.xpath(".//div[@id='simple-tabpanel-2']"));

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[@class='ScrollbarsCustom-Content'])[2]")));

        processAssignmentPanel(tabPanel);
    }

    private void refreshPage() {
        driver.navigate().refresh();
    }

    public void dialogBox_ImpAnnouncement() throws InterruptedException{
        try {
            WebElement dialog_ImpAnnouncement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@aria-labelledby='customized-dialog-title']")));

            if (dialog_ImpAnnouncement.isDisplayed()) {

                WebElement title= driver.findElement(By.xpath("//span[@class='isLeafContentDetail']"));
                boxTitle= title.getText();
                System.out.println("Title in Important Announcement is: " + boxTitle);

                WebElement msgInBox= driver.findElement(By.xpath("//p[@class='value']"));
                messageAnnouncement= msgInBox.getText();
                System.out.println("Announcement in Important Announcement is: " + messageAnnouncement);

                WebElement dialog_close = dialog_ImpAnnouncement.findElement(By.xpath("//button[@aria-label='archive']"));
                dialog_close.click();
                Thread.sleep(2000);
            } else {
                System.out.println("Dialog element found, but it is not visible.");
            }
        } catch (NoSuchElementException | ElementNotInteractableException | TimeoutException e) {
            System.out.println("No announcement found.");
        }
    }

    public void get_TotalQuestions() throws InterruptedException, AWTException {
        nav_Pagination.isDisplayed();

        WebElement btn_Page = nav_Pagination.findElement(By.xpath("//button[@aria-label='Go to page 11']"));
        btn_Page.click();
//        Thread.sleep(1000);
//        btn_NavNextPage.click();
//        WebElement btn_previous = nav_Pagination.findElement(By.xpath("//button[@aria-label='Go to page 16']"));
//        btn_previous.click();

        Thread.sleep(2000);
        AttemptAssignment();
//        btn_NavNextPage.click();
//        Thread.sleep(2000);

    }

    public void attemptAllQuestionsAndSubmit() throws InterruptedException, AWTException {
        if (!isPaginationDisplayed()) {
            AssignmentSubmitAsCompleted();
            return;
        }

        try {
            List<WebElement> questionButtons = nav_Pagination.findElements(By.xpath("//button[contains(@aria-label, 'Go to page')]"));

            for (WebElement questionButton : questionButtons) {
                String questionText = questionButton.getText();
                System.out.println("Question: " + questionText);
            }

            while (btn_NavNextPage.isEnabled()) {
                Thread.sleep(2000);
                AttemptAssignment();
                btn_NavNextPage.click();
                Thread.sleep(2000);
            }

            AssignmentSubmitAsCompleted();
        } catch (NoSuchElementException | ElementNotInteractableException | TimeoutException e) {
            System.out.println("No Question found.");
        }
    }

    private boolean isPaginationDisplayed() {
        try {
            return nav_Pagination.isDisplayed();
        } catch (NoSuchElementException | ElementNotInteractableException | TimeoutException e) {
            return false;
        }
    }


    public void AttemptAssignment() throws InterruptedException, AWTException {
        System.out.println("I'm in attempting all questions");
        Thread.sleep(1000);

        WebElement questionPlayer = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("lesson-player-ifram")));
        driver.switchTo().frame(questionPlayer);
        WebElement QuestionBody = driver.findElement(By.xpath("//div[contains(@class, 'LessonPlayerRoot')]"));

        WebElement QuestionPlayer = null;

        try {
            QuestionPlayer = QuestionBody.findElement(By.xpath("//div[contains(@class, 'QuestionPlayer')]"));

            System.out.println("Question is found");
            String questionType = QuestionPlayer.getAttribute("data-type");
            System.out.println("Question Type is: " + questionType);

            switch (questionType) {
                case "extended-text-interaction" -> QuestionExtendedTextInteraction();
                case "choice-interaction-single" -> QuestionChoiceInteractionSingle();
                case "choice-interaction" -> QuestionChoiceInteractions();
                case "match-dragdrop-interaction" -> QuestionMatchDragdropInteraction();
                case "inline-choice-select-interaction" -> QuestionInlineChoiceSelectInteraction();
                case "gap-match-interaction" -> QuestionGapMatchInteraction();
                case "choice-imagelabel-select-interaction" -> QuestionChoiceImageLabelSelectInteraction();
                case "inline-choice-text-interaction" -> QuestionInlineChoiceTextInteraction();
                case "inline-choice-spelling-interaction" -> QuestionInlineChoiceSpellingInteraction();
                case "drawing-interaction" -> QuestionDrawingInteraction();
                case "match-interaction" -> QuestionMatchInteraction();
                case "upload-interaction" -> QuestionUploadInteraction();
                default -> { }
            }
        } catch (NoSuchElementException e) {
            System.out.println("This is a content player question and have no any data type question");
//            WebElement ContentPlayer = QuestionBody.findElement(By.xpath("//div[contains(@class, 'resourcePlayerWrapper')]"));
//            String Content = ContentPlayer.getText();
//            System.out.println(Content);

            helper.takeScreenshot(driver , Thread.currentThread().getStackTrace()[1].getMethodName() );
        } finally {
            driver.switchTo().defaultContent();
        }
    }

    public void QuestionExtendedTextInteraction() throws InterruptedException{
        TestRunner.startTest("Question: Extended Text Interaction");
        System.out.println("Enter data into text box");

//        WebElement edt_RichTextBox = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//body[@id='tinymce']")));
        WebElement RichTextBoxBody = driver.findElement(By.xpath("//div[@class='tox-edit-area']/iframe"));

        driver.switchTo().frame(RichTextBoxBody);

        WebElement edt_RichTextBox = driver.findElement(By.xpath("//body[@id='tinymce']//p"));
        if (edt_RichTextBox.isDisplayed() && edt_RichTextBox.isEnabled()) {
            System.out.println("Edit text area is found");

            edt_RichTextBox.clear();

            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript("arguments[0].value='';", edt_RichTextBox);

            String randomTextInteraction = generateRandomText("Historians use skills ");
            System.out.println(randomTextInteraction);

            edt_RichTextBox.sendKeys(randomTextInteraction);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed : Question attempted successfully!");
        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Question attempted failed!");
        }

        helper.takeScreenshot(driver , Thread.currentThread().getStackTrace()[1].getMethodName() );

        driver.switchTo().defaultContent();

    }

    public void QuestionChoiceInteractionSingle() throws InterruptedException{
        System.out.println("Click on 1 option");
        try{
            WebElement inputElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class,'SingleSelectWrapper')]")));

            List<WebElement> listOptions = inputElement.findElements(By.tagName("li"));

            int totalInputElements = listOptions.size();
            System.out.println("Total inputElements: " + totalInputElements);

            if (!listOptions.isEmpty()) {
                Random random = new Random();
                int randomIndex = random.nextInt(listOptions.size());

                WebElement randomInput = listOptions.get(randomIndex);
                randomInput.click();
            } else {
                System.out.println("Option is already selected");
            }
            System.out.println("Test case Passed    :   Question attempted successfully");
        } catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            helper.takeScreenshot(driver , Thread.currentThread().getStackTrace()[1].getMethodName() );
            System.out.println("Test Case Failed    :   Exception is found");
        }

        helper.takeScreenshot(driver , Thread.currentThread().getStackTrace()[1].getMethodName() );

    }

    public void QuestionMatchDragdropInteraction() throws InterruptedException{
        System.out.println("I'm in Match Dragdrop Interaction question");

        WebElement QuestionComponentBody = driver.findElement(By.xpath("//div[@class = 'planComponentQuestion']"));

        WebElement QuestionContainer = QuestionComponentBody.findElement(By.xpath("//div[@class = 'column-options-container']"));
        List<WebElement> values_Drag = QuestionContainer.findElements(By.xpath("//div[contains(@class, 'task-container task-container-draging-off')]"));

        WebElement AnswerContainer = QuestionComponentBody.findElement(By.xpath("//div[@class='column-answers-container']"));
        List<WebElement> TotalAnswerContainers = AnswerContainer.findElements(By.xpath("//div[contains(@class, 'column-tasks-container')]"));
        WebElement drop = driver.findElement(By.xpath("//div[@data-rbd-droppable-id='cell1']"));

        Actions builder = new Actions(driver);
        Random random = new Random();

        while (!values_Drag.isEmpty()) {
            WebElement dragValue = values_Drag.get(0);
            System.out.println("Value to be dragged: " + dragValue.getText());
            highlightElement(dragValue);

            WebElement randomContainer = TotalAnswerContainers.get(random.nextInt(TotalAnswerContainers.size()));
            highlightElement(randomContainer);

//            builder.moveToElement(dragValue).clickAndHold().moveToElement(randomContainer).release().perform();
            builder.dragAndDrop(dragValue, randomContainer).perform();

            Thread.sleep(3000);

            values_Drag.remove(0);

            TotalAnswerContainers = AnswerContainer.findElements(By.xpath("//div[contains(@class, 'column-tasks-container')]"));
        }


        int totalContainers = TotalAnswerContainers.size();
        System.out.println("Total Answer containers is: " + totalContainers);

        helper.takeScreenshot(driver , Thread.currentThread().getStackTrace()[1].getMethodName() );

    }

    public void QuestionChoiceInteractions() throws InterruptedException {
        System.out.println("I'm in Choice Interaction question");

        WebElement inputOptions = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class,'MultiselectList')]")));

        WebElement questionTextHeader = driver.findElement(By.xpath("//div[contains(@class, 'testItemHeader')]"));
        String questionText = questionTextHeader.getText();

        System.out.println("Question Text is: " + questionText);

        Pattern pattern = Pattern.compile("\\d+");
        Matcher matcher = pattern.matcher(questionText);

        int numberOfChoices = 0;
        if (matcher.find()) {
            numberOfChoices = Integer.parseInt(matcher.group());
            System.out.println("Number of choices: " + numberOfChoices);
        } else {
            System.out.println("No numeric value found in the question text");
        }

        List<WebElement> listOptions = inputOptions.findElements(By.tagName("li"));

        int totalInputOptions = listOptions.size();
        System.out.println("Total options: " + totalInputOptions);

        if (numberOfChoices == 0) {
            for (WebElement option : listOptions) {
                if (!option.isSelected()) {
                    option.click();
                    System.out.println("Selected Option: " + option.getText());
                }
            }
        } else if (totalInputOptions >= numberOfChoices) {
            int selectedOptionsCount = 0;
            System.out.println(totalInputOptions + ">=" + numberOfChoices);
            for (WebElement option : listOptions) {
                if (option.isSelected()) {
                    System.out.println("Already selected option is: " + option.getText());
//                    option.click();
                    selectedOptionsCount++;
                    Thread.sleep(1000);
                }
            }

            Random random = new Random();
            while (selectedOptionsCount < numberOfChoices) {
                int randomOption = random.nextInt(listOptions.size());
                WebElement selectedOption = listOptions.get(randomOption);
                if (!selectedOption.isSelected()) {
                    selectedOption.click();
                    System.out.println("Selected Option: " + selectedOption.getText());
                    selectedOptionsCount++;
                }
            }
        } else {
            System.out.println("Insufficient options to select.");
        }
        helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
    }

    public void QuestionInlineChoiceSelectInteraction() throws InterruptedException{
        System.out.println("I'm in Inline Choice Select Interaction question");

        WebElement ItemAnswerContainer = driver.findElement(By.xpath("//div[contains(@class, 'testItemAnswersContainer')]"));
        List<WebElement> AnswersDropdowns;

        for (int attempt = 1; attempt <= 3; attempt++) {
            try {
                AnswersDropdowns = ItemAnswerContainer.findElements(By.xpath("//div[contains(@class, 'correct-container')]"));

                for (WebElement dropdown : AnswersDropdowns) {
                    WebElement dropdownElement = wait.until(ExpectedConditions.elementToBeClickable(dropdown.findElement(By.tagName("select"))));

                    List<WebElement> SelectableOptions = dropdownElement.findElements(By.tagName("option"));
                    List<WebElement> nonChooseOptions = SelectableOptions.stream().filter(option -> !option.getText().equalsIgnoreCase("choose")).toList();

                    for (WebElement option : nonChooseOptions) {
                        System.out.println("Option Text: " + option.getText());
                    }

                    int totalNonChooseOptions = nonChooseOptions.size();

                    if (totalNonChooseOptions > 0) {
                        Random random = new Random();
                        int randomIndex = random.nextInt(totalNonChooseOptions);
                        WebElement randomOption = nonChooseOptions.get(randomIndex);
                        randomOption.click();
                    }
                }
                break;
            } catch (StaleElementReferenceException | TimeoutException e) {
                System.out.println("Exception occurred. Retrying outer loop attempt " + attempt);
            }
        }

        Thread.sleep(2000);
        helper.takeScreenshot(driver , Thread.currentThread().getStackTrace()[1].getMethodName() );
    }

    public void QuestionGapMatchInteraction() throws InterruptedException{
        System.out.println("I'm in Gap Match Interaction question");

        WebElement QuestionComponentBody = driver.findElement(By.xpath("//div[@class = 'planComponentQuestion']"));

        WebElement QuestionContainer = QuestionComponentBody.findElement(By.xpath("//div[@class = 'column-options-container']"));
        List<WebElement> values_Drag = QuestionContainer.findElements(By.xpath("//div[contains(@class, 'task-container task-container-draging-off')]"));

        WebElement AnswerContainer = QuestionComponentBody.findElement(By.xpath("//div[@class='column-answers-container']"));
        List<WebElement> TotalAnswerContainers = AnswerContainer.findElements(By.xpath("//div[contains(@class, 'column-tasks-container')]"));
        System.out.println("Total Answers container is: " + TotalAnswerContainers.size());
        WebElement drop = driver.findElement(By.xpath("(//div[@class='column-tasks-container empty-text-water-mark  dragging-out-column column-empty-task'])[1]"));

        for (WebElement option : values_Drag) {
            String optionText = option.findElement(By.tagName("span")).getText();
            System.out.println("Option: " + optionText);
        }

        Actions actions = new Actions(driver);
        WebElement elementToDrag = values_Drag.get(0);
        highlightElement(elementToDrag);
        highlightElement(drop);
        actions.dragAndDrop(elementToDrag, drop).build().perform();

        helper.takeScreenshot(driver , Thread.currentThread().getStackTrace()[1].getMethodName() );

    }

    public void QuestionChoiceImageLabelSelectInteraction() throws InterruptedException{
        System.out.println("I'm in Choice Image Label Select Interaction");

        WebElement ImageContainer = driver.findElement(By.xpath("//div[contains(@class, 'imageBodyContainer')]"));
        List<WebElement> AnswersDropdowns;

        for (int attempt = 1; attempt <= 3; attempt++) {
            try {
                AnswersDropdowns = ImageContainer.findElements(By.xpath("//div[contains(@class, 'correct-container')]"));

                for (WebElement dropdown : AnswersDropdowns) {
                    WebElement dropdownElement = wait.until(ExpectedConditions.elementToBeClickable(dropdown.findElement(By.tagName("select"))));

                    List<WebElement> SelectableOptions = dropdownElement.findElements(By.tagName("option"));
                    List<WebElement> nonChooseOptions = SelectableOptions.stream().filter(option -> !option.getText().equalsIgnoreCase("choose")).toList();

                    for (WebElement option : nonChooseOptions) {
                        System.out.println("Option Text: " + option.getText());
                    }

                    int totalNonChooseOptions = nonChooseOptions.size();

                    if (totalNonChooseOptions > 0) {
                        Random random = new Random();
                        int randomIndex = random.nextInt(totalNonChooseOptions);
                        WebElement randomOption = nonChooseOptions.get(randomIndex);
                        randomOption.click();
                    }
                }
                break;
            } catch (StaleElementReferenceException | TimeoutException e) {
                System.out.println("Exception occurred. Retrying outer loop attempt " + attempt);
            }
        }

        Thread.sleep(2000);
        helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
    }

    public void QuestionInlineChoiceTextInteraction() throws InterruptedException{
        TestRunner.startTest("Question: Inline Choice Text Interaction");
        System.out.println("I'm in Inline Choice Text Interaction");

        WebElement ItemAnswerContainerVB = driver.findElement(By.xpath("//div[contains(@class, 'testItemAnswersContainer')]"));
        List<WebElement> AnswersTextAreaVB;         //VB = Vocabulary Builder

        AnswersTextAreaVB = ItemAnswerContainerVB.findElements(By.tagName("textarea"));

        int numberOfTextAreas = AnswersTextAreaVB.size();
        System.out.println("Number of text areas: " + numberOfTextAreas);
        TestRunner.getTest().log(Status.INFO, "Total number of edit text boxes: " + numberOfTextAreas);

        for (WebElement textAreaVB : AnswersTextAreaVB) {

            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript("arguments[0].value='';", textAreaVB);

            String RandomTextForTextAreaVB = generateRandomText("Automated Text Generated For Inline Choice Text Interaction ");
            System.out.println(RandomTextForTextAreaVB);

            textAreaVB.sendKeys(RandomTextForTextAreaVB);
            TestRunner.getTest().log(Status.PASS, "Test case Passed    :   Question attempted successfully " + RandomTextForTextAreaVB);
        }

        Thread.sleep(2000);
        helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
    }

    public void QuestionInlineChoiceSpellingInteraction() throws InterruptedException{
        System.out.println("I'm in Inline Choice Spelling Interaction");
        try {
            WebElement QuestionPlayer = driver.findElement(By.xpath("//div[contains(@class, 'QuestionPlayer')]"));

            //SI = Spelling Interactions
            WebElement ItemQuestionContainerSI = QuestionPlayer.findElement(By.xpath("//div[contains(@class, 'questionTextContainer')]"));
            WebElement typedWord = ItemQuestionContainerSI.findElement(By.tagName("strong"));
            System.out.println("Entered value is: " + typedWord.getText());

            WebElement ItemAnswerContainerSI = QuestionPlayer.findElement(By.xpath("//div[contains(@class, 'testItemAnswersContainer')]"));
            List<WebElement> AnswersInputsSI = ItemAnswerContainerSI.findElements(By.tagName("input"));

            int numberOfInputs = AnswersInputsSI.size();
            System.out.println("Number of inputs: " + numberOfInputs);

            String wordToType = typedWord.getText();

            for (int i = 0; i < Math.min(wordToType.length(), numberOfInputs); i++) {
                WebElement inputSI = AnswersInputsSI.get(i);

                JavascriptExecutor js = (JavascriptExecutor) driver;
                js.executeScript("arguments[0].value='';", inputSI);

                char character = wordToType.charAt(i);
                inputSI.sendKeys(String.valueOf(character));
            }

            Thread.sleep(2000);
            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
        } catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            helper.takeScreenshot(driver , Thread.currentThread().getStackTrace()[1].getMethodName() );
            System.out.println("Exception is found    :   Question text is not visible");
        }

    }

    public void QuestionDrawingInteraction() throws InterruptedException, AWTException{
        TestRunner.startTest("Question: Drawing Interaction");
        System.out.println("I'm in Drawing Interaction");

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class, 'canvasContainerOuter')]")));

        WebElement QuestionPlayer = driver.findElement(By.xpath("//div[contains(@class, 'QuestionPlayer')]"));

        //DI = Drawing Interactions
        WebElement ItemQuestionContainerDI = QuestionPlayer.findElement(By.xpath("//div[contains(@class, 'questionTextContainer')]"));
        System.out.println("Entered value is: " + ItemQuestionContainerDI.getText());

        WebElement ItemAnswerContainerDI = QuestionPlayer.findElement(By.xpath("//div[contains(@class, 'imageBodyContainer')]"));
        List<WebElement> AnswerButtonDI = ItemAnswerContainerDI.findElements(By.tagName("button"));

        int numberOfButtons = AnswerButtonDI.size();
        System.out.println("Number of buttons: " + numberOfButtons);
        TestRunner.getTest().log(Status.INFO, "Number of buttons shows in drawing panel: " + numberOfButtons);

        WebElement ItemAnswerCanvasDI = QuestionPlayer.findElement(By.xpath("//div[contains(@class, 'canvasContainerOuter')]"));

        int canvasWidth = ItemAnswerCanvasDI.getSize().getWidth();
        int canvasHeight = ItemAnswerCanvasDI.getSize().getHeight();
        System.out.println("Canvas width is: " + canvasWidth + " Canvas height is: " + canvasHeight);
        TestRunner.getTest().log(Status.INFO, "Drawing canvas width is: " + canvasWidth + " Canvas height is: " + canvasHeight);

        JavascriptExecutor js = (JavascriptExecutor) driver;

        for (int i = 0; i < numberOfButtons; i++) {
            WebElement button = AnswerButtonDI.get(i);
            button.click();
            Thread.sleep(1000); // You might need to adjust the sleep duration

            if (i == 0 || i == 1) {
//                drawRandomLineUsingJS(js, ItemAnswerCanvasDI, canvasWidth, canvasHeight);
                simulateDrawingAction(js, ItemAnswerCanvasDI);


            } else {
                System.out.println("Button is clicked");
            }
        }

        TestRunner.getTest().log(Status.PASS, "Test Case Passed : Question attempted successfully!");

        Thread.sleep(2000);
        helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
    }

    public void QuestionMatchInteraction() throws InterruptedException {
        System.out.println("I'm in Match Interaction");

        WebElement QuestionPlayer = driver.findElement(By.xpath("//div[contains(@class, 'QuestionPlayer')]"));

        //MI = Match Interactions
        WebElement ItemQuestionContainerMI = QuestionPlayer.findElement(By.xpath("//div[contains(@class, 'questionTextContainer')]"));
        System.out.println("Question heading is: " + ItemQuestionContainerMI.getText());

        WebElement ItemAnswerContainerMI = QuestionPlayer.findElement(By.xpath("//div[contains(@class, 'testItemAnswersContainer')]"));

        List<WebElement> QuestionMatchInteraction = ItemAnswerContainerMI.findElements(By.xpath("//table/tbody/tr"));

        Random random = new Random();

        for(WebElement rowQuestionChoice : QuestionMatchInteraction){
            System.out.println("Choice question is: " + rowQuestionChoice.getText());

            List<WebElement> inputChoice = rowQuestionChoice.findElements(By.tagName("input"));
            int totalInputs = inputChoice.size();
            System.out.println("Total inputs: " + totalInputs);

            if (totalInputs > 0) {
                int randomInputIndex = random.nextInt(totalInputs);
                WebElement randomInput = inputChoice.get(randomInputIndex);
                randomInput.click();
                System.out.println("Clicked on random input");
                Thread.sleep(500);
            }

        }

        Thread.sleep(2000);
        helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());

    }

    public void QuestionUploadInteraction() throws InterruptedException {
        TestRunner.startTest("Question: Upload Interaction");
        System.out.println("I'm in Upload Interaction");

        WebElement QuestionPlayer = driver.findElement(By.xpath("//div[contains(@class, 'QuestionPlayer')]"));

        //UI = Upload Interactions
        WebElement ItemQuestionContainerUI = QuestionPlayer.findElement(By.xpath("//div[contains(@class, 'questionTextContainer')]"));
        System.out.println("Question heading is: " + ItemQuestionContainerUI.getText());
        TestRunner.getTest().log(Status.INFO, "Question heading is: " + ItemQuestionContainerUI.getText());

        WebElement btnUploadDocument = QuestionPlayer.findElement(By.xpath("//div[contains(@class, 'uploadDocumentWrapper')]"));
//        btnUploadDocument.click();

        WebElement fileInput = QuestionPlayer.findElement(By.xpath("//input[@type='file']"));

        // Get the absolute path of the file
        String filePath = System.getProperty("user.dir") + "/src/test/resources/drivers/DummyImg.png";

        // Provide the absolute path to the file input
        fileInput.sendKeys(filePath);

//        fileInput.sendKeys("src/test/resources/drivers/DummyImg.png");

        TestRunner.getTest().log(Status.PASS, "Test Case Passed : Question attempted successfully and dummy file uploaded" );

        Thread.sleep(2000);
        helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());

    }

    public void AssignmentSubmitAsCompleted() throws InterruptedException{
        System.out.println("I'm in to submit the assignment");
        TestRunner.startTest("Submit Assignment");
        Thread.sleep(5000);

        WebElement headerBar = driver.findElement(By.xpath("//div[@id='ContentPlayerMainPanel']"));

        WebElement btnSubmitAsCompleted = headerBar.findElement(By.xpath("//button[normalize-space()='Submit as Completed']"));
        btnSubmitAsCompleted.click();
        System.out.println("Click on assignment Submit as Completed");
        TestRunner.getTest().log(Status.INFO, "Click on assignment Submit as Completed");

        wait.until(ExpectedConditions.invisibilityOf(progressBar));

        WebElement dialogIframe = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("lesson-player-ifram")));
        driver.switchTo().frame(dialogIframe);

        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@aria-labelledby='customized-dialog-title']")));

        WebElement promptSubmit = driver.findElement(By.xpath("//div[@aria-labelledby='customized-dialog-title']"));

        WebElement btnSubmit = promptSubmit.findElement(By.xpath("//button[@id='btn-save']"));
        btnSubmit.click();
        System.out.println("Assignment submitted successfully");
        TestRunner.getTest().log(Status.PASS, "Test Case Passed : Assignment submitted successfully");

        Thread.sleep(2000);

        driver.switchTo().defaultContent();

        reviewSubmissionOption();
        // Pressing the ESC key
        Actions actions = new Actions(driver);
        actions.sendKeys(Keys.ESCAPE).build().perform();

//        driver.switchTo().defaultContent();

        wait.until(ExpectedConditions.invisibilityOf(loader));

        By[] elementsToWaitFor = {
                By.xpath("//div[contains(@class,'navigation')]"),
                By.xpath("//div[contains(@class,'studentPortal-header')]"),
                By.xpath("//div[contains(@class,'AssignmentWrapper')]"),
                By.xpath("//div[contains(@class,'CoursesList')]")
        };
        try {
            for (By element : elementsToWaitFor) {
                wait.until(ExpectedConditions.visibilityOfElementLocated(element));
            }
            Thread.sleep(2000);
            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
        } catch (NoSuchElementException | ElementNotInteractableException e){
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            helper.takeScreenshot(driver , Thread.currentThread().getStackTrace()[1].getMethodName() );
            System.out.println("Exception is found    :   Dashboard is not shows");
            Assert.fail();
        }
    }

    public void reviewSubmissionOption() {
        System.out.println("I'm in to submit review to get score");

        try {
            WebElement dialogIframe = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("lesson-player-ifram")));
            driver.switchTo().frame(dialogIframe);

            WebElement reviewSubmissionDialog = driver.findElement(
                    By.xpath("//div[contains(@class, 'dialogContent-submittedContainer')]")
            );

            WebElement reviewSubmission = reviewSubmissionDialog.findElement(
                    By.xpath(".//div[@class='score-Container']")
            );
            if (reviewSubmission.isDisplayed()) {
                String scoreText = reviewSubmission.getText();
                System.out.println("The score container is displayed with the text: " + scoreText);
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: The submitted assignment score is: " + scoreText);
            } else {
                System.out.println("The score container is not displayed.");
                TestRunner.getTest().log(Status.WARNING, "Test Case Failed: The submitted assignment score is not displayed.");
            }

            try {
                WebElement reviewButton = reviewSubmissionDialog.findElement(
                        By.xpath(".//button[@id='btn-saveNext']")
                );
                if (reviewButton.isDisplayed()) {
                    reviewButton.click();
                    System.out.println("Clicked the 'Review' button.");
                    TestRunner.getTest().log(Status.PASS, "Clicked the 'Review' button successfully.");

                    driver.switchTo().defaultContent();

                    wait.until(ExpectedConditions.invisibilityOf(loader));

                    this.handleTeacherInstructionsDialog();

                    this.getGradingsSummary();
                } else {
                    System.out.println("'Review' button is not visible.");
                    TestRunner.getTest().log(Status.INFO, "'Review' button is not visible.");
                }
            } catch (NoSuchElementException e) {
                System.out.println("'Review' button not found.");
                TestRunner.getTest().log(Status.INFO, "'Review' button not found.");
            }

        } catch (NoSuchElementException | ElementNotInteractableException | InterruptedException e) {
            System.out.println("Review section or score not found: " + e.getMessage());
            TestRunner.getTest().log(Status.INFO, "Review section or score not found: " + e.getMessage());
        }
    }

    public void getGradingsSummary() throws InterruptedException {
        TestRunner.startTest("Grading Summary in Review Assignment After Submission");
        String contentTypeValue = "";
        try {
            WebElement controlPanel = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class,'ControlPanel')]")));

            String classAttribute = controlPanel.getAttribute("class");
            System.out.println("ControlPanel class attribute: " + classAttribute);

            Pattern pattern = Pattern.compile("contentType-\\d+");
            Matcher matcher = pattern.matcher(classAttribute);
            if (matcher.find()) {
                contentTypeValue = matcher.group();
                System.out.println("Extracted contentType: " + contentTypeValue);
                TestRunner.getTest().log(Status.INFO, "Extracted contentType: " + contentTypeValue);
            } else {
                System.out.println("contentType not found in class attribute");
                TestRunner.getTest().log(Status.WARNING, "contentType not found in class attribute");
            }

            WebElement questionPlayer = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("lesson-player-ifram")));
            driver.switchTo().frame(questionPlayer);

            if ("contentType-1".equals(contentTypeValue)) {
                WebElement totalScoreElement = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='pointWrapper']//span[1]")));
                String totalScoreText = totalScoreElement.getText().trim();
                System.out.println("Total Score from iframe (contentType-1): " + totalScoreText);
                setAssignmentScore(totalScoreText);
                TestRunner.getTest().log(Status.INFO, "Total Score: " + totalScoreText);

                driver.switchTo().defaultContent();
            } else {
                WebElement overviewWrapper = driver.findElement(By.className("OverviewScreenWrapper"));

                totalQuestions.set(getElementTextByType(overviewWrapper, "totalquestion"));
                String answered = getElementTextByType(overviewWrapper, "answered");
                String unanswered = getElementTextByType(overviewWrapper, "unanswered");
                String flagged = getElementTextByType(overviewWrapper, "flagged");
                String correct = getElementTextByType(overviewWrapper, "correct");
                String incorrect = getElementTextByType(overviewWrapper, "Incorrect");
                String partial = getElementTextByType(overviewWrapper, "partial");

                System.out.println("Review Summary:");
                System.out.println("Total Questions: " + totalQuestions.get());
                System.out.println("Answered: " + answered);
                System.out.println("Unanswered: " + unanswered);
                System.out.println("Flagged: " + flagged);
                System.out.println("Correct: " + correct);
                System.out.println("Incorrect: " + incorrect);
                System.out.println("Partial: " + partial);

                TestRunner.getTest().log(Status.INFO, "Total Questions: " + totalQuestions.get() +
                        ", Answered: " + answered + ", Unanswered: " + unanswered +
                        ", Flagged: " + flagged +
                        ", Correct: " + correct + ", Incorrect: " + incorrect +
                        ", Partial: " + partial);

                try {
                    String assignmentTotalScore = overviewWrapper.findElement(By.xpath(".//div[@class='score']")).getText();
                    assignmentTotalScore.replaceAll("%", "").trim();
                    System.out.println("Total Score: " + assignmentTotalScore);

                    setAssignmentScore(assignmentTotalScore);
                    TestRunner.getTest().log(Status.INFO, "Total Score: " + totalScore.get());
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed : Grading summary available");
                } catch (Exception e) {
                    System.out.println(e);
                    TestRunner.getTest().log(Status.INFO, "Grades not available");
                }
            }
        } catch (NoSuchElementException e) {
            if (!"contentType-1".equals(contentTypeValue)) {
                System.out.println("Error retrieving data: Element not found. " + e.getMessage());
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Review Button Not Available");
            }
        } finally {
            driver.switchTo().defaultContent();
        }

        Thread.sleep(2000);
        WebElement btn_CloseReview = driver.findElement(By.xpath("//button[@id='closeReview-btn']"));
        helper.scrollToElement(driver, btn_CloseReview);
        Thread.sleep(1000);
        System.out.println("Clicked on close review");
        btn_CloseReview.click();
        TestRunner.getTest().log(Status.PASS, "Test Case Passed : Close Review of Assignment");
    }

    public static void setAssignmentScore(String assignmentScore) {
        totalScore.set(assignmentScore);
    }

    private String getElementTextByType(WebElement parent, String type) {
        try {
            return parent.findElement(By.xpath(".//div[@type='" + type + "']")).getText();
        } catch (NoSuchElementException e) {
            System.out.println("Element not found for type: " + type);
            return "N/A";
        }
    }

    public String generateRandomText(String prefix) {
        String characters = "ABC123456789";
        StringBuilder randomText = new StringBuilder();
        Random random = new Random();
        int length = 6;
        randomText.append(prefix);
        for (int i = 0; i < length; i++) {
            randomText.append(characters.charAt(random.nextInt(characters.length())));
        }
        return randomText.toString();
    }


    private void highlightElement(WebElement element) {
        JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
        jsExecutor.executeScript("arguments[0].setAttribute('style', 'border: 2px solid red;');", element);
        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        jsExecutor.executeScript("arguments[0].setAttribute('style', '');", element);
    }

    public void handleTeacherInstructionsDialog() throws InterruptedException {
        System.out.println("I'm in Teacher Instructions Prompt");
        TestRunner.startTest("Teacher Instructions");
        Thread.sleep(1000);
        try {
            WebElement iframeQuestionPlayer = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("lesson-player-ifram")));
            driver.switchTo().frame(iframeQuestionPlayer);

            WebElement promptTeacherInstructions = null;
            try {
                promptTeacherInstructions = driver.findElement(By.xpath("//div[@aria-labelledby='customized-dialog-title']"));

                WebElement textTeacherInstructions = promptTeacherInstructions.findElement(By.xpath("//div[@class='instruction-text']"));
                System.out.println("Teacher instructions are: " + textTeacherInstructions.getText());

                TestRunner.getTest().log(Status.INFO, "Teacher instructions prompt shows and instructions are " + textTeacherInstructions.getText());

                WebElement btnReturnToAssignment = promptTeacherInstructions.findElement(By.xpath("//button[normalize-space()='Return to Assignment']"));
//                btnReturnToAssignment.click();
                Actions action = new Actions(driver);
                action.sendKeys(Keys.ESCAPE).perform();
                TestRunner.getTest().log(Status.PASS, "Test Case Passed : Teacher instructions read successfully");

            } catch (NoSuchElementException e) {
                System.out.println("Prompt not displayed");
                TestRunner.getTest().log(Status.INFO, "Prompt not displayed");
            }
        } catch (NoSuchElementException e) {
            System.out.println("Element not found in the prompt");
        } finally {
            driver.switchTo().defaultContent();
        }
    }

    private void simulateDrawingAction(JavascriptExecutor js, WebElement canvas) {
        // Simulate a simple drawing action using JavaScript
        String script = "var canvas = arguments[0];" +
                "var event = new MouseEvent('mousedown', { bubbles: true, cancelable: true });" +
                "canvas.dispatchEvent(event);" +
                "event = new MouseEvent('mousemove', { bubbles: true, cancelable: true });" +
                "canvas.dispatchEvent(event);" +
                "event = new MouseEvent('mouseup', { bubbles: true, cancelable: true });" +
                "canvas.dispatchEvent(event);";

        js.executeScript(script, canvas);
    }

}