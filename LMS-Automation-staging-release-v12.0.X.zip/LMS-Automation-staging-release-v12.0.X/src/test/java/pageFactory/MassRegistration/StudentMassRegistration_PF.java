package pageFactory.MassRegistration;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.sl.In;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.stream.Collectors;

public class StudentMassRegistration_PF {
    WebDriverWait wait;
    WebDriver driver;
    Helper helper;
    Actions actions;

    WebDriverWait quickWait;

    public StudentMassRegistration_PF(WebDriver driver) {
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        helper = new Helper();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        quickWait = new WebDriverWait(driver, Duration.ofSeconds(10));
        actions = new Actions(driver);
    }


    public void validateClickAddMultiple() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into Validate and Click on Add Multiple Button");

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(6));
        WebDriverWait quickWait = new WebDriverWait(driver, Duration.ofSeconds(4));

        try {
            // Locate the button and wait for it to be clickable
            WebElement addMultipleButton = wait.until(ExpectedConditions.elementToBeClickable(
                    By.xpath("//button[normalize-space()='+ Add Multiple']")
            ));

            // Check if the button is displayed and enabled
            if (addMultipleButton.isDisplayed() && addMultipleButton.isEnabled()) {
                System.out.println("Add Multiple button is visible and enabled. Clicking now...");
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: Add Multiple Button is Visible and Enabled.");
                addMultipleButton.click();
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: Add Multiple Button Clicked Successfully");
            } else {
                System.out.println("Add Multiple button is either not visible or not enabled.");
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Add Multiple button is either not visible or not enabled");
                Assert.fail("Add Multiple button is either not visible or not enabled");
            }

        } catch (TimeoutException e) {
            System.out.println("Add Multiple button not found within the wait time.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Add Multiple button not found within the wait time");
            Assert.fail("Add Multiple button not found within the wait time");
        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception while validating/clicking Add Multiple button: " + e.getMessage());
            Assert.fail("Error while validating/clicking Add Multiple button: " + e.getMessage());
        }

    }

    public void validateBreadCrumb() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into verify breadcrumb on Add Multiple Accounts");

        try {
            WebElement breadcrumbContainer = wait.until(ExpectedConditions.visibilityOfElementLocated(
                    By.xpath("//nav[contains(@class,'BreadcrumbsWrapper')]//ol[contains(@class,'MuiBreadcrumbs-ol')]")
            ));

            List<WebElement> breadcrumbItems = breadcrumbContainer.findElements(
                    By.xpath(".//li[not(@aria-hidden='true')]//a")
            );

            List<String> actualBreadcrumb = breadcrumbItems.stream()
                    .map(e -> e.getText().trim())
                    .collect(Collectors.toList());

            List<String> expectedBreadcrumb = List.of("Home", "Register", "User-Detail");

            // Case-insensitive comparison
            List<String> actualLower = actualBreadcrumb.stream()
                    .map(String::toLowerCase)
                    .collect(Collectors.toList());

            List<String> expectedLower = expectedBreadcrumb.stream()
                    .map(String::toLowerCase)
                    .collect(Collectors.toList());

            if (actualLower.equals(expectedLower)) {
                TestRunner.getTest().log(Status.PASS, "✅ Breadcrumb validation passed: " + actualBreadcrumb);
            } else {
                TestRunner.getTest().log(Status.FAIL,
                        "❌ Breadcrumb mismatch! Expected: " + expectedBreadcrumb + " | Actual: " + actualBreadcrumb);
                Assert.fail("Breadcrumb validation failed!");
            }

        } catch (TimeoutException e) {
            TestRunner.getTest().log(Status.FAIL, "❌ Breadcrumb not found within wait time.");
            Assert.fail("Breadcrumb element not found.");
        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "❌ Exception during breadcrumb validation: " + e.getMessage());
            Assert.fail("Error during breadcrumb validation.");
        }
    }

    public void validateAllButtonsDisable() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into validate that All Buttons are disable before we add Accounts");
        System.out.println("I'm into validate that All Buttons are disable before we add Accounts");


        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(8));
        WebDriverWait quickWait = new WebDriverWait(driver, Duration.ofSeconds(4));

        // List of button XPaths to check
        String[] buttonXPaths = {
                "//button[normalize-space()='+ Add Accounts']",
                "//button[normalize-space()='Generate']",
                "//button[normalize-space()='Apply']",
                "//button[normalize-space()='Clear All']",
                "//button[@id='btn-save-draft']"
        };

        for (String xpath : buttonXPaths) {
            try {
                WebElement button = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpath)));

                // Check if displayed
                if (!button.isDisplayed()) {
                    TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Button not displayed: " + xpath);
                    Assert.fail("Button not displayed: " + xpath);
                }

                // Check if disabled
                if (button.isEnabled()) {
                    TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Button is enabled (should be disabled): " + button.getText());
                    Assert.fail("Button is enabled: " + button.getText());
                }

                // If both checks pass
                TestRunner.getTest().log(Status.PASS, "✅ Test Case Passed: Button displayed and disabled: " + button.getText());
                System.out.println("✅ Test Case Passed: Button displayed and disabled: " + button.getText());

            } catch (TimeoutException e) {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Button not found in DOM: " + xpath);
                Assert.fail("Button not found in DOM: " + xpath);
            } catch (Exception e) {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Error validating button: " + xpath + " | " + e.getMessage());
                Assert.fail("Error validating button: " + xpath);
            }
        }
    }

    public void validateNoAccountsMessages() {
        TestRunner.getTest().log(Status.INFO, "I'm into verify Message is display before add any account");
        System.out.println("I'm into verify Message is display before add any account");


        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        try {
            WebElement messageContainer = wait.until(ExpectedConditions.visibilityOfElementLocated(
                    By.xpath("//td[contains(@class,'MuiTableCell-body')]")
            ));

            List<WebElement> messages = messageContainer.findElements(By.tagName("div"));

            String expectedMessage1 = "No accounts added yet";
            String actualMessage1 = messages.get(0).getText().trim();
            if (actualMessage1.equals(expectedMessage1)) {
                TestRunner.getTest().log(Status.PASS, "✅ Test Case Passed: First message displayed correctly: " + actualMessage1);
            } else {
                TestRunner.getTest().log(Status.FAIL, "❌ Test Case Failed: First message mismatch! Expected: '" + expectedMessage1 + "' | Actual: '" + actualMessage1 + "'");
                Assert.fail("First message mismatch!");
            }

            // Validate second message
            String expectedMessage2 = "Select your Criteria above and click Add Account to get started";
            String actualMessage2 = messages.get(1).getText().trim();
            if (actualMessage2.equals(expectedMessage2)) {
                TestRunner.getTest().log(Status.PASS, "✅ Test Case Passed: Second message displayed correctly: " + actualMessage2);
            } else {
                TestRunner.getTest().log(Status.FAIL, "❌ Test Case Failed: Second message mismatch! Expected: '" + expectedMessage2 + "' | Actual: '" + actualMessage2 + "'");
                Assert.fail("Second message mismatch!");
            }

        } catch (TimeoutException e) {
            TestRunner.getTest().log(Status.FAIL, "❌ Test Case Failed: Messages not found before adding accounts.");
            Assert.fail("Messages not found in DOM!");
        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "❌ Test Case Failed: Exception while validating messages: " + e.getMessage());
            Assert.fail("Error validating messages!");
        }
    }

    public void selectDistrictFromDropDown() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into select District From DropDown");

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        try {
            // 1️⃣ Click the dropdown icon to open the options list
            WebElement dropdownButton = wait.until(ExpectedConditions.elementToBeClickable(
                    By.xpath("//label[contains(text(),'District')]/following::button[@aria-label='Open'][1]")
            ));
            dropdownButton.click();

            // 2️⃣ Wait for dropdown options to be visible (MUI typically uses <ul role='listbox'>)
            // Wait for the listbox to appear first, then find options within it
            WebElement listbox = quickWait.until(ExpectedConditions.visibilityOfElementLocated(
                    By.xpath("//ul[@role='listbox']")
            ));

            List<WebElement> options = listbox.findElements(
                    By.xpath(".//li[not(contains(@class,'Mui-disabled'))]")
            );

            if (options.isEmpty()) {
                TestRunner.getTest().log(Status.FAIL, "❌ Test Case Failed: No districts available in the dropdown.");
                Assert.fail("No districts available to select.");
            }

            // 3️⃣ Select a random option
            Random random = new Random();
            WebElement randomOption = options.get(random.nextInt(options.size()));
            String selectedDistrict = randomOption.getText().trim();

            // 4️⃣ Click the random option
            randomOption.click();

            // 5️⃣ Log success
            TestRunner.getTest().log(Status.PASS, "✅ Test Case Passed: Random district selected: " + selectedDistrict);
            System.out.println("✅ Test Case Passed: Random district selected: " + selectedDistrict);

        } catch (TimeoutException e) {
            TestRunner.getTest().log(Status.FAIL, "❌ Test Case Failed: District dropdown or options not found within timeout.");
            Assert.fail("District dropdown not found.");
        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "❌ Test Case Failed: Exception while selecting random district: " + e.getMessage());
            Assert.fail("Error while selecting random district.");
        }
    }

    public void selectSchoolFromDropdown() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into Select School From Dropdown");
        System.out.println("I'm into Select School From Dropdown");

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(8));
        WebDriverWait quickWait = new WebDriverWait(driver, Duration.ofSeconds(4));

        try {
            // 1️⃣ Click the dropdown icon to open the options list
            WebElement dropdownButton = wait.until(ExpectedConditions.elementToBeClickable(
                    By.xpath("//label[contains(text(),'School')]/following::button[@aria-label='Open'][1]")
            ));
            dropdownButton.click();

            // 2️⃣ Wait for dropdown options to be visible (MUI typically uses <ul role='listbox'>)
            // Wait for the listbox to appear first, then find options within it
            WebElement listbox = quickWait.until(ExpectedConditions.visibilityOfElementLocated(
                    By.xpath("//ul[@role='listbox']")
            ));

            List<WebElement> options = listbox.findElements(
                    By.xpath(".//li[not(contains(@class,'Mui-disabled'))]")
            );

            if (options.isEmpty()) {
                TestRunner.getTest().log(Status.FAIL, "❌ Test Case Failed: No School available in the dropdown.");
                Assert.fail("No School available to select.");
            }

            // 3️⃣ Select a random option
            Random random = new Random();
            WebElement randomOption = options.get(random.nextInt(options.size()));
            String selectedSchool = randomOption.getText().trim();

            // 4️⃣ Click the random option
            randomOption.click();

            // 5️⃣ Log success
            TestRunner.getTest().log(Status.PASS, "✅ Test Case Passed: Random School selected: " + selectedSchool);
            System.out.println("✅ Test Case Passed: Random School selected: " + selectedSchool);

        } catch (TimeoutException e) {
            TestRunner.getTest().log(Status.FAIL, "❌ Test Case Failed: School dropdown or options not found within timeout.");
            Assert.fail("School dropdown not found.");
        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "❌ Test Case Failed: Exception while selecting random School: " + e.getMessage());
            Assert.fail("Error while selecting random School.");
        }
    }

    public void validateNumberOfAccountsAndAdd() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Validating default number of accounts and adding accounts");

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        try {
            WebElement numberInput = wait.until(ExpectedConditions.visibilityOfElementLocated(
                    By.xpath("//label[normalize-space()='# Number of Accounts']/following::input[@type='number'][1]")
            ));

            String initialValue = numberInput.getAttribute("value").trim();
            if (!"0".equals(initialValue)) {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Default number of accounts is not 0. Found: " + initialValue);
                Assert.fail("Default number of accounts is not 0. Found: " + initialValue);
            }

            numberInput.click();
            numberInput.sendKeys(Keys.ARROW_UP);

            String updatedValue = numberInput.getAttribute("value").trim();
            if (!"1".equals(updatedValue)) {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Unable to set number of accounts to 1. Found: " + updatedValue);
                Assert.fail("Unable to set number of accounts to 1. Found: " + updatedValue);
            }

            WebElement addAccountsButton = wait.until(ExpectedConditions.elementToBeClickable(
                    By.xpath("//button[normalize-space()='+ Add Accounts']")
            ));
            addAccountsButton.click();

            TestRunner.getTest().log(Status.PASS, "✅ Test Case Passed: Number of accounts set to 1 and + Add Accounts clicked.");
            System.out.println("✅ Test Case Passed: Number of accounts set to 1 and + Add Accounts clicked.");

        } catch (TimeoutException e) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Number of Accounts input or Add Accounts button not found within timeout.");
            Assert.fail("Number of Accounts input or Add Accounts button not found within timeout.");
        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception while validating/setting number of accounts: " + e.getMessage());
            Assert.fail("Exception while validating/setting number of accounts: " + e.getMessage());
        }
    }

    public void validateRoleDropdownStudentPreselected() {
        TestRunner.getTest().log(Status.INFO, "Validating Role dropdown options and preselected value");

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        try {
            // Locate the Role cell container (first row, first column)
            WebElement roleCellContainer = wait.until(ExpectedConditions.visibilityOfElementLocated(
                    By.xpath("//table[contains(@class,'MuiTable-root')]//tbody//tr[1]//td[1]//div[contains(@class,'MuiInputBase-root')]")
            ));

            // Scroll into view to ensure interactability
            ((org.openqa.selenium.JavascriptExecutor) driver)
                    .executeScript("arguments[0].scrollIntoView({block:'center'});", roleCellContainer);

            // Read preselected value from the combobox text node
            WebElement roleCombobox = roleCellContainer.findElement(By.xpath(".//div[@role='combobox']"));

            String preselectedText = roleCombobox.getText().trim();
            if (!"Student".equalsIgnoreCase(preselectedText)) {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Role preselected is not 'Student'. Found: " + preselectedText);
                Assert.fail("Role preselected is not 'Student'. Found: " + preselectedText);
            }

            // Try to open the dropdown robustly
            try {
                wait.until(ExpectedConditions.elementToBeClickable(roleCombobox)).click();
            } catch (Exception clickEx) {
                try {
                    // Fallback to clicking the dropdown icon
                    WebElement dropdownIcon = roleCellContainer.findElement(By.xpath(".//svg[contains(@class,'MuiSelect-icon')]"));
                    wait.until(ExpectedConditions.elementToBeClickable(dropdownIcon));
                    new Actions(driver).moveToElement(dropdownIcon).click().perform();
                } catch (Exception iconEx) {
                    // Final fallback to JS click
                    ((org.openqa.selenium.JavascriptExecutor) driver)
                            .executeScript("arguments[0].click();", roleCombobox);
                }
            }

            WebElement listbox = quickWait.until(ExpectedConditions.visibilityOfElementLocated(
                    By.xpath("//ul[@role='listbox']")
            ));
            List<WebElement> options = listbox.findElements(By.xpath(".//li[not(contains(@class,'Mui-disabled'))]"));

            if (options.isEmpty()) {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Role dropdown has no options.");
                Assert.fail("Role dropdown has no options.");
            }

            boolean containsStudent = options.stream().anyMatch(o -> "Student".equalsIgnoreCase(o.getText().trim()));
            if (!containsStudent) {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Role dropdown options do not include 'Student'.");
                Assert.fail("Role dropdown options do not include 'Student'.");
            }

            try {
                new Actions(driver).sendKeys(Keys.ESCAPE).perform();
                wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//ul[@role='listbox']")));
            } catch (Exception closeEx) {
                // Ignore if already closed
            }

            TestRunner.getTest().log(Status.PASS, "✅ Test Case Passed: Role dropdown preselected 'Student' and options loaded.");
            System.out.println("✅ Test Case Passed: Role dropdown preselected 'Student' and options loaded.");

        } catch (TimeoutException e) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Role dropdown not found within timeout.");
            Assert.fail("Role dropdown not found within timeout.");
        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception while validating Role dropdown: " + e.getMessage());
            Assert.fail("Exception while validating Role dropdown: " + e.getMessage());
        }
    }


    public void validateRowSchoolDropdownPreselectedAndOptions() {
        TestRunner.getTest().log(Status.INFO, "Validating row School dropdown preselected value and options");

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        try {
            // Locate the School cell container (first row, second column)
            WebElement schoolCellContainer = wait.until(ExpectedConditions.visibilityOfElementLocated(
                    By.xpath("//table[contains(@class,'MuiTable-root')]//tbody//tr[1]//td[2]//div[contains(@class,'MuiInputBase-root')]")
            ));

            // Scroll into view to ensure interactability
            ((org.openqa.selenium.JavascriptExecutor) driver)
                    .executeScript("arguments[0].scrollIntoView({block:'center'});", schoolCellContainer);

            // Read preselected school from the row combobox
            WebElement schoolCombobox = schoolCellContainer.findElement(By.xpath(".//div[@role='combobox']"));
            String rowPreselectedSchool = schoolCombobox.getText().trim();
            if (rowPreselectedSchool.isEmpty()) {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Row School combobox has empty preselected value.");
                Assert.fail("Row School combobox has empty preselected value.");
            }

            // Determine selected values for comparison (prefer underlying value/id, fallback to text)
            String rowSchoolValue = "";
            try {
                WebElement hiddenInput = schoolCellContainer.findElement(By.xpath(".//input[contains(@class,'MuiSelect-nativeInput')]"));
                rowSchoolValue = hiddenInput.getAttribute("value");
            } catch (Exception ignored) { }

            WebElement topSchoolContainer = wait.until(ExpectedConditions.visibilityOfElementLocated(
                    By.xpath("//label[contains(.,'School')]/following::div[contains(@class,'MuiInputBase-root')][1]")
            ));
            String topSchoolText = "";
            if (topSchoolContainer != null) {
                try {
                    WebElement topCombobox = topSchoolContainer.findElement(By.xpath(".//div[@role='combobox' or @role='button']"));
                    topSchoolText = topCombobox.getText().trim();
                } catch (Exception ignored) { }
            }

            String topSchoolValue = "";
            try {
                WebElement topHiddenInput = topSchoolContainer.findElement(By.xpath(".//input[contains(@class,'MuiSelect-nativeInput')]"));
                topSchoolValue = topHiddenInput.getAttribute("value");
            } catch (Exception ignored) { }

            boolean compared = false;
            if (rowSchoolValue != null && !rowSchoolValue.isEmpty() && topSchoolValue != null && !topSchoolValue.isEmpty()) {
                compared = true;
                if (!rowSchoolValue.equals(topSchoolValue)) {
                    TestRunner.getTest().log(Status.FAIL,
                            String.format("Test Case Failed: Row School ID '%s' does not match selected School ID '%s'. (Row text: %s, Top text: %s)",
                                    rowSchoolValue, topSchoolValue, rowPreselectedSchool, topSchoolText));
                    Assert.fail("Row School does not match selected School.");
                }
            }

            if (!compared && !topSchoolText.isEmpty() && !rowPreselectedSchool.equalsIgnoreCase(topSchoolText)) {
                TestRunner.getTest().log(Status.FAIL,
                        String.format("Test Case Failed: Row School '%s' does not match selected School '%s'.", rowPreselectedSchool, topSchoolText));
                Assert.fail("Row School does not match selected School.");
            }

            // Open dropdown robustly to validate options
            try {
                wait.until(ExpectedConditions.elementToBeClickable(schoolCombobox)).click();
            } catch (Exception clickEx) {
                try {
                    WebElement dropdownIcon = schoolCellContainer.findElement(By.xpath(".//svg[contains(@class,'MuiSelect-icon')]"));
                    wait.until(ExpectedConditions.elementToBeClickable(dropdownIcon));
                    new Actions(driver).moveToElement(dropdownIcon).click().perform();
                } catch (Exception iconEx) {
                    ((org.openqa.selenium.JavascriptExecutor) driver).executeScript("arguments[0].click();", schoolCombobox);
                }
            }

            WebElement listbox = quickWait.until(ExpectedConditions.visibilityOfElementLocated(
                    By.xpath("//ul[@role='listbox']")
            ));
            List<WebElement> options = listbox.findElements(By.xpath(".//li[not(contains(@class,'Mui-disabled'))]"));
            if (options.isEmpty()) {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: School dropdown in row has no options.");
                Assert.fail("School dropdown in row has no options.");
            }

            // Ensure the currently selected school exists in the options (as with Role contains check)
            String schoolToValidate = !topSchoolText.isEmpty() ? topSchoolText : rowPreselectedSchool;
            boolean containsTopSchool = options.stream().anyMatch(o -> o.getText() != null && o.getText().trim().equalsIgnoreCase(schoolToValidate));
            if (!schoolToValidate.isEmpty() && !containsTopSchool) {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: School dropdown options do not include '" + schoolToValidate + "'.");
                Assert.fail("School dropdown options do not include the selected School.");
            }

            // Close dropdown via ESC and wait to disappear
            try {
                new Actions(driver).sendKeys(Keys.ESCAPE).perform();
                wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//ul[@role='listbox']")));
            } catch (Exception ignore) { }

            TestRunner.getTest().log(Status.PASS, "✅ Test Case Passed: Row School dropdown preselected and options loaded.");
            System.out.println("✅ Test Case Passed: Row School dropdown preselected and options loaded.");

        } catch (TimeoutException e) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Row School dropdown not found within timeout.");
            Assert.fail("Row School dropdown not found within timeout.");
        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception while validating row School dropdown: " + e.getMessage());
            Assert.fail("Exception while validating row School dropdown: " + e.getMessage());
        }
    }

    public void validateFirstNameFieldRequiredMessage() {
        TestRunner.getTest().log(Status.INFO, "Validating First Name required message in row");

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        try {
            // Locate the First Name input (first row, third column)
            WebElement firstNameContainer = wait.until(ExpectedConditions.visibilityOfElementLocated(
                    By.xpath("//table[contains(@class,'MuiTable-root')]//tbody//tr[1]//td[3]//div[contains(@class,'MuiTextField-root')]")
            ));

            ((org.openqa.selenium.JavascriptExecutor) driver)
                    .executeScript("arguments[0].scrollIntoView({block:'center'});", firstNameContainer);

            WebElement firstNameInput = firstNameContainer.findElement(By.xpath(".//input[@type='text']"));

            wait.until(ExpectedConditions.elementToBeClickable(firstNameContainer)).click();

            WebElement continueButton = wait.until(ExpectedConditions.elementToBeClickable(
                    By.xpath("//button[@id='btn-continue']")
            ));
            continueButton.click();

            WebElement errorMessage = wait.until(ExpectedConditions.visibilityOfElementLocated(
                    By.xpath("//table[contains(@class,'MuiTable-root')]//tbody//tr[1]//td[3]//p[contains(@class,'MuiFormHelperText-root')]")
            ));

            String errorText = errorMessage.getText().trim();
            if (!"First name is required".equalsIgnoreCase(errorText)) {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: First Name required message mismatch. Found: " + errorText);
                Assert.fail("First Name required message mismatch.");
            }
            continueButton.click();

//            validateValidationFailedSnackbarMessage();

            TestRunner.getTest().log(Status.PASS, "✅ Test Case Passed: First Name required validation displayed.");
            System.out.println("✅ Test Case Passed: First Name required validation displayed.");

        } catch (TimeoutException e) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: First Name input or validation message not found within timeout.");
            Assert.fail("First Name input or validation message not found within timeout.");
        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception while validating First Name required message: " + e.getMessage());
            Assert.fail("Exception while validating First Name required message: " + e.getMessage());
        }
    }

//    public void validateValidationFailedSnackbarMessage() {
//        TestRunner.getTest().log(Status.INFO, "Validating 'Validation Failed' snackbar message");
//
//        try {
//            WebElement snackbarContainer = wait.until(ExpectedConditions.visibilityOfElementLocated(
//                    By.xpath("//div[contains(@class,'MuiSnackbar-root')]")
//            ));
//
//            WebElement snackbarTitle = snackbarContainer.findElement(
//                    By.xpath(".//p[contains(@class,'MuiTypography-body1') and normalize-space()='Validation Failed']")
//            );
//
//            WebElement snackbarDescription = snackbarContainer.findElement(
//                    By.xpath(".//p[contains(@class,'MuiTypography-body1') and contains(normalize-space(),'required fields')]")
//            );
//
//            String descriptionText = snackbarDescription.getText().trim();
//            if (!"Some required fields are missing or invalid.".equals(descriptionText)) {
//                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Snackbar message mismatch. Found: " + descriptionText);
//                Assert.fail("Snackbar message mismatch.");
//            }
//
//            TestRunner.getTest().log(Status.PASS, "✅ Test Case Passed: Snackbar message displayed as expected.");
//            System.out.println("✅ Test Case Passed: Snackbar message displayed as expected.");
//
//        } catch (TimeoutException e) {
//            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Validation snackbar not displayed within timeout.");
//            Assert.fail("Validation snackbar not displayed within timeout.");
//        } catch (Exception e) {
//            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception while validating snackbar message: " + e.getMessage());
//            Assert.fail("Exception while validating snackbar message: " + e.getMessage());
//        }
//    }

    public void validateValidationFailedSnackbarMessage() {
        wait.pollingEvery(Duration.ofMillis(5));

        try {
            // Very stable parent locator
            WebElement toastContainer = wait.until(
                    ExpectedConditions.visibilityOfElementLocated(
                            By.xpath("//div[@role='presentation']")
                    )
            );

            try {
                if (toastContainer.isDisplayed()) {

                    toastContainer = driver.findElement(By.xpath("//div[@role='presentation']"));

                    // Inner container that holds text and close button
                    WebElement bgElement = toastContainer.findElement(
                            By.xpath(".//div[./p]")
                    );

                    String actualBackgroundColor = bgElement.getCssValue("background-color");

                    String expectedBackgroundColor = "rgb(96, 187, 113)";
                    String expectedBackgroundColorWithAlpha = "rgba(96, 187, 113, 1)";

                    System.out.println("Captured Background Color: " + actualBackgroundColor);

                    // SUCCESS TOAST (same logic)
                    if (actualBackgroundColor.equals(expectedBackgroundColor)
                            || actualBackgroundColor.equals(expectedBackgroundColorWithAlpha)) {

                        // First <p> = Title
                        String messageTitle = toastContainer.findElement(By.xpath(".//p[1]")).getText();
                        String messageText  = toastContainer.findElement(By.xpath(".//p[2]")).getText();

                        System.out.println("Message Title: " + messageTitle);
                        System.out.println("Message Text: " + messageText);

                        TestRunner.getTest().log(Status.INFO, "Success toast title: " + messageTitle);
                        TestRunner.getTest().log(Status.INFO, "Success toast message: " + messageText);
                        TestRunner.getTest().log(Status.PASS, "Success toast displayed correctly.");
                    }
                    // ERROR TOAST
                    else {
                        String errorTitle = toastContainer.findElement(By.xpath(".//p[1]")).getText();
                        String errorText  = toastContainer.findElement(By.xpath(".//p[2]")).getText();

                        System.out.println("Error Title: " + errorTitle);
                        System.out.println("Error Text: " + errorText);

                        TestRunner.getTest().log(Status.FAIL,
                                "Error toast displayed. Background: " + actualBackgroundColor);

                        TestRunner.getTest().log(Status.INFO, "Error toast title: " + errorTitle);
                        TestRunner.getTest().log(Status.INFO, "Error toast message: " + errorText);
                    }

                } else {
                    TestRunner.getTest().log(Status.FAIL, "Toast popup not displayed.");
                }

            } catch (StaleElementReferenceException staleEx) {

                TestRunner.getTest().log(Status.WARNING, "Toast became stale. Retrying...");

                toastContainer = wait.until(
                        ExpectedConditions.visibilityOfElementLocated(
                                By.xpath("//div[@role='presentation']")
                        )
                );

                WebElement bgElement = toastContainer.findElement(By.xpath(".//div[./p]"));
                String retryColor = bgElement.getCssValue("background-color");

                System.out.println("Retried Background Color: " + retryColor);
                TestRunner.getTest().log(Status.INFO,
                        "Retried and captured background color: " + retryColor);

            }

        } catch (TimeoutException e) {
            TestRunner.getTest().log(Status.FAIL, "Toast did not appear in time.");
        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL,
                    "Unexpected error while validating toast: " + e.getMessage());
        }
    }


    public void validateLastNameFieldRequiredMessage() {
        TestRunner.getTest().log(Status.INFO, "Validating Last Name required message in row");

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        try {
            WebElement lastNameContainer = wait.until(ExpectedConditions.visibilityOfElementLocated(
                    By.xpath("//table[contains(@class,'MuiTable-root')]//tbody//tr[1]//td[4]//div[contains(@class,'MuiTextField-root')]")
            ));

            ((org.openqa.selenium.JavascriptExecutor) driver)
                    .executeScript("arguments[0].scrollIntoView({block:'center'});", lastNameContainer);

            wait.until(ExpectedConditions.elementToBeClickable(lastNameContainer)).click();

            WebElement continueButton = wait.until(ExpectedConditions.elementToBeClickable(
                    By.xpath("//button[@id='btn-continue']")
            ));
            continueButton.click();

            WebElement errorMessage = wait.until(ExpectedConditions.visibilityOfElementLocated(
                    By.xpath("//table[contains(@class,'MuiTable-root')]//tbody//tr[1]//td[4]//p[contains(@class,'MuiFormHelperText-root')]")
            ));

            String errorText = errorMessage.getText().trim();
            if (!"Last name is required".equalsIgnoreCase(errorText)) {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Last Name required message mismatch. Found: " + errorText);
                Assert.fail("Last Name required message mismatch.");
            }

            continueButton.click();

//            validateValidationFailedSnackbarMessage();

            TestRunner.getTest().log(Status.PASS, "✅ Test Case Passed: Last Name required validation displayed.");
            System.out.println("✅ Test Case Passed: Last Name required validation displayed.");

        } catch (TimeoutException e) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Last Name input or validation message not found within timeout.");
            Assert.fail("Last Name input or validation message not found within timeout.");
        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception while validating Last Name required message: " + e.getMessage());
            Assert.fail("Exception while validating Last Name required message: " + e.getMessage());
        }
    }

    public void validateEmailFieldRequiredMessage(){

        TestRunner.getTest().log(Status.INFO, "Validating Email is required message in row");

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        try {
            WebElement lastNameContainer = wait.until(ExpectedConditions.visibilityOfElementLocated(
                    By.xpath("//table[contains(@class,'MuiTable-root')]//tbody//tr[1]//td[5]//div[contains(@class,'MuiTextField-root')]")
            ));

            ((org.openqa.selenium.JavascriptExecutor) driver)
                    .executeScript("arguments[0].scrollIntoView({block:'center'});", lastNameContainer);

            wait.until(ExpectedConditions.elementToBeClickable(lastNameContainer)).click();

            WebElement continueButton = wait.until(ExpectedConditions.elementToBeClickable(
                    By.xpath("//button[@id='btn-continue']")
            ));
            continueButton.click();

            WebElement errorMessage = wait.until(ExpectedConditions.visibilityOfElementLocated(
                    By.xpath("//table[contains(@class,'MuiTable-root')]//tbody//tr[1]//td[5]//p[contains(@class,'MuiFormHelperText-root')]")
            ));

            String errorText = errorMessage.getText().trim();
            if (!"Email is required".equalsIgnoreCase(errorText)) {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Email is required message mismatch. Found: " + errorText);
                Assert.fail("Email is required message mismatch.");
            }

            continueButton.click();

//            validateValidationFailedSnackbarMessage();

            TestRunner.getTest().log(Status.PASS, "✅ Test Case Passed: Email is required validation displayed.");
            System.out.println("✅ Test Case Passed: Email is required validation displayed.");

        } catch (TimeoutException e) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Email input or validation message not found within timeout.");
            Assert.fail("Email input or validation message not found within timeout");
        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception while validating Email is required message: " + e.getMessage());
            Assert.fail("Exception while validating Email is required message: " + e.getMessage());
        }
    }

    public void validateRefreshPage() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into Refresh Page");
        System.out.println("I'm into Refresh Page");

        driver.navigate().refresh();

    }

    public void addAccountsInformation() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into add Accounts Information For Multiple Users");

        addFirstName();

    }
    public static Map<String, String> studentData = new HashMap<>();


    public void addFirstName() {

        // 1. Generate random first name at runtime
        String randomFirstName = generateRandomName();

// 2. Locate the First Name input (first row → first column)
        WebElement firstNameInput = driver.findElement(
                By.xpath("//tr[1]//td[1]//input[@type='text']")
        );

// 3. Enter the random name
        firstNameInput.clear();
        firstNameInput.sendKeys(randomFirstName);

// 4. Store in map for future use
        studentData.put("firstName", randomFirstName);
        TestRunner.getTest().log(Status.INFO, "Enter First Name: " + randomFirstName);

        System.out.println("Generated First Name: " + randomFirstName);
        TestRunner.getTest().log(Status.INFO, "Generated First Name: " + randomFirstName);

    }

    public static String generateRandomName() {
        String alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
        StringBuilder name = new StringBuilder();
        Random r = new Random();

        int length = 6 + r.nextInt(5); // length between 6–10 characters

        for (int i = 0; i < length; i++) {
            name.append(alphabet.charAt(r.nextInt(alphabet.length())));
        }
        return name.toString();
    }

}

