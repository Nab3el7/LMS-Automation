package pageFactory;

import StepDefinitions.AssignmentOverviewSteps;
import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import apiHandler.GetAPIHandler;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.*;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Assignmment.CorrectAnswerExecutor_PF;
import pageFactory.Assignmment.StudentExecutor_PF;
import pageFactory.MyContent.AssignAssessment_PF;

import java.awt.*;
import java.time.Duration;
import java.util.*;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;


public class AssignmentOverview_PF {

    Helper helper;
    GetAPIHandler getAPIHandler;
    StudentExecutor_PF studentExecutor;
    CorrectAnswerExecutor_PF correctAnswerExecutor_pf;
    AssignAssessment_PF assignAssessment;
    public WebDriverWait wait;
    WebDriver driver;
//    public static String AssignmentNameForCorrect = Configurations.getDotEnv().get("SITE_ASSIGNMENT_NAME_FOR_CORRECT_ANSWER");
    String questionID = null;


    @FindBy(xpath = "//div[@aria-labelledby='simple-tab-2']")
    WebElement panel_Assignments;

    @FindBy(xpath = "//nav[@aria-label='pagination navigation']")
    WebElement nav_Pagination;

    @FindBy(xpath = "//button[@aria-label='Go to next page']")
    WebElement btn_NavNextPage;



    public AssignmentOverview_PF(WebDriver driver) {
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        helper = new Helper();
        getAPIHandler = new GetAPIHandler();
        studentExecutor = new StudentExecutor_PF(driver);
        correctAnswerExecutor_pf = new CorrectAnswerExecutor_PF(driver);
        assignAssessment = new AssignAssessment_PF(driver);
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
    }

    public void ReleaseAssignmentTypeETForOverview() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Release Assignment Type Expert Track For Overview");
        System.out.println("Release Assignment Type ET for Overview");
        Thread.sleep(2000);
        List<WebElement> totalUnits = driver.findElements(By.xpath("(//div[contains(@class, 'navigation')])[2]//a"));

        String totalUnitName = null;
        for (WebElement unit : totalUnits) {
            totalUnitName = unit.getText();
            System.out.println("Unit Name: " + totalUnitName);

            if (totalUnitName.contains("Unit 1")) {
                unit.click();
                break;
            }
        }
        TestRunner.getTest().log(Status.PASS,"Test Case passed : " + totalUnitName + " Select Successfully");

        Thread.sleep(2000);
        WebElement listContentPlayer = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@id='ContentPlayerMainPanel']")));

        if (listContentPlayer.isDisplayed() && listContentPlayer.isEnabled()) {
            WebElement btnAssignForSpecificAssignment = listContentPlayer.findElement(By.xpath("(//div[contains(@class, 'MuiBox-root')]//button[contains(text(), 'Assign')])[5]"));
            btnAssignForSpecificAssignment.click();

            WebElement dialogAssignment = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@role='dialog']")));
            if (dialogAssignment.isDisplayed()) {
                correctAnswerExecutor_pf.EnterAssignmentTitleForCorrectAnswers();
                correctAnswerExecutor_pf.selectSpecificClasses();
                assignAssessment.setDateTimeAndCategory();
                assignAssessment.enterAdditionalSettings();
                assignAssessment.enterWeightPercentage();
                assignAssessment.assignAssignment();
                assignAssessment.verifyDialogBox();
                TestRunner.getTest().log(Status.PASS, "Test Case Passed : Specific Assignment Type ET Released Successfully");
            }
        }
    }

    public void ReleaseAssignmentTypeVBForOverview() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Release Assignment Type Vocabulary Builder For Overview");
        System.out.println("Release Assignment Type VB for Overview");
        Thread.sleep(2000);
        List<WebElement> totalUnits = driver.findElements(By.xpath("(//div[contains(@class, 'navigation')])[2]//a"));

        String totalUnitName = null;
        for (WebElement unit : totalUnits) {
            totalUnitName = unit.getText();
            System.out.println("Unit Name: " + totalUnitName);

            if (totalUnitName.contains("Unit 1")) {
                unit.click();
                break;
            }
        }
        TestRunner.getTest().log(Status.PASS,"Test Case passed : " + totalUnitName + " Select Successfully");

        Thread.sleep(2000);
        WebElement listContentPlayer = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@id='ContentPlayerMainPanel']")));

        if (listContentPlayer.isDisplayed() && listContentPlayer.isEnabled()) {
            WebElement btnAssignForSpecificAssignment = listContentPlayer.findElement(By.xpath("(//div[contains(@class, 'MuiBox-root')]//button[contains(text(), 'Assign')])[3]"));
            btnAssignForSpecificAssignment.click();

            WebElement dialogAssignment = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@role='dialog']")));
            if (dialogAssignment.isDisplayed()) {
                correctAnswerExecutor_pf.EnterAssignmentTitleForCorrectAnswers();
                correctAnswerExecutor_pf.selectSpecificClasses();
                assignAssessment.setDateTimeAndCategory();
                assignAssessment.enterAdditionalSettings();
                assignAssessment.enterWeightPercentage();
                assignAssessment.assignAssignment();
                assignAssessment.verifyDialogBox();
                TestRunner.getTest().log(Status.PASS, "Test Case Passed : Specific Assignment Type VB Released Successfully");
            }
        }
    }

    public void ReleaseAssignmentTypeVQForOverview() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO,"Release Assignment Type VQ For Overview");
        System.out.println("Release Assignment Type VQ for Overview");
        Thread.sleep(2000);
        List<WebElement> totalUnits = driver.findElements(By.xpath("(//div[contains(@class, 'navigation')])[2]//a"));

        String totalUnitName = null;
        for (WebElement unit : totalUnits) {
            totalUnitName = unit.getText();
            System.out.println("Unit Name: " + totalUnitName);

            if (totalUnitName.contains("Unit 1")) {
                unit.click();
                break;
            }
        }
        TestRunner.getTest().log(Status.PASS, "Test Case passed : " + totalUnitName + " Select Successfully");

        Thread.sleep(2000);
        WebElement listContentPlayer = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@id='ContentPlayerMainPanel']")));

        if (listContentPlayer.isDisplayed() && listContentPlayer.isEnabled()) {
            WebElement btnAssignForSpecificAssignment = listContentPlayer.findElement(By.xpath("(//div[contains(@class, 'MuiBox-root')]//button[contains(text(), 'Assign')])[4]"));
            btnAssignForSpecificAssignment.click();

            WebElement dialogAssignment = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@role='dialog']")));
            if (dialogAssignment.isDisplayed()) {
                correctAnswerExecutor_pf.EnterAssignmentTitleForCorrectAnswers();
                correctAnswerExecutor_pf.selectSpecificClasses();
                assignAssessment.setDateTimeAndCategory();
                assignAssessment.enterAdditionalSettings();
                assignAssessment.enterWeightPercentage();
                assignAssessment.assignAssignment();
                assignAssessment.verifyDialogBox();
                TestRunner.getTest().log(Status.PASS, "Test Case Passed : Specific Assignment Type VQ Released Successfully");
            }
        }
    }

    public void ReleaseAssignmentTypeDSBForOverview() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO,"Release Assignment Type DSB For Overview");
        System.out.println("Release Assignment Type DSB for Overview");
        Thread.sleep(2000);
        List<WebElement> totalUnits = driver.findElements(By.xpath("(//div[contains(@class, 'navigation')])[2]//a"));

        String totalUnitName = null;
        for (WebElement unit : totalUnits) {
            totalUnitName = unit.getText();
            System.out.println("Unit Name: " + totalUnitName);

            if (totalUnitName.contains("Unit 1")) {
                unit.click();
                WebElement listContentPlayer = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@id='ContentPlayerMainPanel']")));
                if (listContentPlayer.isDisplayed() && listContentPlayer.isEnabled()) {
                    WebElement btnOpenForSpecificAssignment = listContentPlayer.findElement(By.xpath("(//div[contains(@class, 'MuiBox-root')]//button[contains(text(), 'Open')])[7]"));
                    btnOpenForSpecificAssignment.click();
                }
                break;
            }
        }
        TestRunner.getTest().log(Status.PASS, "Test Case passed : " + totalUnitName + " Select Successfully");

        Thread.sleep(2000);
        WebElement listContentPlayer2 = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@id='ContentPlayerMainPanel']")));

        if (listContentPlayer2.isDisplayed() && listContentPlayer2.isEnabled()) {
            WebElement btnAssignForSpecificAssignment = listContentPlayer2.findElement(By.xpath("(//div[contains(@class, 'MuiBox-root')]//button[contains(text(), 'Assign')])[1]"));
            btnAssignForSpecificAssignment.click();

            WebElement dialogAssignment = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@role='dialog']")));
            if (dialogAssignment.isDisplayed()) {
                correctAnswerExecutor_pf.EnterAssignmentTitleForCorrectAnswers();
                correctAnswerExecutor_pf.selectSpecificClasses();
                assignAssessment.setDateTimeAndCategory();
                assignAssessment.enterAdditionalSettings();
                assignAssessment.enterWeightPercentage();
                assignAssessment.assignAssignment();
                assignAssessment.verifyDialogBox();
                TestRunner.getTest().log(Status.PASS, "Test Case Passed : Specific Assignment Type DSB Released Successfully");
            }
        }
    }

    public void SelectAssignmentForCorrectAnswers() throws InterruptedException, AWTException {

        panel_Assignments.isDisplayed();

        String assignmentNameForCorrect = CorrectAnswerExecutor_PF.assignmentNameForCorrect.get();
        System.out.println("Attempting to find assignment: " + assignmentNameForCorrect);
        TestRunner.getTest().log(Status.INFO, "Looking for assignment: " + assignmentNameForCorrect);

        // Search for the assignment by keyword
        WebElement searchBar = driver.findElement(By.xpath("//input[@placeholder='Search Assignment by Title']"));
        searchBar.clear();
        searchBar.click();
        searchBar.sendKeys(assignmentNameForCorrect); // Enter assignment name
        searchBar.sendKeys(Keys.ENTER); // Trigger search

        Thread.sleep(3000);
        WebElement searchBtn= driver.findElement(By.xpath("//button[contains(@class,'MuiButtonBase-root MuiIconButton-root MuiIconButton-edgeStart')]"));
        searchBtn.click();

        Thread.sleep(3000);

// Wait for search results to load and get assignments from search results
        WebElement panelTabOpen = driver.findElement(By.xpath("//div[@aria-labelledby='simple-tab-2']"));
        wait.until(ExpectedConditions.visibilityOf(panelTabOpen));
        Thread.sleep(2000);
        List<WebElement> totalAssignments = panel_Assignments.findElements(By.xpath(".//div[contains(@class, 'MuiGrid-container')]"));
        System.out.println("Total Assignments: " + totalAssignments.size());
        System.out.println("Attempting to find assignment: " + assignmentNameForCorrect);
        TestRunner.getTest().log(Status.INFO, "Looking for assignment: " + assignmentNameForCorrect);

        boolean assignmentFound = false;
// Loop through filtered assignments to find the correct one
        for (WebElement assignment : totalAssignments) {
            WebElement assignmentNameElement = assignment.findElement(By.xpath(".//div[contains(@class, 'notranslate')]"));
            String assignmentName = assignmentNameElement.getText();
            System.out.println("Assignment Name: " + assignmentName);

            if (assignmentName.equals(assignmentNameForCorrect)) {
                System.out.println("Found assignment: " + assignmentName);
                assignmentFound = true;
                try {
                    WebElement startOrResumeButton = assignment.findElement(By.xpath(".//div[@statustype='START' or @statustype='RESUME']"));
                    startOrResumeButton.click();
                    TestRunner.getTest().log(Status.PASS, "Successfully started assignment: " + assignmentName);
                    System.out.println("Assignment started");
                    Thread.sleep(3000);
                    studentExecutor.handleTeacherInstructionsDialog();
                    AttemptAndSubmitWithCorrectAnswers();
                    Thread.sleep(2000);
                } catch (NoSuchElementException e) {
                    System.out.println("START/RESUME button not found for assignment: " + assignmentName);
                    return;
                }

                // Refresh and load assignments again to verify completion
                refreshPage();
                Thread.sleep(3000);
                studentExecutor.dialogBox_ImpAnnouncement();

                try {
//                    WebElement tabOpenPanel = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[@class='ScrollbarsCustom-Content'])[2]")));
                    WebElement tabOpenAssignments = driver.findElement(By.xpath("//div[@aria-labelledby='simple-tab-2']"));

                    List<WebElement> totalAssignment = tabOpenAssignments.findElements(By.xpath(".//div[contains(@class, 'notranslate')]"));
                    System.out.println("Total Assignments after refresh: " + totalAssignment.size());

                    if (!totalAssignment.isEmpty()) {
                        for (WebElement assignmentText : totalAssignment) {
                            System.out.println("Assignment Text: " + assignmentText.getText());
                        }
                    }
                } catch (TimeoutException te) {
                    System.out.println("Failed to load assignments after refresh. Retrying...");
                }
                break;
            } else {
                System.out.println("Assignment not found: " + assignmentName);
            }
        }

        if (!assignmentFound) {
            System.out.println("Assignment not found : " + assignmentNameForCorrect);
            TestRunner.getTest().log(Status.FAIL, "Assignment not found in the list. Using search bar to find: " + assignmentNameForCorrect);
        }
    }

    private void refreshPage() {
        driver.navigate().refresh();
    }

    public void AttemptAndSubmitWithCorrectAnswers() throws InterruptedException, AWTException {
        if (!isPaginationDisplayed()) {
            studentExecutor.AssignmentSubmitAsCompleted();
            return;
        }

        try {

            List<WebElement> questionButtons = nav_Pagination.findElements(By.xpath("//button[contains(@aria-label, 'Go to page')]"));

            for (WebElement questionButton : questionButtons) {
                String questionText = questionButton.getText();
                System.out.println("Question: " + questionText);
            }

            AtomicInteger questionIndex = new AtomicInteger(1);
            while (btn_NavNextPage.isEnabled()) {
                Thread.sleep(2000);
                attemptAssignmentWithCorrectAnswers(questionIndex);
                btn_NavNextPage.click();
                Thread.sleep(2000);
            }

            System.out.println("Assignment attempted with all correct answers. Now submit the assignment");
            TestRunner.getTest().log(Status.INFO, "Assignment submitted with all correct answers. And Overview Status is verified");
            studentExecutor.AssignmentSubmitAsCompleted();
        } catch (NoSuchElementException | ElementNotInteractableException | TimeoutException e) {
            System.out.println("No Question found.");
        }
    }

    private boolean isPaginationDisplayed() {
        try {
            return nav_Pagination.isDisplayed();
        } catch (NoSuchElementException | ElementNotInteractableException | TimeoutException e) {
            return false;
        }
    }

    List<String> solvedQuestionIDs = new ArrayList<>();

    public void attemptAssignmentWithCorrectAnswers(AtomicInteger questionIndex) throws InterruptedException, AWTException {
        System.out.println("I'm in attempting all questions with correct answers");
        TestRunner.startTest("Attempt assignment with all correct answers For Overview Status");
        Thread.sleep(1000);

        WebElement questionPlayer = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("lesson-player-ifram")));
        driver.switchTo().frame(questionPlayer);
        WebElement QuestionBody = driver.findElement(By.xpath("//div[contains(@class, 'LessonPlayerRoot')]"));


        WebElement QuestionPlayer = null;


        try {
            List<WebElement> multiParts = QuestionBody.findElements(By.xpath("//div[contains(@class, 'planComponentQuestion')]"));
            System.out.println("Total number of multi-part on this page: " + multiParts.size());
            TestRunner.getTest().log(Status.INFO, "Total part of question (if multipart question exists): " + multiParts.size());

            for (var part : multiParts) {
                QuestionPlayer = part.findElement(By.xpath(".//div[contains(@class, 'QuestionPlayer')]"));

                System.out.println("Question is found");
                String questionType = QuestionPlayer.getAttribute("data-type");
                System.out.println("Question Type is: " + questionType);
                TestRunner.getTest().log(Status.INFO, "Attempted question type is: " + questionType);

                WebElement questionRoot = QuestionPlayer.findElement(By.xpath(".//div[contains(@class, 'question-root')]"));
                questionID = questionRoot.getAttribute("data-question-id");
                System.out.println("Question ID is: " + questionID);
                TestRunner.getTest().log(Status.INFO, "Attempted question ID is: " + questionID);

                solvedQuestionIDs.add(questionID);
                System.out.println("Solved Question IDs: " + solvedQuestionIDs);

                switch (questionType) {
                    case "extended-text-interaction" -> studentExecutor.QuestionExtendedTextInteraction();
                    case "choice-interaction-single" -> correctAnswerExecutor_pf.QuestionChoiceInteractionSingleAccurate(questionRoot,questionID);
                    case "match-dragdrop-interaction" -> correctAnswerExecutor_pf.QuestionMatchDragdropInteractionAccurate(questionRoot,questionID);
                    case "inline-choice-select-interaction" -> correctAnswerExecutor_pf.QuestionInlineChoiceSelectInteractionAccurate(questionRoot,questionID);
                    case "choice-imagelabel-select-interaction" -> correctAnswerExecutor_pf.QuestionChoiceImageLabelSelectInteractionAccurate(questionRoot,questionID);
                    case "inline-choice-text-interaction" -> QuestionInlineChoiceTextInteraction(questionRoot,questionID);
                    case "inline-choice-spelling-interaction" -> correctAnswerExecutor_pf.QuestionInlineChoiceSpellingInteractionAccurate(questionRoot,questionID);
                    case "drawing-interaction" -> studentExecutor.QuestionDrawingInteraction();
                    case "match-interaction" -> correctAnswerExecutor_pf.QuestionMatchInteractionAccurate(questionRoot,questionID);
                    case "upload-interaction" -> studentExecutor.QuestionUploadInteraction();
                    case "graphic-gap-match-interaction" -> correctAnswerExecutor_pf.QuestionGraphicGapMatchInteractionAccurate(questionID);
                    case "order-interaction" -> correctAnswerExecutor_pf.QuestionOrderInteractionAccurate(questionID);
                    case "choice-interaction" -> correctAnswerExecutor_pf.QuestionChoiceInteractionsAccurate(questionRoot,questionID);
                    case "gap-match-interaction" -> correctAnswerExecutor_pf.QuestionGapMatchInteractionAccurate(questionID);
                    default -> {
                    }
                }
                TestRunner.getTest().log(Status.INFO, "I'm at overview Screen for verify Answered Questions " + questionID);

                overviewVerification(driver, questionIndex);
                questionIndex.incrementAndGet();

                closeOverviewAndSwitchToQuestionFrame();
            }
        } catch (NoSuchElementException e) {
            System.out.println("This is a content player question and have no any data type question");
            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
        } finally {
            driver.switchTo().defaultContent();
        }
    }
    public void overviewVerification(WebDriver driver, AtomicInteger questionIndex) {
        String buttonIndex;
        driver.switchTo().defaultContent();

        WebElement overview = driver.findElement(By.xpath("//span[@class='openOverview']"));

        overview.click();

        driver.switchTo().frame("lesson-player-ifram");

        List<WebElement> overviewButtons = driver.findElements(By.xpath("//div[contains(@class, 'ScrollbarsCustom-Content')]//button[contains(@class, 'MuiButton-root') and .//div[contains(text(), 'Answered')]]"));


        List<String> overviewTexts = new ArrayList<>();
        for (WebElement button : overviewButtons) {
            String overviewText = button.getText().trim();
            System.out.println("All answered text are: " + overviewText);
            TestRunner.getTest().log(Status.INFO, "Answered Question on Overview Screen " + overviewText);
            overviewTexts.add(overviewText);

        }

        boolean found = false;
        for (String overviewText : overviewTexts) {
            buttonIndex = overviewText.replaceAll("[^0-9]", "");
            if (Integer.toString(questionIndex.get()).equals(buttonIndex)) {
                if (overviewText.contains("Unanswered")) {
                    System.out.println("Unanswered");
                    TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Attempted Question in Still Unanswered.");
//                    throw new RuntimeException("Attempted Question in Still Unanswered.");

                }
                System.out.println(overviewText + " Question Attempted Status is answered. ");
                TestRunner.getTest().log(Status.INFO, overviewText + " Question Attempted Status is answered.");
                TestRunner.getTest().log(Status.PASS, "Test Case Passed : Question Overview Status verify Successfully");
                found = true;
                break;
            }
        }

        if (!found) {
            System.out.println("The numbers do not match!");
        }

    }
//    public void overviewVerification(WebDriver driver, AtomicInteger questionIndex) {
//        driver.switchTo().defaultContent();
//
//        WebElement overview = driver.findElement(By.xpath("//span[@class='openOverview']"));
//        overview.click();
//        driver.switchTo().frame("lesson-player-ifram");
//
//        List<WebElement> overviewButtons = driver.findElements(By.xpath("//button[contains(@class,'MuiButton-root') and contains(@class,'MuiButton-text') and contains(@class,'MuiButton-textPrimary') and contains(@class,'MuiButton-sizeMedium') and contains(@class,'MuiButton-textSizeMedium') and contains(@class,'MuiButtonBase-root') and contains(@class,'css-1htsiew')]"));
//
//        List<String> overviewTexts = new ArrayList<>();
//        for (WebElement button : overviewButtons) {
//            WebElement numberOverview = button.findElement(By.xpath(".//div[contains(@class, 'MuiBox-root css-1eac18r')]"));
//            String overviewText = numberOverview.getText().trim();
//            overviewTexts.add(overviewText);
//        }
//
//        boolean found = false;
//        for (String overviewText : overviewTexts) {
//            if (Integer.toString(questionIndex.get()).equals(overviewText)) {
//                System.out.println( overviewText + " Question is answered. ");
//                System.out.println("************************************************************");
//                found = true;
//                break;
//            }
//        }
//
//        if (!found) {
//            System.out.println("The numbers do not match!");
//        }
//    }


    public void closeOverviewAndSwitchToQuestionFrame() {
        driver.switchTo().defaultContent();

        WebElement close_review = driver.findElement(By.xpath("//span[@class='closeOverview']"));
        close_review.click();

        WebElement questionPlayer = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("lesson-player-ifram")));
        driver.switchTo().frame(questionPlayer);
    }

    public void QuestionInlineChoiceTextInteraction(WebElement qs,String questionID) throws InterruptedException {
        System.out.println("I'm in Inline Choice Text Interaction");

        WebElement ItemAnswerContainerVB = qs.findElement(By.xpath(".//div[contains(@class, 'testItemAnswersContainer')]"));
        List<WebElement> AnswersTextAreaVB;         //VB = Vocabulary Builder

        AnswersTextAreaVB = ItemAnswerContainerVB.findElements(By.tagName("textarea"));

        int numberOfTextAreas = AnswersTextAreaVB.size();
        System.out.println("Number of text areas: " + numberOfTextAreas);

        for (WebElement textAreaVB : AnswersTextAreaVB) {

            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript("arguments[0].value='';", textAreaVB);

            String RandomTextForTextAreaVB = generateRandomText("Automated Text Generated For Inline Choice Text Interaction ");
            System.out.println(RandomTextForTextAreaVB);

            textAreaVB.sendKeys(RandomTextForTextAreaVB);
        }

        Thread.sleep(2000);
        helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
    }

    public String generateRandomText(String prefix) {
        String characters = "ABC123456789";
        StringBuilder randomText = new StringBuilder();
        Random random = new Random();
        int length = 6;
        randomText.append(prefix);
        for (int i = 0; i < length; i++) {
            randomText.append(characters.charAt(random.nextInt(characters.length())));
        }
        return randomText.toString();
    }

}
