package pageFactory.NotificationModule;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;
import java.util.Random;

import static org.openqa.selenium.By.tagName;

public class CreateNotificationByTeacher_PF {
    WebDriverWait wait;
    WebDriver driver;
    Helper helper;
    

    public  CreateNotificationByTeacher_PF(WebDriver driver){
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        helper = new Helper();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
    }
    public static String AnnouncementTitle;
    public static String selectedStatusForAnnouncement;
    public static String selectedTypeForAnnouncement;
    public static String selectedUrgencyForAnnouncement;
    public static String announcementStatement;
    private static String startDateTime;
    public static String selectedRole;

    public static String boxTitle;
    public static String messageAnnouncement;

    public static String specificClasses = "FL Grade 5";


    @FindBy(xpath = "//input[@name='subjectText']")
    WebElement AnnouncementTitleInput;

    @FindBy(xpath = "//label[normalize-space(text())='Status']/following-sibling::div//div[@role='button' or @role='combobox']")
    WebElement statusDropdown;

    @FindBy(xpath = "//label[normalize-space(text())='Select Type']/following-sibling::div//div[@role='button' or @role='combobox']")
    WebElement typeDropdown;

    @FindBy(xpath = "//label[normalize-space(text())='Select Urgency']/following-sibling::div//div[@role='button' or @role='combobox']")
    WebElement UrgencyDropdown;

    @FindBy(xpath = "(//input[@type='checkbox'])[2]")
    WebElement AutoDisplayCheckBox;

    @FindBy(xpath = "//div[contains(@class, 'selectTextFieldsWrapper')]")
    WebElement dropDown_SelectCourse;

    @FindBy(xpath = "//button[@id='btn-send']")
    WebElement btn_send;

    @FindBy(xpath = "//div[@class='rrt-middle-container']")
    WebElement toastContainer;

    static String messageTitle;
    static String messageText;

    public void teacherDashboard() throws InterruptedException{
        TestRunner.getTest().log(Status.PASS,"I'm in Teacher Dashboard");

        System.out.println("Waiting for Teacher dashboard visible...");
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class,'analytics staffDashboard')]")));
        TestRunner.getTest().log(Status.PASS,"Test Case Passed : Teacher Dashboard Loads Successfully");
    }

    public void SideNavBar() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm in Dashboard and checking the side navbar");
        Thread.sleep(1000);

        WebElement navBar = driver.findElement(By.xpath("//div[@class='navigation']"));

        List<WebElement> totalLinks = navBar.findElements(tagName("a"));

        for (WebElement link : totalLinks) {
            String hrefValue = link.getAttribute("href");
            System.out.println("Link is: " + hrefValue);
        }
        TestRunner.getTest().log(Status.PASS, "Test Case Passed : Dashboard is visible");
    }

    public void NotificationButton() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm in Dashboard and checking Notification Button");

        WebElement notificationButton= driver.findElement(By.xpath("(//*[name()='svg'][@aria-label='Announcements'])[2]/parent::button"));

        if (notificationButton.isDisplayed() && notificationButton.isEnabled()){
            notificationButton.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed : Notification Button clicked Successfully");
        }
        else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Notification Button is not Display");
            throw new RuntimeException("Notification Button is not Display on Teacher's Dashboard");
        }
    }

    public void NotificationDialogueBox() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm in Notification Dialogue Box");
        WebElement DialogueBox= driver.findElement(By.xpath("//div[contains(@class, 'MuiPopover-paper')]"));

        if (DialogueBox.isDisplayed()){
            WebElement nameInsideBox= driver.findElement(By.xpath("//span[normalize-space()='Notifications']"));
            String notificationName = nameInsideBox.getText();
            System.out.println("Heading of Dialogue Box is : " + notificationName);
            TestRunner.getTest().log(Status.INFO, "Heading of Dialogue Box is : " + notificationName);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed : Notification Dialogue Name Display Successfully");
        }else {
           System.out.println("Heading is not Displayed");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Notification Dialogue Name not Display/Heading is not Displayed");
        }
    }

    public void clickOnPlusIcon() throws InterruptedException{

        TestRunner.getTest().log(Status.INFO, "I'm in Notification Dialogue Box To click on + Icon ");

        WebElement plusIcon= driver.findElement(By.xpath("//div[contains(@class,'header-container')]//span[@role='button' or @role='combobox']"));

        if ((plusIcon.isDisplayed() && plusIcon.isEnabled())){
            plusIcon.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed : Plus Icon Clicked Successfully");
        }
        else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed :  Plus Icon in Notification is not Displayed.");
            throw new RuntimeException("Plus Icon in Notification is not Displayed.");
        }

    }

    public void validateNotificationDashboard() throws InterruptedException{
        System.out.println("I'm in Notifications dashboard");
        TestRunner.getTest().log(Status.INFO, "I'm in Notifications dashboard ");
        Thread.sleep(1000);

        try {

            WebElement breadCrumbOfMyContent = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ol[contains(@class, 'MuiBreadcrumbs')]")));
            System.out.println("Notifications BreadCrumb is: " + breadCrumbOfMyContent.getText());
            TestRunner.getTest().log(Status.INFO, "Notifications BreadCrumb is: " + breadCrumbOfMyContent.getText());
            TestRunner.getTest().log(Status.PASS, "Test Case Passed : Notification Dashboard Loads Successfully");
        } catch (TimeoutException e) {
            System.out.println("Notification Dashboard not Display");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Notification Dashboard not Display");
            throw new RuntimeException("Notification Dashboard not Display");
        }
    }

    public void EnterAnnouncementTitle() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "Enter Announcement Title ");

        AnnouncementTitleInput.click();
        ((JavascriptExecutor) driver).executeScript("arguments[0].value='';", AnnouncementTitleInput);
        AnnouncementTitle = helper.generateRandomText("Automated Announcement ");
        TestRunner.getTest().log(Status.INFO, "Announcement Title is: " + AnnouncementTitle);
        System.out.println("Announcement title is: " + AnnouncementTitle);
        AnnouncementTitleInput.sendKeys(AnnouncementTitle);
        TestRunner.getTest().log(Status.PASS, "Test Case Passed : New Announcement Title enter successfully");
    }

    public void selectType() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "Select Type For Announcement ");
        wait.until(ExpectedConditions.elementToBeClickable(typeDropdown));
        typeDropdown.click();

        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//ul[@role='listbox']")));
        List<WebElement> AnnouncementTypeOptions = driver.findElements(By.xpath("//ul[@role='listbox']//li"));

        System.out.println("Available Types Options For Announcement:");
        for (WebElement option : AnnouncementTypeOptions) {
            System.out.println(option.getText());
        }

        if (!AnnouncementTypeOptions.isEmpty()) {
            Random random = new Random();
            int randomCourse = random.nextInt(AnnouncementTypeOptions.size());
            WebElement selectedOption = AnnouncementTypeOptions.get(randomCourse);
            selectedTypeForAnnouncement = selectedOption.getText();
            selectedOption.click();
//            selectedStatusForAnnouncement = selectedOption.getText();
            System.out.println("Selected Type for Announcement: " + selectedTypeForAnnouncement);
            TestRunner.getTest().log(Status.INFO, "Selected Type for Announcement: " + selectedTypeForAnnouncement);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed : Type for Announcement select successfully");

        } else {

            System.out.println(" No options found in the Type dropdown.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : No options found in the Type dropdown.");
            throw new RuntimeException("No Type Value found in dropdown");
        }
        Actions actions = new Actions(driver);
        actions.sendKeys(Keys.ESCAPE).build().perform();

    }

    public void selectStatusForAnnouncement() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "Select Status For Announcement ");

        wait.until(ExpectedConditions.elementToBeClickable(statusDropdown));
        statusDropdown.click();

        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//ul[@role='listbox']")));
        List<WebElement> AnnouncementStatusOptions = driver.findElements(By.xpath("//ul[@role='listbox']//li"));

        System.out.println("Available Status Options For Announcement:");
        for (WebElement option : AnnouncementStatusOptions) {
            System.out.println(option.getText());
        }

        if (!AnnouncementStatusOptions.isEmpty()) {
            Random random = new Random();
            int randomCourse = random.nextInt(AnnouncementStatusOptions.size());
            WebElement selectedOption = AnnouncementStatusOptions.get(randomCourse);
            selectedStatusForAnnouncement = selectedOption.getText();
            selectedOption.click();
//            selectedTypeForAnnouncement = selectedOption.getText();
            System.out.println("Selected Status for Announcement: " + selectedStatusForAnnouncement);
            TestRunner.getTest().log(Status.INFO, "Selected Status for Announcement: " + selectedStatusForAnnouncement);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed :  Status for Announcement select successfully");

        } else {

           System.out.println("No options found in the Status dropdown.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : No options found in the Status dropdown.");
            throw new RuntimeException("No Status Value found in dropdown");
        }
        Actions actions = new Actions(driver);
        actions.sendKeys(Keys.ESCAPE).build().perform();
    }

    public void setStartDateAndTime() {
        TestRunner.getTest().log(Status.INFO, "Set Date And Time For Announcement ");

        startDateTime = helper.generateStartDateTime();
        System.out.println("Generated Start DateTime: " + startDateTime);
        TestRunner.getTest().log(Status.INFO, " End DateTime: " + startDateTime);
        setDateTimeValueByJS("//label[contains(text(),'End Date & Time')]/following-sibling::div//input", startDateTime);
        TestRunner.getTest().log(Status.PASS, "Test Case Passed :  End date and Time set Successfully");

    }

    private void setDateTimeValueByJS( String xpath, String value) {
        WebElement element = driver.findElement(By.xpath(xpath));
        JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
        jsExecutor.executeScript("arguments[0].value = arguments[1];", element, value);
    }

    public void selectUrgencyForAnnouncement() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "Select Urgency For Announcement");

        wait.until(ExpectedConditions.elementToBeClickable(UrgencyDropdown));
        UrgencyDropdown.click();

        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//ul[@role='listbox']")));
        List<WebElement> AnnouncementUrgencyOptions = driver.findElements(By.xpath("//ul[@role='listbox']//li"));

        System.out.println("Available Urgency Options For Announcement:");
        for (WebElement option : AnnouncementUrgencyOptions) {
            System.out.println(option.getText());
        }

        if (!AnnouncementUrgencyOptions.isEmpty()) {
            Random random = new Random();
            int randomCourse = random.nextInt(AnnouncementUrgencyOptions.size());
            WebElement selectedOption = AnnouncementUrgencyOptions.get(randomCourse);
            selectedUrgencyForAnnouncement = selectedOption.getText();
            selectedOption.click();
//            selectedUrgencyForAnnouncement = selectedOption.getText();
            System.out.println("Selected Urgency for Announcement: " + selectedUrgencyForAnnouncement);

            TestRunner.getTest().log(Status.INFO, "Selected Urgency for Announcement: " + selectedUrgencyForAnnouncement);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed :   Urgency for Announcement select successfully");
        } else {

            System.out.println("No options found in the Urgency dropdown.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : No options found in the Urgency dropdown.");
            throw new RuntimeException("No Urgency Value found in dropdown");
        }
        Actions actions = new Actions(driver);
        actions.sendKeys(Keys.ESCAPE).build().perform();

    }

    public void AnnouncementStatement() throws InterruptedException{
        System.out.println("Enter data into Announcement Statement text box");
        TestRunner.getTest().log(Status.INFO, "Enter data into Announcement Statement text box");
        WebElement RichTextBoxBody = driver.findElement(By.xpath("//div[@class='tox-edit-area']/iframe"));

        driver.switchTo().frame(RichTextBoxBody);

        WebElement edt_RichTextBox = driver.findElement(By.xpath("//body[@id='tinymce']//p"));

        System.out.println("Edit text area is found");

        edt_RichTextBox.clear();

        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].value='';", edt_RichTextBox);

        announcementStatement = generateRandomText("Announcement Statement! Important Announcement...  ");
        System.out.println(announcementStatement);
        TestRunner.getTest().log(Status.INFO, "Announcement Statement is : " + announcementStatement);

        edt_RichTextBox.sendKeys(announcementStatement);
        helper.takeScreenshot(driver , Thread.currentThread().getStackTrace()[1].getMethodName() );

        TestRunner.getTest().log(Status.PASS, "Test Case Passed :   Announcement Statement enter successfully");
        driver.switchTo().defaultContent();
    }

    public void selectAutoDDisplayCheckBox() throws InterruptedException{
        System.out.println("Click on Auto Display Check Box");
        TestRunner.getTest().log(Status.INFO, "Click on Auto Display Check Box");
        AutoDisplayCheckBox.click();
        TestRunner.getTest().log(Status.PASS, "Test Case Passed :   Auto Display Checkbox click successfully");
    }

    public void NextButtonAnnouncement() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "Click on Announcement Next Button ");
        WebElement btn_next= driver.findElement(By.xpath("//button[@id='btn-saveNext']"));
        if (btn_next.isDisplayed()){
            btn_next.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed :   Next Button clicked Successfully");
        }
        else {
            System.out.println("Next Button is Disable");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Next Button is Disable.");
            throw new RuntimeException("Next Button is Disable");
        }
    }


    public void selected_Class() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Select Class For Announcement ");
        Thread.sleep(5000);
        WebElement classDropdown = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class,'selectTextFieldsWrapper')]")));
        if (classDropdown.isDisplayed() && classDropdown.isEnabled()) {
            System.out.println("Class dropdown enabled and click");
            TestRunner.getTest().log(Status.INFO, "Class dropdown enabled and click");
            classDropdown.click();
            Thread.sleep(2000);

            WebElement listBox = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//ul[@role='listbox']")));
            List<WebElement> totalClasses = listBox.findElements(By.tagName("li"));
            System.out.println("Total Classes: " + totalClasses.size());

            for (WebElement classElement : totalClasses) {
                if (classElement.getText().equals(specificClasses)) {
                    classElement.click();
                    System.out.println("Selected class: " + specificClasses);
                    TestRunner.getTest().log(Status.INFO, "Selected class: " + specificClasses);
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed :   Class Select Successfully");
                    break;
                }
            }
        } else {
            System.out.println("Class dropdown is not visible or enabled.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Class dropdown is not visible or enabled");
            throw new RuntimeException("no class found");
        }
    }

    public void Select_Roles()throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "Select Roles ");

        List<WebElement> checkboxes = driver.findElements(By.xpath("//div[contains(@class, 'MuiFormGroup-root')]//label"));

        for (WebElement checkboxLabel : checkboxes) {
            WebElement checkboxInput = checkboxLabel.findElement(By.tagName("input"));
            if (checkboxInput.isSelected()) {
                checkboxInput.click();
            }
        }

        for (WebElement checkboxLabel : checkboxes) {

            String labelText = checkboxLabel.getText();
            if (labelText.contains("Student")) {
                WebElement checkboxInput = checkboxLabel.findElement(By.tagName("input"));
                checkboxInput.click();
                selectedRole = labelText;
                TestRunner.getTest().log(Status.INFO, "Selected Role is : " + selectedRole);
                TestRunner.getTest().log(Status.PASS, "Test Case Passed :   Role Select Successfully");
                break;
            }
        }
        helper.takeScreenshot(driver , Thread.currentThread().getStackTrace()[1].getMethodName() );
    }

    public void getAnnouncementSummary() throws InterruptedException{

        TestRunner.getTest().log(Status.INFO, "Get Announcement Summary ");
        WebElement announcementSummary = driver.findElement(By.xpath("//div[@class='autherAnnouncementSummary-InerContainer']"));

        String titleAnnouncement = getElementTextByType(announcementSummary, "Title");
        String typeAnnouncement = getElementTextByType(announcementSummary, "Type");
        String statusAnnouncement = getElementTextByType(announcementSummary, "Status");
        String autoDisplayAnnouncement= getElementTextByType(announcementSummary, "Auto Display");
        String urgentAnnouncement = getElementTextByType(announcementSummary, "Urgent");
        String descriptionAnnouncement = getElementTextByType(announcementSummary, "Description");
        String districtAnnouncement = getElementTextByType(announcementSummary, "District");
        String schoolAnnouncement = getElementTextByType(announcementSummary, "School");
        String distributeToAnnouncement = getElementTextByType(announcementSummary, "Distribute to");


        System.out.println("Announcement Summary:");
        System.out.println("Title: " + titleAnnouncement);
        TestRunner.getTest().log(Status.INFO, "Title: " + titleAnnouncement);
        System.out.println("Type: " + typeAnnouncement);
        TestRunner.getTest().log(Status.INFO, "Type: " + typeAnnouncement);
        System.out.println("Status: " + statusAnnouncement);
        TestRunner.getTest().log(Status.INFO, "Status: " + statusAnnouncement);
        System.out.println("Auto-Display: " + autoDisplayAnnouncement);
        TestRunner.getTest().log(Status.INFO, "Auto-Display: " + autoDisplayAnnouncement);
        System.out.println("Urgent: " + urgentAnnouncement);
        TestRunner.getTest().log(Status.INFO, "Urgent: " + urgentAnnouncement);
        System.out.println("Description: " + descriptionAnnouncement);
        TestRunner.getTest().log(Status.INFO, "Description: " + descriptionAnnouncement);
        System.out.println("District: " + districtAnnouncement);
        TestRunner.getTest().log(Status.INFO, "District: " + districtAnnouncement);
        System.out.println("School: " + schoolAnnouncement);
        TestRunner.getTest().log(Status.INFO, "School: " + schoolAnnouncement);
        System.out.println("Distribute to: " + distributeToAnnouncement);
        TestRunner.getTest().log(Status.INFO, "Distribute to: " + distributeToAnnouncement);

        validateAnnouncementDetail("Announcement Title", titleAnnouncement, AnnouncementTitle);
        validateAnnouncementDetail("Announcement Type", typeAnnouncement, selectedTypeForAnnouncement);
        validateAnnouncementDetail("Announcement Status", statusAnnouncement, selectedStatusForAnnouncement);
        validateAnnouncementDetail("Announcement Urgency", urgentAnnouncement, selectedUrgencyForAnnouncement);
        validateAnnouncementDetail("Announcement Description",descriptionAnnouncement, announcementStatement);
        validateAnnouncementDetail("Announcement Role", distributeToAnnouncement, selectedRole);

    }

    private void validateAnnouncementDetail(String detailName, String actualValue, String expectedValue) {
        if (actualValue.equals(expectedValue)) {
            TestRunner.getTest().log(Status.INFO,"Test Case Passed: Match" +  detailName);
            TestRunner.getTest().log(Status.INFO, "Match in  Announcement Summary Data match" + detailName);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Announcement Summary Data match ");
        } else {
            TestRunner.getTest().log(Status.INFO,"Test Case Failed:  Mismatch on summary page" +  detailName);
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Mismatch on summary page" + detailName);
            throw new RuntimeException(detailName + " Mismatch on summary page");
        }
    }

    public String getElementTextByType(WebElement wrapper, String keyLabel) {

        try {
            WebElement keyValuePair = wrapper.findElement(By.xpath(".//div[contains(@class, 'key-value-pair')][.//strong[text()='" + keyLabel + "']]"));
            WebElement valueElement = keyValuePair.findElement(By.xpath(".//*[contains(@class, 'value')]"));
            return valueElement.getText().trim();
        }
        catch (NoSuchElementException e){
            System.out.println("Element not found for type: " + keyLabel);
            return "N/A";
        }

    }

    public String generateRandomText(String prefix) {
        String characters = "ABC123456789";
        StringBuilder randomText = new StringBuilder();
        Random random = new Random();
        int length = 6;
        randomText.append(prefix);
        for (int i = 0; i < length; i++) {
            randomText.append(characters.charAt(random.nextInt(characters.length())));
        }
        return randomText.toString();
    }


    public void ClickSendButton() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "Click on Save Button ");
        if (btn_send.isEnabled() && btn_send.isDisplayed()){
            btn_send.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed : Announcement Send Button clicked successfully");
        } else {
           System.out.println("Send Button is Disable");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed :Send Button is Disable");
            throw new RuntimeException("Send Button not Enabled.");

        }
    }

    public void ValidateSendingAnnouncementDialogueBox() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "Validate Sending Announcement Dialogue Box");
        WebElement sendingAnnouncementBox= wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@aria-labelledby='customized-dialog-title']")));

        WebElement dialogueBoxTitle= sendingAnnouncementBox.findElement(By.xpath(".//h2[@id='customized-dialog-title']"));
        String dialogTitle = dialogueBoxTitle.getText();
        System.out.println("Dialog Title: " + dialogTitle);

        TestRunner.getTest().log(Status.INFO, "Dialog Title: " + dialogTitle);

        WebElement dialogContent = driver.findElement(By.xpath("//div[contains(@class, 'MuiDialogContent-root')]"));

        List<WebElement> paragraphs = dialogContent.findElements(By.tagName("p"));

        for (WebElement paragraph : paragraphs) {
            String text = paragraph.getText();
            System.out.println("Paragraph Text: " + text);
            TestRunner.getTest().log(Status.INFO, "Paragraph Text: " + text);
        }

        TestRunner.getTest().log(Status.PASS, "Test Case Passed : Sending Announcement Dialogue Box Success fully");

        WebElement btn_confirm= driver.findElement(By.xpath("(//button[normalize-space()='Confirm'])[1]"));

        if (btn_confirm.isEnabled() && btn_confirm.isDisplayed()){
            btn_confirm.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed : Button Confirm is clicked and Announcement Send Successfully");
        }else {
            System.out.println("Button confirm is not enabled");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Button confirm is not enabled");
            throw new RuntimeException("Button confirm is not enabled");

        }
    }

    public void ValidateToastMessage() throws InterruptedException{

//        WebDriverWait wait = new WebDriverWait(driver, 2);
        wait.pollingEvery(Duration.ofMillis(20));
        try {
            WebElement toastContainer = wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("toastr")));
            if (toastContainer.isDisplayed()) {
                String messageTitle = toastContainer.findElement(By.className("rrt-title")).getText();
                String messageText = toastContainer.findElement(By.className("rrt-text")).getText();

                System.out.println("Message Title: " + messageTitle);
                System.out.println("Message Text: " + messageText);
                TestRunner.getTest().log(Status.PASS,"Test case Passed : Toast Message Get Successfully");
            } else {
                TestRunner.getTest().log(Status.FAIL,"Toast message is not displayed.");
            }
        } catch (TimeoutException e) {
            TestRunner.getTest().log(Status.FAIL,"Toast message did not appear in the expected time.");
        }
    }

    public void ValidateImportantAnnouncementDialogueBox() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "Validate Important Announcement Dialogue Box");
        try {
            if (boxTitle.equals(AnnouncementTitle)){
                System.out.println("Announcement Title in Dialogue box match with Teacher's Title ");
                TestRunner.getTest().log(Status.INFO, "Announcement Title in Dialogue box: " +  boxTitle +" match with Teacher's Title: " + AnnouncementTitle);
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: Title Match in Dialogue Box");
            }else {
                System.out.println("Title Not Match in Dialogue Box");
                TestRunner.getTest().log(Status.INFO, "Announcement Title in Dialogue box: " +  boxTitle +" not match with Teacher's Title: " + AnnouncementTitle);
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Title Not Match in Dialogue Box");
                throw new RuntimeException("Title Not Match in Dialogue Box with Teacher's Title of Announcement.");
            }

            if (messageAnnouncement.equals(announcementStatement)){
                System.out.println("Announcement Description in Dialogue box match with Teacher's Description");
                TestRunner.getTest().log(Status.INFO, "Announcement Description in Dialogue box: " +  messageAnnouncement +" match with Teacher's Description: " + announcementStatement);
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: Description Match in Dialogue Box");
            }else {
                System.out.println("Announcement Description Not Match in Dialogue Box");
                TestRunner.getTest().log(Status.INFO, "Announcement Description in Dialogue box: " +  messageAnnouncement +" Not match with Teacher's Description: " + announcementStatement);
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Description Not Match in Dialogue Box");
                throw new RuntimeException("Description Not Match in Dialogue Box with Teacher's Description of Announcement.");
            }

        } catch (NoSuchElementException | ElementNotInteractableException | TimeoutException e) {
            System.out.println("Announcement not found at Student Side.");
            throw new RuntimeException("Announcement not found at Student Side.");
        }
    }
    
}
