package pageFactory.NotificationModule;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.sl.In;
import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static pageFactory.NotificationModule.CreateNotificationByTeacher_PF.AnnouncementTitle;
import static pageFactory.NotificationModule.CreateNotificationByTeacher_PF.announcementStatement;

public class AnnouncementStudentSide_PF {

    WebDriverWait wait;
    WebDriver driver;
    Helper helper;
    

    public  AnnouncementStudentSide_PF(WebDriver driver){
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        helper = new Helper();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
    }

    public void NotificationButtonStudentSide() throws InterruptedException{
        WebElement notificationButton= driver.findElement(By.xpath("(//*[name()='svg'][@aria-label='Announcements'])"));

        if (notificationButton.isDisplayed() && notificationButton.isEnabled()){
            notificationButton.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed : Notification Button At Student Dashboard clicked Successfully ");
        }
        else {
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed : Notification Button is not Display at Student Dashboard");
        }
    }

    public void InboxButtonValidation() throws InterruptedException{
        List<WebElement> buttons = driver.findElements(By.xpath("//div[contains(@class,'AssessmentDashboardLeftPanelWrapper')]//div[@role='group']//button"));

        for (WebElement button : buttons) {
            String buttonText = button.getText();
            System.out.println("Button name: " + buttonText);

            if (buttonText.equals("Inbox")) {
                button.click();
                TestRunner.getTest().log(Status.PASS, "Test Case Passed :  Inbox Button Click successfully");
                break;
            }
        }
    }
    public void GetAllAnnouncementInInboxTab() throws InterruptedException{
        Map<String, WebElement> descriptionToCardMap = new HashMap<>();

        List<WebElement> cards = driver.findElements(By.cssSelector("div.cardContainer"));

        for (WebElement card : cards) {
            String textInSentTab = card.findElement(By.cssSelector("span.isLeafContentDetail")).getText().trim();
            descriptionToCardMap.put(textInSentTab, card);

            String name = card.findElement(By.cssSelector("h6.rightSide-title")).getText().trim();
            String dateTime = card.findElement(By.cssSelector("span.main-heading")).getText().trim();

            System.out.println("Name: " + name);
            System.out.println("Description: " + textInSentTab);
            System.out.println("Date and Time: " + dateTime);
            System.out.println("-----------------------------");
        }

        WebElement matchingCard = descriptionToCardMap.get(AnnouncementTitle);

        if (matchingCard != null) {
            matchingCard.click();
            System.out.println("Clicked on the card with description: " + AnnouncementTitle);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed : Announcement Title Match and Clicked Successfully");
        } else {
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed: The previous description does not match any descriptions in the Sent tab.");
            throw new RuntimeException("Announcement Not Found");

        }
    }

    public void GetAllDetailsInRightPanelForInbox() throws InterruptedException {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class='right-panel mainBottomLayout-right']")));
        WebElement rightLayout = driver.findElement(By.xpath("//div[@class='right-panel mainBottomLayout-right']"));

        if (rightLayout.isDisplayed()) {
            WebElement titleInRightPanel = driver.findElement(By.xpath("//div[@class='subject']"));
            String titleAtStudent = titleInRightPanel.getText().trim();
            System.out.println("Title of Announcement in Right Panel is: " + titleAtStudent);


            WebElement descriptionInRightPanel = driver.findElement(By.xpath("//div[@class='description']"));
            String descriptionAtStudent = descriptionInRightPanel.getText().trim();
            System.out.println("Description of Announcement in Right Panel is:" + descriptionAtStudent);

            TestRunner.getTest().log(Status.PASS, "Test Case Passed : All Information In Right Panel Get Successfully");

          System.out.println(" Validating Announcement at Student Side");
            if (titleAtStudent.equals(AnnouncementTitle)) {
                System.out.println("Announcement Title Match with Teacher's Title!!!");
                TestRunner.getTest().log(Status.PASS, "Test Case Passed : Title is Match with the Title That teacher set at the Time of creation");
            } else {
                TestRunner.getTest().log(Status.FAIL, " Test Case Failed:  Title not match");
            }

            if (descriptionAtStudent.equals(announcementStatement)) {
                System.out.println("Description Match with Teacher's Description!!!");
                TestRunner.getTest().log(Status.PASS, "Test Case Passed : Description is Match with the Description That teacher set at the Time of creation");
            } else {
                TestRunner.getTest().log(Status.FAIL, " Test Case Failed: Description not match");
            }
        }
        else {
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed : Data in Right Panel Not Display");
            throw new RuntimeException("Data in Right Panel Not Display");

        }
    }

    public void ReadAnnouncementButton() throws InterruptedException{
        WebElement readAnnouncement= driver.findElement(By.xpath("(//span[@aria-label='attach standard'])[1]"));

        if (readAnnouncement.isDisplayed()){
            readAnnouncement.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed : Announcement read Successfully");
        }else {
            TestRunner.getTest().log(Status.PASS, "Test Case Failed : Read Option is not visible");
            throw new RuntimeException(" Read Option is not Display");

        }
    }

    public void VerifyToastMessage() throws InterruptedException{
        wait.pollingEvery(Duration.ofMillis(20));
        try {
            WebElement toastContainer = wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("toastr")));
            if (toastContainer.isDisplayed()) {
                String messageTitle = toastContainer.findElement(By.className("rrt-title")).getText();
                String messageText = toastContainer.findElement(By.className("rrt-text")).getText();

                System.out.println("Message Title: " + messageTitle);
                System.out.println("Message Text: " + messageText);
                TestRunner.getTest().log(Status.PASS, "Test case Passed : Toast Message Get Successfully");
            } else {
                TestRunner.getTest().log(Status.FAIL, " Test Case Failed: Toast message is not displayed.");
            }
        } catch (TimeoutException e) {
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed: Toast message did not appear in the expected time.");
        }
    }

    public void VerifyInboxSection() throws InterruptedException{

        Thread.sleep(5000);
        Map<String, WebElement> descriptionToCardMap = new HashMap<>();

        List<WebElement> cards = driver.findElements(By.cssSelector("div.cardContainer"));

        for (WebElement card : cards) {
            String textInSentTab = card.findElement(By.cssSelector("span.isLeafContentDetail")).getText().trim();
            descriptionToCardMap.put(textInSentTab, card);

            String name = card.findElement(By.cssSelector("h6.rightSide-title")).getText().trim();
            String dateTime = card.findElement(By.cssSelector("span.main-heading")).getText().trim();

            System.out.println("Name: " + name);
            System.out.println("Description: " + textInSentTab);
            System.out.println("Date and Time: " + dateTime);
            System.out.println("-----------------------------");
        }

        WebElement matchingCard = descriptionToCardMap.get(AnnouncementTitle);

        if (matchingCard == null) {
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: The announcement with title '" + AnnouncementTitle + "' was not found.");
        } else {
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed: The announcement with title '" + AnnouncementTitle + "' was found. ");
            throw new AssertionError("Announcement found when it shouldn't be.");
        }
    }

    public void ReadTabAnnouncement() throws InterruptedException{
        List<WebElement> buttons = driver.findElements(By.xpath("//div[contains(@class,'AssessmentDashboardLeftPanelWrapper')]//div[@role='group']//button"));

        for (WebElement button : buttons) {
            String buttonText = button.getText();
            System.out.println("Button name: " + buttonText);

            if (buttonText.equals("Read")) {
                button.click();
                TestRunner.getTest().log(Status.PASS, "Test Case Passed :  Read Button Click successfully");
                break;
            }
        }
    }

    public void VerifyReadSectionAfterReadingAnnouncement() throws InterruptedException{
        Map<String, WebElement> descriptionToCardMap = new HashMap<>();

        List<WebElement> cards = driver.findElements(By.cssSelector("div.cardContainer"));

        for (WebElement card : cards) {
            String textInSentTab = card.findElement(By.cssSelector("span.isLeafContentDetail")).getText().trim();
            descriptionToCardMap.put(textInSentTab, card);

            String name = card.findElement(By.cssSelector("h6.rightSide-title")).getText().trim();
            String dateTime = card.findElement(By.cssSelector("span.main-heading")).getText().trim();

            System.out.println("Name: " + name);
            System.out.println("Description: " + textInSentTab);
            System.out.println("Date and Time: " + dateTime);
            System.out.println("-----------------------------");
        }

        WebElement matchingCard = descriptionToCardMap.get(AnnouncementTitle);

        if (matchingCard != null) {
            matchingCard.click();
            System.out.println("Clicked on the card with description: " + AnnouncementTitle);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed : Announcement Title Match. Announcement is present in Read Section");
        } else {
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed: The Title does not match. Announcement not found in Read tab.");
            throw new RuntimeException(" Announcement not found in Read Tab");

        }
    }

    public void ClickArchiveButton() throws InterruptedException{
        WebElement archiveAnnouncement= driver.findElement(By.xpath("(//span[@aria-label='attach standard'])[2]"));

        if (archiveAnnouncement.isDisplayed()){
            archiveAnnouncement.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed : Announcement Archive Successfully");
        }else {
            TestRunner.getTest().log(Status.PASS, "Test Case Failed : Archive Option is not visible");
            throw new RuntimeException(" Archive Option is not Display");
        }
    }

    public void ArchiveTabAnnouncement() throws InterruptedException{
        List<WebElement> buttons = driver.findElements(By.xpath("//div[contains(@class,'AssessmentDashboardLeftPanelWrapper')]//div[@role='group']//button"));

        for (WebElement button : buttons) {
            String buttonText = button.getText();
            System.out.println("Button name: " + buttonText);

            if (buttonText.equals("Archived")) {
                button.click();
                TestRunner.getTest().log(Status.PASS, "Test Case Passed :  Archive Button Click successfully");
                break;
            }
        }
    }

    public void ClickDeleteButton() throws InterruptedException{
        WebElement deleteIcon= driver.findElement(By.xpath("(//span[@aria-label='attach standard'])[3]"));

        if (deleteIcon.isDisplayed()){
            deleteIcon.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed : Delete Button Click Successfully");
        }else {
            TestRunner.getTest().log(Status.PASS, "Test Case Failed : Delete Button is not found");
            throw new RuntimeException(" Delete Button  is not Display");
        }
    }

    public void VerifyDeletingAnnouncementWindow() throws InterruptedException{
        WebElement DeletingAnnouncement= driver.findElement(By.xpath("//div[@aria-labelledby='customized-dialog-title']"));

        if (DeletingAnnouncement.isDisplayed()){
            WebElement headingInWindow= driver.findElement(By.xpath("//h2[@id='customized-dialog-title']"));
            System.out.println("Heading of Dialogue Box is: " + headingInWindow.getText());

            WebElement Delete_yes= driver.findElement(By.xpath("//button[@id='btn-send']"));
            if (Delete_yes.isDisplayed() && Delete_yes.isEnabled()){
                Delete_yes.click();
                TestRunner.getTest().log(Status.PASS, "Test Case Passed : Yes Delete It Button click Successfully");
            }else {
                TestRunner.getTest().log(Status.PASS, "Test Case Failed : Yes Delete It Button not found");
                throw new RuntimeException(" Yes Delete It Button not found");
            }
        }else {
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed : Deleting Announcement Window not display");
            throw new RuntimeException("Deleting Announcement Window not display");
        }
    }

    public void VerifyDeletedAnnouncementInAllTabs() throws InterruptedException{
        List<WebElement> buttons = driver.findElements(By.xpath("//div[contains(@class,'AssessmentDashboardLeftPanelWrapper')]//div[@role='group']//button"));

        for (WebElement button : buttons) {
            String buttonText = button.getText();
            System.out.println("Clicking on button: " + buttonText);
            button.click();
            Thread.sleep(2000);
            VerifyDeleteAnnouncement(buttonText);
        }
    }

    public void VerifyDeleteAnnouncement(String buttonName) {
        Map<String, WebElement> descriptionToCardMap = new HashMap<>();

        List<WebElement> cards = driver.findElements(By.cssSelector("div.cardContainer"));

        for (WebElement card : cards) {
            String textInSentTab = card.findElement(By.cssSelector("span.isLeafContentDetail")).getText().trim();
            descriptionToCardMap.put(textInSentTab, card);

            String name = card.findElement(By.cssSelector("h6.rightSide-title")).getText().trim();
            String dateTime = card.findElement(By.cssSelector("span.main-heading")).getText().trim();

            System.out.println("Name: " + name);
            System.out.println("Description: " + textInSentTab);
            System.out.println("Date and Time: " + dateTime);
            System.out.println("-----------------------------");
        }

        WebElement matchingCard = descriptionToCardMap.get(AnnouncementTitle);

        if (matchingCard != null) {
            System.out.println("Announcement found in " + buttonName + " tab: " + AnnouncementTitle);
            TestRunner.getTest().log(Status.FAIL, " Test Case Failed: Announcement Title found in " + buttonName + " tab. Announcement should not be present.");
            throw new RuntimeException("Deleting Announcement Window Still found.");
        } else {
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Announcement not found in {} tab. Delete operation successful." +  buttonName);
        }
    }
}
