package pageFactory.NotificationModule;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static pageFactory.NotificationModule.CreateNotificationByTeacher_PF.AnnouncementTitle;
import static pageFactory.NotificationModule.CreateNotificationByTeacher_PF.announcementStatement;

public class AnnouncementVerificationByTeacherRole_PF {

    WebDriverWait wait;
    WebDriver driver;
    Helper helper;

    CreateNotificationByTeacher_PF createNotificationByTeacher_pf;
    public static String textInSentTab;
    

    public  AnnouncementVerificationByTeacherRole_PF(WebDriver driver){
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        helper = new Helper();
        createNotificationByTeacher_pf = new CreateNotificationByTeacher_PF(driver);
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
    }

    @FindBy(xpath = "//div[@aria-label='User Dashboard']")
    WebElement user_dashboard;

    @FindBy(xpath = "//div[@class='footer-container']//button[1]")
    WebElement view_allButton;

    public void ClickUserDashboard() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "Click on User's Dashboard");
        user_dashboard.click();
        TestRunner.getTest().log(Status.PASS, "Test Case Passed : Clicked on User Dashboard Successfully");
    }

    public void ClickViewAllButton() throws InterruptedException{
        if (view_allButton.isDisplayed() && view_allButton.isEnabled()){
            TestRunner.getTest().log(Status.INFO, "Click on View All Button");
            view_allButton.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed : ViewAll Button Clicked Successfully");
        }else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : ViewAll Button is not enable or not Display");
            throw new RuntimeException("ViewAll Button is not enable or not Display.");
        }
    }

    public void verifyLeftPanel() throws InterruptedException {
        try {
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class,'AssessmentDashboardLeftPanelWrapper')]")));
            TestRunner.getTest().log(Status.PASS,"Left panel loaded successfully.");

            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class='right-panel mainBottomLayout-right']")));
            TestRunner.getTest().log(Status.INFO,"Right panel loaded successfully.");

            TestRunner.getTest().log(Status.PASS,"Test case passed.");

        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL,"Test case failed: One or more elements were not visible in the allotted time.");
            throw new AssertionError("Test case failed: Elements were not loaded.");
        }
    }

    public void validateSentButton() throws InterruptedException{

        List<WebElement> buttons = driver.findElements(By.xpath("//div[contains(@class,'AssessmentDashboardLeftPanelWrapper')]//div[@role='group']//button"));

        for (WebElement button : buttons) {
            String buttonText = button.getText();
            System.out.println("Button name: " + buttonText);

            if (buttonText.equals("Sent")) {
                button.click();
                TestRunner.getTest().log(Status.PASS,"Test Case Passed :  Sent Button Click successfully");
                break;
            }
        }
    }

    public void GetAllAnnouncementInSentTab() throws InterruptedException{

        Map<String, WebElement> descriptionToCardMap = new HashMap<>();

        List<WebElement> cards = driver.findElements(By.cssSelector("div.cardContainer"));

        for (WebElement card : cards) {
            String textInSentTab = card.findElement(By.cssSelector("span.isLeafContentDetail")).getText().trim();
            descriptionToCardMap.put(textInSentTab, card);

            String name = card.findElement(By.cssSelector("h6.rightSide-title")).getText().trim();
            String dateTime = card.findElement(By.cssSelector("span.main-heading")).getText().trim();

            System.out.println("Name: " + name);
            System.out.println("Description: " + textInSentTab);
            System.out.println("Date and Time: " + dateTime);
            System.out.println("-----------------------------");
        }

        WebElement matchingCard = descriptionToCardMap.get(AnnouncementTitle);

        if (matchingCard != null) {
            matchingCard.click();
            System.out.println("Clicked on the card with description: " + AnnouncementTitle);
            TestRunner.getTest().log(Status.PASS,"Test Case Passed : Announcement Title Match and Clicked Successfully");
        } else {
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed: The previous description does not match any descriptions in the Sent tab.");
        }
    }

    public void GetAllDetailsInRightPanel() throws InterruptedException {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class='right-panel mainBottomLayout-right']")));

        try {

            WebElement titleInRightPanel = driver.findElement(By.xpath("//div[@class='subject']"));
            System.out.println("Title of Announcement in Right Panel is: " + titleInRightPanel.getText());

            WebElement descriptionInRightPanel = driver.findElement(By.xpath("//div[@class='description']"));
            System.out.println("Description of Announcement in Right Panel is:" + descriptionInRightPanel.getText());

            TestRunner.getTest().log(Status.PASS,"Test Case Passed : All Information In Right Panel Get Successfully");
        } catch (TimeoutException e) {
            TestRunner.getTest().log(Status.FAIL,"Test Case failed: Right Panel not Display");
            throw new RuntimeException("Right Panel not Display");
        }
    }
}
