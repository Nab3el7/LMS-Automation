package pageFactory.Gradebook;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

public class AssignmentVerification_PF {
    ManualGrading_PF manualGrading_PF;
    AssignmentScoreVerification_PF assignmentScoreVerification_PF;
    WebDriverWait wait;
    WebDriver driver;
    Helper helper;
//    String[] specificClasses = {"FL Grade 1", "FL Grade 2"};
    public static String specificClasses = "FL Grade 5";

    @FindBy(xpath = "//span[@role='progressbar']")
    WebElement progressBar;

    @FindBy(xpath = "//ul[@role='listbox']")
    WebElement listBox;

    @FindBy(xpath = "//div[contains(@class, 'StudentListingAndTableWrapper')]")
    WebElement studentAssignmentTable;

    @FindBy(xpath = "//div[contains(@class,'SelectTextFieldsWrapper')]")
    WebElement select_class;

    @FindBy (xpath = "//span[normalize-space()='Summary']")
    WebElement tab_SummaryUpdatedUI;

    public AssignmentVerification_PF(WebDriver driver){
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        helper = new Helper();
        manualGrading_PF = new ManualGrading_PF(driver);
        assignmentScoreVerification_PF = new AssignmentScoreVerification_PF(driver);
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
    }

    public void Select_Class() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm to select class in class dropdown");
        
        // Comprehensive page load check - wait for all API responses and page to be fully loaded
        helper.waitForPageToLoad();
        
        By courseDropDownLocator = By.xpath("//div[contains(@class,'SelectTextFieldsWrapper')]");
        
        // Wait for dropdown to be visible, present, and clickable
        WebElement classDropdown = wait.until(ExpectedConditions.elementToBeClickable(courseDropDownLocator));
        
        if (classDropdown.isDisplayed() && classDropdown.isEnabled()) {
            System.out.println("Class dropdown enabled and click");
            TestRunner.getTest().log(Status.INFO, "Class dropdown enabled and click");
            
            // Scroll to element if needed
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", classDropdown);
            
            // Click the dropdown
            try {
                classDropdown.click();
            } catch (ElementClickInterceptedException e) {
                // If click is intercepted, use JavaScript click
                ((JavascriptExecutor) driver).executeScript("arguments[0].click();", classDropdown);
            }
            
            // Wait for listbox to appear with increased timeout and better error handling
            WebElement listBox;
            try {
                WebDriverWait listBoxWait = new WebDriverWait(driver, Duration.ofSeconds(30));
                listBox = listBoxWait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//ul[@role='listbox']")));
                // Also wait for it to be visible
                listBoxWait.until(ExpectedConditions.visibilityOf(listBox));
            } catch (TimeoutException e) {
                System.out.println("Listbox did not appear within timeout period");
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Listbox did not appear after clicking dropdown");
                throw new RuntimeException("Listbox did not appear after clicking class dropdown: " + e.getMessage());
            }
            
            List<WebElement> totalClasses = listBox.findElements(By.tagName("li"));
            System.out.println("Total Classes: " + totalClasses.size());
            TestRunner.getTest().log(Status.INFO, "Total Classes: " + totalClasses.size());
            
            if (totalClasses.isEmpty()) {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed : No classes found in dropdown");
                throw new RuntimeException("No classes found in dropdown listbox");
            }

            boolean classFound = false;
            for (WebElement classElement : totalClasses) {
                String classText = classElement.getText().trim();
                if (classText.equals(specificClasses)) {
                    System.out.println("Selected class: " + specificClasses);
                    TestRunner.getTest().log(Status.INFO, "Found class: " + specificClasses);
                    
                    // Scroll to the class element and click
                    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", classElement);
                    try {
                        classElement.click();
                    } catch (ElementClickInterceptedException e) {
                        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", classElement);
                    }
                    
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed : Selected class: " + specificClasses);
                    classFound = true;
                    break;
                }
            }
            
            if (!classFound) {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Class '" + specificClasses + "' not found in dropdown");
                throw new RuntimeException("Class '" + specificClasses + "' not found in dropdown list");
            }
        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Class dropdown is not visible or enabled.");
            throw new RuntimeException("Class dropdown is not visible or enabled");
        }
    }

    public void CollapseButton()throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "Click On Collapse Button ");
        Thread.sleep(1000);
        WebElement table = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class, 'StudentListingAndTableWrapper')]")));

        List<WebElement> totalCollapseButton= table.findElements(By.xpath(".//span[@class='CollapseArrow collapse ']//span[contains(@class,'MuiTypography-root')]"));
        int numberOfCollapseButtons= totalCollapseButton.size();
        System.out.println("Total Collapse Buttons are:" + numberOfCollapseButtons);
        TestRunner.getTest().log(Status.INFO, "Total Collapse Buttons are:" + numberOfCollapseButtons);

        for (int i = 0; i < numberOfCollapseButtons; i++) {
            List<WebElement> totalCollapseButtons = table.findElements(By.xpath(".//span[@class='CollapseArrow collapse ']//span[contains(@class,'MuiTypography-root')]"));
            WebElement btn_Collapse = totalCollapseButtons.get(i);
            if (btn_Collapse.isEnabled() && btn_Collapse.isDisplayed()) {
                wait.until(ExpectedConditions.elementToBeClickable(btn_Collapse));
                ((JavascriptExecutor) driver).executeScript("arguments[0].click();", btn_Collapse);
                System.out.println("Clicked on the collapse button.");
                TestRunner.getTest().log(Status.PASS, "Test Case passed  :   Collapse button click successfully");
                Thread.sleep(2000);
            } else {
                System.out.println("Collapse button is not clickable.");
            }
        }
    }

    public void searchAssignmentNames(String assignmentName) throws InterruptedException {
        Thread.sleep(2000);
        helper.waitForPageToLoad();
        
        // Wait for table to be ready
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class, 'StudentListingAndTableWrapper')]//table")));
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(@class, 'StudentListingAndTableWrapper')]//table")));

        // Use locators instead of storing WebElement references to avoid stale elements
        By tableLocator = By.xpath("//div[contains(@class, 'StudentListingAndTableWrapper')]");
        By headerLocator = By.xpath(".//thead//tr//th");
        
        // Re-find table and get containers to avoid stale elements
        WebElement assignmentTable = wait.until(ExpectedConditions.visibilityOfElementLocated(tableLocator));
        List<WebElement> assignmentContainers = assignmentTable.findElements(headerLocator);
        System.out.println("Total Assignment Names are: " + assignmentContainers.size());
        TestRunner.getTest().log(Status.INFO, "Total Assignment Names are: " + assignmentContainers.size());

        for (int i = 0; i < assignmentContainers.size(); i++) {
            // Re-find table and containers for each iteration to avoid stale elements
            try {
                assignmentTable = wait.until(ExpectedConditions.visibilityOfElementLocated(tableLocator));
                assignmentContainers = assignmentTable.findElements(headerLocator);
                
                if (i >= assignmentContainers.size()) {
                    System.out.println("Index " + i + " out of bounds, breaking loop");
                    break;
                }
                
                WebElement assignment = assignmentContainers.get(i);
                String assignmentsName = assignment.getText().trim();
                System.out.println("Assignment Name: " + assignmentsName);

                if (assignmentsName.equalsIgnoreCase(assignmentName)) {
                    System.out.println("Found assignment: " + assignmentsName);

                    // Re-find elements before clicking to ensure they're not stale
                    boolean clicked = false;
                    int maxRetries = 3;
                    for (int retry = 0; retry < maxRetries && !clicked; retry++) {
                        try {
                            // Re-find the table element each time to avoid stale reference
                            assignmentTable = wait.until(ExpectedConditions.visibilityOfElementLocated(tableLocator));
                            assignmentContainers = assignmentTable.findElements(headerLocator);
                            
                            if (i >= assignmentContainers.size()) {
                                throw new IndexOutOfBoundsException("Index " + i + " out of bounds after " + assignmentContainers.size() + " elements");
                            }
                            
                            WebElement assignmentElement = assignmentContainers.get(i);
                            
                            // Verify it's still the same assignment
                            String currentName = assignmentElement.getText().trim();
                            if (!currentName.equalsIgnoreCase(assignmentName)) {
                                System.out.println("Assignment name changed, retrying...");
                                Thread.sleep(500);
                                continue;
                            }
                            
                            wait.until(ExpectedConditions.elementToBeClickable(assignmentElement));
                            assignmentElement.click();
                            clicked = true;

                            System.out.println("Assignment found and clicked");
                            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Assignment found successfully " + assignmentsName);

                            // Perform other actions
                            Thread.sleep(2000);
                            clickSummaryButton();
                            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Click on Summary button successfully " + assignmentsName);

                            wait.until(ExpectedConditions.invisibilityOf(progressBar));
                            manualGrading_PF.ClickOnSummaryTab();
                            manualGrading_PF.AssignmentScoresSummary();
                            wait.until(ExpectedConditions.invisibilityOf(progressBar));
                            Thread.sleep(2000);
                            assignmentScoreVerification_PF.PrintAndVerifyStudentScoreWithAssignmentScore();
                            wait.until(ExpectedConditions.invisibilityOf(progressBar));
                            Thread.sleep(2000);
                            assignmentScoreVerification_PF.AssignmentScoresSummaryForVerification();
                            break;
                            
                        } catch (StaleElementReferenceException e) {
                            System.out.println("StaleElementReferenceException on retry " + (retry + 1) + " of " + maxRetries + ": " + e.getMessage());
                            if (retry < maxRetries - 1) {
                                Thread.sleep(500);
                            } else {
                                throw new RuntimeException("Failed to click assignment after " + maxRetries + " retries due to stale elements", e);
                            }
                        } catch (IndexOutOfBoundsException e) {
                            System.out.println("Index out of bounds on retry " + (retry + 1) + ": " + e.getMessage());
                            if (retry < maxRetries - 1) {
                                Thread.sleep(500);
                            } else {
                                throw e;
                            }
                        }
                    }
                    
                    if (!clicked) {
                        TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Could not click assignment after " + maxRetries + " retries");
                        throw new RuntimeException("Failed to click assignment '" + assignmentName + "' after " + maxRetries + " retries");
                    }
                    
                    return; // Successfully found and clicked, exit method
                }
            } catch (StaleElementReferenceException e) {
                System.out.println("StaleElementReferenceException at index " + i + ", continuing to next assignment...");
                // Continue to next iteration
            }
        }
        
        // If we reach here, assignment was not found
        TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Assignment '" + assignmentName + "' not found in the list");
        throw new RuntimeException("Assignment '" + assignmentName + "' not found in the table");
    }

    public void searchAndOpenSpecificAssignment(String assignmentName) throws InterruptedException {
        Thread.sleep(2000);
        WebElement assignmentTable = wait.until(ExpectedConditions.visibilityOf(studentAssignmentTable));

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class, 'StudentListingAndTableWrapper')]//table")));
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(@class, 'StudentListingAndTableWrapper')]//table")));

        List<WebElement> assignmentContainers = assignmentTable.findElements(By.xpath(".//thead//tr//th"));
        System.out.println("Total Assignment Names are: " + assignmentContainers.size());
        TestRunner.getTest().log(Status.INFO, "Total Assignment Names are: " + assignmentContainers.size());

        for (int i = 0; i < assignmentContainers.size(); i++) {
            WebElement assignment = assignmentContainers.get(i);
            String assignmentsName = assignment.getText();
            System.out.println("Assignment Name: " + assignmentsName);

            if (assignmentsName.equalsIgnoreCase(assignmentName)) {
                System.out.println("Found assignment: " + assignmentsName);

                boolean staleElement = true;
                while (staleElement) {
                    try {
                        assignmentContainers = assignmentTable.findElements(By.xpath(".//thead//tr//th"));
                        assignment = assignmentContainers.get(i);

                        wait.until(ExpectedConditions.elementToBeClickable(assignment));
                        assignment.click();
                        staleElement = false;

                        System.out.println("Assignment found");
                        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Assignment found successfully " + assignmentsName);

                        // Perform other actions
                        Thread.sleep(2000);
                        clickSummaryButton();
                        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Click on Summary button successfully " + assignmentsName);
                    } catch (StaleElementReferenceException e) {
                        System.out.println("StaleElementReferenceException occurred. Retrying...");
                        staleElement = true;
                    } catch (NoSuchElementException e) {
                        TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Summary button not found for assignment: " + assignmentName);
                        return;
                    }
                }
                break;
            }
        }
    }

    public void searchAssignmentNamesUpdatedUI(String assignmentName) throws InterruptedException {
        Thread.sleep(2000);
        WebElement assignmentTable = wait.until(ExpectedConditions.visibilityOf(studentAssignmentTable));

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class, 'StudentListingAndTableWrapper')]//table")));
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(@class, 'StudentListingAndTableWrapper')]//table")));

        List<WebElement> assignmentContainers = assignmentTable.findElements(By.xpath(".//thead//tr//th"));
        System.out.println("Total Assignment Names are: " + assignmentContainers.size());
        TestRunner.getTest().log(Status.INFO, "Total Assignment Names are: " + assignmentContainers.size());

        for (int i = 0; i < assignmentContainers.size(); i++) {
            WebElement assignment = assignmentContainers.get(i);
            String assignmentsName = assignment.getText();
            System.out.println("Assignment Name: " + assignmentsName);

            if (assignmentsName.equalsIgnoreCase(assignmentName)) {
                System.out.println("Found assignment: " + assignmentsName);

                boolean staleElement = true;
                while (staleElement) {
                    try {
                        assignmentContainers = assignmentTable.findElements(By.xpath(".//thead//tr//th"));
                        assignment = assignmentContainers.get(i);

                        wait.until(ExpectedConditions.elementToBeClickable(assignment));
                        assignment.click();
                        staleElement = false;

                        System.out.println("Assignment found");
                        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Assignment found successfully " + assignmentsName);

                        // Perform other actions
                        Thread.sleep(2000);
                        clickSummaryButton();
                        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Click on Grade button successfully " + assignmentsName);

                        wait.until(ExpectedConditions.invisibilityOf(progressBar));
                        manualGrading_PF.ClickOnSummaryTabUpdatedUI();
                        manualGrading_PF.AssignmentScoresSummaryUpdatedUI();
                        wait.until(ExpectedConditions.invisibilityOf(progressBar));
                        Thread.sleep(2000);
                        assignmentScoreVerification_PF.PrintAndVerifyStudentScoreWithAssignmentScoreUpdatedUI();
                        wait.until(ExpectedConditions.invisibilityOf(progressBar));
                        Thread.sleep(2000);
                        assignmentScoreVerification_PF.AssignmentScoresSummaryForVerificationUpdatedUI();
                    } catch (StaleElementReferenceException e) {
                        System.out.println("StaleElementReferenceException occurred. Retrying...");
                        staleElement = true;
                    } catch (NoSuchElementException e) {
                        TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Preview(New Design) button not found for assignment: " + assignmentName);
                        return;
                    }
                }
                break;
            }
        }
    }

    public void clickGradeButton() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm in to select Grade Option from Menu");
        System.out.println("Grade button");
        Thread.sleep(2000);

        List<WebElement> listAssignment = driver.findElements(By.xpath("//ul[@role='menu']"));
        System.out.println("I'm in to click on Grade button");

        for (WebElement option : listAssignment) {
            List<WebElement> buttons = option.findElements(By.tagName("button"));

            for (WebElement button : buttons) {
                String buttonText = button.getText().trim();

                if (buttonText.equals("Grade") && button.isEnabled() && button.isDisplayed()) {
                    button.click();
                    System.out.println("Clicked on Grade button.");
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed: Grade Button Click Successfully");
                    return;
                }
            }
        }
    }

    public void clickSummaryButton() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Attempting to click on Summary Tab (Updated UI)");
        try {
            wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Summary']")));
            Thread.sleep(1000);

            if (tab_SummaryUpdatedUI.isDisplayed() && tab_SummaryUpdatedUI.isEnabled()) {
                tab_SummaryUpdatedUI.click();
                Thread.sleep(1000);

                TestRunner.getTest().log(Status.PASS, "Test Case Passed: Successfully clicked on Summary Tab.");
                System.out.println("Successfully clicked on the Summary Tab (Updated UI).");
            } else {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Summary Tab is not clickable.");
                System.out.println("Summary Tab is either not visible or not enabled.");
            }

        } catch (InterruptedException e) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Interrupted Exception occurred while clicking on Summary Tab. " + e.getMessage());
            System.out.println("Interrupted Exception occurred while clicking on the Summary Tab: " + e.getMessage());

        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception occurred while clicking on Summary Tab. " + e.getMessage());
            System.out.println("Exception occurred while clicking on the Summary Tab: " + e.getMessage());
        }
    }


    public void searchAssignmentNameForEdit(String assignmentName) throws InterruptedException {
        WebElement assignmentTable = wait.until(ExpectedConditions.visibilityOf(studentAssignmentTable));

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class, 'StudentListingAndTableWrapper')]//table")));
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(@class, 'StudentListingAndTableWrapper')]//table")));

        List<WebElement> assignmentContainers = assignmentTable.findElements(By.xpath(".//thead//tr//th"));
        System.out.println("Total Assignment Names are: " + assignmentContainers.size());
        TestRunner.getTest().log(Status.INFO, "Total Assignment Names are: " + assignmentContainers.size());

        for (int i = 0; i < assignmentContainers.size(); i++) {
            WebElement assignment = assignmentContainers.get(i);
            String assignmentsName = assignment.getText();
            System.out.println("Assignment Name: " + assignmentsName);

            if (assignmentsName.equalsIgnoreCase(assignmentName)) {
                System.out.println("Found assignment: " + assignmentsName);

                boolean staleElement = true;
                while (staleElement) {
                    try {
                        assignmentContainers = assignmentTable.findElements(By.xpath(".//thead//tr//th"));
                        assignment = assignmentContainers.get(i);

                        wait.until(ExpectedConditions.elementToBeClickable(assignment));
                        assignment.click();
                        staleElement = false;

                        System.out.println("Assignment found");
                        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Assignment found successfully " + assignmentsName);

                        // Perform other actions
                        Thread.sleep(2000);
                        clickEditButton();
                        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Click on Edit button successfully " + assignmentsName);;

                    } catch (StaleElementReferenceException e) {
                        System.out.println("StaleElementReferenceException occurred. Retrying...");
                        staleElement = true;
                    } catch (NoSuchElementException e) {
                        TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Edit button not found for assignment: " + assignmentName);
                        return;
                    }
                }
                break;
            }
        }
    }

    public void clickEditButton() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm in to select Edit Option from Menu");
        System.out.println("Edit button");
        Thread.sleep(2000);

        List<WebElement> listAssignment = driver.findElements(By.xpath("//ul[@role='menu']"));
        System.out.println("I'm in to click on Edit button");

        for (WebElement option : listAssignment) {
            List<WebElement> buttons = option.findElements(By.tagName("button"));

            for (WebElement button : buttons) {
                String buttonText = button.getText().trim();

                if (buttonText.equals("Edit") && button.isEnabled() && button.isDisplayed()) {
                    button.click();
                    System.out.println("Clicked on Edit  button.");
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed: Edit  Button Click Successfully");
                    return;
                }
            }
        }
    }

}
