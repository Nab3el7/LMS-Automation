package pageFactory.Gradebook;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import static pageFactory.Gradebook.SelectedStudent_PF.studentPointsList;

public class GradeBookGradingTab_PF {
    WebDriverWait wait;
    WebDriver driver;
    Helper helper;
    Actions actions;

    @FindBy (xpath = "//span[normalize-space() = 'Grading']")
    WebElement tab_Grading;

//    public static List<Integer> studentPointsList = new ArrayList<>();

    public  GradeBookGradingTab_PF(WebDriver driver){
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        helper = new Helper();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        actions = new Actions(driver);
    }
    @FindBy(xpath = "//div[contains(@class, 'StudentListingAndTableWrapper')]")
    WebElement studentAssignmentTable;

    public void searchAssignmentNamesForSummary(String assignmentName) throws InterruptedException{

        WebElement assignmentTable = wait.until(ExpectedConditions.visibilityOf(studentAssignmentTable));

        List<WebElement> assignmentContainers = assignmentTable.findElements(By.xpath(".//thead//tr//th"));
        System.out.println("Total Assignment Names are: " + assignmentContainers.size());
        TestRunner.getTest().log(Status.INFO, "Total Assignment Names are: " + assignmentContainers.size());

        for (int i = 0; i < assignmentContainers.size(); i++) {
            WebElement assignment = assignmentContainers.get(i);
            String assignmentsName = assignment.getText();
            System.out.println("Assignment Name: " + assignmentsName);

            if (assignmentsName.equalsIgnoreCase(assignmentName)) {
                System.out.println("Found assignment: " + assignmentsName);

                boolean staleElement = true;
                while (staleElement) {
                    try {
                        // Re-locate the assignment element to avoid stale element issues
                        assignmentContainers = assignmentTable.findElements(By.xpath(".//thead//tr//th"));
                        assignment = assignmentContainers.get(i);

                        // Wait until the assignment is clickable
                        wait.until(ExpectedConditions.elementToBeClickable(assignment));
                        assignment.click();
                        staleElement = false; // Break the loop as element is successfully clicked

                        System.out.println("Assignment found");
                        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Assignment found successfully " + assignmentsName);

                        // Perform other actions
                        Thread.sleep(2000);
                        ClickSummaryButton();
                        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Click on Summary button successfully " + assignmentsName);


                    } catch (StaleElementReferenceException e) {
                        System.out.println("StaleElementReferenceException occurred. Retrying...");
                        staleElement = true; // Continue the loop to re-locate and retry
                    } catch (NoSuchElementException e) {
                        TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Summary button not found for assignment: " + assignmentName);
                        return;
                    }
                }
                break; // Exit loop once the desired assignment is found and processed
            }
        }
    }

    public void ClickSummaryButton() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm in to select Summary Option from Menu");
        System.out.println("Summary button");
        Thread.sleep(2000);

        List<WebElement> listAssignment = driver.findElements(By.xpath("//ul[@role='menu']"));
        System.out.println("I'm in to click on Summary button");

        for (WebElement option : listAssignment) {
            List<WebElement> buttons = option.findElements(By.tagName("button"));

            for (WebElement button : buttons) {
                String buttonText = button.getText().trim();

                if (buttonText.equals("Summary") && button.isEnabled() && button.isDisplayed()) {
                    button.click();
                    System.out.println("Clicked on Summary button.");
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed: Summary Button Click Successfully");
                    return;
                }
            }
        }
    }

    public void clickGradingTab() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm to click on Grading Tab");
        System.out.println("I'm to click on Grading Tab");

        if (tab_Grading.isDisplayed()){
            tab_Grading.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed   : Grading Tab is clicked successfully ");
        }else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : Grading Tab option not Display");
        }
    }

    public void VerifyWeightAddStdPoints() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm to Verify Weight/Points And Add New Student Points For VB");
        System.out.println("I'm to Verify Weight/Points And Add New Student Points For VB");

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(60));

        try {
            // Locate the point weight input field
            WebElement pointWeightInput = driver.findElement(By.xpath("(//input[@name='pointWeight '])"));

            // Get the weight value
            int weight = Integer.parseInt(pointWeightInput.getAttribute("value"));
            System.out.println("Point weight: " + weight);
            TestRunner.getTest().log(Status.INFO, "Point weight: " + weight);

            // Locate the student points input field
            WebElement pointsInput = wait.until(ExpectedConditions.elementToBeClickable(
                    By.xpath("(//input[@name='points'])")  // XPath for the student points field
            ));
            pointsInput.click();

            String existingStudentPoint = pointsInput.getAttribute("value");
            System.out.println("Current Student Point: " + existingStudentPoint);
            TestRunner.getTest().log(Status.INFO, "Current Student Point: " + existingStudentPoint);

            // Clear the existing input in the field
            Actions actions = new Actions(driver);
            int length = pointsInput.getAttribute("value").length();
            for (int j = 0; j < length; j++) {
                actions.sendKeys(Keys.BACK_SPACE).perform();
            }
            System.out.println("Cleared the input field");
            TestRunner.getTest().log(Status.INFO, "Cleared the input field");

            // Generate student points <= weight
            int studentPoint = (int) (Math.random() * (weight + 1)); // Ensure points are <= weight
            System.out.println("Generated student point: " + studentPoint);
            TestRunner.getTest().log(Status.INFO, "Generated student point: " + studentPoint);

            // Enter the new student point
            pointsInput.sendKeys(String.valueOf(studentPoint));
            System.out.println("Clear Student Point List");
            studentPointsList.get().clear();

            System.out.println("Add Student Points For VQ");
            studentPointsList.get().add(studentPoint);  // Add point to the list


            System.out.println("Teacher Entered student point: " + studentPoint);
            TestRunner.getTest().log(Status.INFO, "Teacher Entered student point: " + studentPoint);

            // Locate and click the submit button
            WebElement clickSubmit = driver.findElement(By.xpath("//button[@name='btn-submit-applyfilter']"));
            clickSubmit.click();
            System.out.println("Submit button clicked successfully");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Submit button clicked successfully.");

            TestRunner.getTest().log(Status.INFO, "I'm in to get Success Message.");
            System.out.println("Get Success Message");
            getSuccessMessage();

        } catch (NoSuchElementException e) {
            System.out.println("Element not found: " + e.getMessage());
            TestRunner.getTest().log(Status.FAIL, "Test case failed: Element not found - " + e.getMessage());

        } catch (TimeoutException e) {
            System.out.println("Timed out waiting for element: " + e.getMessage());
            TestRunner.getTest().log(Status.FAIL, "Test case failed: Timeout waiting for element - " + e.getMessage());

        } catch (Exception e) {
            System.out.println("An error occurred: " + e.getMessage());
            TestRunner.getTest().log(Status.FAIL, "Test case failed: Unexpected error - " + e.getMessage());
        }
    }

    public void getSuccessMessage() {

        System.out.println("New Student Points: "  +  studentPointsList.get());

        TestRunner.getTest().log(Status.INFO, "New Student Points"  +  studentPointsList.get());

        TestRunner.getTest().log(Status.INFO, "I'm into get the success Message After Points Update by Teacher for VQ");
        System.out.println("I'm into get the success Message After Points Update by Teacher for VQ");
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        WebElement successBox = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//div[contains(@class, 'MuiAlert-message')]")
        ));

        String successMessage = successBox.getText();
        System.out.println("Success message: " + successMessage);

        // Log the success message
        TestRunner.getTest().log(Status.INFO, "Success message: " + successMessage);
    }

    public void VerifyOverAllScore() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm to Verify Sum of all Student Points And Compare it with Overall Score");
        System.out.println("I'm to Verify Sum of all Student Points And Compare it with Overall Score");

        int sum = studentPointsList.get().stream().mapToInt(Integer::intValue).sum();
        System.out.println("Total Sum of All Points That teacher added: " + sum);

        Thread.sleep(2000);
         WebElement scoreElement= driver.findElement(By.xpath("//div[contains(@class, 'over-all-score')][1]//span[1]"));

        String overallScoreText = scoreElement.getText();
        System.out.println("OverAll Score text: " + overallScoreText);
        TestRunner.getTest().log(Status.INFO, "OverAll Score text: " + overallScoreText);

        int overallScore = Integer.parseInt(overallScoreText);

        System.out.println("Overall Score: " + overallScore);
        TestRunner.getTest().log(Status.INFO, "OverAll Score In Selected Student tab is : " + overallScore);

        if (overallScore == sum) {
            System.out.println("The overall score matches. The student Side Points "  + sum + " match with Overall Score in Selected Student tab " + overallScore );
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: The overall score matches. The Score At student Side points "  + sum + " match with Overall Score in Selected Student tab " + overallScore);
        } else {
            System.out.println("The overall score At teacher side does not match with Student side Points.");
            TestRunner.getTest().log(Status.FAIL, "Test case failed: The student Side points "  + sum + " does not match with Overall Score in Selected Student tab Teacher Side " + overallScore);
        }


    }
}

