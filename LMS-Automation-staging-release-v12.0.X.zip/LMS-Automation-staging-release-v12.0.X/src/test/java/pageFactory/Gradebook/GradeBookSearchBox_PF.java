package pageFactory.Gradebook;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;
import java.util.Random;

public class GradeBookSearchBox_PF {
    WebDriverWait wait;
    WebDriver driver;
    Helper helper;
    

    @FindBy(xpath = "//div[contains(@class, 'StudentListingAndTableWrapper')]")
    WebElement studentAssignmentTable;


    @FindBy(xpath = "//span[@role='progressbar']")
    WebElement progressBar;


    public  GradeBookSearchBox_PF(WebDriver driver){
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        helper = new Helper();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
    }

    public void SearchAssessmentByKeyword(String assignmentName) throws InterruptedException {
        WebElement search_box = driver.findElement(By.xpath("//input[@placeholder='Search by name or keyword']"));
        try {
            if (search_box.isDisplayed()) {
                search_box.sendKeys(assignmentName);
                Thread.sleep(3000);
            }
            TestRunner.getTest().log(Status.PASS, "  Assignment Name Search in Search box Successfully ");

        } catch (NoSuchElementException e) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Search box not found on gradeBook Dashboard");
        }
    }

    public void searchAssignmentNames(String assignmentName) throws InterruptedException{
        WebElement assignmentTable = wait.until(ExpectedConditions.visibilityOf(studentAssignmentTable));

        List<WebElement> assignmentContainers = assignmentTable.findElements(By.xpath(".//thead//tr//th"));
        System.out.println("Total Assignment Names are: " + assignmentContainers.size());

        for (WebElement assignment : assignmentContainers) {
            String assignmentsName = assignment.getText();
            System.out.println("Assignment Name: " + assignmentsName);

            if (assignmentsName.equalsIgnoreCase(assignmentName)) {
                System.out.println("Found assignment: " + assignmentsName);
                try {
                    helper.scrollToElement(driver, assignment);
                    Thread.sleep(2000);
                    assignment.click();
                    System.out.println("Assignment found");
                    TestRunner.getTest().log(Status.PASS, " :   Assignment found Successfully " + assignmentsName);
                    
//                    clickGradeButton();
//                    wait.until(ExpectedConditions.invisibilityOf(progressBar));
//                    manualGrading_PF.ClickOnSummaryTab();
//                    manualGrading_PF.AssignmentScoresSummary();
//                    wait.until(ExpectedConditions.invisibilityOf(progressBar));
//                    Thread.sleep(2000);
////                    assignmentScoreVerification_PF.ClickOnScoreViewIntoPoints();
////                    Thread.sleep(2000);
//                    assignmentScoreVerification_PF.PrintAndVerifyStudentScoreWithAssignmentScore();
                } catch (NoSuchElementException e) {
                    System.out.println("Grade button not found for assignment: " + assignmentName);
                    return;
                }
                break;
            } else {
                System.out.println("Assignment not found: " + assignmentName);
            }
        }
    }
}
