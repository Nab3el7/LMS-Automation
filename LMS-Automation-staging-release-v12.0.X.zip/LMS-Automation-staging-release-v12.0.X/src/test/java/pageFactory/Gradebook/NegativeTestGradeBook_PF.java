package pageFactory.Gradebook;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;


public class NegativeTestGradeBook_PF {
    WebDriverWait wait;
    WebDriver driver;
    Helper helper;


    @FindBy(xpath = "//div[contains(@class, 'StudentListingAndTableWrapper')]")
    WebElement studentAssignmentTable;

    public  NegativeTestGradeBook_PF(WebDriver driver){
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        helper = new Helper();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
    }

    public void SearchAssessmentByIncorrectTitle(String assignmentName) throws InterruptedException{
        WebElement search_box = driver.findElement(By.xpath("//input[@placeholder='Search by name or keyword']"));
        try {
            if (search_box.isDisplayed()) {
                search_box.click();
                search_box.sendKeys(assignmentName);
            }
            TestRunner.getTest().log(Status.PASS, "Testcase Passed   : Assignment Name Search in Search box Successfully");


        } catch (NoSuchElementException e) {
            TestRunner.getTest().log(Status.FAIL, "Testcase Failed   : Search box not found on gradeBook Dashboard");

        }
    }

    public void verifyAssignmentPresentInTable() {

        WebElement notFoundBox = driver.findElement(By.xpath("//div[@class='boxListNotFount']"));
        if (notFoundBox.isDisplayed()) {
            String notFoundMessage = notFoundBox.getText();
            String messageColor = notFoundBox.getCssValue("color");

            System.out.println("Message displayed: " + notFoundMessage);
            System.out.println("Message color: " + messageColor);

            Assert.assertTrue("Expected message not displayed.", notFoundMessage.contains("Assessment Not Found"));
            TestRunner.getTest().log(Status.PASS, "Testcase Passed   : 'Assessment Not Found' message is displayed correctly.");
            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());

        } else {
            TestRunner.getTest().log(Status.FAIL, "Testcase Failed   : 'Assessment Not Found' message is not displayed.");
            throw new AssertionError("'Assessment Not Found' message is not displayed.");
        }

    }

    public void GetStudentListAndHandleNotFoundScenario() throws InterruptedException {
        Thread.sleep(3000);

        WebElement searchBar = driver.findElement(By.xpath("//input[@placeholder='Search Student']"));

        if (searchBar.isDisplayed()) {
            String incorrectStudentName = "NonExistent Student";
            searchBar.clear();
            searchBar.click();
            searchBar.sendKeys(incorrectStudentName);
            Thread.sleep(500);

            List<WebElement> listStudent = driver.findElements(By.xpath("//div[contains(@class, 'item undefined')]"));

            boolean isStudentFound = false;

            for (WebElement student : listStudent) {
                String studentName = student.getText().trim();
                System.out.println("Student Name is: " + studentName);

                if (studentName.equals(incorrectStudentName)) {
                    System.out.println("Unexpectedly found student '" + incorrectStudentName + "' in the list.");
                    TestRunner.getTest().log(Status.FAIL, "Testcase Failed   :   Unexpectedly found the student in the list"+  incorrectStudentName);
//                    throw new RuntimeException("Negative Test Failed: Incorrect student '" + incorrectStudentName + "' should not be found.");
                }
            }

            if (!isStudentFound) {
                WebElement noStudentsFoundMessage = driver.findElement(By.xpath("//div[contains(@class, 'StudentsListing')]//span[contains(text(), '0')]"));

                if (noStudentsFoundMessage.isDisplayed()) {
                    String messageText = noStudentsFoundMessage.getText();
                    System.out.println("Displayed message: " + messageText);
                    TestRunner.getTest().log(Status.PASS, "Testcase Passed   :   message is displayed correctly." + messageText);
                    helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());

                } else {
                    TestRunner.getTest().log(Status.FAIL, "Testcase Failed   :  '0 Students Found' message is not displayed.");
//                    throw new RuntimeException("'0 Students Found' message is not displayed.");
                }
            }
        } else {
            TestRunner.getTest().log(Status.FAIL, "Testcase Failed   : Search bar is not displayed");
//            throw new RuntimeException("Search bar is not displayed.");
        }
    }


    public void ApplyFilterButton() throws InterruptedException{
        WebElement applyFilter= driver.findElement(By.xpath("//button[normalize-space()='Apply Filters']"));
        if (applyFilter.isDisplayed() && applyFilter.isEnabled()){
            applyFilter.click();
            TestRunner.getTest().log(Status.PASS, "Testcase Passed   :  Apply Filter button clicked.");

        } else {
            TestRunner.getTest().log(Status.FAIL, "Testcase Failed   :  Apply Filter button is not displayed.");
//            throw new RuntimeException("Apply Filter button is not displayed.");
        }
    }


    public void ClearSearchBox() throws InterruptedException{
        WebElement searchBar = driver.findElement(By.xpath("//input[@placeholder='Search Student']"));
        searchBar.click();
        searchBar.clear();
        TestRunner.getTest().log(Status.PASS, "Testcase Passed   :  Search Box clear Successfully");

    }

    public void EmptyEmailStdModal() throws InterruptedException{
        WebElement usernameField = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@name='userName']")));  // Replace with your actual locator


        String oldName = usernameField.getAttribute("value");
        System.out.println("Old Name: " + oldName);
        Actions actions = new Actions(driver);
        usernameField.click();

        for (int i = 0; i < oldName.length(); i++) {
            actions.sendKeys(Keys.BACK_SPACE).perform();
        }


    }

    public void updateButtonStd() throws InterruptedException{

        WebElement updateBtnStd= driver.findElement(By.xpath("//button[normalize-space()='Update']"));
        if (updateBtnStd.isDisplayed() && updateBtnStd.isEnabled()){
            System.out.println("Test Case Failed  : On  Empty Filed Button should be Disabled but it still it is Enabled");
            TestRunner.getTest().log(Status.FAIL, "Testcase Failed  : On  Empty Filed Button should be Disabled but it still it is Enabled");
//            throw new RuntimeException(" On Empty both Empty Fields Update Button is  still it is Enabled.");
        }
        else {
            TestRunner.getTest().log(Status.PASS, "Testcase Passed   :  Update Button Disabled on Empty Filed");
            System.out.println("Testcase Passed   :  Update Button Disabled on Empty Filed");

        }
    }

    public void EnterEmailForStd() throws InterruptedException{
        WebElement usernameField = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@name='userName']")));
        // Replace with your actual locator
        usernameField.click();
        usernameField.sendKeys("AutoStdNeg@gmail.com");
    }

    public void EnterInvalidEmailAddress() throws InterruptedException{
        WebElement usernameField = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@name='userName']")));
        // Replace with your actual locator
        usernameField.click();
        usernameField.sendKeys("InvalidEmail");

    }

    public void UpdateButtonForFilledEmail(){
        WebElement updateBtnStd= driver.findElement(By.xpath("//button[normalize-space()='Update']"));
        if (updateBtnStd.isDisplayed() && updateBtnStd.isEnabled()){
            System.out.println("Test case Passed   :  Update Button enabled.");
            TestRunner.getTest().log(Status.PASS, "Test case Passed   :  Update Button enabled.");

        }
        else {
            System.out.println("Test case Passed   : Update Button Disabled on Empty Filed");
            TestRunner.getTest().log(Status.FAIL, "Test case Passed   : Update Button Disabled on Empty Filed");
//            throw new RuntimeException(" Update Button Disabled on Filled Filed");


        }
    }

    public void VerifyConfirmPasswordRequiredMessage() throws InterruptedException {
//        Thread.sleep(5000);

        WebElement confirmPasswordField = driver.findElement(By.xpath("//input[@name='stdConfirmPassword']"));

        confirmPasswordField.clear();


        WebElement confirmPasswordErrorMessage = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//p[@id='stdConfirmPassword-helper-text']")));

        if (confirmPasswordErrorMessage.isDisplayed()) {
            String messageText = confirmPasswordErrorMessage.getText();
            System.out.println("Displayed message: " + messageText);
            TestRunner.getTest().log(Status.PASS, "Test case Passed   : message is displayed correctly.");
        } else {
            TestRunner.getTest().log(Status.FAIL, "Test case Failed   : Confirm Password is required' message is not displayed");
//            throw new RuntimeException("'Confirm Password is required' message is not displayed.");
        }
    }

    public void enterConfirmPasswordMisMatch() throws InterruptedException{

//            Thread.sleep(5000);

            WebElement confirmPasswordField = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@name='stdConfirmPassword']")));

            confirmPasswordField.clear();

            Actions actions = new Actions(driver);
            actions.moveToElement(confirmPasswordField).click().sendKeys("Fltester@2").perform();

            System.out.println("Confirm Password added Successfully");

            String confirmPasswordValue = confirmPasswordField.getAttribute("value");
            System.out.println("Confirm Password field value after input: " + confirmPasswordValue);

            if (!"Fltester@2".equals(confirmPasswordValue)) {
                TestRunner.getTest().log(Status.FAIL, "Confirm Password field did not receive the expected value. Actual value: '" + confirmPasswordValue + "'");
//                throw new RuntimeException("Confirm Password field did not receive the expected value. Actual value: '" + confirmPasswordValue + "'");
            }

        TestRunner.getTest().log(Status.PASS, "Test case Passed   : Mismatch Confirm Password enter Click successfully");

    }

    public void clearPasswordField() throws InterruptedException{
        WebElement password = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@name='stdPassword']")));  // Replace with your actual locator


        String oldName = password.getAttribute("value");
        System.out.println("Old Name: " + oldName);
        Actions actions = new Actions(driver);
        password.click();

        for (int i = 0; i < oldName.length(); i++) {
            actions.sendKeys(Keys.BACK_SPACE).perform();
        }

    }

    public void SearchAssessment( String assignmentName) throws InterruptedException{
        WebElement search_box = driver.findElement(By.xpath("//div[contains(@class,'MuiOutlinedInput-root')]//input[@placeholder='Search by name or keyword']"));
        search_box.click();

        try {
            if (search_box.isDisplayed()) {
                search_box.sendKeys(assignmentName);
                TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  Assignment Name  Search in Search box Successfully");
            }

        } catch (NoSuchElementException e) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  Search box not  found on gradeBook Dashboard");

        }
    }

    public void searchAssignmentNames(String assignmentName) throws InterruptedException{
        WebElement assignmentTable = wait.until(ExpectedConditions.visibilityOf(studentAssignmentTable));

        List<WebElement> assignmentContainers = assignmentTable.findElements(By.xpath(".//thead//tr//th"));
        System.out.println("Total Assignment Names are: " + assignmentContainers.size());
        TestRunner.getTest().log(Status.INFO, "Total Assignment Names are :"+ assignmentContainers.size());


        for (WebElement assignment : assignmentContainers) {
            String assignmentsName = assignment.getText();
            System.out.println("Assignment Name: " + assignmentsName);

            if (assignmentsName.equalsIgnoreCase(assignmentName)) {
                System.out.println("Found assignment: " + assignmentsName);

                try {
//                    helper.scrollToElement(driver, assignment);
                    Thread.sleep(2000);
                    assignment.click();
                    System.out.println("Assignment found");
                    TestRunner.getTest().log(Status.INFO, "Assignment found Successfully " + assignmentsName);

                    clickGradeButton();
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  Grade button click successfully");

                } catch (NoSuchElementException e) {
                    System.out.println("Grade button not found for assignment: " + assignmentName);
                    return;
                }
                break;
            } else {
                System.out.println("Assignment not found: " + assignmentName);
            }
        }
    }

    private void clickGradeButton() throws InterruptedException {
        Thread.sleep(2000);
        List<WebElement> listAssignment = driver.findElements(By.xpath("//ul[@role='menu']"));

        for (WebElement option : listAssignment) {
            List<WebElement> buttons = option.findElements(By.tagName("button"));

            for (WebElement button : buttons) {
                String buttonText = button.getText().trim();

                if (buttonText.equals("Grade") && button.isEnabled() && button.isDisplayed()) {
                    button.click();
                    System.out.println("Clicked on Grade button.");
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  Grade button click successfully");

                    return;
                }
            }
        }
    }

}
