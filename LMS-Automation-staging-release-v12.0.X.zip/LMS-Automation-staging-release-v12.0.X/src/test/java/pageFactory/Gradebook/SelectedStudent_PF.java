package pageFactory.Gradebook;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.Point;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Assignmment.AnnotationAnswerExecutor_PF;
import pageFactory.Assignmment.CorrectAnswerExecutor_PF;
import org.openqa.selenium.ElementNotInteractableException;

import java.time.Duration;
import java.util.*;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

import static pageFactory.Assignmment.CorrectAnswerExecutor_PF.addedNotes;
import static pageFactory.Assignmment.ReleaseAssignment_PF.referenceArray;
import static pageFactory.Gradebook.AssignmentScoreVerification_PF.totalScore;

public class SelectedStudent_PF {
    WebDriverWait wait;
    WebDriver driver;
    Helper helper;
    Actions actions;
    CorrectAnswerExecutor_PF correctAnswerExecutor_pf;
    AnnotationAnswerExecutor_PF annotationAnswerExecutorPf;

    public static List<String> generatedComments = new ArrayList<>();
    public static ThreadLocal<List<String>> attemptedQuestionTypes = ThreadLocal.withInitial(ArrayList::new);
    public static ThreadLocal<List<String>> savedNotes = ThreadLocal.withInitial(ArrayList::new);

    private final String[] comments = {
            "Well done",
            "Needs improvement",
            "Excellent effort",
            "Good job on this one",
            "Please review this concept again",
            "You can do better next time",
            "Solid understanding",
            "Try solving similar problems",
            "Keep practicing",
            "Focus on the basics"
    };

    @FindBy(xpath = "//span[normalize-space()='Selected Student']")
    WebElement selected_student;

    @FindBy(xpath = "//div[contains(@class, 'over-all-score')]//input")
    WebElement markAsGradedCheckbox;

    @FindBy(xpath = "//nav[@aria-label='pagination navigation']")
    WebElement nav_Pagination;

    @FindBy(xpath = "(//input[@role='button' or @role='combobox']/parent::div)[2]")
    WebElement dropDown_AssignmentQuestions;

    @FindBy(xpath = "(//input[@role='button' or @role='combobox']/parent::div)[2]/following::div[1]")
    WebElement btn_AssignmentQuestionsDropDownNext;

    @FindBy(xpath = "//div[@aria-labelledby='customized-dialog-title']")
    WebElement customizedDialogTitle;

    @FindBy(xpath = "//button[@aria-label='Go to next page']")
    WebElement btn_NavNextPage;

    @FindBy(xpath = "//span[@role='progressbar']")
    WebElement loader;

    // Replace static variables with ThreadLocal
    public static ThreadLocal<Integer> temp = ThreadLocal.withInitial(() -> 0);
    public static ThreadLocal<List<Integer>> studentPointsList = ThreadLocal.withInitial(ArrayList::new);
    public static ThreadLocal<String> storedFinalScore = ThreadLocal.withInitial(() -> null);
    public static ThreadLocal<String> StudentFinalScoreUpdate = ThreadLocal.withInitial(() -> null);


    @FindBy(xpath = "//div[@role='dialog']")
    WebElement updated_score;
    String questionID = null;

    public SelectedStudent_PF(WebDriver driver) {
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        helper = new Helper();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        actions = new Actions(driver);
        correctAnswerExecutor_pf = new CorrectAnswerExecutor_PF(driver);
        annotationAnswerExecutorPf = new AnnotationAnswerExecutor_PF(driver);

    }

    /**
     * Safe click method that handles click interception permanently
     * Waits for overlays to disappear, scrolls element into view, and uses multiple click strategies
     */
    private void safeClickElement(WebElement element, String elementName) throws InterruptedException {
        try {
            // Step 1: Wait for any overlays/backdrops to disappear
            try {
                wait.until(ExpectedConditions.invisibilityOfElementLocated(By.className("MuiBackdrop-root")));
            } catch (Exception e) {
                // If no backdrop found, continue
            }
            
            // Step 2: Wait for any dialogs to close
            try {
                List<WebElement> openDialogs = driver.findElements(By.xpath("//div[@role='dialog'][@aria-labelledby='customized-dialog-title']"));
                for (WebElement dialog : openDialogs) {
                    if (dialog.isDisplayed()) {
                        wait.until(ExpectedConditions.invisibilityOf(dialog));
                    }
                }
            } catch (Exception e) {
                // If no dialog found, continue
            }
            
            Thread.sleep(300); // Small wait for any animations
            
            // Step 3: Refresh element reference to avoid stale element
            WebElement freshElement = element;
            try {
                // Try to verify element is still valid
                freshElement.isDisplayed();
            } catch (StaleElementReferenceException e) {
                // If stale, re-locate using the same xpath pattern
                freshElement = wait.until(ExpectedConditions.presenceOfElementLocated(
                        By.xpath("(//input[@role='button' or @role='combobox']/parent::div)[2]/following::div[1]")));
            }
            
            // Step 4: Scroll element into view
            helper.scrollToElement(driver, freshElement);
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center', behavior:'smooth'});", freshElement);
            Thread.sleep(500);
            
            // Step 5: Wait for element to be clickable
            wait.until(ExpectedConditions.elementToBeClickable(freshElement));
            
            // Step 6: Try multiple click strategies
            try {
                // Strategy 1: Normal click
                freshElement.click();
                System.out.println("✅ " + elementName + " clicked successfully (normal click)");
                TestRunner.getTest().log(Status.PASS, elementName + " clicked successfully");
            } catch (ElementClickInterceptedException e) {
                // Strategy 2: JavaScript click
                try {
                    ((JavascriptExecutor) driver).executeScript("arguments[0].click();", freshElement);
                    System.out.println("✅ " + elementName + " clicked successfully (JavaScript click)");
                    TestRunner.getTest().log(Status.PASS, elementName + " clicked successfully (JavaScript)");
                } catch (Exception jsException) {
                    // Strategy 3: Click via Actions
                    try {
                        actions.moveToElement(freshElement).click().perform();
                        System.out.println("✅ " + elementName + " clicked successfully (Actions click)");
                        TestRunner.getTest().log(Status.PASS, elementName + " clicked successfully (Actions)");
                    } catch (Exception actionsException) {
                        // Strategy 4: Force click via JavaScript with event dispatch
                        ((JavascriptExecutor) driver).executeScript(
                            "var element = arguments[0]; " +
                            "var event = new MouseEvent('click', { " +
                            "  view: window, " +
                            "  bubbles: true, " +
                            "  cancelable: true " +
                            "}); " +
                            "element.dispatchEvent(event);", freshElement);
                        System.out.println("✅ " + elementName + " clicked successfully (force JavaScript click)");
                        TestRunner.getTest().log(Status.PASS, elementName + " clicked successfully (force JavaScript)");
                    }
                }
            }
        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "Failed to click " + elementName + ": " + e.getMessage());
            System.out.println("❌ Error clicking " + elementName + ": " + e.getMessage());
            throw e;
        }
    }


    public void clickSelectedStudent() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm to click in Selected Student");
        if (selected_student.isDisplayed()) {
            selected_student.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed   : Selected Student tab is clicked successfully ");
        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : Selected Student tab option not Display");
        }
    }

    public void MarkAsGradedCheckbox() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm to Uncheck Mark As Graded Checkbox");

        Thread.sleep(3000);
        if (markAsGradedCheckbox.isSelected()) {
            markAsGradedCheckbox.click();
            System.out.println("Checkbox 'Mark as Graded' is unchecked.");
            TestRunner.getTest().log(Status.PASS, "Test case Passed: Checkbox 'Mark as Graded' is unchecked.");
        } else {
            System.out.println("Checkbox 'Mark as Graded' is already unchecked.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Checkbox 'Mark as Graded' is already unchecked.");
        }
    }

    public void StudentPoints() throws InterruptedException {
        if (!isPaginationDisplayed()) {
//            studentExecutor.AssignmentSubmitAsCompleted();
            return;
        }

//        try {
        List<WebElement> questionButtons = nav_Pagination.findElements(By.xpath("//button[contains(@aria-label, 'Go to page')]"));

        for (WebElement questionButton : questionButtons) {
            String questionText = questionButton.getText();
            System.out.println("Question: " + questionText);
            TestRunner.getTest().log(Status.INFO, "Total Questions: " + questionText);
        }
        System.out.println("I'm here to clear Student Point list");
        studentPointsList.get().clear();
//            studentPointsList.get().add(studentPoint);
        System.out.println("Student Point List :" + studentPointsList.get());

        TestRunner.startTest("Attempt assignment At Teacher Side in Selected Student Tab");
        while (btn_NavNextPage.isEnabled()) {
            Thread.sleep(2000);
            VerifyQuestionsInSelectedStudentTab();
            enterStudentPointsAndSubmit();
            Thread.sleep(2000);
            helper.scrollToElement(driver, btn_NavNextPage);
            Thread.sleep(2000);
            btn_NavNextPage.click();
            Thread.sleep(2000);
        }
        enterStudentPointsAndSubmit();

        System.out.println("New Student Points: " + studentPointsList);

        TestRunner.getTest().log(Status.INFO, "New Student Points" + studentPointsList);

        System.out.println("New Points Added for Student Successfully ");
        TestRunner.getTest().log(Status.PASS, "Test Case Passed: New Points Added for Student Successfully");
//            studentExecutor.AssignmentSubmitAsCompleted();
//        } catch (NoSuchElementException | ElementNotInteractableException | TimeoutException e) {
//            System.out.println("No Question found.");
//            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : No Question found or Question not visible");
//        }
    }

    public void StudentPointsAndCommentsInVerticalView() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Verifying the assignment vertical view in gradebook");
        try {
            studentPointsList.get().clear();
            System.out.println("Student Point List :" + studentPointsList);

            validateQuestionsInVerticalViewWithPagination();
            enterCommentsForEachQuestionInVerticalViewAndSubmit();

            System.out.println("New Student Points: " + studentPointsList.get());

            TestRunner.getTest().log(Status.INFO, "New Student Points" + studentPointsList.get());

            System.out.println("New points added for student in vertical view");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed : New Points Added for Student in Vertical View Successfully");
        } catch (NoSuchElementException | ElementNotInteractableException | TimeoutException e) {
            System.out.println("No Question found.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : No Question found or Question not visible");
        }
    }

    public void enterCommentsForEachQuestionInVerticalViewAndSubmit() {
        TestRunner.getTest().log(Status.INFO, "Entering student Points and Comments for each question in Vertical View and submitting");

        try {
            // Click on Vertical View checkbox if it's not already selected
            WebElement checkBoxIncludeGradesComments = driver.findElement(By.xpath("//div[contains(@class, 'verticalViewContainer')][2]//input"));
            if (!checkBoxIncludeGradesComments.isSelected()) {
                checkBoxIncludeGradesComments.click();
                TestRunner.getTest().log(Status.PASS, "Include Grades/Comments checkbox clicked successfully");
            }

            // Switch to the iframe where questions are displayed
            WebElement questionPlayer = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("lesson-player-ifram")));
            driver.switchTo().frame(questionPlayer);

            // Wait for the questions to load and retrieve the questions
            WebElement QuestionBody = driver.findElement(By.xpath("//div[contains(@class, 'LessonPlayerRoot')]"));
            List<WebElement> verticalViewQuestions = QuestionBody.findElements(By.xpath("//div[contains(@class, 'planComponentQuestion')]"));
            wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("(//span[normalize-space()='Grade Assignment:'])[2]")));

            // Iterate over all the questions in vertical view
            for (WebElement verticalViewQuestion : verticalViewQuestions) {
                WebElement QuestionPlayer = verticalViewQuestion.findElement(By.xpath(".//div[contains(@class, 'QuestionPlayer')]"));
                WebElement questionRoot = QuestionPlayer.findElement(By.xpath(".//div[contains(@class, 'question-root')]"));

                try {
                    // Add points in vertical view
                    TestRunner.getTest().log(Status.INFO, "Entering student points for question");
                    System.out.println("Entering student points for question");

                    WebElement pointWeightInput = questionRoot.findElement(By.xpath(".//input[contains(@name, 'pointWeight')]"));
                    helper.scrollToElement(driver, pointWeightInput);

                    int weight = Integer.parseInt(pointWeightInput.getAttribute("value"));
                    System.out.println("Point weight: " + weight);
                    TestRunner.getTest().log(Status.INFO, "Point weight: " + weight);

                    // Get the points input for the question
                    WebElement pointsInput = questionRoot.findElement(By.xpath(".//input[@name='points']"));
                    pointsInput.click();

                    String existingStudentPoint = pointsInput.getAttribute("value");
                    System.out.println("Current Student Point: " + existingStudentPoint);
                    TestRunner.getTest().log(Status.INFO, "Current Student Point: " + existingStudentPoint);

                    // Clear the input field for points
                    int length = pointsInput.getAttribute("value").length();
                    for (int j = 0; j < length; j++) {
                        actions.sendKeys(Keys.BACK_SPACE).perform();
                    }
                    System.out.println("Cleared the input field");
                    TestRunner.getTest().log(Status.INFO, "Cleared the input field");

                    // Ensure points are <= weight
                    int studentPoint = (int) (Math.random() * (weight + 1));
                    System.out.println("Generated student point: " + studentPoint);
                    TestRunner.getTest().log(Status.INFO, "Generated student point: " + studentPoint);

                    pointsInput.sendKeys(String.valueOf(studentPoint));

                    // Add point to the list (for logging or further validation if needed)
                    studentPointsList.get().add(studentPoint);
                    System.out.println("Teacher Entered student point: " + studentPoint);
                    TestRunner.getTest().log(Status.INFO, "Teacher Entered student point: " + studentPoint);

                    // Add comments for each question
                    TestRunner.getTest().log(Status.INFO, "Entering student comments for question");
                    System.out.println("Entering student comments for question");

                    WebElement commentInput = questionRoot.findElement(By.xpath(".//input[@name='comments']"));
                    commentInput.click();

                    String existingStudentComment = commentInput.getAttribute("value");

                    // Clear existing comment if present
                    while (!existingStudentComment.isEmpty()) {
                        commentInput.sendKeys(Keys.BACK_SPACE);
                        existingStudentComment = commentInput.getAttribute("value");
                    }

                    System.out.println("Cleared the input field");
                    TestRunner.getTest().log(Status.INFO, "Cleared the input field");

                    // Generate random comment from predefined list
                    String teacherComment = comments[(int) (Math.random() * comments.length)];
                    System.out.println("Generated Teacher Comment: " + teacherComment);
                    TestRunner.getTest().log(Status.INFO, "Generated Teacher Comment: " + teacherComment);

                    commentInput.sendKeys(teacherComment);

                    // Add the comment to the list
                    generatedComments.add(teacherComment);
                    System.out.println("Teacher Entered Comments: " + teacherComment);
                    TestRunner.getTest().log(Status.INFO, "Teacher Entered Comments: " + teacherComment);

                    // Submit the question after entering points and comments
                    WebElement clickSubmit = questionRoot.findElement(By.xpath(".//button[@name='btn-submit-applyfilter']"));
                    clickSubmit.click();
                    System.out.println("Submit button clicked successfully");
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed: Submit button clicked successfully.");

                    // Log the success message
                    TestRunner.getTest().log(Status.INFO, "Get Success Message.");
                    System.out.println("Get Success Message");
                    getSuccessMessageInVerticalView();
                    Thread.sleep(1000);

                } catch (NoSuchElementException e) {
                    System.out.println("Content Type Question Has No Grade Assignment Points");
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed: Content Type Question Has No Grade Assignment Points");
                    helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());

                } catch (TimeoutException e) {
                    System.out.println("Timed out waiting for element: " + e.getMessage());
                    TestRunner.getTest().log(Status.FAIL, "Test case failed: Timeout waiting for element - " + e.getMessage());

                } catch (Exception e) {
                    System.out.println("An error occurred: " + e.getMessage());
                    TestRunner.getTest().log(Status.FAIL, "Test case failed: Unexpected error - " + e.getMessage());
                }
            }
        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "Failed to enter points and comments for all questions.");
            e.printStackTrace();
        } finally {
            driver.switchTo().defaultContent();
        }
    }

    public void validateQuestionsInVerticalViewWithPagination() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Validate the total number of questions from pagination and in vertical view");

        List<String> paginationQuestionIds = new ArrayList<>();
        List<String> verticalViewQuestionIds = new ArrayList<>();
        List<String> verticalViewQuestionsData = new ArrayList<>();

        try {
//            if (!isPaginationDisplayed()) {
//                TestRunner.getTest().log(Status.INFO, "Pagination is not displayed.");
//                return;
//            }
//
//            List<WebElement> pageButtons = driver.findElements(By.xpath(
//                    "//ul[contains(@class,'MuiPagination-ul')]/li/button[not(@aria-label='Go to previous page') and not(@aria-label='Go to next page')]"
//            ));
//            int totalPages = pageButtons.size();
//            TestRunner.getTest().log(Status.INFO, "Total pages (pagination): " + totalPages);
//
//            for (int i = 1; i <= totalPages; i++) {
//                helper.scrollToElement(driver, nav_Pagination);
//                WebElement pageBtn = driver.findElement(By.xpath("//ul[contains(@class,'MuiPagination-ul')]/li/button[text()='" + i + "']"));
//                pageBtn.click();
//                wait.until(ExpectedConditions.invisibilityOf(loader));
//                Thread.sleep(1000);
//
//                // Switch into iframe for pagination page
//                WebElement iframe = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("lesson-player-ifram")));
//                driver.switchTo().frame(iframe);
//
//                WebElement QuestionBody = driver.findElement(By.xpath("//div[contains(@class, 'LessonPlayerRoot')]"));
//                List<WebElement> paginationQuestions = QuestionBody.findElements(By.xpath("//div[contains(@class, 'planComponentQuestion')]"));
//                for (WebElement paginationQuestion : paginationQuestions) {
//                    WebElement QuestionPlayer = paginationQuestion.findElement(By.xpath(".//div[contains(@class, 'QuestionPlayer')]"));
//                    WebElement questionRoot = QuestionPlayer.findElement(By.xpath(".//div[contains(@class, 'question-root')]"));
//                    String qId = questionRoot.getAttribute("data-question-id");
//                    paginationQuestionIds.add(qId);
//                }
//
//                driver.switchTo().defaultContent();
//            }
//
//            TestRunner.getTest().log(Status.INFO, "Collected " + paginationQuestionIds.size() + " question IDs from pagination view.");
//            TestRunner.getTest().log(Status.INFO, "Collected question IDs from pagination view. " + paginationQuestionIds);

            // Click on Vertical View checkbox
            WebElement checkBoxVerticalView = driver.findElement(By.xpath("//input[@value='verticalView']"));
            if (!checkBoxVerticalView.isSelected()) {
                checkBoxVerticalView.click();
                TestRunner.getTest().log(Status.PASS, "Vertical view checkbox clicked successfully");
            }
            wait.until(ExpectedConditions.invisibilityOf(loader));

            WebElement questionPlayer = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("lesson-player-ifram")));
            driver.switchTo().frame(questionPlayer);

            WebElement QuestionBody = driver.findElement(By.xpath("//div[contains(@class, 'LessonPlayerRoot')]"));
            List<WebElement> verticalViewQuestions = QuestionBody.findElements(By.xpath("//div[contains(@class, 'planComponentQuestion')]"));

            for (WebElement verticalViewQuestion : verticalViewQuestions) {
                WebElement QuestionPlayer = verticalViewQuestion.findElement(By.xpath(".//div[contains(@class, 'QuestionPlayer')]"));
                WebElement questionRoot = QuestionPlayer.findElement(By.xpath(".//div[contains(@class, 'question-root')]"));
                String questionID = questionRoot.getAttribute("data-question-id");
                verticalViewQuestionIds.add(questionID);
                String questionType = QuestionPlayer.getAttribute("data-type");
                verticalViewQuestionsData.add(questionType);
            }

            TestRunner.getTest().log(Status.INFO, "Collected " + verticalViewQuestionIds.size() + " question IDs from vertical view.");
            TestRunner.getTest().log(Status.INFO, "Collected question IDs from vertical view. " + verticalViewQuestionIds);
            TestRunner.getTest().log(Status.INFO, "Collected question data types from vertical view. " + verticalViewQuestionsData);

//            Set<String> paginationSet = new HashSet<>(paginationQuestionIds);
            Set<String> verticalViewSet = new HashSet<>(verticalViewQuestionIds);

//            if (paginationSet.equals(verticalViewSet)) {
//                System.out.println("Question IDs match between pagination and vertical view.");
//                TestRunner.getTest().log(Status.PASS, "Question IDs match between pagination and vertical view.");
//            } else {
//                System.out.println("Mismatch in question IDs!");
//                TestRunner.getTest().log(Status.FAIL, "Mismatch in question IDs between pagination and vertical view.");
//            }

//            if (paginationQuestionIds.size() == verticalViewQuestionIds.size()) {
//                TestRunner.getTest().log(Status.PASS, "The total number of questions match between pagination and vertical view.");
//            } else {
//                TestRunner.getTest().log(Status.FAIL, "Mismatch in the total number of questions between pagination and vertical view.");
//            }
//
//            boolean isSequenceValid = true;
//            for (int i = 0; i < paginationQuestionIds.size(); i++) {
//                if (!paginationQuestionIds.get(i).equals(verticalViewQuestionIds.get(i))) {
//                    isSequenceValid = false;
//                    TestRunner.getTest().log(Status.FAIL, "Mismatch in question sequence at index: " + i);
//                    break;
//                }
//            }
//
//            if (isSequenceValid) {
//                TestRunner.getTest().log(Status.PASS, "The sequence of question IDs match between pagination and vertical view.");
//            } else {
//                TestRunner.getTest().log(Status.FAIL, "Mismatch in question sequence between pagination and vertical view.");
//            }

        } catch (Exception e) {
            e.printStackTrace();
            TestRunner.getTest().log(Status.FAIL, "Exception occurred: " + e.getMessage());
        } finally {
            driver.switchTo().defaultContent();
        }
    }

    public void checkShowsCorrectAnswersOfQuestion() {
        TestRunner.getTest().log(Status.INFO, "Check shows correct answer of each question");

        try {
            WebElement btnShowAnswers = driver.findElement(By.xpath("//div[@class='button-group otherToolBtn']//div[@role='group']//span[normalize-space()='Show Answers']/parent::button"));

            String classBeforeClick = btnShowAnswers.getAttribute("class");
            TestRunner.getTest().log(Status.INFO, "Class before click: " + classBeforeClick);

            if (classBeforeClick.contains("inactive-tool")) {
                btnShowAnswers.click();
                TestRunner.getTest().log(Status.PASS, "Show Answers button clicked successfully");
                Thread.sleep(1000);

                String classAfterClick = btnShowAnswers.getAttribute("class");
                TestRunner.getTest().log(Status.INFO, "Class after click: " + classAfterClick);

                if (classAfterClick.contains("active-tool")) {
                    TestRunner.getTest().log(Status.PASS, "'Show Answers' button is now active.");

                    WebElement questionPlayerIFrame = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("lesson-player-ifram")));
                    driver.switchTo().frame(questionPlayerIFrame);

                    WebElement QuestionBody = driver.findElement(By.xpath("//div[contains(@class, 'LessonPlayerRoot')]"));
                    wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//div[contains(@class, 'planComponentQuestion')]")));

                    List<WebElement> questionRoots = QuestionBody.findElements(By.xpath("//div[contains(@class, 'planComponentQuestion')]//div[contains(@class, 'QuestionPlayer')]//div[contains(@class, 'question-root')]"));
                    TestRunner.getTest().log(Status.INFO, "Total questions: " + questionRoots.size());
                    System.out.println("Total questions: " + questionRoots.size());

                    for (WebElement questionRoot : questionRoots) {
                        try {
                            String questionClass = questionRoot.getAttribute("class");
                            TestRunner.getTest().log(Status.INFO, "Question class: " + questionClass);

                            if (questionClass.contains("showAnswer")) {
                                TestRunner.getTest().log(Status.PASS, "Show answer is correctly visible for this question.");
                                System.out.println("Show answer is visible for this question.");
                            } else {
                                TestRunner.getTest().log(Status.FAIL, "Show answer is NOT visible for this question.");
                                System.out.println("Show answer is NOT visible for this question.");
                            }

                        } catch (NoSuchElementException e) {
                            System.out.println("Question Has No Correct Answers Options");
                            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Question Has No Grade Assignment Points");
                            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());

                        } catch (TimeoutException e) {
                            TestRunner.getTest().log(Status.FAIL, "Timeout waiting for element - " + e.getMessage());

                        } catch (Exception e) {
                            TestRunner.getTest().log(Status.FAIL, "Unexpected error - " + e.getMessage());
                        }
                    }
                    driver.switchTo().defaultContent();
                } else {
                    TestRunner.getTest().log(Status.FAIL, "Button did not switch to active state after click.");
                }
            } else {
                TestRunner.getTest().log(Status.INFO, "Show Answers button is already active.");
            }
        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "Failed to check or click Show Answers button.");
            e.printStackTrace();
        }
    }

    public void checkShowsCorrectAnswersOfQuestionInPagination() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Check shows correct answer of each question in pagination");

        List<WebElement> questionButtons = nav_Pagination.findElements(By.xpath("//button[contains(@aria-label, 'Go to page')]"));
        for (WebElement questionButton : questionButtons) {
            String questionText = questionButton.getText();
            System.out.println("Question: " + questionText);
            TestRunner.getTest().log(Status.INFO, "Total Questions: " + questionText);
        }

        // Wait for Show Answer button to be present and clickable
        WebElement btnShowAnswers;
        try {
            btnShowAnswers = wait.until(ExpectedConditions.elementToBeClickable(
                    By.xpath("//button[@id='showAnswer-btn']")));
        } catch (TimeoutException e) {
            // Try alternative locator by aria-label
            try {
                btnShowAnswers = wait.until(ExpectedConditions.elementToBeClickable(
                        By.xpath("//button[@aria-label='Show Correct Answer']")));
            } catch (TimeoutException e2) {
                // Try by class name
                btnShowAnswers = wait.until(ExpectedConditions.elementToBeClickable(
                        By.xpath("//div[contains(@class,'showAnswer-button')]//button")));
            }
        }
        
        // Use safe click method to handle any interception
        safeClickElement(btnShowAnswers, "Show Answer button");
        TestRunner.getTest().log(Status.INFO, "Shows Answer button clicked successfully");

        while (btn_NavNextPage.isEnabled()) {
            Thread.sleep(2000);
            try {
                WebElement questionPlayerIFrame = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("lesson-player-ifram")));
                driver.switchTo().frame(questionPlayerIFrame);

                WebElement QuestionBody = driver.findElement(By.xpath("//div[contains(@class, 'LessonPlayerRoot')]"));
                wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//div[contains(@class, 'planComponentQuestion')]")));

                WebElement QuestionPlayer = driver.findElement(By.xpath("//div[contains(@class, 'planComponentQuestion')]//div[contains(@class, 'QuestionPlayer')]"));

                System.out.println("Question is found");
                String questionType = QuestionPlayer.getAttribute("data-type");
                System.out.println("Question Type is: " + questionType);
                TestRunner.getTest().log(Status.INFO, "Attempted question type is: " + questionType);

                attemptedQuestionTypes.get().add(questionType);

                List<WebElement> questionRoots = QuestionBody.findElements(By.xpath("//div[contains(@class, 'planComponentQuestion')]//div[contains(@class, 'QuestionPlayer')]//div[contains(@class, 'question-root')]"));
                TestRunner.getTest().log(Status.INFO, "Total questions: " + questionRoots.size());
                System.out.println("Total questions: " + questionRoots.size());

                for (WebElement questionRoot : questionRoots) {
                    try {
                        String questionClass = questionRoot.getAttribute("class");
                        TestRunner.getTest().log(Status.INFO, "Question class: " + questionClass);

                        if (questionClass.contains("showAnswer")) {
                            TestRunner.getTest().log(Status.PASS, "Show answer is correctly visible for this question.");
                            System.out.println("Show answer is visible for this question.");
                        } else {
                            TestRunner.getTest().log(Status.FAIL, "Show answer is NOT visible for this question.");
                            System.out.println("Show answer is NOT visible for this question.");
                        }

                    } catch (NoSuchElementException e) {
                        System.out.println("Question Has No Correct Answers Options");
                        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Question Has No Grade Assignment Points");
                        helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());

                    } catch (TimeoutException e) {
                        TestRunner.getTest().log(Status.FAIL, "Timeout waiting for element - " + e.getMessage());

                    } catch (Exception e) {
                        TestRunner.getTest().log(Status.FAIL, "Unexpected error - " + e.getMessage());
                    }
                }
                driver.switchTo().defaultContent();
            } catch (Exception e) {
                TestRunner.getTest().log(Status.FAIL, "Failed to check or click Show Answers button.");
                e.printStackTrace();
            }
            Thread.sleep(2000);
            helper.scrollToElement(driver, btn_NavNextPage);
            Thread.sleep(2000);
            btn_NavNextPage.click();
            Thread.sleep(2000);
        }

        System.out.println("Attempted Question Types: " + attemptedQuestionTypes.get());
        TestRunner.getTest().log(Status.INFO, "Attempted Question Types: " + attemptedQuestionTypes.get());
    }

//    public void updateGradesOfEachQuestionAndShowsCorrectAnswers() throws InterruptedException {
//        TestRunner.getTest().log(Status.INFO, "Update Grades of Each Question and Shows correct Answers");
//
//        if (dropDown_AssignmentQuestions.isEnabled()) {
//            dropDown_AssignmentQuestions.click();
//            Thread.sleep(2000);
//            System.out.println("Questions dropdown clicked");
//            TestRunner.getTest().log(Status.PASS, "TestCase Passed : Questions dropdown clicked successfully");
//
//            wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//ul[@role='listbox']//li")));
//
//            List<WebElement> listQuestions = driver.findElements(By.xpath("//ul[@role='listbox']//li"));
//            System.out.println("Total status options: " + listQuestions.size());
//
//            for (WebElement selectedQuestion : listQuestions) {
//                String selectedQuestionText = selectedQuestion.getText().trim();
//                System.out.println("Assignment Question: " + selectedQuestionText);
//                TestRunner.getTest().log(Status.INFO, "Assignment Question: " + selectedQuestionText);
//            }
//
////            boolean isButtonEnable = true;
//            int totalQuestions = listQuestions.size();
//            int processedQuestions = 0;
//
//            while (processedQuestions < totalQuestions) {
//                WebElement nextButton = driver.findElement(By.xpath("(//input[@role='button' or @role='combobox']/parent::div)[2]/following::div[1]"));
//                boolean isNextEnabled = nextButton.isEnabled() && !nextButton.getAttribute("class").contains("disabled");
//
//                if (!isNextEnabled) {
//                    TestRunner.getTest().log(Status.INFO, "Next button is disabled or not available. Stopping loop.");
//                    break;
//                }
//                Thread.sleep(2000);
////                WebElement btnShowAnswers = driver.findElement(By.xpath("//div[contains(@class,'showAnswer-button')]//button"));
////
////                btnShowAnswers.click();
////                TestRunner.getTest().log(Status.INFO, "Shows Answer button clicked successfully");
//
////                Thread.sleep(5000);
//              //  try {
////                    WebElement questionPlayerIFrame = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("lesson-player-ifram")));
////                    driver.switchTo().frame(questionPlayerIFrame);
////
////                    WebElement QuestionBody = driver.findElement(By.xpath("//div[contains(@class, 'LessonPlayerRoot')]"));
////                    wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//div[contains(@class, 'planComponentQuestion')]")));
////
////                    WebElement QuestionPlayer = driver.findElement(By.xpath("//div[contains(@class, 'planComponentQuestion')]//div[contains(@class, 'QuestionPlayer')]"));
////
////                    System.out.println("Question is found");
////                    String questionType = QuestionPlayer.getAttribute("data-type");
////                    System.out.println("Question Type is: " + questionType);
////                    TestRunner.getTest().log(Status.INFO, "Attempted question type is: " + questionType);
////
//////                    attemptedQuestionTypes.get().add(questionType);
////
////                    List<WebElement> questionRoots = QuestionBody.findElements(By.xpath("//div[contains(@class, 'planComponentQuestion')]//div[contains(@class, 'QuestionPlayer')]//div[contains(@class, 'question-root')]"));
////                    TestRunner.getTest().log(Status.INFO, "Total questions: " + questionRoots.size());
////                    System.out.println("Total questions: " + questionRoots.size());
////
////                    for (WebElement questionRoot : questionRoots) {
////                        try {
////                            String questionClass = questionRoot.getAttribute("class");
////                            TestRunner.getTest().log(Status.INFO, "Question class: " + questionClass);
////
//////                            if (questionClass.contains("showAnswer")) {
//////                                TestRunner.getTest().log(Status.PASS, "Show answer is correctly visible for this question.");
//////                                System.out.println("Show answer is visible for this question.");
//////                            } else {
//////                                TestRunner.getTest().log(Status.FAIL, "Show answer is NOT visible for this question.");
//////                                System.out.println("Show answer is NOT visible for this question.");
//////                            }
////
////                        }
//////                        catch (NoSuchElementException e) {
//////                            System.out.println("Question Has No Correct Answers Options");
//////                            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Question Has No Grade Assignment Points");
//////                            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
//////
//////                        }
////                        catch (TimeoutException e) {
////                            TestRunner.getTest().log(Status.FAIL, "Timeout waiting for element - " + e.getMessage());
////
////                        } catch (Exception e) {
////                            TestRunner.getTest().log(Status.FAIL, "Unexpected error - " + e.getMessage());
////                        }
////                    }
////                    driver.switchTo().defaultContent();
//                    enterStudentPointsOfEachQuestion();
//                    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//input[@role='button' or @role='combobox']/parent::div)[2]")));
//               // }
////                catch (Exception e) {
////                    TestRunner.getTest().log(Status.FAIL, "Failed to check or click Show Answers button.");
////                    e.printStackTrace();
////                }
//                Thread.sleep(2000);
//
//                // Use safe click method to handle interception
//                safeClickElement(nextButton, "Assignment Questions DropDown Next");
//
//                Thread.sleep(2000);
//                processedQuestions++;
////                }else {
////                    Point point = btn_AssignmentQuestionsDropDownNext.getLocation();
////                    int x = point.getX() + (int) (Math.random() * 10);
////                    int y = point.getY() + (int) (Math.random() * 10);
////                    actions.moveByOffset(x, y).click().perform();
////                    System.out.println("Random click performed near the score input.");
////                    TestRunner.getTest().log(Status.INFO, "Random click performed near the score input.");
////
////                    studentGradesUpdatedPrompt();
////                    verifySuccessAlertMessage();
////                }
//            }
////            System.out.println("Attempted Question Types: " + attemptedQuestionTypes.get());
////            TestRunner.getTest().log(Status.INFO, "Attempted Question Types: " + attemptedQuestionTypes.get());
//        }
//    }

    public void updateGradesOfEachQuestionAndShowsCorrectAnswers() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Update Grades of Each Question and Shows correct Answers");

        if (!dropDown_AssignmentQuestions.isEnabled()) {
            TestRunner.getTest().log(Status.FAIL, "Questions dropdown is not enabled");
            return;
        }

        // Open dropdown once to load options
        dropDown_AssignmentQuestions.click();
        Thread.sleep(1500);

        wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//ul[@role='listbox']//li")));

        List<WebElement> listQuestions = driver.findElements(
                By.xpath("//ul[@role='listbox']//li"));
        int totalQuestions = listQuestions.size();

        System.out.println("Total questions in dropdown: " + totalQuestions);
        TestRunner.getTest().log(Status.INFO, "Total questions in dropdown: " + totalQuestions);

        for (int i = 0; i < totalQuestions; i++) {
            // Re-open dropdown each iteration to get fresh elements
            dropDown_AssignmentQuestions.click();
            wait.until(ExpectedConditions.visibilityOfElementLocated(
                    By.xpath("//ul[@role='listbox']//li")));

            listQuestions = driver.findElements(
                    By.xpath("//ul[@role='listbox']//li"));

            if (i >= listQuestions.size()) {
                System.out.println("Index " + i + " out of bounds after refresh. Breaking loop.");
                break;
            }

            WebElement questionOption = listQuestions.get(i);
            String questionText = questionOption.getText().trim();

            System.out.println("Selecting Assignment Question: " + questionText);
            TestRunner.getTest().log(Status.INFO, "Selecting Assignment Question: " + questionText);

            questionOption.click();
            Thread.sleep(1500); // allow question content to load

            // Now update grades/points for this selected question
            enterStudentPointsOfEachQuestion();

            // Make sure dropdown is ready for the next iteration
            wait.until(ExpectedConditions.elementToBeClickable(
                    By.xpath("(//input[@role='button' or @role='combobox']/parent::div)[2]")));
        }
    }



    public void viewCorrectAnswer() {
        WebElement btnShowAnswers = driver.findElement(By.xpath("//span[normalize-space()='Show Answers']/parent::button"));

        try {
            if (btnShowAnswers.isDisplayed() && btnShowAnswers.isEnabled()) {
                btnShowAnswers.click();
                TestRunner.getTest().log(Status.INFO, "Show Answer button clicked successfully");

                Thread.sleep(2000);

                try {
                    WebElement questionPlayerIFrame = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("lesson-player-ifram")));
                    driver.switchTo().frame(questionPlayerIFrame);

                    WebElement QuestionBody = driver.findElement(By.xpath("//div[contains(@class, 'LessonPlayerRoot')]"));
                    wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//div[contains(@class, 'planComponentQuestion')]")));

                    WebElement QuestionPlayer = driver.findElement(By.xpath("//div[contains(@class, 'planComponentQuestion')]//div[contains(@class, 'QuestionPlayer')]"));

                    String questionType = QuestionPlayer.getAttribute("data-type");
                    System.out.println("Question Type is: " + questionType);
                    TestRunner.getTest().log(Status.INFO, "Attempted question type is: " + questionType);

                    List<WebElement> questionRoots = QuestionBody.findElements(By.xpath("//div[contains(@class, 'planComponentQuestion')]//div[contains(@class, 'QuestionPlayer')]//div[contains(@class, 'question-root')]"));
                    TestRunner.getTest().log(Status.INFO, "Total questions: " + questionRoots.size());
                    System.out.println("Total questions: " + questionRoots.size());

                    for (WebElement questionRoot : questionRoots) {
                        try {
                            String questionClass = questionRoot.getAttribute("class");
                            TestRunner.getTest().log(Status.INFO, "Question class: " + questionClass);

                            if (questionClass.contains("showAnswer")) {
                                TestRunner.getTest().log(Status.PASS, "Show answer is correctly visible for this question.");
                                System.out.println("Show answer is visible for this question.");
                            } else {
                                TestRunner.getTest().log(Status.FAIL, "Show answer is NOT visible for this question.");
                                System.out.println("Show answer is NOT visible for this question.");
                            }

                        } catch (NoSuchElementException e) {
                            System.out.println("Question Has No Correct Answers Options");
                            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Question Has No Grade Assignment Points");
                            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());

                        } catch (TimeoutException e) {
                            TestRunner.getTest().log(Status.FAIL, "Timeout waiting for element - " + e.getMessage());
                        } catch (Exception e) {
                            TestRunner.getTest().log(Status.FAIL, "Unexpected error - " + e.getMessage());
                        }
                    }
                    driver.switchTo().defaultContent();
                } catch (Exception e) {
                    TestRunner.getTest().log(Status.FAIL, "Failed to interact with the iframe or retrieve question elements.");
                    e.printStackTrace();
                }
            } else {
                TestRunner.getTest().log(Status.FAIL, "Show Answers button is not displayed or enabled.");
                System.out.println("Show Answers button is not displayed or enabled.");
            }
        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "Failed to click Show Answers button or it's not clickable.");
            e.printStackTrace();
        }
    }

    public void enterStudentPointsOfEachQuestion() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into Enter student Points of each Question and Submit that point");
        System.out.println("I'm into Enter student Points of each Question and Submit that point");

//        try {
        WebElement scoreDiv = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//p[normalize-space()='Score']/parent::div")));

        String scoreValueText = scoreDiv.findElement(By.xpath("//p[normalize-space()='Score']/parent::div//p[normalize-space()='Score']/following-sibling::p")).getText().trim();
        String numericScore = scoreValueText.split("/")[1].trim();
        System.out.println("Score Value with /: " + numericScore);
        int scoreValue = Integer.parseInt(numericScore);
        System.out.println("Score Value: " + scoreValue);
        TestRunner.getTest().log(Status.INFO, "Score Value: " + scoreValue);

        WebElement scoreInput = scoreDiv.findElement(By.xpath(".//input[@type='number']"));
        scoreInput.click();
        String existingStudentPoint = scoreInput.getAttribute("value");
        System.out.println("Current Student Point: " + existingStudentPoint);
        TestRunner.getTest().log(Status.INFO, "Current Student Point: " + existingStudentPoint);

        // Optionally, you can handle the "Full Credit" or "No Credit" buttons if needed
//            WebElement fullCreditButton = scoreDiv.findElement(By.xpath(".//button[normalize-space()='Full Credit']"));
//            if (fullCreditButton.isDisplayed() && fullCreditButton.isEnabled()) {
//                fullCreditButton.click();
//                System.out.println("Full Credit button clicked successfully");
//                TestRunner.getTest().log(Status.PASS, "Full Credit button clicked successfully");
//                studentGradesUpdatedPrompt();
//            }

        int length = scoreInput.getAttribute("value").length();
        for (int j = 0; j < length; j++) {
            actions.sendKeys(Keys.BACK_SPACE).perform();
        }
        System.out.println("Cleared the input field");
        TestRunner.getTest().log(Status.INFO, "Cleared the input field");

        int studentPoint = (int) (Math.random() * (scoreValue + 1)); // Ensure points are <= weight
        System.out.println("Generated student point: " + studentPoint);
        TestRunner.getTest().log(Status.INFO, "Generated student point: " + studentPoint);

        scoreInput.clear();
        scoreInput.sendKeys(String.valueOf(studentPoint));
        System.out.println("Score input updated to: " + scoreValue);
        TestRunner.getTest().log(Status.INFO, "Score input updated to: " + scoreValue);

        System.out.println("Add New Student Points");

        studentPointsList.get().add(studentPoint);

        System.out.println("Teacher Entered student point: " + studentPoint);
        TestRunner.getTest().log(Status.INFO, "Teacher Entered student point: " + studentPoint);

        Thread.sleep(1000);

        WebElement tableClick= driver.findElement(By.xpath("//button[normalize-space()='Grade by Student']"));
        tableClick.click();

        studentGradesUpdatedPrompt();
        verifySuccessAlertMessage();

//        clickOnNextArrow();

//        studentGradesUpdatedPrompt();
//        verifySuccessAlertMessage();
//        } catch (NoSuchElementException e) {
//            System.out.println("Content Type Question Have not Grade Assignment Points");
//            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Content Type Question Have not Grade Assignment Points ");
//            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
//
//        } catch (TimeoutException e) {
//            System.out.println("Timed out waiting for element: " + e.getMessage());
//            TestRunner.getTest().log(Status.FAIL, "Test case failed: Timeout waiting for element - " + e.getMessage());
//
//        } catch (Exception e) {
//            System.out.println("An error occurred: " + e.getMessage());
//            TestRunner.getTest().log(Status.FAIL, "Test case failed: Unexpected error - " + e.getMessage());
//        }
    }

    public void clickOnNextArrow() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO,"I'm into click on Next Arrow");

        try {
            // Wait for the next arrow to be present
            WebElement nextArrow = wait.until(ExpectedConditions.presenceOfElementLocated(
                    By.xpath("(//*[name()='svg' and @width='10' and @height='16'])[4]")));
            
            // Check if next arrow is disabled (we're on last question)
            String parentClass = ((JavascriptExecutor) driver).executeScript(
                    "return arguments[0].closest('button') ? arguments[0].closest('button').getAttribute('class') : '';", 
                    nextArrow).toString();
            
            boolean isDisabled = parentClass.contains("disabled") || parentClass.contains("Mui-disabled");
            
            // Also check if the SVG's parent button is disabled
            try {
                WebElement parentButton = (WebElement) ((JavascriptExecutor) driver).executeScript(
                        "return arguments[0].closest('button');", nextArrow);
                if (parentButton != null) {
                    isDisabled = !parentButton.isEnabled() || parentButton.getAttribute("disabled") != null;
                }
            } catch (Exception e) {
                // If we can't find parent, continue with other checks
            }
            
            if (isDisabled) {
                System.out.println("ℹ️ Next Arrow is disabled - we're on the last question");
                TestRunner.getTest().log(Status.INFO, "Next Arrow is disabled - we're on the last question");
                return; // Exit gracefully if on last question
            }
            
            // Scroll to element and wait for it to be clickable
            helper.scrollToElement(driver, nextArrow);
            Thread.sleep(500); // Small wait for scroll to complete
            
            // Try to find the parent button element for more reliable clicking
            WebElement clickableElement = nextArrow;
            try {
                WebElement parentButton = (WebElement) ((JavascriptExecutor) driver).executeScript(
                        "return arguments[0].closest('button');", nextArrow);
                if (parentButton != null && parentButton.isEnabled()) {
                    clickableElement = parentButton;
                }
            } catch (Exception e) {
                // If parent not found, use the SVG itself
            }
            
            // Try multiple click strategies to avoid interception
            try {
                // First try: JavaScript click on the element
                ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", clickableElement);
                ((JavascriptExecutor) driver).executeScript("arguments[0].click();", clickableElement);
                System.out.println("✅ Clicked with JavaScript");
                TestRunner.getTest().log(Status.PASS, "Next Arrow clicked successfully");
            } catch (Exception jsException) {
                // Second try: Click on parent button if available
                try {
                    WebElement parentBtn = clickableElement.findElement(By.xpath("./ancestor::button[1]"));
                    if (parentBtn != null && parentBtn.isEnabled()) {
                        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", parentBtn);
                        System.out.println("✅ Clicked parent button with JavaScript");
                        TestRunner.getTest().log(Status.PASS, "Next Arrow clicked via parent button");
                    } else {
                        throw jsException; // Re-throw if parent click fails
                    }
                } catch (Exception parentException) {
                    // Last resort: Try Actions class
                    try {
                        Actions actions = new Actions(driver);
                        actions.moveToElement(clickableElement).click().perform();
                        System.out.println("✅ Clicked with Actions");
                        TestRunner.getTest().log(Status.PASS, "Next Arrow clicked with Actions");
                    } catch (Exception actionsException) {
                        TestRunner.getTest().log(Status.FAIL, "Failed to click Next Arrow after all attempts: " + actionsException.getMessage());
                        System.out.println("❌ Error clicking Next Arrow: " + actionsException.getMessage());
                        throw actionsException;
                    }
                }
            }
            
        } catch (NoSuchElementException e) {
            System.out.println("ℹ️ Next Arrow not found - might be on last question");
            TestRunner.getTest().log(Status.INFO, "Next Arrow not found - might be on last question");
            // Don't throw exception, just log and return
        } catch (Exception e) {
            TestRunner.getTest().log(Status.WARNING, "Error clicking Next Arrow: " + e.getMessage());
            System.out.println("⚠️ Warning: " + e.getMessage());
            // Don't throw exception, just log warning
        }
    }

    public void studentGradesUpdatedPrompt() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Delete Question Prompt");
        Thread.sleep(1000);

//        WebElement gradesUpdatePrompt = wait.until(ExpectedConditions.elementToBeClickable(customizedDialogTitle));

        if (customizedDialogTitle.isDisplayed()) {
            WebElement gradeUpdatePromptText = customizedDialogTitle.findElement(By.xpath(".//div[contains(@class, 'MuiDialogContent')]"));
            System.out.println("Question grade update prompt text is: " + gradeUpdatePromptText.getText());

            WebElement btnPromptSave = customizedDialogTitle.findElement(By.xpath(".//button[normalize-space()='Save']"));

            if (btnPromptSave.isEnabled()) {
                btnPromptSave.click();
                TestRunner.getTest().log(Status.PASS, "Test Case Passed : Question grade Update clicked successfully");
            }
        }
    }

    public void checkShowsAssignmentNotesOfQuestion() {
        TestRunner.getTest().log(Status.INFO, "Check shows assignment notes of each question");
        System.out.println("I'm in to check shows assignment notes of each question");

        try {
            WebElement table = driver.findElement(By.xpath("//div[contains(@class, 'StudentGradingWrapper')]"));
            List<WebElement> rows = table.findElements(By.xpath(".//tbody/tr"));

            boolean assignmentFound = false;

            for (WebElement row : rows) {
                WebElement studentCell = row.findElement(By.xpath(".//td[1]"));
                String studentName = studentCell.getText().trim();
                System.out.println("Students Name: " + studentName);
                TestRunner.getTest().log(Status.INFO, "Students Name: " + studentName);

                // Check the status of Student
                WebElement statusCell = row.findElement(By.xpath(".//td[2]//input"));
                String status = statusCell.getAttribute("value").trim();
                System.out.println("Student Status: " + status);
                TestRunner.getTest().log(Status.INFO, "Student Status: " + status);

                if (status.equalsIgnoreCase("Submitted") || status.equalsIgnoreCase("Graded")) {
                    TestRunner.getTest().log(Status.INFO, "Student Name: " + studentName + " | Student Status: " + status);
                    assignmentFound = true;
                    WebElement viewNotesCell = row.findElement(By.xpath(".//td[5]//button[@type='button'][normalize-space()='View Notes']"));
                    Thread.sleep(500);
                    helper.scrollToElement(driver, viewNotesCell);
                    Thread.sleep(2000);

                    if (viewNotesCell != null) {
                        if (viewNotesCell.isDisplayed() && viewNotesCell.isEnabled()) {
                            viewNotesCell.click();
                            System.out.println("View Notes button clicked successfully");
                            TestRunner.getTest().log(Status.PASS, "View Notes button clicked successfully");

                            WebElement dialog = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class, 'MuiDialog-paper')]")));
                            TestRunner.getTest().log(Status.INFO, "Assignment Notes dialog is visible.");

                            List<WebElement> textAreas = dialog.findElements(By.xpath(".//input"));
                            for (WebElement textArea : textAreas) {
                                String textAreaValue = textArea.getAttribute("value");
                                System.out.println("Text in input: " + textAreaValue);
                                TestRunner.getTest().log(Status.INFO, "Text in input: " + textAreaValue);

                                savedNotes.get().add(textAreaValue);
                            }

                            TestRunner.getTest().log(Status.INFO, "Saved Notes: " + savedNotes.get());

                            Thread.sleep(2000);
                            WebElement closeButton = dialog.findElement(By.xpath("//button[@aria-label='close']"));
                            closeButton.click();
                            TestRunner.getTest().log(Status.PASS, "Closed the Assignment Notes dialog.");
                            System.out.println("Closed the Assignment Notes dialog.");
                        } else {
                            System.out.println("View Notes button is either not visible or not enabled.");
                            TestRunner.getTest().log(Status.FAIL, "View Notes button is either not visible or not enabled.");
                        }
                    } else {
                        System.out.println("View Notes button element not found.");
                        TestRunner.getTest().log(Status.FAIL, "View Notes button element not found.");
                    }
                    break;
                } else {
                    System.out.println("No any Submitted or Graded assignment status found");
                }
            }

            if (!assignmentFound) {
                TestRunner.getTest().log(Status.FAIL, "No any Submitted or Graded assignment status found");
                System.out.println("No any Submitted or Graded assignment status found");
            }

        } catch (Exception e) {
            System.out.println("Exception while viewing assignment View Notes: " + e.getMessage());
            TestRunner.getTest().log(Status.FAIL, "Exception while viewing assignment View Notes: " + e.getMessage());
        }
    }

    public void ValidateStudentAndTeacherNotes() {
        if (savedNotes.get().size() != addedNotes.get().size()) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: The number of notes does not match.");
            System.out.println("The number of notes does not match. Expected: " + addedNotes.get().size() + ", Found: " + savedNotes.get().size());
            return;
        }

        for (int i = 0; i < savedNotes.get().size(); i++) {
            String savedNote = savedNotes.get().get(i);
            String addedNote = addedNotes.get().get(i);

            if (savedNote.equals(addedNote)) {
                System.out.println("Note " + (i + 1) + " matches: " + savedNote);
                TestRunner.getTest().log(Status.PASS, "Note " + (i + 1) + " matches: " + savedNote);
            } else {
                System.out.println("Note " + (i + 1) + " mismatch. Added: " + addedNote + ", Found: " + savedNote);
                TestRunner.getTest().log(Status.FAIL, "Note " + (i + 1) + " mismatch. Added: " + addedNote + ", Found: " + savedNote);
            }
        }

        TestRunner.getTest().log(Status.INFO, "Comparison between saved and added notes is completed.");
        System.out.println("Comparison between saved and added notes is completed.");
    }

    public void checkCopyTextOfAssignment() {
        TestRunner.getTest().log(Status.INFO, "Check shows copy text of each assignment");

        try {
            WebElement btnCopyText = driver.findElement(By.xpath("//div[@class='button-group otherToolBtn']//div[@role='group']//span[normalize-space()='Copy Text']/parent::button"));
            helper.scrollToElement(driver, btnCopyText);

            String classBeforeClick = btnCopyText.getAttribute("class");
            TestRunner.getTest().log(Status.INFO, "Class before click: " + classBeforeClick);

            if (classBeforeClick.contains("inactive-tool")) {
                btnCopyText.click();
                TestRunner.getTest().log(Status.PASS, "Copy Text button clicked successfully");
                Thread.sleep(1000);

                String classAfterClick = btnCopyText.getAttribute("class");
                TestRunner.getTest().log(Status.INFO, "Class after click: " + classAfterClick);

                if (classAfterClick.contains("active-tool")) {
                    TestRunner.getTest().log(Status.PASS, "'Copy Text' button is now active.");

                    WebElement questionPlayerIFrame = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("lesson-player-ifram")));
                    driver.switchTo().frame(questionPlayerIFrame);

                    WebElement QuestionBody = driver.findElement(By.xpath("//div[contains(@class, 'LessonPlayerRoot')]"));
                    wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//div[contains(@class, 'planComponentQuestion')]")));

                    WebElement questionRoots = QuestionBody.findElement(By.xpath("//div[contains(@class, 'planComponentQuestion')]//div[contains(@class, 'QuestionPlayer')]//div[contains(@class, 'question-root')]"));

                    WebElement questionText = questionRoots.findElement(By.xpath(".//div[contains(@class, 'questionText')]"));
                    helper.scrollToElement(driver, questionText);
                    Thread.sleep(1000);
                    actions.doubleClick(questionText).perform();

                    WebElement successToast = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(), 'Copied to Clipboard')]")));
                    if (successToast != null && successToast.isDisplayed()) {
                        TestRunner.getTest().log(Status.PASS, "Success message 'Copied to Clipboard' is displayed.");
                        System.out.println("Success message 'Copied to Clipboard' is displayed.");
                    } else {
                        TestRunner.getTest().log(Status.FAIL, "Success message 'Copied to Clipboard' is not displayed.");
                    }

                    String copiedTextContent = questionText.getText().trim();
                    TestRunner.getTest().log(Status.INFO, "Copied text: " + copiedTextContent);

                    String originalWindow = driver.getWindowHandle();
                    ((JavascriptExecutor) driver).executeScript("window.open('about:blank','_blank');");
                    Thread.sleep(2000);

                    Set<String> allWindows = driver.getWindowHandles();
                    for (String windowHandle : allWindows) {
                        if (!windowHandle.equals(originalWindow)) {
                            driver.switchTo().window(windowHandle);
                            break;
                        }
                    }

                    ((JavascriptExecutor) driver).executeScript("document.body.innerText = arguments[0];", copiedTextContent);

                    WebElement pastedTextElement = driver.findElement(By.xpath("//body"));
                    String pastedTextContent = pastedTextElement.getText().trim();

                    TestRunner.getTest().log(Status.INFO, "Pasted text: " + pastedTextContent);

                    if (pastedTextContent.equals(copiedTextContent)) {
                        TestRunner.getTest().log(Status.PASS, "Copied text matches pasted text.");
                    } else {
                        TestRunner.getTest().log(Status.FAIL, "Copied text does not match pasted text.");
                    }

                    driver.close();
                    Thread.sleep(1000);
                    driver.switchTo().window(originalWindow);

                } else {
                    TestRunner.getTest().log(Status.FAIL, "'Copy Text' button did not become active.");
                }
            } else {
                TestRunner.getTest().log(Status.INFO, "Copy Text button is already active.");
            }
        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "Failed to check or click Copy Text button.");
            e.printStackTrace();
        }
    }

    public void checkReadAloudOfAssignment() {
        TestRunner.getTest().log(Status.INFO, "Check shows read aloud of each assignment");

        try {
            WebElement btnReadAloud = driver.findElement(By.xpath("//div[@class='button-group accessibilityTools']//div[@role='group']//span[normalize-space()='Read Aloud']/parent::button"));
            helper.scrollToElement(driver, btnReadAloud);

            String classBeforeClick = btnReadAloud.getAttribute("class");
            TestRunner.getTest().log(Status.INFO, "Class before click: " + classBeforeClick);

            if (classBeforeClick.contains("inactive-tool")) {
                btnReadAloud.click();
                TestRunner.getTest().log(Status.PASS, "Read Aloud button clicked successfully");
                Thread.sleep(1000);

                String classAfterClick = btnReadAloud.getAttribute("class");
                TestRunner.getTest().log(Status.INFO, "Class after click: " + classAfterClick);

                if (classAfterClick.contains("active-tool")) {
                    TestRunner.getTest().log(Status.PASS, "'Read Aloud' button is now active.");

                    WebElement questionPlayerIFrame = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("lesson-player-ifram")));
                    driver.switchTo().frame(questionPlayerIFrame);

                    WebElement QuestionBody = driver.findElement(By.xpath("//div[contains(@class, 'LessonPlayerRoot')]"));
                    wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//div[contains(@class, 'planComponentQuestion')]")));

                    WebElement questionRoots = QuestionBody.findElement(By.xpath("//div[contains(@class, 'planComponentQuestion')]//div[contains(@class, 'QuestionPlayer')]//div[contains(@class, 'question-root')]"));

                    WebElement questionText = questionRoots.findElement(By.xpath(".//div[contains(@class, 'questionText')]"));
                    helper.scrollToElement(driver, questionText);
                    Thread.sleep(1000);
                    actions.doubleClick(questionText).perform();

                    String copiedTextContent = questionText.getText().trim();
                    TestRunner.getTest().log(Status.INFO, "Copied text: " + copiedTextContent);

                    // Use the SpeechSynthesis API to read the copied text aloud
                    ((JavascriptExecutor) driver).executeScript("var msg = new SpeechSynthesisUtterance('" + copiedTextContent + "');" +
                            "window.speechSynthesis.speak(msg);");

                    // Verify that speech synthesis has started (simple check by logging)
                    TestRunner.getTest().log(Status.INFO, "Text is being read aloud.");

                    Thread.sleep(3000);

                    btnReadAloud.click();

                } else {
                    TestRunner.getTest().log(Status.FAIL, "'Read Aloud' button did not become active.");
                }
            } else {
                TestRunner.getTest().log(Status.INFO, "'Read Aloud' button is already active.");
            }
        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "Failed to check or click 'Read Aloud' button.");
            e.printStackTrace();
        }
    }

    public void checkFontSizeOfAssignment() {
        TestRunner.getTest().log(Status.INFO, "Check shows font size of each assignment");

        try {
            WebElement btnFontSize = driver.findElement(By.xpath("//div[@class='button-group accessibilityTools']//div[@role='group']//span[normalize-space()='Font Size']/parent::button"));
            helper.scrollToElement(driver, btnFontSize);

            String classBeforeClick = btnFontSize.getAttribute("class");
            TestRunner.getTest().log(Status.INFO, "Class before click: " + classBeforeClick);

            if (classBeforeClick.contains("inactive-tool")) {
                btnFontSize.click();
                TestRunner.getTest().log(Status.PASS, "Font Size button clicked successfully");
                Thread.sleep(1000);

                WebElement fontSizeMenu = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@data-popper-placement='bottom-start']")));
                if (fontSizeMenu.isDisplayed()) {
                    TestRunner.getTest().log(Status.PASS, "'Font Size' menu is now visible.");

                    List<WebElement> fontSizeOptions = fontSizeMenu.findElements(By.xpath(".//li"));
                    Random rand = new Random();
                    WebElement selectedFontSize = fontSizeOptions.get(rand.nextInt(fontSizeOptions.size()));

                    String selectedFontSizeText = selectedFontSize.getText();
                    TestRunner.getTest().log(Status.INFO, "Selected font size: " + selectedFontSizeText);

                    selectedFontSize.click();
                    TestRunner.getTest().log(Status.PASS, "Font size selected: " + selectedFontSizeText);

                    WebElement questionPlayerIFrame = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("lesson-player-ifram")));
                    driver.switchTo().frame(questionPlayerIFrame);

                    WebElement questionText = driver.findElement(By.xpath("//div[contains(@class, 'contentWrapperSelectedItem')]"));
                    String fontSizeStyle = questionText.getAttribute("style");
                    TestRunner.getTest().log(Status.INFO, "Font style after selection: " + fontSizeStyle);

                    if (fontSizeStyle.contains("font-size")) {
                        TestRunner.getTest().log(Status.PASS, "Font size updated successfully in the iframe.");
                    } else {
                        TestRunner.getTest().log(Status.FAIL, "Font size did not update in the iframe.");
                    }

                    driver.switchTo().defaultContent();
                } else {
                    TestRunner.getTest().log(Status.FAIL, "'Font Size' menu did not appear.");
                }
            } else {
                TestRunner.getTest().log(Status.INFO, "'Font Size' button is already active.");
            }
        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "Failed to check or click 'Font Size' button.");
            e.printStackTrace();
        }
    }

    private boolean isPaginationDisplayed() {
        try {
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//nav[@aria-label='pagination navigation']")));
            return nav_Pagination.isDisplayed();
        } catch (NoSuchElementException | ElementNotInteractableException | TimeoutException e) {
            return false;
        }
    }

    public void enterStudentPointsAndSubmit() {
        TestRunner.getTest().log(Status.INFO, "I'm into Enter student Points and Submit that point");
        System.out.println("I'm into Enter student Points and Submit that point");

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(60));

        try {
            // Locate the point weight input field
            WebElement pointWeightInput = driver.findElement(By.xpath("(//input[@name='pointWeight '])"));

            // Get the weight value
            int weight = Integer.parseInt(pointWeightInput.getAttribute("value"));
            System.out.println("Point weight: " + weight);
            TestRunner.getTest().log(Status.INFO, "Point weight: " + weight);

            // Locate the student points input field
            WebElement pointsInput = wait.until(ExpectedConditions.elementToBeClickable(
                    By.xpath("(//input[@name='points'])")  // XPath for the student points field
            ));
            pointsInput.click();

            String existingStudentPoint = pointsInput.getAttribute("value");
            System.out.println("Current Student Point: " + existingStudentPoint);
            TestRunner.getTest().log(Status.INFO, "Current Student Point: " + existingStudentPoint);

            // Clear the existing input in the field
            int length = pointsInput.getAttribute("value").length();
            for (int j = 0; j < length; j++) {
                actions.sendKeys(Keys.BACK_SPACE).perform();
            }
            System.out.println("Cleared the input field");
            TestRunner.getTest().log(Status.INFO, "Cleared the input field");

            // Generate student points <= weight
            int studentPoint = (int) (Math.random() * (weight + 1)); // Ensure points are <= weight
            System.out.println("Generated student point: " + studentPoint);
            TestRunner.getTest().log(Status.INFO, "Generated student point: " + studentPoint);

            // Enter the new student point
            pointsInput.sendKeys(String.valueOf(studentPoint));

            System.out.println("Add New Student Points");

            studentPointsList.get().add(studentPoint);  // Add point to the list

            System.out.println("Teacher Entered student point: " + studentPoint);
            TestRunner.getTest().log(Status.INFO, "Teacher Entered student point: " + studentPoint);

            // Locate and click the submit button
            WebElement clickSubmit = driver.findElement(By.xpath("//button[@name='btn-submit-applyfilter']"));
            clickSubmit.click();
            System.out.println("Submit button clicked successfully");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Submit button clicked successfully.");

            TestRunner.getTest().log(Status.INFO, "I'm in to get Success Message.");
            System.out.println("Get Success Message");
            getSuccessMessage();

        } catch (NoSuchElementException e) {
            System.out.println("Content Type Question Have not Grade Assignment Points");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Content Type Question Have not Grade Assignment Points ");
            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());

        } catch (TimeoutException e) {
            System.out.println("Timed out waiting for element: " + e.getMessage());
            TestRunner.getTest().log(Status.FAIL, "Test case failed: Timeout waiting for element - " + e.getMessage());

        } catch (Exception e) {
            System.out.println("An error occurred: " + e.getMessage());
            TestRunner.getTest().log(Status.FAIL, "Test case failed: Unexpected error - " + e.getMessage());
        }
    }

    public void getSuccessMessageInVerticalView() {

        WebElement successBox = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//div[contains(@class, 'MuiAlert-message')]")
        ));

        String successMessage = successBox.getText();
        System.out.println("Success message: " + successMessage);

        // Log the success message
        TestRunner.getTest().log(Status.INFO, "Success message: " + successMessage);
    }

    public void getSuccessMessage() {
//        WebElement successBox = wait.until(ExpectedConditions.visibilityOfElementLocated(
//                By.xpath("//div[contains(@class, 'MuiAlert-message')]")
//        ));
//
//        String successMessage = successBox.getText();
//        System.out.println("Success message: " + successMessage);
//
//        // Log the success message
//        TestRunner.getTest().log(Status.INFO, "Success message: " + successMessage);


        wait.pollingEvery(Duration.ofMillis(20));

        try {
            WebElement toastContainer = wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("toastr")));

            try {
                if (toastContainer.isDisplayed()) {
                    toastContainer = driver.findElement(By.className("toastr"));
                    String actualBackgroundColor = toastContainer.getCssValue("background-color");

                    String expectedBackgroundColor = "rgb(96, 187, 113)";
                    String expectedBackgroundColorWithAlpha = "rgba(96, 187, 113, 1)";

                    System.out.println("Captured Background Color: " + actualBackgroundColor);

                    if (actualBackgroundColor.equals(expectedBackgroundColor) || actualBackgroundColor.equals(expectedBackgroundColorWithAlpha)) {
                        System.out.println("Test case Passed: Background color is as expected (" + actualBackgroundColor + ").");

                        String messageTitle = toastContainer.findElement(By.className("rrt-title")).getText();
                        String messageText = toastContainer.findElement(By.className("rrt-text")).getText();

                        System.out.println("Message Title: " + messageTitle);
                        TestRunner.getTest().log(Status.INFO, "Success toast title is: " + messageTitle);
                        System.out.println("Message Text: " + messageText);
                        TestRunner.getTest().log(Status.INFO, "Success toast message is: " + messageText);

                        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Shows success message toast");

                    } else {
                        System.out.println("Test case Failed: Background color is not as expected. Actual: " + actualBackgroundColor);
                        TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Shows error toast with background color " + actualBackgroundColor);

                        String errorMessageTitle = toastContainer.findElement(By.className("rrt-title")).getText();
                        String errorMessageText = toastContainer.findElement(By.className("rrt-text")).getText();

                        System.out.println("Message Title: " + errorMessageTitle);
                        TestRunner.getTest().log(Status.INFO, "Error toast title is: " + errorMessageTitle);
                        System.out.println("Message Text: " + errorMessageText);
                        TestRunner.getTest().log(Status.INFO, "Error toast message is: " + errorMessageText);
                    }

                } else {
                    TestRunner.getTest().log(Status.FAIL, "Toast message is not displayed.");
                }
            } catch (StaleElementReferenceException staleEx) {
                TestRunner.getTest().log(Status.WARNING, "Toast element became stale. Retrying...");

                toastContainer = wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("toastr")));
                String retryBackgroundColor = toastContainer.getCssValue("background-color");

                System.out.println("Retried Background Color: " + retryBackgroundColor);
                TestRunner.getTest().log(Status.INFO, "Retried and captured background color: " + retryBackgroundColor);
            }

        } catch (TimeoutException e) {
            TestRunner.getTest().log(Status.FAIL, "Toast message did not appear in the expected time.");
        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "Unexpected error while verifying toast message: " + e.getMessage());
        }
    }

    public void ClickMarkAsGraded() {
        try {
            TestRunner.getTest().log(Status.INFO, "Attempting to check 'Mark As Graded' checkbox");
            System.out.println("Attempting to check 'Mark As Graded' checkbox");
            helper.scrollToElement(driver, markAsGradedCheckbox);
            if (!markAsGradedCheckbox.isSelected()) {
                markAsGradedCheckbox.click();
                System.out.println("Checkbox 'Mark as Graded' is now checked.");
                TestRunner.getTest().log(Status.PASS, "Checkbox 'Mark as Graded' was unchecked, now checked.");
            } else {
                System.out.println("Checkbox 'Mark as Graded' is already checked.");
                TestRunner.getTest().log(Status.INFO, "Checkbox 'Mark as Graded' was already checked.");
            }
        } catch (Exception e) {
            System.err.println("Failed to check 'Mark As Graded' checkbox: " + e.getMessage());
            TestRunner.getTest().log(Status.FAIL, "Exception occurred while checking 'Mark As Graded' checkbox: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public void VerifyStudentPoints() throws InterruptedException {
        WebElement overviewWrapper = driver.findElement(By.xpath("//div[contains(@class,'OverviewScreenWrapper')]"));
//            WebElement answer_element = overviewWrapper.findElement(By.xpath(".//div[@class='ScrollbarsCustom-Content']"));

//           List<WebElement> correctAnswers = driver.findElements(By.xpath("//*[@iscorrectanswer='Correct']"));


        List<WebElement> button_answers = overviewWrapper.findElements(By.xpath(".//button[@isCorrectAnswer]"));
        System.out.println("Total Answer: " + button_answers.size());
        if (!button_answers.isEmpty()) {
            WebElement button = button_answers.get(0);
            if (button.isDisplayed()) {
                System.out.println("Button was clicked: " + button.getText());
                button.click();
                System.out.println("Answer is clicked.");
                isPointExist();
            } else {
                System.out.println("Button is not displayed.");
            }
        } else {
            System.out.println("No answer buttons found.");
        }
    }

    public void isPointExist() throws InterruptedException {

        driver.switchTo().defaultContent();
        temp.set(0);
        try {

            List<WebElement> questionButtons = nav_Pagination.findElements(By.xpath("//button[contains(@aria-label, 'Go to page')]"));
            for (WebElement questionButton : questionButtons) {
                String questionText = questionButton.getText();
                System.out.println("Question: " + questionText);
            }

            while (btn_NavNextPage.isEnabled()) {
                Thread.sleep(2000);
                VerifyPointsWithNewTeacherPoints();
                btn_NavNextPage.click();
                Thread.sleep(2000);
            }

            Thread.sleep(2000);
            WebElement btn_CloseReview = driver.findElement(By.xpath("//button[@id='closeReview-btn']"));
            helper.scrollToElement(driver, btn_CloseReview);
            Thread.sleep(1000);
            System.out.println("Clicked on close review");
            btn_CloseReview.click();
        } catch (NoSuchElementException | ElementNotInteractableException | TimeoutException e) {
            driver.switchTo().defaultContent();
            WebElement btn_CloseReview = driver.findElement(By.xpath("//button[@id='closeReview-btn']"));
            helper.scrollToElement(driver, btn_CloseReview);
            btn_CloseReview.click();
            System.out.println("No Points are Visible.");
            TestRunner.getTest().log(Status.INFO, "Question Points not visible");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Question Points not visible");
        }
    }

    public void VerifyPointsWithNewTeacherPoints() throws InterruptedException {
        System.out.println("I'm in to verify Student Points that teacher set ");

        WebElement questionPlayer = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("lesson-player-ifram")));
        driver.switchTo().frame(questionPlayer);

        WebElement points = driver.findElement(By.xpath("//div[@class='pointWrapper']//span[1]"));
        String weightOnAssignmentAttemptStr = points.getText();
        System.out.println("Points At student Side on Assignment: " + weightOnAssignmentAttemptStr);
        int weightOnAssignmentAttempt = Integer.parseInt(weightOnAssignmentAttemptStr);

        System.out.println("Size of Student Point Array from teacher side: " + studentPointsList.get().size());
        System.out.println("New Student Points Array from teacher Side: " + studentPointsList.get());

        if (temp.get() < studentPointsList.get().size()) {
            int correspondingWeight = studentPointsList.get().get(temp.get());
            System.out.println("Student Points on Assignment Attempt Student Side: " + weightOnAssignmentAttempt);
            System.out.println("New Student Point that Teacher change: " + correspondingWeight);

            if (weightOnAssignmentAttempt == correspondingWeight) {
                System.out.println("Student Points on assignment attempt matches with Points that Teacher set at index " + temp.get() + ": " + weightOnAssignmentAttempt);
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: Verified Point matches at index " + temp.get());
            } else {
                System.out.println("Point mismatch at index " + temp.get() + ": Assignment Point is " + weightOnAssignmentAttempt + " but expected teacher set " + correspondingWeight);
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Student Points mismatch at index " + temp.get());
            }
        } else {
            System.out.println("Invalid index: " + temp.get());
            TestRunner.getTest().log(Status.FAIL, "Invalid index " + temp.get());
        }

        // Increment temp for the current thread
        temp.set(temp.get() + 1);

        driver.switchTo().defaultContent();
    }


    // update Final scores

    public void UnCheckMarkAsGradedCheckBox() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm to Uncheck Mark As graded CheckBox");
        System.out.println("I'm to Uncheck Mark As graded CheckBox");


        WebElement table = driver.findElement(By.xpath("(//div[contains(@class, 'AssignmentSummary')])[3]"));
        WebElement StatusColumnOption = table.findElement(By.xpath(".//th[7]"));
        System.out.println("Mark As graded Column Option" + StatusColumnOption.getText());

        TestRunner.getTest().log(Status.INFO, "MARK AS GRADED");

        WebElement MarkAsGraded = StatusColumnOption.findElement(By.xpath(".//input[@type='checkbox']"));

        if (MarkAsGraded.isSelected()) {
            MarkAsGraded.click();
            System.out.println("Checkbox was selected, now it is unchecked.");

            // Verify that it is now unchecked
            if (!MarkAsGraded.isSelected()) {
                System.out.println("Test Passed: Checkbox successfully unchecked.");
                TestRunner.getTest().log(Status.PASS, "Checkbox successfully unchecked.");
            } else {
                System.out.println("Test Failed: Checkbox could not be unchecked.");
                TestRunner.getTest().log(Status.FAIL, "Checkbox could not be unchecked.");
            }
        } else {
            System.out.println("Test Passed: Checkbox was already unchecked.");
            TestRunner.getTest().log(Status.PASS, "Checkbox was already unchecked.");
        }
    }

    public void updateFinalScores() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm to Update final Scores for Student");
        System.out.println("I'm to Update final Scores for Student");

        WebElement tableInputCheckbox = driver.findElement(By.xpath("//div[contains(@class, 'StudentGradingWrapper')]//table//th[1]//input"));
        tableInputCheckbox.click();

        TestRunner.getTest().log(Status.PASS, "Clicked on all student checkbox");

        WebElement finalScores = driver.findElement(By.xpath("//div[contains(@class, 'StudentGradingWrapper')]//table//th[4]//input"));
        System.out.println("Final Score Column Option" + finalScores.getText());

        TestRunner.getTest().log(Status.INFO, "Final Scores %");

        finalScores.click();

        Random random = new Random();
        int randomScore = random.nextInt(99);
//        storedFinalScore = Integer.toString(randomScore);
        storedFinalScore.set(Integer.toString(randomScore));

        finalScores.clear();
        finalScores.sendKeys(storedFinalScore.get());

        System.out.println("Entered Final Score: " + storedFinalScore.get());
        TestRunner.getTest().log(Status.INFO, "Entered Final Score: " + storedFinalScore.get());

        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Final Score Added Successfully");

        WebElement btnApplyBulkScores = driver.findElement(By.xpath("//div[contains(@class, 'StudentGradingWrapper')]//table//th[4]//button[normalize-space()='Apply']"));

        if (btnApplyBulkScores.isDisplayed() && btnApplyBulkScores.isEnabled()) {
            btnApplyBulkScores.click();
            TestRunner.getTest().log(Status.PASS, "Clicked on Apply Bulk Scores button");
            System.out.println("Clicked on Apply Bulk Scores button");
        } else {
            TestRunner.getTest().log(Status.FAIL, "Apply Bulk Scores button is not enabled or not visible");
            System.out.println("Apply Bulk Scores button is not enabled or not visible");
        }
    }

    public void verifyBulkScoresChangedToGradeAllStudents() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm in to verify Bulk Scores changed For all students");
        System.out.println("I'm in to verify Bulk Scores changed For all students");

        wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//div[contains(@class, 'StudentGradingWrapper')]//table//input[@type='number']")));

        Thread.sleep(1000); // Small wait for page to stabilize

        // Get the count of score inputs first
        List<WebElement> assignmentScoresInput = driver.findElements(
                By.xpath("//div[contains(@class, 'StudentGradingWrapper')]//table//input[@type='number']"));

        int totalStudents = assignmentScoresInput.size();
        TestRunner.getTest().log(Status.INFO, "Total students assignments: " + totalStudents);
        System.out.println("Total students assignments: " + totalStudents);

        String expectedScore = storedFinalScore.get();
        if (expectedScore == null || expectedScore.isEmpty()) {
            TestRunner.getTest().log(Status.WARNING, "storedFinalScore is null or empty, cannot verify scores");
            System.out.println("Warning: storedFinalScore is null or empty");
            return;
        }

        // Re-locate elements inside the loop to avoid stale element references
        for (int i = 0; i < totalStudents; i++) {
            try {
                // Re-locate all score inputs fresh for each iteration
                List<WebElement> freshScoreInputs = driver.findElements(
                        By.xpath("//div[contains(@class, 'StudentGradingWrapper')]//table//input[@type='number']"));

                if (i < freshScoreInputs.size()) {
                    WebElement scoreInput = freshScoreInputs.get(i);
                    String scoreInputValue = scoreInput.getAttribute("value").trim();

                    TestRunner.getTest().log(Status.INFO, "Student " + (i + 1) + " score: " + scoreInputValue);
                    System.out.println("Student " + (i + 1) + " score: " + scoreInputValue);

                    if (!scoreInputValue.equals(expectedScore)) {
                        TestRunner.getTest().log(Status.FAIL, "Student " + (i + 1)
                                + " Score is not Updated, found: " + scoreInputValue
                                + " but expected: " + expectedScore);
                        System.out.println("Student " + (i + 1) + " Score mismatch: " + scoreInputValue);
                    }
                }
            } catch (StaleElementReferenceException e) {
                System.out.println("Stale element detected for student " + (i + 1) + ", retrying...");
                Thread.sleep(500);
                i--; // Retry the same index
            } catch (Exception e) {
                System.out.println("Error verifying score for student " + (i + 1) + ": " + e.getMessage());
                TestRunner.getTest().log(Status.WARNING, "Error verifying score for student " + (i + 1) + ": " + e.getMessage());
            }
        }

        TestRunner.getTest().log(Status.PASS, "All students' Scores are successfully set to: " + expectedScore);
        System.out.println("All students' Scores are successfully set to: " + expectedScore);
    }

    public void ClickOnApplyButton() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm to click on Apply Button");
        System.out.println("I'm to click on Apply Button");

        WebElement apply_btn = driver.findElement(By.xpath("(//button[@type='button'][normalize-space()='Apply'])[2]"));

        if (apply_btn.isDisplayed() && apply_btn.isEnabled()) {
            apply_btn.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Final Score and Apply Button Click Successfully");
        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Final Score not added and Apply Button not Enable");
        }

    }

    public void UpdateScoreDialogueBox() throws InterruptedException {

        TestRunner.getTest().log(Status.INFO, "Update Score Dialogue Window pop-up");
        System.out.println("Update Score Dialogue Window pop-up");

        WebElement dialogBoxUpdateScore = wait.until(ExpectedConditions.visibilityOf(updated_score));
        if (dialogBoxUpdateScore.isDisplayed()) {

            WebElement titleElement = dialogBoxUpdateScore.findElement(By.xpath(".//h2[contains(@id, 'customized-dialog-title')]"));
            String titleText = titleElement.getText().trim();
            System.out.println("Dialog Title: " + titleText);
            TestRunner.getTest().log(Status.INFO, "Dialog Title: " + titleText);


            WebElement descriptionElement1 = dialogBoxUpdateScore.findElement(By.xpath(".//div[contains(@class,'MuiDialogContent-root')]//h2[1]"));
            String descriptionText1 = descriptionElement1.getText().trim();
            System.out.println("Description 1: " + descriptionText1);
            TestRunner.getTest().log(Status.INFO, "Description 1: " + descriptionText1);

            WebElement descriptionElement2 = dialogBoxUpdateScore.findElement(By.xpath(".//div[contains(@class,'MuiDialogContent-root')]//h2[2]"));
            String descriptionText2 = descriptionElement2.getText().trim();
            System.out.println("Description 2: " + descriptionText2);
            TestRunner.getTest().log(Status.INFO, "Description 2: " + descriptionText2);

            System.out.println("All Information get Successfully from Update Score Dialogue Box");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: All Information get Successfully from Update Score Dialogue Box");
        } else {
            TestRunner.getTest().log(Status.FAIL, "Update Score  Dialogue Box not appear.");
            System.out.println("Update Score Dialogue Box not appear.");
        }
    }

    public void ClickSaveBtnFinalScore() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm in to click on Save Button in Un-Submitted Dialogue Box");
        System.out.println("I'm in to click on Save Button in Un-Submitted Dialogue Box");

        WebElement saveBtn = driver.findElement(By.xpath("//button[normalize-space()='Save']"));

        if (saveBtn.isDisplayed() && saveBtn.isEnabled()) {
            saveBtn.click();
            System.out.println("Un-Submitted Dialogue Box Save Button Click Successfully");
            TestRunner.getTest().log(Status.PASS, "Un-Submitted Dialogue Box Save Button Click Successfully");
        } else {
            TestRunner.getTest().log(Status.FAIL, "Un-Submitted Dialogue Box Save Button is Disable/Not found.");
            System.out.println("Un-Submitted Dialogue Box Save Button is Disable/Not found");
        }
    }

    public void CheckBoxMarkAsGraded() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm to check Mark As graded CheckBox");
        System.out.println("I'm to check Mark As graded CheckBox");

        Thread.sleep(3000);
        WebElement table = driver.findElement(By.xpath("(//div[contains(@class, 'AssignmentSummary')])[3]"));
        WebElement StatusColumnOption = table.findElement(By.xpath(".//th[7]"));
        System.out.println("Mark As graded Column Option" + StatusColumnOption.getText());

        TestRunner.getTest().log(Status.INFO, "MARK AS GRADED");

        WebElement MarkAsGraded = StatusColumnOption.findElement(By.xpath(".//input[@type='checkbox']"));

        if (!MarkAsGraded.isSelected()) {
            // Checkbox is not selected, so click to select it
            MarkAsGraded.click();
            System.out.println("Checkbox was not selected, now it is checked.");
            TestRunner.getTest().log(Status.PASS, "'Mark As Graded' checkbox was not selected, now it is checked.");
        } else {
            // Checkbox is already selected
            System.out.println("Checkbox is already checked.");
            TestRunner.getTest().log(Status.FAIL, "'Mark As Graded' checkbox is already checked.");
        }

    }

    public void VerifyFinalScoresAtStudentSide() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm verify new Final Scores That Teacher Update Checking Score Update at student Side");
        System.out.println("I'm verify new Final Scores That Teacher Update Checking Score Update at student Side");

        String assignmentTotalScore = totalScore.get();
        System.out.println("Assignment total score: " + assignmentTotalScore);
        TestRunner.getTest().log(Status.INFO, "Assignment total score: " + assignmentTotalScore);

        String cleanedTotalScore = assignmentTotalScore.replaceAll("%", "").trim();
        System.out.println("Total Score after we remove % : " + cleanedTotalScore);

        double scoreValue = Double.parseDouble(cleanedTotalScore);

        long roundedScore = Math.round(scoreValue);

        String roundedScoreStr = Long.toString(roundedScore);
        System.out.println("Rounded Total Score: " + roundedScoreStr);

        System.out.println("Final Score That teacher Update Score: " + storedFinalScore.get());
        TestRunner.getTest().log(Status.INFO, "Final Score That teacher Update Score: " + storedFinalScore.get());

        if (storedFinalScore.get().equals(roundedScoreStr)) {
            TestRunner.getTest().log(Status.INFO, "Teacher Side Final Score: " + storedFinalScore.get() + " Student Side Score:" + roundedScoreStr);
            TestRunner.getTest().log(Status.PASS, "Test case Passed: Final Score that teacher update also change at student side. Both Side Score match");
            System.out.println("Final Score that teacher update also change at student side. Both Score Match");
        } else {
            TestRunner.getTest().log(Status.INFO, "Teacher Side Final:" + storedFinalScore.get() + " Student Side Score" + roundedScoreStr);
            TestRunner.getTest().log(Status.FAIL, "Test case Failed: Teacher Side Final Score not match with student side score.");
//            throw new RuntimeException("Teacher Side Final Score not match with student side score");
        }
    }

    public void VerifyQuestionsInSelectedStudentTab() throws InterruptedException {
        System.out.println("I'm in attempting all questions with correct answers");
//        Thread.sleep(1000);
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        WebElement questionPlayer = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("lesson-player-ifram")));
        driver.switchTo().frame(questionPlayer);
        WebElement QuestionBody = driver.findElement(By.xpath("//div[contains(@class, 'LessonPlayerRoot')]"));

        WebElement QuestionPlayer = null;

        try {
            List<WebElement> MultiParts = QuestionBody.findElements(By.xpath("//div[contains(@class, 'planComponentQuestion')]"));
            System.out.println("Total number of multi-part on this page: " + MultiParts.size());
            TestRunner.getTest().log(Status.INFO, "Total part of question (if multipart question exists): " + MultiParts.size());

            for (WebElement part : MultiParts) {
                QuestionPlayer = part.findElement(By.xpath(".//div[contains(@class, 'QuestionPlayer')]"));

                System.out.println("Question is found");
                String questionType = QuestionPlayer.getAttribute("data-type");
                System.out.println("Question Type is: " + questionType);
                TestRunner.getTest().log(Status.INFO, "Attempted question type is: " + questionType);

                WebElement questionRoot = QuestionPlayer.findElement(By.xpath(".//div[contains(@class, 'question-root')]"));
                questionID = questionRoot.getAttribute("data-question-id");
                System.out.println("Question ID is: " + questionID);
                TestRunner.getTest().log(Status.INFO, "Attempted question ID is: " + questionID);

            }
        } catch (NoSuchElementException e) {
            System.out.println("This is a content player question and have no any data type question");
            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
        } finally {
            driver.switchTo().defaultContent();
        }
    }

    public void GetStudentWithSubmittedStatus() throws InterruptedException {
        TestRunner.startTest("I'm into Get the student Whose Status is Submitted ");
        System.out.println("I'm into Get the student Whose Status is Submitted ");
        Thread.sleep(2000);

//        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));  // Explicit wait

        int retryCount = 5;  // Retry limit
        for (int attempt = 0; attempt < retryCount; attempt++) {
            try {
                // Re-fetch table and rows on every attempt
                WebElement table = driver.findElement(By.xpath("(//div[contains(@class, 'AssignmentSummary')])[3]"));
                List<WebElement> rows = table.findElements(By.xpath(".//tbody/tr"));

                for (WebElement row : rows) {
                    WebElement studentCell = row.findElement(By.xpath(".//td[1]"));
                    String studentName = studentCell.getText().trim();

                    WebElement statusCell = row.findElement(By.xpath(".//td[2]"));
                    String status = statusCell.getText().trim();

                    if (status.equalsIgnoreCase("Submitted")) {
                        WebElement scoreCell = row.findElement(By.xpath(".//div[contains(@class, 'scorePercentage')]"));
                        String score = scoreCell.getText().trim();

                        if (!score.isEmpty()) {
                            System.out.println("Student: " + studentName + " Status: " + status + " Score: " + score);
                            TestRunner.getTest().log(Status.PASS, "Student: " + studentName + " Status: " + status + " Score: " + score);

                            WebElement statusColumnOption = row.findElement(By.xpath(".//div[contains(@class, 'FinalScorePercentage')]"));
                            WebElement finalScores = statusColumnOption.findElement(By.xpath(".//input[@type='number']"));
                            finalScores.click();

                            String currentText = finalScores.getAttribute("value");
                            for (int i = 0; i < currentText.length(); i++) {
                                actions.sendKeys(Keys.BACK_SPACE).perform();
                            }

                            Random random = new Random();
                            int randomScore = random.nextInt(99);
                            StudentFinalScoreUpdate.set(Integer.toString(randomScore));
//                            StudentFinalScoreUpdate = Integer.toString(randomScore);
                            finalScores.sendKeys(StudentFinalScoreUpdate.get());

                            System.out.println("Entered Final Score: " + StudentFinalScoreUpdate.get());
                            TestRunner.getTest().log(Status.INFO, "Entered Final Score: " + StudentFinalScoreUpdate.get());

                            WebElement markAsGraded = row.findElement(By.xpath(".//div[contains(@class, 'CheckboxesGroupWrapper')]"));
                            WebElement markAsGradedCheckbox = markAsGraded.findElement(By.xpath(".//input[@type='checkbox']"));

                            if (!markAsGradedCheckbox.isSelected()) {
                                markAsGradedCheckbox.click();
                                System.out.println("Checkbox was not selected, now it is checked.");
                                TestRunner.getTest().log(Status.PASS, "Test Case Passed: Mark As Graded' checkbox was not selected, now it is checked.");
                            } else {
                                System.out.println("Checkbox is already checked.");
                                TestRunner.getTest().log(Status.FAIL, "'Mark As Graded' checkbox is already checked.");
                            }

                            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
                        } else {
                            System.out.println("Student: " + studentName + " Status: " + status + " No score available.");
                            TestRunner.getTest().log(Status.FAIL, "Student: " + studentName + " Status: " + status + " No score available.");
                        }
                    } else {
                        // Log the failure if the status is not "Submitted"
                        System.out.println("Test case failed: Status is not 'Submitted' After MArk As Graded is Unchecked. Current Status: " + status);
                        TestRunner.getTest().log(Status.FAIL, "Test case failed: Expected status 'Submitted' but found After MArk As Graded is Unchecked '" + status + "'.");
                        helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
                    }
                }

                break;  // If everything was successful, exit retry loop

            } catch (StaleElementReferenceException e) {
                System.out.println("StaleElementReferenceException caught, retrying... Attempt: " + (attempt + 1));

                if (attempt == retryCount - 1) {
                    throw e;  // Throw exception if the retry limit is reached
                }
            }
        }
    }

    public void VerifyScoresWithNewScores() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm verify new Final Scores That Teacher Update Checking Score Update at student Side");
        System.out.println("I'm verify new Final Scores That Teacher Update Checking Score Update at student Side");

        String assignmentTotalScore = totalScore.get();
        System.out.println("Assignment total score: " + assignmentTotalScore);
        TestRunner.getTest().log(Status.INFO, "Assignment total score: " + assignmentTotalScore);

        String cleanedTotalScore = assignmentTotalScore.replaceAll("%", "").trim();
        System.out.println("Total Score after we remove % : " + cleanedTotalScore);

        double scoreValue = Double.parseDouble(cleanedTotalScore);

        long roundedScore = Math.round(scoreValue);

        String roundedScoreStr = Long.toString(roundedScore);
        System.out.println("Rounded Total Score: " + roundedScoreStr);
        TestRunner.getTest().log(Status.INFO, "Student Side Score : " + roundedScoreStr);


        System.out.println("Final Score That teacher Update Score: " + StudentFinalScoreUpdate.get());
        TestRunner.getTest().log(Status.INFO, "Final Score That teacher Update Score: " + StudentFinalScoreUpdate.get());

        if (StudentFinalScoreUpdate.get().equals(roundedScoreStr)) {
            TestRunner.getTest().log(Status.INFO, "Teacher Side Final Score: " + StudentFinalScoreUpdate.get() + " Student Side Score:" + roundedScoreStr);
            TestRunner.getTest().log(Status.PASS, "Test case Passed: Final Score that teacher update also change at student side. Both Side Score match");
            System.out.println("Final Score that teacher update also change at student side. Both Score Match");
        } else {
            TestRunner.getTest().log(Status.INFO, "Teacher Side Final:" + StudentFinalScoreUpdate.get() + " Student Side Score" + roundedScoreStr);
            TestRunner.getTest().log(Status.FAIL, "Test case Failed: Teacher Side Final Score not match with student side score.");
            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
//            throw new RuntimeException("Teacher Side Final Score not match with student side score");
        }
    }

    public void ScoresUpdateInAssignmentSummary() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Getting Assignment Score Summary");
        System.out.println("Getting Assignment Score Summary");

        Thread.sleep(2000);
//        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
        WebElement assignmentSummary = driver.findElement(By.xpath("//div[contains(@class, 'AssignmentSummaryCountWrappe')]"));
        WebElement countsSummary = assignmentSummary.findElement(By.xpath(".//div[contains(@class, 'AssCountWrapper')][span[text()='Highest Score']]/span[1]"));

        String teacher_score = countsSummary.getText();
        System.out.println("teacher side score: " + teacher_score);

        System.out.println("Highest Score: " + teacher_score);
        TestRunner.getTest().log(Status.INFO, " Highest Score: " + teacher_score);

        System.out.println("Final Score for student: " + StudentFinalScoreUpdate.get());
        TestRunner.getTest().log(Status.INFO, " Final Score for student: " + StudentFinalScoreUpdate.get());

        if (teacher_score.equals(StudentFinalScoreUpdate)) {
            TestRunner.getTest().log(Status.INFO, "Teacher Side Score that teacher update for specific student : " + teacher_score + " is match with New Scores for that student at student side :" + StudentFinalScoreUpdate.get());
            TestRunner.getTest().log(Status.PASS, "Test case Passed: Teacher Side Score that teacher update for specific student is match with New Scores for that student at student side .");
            System.out.println("Score Matches with new Added Score .");
        } else {
            TestRunner.getTest().log(Status.INFO, "Teacher Side Score that teacher update for specific student :" + teacher_score + " Not match with New Scores for that student at student side " + StudentFinalScoreUpdate.get());
            TestRunner.getTest().log(Status.FAIL, "Test case Failed: Teacher Side Score that teacher update for specific student is Not  match with New Scores for that student at student side .");

//            throw new RuntimeException("Scores not match. Scores Not Updated.");
        }
    }


    //  Verify Question Sequence In Summary Tab

    public void QuestionSequenceVerification() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into verify question Sequence That Must be Same at Both Teacher Side and at Student Side");
        System.out.println("I'm into verify question Sequence That Must be Same at both teacher Side and at Student Side");


        List<WebElement> questionTypeElements = driver.findElements(By.xpath("//div[@class='assignment-details-container']//table//tbody//tr[1]//div[contains(@class, 'questionType')]"));
        System.out.println("question Type Elements size at Teacher Side: " + questionTypeElements.size());

        List<String> tableQuestionIds = new ArrayList<>();
        for (WebElement questionElement : questionTypeElements) {
            // Extract the data-question-id attribute
            String questionId = questionElement.getAttribute("data-question-id");
            tableQuestionIds.add(questionId);
        }

        List<String> questionIDsList = CorrectAnswerExecutor_PF.questionIDs.get();

        TestRunner.getTest().log(Status.INFO, "Question Sequence From Student Side: " + questionIDsList);
        System.out.println("Question Sequence From Student Side: " + questionIDsList);
        System.out.println("Question Sequence  array size At student Side: " + questionIDsList.size());

        TestRunner.getTest().log(Status.INFO, "Question Sequence at Teacher Side : " + tableQuestionIds);
        System.out.println("Question Sequence at Teacher Side : " + tableQuestionIds);
        System.out.println("Question Sequence  array size at Teacher Side: " + tableQuestionIds.size());


        if (questionIDsList.size() != tableQuestionIds.size()) {
            System.out.println("The number of questions does not match between Student Side and Teacher Side.");
            TestRunner.getTest().log(Status.FAIL, "Test case Failed: The number of questions does not match between Student Side and Teacher Side.");
            throw new RuntimeException("Mismatch in number of questions between Student and Teacher sides.");
        }

        for (int i = 0; i < questionIDsList.size(); i++) {
            String studentSideId = questionIDsList.get(i);
            String teacherSideId = tableQuestionIds.get(i);

            System.out.println("Student Side Question ID: " + studentSideId);
            TestRunner.getTest().log(Status.INFO, "Student Side Question ID: " + studentSideId);

            System.out.println("Teacher Side Question ID: " + teacherSideId);
            TestRunner.getTest().log(Status.INFO, "Teacher Side Question ID: " + teacherSideId);

            // Compare the IDs at the same index
            if (studentSideId.equals(teacherSideId)) {
                // If IDs match, log success
                TestRunner.getTest().log(Status.INFO, "ID " + studentSideId + " at index " + i + " matches on both Student and Teacher sides.");
                TestRunner.getTest().log(Status.INFO, "Question Sequence Match Question no. " + i + ": Student Side ID = " + studentSideId + ", Teacher Side ID = " + teacherSideId);
                System.out.println("ID " + studentSideId + " at Question no. " + i + " matches on both Student and Teacher sides.");
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: Question Sequence Match at question no. " +
                        "Student Side ID: " + studentSideId + " at question no " + i + " matches with Teacher Side.");
            } else {
                TestRunner.getTest().log(Status.INFO, "Mismatch at index " + i + ": Student Side ID = " + studentSideId + ", Teacher Side ID = " + teacherSideId);
                System.out.println("Mismatch at question no. " + i + ": Student Side ID = " + studentSideId + ", Teacher Side ID = " + teacherSideId);
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed. " +
                        "Mismatch at question no. " + i + ": Student Side ID = " + studentSideId + ", Teacher Side ID = " + teacherSideId);
//                throw new RuntimeException("Mismatch at question no. " + i + ": Student ID = " + studentSideId + ", Teacher ID = " + teacherSideId);
            }
        }

    }

    public void StartAndEndDatePresent() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm in to verify Start And End Date Presence");
        System.out.println("I'm into verify question Sequence That Must be Same at both teacher Side and at Student Side");

        WebElement StartAndEndDate = driver.findElement(By.xpath("//div[contains(@class,'showDateFormat')]"));
        if (StartAndEndDate.isDisplayed()) {
            StartAndEndDate.getText();
            System.out.println("Start and End Date Present: " + StartAndEndDate.getText());
            TestRunner.getTest().log(Status.INFO, "Start and End Date Present: " + StartAndEndDate.getText());
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Start and End Date Found successfully");
        } else {

            System.out.println("Start and End Date not is Displayed");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Start and End Date not Displayed ");
//            throw new RuntimeException("Start and End Date not is Displayed.");
        }
    }

    public void StandardIconSummaryTab() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm in to verify Standard icon Presence");
        System.out.println("I'm in to verify Standard icon Presence");

        WebElement StandardIcon = driver.findElement(By.xpath("//div[@aria-label='Standards']//*[name()='svg']"));

        if (StandardIcon.isDisplayed()) {
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Standard Icon Displayed On Summary Tab");
        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Standard Icon not Displayed ");
//            throw new RuntimeException("Standard Icon not Displayed.");
        }
    }

    public void AssignmentPresenceOnSummaryTab() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm in to verify Assignment name is Present on Summary Tab");
        System.out.println("I'm in to verify Assignment name is Present on Summary Tab");

        WebElement AssessmentName = driver.findElement(By.xpath("//p[@aria-label]"));
        String Assignment_name = AssessmentName.getText();
        System.out.println("Assignment name on Summary Tab is: " + Assignment_name);
        TestRunner.getTest().log(Status.INFO, "Assignment name on Summary Tab is: " + Assignment_name);

        String assignmentNameForCorrect = CorrectAnswerExecutor_PF.assignmentNameForCorrect.get();
        System.out.println("Want to search assessment to verify assignment name: " + assignmentNameForCorrect);
        TestRunner.getTest().log(Status.INFO, "Want to search assessment to verify assignment name: " + assignmentNameForCorrect);

        TestRunner.getTest().log(Status.INFO, "Assignment That is Release and Attempt By Student is: " + assignmentNameForCorrect);
        System.out.println("Assignment That is Release and Attempt By Student is: " + assignmentNameForCorrect);

        TestRunner.getTest().log(Status.INFO, "Verify Assignment Name is match with the Assignment that is created/Assign ");

        if (Assignment_name.equalsIgnoreCase(assignmentNameForCorrect)) {
            System.out.println("Assignment that is release and Attempt By student is Successfully open and name match in Summary tab");
            TestRunner.getTest().log(Status.INFO, "Assignment that is release: " + assignmentNameForCorrect + " and Attempt By student is Successfully open and name match in Summary tab" + Assignment_name);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Assignment name Match " + Assignment_name);
        } else {
            TestRunner.getTest().log(Status.INFO, "Assignment that is release: " + assignmentNameForCorrect + " and Attempt By student is Successfully open and name match in Summary tab" + Assignment_name);
            TestRunner.getTest().log(Status.PASS, "Test Case Failed: Assignment name Not Match " + Assignment_name);
//            throw new RuntimeException("Wrong Assignment open in summary tab.");
        }

    }

    public void clickOnPointsButton() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into click on Points Button on Summary");

        WebElement pointsBtn = driver.findElement(By.xpath("//button[normalize-space()='Points']"));

        if (pointsBtn.isDisplayed()) {
            pointsBtn.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Points Button Click successfully");
        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Points Button not Display/Found");
        }
    }


    public String studentNameFromSummary;
    public String statusFromPoint;
    public String scoreFromSummary;

    public void getStudentPointAndStatus() throws InterruptedException {
        PrintAndVerifyTableInfo();
        PrintAndStoreTableInfo();
        TestRunner.getTest().log(Status.INFO, "Verify Student List and Scores");
        Thread.sleep(2000);
        WebElement table = driver.findElement(By.xpath("//div[contains(@class, 'StudentGradingWrapper')]"));
        List<WebElement> rows = table.findElements(By.xpath(".//tbody/tr"));

        for (WebElement row : rows) {
            WebElement studentCell = row.findElement(By.xpath(".//td[1]"));
            studentNameFromSummary = studentCell.getText().trim();
            System.out.println("Students Name: " + studentNameFromSummary);
            TestRunner.getTest().log(Status.INFO, "Students Name: " + studentNameFromSummary);

            // Check the status of Student
            WebElement statusCell = row.findElement(By.xpath(".//td[2]//input"));
            statusFromPoint = statusCell.getAttribute("value").trim();
            System.out.println("Student Status: " + statusFromPoint);
            TestRunner.getTest().log(Status.INFO, "Student Status: " + statusFromPoint);

            // Check if the status is 'Submitted' or 'Graded'
            if (statusFromPoint.equalsIgnoreCase("Submitted") || statusFromPoint.equalsIgnoreCase("Graded")) {
                WebElement scoreCell = row.findElement(By.xpath(".//td[3]"));
                scoreFromSummary = scoreCell.getText().trim();
                Thread.sleep(500);
                helper.scrollToElement(driver, scoreCell);
                Thread.sleep(2000);

                System.out.println("Student: " + studentNameFromSummary + " Status: " + statusFromPoint + " Original Score: " + scoreFromSummary);
                TestRunner.getTest().log(Status.INFO, "Student: " + studentNameFromSummary + " Status: " + statusFromPoint + " Original Score: " + scoreFromSummary);
                System.out.println("Total Assignment Score in Closed Assignment: " + totalScore.get());
                TestRunner.getTest().log(Status.INFO, "Total Assignment Score in Closed Assignment: " + totalScore.get());
                break;
            }
        }
    }

    public void getPtsOverallFromGradeByStudent() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into get Pts Overall From Grade By Student");

        WebElement ptsOverallElement = driver.findElement(
                By.xpath("//span[normalize-space()='Pts Overall']/preceding-sibling::h6")
        );
        String ptsOverall = ptsOverallElement.getText();
        System.out.println("Pts Overall: " + ptsOverall);

        if (ptsOverall.equalsIgnoreCase(scoreFromSummary)) {
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Pts Overall : " + ptsOverall + " from Grade By Student Match with " + scoreFromSummary + " from Summary");

        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Pts Overall : " + ptsOverall + " from Grade By Student Not Match with " + scoreFromSummary + " from Summary Points");

        }

    }

    public void getStatusFromGradeByStudent() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into get Status From Grade By Student");

        WebElement statusBtn = driver.findElement(By.id("basic-button"));
        String status = statusBtn.getText();
        System.out.println("Get Status from Grade By Student: " + status);
        TestRunner.getTest().log(Status.INFO, "Get Status From Grade By Student: " + status);

        if (status.equalsIgnoreCase(statusFromPoint)) {
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Status: " + status + " from Grade By Student Match with " + statusFromPoint + " from Summary Status");

        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Status: " + status + " from Grade By Student Not Match with " + statusFromPoint + " from Summary Status");
        }

    }

    public void getStudentNameFromGradeByStudent() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm Into get Student Name From Grade By Student");

        WebElement studentInput = driver.findElement(
                By.xpath("(//input[@role='combobox' and contains(@class,'MuiAutocomplete-input')])[1]")
        );
        String studentNameFromGradeByStudent = studentInput.getAttribute("value");
        System.out.println("Student Name From Grade By Student: " + studentNameFromGradeByStudent);
        TestRunner.getTest().log(Status.INFO, "Student Name From Grade By Student: " + studentNameFromGradeByStudent);

        System.out.println("Student Name From Summary: " + studentNameFromSummary);
        TestRunner.getTest().log(Status.INFO, "Student Name From Summary: " + studentNameFromSummary);

        String firstLine = studentNameFromSummary.split("\\n")[0];
        System.out.println("Complete Student Name: " + firstLine);
        TestRunner.getTest().log(Status.INFO, "Complete Student Name: " + firstLine);


        if (studentNameFromGradeByStudent.equalsIgnoreCase(firstLine)) {
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Student Name: " + studentNameFromGradeByStudent + " from Grade By Student Match with " + firstLine + " from Summary Student Name");

        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Student Name: " + studentNameFromGradeByStudent + " from Grade By Student Not Match with " + firstLine + " from Summary Student Name");

        }


    }


    public void PrintAndVerifyTableInfo() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Verifying Table Data");
        Thread.sleep(2000);

        WebElement table = driver.findElement(By.xpath("(//table[contains(@class, 'MuiTable-root')])[1]"));

        List<WebElement> rows = table.findElements(By.xpath(".//tbody/tr"));

        for (WebElement row : rows) {
            List<WebElement> columns = row.findElements(By.xpath(".//td"));

            StringBuilder rowData = new StringBuilder();
            for (WebElement column : columns) {
                rowData.append(column.getText()).append(" | ");
            }

            System.out.println(rowData.toString());
            TestRunner.getTest().log(Status.INFO, rowData.toString());
        }

        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Table data printed successfully.");
    }

    public void PrintAndStoreTableInfo() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Verifying table data in array form");

        Thread.sleep(2000);

        WebElement table = driver.findElement(By.xpath("(//table[contains(@class, 'MuiTable-root')])[1]"));
        List<WebElement> rows = table.findElements(By.xpath(".//tbody/tr"));

        List<String> questionTypes = new ArrayList<>();
        List<String> percentPossible = new ArrayList<>();
        List<String> overallAverage = new ArrayList<>();

        for (WebElement row : rows) {
            String rowHeader = row.findElement(By.xpath(".//td[1]")).getText().trim();
            List<WebElement> cells = row.findElements(By.xpath(".//td[position()>1]"));

            switch (rowHeader) {
                case "Question Type":
                    for (WebElement cell : cells) {
                        String data = cell.getText().trim();
                        questionTypes.add(data);
                    }
                    break;

                case "% Possible":
                    for (WebElement cell : cells) {
                        String data = cell.getText().trim();
                        percentPossible.add(data);
                    }
                    break;

                case "Overall Average":
                    for (WebElement cell : cells) {
                        String data = cell.getText().trim();
                        overallAverage.add(data);
                    }
                    break;

                default:
                    TestRunner.getTest().log(Status.INFO, "Unknown Row Header: " + rowHeader);
                    System.out.println("Unknown Row Header: " + rowHeader);
                    break;
            }
        }

        System.out.println("Question Types when Attempting Assignment: " + CorrectAnswerExecutor_PF.questionTypes.get());
        TestRunner.getTest().log(Status.INFO, "Question Types when Attempting Assignment: " + CorrectAnswerExecutor_PF.questionTypes.get());

        System.out.println("Question Types: " + questionTypes);
        TestRunner.getTest().log(Status.INFO, "Question Types: " + questionTypes);

        System.out.println("% Possible: " + percentPossible);
        TestRunner.getTest().log(Status.INFO, "% Possible: " + percentPossible);

        System.out.println("Overall Average: " + overallAverage);
        TestRunner.getTest().log(Status.INFO, "Overall Average: " + overallAverage);

        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Table data printed and stored successfully.");
    }


    public void addCommentOnEachQuestion() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into Add comments in each question");
        System.out.println("I'm into Add comments in each question");


        if (!isPaginationDisplayedOnGradeByStudent()) {
//            studentExecutor.AssignmentSubmitAsCompleted();
            return;
        }

        System.out.println("I'm here to clear Student Point list");
        generatedComments.clear();
        System.out.println("Teacher Comments  List :" + generatedComments);
        Thread.sleep(2000);

        TestRunner.startTest("Attempt assignment At Teacher Side in Selected Student Tab");

        // Step 1: Click dropdown
        WebElement dropdown = driver.findElement(By.xpath("(//button[@aria-label='Open'])[2]"));
        dropdown.click();
        Thread.sleep(2000);

// Step 2: Get all options inside dropdown list
        List<WebElement> options = driver.findElements(By.xpath("//ul[@role='listbox']//li"));
        int size = options.size();
        System.out.println("Total options: " + size);

// Step 3: Run loop till size - 1
        for (int i = 0; i < size - 1; i++) {
            Thread.sleep(2000);
            VerifyQuestionsInSelectedStudentTab();
            enterCommentsForEachQuestionAndSubmit();
            Thread.sleep(2000);

            // Click arrow for next question
            if (questionsArrow.isEnabled()) {
                questionsArrow.click();
                Thread.sleep(2000);
            } else {
                System.out.println("Arrow disabled, stopping loop...");
                break;
            }
        }

        enterCommentsForEachQuestionAndSubmit();

        System.out.println("New Teacher Comments On Each Question: " + generatedComments);

        TestRunner.getTest().log(Status.INFO, "New Teacher Comments On Each Question: " + generatedComments);

        System.out.println("New Comments Added for Student Successfully ");
        TestRunner.getTest().log(Status.PASS, "Test Case Passed: New Comments Added for Student Successfully");
//            studentExecutor.AssignmentSubmitAsCompleted();
//        } catch (NoSuchElementException | ElementNotInteractableException | TimeoutException e) {
//            System.out.println("No Question found.");
//            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : No Question found or Question not visible");
//        }
    }

    public void enterCommentsForEachQuestionAndSubmit() {
        TestRunner.getTest().log(Status.INFO, "I'm into Enter student Points and Submit that point");
        System.out.println("I'm into Enter student Points and Submit that point");

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(60));

        try {

            // Locate the Add question Comment input field
            WebElement commentInput = wait.until(ExpectedConditions.elementToBeClickable(
                    By.xpath("//button[normalize-space()='+ Question Comment']")  // XPath for the student points field
            ));
            commentInput.click();

            WebElement commentInputArea = driver.findElement(By.xpath("//label[normalize-space()='Question Comment']/following::textarea[1]"));

            Thread.sleep(2000);
            // Clear the existing input in the field
            Actions actions = new Actions(driver);
//            int length = commentInput.getAttribute("value").length();
//            for (int j = 0; j < length; j++) {
//                commentInput.sendKeys(Keys.DELETE);
//            }

// Click on the input field to focus
            actions.click(commentInputArea).perform();

// Retrieve the current value of the input field
            String existingStudentComment = commentInputArea.getAttribute("value");

// Keep deleting characters until the input is empty
            while (existingStudentComment.length() > 0) {
                commentInput.sendKeys(Keys.BACK_SPACE); // You can also use Keys.DELETE depending on the cursor position
                existingStudentComment = commentInput.getAttribute("value"); // Update the current value after each deletion
            }

            System.out.println("Cleared the input field");
            TestRunner.getTest().log(Status.INFO, "Cleared the input field");

            String[] comments = {
                    "Well done",
                    "Needs improvement",
                    "Excellent effort",
                    "Good job on this one",
                    "Please review this concept again",
                    "You can do better next time",
                    "Solid understanding",
                    "Try solving similar problems",
                    "Keep practicing",
                    "Focus on the basics"
            };

            String teacherComment = comments[(int) (Math.random() * comments.length)];

            System.out.println("Generated Teacher Comment: " + teacherComment);

            TestRunner.getTest().log(Status.INFO, "Generated Teacher Comment: " + teacherComment);

            // Enter the new comment
            commentInputArea.sendKeys(teacherComment);

            System.out.println("Add New Teacher comments on Question");

            generatedComments.add(teacherComment);  // Add point to the list

            System.out.println("Teacher Entered Comments: " + teacherComment);
            TestRunner.getTest().log(Status.INFO, "Teacher Entered Comments: " + teacherComment);

//            // Locate and click the save button
            WebElement clickSubmit = driver.findElement(By.xpath("//button[normalize-space()='Save']"));
            clickSubmit.click();
            System.out.println("Submit button clicked successfully");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Submit button clicked successfully.");

            TestRunner.getTest().log(Status.INFO, "I'm in to get Success Message.");
            System.out.println("Get Success Message");
            getSuccessMessage();

        } catch (NoSuchElementException e) {
            System.out.println("Content Type Question Have not Grade Assignment Points");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Content Type Question Have not Grade Assignment Points ");
            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());

        } catch (TimeoutException e) {
            System.out.println("Timed out waiting for element: " + e.getMessage());
            TestRunner.getTest().log(Status.FAIL, "Test case failed: Timeout waiting for element - " + e.getMessage());

        } catch (Exception e) {
            System.out.println("An error occurred: " + e.getMessage());
            TestRunner.getTest().log(Status.FAIL, "Test case failed: Unexpected error - " + e.getMessage());
        }
    }

    @FindBy(xpath = "(//div[contains(@class,'css')]//*[name()='path' and contains(@d,'M2 14L8 8L')]/parent::*[name()='svg'])[2]")
    WebElement questionsArrow;

    private boolean isPaginationDisplayedOnGradeByStudent() {
        try {
            return questionsArrow.isDisplayed();
        } catch (NoSuchElementException | ElementNotInteractableException | TimeoutException e) {
            return false;
        }
    }


    public void verifyTeachersCommentsOnStudentSide() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into verify Teachers Comment on Each Question on Student side");

        WebElement overviewWrapper = driver.findElement(By.xpath("//div[@class='OverviewScreenWrapper MuiBox-root css-0']"));
//        WebElement answer_element = overviewWrapper.findElement(By.xpath(".//div[@class='ScrollbarsCustom-Content']"));

        List<WebElement> button_answers = overviewWrapper.findElements(By.xpath(".//button[@isCorrectAnswer]"));
        System.out.println("Total Answer: " + button_answers.size());
        if (!button_answers.isEmpty()) {
            WebElement button = button_answers.get(0);
            if (button.isDisplayed()) {
                System.out.println("Button was clicked: " + button.getText());
                button.click();
                System.out.println("Answer is clicked.");
                ISCommentExitsOnStudentSide();
            } else {
                System.out.println("Button is not displayed.");
            }
        } else {
            System.out.println("No answer buttons found.");
        }
    }

    public void ISCommentExitsOnStudentSide() throws InterruptedException {

        driver.switchTo().defaultContent();

        try {
            List<WebElement> questionButtons = nav_Pagination.findElements(By.xpath("//button[contains(@aria-label, 'Go to page')]"));
            for (WebElement questionButton : questionButtons) {
                String questionText = questionButton.getText();
                System.out.println("Question: " + questionText);
            }
            while (btn_NavNextPage.isEnabled()) {
                Thread.sleep(2000);
                VerifyStudentSideCommentsWithTeacherComments();
                btn_NavNextPage.click();
                Thread.sleep(2000);
            }

            Thread.sleep(2000);
            WebElement btn_CloseReview = driver.findElement(By.xpath("//button[@id='closeReview-btn']"));
            helper.scrollToElement(driver, btn_CloseReview);
            Thread.sleep(1000);
            System.out.println("Clicked on close review");
            btn_CloseReview.click();
        } catch (NoSuchElementException | ElementNotInteractableException | TimeoutException e) {
            driver.switchTo().defaultContent();
            WebElement btn_CloseReview = driver.findElement(By.xpath("//button[@id='closeReview-btn']"));
            helper.scrollToElement(driver, btn_CloseReview);
            btn_CloseReview.click();
            System.out.println("No Comments are Visible.");
            TestRunner.getTest().log(Status.INFO, "Question Comments not visible");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Question Comments not visible");
        }
    }

    //    int temp1;
    int temp1 = 0; // Initialize the index to 0

    public void VerifyStudentSideCommentsWithTeacherComments() throws InterruptedException {
        System.out.println("I'm in to verify Student Comments that the teacher set");

        // Switch to the iframe where the student's comment is located
        WebElement questionPlayer = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("lesson-player-ifram")));
        driver.switchTo().frame(questionPlayer);

        // Locate the comment at the student's side
        WebElement comment = driver.findElement(By.xpath("//div[@class='commentWrapper']//div[@class='Container']/span[2]"));
        String commentOnAssignmentAttemptStr = comment.getText(); // Get the comment text
        System.out.println("Comment at student side on Assignment: " + commentOnAssignmentAttemptStr);
        TestRunner.getTest().log(Status.INFO, "Comment at student side on Assignment: " + commentOnAssignmentAttemptStr);


        // Print teacher comments list size and content
        TestRunner.getTest().log(Status.INFO, "Size of Teacher Comment Array from teacher side: " + generatedComments.size());
        System.out.println("Size of Teacher Comment Array from teacher side: " + generatedComments.size());
        System.out.println("New Teacher Comments Array from teacher side: " + generatedComments);
        TestRunner.getTest().log(Status.INFO, "New Teacher Comments Array from teacher side: " + generatedComments);


        // Verify if temp1 index is valid for the generated comments list
        if (temp1 < generatedComments.size()) {
            // Retrieve the corresponding teacher comment from the list
            String correspondingTeacherComment = generatedComments.get(temp1);
            System.out.println("Student Comment on Assignment Attempt (Student Side): " + commentOnAssignmentAttemptStr);
            System.out.println("New Teacher Comment: " + correspondingTeacherComment);

            TestRunner.getTest().log(Status.INFO, "Student Comment on Assignment Attempt (Student Side): " + commentOnAssignmentAttemptStr);
            TestRunner.getTest().log(Status.INFO, "Teacher Comment: " + correspondingTeacherComment);

            // Compare student side comment with teacher side comment
            if (commentOnAssignmentAttemptStr.equals(correspondingTeacherComment)) {
                System.out.println("Student comment matches with the teacher-set comment at Question " + temp1 + ": " + commentOnAssignmentAttemptStr);
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: Verified comment matches at Question " + temp1);
            } else {
                System.out.println("Comment mismatch at Question " + temp1 + ": Student's comment is '" + commentOnAssignmentAttemptStr + "' but expected '" + correspondingTeacherComment + "'");
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Comment mismatch at Question " + temp1);
            }

        } else {
            System.out.println("Invalid index: " + temp1);
            TestRunner.getTest().log(Status.FAIL, "Invalid index " + temp1);
        }

        // Move to the next comment for the next question
        temp1++;
        driver.switchTo().defaultContent();
    }


    public void VerifyOnlyUngradedToggle() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm Into Verify Only Ungraded Toggle on Grade By Student");

        // Locate the toggle element
        WebElement toggle = driver.findElement(By.xpath("//input[@value='ungraded']"));

// Check if it is already selected
        if (toggle.isSelected()) {
            System.out.println("Test Case Passed: Toggle Only Ungraded  is already checked.");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Toggle Only Ungraded  is already checked.");
        } else {
            System.out.println("Test Case Failed: Only Ungraded Toggle is not checked.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Toggle Only Ungraded  is already checked.");
        }

    }

    public void VerifyOnlyUnGradedLabelIsDisplay() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into Verify OnlyUnGraded Label Is Display");

        String expectedMessage = "There are no started or submitted student assignments to review.";

        try {
            WebElement messageElement = driver.findElement(
                    By.xpath("//div[contains(text(),'There are no started or submitted student assignments to review.')]")
            );

            if (messageElement.isDisplayed() && messageElement.getText().equals(expectedMessage)) {
                System.out.println("✅ Test Passed: Message is displayed correctly.");
            } else {
                System.out.println("❌ Test Failed: Message is not displayed correctly.");
            }

        } catch (NoSuchElementException e) {
            System.out.println("❌ Test Failed: Message not found on the page.");
        }

    }

    public void verifyDropdownOption() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into verify Dropdown Option For Only Ungraded Toggle");

        WebElement dropdownInput = driver.findElement(
                By.xpath("//div[contains(@class,'MuiAutocomplete-root')]//input[@role='combobox']")
        );

        String actualValue = dropdownInput.getAttribute("value");

        String expectedValue = "None Found";

        if (actualValue.equals(expectedValue)) {
            System.out.println("✅ Test Passed: 'None Found' is displayed in the dropdown.");
            TestRunner.getTest().log(Status.PASS, "✅ Test Passed: 'None Found' is displayed in the dropdown.");
        } else {
            System.out.println("❌ Test Failed: Expected 'None Found' but found '" + actualValue + "'");
            TestRunner.getTest().log(Status.FAIL, "❌ Test Failed: Expected 'None Found' but found '" + actualValue + "'");
        }

    }

    public void verifyStatusIsDisable() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into verify Status Is Disable");

        WebElement button = driver.findElement(By.id("basic-button"));

        String disabledAttr = button.getAttribute("disabled");
        if (disabledAttr != null) {
            System.out.println("✅ Test Passed: Button is disabled.");
            TestRunner.getTest().log(Status.PASS, "✅ Test Passed: Button is disabled.");
        } else {
            System.out.println("❌ Test Failed: Button is enabled.");
            TestRunner.getTest().log(Status.FAIL, "❌ Test Failed: Button is enabled.");
        }

    }


    public void clickGradeByQuestionsTab() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into click Grade By Questions Tab");

        WebElement gradeByQuestionButton = driver.findElement(By.xpath("//button[normalize-space()='Grade by Questions']"));

        if (gradeByQuestionButton.isDisplayed()) {
            gradeByQuestionButton.click();
            System.out.println("Test Case Passed: Grade By Question Activity click successfully");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Grade By Question Activity click successfully");
        } else {
            System.out.println("Test Case Failed: Grade By Question Activity not click/found");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Grade By Question Activity not click/found");
        }
    }


    public void getQuestionsTable() throws InterruptedException {

        TestRunner.getTest().log(Status.INFO, "I'm into Get Questions Table From Grade By Questions Tab");

        // Wait for the table body
        WebElement tableBody = driver.findElement(By.xpath("//div[contains(@class,'MuiTableContainer-root')]//tbody"));

// Get all rows
        List<WebElement> rows = tableBody.findElements(By.tagName("tr"));
        System.out.println("Total Rows: " + rows.size());

// Loop through rows
        for (WebElement row : rows) {
            // Get all columns
            List<WebElement> cols = row.findElements(By.tagName("td"));

            // Extract values
            String question = cols.get(0).getText().trim();
            String questionType = cols.get(1).getText().trim();
            String possible = cols.get(2).getText().trim();
            String overallAvg = cols.get(3).getText().trim();

            // Print row data
            System.out.println("Question: " + question +
                    " | Type: " + questionType +
                    " | % Possible: " + possible +
                    " | Overall Avg %: " + overallAvg);

            TestRunner.getTest().log(Status.INFO, "Question: " + question +
                    " | Type: " + questionType +
                    " | % Possible: " + possible +
                    " | Overall Avg %: " + overallAvg);
        }

    }


    public static ThreadLocal<List<String>> referenceArrayOnGradeByQuestions = ThreadLocal.withInitial(ArrayList::new);

    public void getStandardsFromGradeByQuestions() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into get Standards From Grade By Questions");

        System.out.println("Get Assignment Standards From Grade By Questions");


        try {

            WebElement dialogAssignment = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@role='dialog']")));

            if (dialogAssignment.isDisplayed()) {

                List<WebElement> references = dialogAssignment.findElements(By.xpath(".//table//tr//td[1]"));

                if (references.isEmpty()) {
                    System.out.println("No references found. Empty row data.");
                    TestRunner.getTest().log(Status.FAIL, "No references found. Empty row data.");
                    Thread.sleep(3000);
                    helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());

                    WebElement closeButton = dialogAssignment.findElement(By.xpath(".//button[@aria-label='close']"));
                    closeButton.click();
                    TestRunner.getTest().log(Status.PASS, "Dialog box closed successfully after failed attempt.");
                    return;
                }

                for (WebElement reference : references) {
                    referenceArrayOnGradeByQuestions.get().add(reference.getText().trim());
                }

                for (String reference : referenceArrayOnGradeByQuestions.get()) {
                    System.out.println("Reference: " + reference);
                    TestRunner.getTest().log(Status.INFO, "Reference: " + reference);
                }
                Thread.sleep(3000);
                helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());

                WebElement closeButton = dialogAssignment.findElement(By.xpath(".//button[@aria-label='close']"));
                closeButton.click();
                System.out.println("Dialog box closed successfully.");
                TestRunner.getTest().log(Status.PASS, "Dialog box closed successfully.");

            } else {
                TestRunner.getTest().log(Status.FAIL, "Dialog box not displayed.");
            }

        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "An error occurred while getting assignment standards.");
            e.printStackTrace();
        }
    }

    public void validateStandardMatchOnGradeByQuestions() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into validate Standard Match");
        System.out.println("I'm into validate Standard Match");

        List<String> arr1 = referenceArray.get();
        List<String> arr2 = referenceArrayOnGradeByQuestions.get();

        if (arr1.size() != arr2.size()) {
            System.out.println("❌ Test Failed: Array sizes do not match!");
            TestRunner.getTest().log(Status.FAIL, "❌ Test Failed: Array sizes do not match!");
            System.out.println("Array1: " + arr1);
            TestRunner.getTest().log(Status.INFO, "Standard Array list from Content:" + arr1);
            System.out.println("Array2: " + arr2);
            TestRunner.getTest().log(Status.INFO, "Standard Array list from Grade By Student:" + arr2);
            return;
        }

        boolean allMatch = true;

        for (int i = 0; i < arr1.size(); i++) {
            String val1 = arr1.get(i);
            String val2 = arr2.get(i);

            if (!val1.equals(val2)) {
                System.out.println("❌ Mismatch at index " + i +
                        " -> Expected: " + val1 +
                        ", Found: " + val2);
                TestRunner.getTest().log(Status.FAIL, "❌ Mismatch at index " + i +
                        " -> Expected: " + val1 +
                        ", Found: " + val2);
                allMatch = false;
            }
        }

        if (allMatch) {
            System.out.println("✅ Test Passed: Standard match on Grade By Questions");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Standard match on Grade By Questions");
        } else {
            System.out.println("❌ Test Failed: One/more standard not match on Grade By Questions.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Standard match on Grade By Questions");
        }

    }

    Random rand = new Random();
    List<Integer> updatedValues = new ArrayList<>();


    public void editAllGradesFunctionality() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into Edit All Grades Functionality");

        // Get total rows (once)
        WebElement tableBody = driver.findElement(By.xpath("//div[contains(@class,'MuiTableContainer-root')]//tbody"));
        List<WebElement> rows = tableBody.findElements(By.tagName("tr"));
        System.out.println("Total Rows: " + rows.size());

        // Loop through each row
        for (int i = 0; i < rows.size(); i++) {

            boolean success = false;

            // Retry in case of stale element
            for (int attempt = 0; attempt < 10; attempt++) {
                try {
                    // Always re-locate tableBody and row inside retry loop
                    tableBody = driver.findElement(By.xpath("//div[contains(@class,'MuiTableContainer-root')]//tbody"));
                    WebElement row = tableBody.findElements(By.tagName("tr")).get(i);

                    // Locate "Edit all Grades" button fresh
                    WebElement editAllGradesBtn = row.findElement(By.xpath(".//p[contains(text(),'Edit all Grades')]"));
                    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", editAllGradesBtn);

                    // Click button
                    editAllGradesBtn.click();
                    TestRunner.getTest().log(Status.INFO, "Clicked on 'Edit all Grades' button in row: " + (i + 1));
                    Thread.sleep(1000);

                    TestRunner.getTest().log(Status.INFO, "Add New Points In Edit All Grades");

                    // Locate number input fresh
                    WebElement numberInput = row.findElement(By.xpath(".//input[contains(@type,'number')]"));

                    // Old value
                    String oldValue = numberInput.getAttribute("value");
                    System.out.println("Old value in row " + (i + 1) + ": " + oldValue);

                    // Clear and enter new value
                    numberInput.click();
                    numberInput.sendKeys(Keys.chord(Keys.CONTROL, "a"));
                    numberInput.sendKeys(Keys.DELETE);
                    Thread.sleep(300);

                    int newValue = rand.nextInt(100) + 1;
                    numberInput.sendKeys(String.valueOf(newValue));

                    String enteredValue = numberInput.getAttribute("value");
                    System.out.println("Entered value in row " + (i + 1) + ": " + enteredValue);

                    updatedValues.add(Integer.parseInt(enteredValue));

                    Thread.sleep(1000);

                    WebElement tableClick= driver.findElement(By.xpath("//div[contains(@class,'TableOptionsContainer')]"));
                    tableClick.click();
//                    TestRunner.getTest().log(Status.INFO, "Clicked on the row for row: " + (i + 1));

                    Thread.sleep(1000);

                    verifyAdjustingQuestionScorePromptDisplay();
                    clickSaveButtonOnAdjustingQuestionScore();
                    verifySuccessAlertMessage();
                    Thread.sleep(3000);

                    success = true; // ✅ success, break retry loop
                    break;

                } catch (StaleElementReferenceException e) {
                    System.out.println("⚠️ StaleElement detected in row " + (i + 1) + " retrying... attempt " + (attempt + 1));
                    Thread.sleep(500); // small wait before retry
                }
            }

            if (!success) {
                TestRunner.getTest().log(Status.WARNING, "Failed to process row " + (i + 1) + " due to repeated stale element issues.");
            }
        }

        // After finishing the loop
        System.out.println("All Updated Values: " + updatedValues);
        TestRunner.getTest().log(Status.INFO, "All Updated Value in Edit All Grades are: " + updatedValues);

// ✅ Calculate sum
        int sum = updatedValues.stream().mapToInt(Integer::intValue).sum();

// ✅ Calculate average
        average = updatedValues.isEmpty() ? 0 : (double) sum / updatedValues.size();

        System.out.println("Sum of Updated Values: " + sum);
        System.out.println("Average of Updated Values: " + average);

        TestRunner.getTest().log(Status.INFO, "Sum of Updated Values: " + sum);
        TestRunner.getTest().log(Status.INFO, "Average of Updated Values: " + average);

    }

    double average;
    double scoreValue;

    public void verifyAdjustingQuestionScorePromptDisplay() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm Into Verify that Adjusting Question Score Prompt Display");

        Thread.sleep(2000);

        WebElement prompt = driver.findElement(By.xpath("//div[@role='dialog']"));
        boolean isDisplayed = prompt.isDisplayed();
        Assert.assertTrue("Prompt is not displayed.", isDisplayed);

        WebElement promptHeader = prompt.findElement(By.tagName("h2"));
        String headerText = promptHeader.getText();
        System.out.println("Prompt header text is: " + headerText);
        TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  Prompt Display Successfully");

        WebElement text = driver.findElement(By.xpath("//div[contains(@class,'MuiDialogContent-root')]"));

        String dialogueBoxText = text.getText();
        System.out.println("Adjusting Question Score Prompt Text: " + dialogueBoxText);

        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Text successfully Display on Adjusting Question Score Prompt");

    }

    public void clickSaveButtonOnAdjustingQuestionScore() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into click on Save Button On Adjusting Question Score");

        WebElement saveBtn = driver.findElement(By.xpath("//button[normalize-space()='Save']"));

        if (saveBtn.isDisplayed() && saveBtn.isEnabled()) {
            saveBtn.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Save Button click successfully");
        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Save Button is not Display/Enabled");
        }
    }

    public void verifySuccessAlertMessage() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into get Success Alert Message");

        wait.pollingEvery(Duration.ofMillis(20));

        try {
            WebElement toastContainer = wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("toastr")));

            try {
                if (toastContainer.isDisplayed()) {
                    toastContainer = driver.findElement(By.className("toastr"));
                    String actualBackgroundColor = toastContainer.getCssValue("background-color");

                    String expectedBackgroundColor = "rgb(96, 187, 113)";
                    String expectedBackgroundColorWithAlpha = "rgba(96, 187, 113, 1)";

                    System.out.println("Captured Background Color: " + actualBackgroundColor);

                    if (actualBackgroundColor.equals(expectedBackgroundColor) || actualBackgroundColor.equals(expectedBackgroundColorWithAlpha)) {
                        System.out.println("Test case Passed: Background color is as expected (" + actualBackgroundColor + ").");

                        String messageTitle = toastContainer.findElement(By.className("rrt-title")).getText();
                        String messageText = toastContainer.findElement(By.className("rrt-text")).getText();

                        System.out.println("Message Title: " + messageTitle);
                        TestRunner.getTest().log(Status.INFO, "Success toast title is: " + messageTitle);
                        System.out.println("Message Text: " + messageText);
                        TestRunner.getTest().log(Status.INFO, "Success toast message is: " + messageText);

                        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Shows success message toast");

                    } else {
                        System.out.println("Test case Failed: Background color is not as expected. Actual: " + actualBackgroundColor);
                        TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Shows error toast with background color " + actualBackgroundColor);

                        String errorMessageTitle = toastContainer.findElement(By.className("rrt-title")).getText();
                        String errorMessageText = toastContainer.findElement(By.className("rrt-text")).getText();

                        System.out.println("Message Title: " + errorMessageTitle);
                        TestRunner.getTest().log(Status.INFO, "Error toast title is: " + errorMessageTitle);
                        System.out.println("Message Text: " + errorMessageText);
                        TestRunner.getTest().log(Status.INFO, "Error toast message is: " + errorMessageText);
                    }

                } else {
                    TestRunner.getTest().log(Status.FAIL, "Toast message is not displayed.");
                }
            } catch (StaleElementReferenceException staleEx) {
                TestRunner.getTest().log(Status.WARNING, "Toast element became stale. Retrying...");

                toastContainer = wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("toastr")));
                String retryBackgroundColor = toastContainer.getCssValue("background-color");

                System.out.println("Retried Background Color: " + retryBackgroundColor);
                TestRunner.getTest().log(Status.INFO, "Retried and captured background color: " + retryBackgroundColor);
            }

        } catch (TimeoutException e) {
            TestRunner.getTest().log(Status.FAIL, "Toast message did not appear in the expected time.");
        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "Unexpected error while verifying toast message: " + e.getMessage());
        }
    }


    public void verifyPercentageAlsoUpdate() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "verify % Grades also update on Student side after Edit All Grades ");


        WebElement overviewWrapper = driver.findElement(By.xpath("//div[contains(@class,'OverviewScreenWrapper')]"));


        WebElement percentageScore = overviewWrapper.findElement(By.xpath(".//div[@class='score']"));

        String scoreText = percentageScore.getText();   // e.g. "69.2 %"
        scoreText = scoreText.replace("%", "").trim();  // "69.2"

        System.out.println("Clean Score: " + scoreText);

        TestRunner.getTest().log(Status.INFO, "Clean Score: " + scoreText);


        scoreValue = Double.parseDouble(scoreText);
        System.out.println("Numeric Score: " + scoreValue);

        TestRunner.getTest().log(Status.INFO, "Updated % From Student side: " + scoreValue);

        compareTeacherSidePercentageScoreWithNewStudentSidePercentage();


        TestRunner.getTest().log(Status.INFO, "Now Click on Close Review Button ");

        Thread.sleep(2000);
        WebElement btn_CloseReview = overviewWrapper.findElement(By.xpath(".//button[normalize-space()='Close Review']"));
        helper.scrollToElement(driver, btn_CloseReview);
        Thread.sleep(1000);
        System.out.println("Clicked on close review");
        btn_CloseReview.click();

    }

    public void compareTeacherSidePercentageScoreWithNewStudentSidePercentage() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Now Compare Teacher side Edit Grades Value to Verify Student side score updation");

        if (average == scoreValue) {
            System.out.println("Values are equal");

            TestRunner.getTest().log(Status.PASS, "Test Case Passed: % value After Edit From Teacher side:  " + average + " match with new % value " + scoreValue + "on Student side");
        } else {
            System.out.println("Values are NOT equal");

            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: % value After Edit From Teacher side:  " + average + " Not match with new % value " + scoreValue + "on Student side");
        }

    }

    public void clickPointsOption() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into click on Points Option");

        WebElement PointsButton = driver.findElement(By.xpath("//button[normalize-space()='Points']"));

        if (PointsButton.isDisplayed() && PointsButton.isEnabled()) {
            PointsButton.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Points Button Click Successfully");
        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Points Button not Displayed/Enabled");
        }
    }

    List<Double> updatedValuesInPoints = new ArrayList<>();


    public void editAllGradesFunctionalityInPoints() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into Edit All Grades Functionality In Points");

        WebElement tableBody = driver.findElement(By.xpath("//div[contains(@class,'MuiTableContainer-root')]//tbody"));
        List<WebElement> rows = tableBody.findElements(By.tagName("tr"));
        System.out.println("Total Rows: " + rows.size());


        for (int i = 0; i < rows.size(); i++) {
            boolean success = false;

            for (int attempt = 0; attempt < 10; attempt++) {
                try {

                    tableBody = driver.findElement(By.xpath("//div[contains(@class,'MuiTableContainer-root')]//tbody"));
                    WebElement row = tableBody.findElements(By.tagName("tr")).get(i);

                    WebElement possibleElement = row.findElement(By.xpath("./td[3]"));
                    String possibleText = possibleElement.getText().trim();
                    double possibleValue = Double.parseDouble(possibleText);
                    System.out.println("Possible value in row " + (i + 1) + ": " + possibleValue);

                    WebElement editAllGradesBtn = row.findElement(By.xpath(".//p[contains(text(),'Edit all Grades')]"));
                    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", editAllGradesBtn);
                    editAllGradesBtn.click();
                    TestRunner.getTest().log(Status.INFO, "Clicked on 'Edit all Grades' button in row: " + (i + 1));
                    Thread.sleep(1000);

                    TestRunner.getTest().log(Status.INFO, "Add New Points In Edit All Grades");

                    WebElement numberInput = row.findElement(By.xpath(".//input[contains(@type,'number')]"));

                    String oldValue = numberInput.getAttribute("value");
                    System.out.println("Old value in row " + (i + 1) + ": " + oldValue);

                    numberInput.click();
                    numberInput.sendKeys(Keys.chord(Keys.CONTROL, "a"));
                    numberInput.sendKeys(Keys.DELETE);
                    Thread.sleep(300);

                    double newValue = Math.round((Math.random() * possibleValue) * 100.0) / 100.0;
                    numberInput.sendKeys(String.format("%.2f", newValue));

                    String enteredValue = numberInput.getAttribute("value");
                    System.out.println("Entered value in row " + (i + 1) + ": " + enteredValue);
                    updatedValuesInPoints.add(Double.parseDouble(enteredValue));

                    Thread.sleep(1000);
                    WebElement tableClick= driver.findElement(By.xpath("//div[contains(@class,'TableOptionsContainer')]"));
                    tableClick.click();

//                    TestRunner.getTest().log(Status.INFO, "Clicked on the row for row: " + (i + 1));
                    Thread.sleep(1000);

                    verifyAdjustingQuestionScorePromptDisplay();
                    clickSaveButtonOnAdjustingQuestionScore();
                    verifySuccessAlertMessage();
                    Thread.sleep(3000);

                    success = true;
                    break;

                } catch (StaleElementReferenceException e) {
                    System.out.println("⚠️ StaleElement detected in row " + (i + 1) + " retrying... attempt " + (attempt + 1));
                    Thread.sleep(500);
                }
            }

            if (!success) {
                TestRunner.getTest().log(Status.WARNING, "Failed to process row " + (i + 1) + " due to repeated stale element issues.");
            }
        }

        System.out.println("All Updated Values: " + updatedValuesInPoints);
        TestRunner.getTest().log(Status.INFO, "All Updated Value in Edit All Grades are: " + updatedValuesInPoints);
    }


    public void validateNewPointsUpdateForEachQuestion() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into Validate New Point Update For Each Question");


        if (!isPaginationDisplayedOnGradeByStudent()) {
            return;
        }

        WebElement dropdown = driver.findElement(By.xpath("(//button[@aria-label='Open'])[2]"));
        dropdown.click();
        Thread.sleep(2000);

        List<WebElement> options = driver.findElements(By.xpath("//ul[@role='listbox']//li"));
        int size = options.size();
        System.out.println("Total options: " + size);

        for (int i = 0; i < size - 1; i++) {
            Thread.sleep(2000);
            VerifyQuestionsInSelectedStudentTab();
            getScoreOfEachQuestion();
            Thread.sleep(2000);

            if (questionsArrow.isEnabled()) {
                questionsArrow.click();
                Thread.sleep(2000);
            } else {
                System.out.println("Arrow disabled, stopping loop...");
                break;
            }
        }

        getScoreOfEachQuestion();

    }

    public void getScoreOfEachQuestion() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Get Score Of Each Question After Edit From Edit All Grades Option");

        try {

            WebElement scoreInput = driver.findElement(By.xpath("//input[@type='number']"));


            String scoreStr = scoreInput.getAttribute("value").trim();
            double scoreValue = Double.parseDouble(scoreStr);

            System.out.println("Score value on Grade By Student: " + scoreValue);

            if (temp.get() < updatedValuesInPoints.size()) {
                double teacherValue = updatedValuesInPoints.get(temp.get());

                System.out.println("Teacher Updated Value at index " + temp.get() + ": " + teacherValue);

                if (Math.abs(scoreValue - teacherValue) < 0.01) {
                    System.out.println("✅ Score matches with Teacher Updated Value!");
                    TestRunner.getTest().log(Status.PASS,
                            "Test Case Passed: Score matches at index " + temp.get() + " Value from Grade By Questions is: " + teacherValue + " Value from Grade By Student " + scoreValue);
                } else {
                    System.out.println("❌ Mismatch -> Student: " + scoreValue + " | Teacher: " + teacherValue);

                    TestRunner.getTest().log(Status.FAIL,
                            "Test Case Failed: Score mismatch at index " + temp.get() + " Value from Grade By Questions is: " + teacherValue + " But Value from Grade By Student " + scoreValue);

                }
            } else {
                System.out.println("⚠️ Invalid index: " + temp.get());
                TestRunner.getTest().log(Status.FAIL, "Invalid index " + temp.get());
            }

            temp.set(temp.get() + 1);


        } catch (NoSuchElementException e) {
            System.out.println("Content Type Question Have not Grade Assignment Points");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Content Type Question Have not Grade Assignment Points ");
            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());

        } catch (TimeoutException e) {
            System.out.println("Timed out waiting for element: " + e.getMessage());
            TestRunner.getTest().log(Status.FAIL, "Test case failed: Timeout waiting for element - " + e.getMessage());

        } catch (Exception e) {
            System.out.println("An error occurred: " + e.getMessage());
            TestRunner.getTest().log(Status.FAIL, "Test case failed: Unexpected error - " + e.getMessage());
        }
    }


    public void VerifyNewStudentPointsAfterEditAll() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into verify new Student Points After Edit All Grades ");

        WebElement overviewWrapper = driver.findElement(By.xpath("//div[contains(@class,'OverviewScreenWrapper')]"));

        List<WebElement> button_answers = overviewWrapper.findElements(By.xpath(".//button[@isCorrectAnswer]"));
        System.out.println("Total Answer: " + button_answers.size());
        if (!button_answers.isEmpty()) {
            WebElement button = button_answers.get(0);
            if (button.isDisplayed()) {
                System.out.println("Button was clicked: " + button.getText());
                button.click();
                System.out.println("Answer is clicked.");
                isNewPointExist();
            } else {
                System.out.println("Button is not displayed.");
            }
        } else {
            System.out.println("No answer buttons found.");
        }
    }

    public void isNewPointExist() throws InterruptedException {

        driver.switchTo().defaultContent();
        temp.set(0);
        try {

            List<WebElement> questionButtons = nav_Pagination.findElements(By.xpath("//button[contains(@aria-label, 'Go to page')]"));
            for (WebElement questionButton : questionButtons) {
                String questionText = questionButton.getText();
                System.out.println("Question: " + questionText);
            }

            while (btn_NavNextPage.isEnabled()) {
                Thread.sleep(2000);
                VerifyNewPointsWithNewTeacherPointsAfterEditAll();
                btn_NavNextPage.click();
                Thread.sleep(2000);
            }

            TestRunner.getTest().log(Status.INFO, "I'm into click on Close Review Button");
            Thread.sleep(2000);
            WebElement btn_CloseReview = driver.findElement(By.xpath("//button[@id='closeReview-btn']"));
            helper.scrollToElement(driver, btn_CloseReview);
            Thread.sleep(1000);
            System.out.println("Clicked on close review");
            btn_CloseReview.click();
        } catch (NoSuchElementException | ElementNotInteractableException | TimeoutException e) {
            driver.switchTo().defaultContent();
            WebElement btn_CloseReview = driver.findElement(By.xpath("//button[@id='closeReview-btn']"));
            helper.scrollToElement(driver, btn_CloseReview);
            btn_CloseReview.click();
            System.out.println("No Points are Visible.");
            TestRunner.getTest().log(Status.INFO, "Question Points not visible");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Question Points not visible");
        }
    }

    public void VerifyNewPointsWithNewTeacherPointsAfterEditAll() throws InterruptedException {
        System.out.println("I'm in to verify Student Points that teacher set ");

        WebElement questionPlayer = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("lesson-player-ifram")));
        driver.switchTo().frame(questionPlayer);

        WebElement points = driver.findElement(By.xpath("//div[@class='pointWrapper']//span[1]"));
        String weightOnAssignmentAttemptStr = points.getText();
        System.out.println("Points At student Side on Assignment: " + weightOnAssignmentAttemptStr);

        double weightOnAssignmentAttempt = Double.parseDouble(weightOnAssignmentAttemptStr);

        System.out.println("Size of Student Point Array from teacher side: "
                + updatedValuesInPoints.size());

        System.out.println("New Student Points Array from teacher Side: "
                + updatedValuesInPoints.size());
        TestRunner.getTest().log(Status.INFO, "New Student Points Array from teacher Side: " + updatedValuesInPoints.size());

        if (temp.get() < updatedValuesInPoints.size()) {
            double correspondingWeight = updatedValuesInPoints.get(temp.get());
            System.out.println("Student Points on Assignment Attempt Student Side: " + weightOnAssignmentAttempt);
            TestRunner.getTest().log(Status.INFO, "Student Points on Assignment Attempt Student Side: " + weightOnAssignmentAttempt);

            System.out.println("New Student Point that Teacher change: " + correspondingWeight);
            TestRunner.getTest().log(Status.INFO, "New Student Point that Teacher change: " + correspondingWeight);

            if (weightOnAssignmentAttempt == correspondingWeight) {
                System.out.println("Student Points on assignment attempt matches with Points that Teacher set at index " + temp.get() + ": " + weightOnAssignmentAttempt);
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: Verified Point matches at index " + temp.get());
            } else {
                System.out.println("Point mismatch at index " + temp.get() + ": Assignment Point is " + weightOnAssignmentAttempt + " but expected teacher set " + correspondingWeight);
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Student Points mismatch at index " + temp.get());
            }
        } else {
            System.out.println("Invalid index: " + temp.get());
            TestRunner.getTest().log(Status.FAIL, "Invalid index " + temp.get());
        }

        temp.set(temp.get() + 1);

        driver.switchTo().defaultContent();
    }


    double scoreValueFromTable;

    public void getPointsAndVerifyEachQuestionOnGradeByQuestions() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Get Points And Verify Each Question On Grade By Questions");

        TestRunner.getTest().log(Status.INFO, "Get Points from 4th column and Click Questions in 1st column");

        WebElement tableBody = driver.findElement(By.xpath("//div[contains(@class,'MuiTableContainer-root')]//tbody"));
        List<WebElement> rows = tableBody.findElements(By.tagName("tr"));
        System.out.println("Total Rows: " + rows.size());

        for (int i = 0; i < rows.size(); i++) {
            boolean success = false;

            for (int attempt = 0; attempt < 5; attempt++) {
                try {

                    tableBody = driver.findElement(By.xpath("//div[contains(@class,'MuiTableContainer-root')]//tbody"));
                    WebElement row = tableBody.findElements(By.tagName("tr")).get(i);

                    WebElement scoreElement = row.findElement(By.xpath("./td[4]//span"));
                    String scoreText = scoreElement.getText().trim();
                    scoreValueFromTable = Double.parseDouble(scoreText);
                    System.out.println("Row " + (i + 1) + " → Score: " + scoreValueFromTable);

                    updatedValuesInPoints.add(scoreValueFromTable);

                    WebElement questionLink = row.findElement(By.xpath("./td[1]//a"));
                    String questionName = questionLink.getText().trim();
                    System.out.println("Clicking Question Link: " + questionName);

                    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", questionLink);
                    questionLink.click();
                    TestRunner.getTest().log(Status.INFO, "Clicked on Question link: " + questionName);

                    // wait for navigation / new page load
                    Thread.sleep(2000);

                    getStudentNameFromDropDown();
                    Thread.sleep(1000);
                    getStudentNameFromHeader();
                    Thread.sleep(1000);
                    validateStudentName();
                    Thread.sleep(1000);
                    validateScore();

                    WebElement gradeByQuestionButton = driver.findElement(By.xpath("//button[normalize-space()='Grade by Questions']"));

                    if (gradeByQuestionButton.isDisplayed()) {
                        gradeByQuestionButton.click();
                        System.out.println("Test Case Passed: Grade By Question Activity click successfully");
                        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Grade By Question Activity click successfully");
                    } else {
                        System.out.println("Test Case Failed: Grade By Question Activity not click/found");
                        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Grade By Question Activity not click/found");
                    }

                    Thread.sleep(2000);

                    success = true;
                    break;

                } catch (StaleElementReferenceException e) {
                    System.out.println("⚠️ StaleElement in row " + (i + 1) + ", retrying attempt " + (attempt + 1));
                    Thread.sleep(1000);
                }
            }

            if (!success) {
                TestRunner.getTest().log(Status.WARNING, "⚠️ Failed to process row " + (i + 1) + " due to repeated stale elements.");
            }
        }

        System.out.println("✅ Final Updated Values from Column 4: " + updatedValuesInPoints);
        TestRunner.getTest().log(Status.INFO, "All Scores stored from 4th column: " + updatedValuesInPoints);
    }

    String studentNameFromDropdown;
    String studentNameFromHeader;

    public void getStudentNameFromDropDown() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into get Student name From Dropdown");

        WebElement inputElement = driver.findElement(By.xpath("(//input[@type='text' and contains(@class,'MuiAutocomplete-input')])[2]"));

        studentNameFromDropdown = inputElement.getAttribute("value").trim();

        if (studentNameFromDropdown.isEmpty() || studentNameFromDropdown.equalsIgnoreCase("None Found")) {
            System.out.println("❌ Invalid value: " + studentNameFromDropdown);
            TestRunner.getTest().log(Status.FAIL, "Student Name is invalid: " + studentNameFromDropdown);
        } else {
            System.out.println("✅ Valid student name: " + studentNameFromDropdown);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Student Name:  " + studentNameFromDropdown + " get successfully");
        }

    }

    public void getStudentNameFromHeader() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into get Student Name From Header");

        WebElement iframeElement = driver.findElement(By.xpath("//iframe[@id='lesson-player-ifram']"));
        driver.switchTo().frame(iframeElement);

        WebElement studentNameElement = driver.findElement(By.xpath("//div[contains(@class,'currentStudentHeader')]"));
        studentNameFromHeader = studentNameElement.getText().trim();

        if (studentNameFromHeader.isEmpty() || studentNameFromHeader.equalsIgnoreCase("None Found")) {
            System.out.println("❌ Invalid student name: " + studentNameFromHeader);
            TestRunner.getTest().log(Status.FAIL, "Student Name Not found in Header: " + studentNameFromHeader);
        } else {
            System.out.println("✅ Student name: " + studentNameFromHeader);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Student Name from Header:  " + studentNameFromHeader + " get successfully");
        }

        driver.switchTo().defaultContent();

    }

    public void validateStudentName() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into verify student name from dropdown and from header");

        if (studentNameFromDropdown.trim().equalsIgnoreCase(studentNameFromHeader.trim())) {
            System.out.println("✅ Both student names match: " + studentNameFromDropdown);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Student Name From Dropdown: " + studentNameFromDropdown + " match with Student Name From Header: " + studentNameFromHeader);
        } else {
            System.out.println("❌ Names do not match!");
            System.out.println("From Dropdown: " + studentNameFromDropdown);
            System.out.println("From Header: " + studentNameFromHeader);
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Student Name From Dropdown: " + studentNameFromDropdown + " not match with Student Name From Header: " + studentNameFromHeader);
        }

    }

    public void validateScore() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into Validate Score");

        Thread.sleep(2000);

        WebElement scoreInput = driver.findElement(By.xpath("//input[@type='number']"));

        String scoreValue = scoreInput.getAttribute("value");

        double scoreFromGradeByStudent = Double.parseDouble(scoreValue);

        System.out.println("Score From Grade By Student: " + scoreFromGradeByStudent);
        TestRunner.getTest().log(Status.INFO, "Score From Grade By Student: " + scoreFromGradeByStudent);

        TestRunner.getTest().log(Status.INFO, "Now Compare score from OverAllAverage From Table and From Grade By Student Score");

        if (scoreValueFromTable == scoreFromGradeByStudent) {

            System.out.println("Score From Table: " + scoreValueFromTable);
            System.out.println("Score From Grade By Student: " + scoreFromGradeByStudent);
            TestRunner.getTest().log(Status.INFO, "Score From Table: " + scoreValueFromTable);
            TestRunner.getTest().log(Status.INFO, "Score From Grade By Student: " + scoreFromGradeByStudent);
            System.out.println("Test Case Passed: Score From Table: " + scoreValueFromTable + " match with score from Grade By Student: " + scoreFromGradeByStudent);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Score From Table: " + scoreValueFromTable + " match with score from Grade By Student: " + scoreFromGradeByStudent);

        } else {
            System.out.println("Test Case Failed: Score From Table: " + scoreValueFromTable + " not match with score from Grade By Student: " + scoreFromGradeByStudent);
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Score From Table: " + scoreValueFromTable + " not match with score from Grade By Student: " + scoreFromGradeByStudent);

        }
    }


    public void validateAndClickStandardsCorrelation() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into validate And Click Standards Correlation");

        WebElement standardsCorrelationBtn = driver.findElement(By.xpath("//button[normalize-space()='Standards Correlation']"));

        if (standardsCorrelationBtn.isEnabled() && standardsCorrelationBtn.isDisplayed()) {
            standardsCorrelationBtn.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: 'Standards Correlation' Button Click successfully");
        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: 'Standards Correlation' Button not enabled/displayed");
        }
    }

    public void validateStandardsCorrelationPrompt() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into validate Standards Correlation Prompt");

        WebElement StandardsCorrelationPrompt = driver.findElement(By.xpath("//div[@role='dialog']"));
        boolean isDisplayed = StandardsCorrelationPrompt.isDisplayed();
        Assert.assertTrue("Prompt is not displayed.", isDisplayed);

// ✅ Step 1: Get heading text
        WebElement promptHeader = StandardsCorrelationPrompt.findElement(By.tagName("h2"));
        String headerText = promptHeader.getText().trim();
        System.out.println("Prompt header text is: " + headerText);

// ✅ Step 2: Verify heading matches expected
        String expectedHeading = "Standards Correlation";
        Assert.assertEquals("Prompt heading does not match!", expectedHeading, headerText);


        System.out.println("Test Case Passed: Prompt displayed successfully with correct heading.");
        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Prompt displayed successfully with correct heading.");

    }

    public void standardsDropdown() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into verify standards dropdown on standards correlation prompt");

        // Step 1: Click the dropdown to expand options
        WebElement dropdown = driver.findElement(By.xpath("//label[normalize-space()='Standard(s)']/following-sibling::div//div[@role='combobox']"));
        dropdown.click();
        Thread.sleep(1000); // wait for options to appear

// Step 2: Capture all options from the dropdown list
        List<WebElement> options = driver.findElements(By.xpath("//ul[@role='listbox']//li"));

// Step 3: Validate if options exist
        if (options.size() > 0) {
            System.out.println("✅ Dropdown has " + options.size() + " option(s).");

            // Click the first option (or modify index/text as needed)
            WebElement firstOption = options.get(0);
            System.out.println("Clicking option: " + firstOption.getText());
            TestRunner.getTest().log(Status.INFO, "Dropdown selected option → " + firstOption.getText());
            firstOption.click();

            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Dropdown option selected successfully");
        } else {
            System.out.println("❌ Dropdown has no options!");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Dropdown has no options available.");
            Assert.fail("Dropdown has no options available!");
        }

    }

    public void validateStandardsViewClicked() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into validate Standards View Already Clicked");


        WebElement standardsViewBtn = driver.findElement(By.id("simple-tab-0"));
        String isSelected = standardsViewBtn.getAttribute("aria-selected");

        if ("true".equals(isSelected)) {
            System.out.println("✅ Standards View button is already clicked (selected).");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: ✅ Standards View button is already clicked (selected).");
        } else {
            System.out.println("❌ Standards View button is not clicked.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: ❌ Standards View button is not clicked.");
        }

    }

    public void getAllStandardsFromStandardsView() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into get All Standards From Standards View");

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        Function<String, String> normalize = (text) -> {
            if (text == null) return "";
            return text.replaceAll("[\\t\\n\\r]+", " ")
                    .replaceAll("\\s{2,}", " ")
                    .trim();
        };

        WebElement panel = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("simple-tabpanel-0")));

        List<WebElement> headings = panel.findElements(By.xpath(".//div[@class='standard-heading']"));

        LinkedHashMap<String, LinkedHashMap<String, List<String>>> hierarchy = new LinkedHashMap<>();

        String currentTop = null;
        String currentSub = null;

        for (WebElement heading : headings) {

            String code = "";
            String label = "";
            try {
                code = normalize.apply(heading.findElement(By.xpath("./span[1]")).getText());
            } catch (NoSuchElementException e) { /* ignore */ }
            try {
                label = normalize.apply(heading.findElement(By.xpath("./span[2]")).getText());
            } catch (NoSuchElementException e) { /* ignore */ }

            if (code.startsWith("FL.SS")) {
                currentTop = code + " " + label;
                hierarchy.put(currentTop, new LinkedHashMap<>());
            } else if (code.startsWith("SS.")) {
                if (currentTop == null) {
                    currentTop = "UNKNOWN_TOP";
                    hierarchy.putIfAbsent(currentTop, new LinkedHashMap<>());
                }
                currentSub = code + " " + label;
                hierarchy.get(currentTop).put(currentSub, new ArrayList<>());

                WebElement liAncestor;
                try {
                    liAncestor = heading.findElement(By.xpath("ancestor::li[contains(@class,'li-container')][1]"));
                } catch (NoSuchElementException ex) {
                    liAncestor = heading.findElement(By.xpath("./..")); // fallback
                }

                List<WebElement> accordions = liAncestor.findElements(By.xpath(".//div[contains(@class,'MuiAccordionSummary-root')]"));
                for (WebElement acc : accordions) {
                    String expanded = acc.getAttribute("aria-expanded");
                    if (expanded == null || "false".equals(expanded)) {
                        try {
                            acc.click();
                            wait.until(ExpectedConditions.attributeToBe(acc, "aria-expanded", "true"));
                        } catch (Exception ignored) {}
                    }
                }

                List<WebElement> resources = liAncestor.findElements(By.xpath(".//div[contains(@class,'btn-container')]"));
                for (WebElement res : resources) {
                    String main = "";
                    String sub = "";
                    try {
                        main = normalize.apply(res.findElement(By.xpath(".//div[@class='title']/span[1]")).getText());
                    } catch (NoSuchElementException e1) {
                        try {
                            main = normalize.apply(res.findElement(By.xpath(".//div[@class='title']")).getText().split("\\n")[0]);
                        } catch (Exception ignore) {}
                    }
                    try {
                        sub = normalize.apply(res.findElement(By.xpath(".//div[@class='title']/span[2]")).getText());
                        if (sub.isEmpty()) {
                            sub = normalize.apply(res.findElement(By.xpath(".//div[@class='title']//p")).getText());
                        }
                    } catch (NoSuchElementException e2) {
                        sub = "";
                    }
                    String combined = main + (sub.isEmpty() ? "" : " → " + sub);
                    hierarchy.get(currentTop).get(currentSub).add(combined);
                }
            }
        }

        // === Log Standards using TestRunner instead of System.out ===
        for (Map.Entry<String, LinkedHashMap<String, List<String>>> topEntry : hierarchy.entrySet()) {
            String top = normalize.apply(topEntry.getKey());
            if (!top.isEmpty()) TestRunner.getTest().log(Status.INFO, top);

            for (Map.Entry<String, List<String>> subEntry : topEntry.getValue().entrySet()) {
                String sub = normalize.apply(subEntry.getKey());
                if (!sub.isEmpty()) TestRunner.getTest().log(Status.INFO, "    " + sub);

                for (String r : subEntry.getValue()) {
                    r = normalize.apply(r);
                    if (!r.isEmpty()) TestRunner.getTest().log(Status.INFO, "        " + r);
                }
            }
        }
    }

    public void closeDialogueBox() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into click on close button");

        WebElement closeBtn= driver.findElement(By.xpath("//button[@aria-label='close']"));

        if (closeBtn.isDisplayed()){
            closeBtn.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: 'X' button click successfully");
        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: 'X' button not found");
        }
    }

    public void clickCoursesView() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into click on Courses View");

        WebElement coursesViewBtn= driver.findElement(By.xpath("//button[@id='simple-tab-1']"));

        if (coursesViewBtn.isDisplayed())
        {
            coursesViewBtn.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Courses View Click successfully");
        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Courses View Not Found");
        }
    }


    public void getCoursesViewList() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into get Courses View List From Standards Correlation");

        JavascriptExecutor js = (JavascriptExecutor) driver;

        // Get all main headings (the divs, not just <p>, so we can navigate properly)
        List<WebElement> mainHeadings = driver.findElements(By.xpath("//div[@class='standard-heading']"));

        for (int i = 0; i < mainHeadings.size(); i++) {
            WebElement mainHeading = mainHeadings.get(i);
            String headingText = mainHeading.getText().trim();
            System.out.println("Main Heading: " + headingText);

            TestRunner.getTest().log(Status.INFO, "📌 Main Heading: " + headingText);


            // Find all <li> after this heading
            List<WebElement> accordions = mainHeading.findElements(By.xpath("following-sibling::li"));

            // If not the last heading, stop before the next heading
            if (i < mainHeadings.size() - 1) {
                WebElement nextHeading = mainHeadings.get(i + 1);

                // Filter accordions so we only take those that appear before the next heading
                accordions = accordions.stream()
                        .filter(acc -> acc.getLocation().getY() < nextHeading.getLocation().getY())
                        .collect(Collectors.toList());
            }

            for (WebElement accordion : accordions) {
                try {
                    // Sub-heading
                    WebElement titleElement = accordion.findElement(By.xpath(".//div[@class='title']/span[1]"));
                    String subHeadingText = titleElement.getText().trim();
                    System.out.println("   Sub-Heading: " + subHeadingText);
                    TestRunner.getTest().log(Status.INFO, "   🔹 Sub-Heading: " + subHeadingText);


                    // Human coding scheme
                    List<WebElement> codes = accordion.findElements(
                            By.xpath(".//div[@class='humanCodingScheme']//div[@class='chip']")
                    );

                    for (WebElement code : codes) {
                        // Scroll into view before reading
                        js.executeScript("arguments[0].scrollIntoView({block: 'center'});", code);
                        String codeText = code.getText().trim();
                        System.out.println("      Code: " + codeText);
                        TestRunner.getTest().log(Status.INFO, "      🧾 Code: " + codeText);

                    }

                } catch (Exception e) {
                    System.out.println("   [Skipped one accordion due to missing elements]");
                }
            }
        }
        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Course View Standards Correlation List Get Successfully");
    }



    public static ThreadLocal<List<String>> referenceArrayOnSummary = ThreadLocal.withInitial(ArrayList::new);

    public void getStandardsFromSummary() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into get Standards From Grade By Questions");

        System.out.println("Get Assignment Standards From Grade By Questions");

        try {

            WebElement dialogAssignment = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@role='dialog']")));

            if (dialogAssignment.isDisplayed()) {

                List<WebElement> references = dialogAssignment.findElements(By.xpath(".//table//tr//td[1]"));

                if (references.isEmpty()) {
                    System.out.println("No references found. Empty row data.");
                    TestRunner.getTest().log(Status.FAIL, "No references found. Empty row data.");
                    Thread.sleep(3000);
                    helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());

                    WebElement closeButton = dialogAssignment.findElement(By.xpath(".//button[@aria-label='close']"));
                    closeButton.click();
                    TestRunner.getTest().log(Status.PASS, "Dialog box closed successfully after failed attempt.");
                    return;
                }

                for (WebElement reference : references) {
                    referenceArrayOnSummary.get().add(reference.getText().trim());
                }

                for (String reference : referenceArrayOnSummary.get()) {
                    System.out.println("Reference: " + reference);
                    TestRunner.getTest().log(Status.INFO, "Reference: " + reference);
                }
                Thread.sleep(3000);
                helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());

                WebElement closeButton = dialogAssignment.findElement(By.xpath(".//button[@aria-label='close']"));
                closeButton.click();
                System.out.println("Dialog box closed successfully.");
                TestRunner.getTest().log(Status.PASS, "Dialog box closed successfully.");

            } else {
                TestRunner.getTest().log(Status.FAIL, "Dialog box not displayed.");
            }

        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "An error occurred while getting assignment standards.");
            e.printStackTrace();
        }
    }

    public void validateStandardMatchOnSummary() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into validate Standard Match");
        System.out.println("I'm into validate Standard Match");

        List<String> arr1 = referenceArray.get();
        List<String> arr2 = referenceArrayOnSummary.get();

        if (arr1.size() != arr2.size()) {
            System.out.println("❌ Test Failed: Array sizes do not match!");
            TestRunner.getTest().log(Status.FAIL, "❌ Test Failed: Array sizes do not match!");
            System.out.println("Array1: " + arr1);
            TestRunner.getTest().log(Status.INFO, "Standard Array list from Content:" + arr1);
            System.out.println("Array2: " + arr2);
            TestRunner.getTest().log(Status.INFO, "Standard Array list from Grade By Student:" + arr2);
            return;
        }

        boolean allMatch = true;

        for (int i = 0; i < arr1.size(); i++) {
            String val1 = arr1.get(i);
            String val2 = arr2.get(i);

            if (!val1.equals(val2)) {
                System.out.println("❌ Mismatch at index " + i +
                        " -> Expected: " + val1 +
                        ", Found: " + val2);
                TestRunner.getTest().log(Status.FAIL, "❌ Mismatch at index " + i +
                        " -> Expected: " + val1 +
                        ", Found: " + val2);
                allMatch = false;
            }
        }

        if (allMatch) {
            System.out.println("✅ Test Passed: Standard match on Grade By Questions");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Standard match on Grade By Questions");
        } else {
            System.out.println("❌ Test Failed: One/more standard not match on Grade By Questions.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Standard match on Grade By Questions");
        }

    }

    public void printOnSummary() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into click on Print Button on Summary");

        WebElement printBtn= driver.findElement(By.xpath("//button[@id='btn-print']"));

        if (printBtn.isDisplayed()){
            printBtn.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Print Button click successfully");
        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Print Button Not Display/Enabled");
        }
    }


    public void validateStudentListOnSummary() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into get Validate Student List Display on Summary Screen");

        // Get all student names inside table rows (ignore heading)
        List<WebElement> studentNames = driver.findElements(
                By.xpath("//td//div[contains(@class,'GradingStudentWrapper')]//p")
        );

// Validate that at least 1 student exists
        if (studentNames.size() > 0) {
            TestRunner.getTest().log(Status.PASS, "✅ Student list is displayed. Total students: " + studentNames.size());
            System.out.println("Test Case Passed:✅ Student list is displayed. Total students: " + studentNames.size());

            // Print all names in TestRunner log
            for (WebElement student : studentNames) {
                TestRunner.getTest().log(Status.INFO, "Student Name On Summary: " + student.getText());
                System.out.println("Student Name On Summary: " + student.getText());
            }
        } else {
            TestRunner.getTest().log(Status.FAIL, "❌ Student list is empty! At least 1 student is required.");
            Assert.fail("Student list is not found on Summary Screen!");
        }

    }

    public void verifyQuestionListDisplay() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into Verify Question List Display Before student Attempt Assignment");

        TestRunner.getTest().log(Status.INFO, "I'm into Get Questions Table From Grade By Questions Tab");

        // Check if table body exists
        List<WebElement> tableBodies = driver.findElements(
                By.xpath("//div[contains(@class,'MuiTableContainer-root')]//tbody")
        );
        if (tableBodies.isEmpty()) {
            TestRunner.getTest().log(Status.FAIL, "Questions table is NOT displayed!");
        }

        WebElement tableBody = tableBodies.get(0);

// Get all rows
        List<WebElement> rows = tableBody.findElements(By.tagName("tr"));
        if (rows.isEmpty()) {
            TestRunner.getTest().log(Status.FAIL, "No questions found in table!");
        }

        System.out.println("Total Rows: " + rows.size());

// Loop through rows
        for (WebElement row : rows) {
            // Get all columns
            List<WebElement> cols = row.findElements(By.tagName("td"));

            // Check column count before accessing
            if (cols.size() < 4) {
                TestRunner.getTest().log(Status.FAIL, "Row does not contain all expected columns");

            }

            // Ensure question cell has no <a> tag
            List<WebElement> linksInQuestion = cols.get(0).findElements(By.tagName("a"));
            if (!linksInQuestion.isEmpty()) {
                TestRunner.getTest().log(Status.FAIL, "Question contains <a> tag which is not allowed!");

            }

            // Extract values safely
            String question = cols.get(0).getText().trim();
            String questionType = cols.get(1).getText().trim();
            String possible = cols.get(2).getText().trim();
            String overallAvg = cols.get(3).getText().trim();

            // Print row data
            System.out.println("Question: " + question +
                    " | Type: " + questionType +
                    " | % Possible: " + possible +
                    " | Overall Avg %: " + overallAvg);

            TestRunner.getTest().log(Status.INFO, "Question: " + question +
                    " | Type: " + questionType +
                    " | % Possible: " + possible +
                    " | Overall Avg %: " + overallAvg);
        }
    }

}

