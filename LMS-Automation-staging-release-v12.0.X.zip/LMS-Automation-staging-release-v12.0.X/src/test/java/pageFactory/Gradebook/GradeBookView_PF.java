package pageFactory.Gradebook;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Assignmment.CorrectAnswerExecutor_PF;
import pageFactory.Assignmment.ReleaseAssignment_PF;
import pageFactory.MyContent.AssignAssessment_PF;
import pageFactory.MyContent.CreateAssessment_PF;
import org.openqa.selenium.ElementNotInteractableException;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static pageFactory.MyContent.CreateAssessment_PF.CustomAssessmentName;

public class GradeBookView_PF {

    WebDriverWait wait;
    WebDriver driver;
    Helper helper;

    Actions actions;

    PositiveTestCaseGradeBook_PF positiveTestCaseGradeBook_pf;

    CreateAssessment_PF createAssessment_pf;
    SelectedStudent_PF selectedStudent_pf;

    @FindBy(xpath = "//div[contains(@class, 'StudentListingAndTableWrapper')]")
    WebElement studentAssignmentTable;

    @FindBy(xpath = "//nav[@aria-label='pagination navigation']")
    WebElement nav_Pagination;

    @FindBy(xpath = "//button[@aria-label='Go to next page']")
    WebElement btn_NavNextPage;

    public static String assignmentComment = "Automated Assignment Comments by Teacher - Test";

    public static List<String> generatedComments = new ArrayList<>();


    public GradeBookView_PF(WebDriver driver) {
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        helper = new Helper();
        PageFactory.initElements(driver, this);
        positiveTestCaseGradeBook_pf = new PositiveTestCaseGradeBook_PF(driver);
        createAssessment_pf = new CreateAssessment_PF(driver);
        selectedStudent_pf = new SelectedStudent_PF(driver);
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        actions = new Actions(driver);

    }

    public void searchAssignmentNamesForView(String assignmentName) throws InterruptedException {

        WebElement assignmentTable = wait.until(ExpectedConditions.visibilityOf(studentAssignmentTable));

        List<WebElement> assignmentContainers = assignmentTable.findElements(By.xpath(".//thead//tr//th"));
        System.out.println("Total Assignment Names are: " + assignmentContainers.size());

        for (
                int i = 0; i < assignmentContainers.size(); i++) {
            WebElement assignment = assignmentContainers.get(i);
            String assignmentsName = assignment.getText();
            System.out.println("Assignment Name: " + assignmentsName);

            if (assignmentsName.equalsIgnoreCase(assignmentName)) {
                System.out.println("Found assignment: " + assignmentsName);

                boolean staleElement = true;
                while (staleElement) {
                    try {
                        // Re-locate the assignment element to avoid stale element issues
                        assignmentContainers = assignmentTable.findElements(By.xpath(".//thead//tr//th"));
                        assignment = assignmentContainers.get(i);

                        // Wait until the assignment is clickable
                        wait.until(ExpectedConditions.elementToBeClickable(assignment));
                        assignment.click();
                        staleElement = false; // Break the loop as element is successfully clicked

                        System.out.println("Assignment found");
                        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Assignment found successfully " + assignmentsName);

                        // Perform other actions
                        Thread.sleep(1000);
                        ClickOnViewButton();
                        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Click on View button successfully " + assignmentsName);


                    } catch (StaleElementReferenceException e) {
                        System.out.println("StaleElementReferenceException occurred. Retrying...");
                        staleElement = true; // Continue the loop to re-locate and retry
                    } catch (NoSuchElementException e) {
                        TestRunner.getTest().log(Status.FAIL, "Test Case Failed: View button not found for assignment: " + assignmentName);
                        return;
                    }
                }
                break; // Exit loop once the desired assignment is found and processed
            }
        }
    }

    private void ClickOnViewButton() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm in to select View Option from Menu");
        System.out.println("View button");
//        Thread.sleep(2000);
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        List<WebElement> listAssignment = driver.findElements(By.xpath("//ul[@role='menu']"));
        System.out.println("I'm in to click on View button");

        for (WebElement option : listAssignment) {
            List<WebElement> buttons = option.findElements(By.tagName("button"));

            for (WebElement button : buttons) {
                String buttonText = button.getText().trim();

                if (buttonText.equals("View") && button.isEnabled() && button.isDisplayed()) {
                    button.click();
                    System.out.println("Clicked on View button.");
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed: View Button Click Successfully");
                    return;
                }
            }
        }
    }

    public void TeacherAddAssignmentComments() throws InterruptedException {
        try {
            TestRunner.getTest().log(Status.INFO, "I'm in to Add Assignment Comments for Assignment");
            System.out.println("I'm in to Add Assignment Comments for Assignment");

            WebElement table = driver.findElement(By.xpath("//div[contains(@class, 'StudentGradingWrapper')]"));
            List<WebElement> rows = table.findElements(By.xpath(".//tbody/tr"));

            boolean assignmentFound = false; // Flag to track if assignment is found

            for (WebElement row : rows) {
                WebElement studentCell = row.findElement(By.xpath(".//td[1]"));
                String studentName = studentCell.getText().trim();
                System.out.println("Students Name: " + studentName);
                TestRunner.getTest().log(Status.INFO, "Students Name: " + studentName);

                // Check the status of Student
                WebElement statusCell = row.findElement(By.xpath(".//td[2]//input"));
                String status = statusCell.getAttribute("value").trim();
                System.out.println("Student Status: " + status);
                TestRunner.getTest().log(Status.INFO, "Student Status: " + status);

                // Check if the status is 'Submitted' or 'Graded'
                if (status.equalsIgnoreCase("Submitted") || status.equalsIgnoreCase("Graded")) {
                    TestRunner.getTest().log(Status.INFO, "Student Name: " + studentName + " | Student Status: " + status);
                    assignmentFound = true; // Mark assignment as found
                    WebElement addCommentCell = row.findElement(By.xpath(".//td[5]//button[@type='button'][normalize-space()='Add Comment']"));
                    Thread.sleep(500);
                    helper.scrollToElement(driver, addCommentCell);
                    Thread.sleep(2000);

                    if (addCommentCell != null) {
                        String commentBtnText = addCommentCell.getText();
                        System.out.println("AddCommentCell text: " + commentBtnText);
                        TestRunner.getTest().log(Status.INFO, "AddCommentCell text: " + commentBtnText);

                        if (addCommentCell.isDisplayed() && addCommentCell.isEnabled()) {
                            addCommentCell.click();
                            System.out.println("Add Comment button clicked successfully");
                            TestRunner.getTest().log(Status.PASS, "Add Comment button clicked successfully");
                            WebElement menuBox = wait.until(ExpectedConditions.visibilityOfElementLocated(
                                    By.xpath("//div[contains(@class, 'MuiPopover-paper')]")));

                            WebElement commentTextArea = menuBox.findElement(By.xpath("//textarea[@aria-invalid='false' and not(@readonly)]"));

                            if (commentTextArea.isDisplayed() && commentTextArea.isEnabled()) {
                                commentTextArea.click();
                                Thread.sleep(2000);
                                commentTextArea.sendKeys(assignmentComment);
                                JavascriptExecutor js = (JavascriptExecutor) driver;
                                System.out.println("Comment Entered successfully: " + assignmentComment);
                                TestRunner.getTest().log(Status.INFO, "Assignment Comment Entered: " + assignmentComment);
                                TestRunner.getTest().log(Status.PASS, "Test Case Passed: Assignment Comment Entered successfully");
                                Thread.sleep(5000);
                                helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());

                                String actualComment = (String) js.executeScript("return arguments[0].value;", commentTextArea);

                                if (assignmentComment.equals(actualComment)) {
                                    System.out.println("Comment verified successfully before save.");
                                    TestRunner.getTest().log(Status.PASS, "Comment verified via JS: " + actualComment);
                                } else {
                                    System.out.println("Comment mismatch via JS. Expected: " + assignmentComment + ", Found: " + actualComment);
                                    TestRunner.getTest().log(Status.FAIL, "Comment mismatch before save. Found: " + actualComment);
                                }

                                TestRunner.getTest().log(Status.INFO, "I'm in to Click on Save Button for Assignment Comments");
                                System.out.println("I'm in to Click on Save Button for Assignment Comments");

                                WebElement btn_save = menuBox.findElement(By.xpath("//button[normalize-space()='Save']"));

                                if (btn_save.isDisplayed() && btn_save.isEnabled()) {
                                    if (assignmentComment.equals(actualComment)) {
                                        System.out.println("Comment verified successfully after save.");
                                        TestRunner.getTest().log(Status.PASS, "Comment verified via JS: " + actualComment);
                                    } else {
                                        System.out.println("Comment mismatch via JS. Expected: " + assignmentComment + ", Found: " + actualComment);
                                        TestRunner.getTest().log(Status.FAIL, "Comment mismatch after save. Found: " + actualComment);
                                    }
                                    Thread.sleep(2000);
                                    btn_save.click();
                                    System.out.println("Save Button is enabled and clicked ");
                                    TestRunner.getTest().log(Status.INFO, "Save Button is clicked successfully");
                                    TestRunner.getTest().log(Status.PASS, "Test Case Passed: Save Button clicked successfully");

                                    Thread.sleep(1000);
                                } else {
                                    System.out.println("Save Button is disabled.");
                                    TestRunner.getTest().log(Status.FAIL, "Save Button is disabled");
                                }

                            } else {
                                System.out.println("Add Comment dialog box is not visible or not enabled.");
                                TestRunner.getTest().log(Status.FAIL, "Add Comment dialog box is not visible or not enabled.");
                            }
                        } else {
                            System.out.println("Add Comment button is either not visible or not enabled.");
                            TestRunner.getTest().log(Status.FAIL, "Add Comment button is either not visible or not enabled.");
                        }
                    } else {
                        System.out.println("Add Comment button element not found.");
                        TestRunner.getTest().log(Status.FAIL, "Add Comment button element not found.");
                    }
                    break;
                } else {
                    System.out.println("No any Submitted or Graded assignment status found");
                }
            }

            if (!assignmentFound) {
                TestRunner.getTest().log(Status.FAIL, "No any Submitted or Graded assignment status found");
                System.out.println("No any Submitted or Graded assignment status found");
            }

        } catch (Exception e) {
            System.out.println("Exception while entering assignment comment: " + e.getMessage());
            TestRunner.getTest().log(Status.FAIL, "Exception while entering assignment comment: " + e.getMessage());
        }
    }

    public void TeacherAddAssignmentCommentsUpdatedUI() throws InterruptedException {
        try {
            TestRunner.getTest().log(Status.INFO, "I'm in to Add Assignment Comments for Assignment");
            System.out.println("I'm in to Add Assignment Comments for Assignment");

            // Wait for the menu box to be visible
            WebElement menuBox = wait.until(ExpectedConditions.visibilityOfElementLocated(
                    By.xpath("//div[contains(@class, 'MuiPopover-paper')]")));

            // Locate the visible textarea for comment input
            WebElement commentTextArea = menuBox.findElement(By.xpath("//textarea[@aria-invalid='false' and not(@readonly)]"));

            // Check if the commentTextArea is displayed and enabled
            if (commentTextArea != null && commentTextArea.isDisplayed() && commentTextArea.isEnabled()) {

                // Focus the textarea before typing
                commentTextArea.click();  // Focus on the textarea
                Thread.sleep(2000);
                commentTextArea.sendKeys(assignmentComment);

                // Use JavascriptExecutor to set the value and dispatch the 'input' event
                JavascriptExecutor js = (JavascriptExecutor) driver;
//                js.executeScript("arguments[0].value = arguments[1]; arguments[0].dispatchEvent(new Event('input'));", commentTextArea, assignmentComment);

                System.out.println("Comment Entered successfully: " + assignmentComment);
                TestRunner.getTest().log(Status.INFO, "Assignment Comment Entered: " + assignmentComment);
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: Assignment Comment Entered successfully");

                // Wait for a moment
                Thread.sleep(5000);
                helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());

                // Verify the entered comment using JavascriptExecutor
                String actualComment = (String) js.executeScript("return arguments[0].value;", commentTextArea);

                if (assignmentComment.equals(actualComment)) {
                    System.out.println("Comment verified successfully before save.");
                    TestRunner.getTest().log(Status.PASS, "Comment verified via JS: " + actualComment);
                } else {
                    System.out.println("Comment mismatch via JS. Expected: " + assignmentComment + ", Found: " + actualComment);
                    TestRunner.getTest().log(Status.FAIL, "Comment mismatch before save. Found: " + actualComment);
                }

                TestRunner.getTest().log(Status.INFO, "I'm in to Click on Save Button for Assignment Comments");
                System.out.println("I'm in to Click on Save Button for Assignment Comments");

                // Locate and click on the Save button
                WebElement btn_save = menuBox.findElement(By.xpath("//button[normalize-space()='Save']"));

                // Check if the Save button is enabled and clickable
                if (btn_save.isDisplayed() && btn_save.isEnabled()) {
                    js.executeScript("arguments[0].style.border='3px solid red';", btn_save);
                    Thread.sleep(3000);
                    btn_save.click();

                    System.out.println("Save Button is enabled and clicked ");
                    TestRunner.getTest().log(Status.INFO, "Save Button is clicked successfully");
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed: Save Button clicked successfully");

                    // After clicking save, verify the comment again
                    if (assignmentComment.equals(actualComment)) {
                        System.out.println("Comment verified successfully after save.");
                        TestRunner.getTest().log(Status.PASS, "Comment verified via JS: " + actualComment);
                    } else {
                        System.out.println("Comment mismatch via JS. Expected: " + assignmentComment + ", Found: " + actualComment);
                        TestRunner.getTest().log(Status.FAIL, "Comment mismatch after save. Found: " + actualComment);
                    }

                    Thread.sleep(2000); // Wait for any potential UI update
                } else {
                    System.out.println("Save Button is disabled.");
                    TestRunner.getTest().log(Status.FAIL, "Save Button is disabled");
                }

            } else {
                System.out.println("Add Comment dialog box is not visible or not enabled.");
                TestRunner.getTest().log(Status.FAIL, "Add Comment dialog box is not visible or not enabled.");
            }
        } catch (Exception e) {
            System.out.println("Exception while entering assignment comment: " + e.getMessage());
            TestRunner.getTest().log(Status.FAIL, "Exception while entering assignment comment: " + e.getMessage());
        }
    }

    public void SubmitButtonComments() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm in to Click on Submit Button for Assignment Comments");
        System.out.println("I'm in to Click on Submit Button for Assignment Comments");

        WebElement btn_submit= driver.findElement(By.xpath("//button[@type='button'][normalize-space()='Submit']"));

        if (btn_submit.isDisplayed() && btn_submit.isEnabled()){
            btn_submit.click();
            System.out.println("Submit Button is Enable and clicked ");
            TestRunner.getTest().log(Status.INFO, "Submit Button is enable and clicked successfully" );
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Submit Button is enable and clicked successfully");

        } else {
            System.out.println("Submit Button is Disable.");
            TestRunner.getTest().log(Status.FAIL, "Submit Button is Disable");
        }
    }


    public void VerificationOfTeacherCommentOnStudentSide() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm in to Verify Teacher Comments Show on Student Side");
        System.out.println("I'm in to Verify Teacher Comments Show on Student Side");

        WebElement commentWrapper = driver.findElement(By.xpath("//div[@class='commentWrapper']"));

        if (commentWrapper.isDisplayed()) {
            WebElement secondSpan = commentWrapper.findElement(By.xpath(".//div[@class='Container']/span[2]"));

            String currentComment = secondSpan.getText();
            System.out.println("Comment on Student side: " + currentComment);
            System.out.println("Comment on Teacher side: " + assignmentComment);

            TestRunner.getTest().log(Status.INFO, "Student Side Comment: " + currentComment);
            TestRunner.getTest().log(Status.INFO, "Teacher Side Comment: " + assignmentComment);

            if (currentComment.equalsIgnoreCase(assignmentComment)) {
                System.out.println("The comments match: " + currentComment + " student side Comments. " + assignmentComment + " Teacher Side comment match");
                TestRunner.getTest().log(Status.INFO, "Teacher Side Comment: " + assignmentComment + ", Student Side Comment: " + currentComment + " match");
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: The comments match: " + currentComment);
            } else {
                System.out.println("The comments do not match. Teacher Side Comment: " + assignmentComment + ", Student Side Comment: " + currentComment);
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: The comments do not match. Teacher Side Comment: " + assignmentComment + ", Student Side Comment: " + currentComment);
            }
        } else {
            System.out.println("The Comments not displayed at Student Side");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: The Comments not displayed at Student Side");
        }
    }

//    GradeBook Filter Category

    @FindBy(xpath = "//label[normalize-space()='Categories']/parent::div") // Locate the dropdown
    WebElement dropdown_select_category;

    @FindBy(xpath = "//label[normalize-space()='Assignment Type']/parent::div") // Locate the dropdown
    WebElement dropdown_Assignment_Type;

    public void SelectCategoryFromGradeBook(String selectedCategory) throws InterruptedException{
        Thread.sleep(1000);
//        new WebDriverWait(driver, Duration.ofSeconds(30));
        TestRunner.getTest().log(Status.INFO, "I'm in to select Category");

        TestRunner.getTest().log(Status.INFO, " select Category From Assignment Release: " + selectedCategory);
        System.out.println("select Category From Assignment Release: " + selectedCategory);
            dropdown_select_category.click();
            WebElement listCategory = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//ul[@role='listbox']")));

            List<WebElement> optionsCategory = listCategory.findElements(By.xpath(".//li"));

            System.out.println("Category List is: " + optionsCategory.size());

            if (optionsCategory.isEmpty()) {
                System.out.println("No options found in the Category dropdown.");
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : No options found in the Category dropdown.");
                throw new RuntimeException("No Category Found.");

            } else {
                System.out.println("Category:");

                for (WebElement category : optionsCategory) {
                    System.out.println(category.getText());
                    if (category.getText().equals(selectedCategory)) {
                        category.click();
                        TestRunner.getTest().log(Status.INFO, "Clicked on Category : " + selectedCategory);
                        System.out.println("Clicked on Category: " + selectedCategory);
                        TestRunner.getTest().log(Status.PASS, "Testcase Passed   :  Category selected successfully");
                        break;
                    }
                }
            }

            Actions actions = new Actions(driver);
            actions.sendKeys(Keys.ESCAPE).build().perform();
    }

    public void SelectAssignmentTypeFromGradeBook(String selectedAssignmentType) throws InterruptedException{
        Thread.sleep(3000);
//        new WebDriverWait(driver, Duration.ofSeconds(30));
        TestRunner.getTest().log(Status.INFO, "I'm in to select Assignment Type");
        TestRunner.getTest().log(Status.INFO, " select Assignment Type From Assignment Release: " + selectedAssignmentType);
        System.out.println("select Category From Assignment Release: " + selectedAssignmentType);

        dropdown_Assignment_Type.click();
        Thread.sleep(2000);
        WebElement listAssignmentType = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//ul[@role='listbox']")));

        List<WebElement> optionsAssignmentType = listAssignmentType.findElements(By.xpath(".//li"));

        System.out.println("Assignment Type List is: " + optionsAssignmentType.size());

        if (optionsAssignmentType.isEmpty()) {
            System.out.println("No options found in the Assignment Type dropdown.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : No options found in the Assignment Type dropdown.");
            throw new RuntimeException("No Assignment Type Found.");

        } else {
            System.out.println("Assignment Type:");

            for (WebElement AssignmentType : optionsAssignmentType) {
                System.out.println(AssignmentType.getText());
                if (AssignmentType.getText().equals(selectedAssignmentType)) {
                    AssignmentType.click();
                    TestRunner.getTest().log(Status.INFO, "Clicked on Assignment Type : " + selectedAssignmentType);
                    System.out.println("Clicked on Assignment Type: " + selectedAssignmentType);
                    TestRunner.getTest().log(Status.PASS, "Testcase Passed   :  Assignment Type selected successfully");
                    break;
                }
            }
        }

        Actions actions = new Actions(driver);
        actions.sendKeys(Keys.ESCAPE).build().perform();
    }

    public void SelectStartDate(String startDate) throws InterruptedException {
        Thread.sleep(1000);

        System.out.println("Start Date From Assignment Release: " + startDate);
        TestRunner.getTest().log(Status.INFO, "Start Date From Assignment Release: " + startDate);

        WebElement edt_StartDate;
        try {
            edt_StartDate = driver.findElement(By.xpath("//label[contains(text(),'Start')]/following-sibling::div//input"));
        } catch (NoSuchElementException e) {
            System.out.println("Start Date input field not found!");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Start Date input field not found!");
            return; // to make sure it doesn't continue if Assert doesn't stop execution
        }

        System.out.println("Now removing time from start date and changing format");

        LocalDateTime dateTime = LocalDateTime.parse(startDate);

        DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
        String formattedDate = dateTime.format(outputFormatter);

        System.out.println("Formatted Date: " + formattedDate);
        TestRunner.getTest().log(Status.INFO, "Start date " + formattedDate);

        edt_StartDate.sendKeys(formattedDate);
        System.out.println("Start date is entered: " + formattedDate);
        TestRunner.getTest().log(Status.PASS, "Start date entered: " + formattedDate);
    }
    public void SelectEndDate(String endDate) throws InterruptedException {
        Thread.sleep(1000);  // Consider using WebDriverWait instead for better stability

        System.out.println("End Date From Assignment Release: " + endDate);
        TestRunner.getTest().log(Status.INFO, "End Date From Assignment Release: " + endDate);

        WebElement edt_EndDate;
        try {
            edt_EndDate = driver.findElement(By.xpath("//label[contains(text(),'End')]/following-sibling::div//input"));
        } catch (NoSuchElementException e) {
            System.out.println("End Date input field not found!");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : End Date input field not found!");
            return;
        }

        System.out.println("Now removing time from End Date and changing format");

        LocalDateTime dateTime = LocalDateTime.parse(endDate);

        DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
        String formattedDate = dateTime.format(outputFormatter);

        System.out.println("Formatted End Date: " + formattedDate);
        TestRunner.getTest().log(Status.INFO, "Formatted End Date: " + formattedDate);

        edt_EndDate.sendKeys(formattedDate);

        System.out.println("End Date is entered: " + formattedDate);
        TestRunner.getTest().log(Status.PASS, "End Date entered: " + formattedDate);
    }


    public void AssignmentSearchAfterFilters(String assignmentName) throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "Verify Assignment after we apply Filters");
        System.out.println("Verify Assignment after we apply Filters");

        WebElement assignmentTable = wait.until(ExpectedConditions.visibilityOf(studentAssignmentTable));

        List<WebElement> assignmentContainers = assignmentTable.findElements(By.xpath(".//thead//tr//th"));
        System.out.println("Total Assignment Names are: " + assignmentContainers.size());
        TestRunner.getTest().log(Status.INFO, "Total Assignment Names are :"+ assignmentContainers.size());


        for (WebElement assignment : assignmentContainers) {
            String assignmentsName = assignment.getText();
            System.out.println("Assignment Name: " + assignmentsName);

            if (assignmentsName.equalsIgnoreCase(assignmentName)) {
                System.out.println("Found assignment: " + assignmentsName);

                try {
                    Thread.sleep(2000);
//                    new WebDriverWait(driver, Duration.ofSeconds(20));
                    assignment.click();
                    System.out.println("Assignment found");
                    TestRunner.getTest().log(Status.INFO, "Assignment found Successfully " + assignmentsName);
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  Assignment Found successfully " + assignmentsName);


                    positiveTestCaseGradeBook_pf.verifyDiableButtons();

                } catch (NoSuchElementException e) {
                    System.out.println("For New Assignment that student is not yet attempt Grade is Enable: " + assignmentName);
                    TestRunner.getTest().log(Status.FAIL, "Test Case Failed : For New Assignment that student is not yet attempt Grade is Enable: " + assignmentName);
                    return;
                }
                break;
            } else {
                System.out.println("Assignment not found: " + assignmentName);
            }
        }
    }

    public void ClickOnAssignAndProcessToAssignCustomAssessmentForFIlterVerifications() {
        try {
            WebElement SearchAssessmentDashboard = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class, 'AssessmentDashboardRightPanel')]//tbody")));

            List<WebElement> totalSearchAssignments = SearchAssessmentDashboard.findElements(By.xpath(".//tr"));
            System.out.println("Total Search Assignment is: " + totalSearchAssignments.size());

            boolean found = false;

            for (WebElement searchAssignment : totalSearchAssignments) {
                createAssessment_pf.AssessmentTableInReadAble();
                WebElement nameElement = searchAssignment.findElement(By.xpath(".//td[2]//div"));
                String searchedAssignmentName = nameElement.getText();

                System.out.println("Searched assignment name: " + searchedAssignmentName);
                TestRunner.getTest().log(Status.INFO, "Searched assignment name: " + searchedAssignmentName);

                if (searchedAssignmentName.equals(CustomAssessmentName)) {
                    WebElement assignButton = searchAssignment.findElement(By.xpath(".//button[normalize-space()='Assign']"));
                    if (assignButton.isDisplayed() && assignButton.isEnabled()) {
                        System.out.println("Assign button found for: " + CustomAssessmentName);
                        found = true;
                        Thread.sleep(1000);
                        createAssessment_pf.ReleaseCustomAssignmentForCorrectAnswers();
                        TestRunner.getTest().log(Status.PASS, "Test Case Passed : Release Custom Assignment for correct Answers successfully");

                    }

                    Thread.sleep(1000);
                    break;
                }
            }

            if (!found) {
                System.out.println("No assignment found with the name: " + CustomAssessmentName);
                throw new RuntimeException("Custom Assessment Name not found");

            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public void ProcessToAddCommentsOnEachQuestion() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm into Add comments in each question");
        System.out.println("I'm into Add comments in each question");


        if (!isPaginationDisplayed()) {
//            studentExecutor.AssignmentSubmitAsCompleted();
            return;
        }

//        try {
        List<WebElement> questionButtons = nav_Pagination.findElements(By.xpath("//button[contains(@aria-label, 'Go to page')]"));

        for (WebElement questionButton : questionButtons) {
            String questionText = questionButton.getText();
            System.out.println("Question: " + questionText);
            TestRunner.getTest().log(Status.INFO, "Total Questions: " + questionText);
        }
        System.out.println("I'm here to clear Student Point list");
        generatedComments.clear();
        System.out.println("Teacher Comments  List :" + generatedComments);
        Thread.sleep(2000);

        TestRunner.startTest("Attempt assignment At Teacher Side in Selected Student Tab");
        while (btn_NavNextPage.isEnabled()) {
            Thread.sleep(2000);
            selectedStudent_pf.VerifyQuestionsInSelectedStudentTab();
            enterCommentsForEachQuestionAndSubmit();
            Thread.sleep(2000);
            helper.scrollToElement(driver, btn_NavNextPage);
            Thread.sleep(2000);
            btn_NavNextPage.click();
            Thread.sleep(2000);
        }
        enterCommentsForEachQuestionAndSubmit();

        System.out.println("New Teacher Comments On Each Question: "  +  generatedComments);

        TestRunner.getTest().log(Status.INFO, "New Teacher Comments On Each Question: "  +  generatedComments);

        System.out.println("New Comments Added for Student Successfully ");
        TestRunner.getTest().log(Status.PASS, "Test Case Passed: New Comments Added for Student Successfully");
//            studentExecutor.AssignmentSubmitAsCompleted();
//        } catch (NoSuchElementException | ElementNotInteractableException | TimeoutException e) {
//            System.out.println("No Question found.");
//            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : No Question found or Question not visible");
//        }
    }
    public void enterCommentsForEachQuestionAndSubmit() {
        TestRunner.getTest().log(Status.INFO, "I'm into Enter student Points and Submit that point");
        System.out.println("I'm into Enter student Points and Submit that point");

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(60));

        try {

            // Locate the Add question Comment input field
            WebElement commentInput = wait.until(ExpectedConditions.elementToBeClickable(
                    By.xpath("(//input[@name='comments'])[2]")  // XPath for the student points field
            ));
            commentInput.click();

//            String existingStudentComment = commentInput.getAttribute("value");
//            System.out.println("Current Student Point: " + existingStudentComment);
//            TestRunner.getTest().log(Status.INFO, "Current Student Point: " + existingStudentComment);

            // Clear the existing input in the field
            Actions actions = new Actions(driver);
//            int length = commentInput.getAttribute("value").length();
//            for (int j = 0; j < length; j++) {
//                commentInput.sendKeys(Keys.DELETE);
//            }

// Click on the input field to focus
            actions.click(commentInput).perform();

// Retrieve the current value of the input field
            String existingStudentComment = commentInput.getAttribute("value");

// Keep deleting characters until the input is empty
            while (existingStudentComment.length() > 0) {
                commentInput.sendKeys(Keys.BACK_SPACE); // You can also use Keys.DELETE depending on the cursor position
                existingStudentComment = commentInput.getAttribute("value"); // Update the current value after each deletion
            }

            System.out.println("Cleared the input field");
            TestRunner.getTest().log(Status.INFO, "Cleared the input field");

            String[] comments = {
                    "Well done",
                    "Needs improvement",
                    "Excellent effort",
                    "Good job on this one",
                    "Please review this concept again",
                    "You can do better next time",
                    "Solid understanding",
                    "Try solving similar problems",
                    "Keep practicing",
                    "Focus on the basics"
            };

            String teacherComment = comments[(int) (Math.random() * comments.length)];

            System.out.println("Generated Teacher Comment: " + teacherComment);

            TestRunner.getTest().log(Status.INFO, "Generated Teacher Comment: " + teacherComment);


            // Enter the new comment
            commentInput.sendKeys(teacherComment);

            System.out.println("Add New Teacher comments on Question");

            generatedComments.add(teacherComment);  // Add point to the list

            System.out.println("Teacher Entered Comments: " + teacherComment);
            TestRunner.getTest().log(Status.INFO, "Teacher Entered Comments: " + teacherComment);

            // Locate and click the submit button
            WebElement clickSubmit = driver.findElement(By.xpath("//button[@name='btn-submit-applyfilter']"));
            clickSubmit.click();
            System.out.println("Submit button clicked successfully");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Submit button clicked successfully.");

            TestRunner.getTest().log(Status.INFO, "I'm in to get Success Message.");
            System.out.println("Get Success Message");
            selectedStudent_pf.getSuccessMessage();

        } catch (NoSuchElementException e) {
            System.out.println("Content Type Question Have not Grade Assignment Points");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Content Type Question Have not Grade Assignment Points ");
            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());

        } catch (TimeoutException e) {
            System.out.println("Timed out waiting for element: " + e.getMessage());
            TestRunner.getTest().log(Status.FAIL, "Test case failed: Timeout waiting for element - " + e.getMessage());

        } catch (Exception e) {
            System.out.println("An error occurred: " + e.getMessage());
            TestRunner.getTest().log(Status.FAIL, "Test case failed: Unexpected error - " + e.getMessage());
        }
    }



    private boolean isPaginationDisplayed() {
        try {
            return nav_Pagination.isDisplayed();
        } catch (NoSuchElementException | ElementNotInteractableException | TimeoutException e) {
            return false;
        }
    }


    public void VerifyCommentsOnStudentSide() throws InterruptedException{
        WebElement overviewWrapper = driver.findElement(By.xpath("//div[@class='OverviewScreenWrapper MuiBox-root css-0']"));
        WebElement answer_element = overviewWrapper.findElement(By.xpath(".//div[@class='ScrollbarsCustom-Content']"));
        List<WebElement> button_answers = answer_element.findElements(By.tagName("button"));
        System.out.println("Total Answer: " + button_answers.size());
        if (!button_answers.isEmpty()) {
            WebElement button = button_answers.get(0);
            if (button.isDisplayed()) {
                System.out.println("Button was clicked: " + button.getText());
                button.click();
                System.out.println("Answer is clicked.");
                ISCommentExitsOnStudentSide();
            } else {
                System.out.println("Button is not displayed.");
            }
        } else {
            System.out.println("No answer buttons found.");
        }
    }

    public void ISCommentExitsOnStudentSide() throws InterruptedException {

        driver.switchTo().defaultContent();

        try {
            List<WebElement> questionButtons = nav_Pagination.findElements(By.xpath("//button[contains(@aria-label, 'Go to page')]"));
            for (WebElement questionButton : questionButtons) {
                String questionText = questionButton.getText();
                System.out.println("Question: " + questionText);
            }
            while (btn_NavNextPage.isEnabled()) {
                Thread.sleep(2000);
                VerifyStudentSideCommentsWithTeacherComments();
                btn_NavNextPage.click();
                Thread.sleep(2000);
            }

            Thread.sleep(2000);
            WebElement btn_CloseReview = driver.findElement(By.xpath("//button[@id='closeReview-btn']"));
            helper.scrollToElement(driver, btn_CloseReview);
            Thread.sleep(1000);
            System.out.println("Clicked on close review");
            btn_CloseReview.click();
        }catch (NoSuchElementException | ElementNotInteractableException | TimeoutException e) {
            driver.switchTo().defaultContent();
            WebElement btn_CloseReview = driver.findElement(By.xpath("//button[@id='closeReview-btn']"));
            helper.scrollToElement(driver, btn_CloseReview);
            btn_CloseReview.click();
            System.out.println("No Comments are Visible.");
            TestRunner.getTest().log(Status.INFO, "Question Comments not visible");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Question Comments not visible");
        }
    }

//    int temp1;
    int temp1 = 0; // Initialize the index to 0

    public void VerifyStudentSideCommentsWithTeacherComments() throws InterruptedException {
        System.out.println("I'm in to verify Student Comments that the teacher set");

        // Switch to the iframe where the student's comment is located
        WebElement questionPlayer = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("lesson-player-ifram")));
        driver.switchTo().frame(questionPlayer);

        // Locate the comment at the student's side
        WebElement comment = driver.findElement(By.xpath("//div[@class='commentWrapper']//div[@class='Container']/span[2]"));
        String commentOnAssignmentAttemptStr = comment.getText(); // Get the comment text
        System.out.println("Comment at student side on Assignment: " + commentOnAssignmentAttemptStr);
        TestRunner.getTest().log(Status.INFO, "Comment at student side on Assignment: " + commentOnAssignmentAttemptStr);


        // Print teacher comments list size and content
        TestRunner.getTest().log(Status.INFO, "Size of Teacher Comment Array from teacher side: " + generatedComments.size());
        System.out.println("Size of Teacher Comment Array from teacher side: " + generatedComments.size());
        System.out.println("New Teacher Comments Array from teacher side: " + generatedComments);
        TestRunner.getTest().log(Status.INFO, "New Teacher Comments Array from teacher side: " + generatedComments);


        // Verify if temp1 index is valid for the generated comments list
        if (temp1 < generatedComments.size()) {
            // Retrieve the corresponding teacher comment from the list
            String correspondingTeacherComment = generatedComments.get(temp1);
            System.out.println("Student Comment on Assignment Attempt (Student Side): " + commentOnAssignmentAttemptStr);
            System.out.println("New Teacher Comment: " + correspondingTeacherComment);

            TestRunner.getTest().log(Status.INFO, "Student Comment on Assignment Attempt (Student Side): " + commentOnAssignmentAttemptStr);
            TestRunner.getTest().log(Status.INFO, "Teacher Comment: " + correspondingTeacherComment);

            // Compare student side comment with teacher side comment
            if (commentOnAssignmentAttemptStr.equals(correspondingTeacherComment)) {
                System.out.println("Student comment matches with the teacher-set comment at Question " + temp1 + ": " + commentOnAssignmentAttemptStr);
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: Verified comment matches at Question " + temp1);
            } else {
                System.out.println("Comment mismatch at Question " + temp1 + ": Student's comment is '" + commentOnAssignmentAttemptStr + "' but expected '" + correspondingTeacherComment + "'");
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Comment mismatch at Question " + temp1);
            }

        } else {
            System.out.println("Invalid index: " + temp1);
            TestRunner.getTest().log(Status.FAIL, "Invalid index " + temp1);
        }

        // Move to the next comment for the next question
        temp1++;
        driver.switchTo().defaultContent();
    }

}
