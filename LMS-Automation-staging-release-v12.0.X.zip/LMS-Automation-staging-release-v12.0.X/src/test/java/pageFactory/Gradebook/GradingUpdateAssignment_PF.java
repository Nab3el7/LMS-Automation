package pageFactory.Gradebook;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Random;

public class GradingUpdateAssignment_PF {

    WebDriverWait wait;
    WebDriver driver;
    Helper helper;
    private static String assignmentName;

    private static String startDateTime;
    private static String endDateTime;

    @FindBy(xpath = "//div[contains(@class, 'AssignmentWrapper')]")
    WebElement card_MyAssignment;

    @FindBy(xpath = "(//div[@class='ScrollbarsCustom-Content'])[2]")
    WebElement panel_Assignments;

    public GradingUpdateAssignment_PF(WebDriver driver){
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        helper = new Helper();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
    }

    public void gotoURL() throws InterruptedException {
        Thread.sleep(3000);
        driver.get("https://staging.gallopade.com/gradebook/da334581-f649-45a9-a9d3-e12d32355b78/editAssignment/8c81e807-9be8-4583-ae4d-f0a75de765ea?classId=da334581-f649-45a9-a9d3-e12d32355b78&districtId=100&orgId=101&teacherId=&currentPage=1&totalRecords=20&totalPages=2&pageSize=10");
        Thread.sleep(2000);
    }

    public void EditStudent() throws InterruptedException {
        Thread.sleep(1000);
        WebElement wholeTable = driver.findElement(By.xpath("//div[@class='studentRecords']"));

        List<WebElement> rowTable = wholeTable.findElements(By.xpath("//div[@role='row']"));

        for (int i = 1; i < rowTable.size(); i++) {
            WebElement row = rowTable.get(i);
            System.out.println(row.getText());
        }

        List<WebElement> tableInputs = wholeTable.findElements(By.xpath("//input[@aria-label='select all desserts']"));

        System.out.println("Total number of input checkboxes: " + tableInputs.size());

//        if (!tableInputs.isEmpty()) {
//            Random rand = new Random();
//            int randomIndex = rand.nextInt(tableInputs.size() - 1) + 1;
//            WebElement randomInput = tableInputs.get(randomIndex);
//            System.out.println("Selected index: " + randomIndex);
//            randomInput.click();
//        } else {
//            System.out.println("No input checkboxes found.");
//        }

        if (tableInputs.size() > 10) {
            WebElement inputAtIndex10 = tableInputs.get(9);
            System.out.println("Selected index: 9");
            inputAtIndex10.click();
        } else {
            System.out.println("Less than 10 input checkboxes found.");
        }
    }

    public void ApplyDateOnAssignment() throws InterruptedException {
        Thread.sleep(2000);

        WebElement girdDate = driver.findElement(By.xpath("//div[@class='applyDataGrid']"));
        girdDate.isDisplayed();

        helper.scrollToElement(driver, girdDate);
        Thread.sleep(2000);

        // Set Start Date Time
        startDateTime = generateStartDateTime();
        System.out.println("Generated Start DateTime: " + startDateTime);
        setDateTimeValueByJS(girdDate, "(//input[@type='datetime-local'])[4]", startDateTime);

        // Set End Date Time
        endDateTime = generateEndDateTime(startDateTime);
        System.out.println("Generated End DateTime: " + endDateTime);
        setDateTimeValueByJS(girdDate, "(//input[@type='datetime-local'])[5]", endDateTime);


        Thread.sleep(2000);
        WebElement checkBoxLateSub = girdDate.findElement(By.xpath("(//input[@name='lateSubmission2'])[1]"));
        checkBoxLateSub.click();

        // Set Late Submission Date Time
        String lateDateTime = generateLateSubDateTime(endDateTime);
        System.out.println("Generated Late Sub DateTime: " + lateDateTime);
        setDateTimeValueByJS(girdDate, "(//input[@type='datetime-local'])[6]", lateDateTime);

        Thread.sleep(2000);
        WebElement dropDown_Review = girdDate.findElement(By.xpath("(//div[contains(@class, 'studentCanReviewWorkIdField')])[1]"));
        dropDown_Review.click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[@role='listbox']")));
        List<WebElement> ReviewOptions = driver.findElements(By.xpath("//ul[@role='listbox']"));
        helper.selectValueFromDropdown(ReviewOptions);

        Thread.sleep(2000);
        WebElement checkBoxAnswer = girdDate.findElement(By.xpath("(//input[@name='Answers'])[1]"));
        checkBoxAnswer.click();

        Thread.sleep(2000);
        WebElement checkBoxGrades = girdDate.findElement(By.xpath("(//input[@name='Grades'])[1]"));
        checkBoxGrades.click();

        Thread.sleep(2000);
        WebElement btnApply = girdDate.findElement(By.xpath("//button[normalize-space()='Apply']"));
        System.out.println(btnApply.getText());
        btnApply.click();
    }

    private void setDateTimeValueByJS(WebElement parentElement, String xpath, String value) {
        WebElement element = parentElement.findElement(By.xpath(xpath));
        JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
        jsExecutor.executeScript("arguments[0].value = arguments[1];", element, value);
    }

    public String generateStartDateTime() {
        Calendar calendar = Calendar.getInstance();
        Date currentDate = calendar.getTime();

        Random random = new Random();
        int randomDays = random.nextInt(30);
        calendar.add(Calendar.DAY_OF_MONTH, randomDays);
        Date randomStartDate = calendar.getTime();

        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm");
        return dateFormat.format(randomStartDate);
    }

    public String generateEndDateTime(String startDateTime) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm");

        try {
            Date startDate = dateFormat.parse(startDateTime);

            Calendar calendar = Calendar.getInstance();
            calendar.setTime(startDate);
            calendar.add(Calendar.MONTH, 1);

            return dateFormat.format(calendar.getTime());
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }

    public String generateLateSubDateTime(String endDateTime) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm");

        try {
            Date endDate = dateFormat.parse(endDateTime);

            Calendar calendar = Calendar.getInstance();
            calendar.setTime(endDate);
            calendar.add(Calendar.MONTH, 1);

            return dateFormat.format(calendar.getTime());
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }

    public String getAssignmentName(){
        if (assignmentName == null){
            WebElement breadCrumb = driver.findElement(By.xpath("//ol[contains(@class, 'MuiBreadcrumbs')]"));
            System.out.println("BreadCrumb is: " + breadCrumb.getText());

            String[] parts = breadCrumb.getText().split(" ");
            assignmentName = parts[parts.length - 1];
            System.out.println("Assignment Name: " + assignmentName);
            return assignmentName;
        }
        return assignmentName;
    }

    public void selectAssignmentTabs() throws InterruptedException{
        card_MyAssignment.isDisplayed();
        WebElement tab_Assignment = card_MyAssignment.findElement(By.xpath("//div[@aria-label='wrapped label tabs example']"));
        tab_Assignment.click();

        List<WebElement> AssignmentTabs = tab_Assignment.findElements(By.xpath(".//button"));

        for (WebElement AssignmentTab : AssignmentTabs) {
            String tabText = AssignmentTab.getText();
            System.out.println("Assignment Tab Text: " +tabText);
            AssignmentTab.click();
            Thread.sleep(1000);
        }

        WebElement openTab = tab_Assignment.findElement(By.xpath(".//button[contains(text(), 'Open')]"));
        System.out.println("All Open Assignments  " + openTab.getText());
        openTab.click();
        Thread.sleep(1000);
    }

    public void searchAssignmentIntoPanel() throws InterruptedException {
        String searchAssignmentName = assignmentName;
        System.out.println("Search assignment name: " + searchAssignmentName);

        if (panel_Assignments.isDisplayed()){
            WebElement tab_Assignment = card_MyAssignment.findElement(By.xpath("//div[@aria-label='wrapped label tabs example']"));

            List<WebElement> AssignmentTabs = tab_Assignment.findElements(By.xpath(".//button"));
            System.out.println("Total tabs: " + AssignmentTabs.size());

            boolean assignmentFound = false;

            for (WebElement AssignmentTab : AssignmentTabs) {
                String tabText = AssignmentTab.getText();
                String[] tabParts = tabText.split(":");
                String tabName = tabParts[0].trim();
                System.out.println("Assignment Tab Text: " + tabName);

                AssignmentTab.click();

                Thread.sleep(2000);

//                List<WebElement> tabPanels = panel_Assignments.findElements(By.xpath(".//div[@id='simple-tabpanel-2']"));
                List<WebElement> tabPanels = panel_Assignments.findElements(By.xpath(".//div[@role='tabpanel']"));
                System.out.println("Total Assignments into panel: " + tabPanels.size());
                for (WebElement tabPanel : tabPanels) {
                    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[@class='ScrollbarsCustom-Content'])[2]")));
                    Thread.sleep(1000);
                    String panelText = tabPanel.getText();
                    System.out.println("Panel Text: " + panelText);

                    if (tabName.equals("Open")) {
                        if (panelText.contains(searchAssignmentName)) {
                            System.out.println("Test case passed: Resubmitted assignment shows into Open tab");
                            assignmentFound = true;
                        }
                    } else {
                        if (panelText.contains(searchAssignmentName)) {
                            System.out.println("Test case passed but Assignment shows into '" + tabName + "' tab ");
                            assignmentFound = true;
                        }
                    }
                }

            }

            if (!assignmentFound) {
                System.out.println("Test case passed: Assignment not found in any panel");
            }
        }
    }

    public void gotoViewURL() throws InterruptedException {
        Thread.sleep(3000);
        driver.get("https://staging.gallopade.com/gradebook/da334581-f649-45a9-a9d3-e12d32355b78/grading/gradebystudent?questionId=AP_6139EBF334CD4AD796B96B073BE044C3&studentClassAssignmentId=91f6d518-8344-4f77-b39d-c64b4c5b8d83&studentId=fc7b7700-bb6b-4bf9-baa7-7505aa00s093&assignmentId=8c81e807-9be8-4583-ae4d-f0a75de765ea&classId=da334581-f649-45a9-a9d3-e12d32355b78&studentOption=view&districtId=100&orgId=101&teacherId=");
        Thread.sleep(2000);
    }

    public void verifyAssignmentViewIntoTeacher() throws InterruptedException {
        Thread.sleep(2000);

        WebElement headerAssignment = driver.findElement(By.xpath("//div[contains(@class, 'grading-header')]"));

        WebElement assignmentDateTime = headerAssignment.findElement(By.xpath("(//div[contains(@class, 'content-footer-left')])[1]"));
        System.out.println("Date Time is: " + assignmentDateTime.getText());

        WebElement startDateElement = assignmentDateTime.findElement(By.xpath(".//div[contains(@class, 'startDate')]"));
        String startDateText = startDateElement.getText();
        String startDate = startDateText.substring(startDateText.indexOf(":") + 2, startDateText.indexOf("   "));
        System.out.println("Start Date is: " + startDate);

        WebElement dueDateElement = assignmentDateTime.findElement(By.xpath(".//div[contains(@class, 'DueDate')]"));
        String dueDateText = dueDateElement.getText();
        String dueDate = dueDateText.substring(dueDateText.indexOf(":") + 2, dueDateText.indexOf("  "));
        System.out.println("Due Date is: " + dueDate);

        String searchAssignmentStartDateTime = startDateTime;
        System.out.println("Search assignment Start Date: " + searchAssignmentStartDateTime);

        String searchAssignmentDueDateTime = endDateTime;
        System.out.println("Search assignment Due Date: " + searchAssignmentDueDateTime);

        if (startDate.equals(searchAssignmentStartDateTime)) {
            System.out.println("Start date matches searchAssignmentStartDateTime");
        } else {
            System.out.println("Start date does not match searchAssignmentStartDateTime");
        }

        if (dueDate.equals(searchAssignmentDueDateTime)) {
            System.out.println("Due date matches searchAssignmentDueDateTime");
        } else {
            System.out.println("Due date does not match searchAssignmentDueDateTime");
        }
    }

}
