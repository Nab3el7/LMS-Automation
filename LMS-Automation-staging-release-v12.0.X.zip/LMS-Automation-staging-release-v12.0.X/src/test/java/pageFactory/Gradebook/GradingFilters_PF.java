package pageFactory.Gradebook;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Random;

public class GradingFilters_PF {
    WebDriverWait wait;
    WebDriver driver;
    Helper helper;


    @FindBy(xpath = "//button[@aria-label='delete']")
    WebElement btn_ShowAllFilters;

    @FindBy (xpath = "(//div[@variant='outlined'])[4]")
    WebElement DropDown_SelectDistrict;

    @FindBy (xpath = "(//div[@variant='outlined'])[5]")
    WebElement DropDown_SelectSchool;

    @FindBy (xpath = "(//div[@variant='outlined'])[6]")
    WebElement DropDown_SelectTeacher;

    @FindBy (xpath = "(//input[contains(@name,'activeStatus')])[1]")
    WebElement Toggle_SelectClasses;

    @FindBy (xpath = "(//input[contains(@name,'activeStatus')])[2]")
    WebElement Toggle_SelectStudents;

    @FindBy (xpath = "//button[normalize-space()='Apply Filters']")
    WebElement btn_ApplyFilters;


//        Sort by Date, %, Points, and Print Button

    @FindBy(xpath = "(//div[@aria-haspopup='listbox'])")
    WebElement dropdown_Class;

    @FindBy(xpath = "//div[@id=\"mui-36\"]")
    WebElement dropdown_SortBy;

    @FindBy(xpath = "//li[@title=\"DueDate\"]")
    WebElement Duedate;

    @FindBy(xpath = "//button[normalize-space()='Points']")
    WebElement Points;

    @FindBy(xpath = "//span[@title=\"Decimal Number\"]")
    WebElement Checkbox;

    @FindBy(xpath = "//button[@aria-label=\"Print\"]")
    WebElement Printbtn;


    public GradingFilters_PF(WebDriver driver) {
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        helper = new Helper();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(100));
    }


//    Manual Grading pageFactory.Filters

    public void clickOnShowFilter() throws InterruptedException{
        Thread.sleep(500);
        btn_ShowAllFilters.click();
        TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  Show all filters clicked successfully");

    }

    public void ClickOnDropDownSelectDistrict() throws InterruptedException{
        Thread.sleep(1000);
        DropDown_SelectDistrict.click();

        WebElement dropdownDistrict = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[@role='listbox']")));
        List<WebElement> selectDistrictOptions = dropdownDistrict.findElements(By.xpath("//ul[@role='listbox']/li"));

        System.out.println("District dropdown values:");
        for (WebElement optionDistrict : selectDistrictOptions) {
            System.out.println(optionDistrict.getText());
        }

        boolean isDistrictDropdownShown = DropDown_SelectDistrict.isDisplayed();
        if (isDistrictDropdownShown) {
            selectRandomValueFromDropdownList(selectDistrictOptions);
            System.out.println("District dropdown is shown.");
        } else {
            System.out.println("District dropdown is not shown.");
        }
    }

    public void ClickOnDropDownSelectSchool() throws InterruptedException{
        Thread.sleep(1000);
        DropDown_SelectSchool.click();

        WebElement dropdownSchool = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[@role='listbox']")));
        List<WebElement> selectSchoolOptions = dropdownSchool.findElements(By.xpath("//ul[@role='listbox']/li"));

        System.out.println("School dropdown values:");
        for (WebElement optionSchool : selectSchoolOptions) {
            System.out.println(optionSchool.getText());
        }

        boolean isSchoolDropdownShown = DropDown_SelectSchool.isDisplayed();
        if (isSchoolDropdownShown) {
            selectRandomValueFromDropdownList(selectSchoolOptions);
            System.out.println("School dropdown is shown.");
        } else {
            System.out.println("School dropdown is not shown.");
        }
    }

    public void ClickOnDropDownSelectTeacher() throws InterruptedException{
        Thread.sleep(1000);
        DropDown_SelectTeacher.click();

        WebElement dropdownTeacher = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[@role='listbox']")));
        List<WebElement> selectTeacherOptions = dropdownTeacher.findElements(By.xpath("//ul[@role='listbox']/li"));

        System.out.println("Teacher dropdown values:");
        for (WebElement optionTeacher : selectTeacherOptions) {
            System.out.println(optionTeacher.getText());
        }

        boolean isTeacherDropdownShown = DropDown_SelectTeacher.isDisplayed();
        if (isTeacherDropdownShown) {
            selectRandomValueFromDropdownList(selectTeacherOptions);
            System.out.println("Teacher dropdown is shown.");
        } else {
            System.out.println("Teacher dropdown is not shown.");
        }
    }

    public void ClickOnClassesToggleButton() throws InterruptedException{
        Thread.sleep(1000);

        boolean isClassesToggleButtonEnabled = Toggle_SelectClasses.isSelected();

        if (isClassesToggleButtonEnabled) {
            System.out.println("Classes toggle button is already enabled.");
            TestRunner.getTest().log(Status.PASS, "Testcase Passed   :  Classes toggle button clicked Successfully ");
        } else {
            Toggle_SelectClasses.click();
            System.out.println("Classes toggle button is now enabled.");
            TestRunner.getTest().log(Status.PASS, "Testcase Passed   : Classes toggle button clicked Successfully ");

        }
    }

    public void ClickOnStudentsToggleButton() throws InterruptedException{
        Thread.sleep(1000);

        boolean isStudentsToggleButtonEnabled = Toggle_SelectStudents.isSelected();

        if (isStudentsToggleButtonEnabled) {
            System.out.println("Students toggle button is already enabled.");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  Toggle button students enabled successfully");

        } else {
            Toggle_SelectStudents.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  Students toggle button is now enabled.");

        }
    }

    public void ClickOnApplyDateFilter() throws InterruptedException {
        Thread.sleep(1000);

        WebElement btn_DateCalendar = driver.findElement(By.xpath("//span[@aria-label='upload picture']"));
        btn_DateCalendar.click();
        TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  Date range button click successfully");

    }
    public void ClickOnStartDateFilter() throws InterruptedException {
        Thread.sleep(1000);

        WebElement edt_StartDate = driver.findElement(By.xpath("//label[contains(text(),'Start')]/following-sibling::div//input"));

        String startDateTime = generateStartDateTime();
        System.out.println("Generated Start DateTime: " + startDateTime);
        TestRunner.getTest().log(Status.INFO, "Start date " + startDateTime);
        edt_StartDate.sendKeys(startDateTime);

        TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  Start date added successfully");


    }

    public void ClickOnEndDateFilter() throws InterruptedException {
        Thread.sleep(1000);

        WebElement edt_StartDate = driver.findElement(By.xpath("//label[contains(text(),'End')]/following-sibling::div//input"));

        String startDateTime = generateStartDateTime();
        System.out.println("Generated Start DateTime 1: " + startDateTime);
        String endDateTime = generateEndDateTime(startDateTime);
        System.out.println("Generated End DateTime: " + endDateTime);
        TestRunner.getTest().log(Status.INFO, "Start date " + endDateTime);

        edt_StartDate.sendKeys(endDateTime);
        TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  End date added successfully");
    }

    private String generateStartDateTime() {
        Calendar calendar = Calendar.getInstance();
        Date currentDate = calendar.getTime();

        Random random = new Random();
        int randomDays = random.nextInt(30);
        calendar.add(Calendar.DAY_OF_MONTH, randomDays);
        Date randomStartDate = calendar.getTime();

        SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
        return dateFormat.format(randomStartDate);
    }

    private String generateEndDateTime(String startDateTime) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");

        try {
            Date startDate = dateFormat.parse(startDateTime);

            Calendar calendar = Calendar.getInstance();
            calendar.setTime(startDate);
            calendar.add(Calendar.MONTH, 1);

            SimpleDateFormat endDateFormat = new SimpleDateFormat("MM/dd/yyyy");
            return endDateFormat.format(calendar.getTime());
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }

    public void ClickOnApplyFilterButton() throws InterruptedException {
        Thread.sleep(1000);

        if (btn_ApplyFilters.isDisplayed()) {
            btn_ApplyFilters.click();
            System.out.println("Apply Filter button clicked.");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  Apply filter clicked successfully");

        } else {
            System.out.println("Apply Filter button is not displayed.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : Apply Filter button is not displayed.");

        }
    }

//        Sort by Date, %, Points, and Print Button

    public void ClickClassDropDownAndValue() throws InterruptedException{
        dropdown_Class.click();
        Thread.sleep(500);

        WebElement dropdownClass = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[@role='listbox']")));
        List<WebElement> selectClassOptions = dropdownClass.findElements(By.xpath("//ul[@role='listbox']/li"));

        System.out.println("Class dropdown values:");
        for (WebElement optionClass : selectClassOptions) {
            System.out.println(optionClass.getText());
        }

        boolean isClassDropdownShown = dropdownClass.isDisplayed();
        if (isClassDropdownShown) {
            System.out.println("Class dropdown is shown.");
            selectRandomValueFromDropdownList(selectClassOptions);
        } else {
            System.out.println("Class dropdown is not shown.");
        }
    }

    public void ClickSortByDropDownAndValue() throws InterruptedException{
        dropdown_SortBy.click();
        Thread.sleep(500);

        WebElement dropdownClass = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[@role='listbox']")));
        List<WebElement> selectClassOptions = dropdownClass.findElements(By.xpath("//ul[@role='listbox']/li"));

        System.out.println("Class dropdown values:");
        for (WebElement optionClass : selectClassOptions) {
            System.out.println(optionClass.getText());
        }

        boolean isClassDropdownShown = dropdownClass.isDisplayed();
        if (isClassDropdownShown) {
            System.out.println("Class dropdown is shown.");
            selectRandomValueFromDropdownList(selectClassOptions);
        } else {
            System.out.println("Class dropdown is not shown.");
        }
    }

    public void Duedate() throws InterruptedException{
        Thread.sleep(3000);
        Duedate.click();
        Thread.sleep(3000);
    }
    public void Points() throws InterruptedException{
        Thread.sleep(3000);
        Points.click();
        Thread.sleep(3000);
    }
    public void Checkbox() throws InterruptedException{
        Thread.sleep(3000);
        Checkbox.click();
        Thread.sleep(3000);
    }
    public void Printbtn() throws InterruptedException{
        Thread.sleep(4000);
        Printbtn.click();
        TestRunner.getTest().log(Status.PASS, "Testcase Passed   :  Print Button click Successfully");

    }

    public void Printloading() throws InterruptedException{
        WebElement loader = driver.findElement(By.xpath("//span[@class=\"BackdropLoader-title\"]"));
        wait.until(ExpectedConditions.invisibilityOf(loader));
        TestRunner.getTest().log(Status.PASS, "Testcase Passed   :  Printing Action Perform successfully");

    }

    private void selectRandomValueFromDropdownList(List<WebElement> options) {
        Random random = new Random();
        int index = random.nextInt(options.size());

        WebElement selectedOption = options.get(index);
        selectedOption.click();

        System.out.println("Randomly selected value: " + selectedOption.getText());
    }

}
