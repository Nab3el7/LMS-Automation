package pageFactory.Gradebook;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Assignmment.CorrectAnswerExecutor_PF;
import pageFactory.Assignmment.ReleaseAssignment_PF;
import pageFactory.MyContent.AssignAssessment_PF;
import org.openqa.selenium.ElementNotInteractableException;

import java.awt.*;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import static pageFactory.Assignmment.ReleaseAssignment_PF.assignmentTypeFromAssignment;

public class PositiveTestCaseGradeBook_PF {
    WebDriverWait wait;
    WebDriver driver;
    Helper helper;

    ReleaseAssignment_PF releaseAssignment_pf;


    @FindBy(xpath = "//span[@title='Collapse Categories']")
    WebElement collapse_checkbox;

    @FindBy(xpath = "//div[contains(@class, 'StudentListingAndTableWrapper')]//table//tbody//tr[2]")
    WebElement decimalPointsRow;

    @FindBy(xpath = "//div[contains(@class, 'StudentListingAndTableWrapper')]//table//tbody//tr[2]")
     WebElement percent_view;

    @FindBy(xpath = "//div[contains(@class, 'StudentListingAndTableWrapper')]//table//tbody//tr[1]")
    WebElement points_view;

    @FindBy(xpath = "//div[contains(@class, 'StudentListingAndTableWrapper')]")
    WebElement studentAssignmentTable;

    @FindBy(xpath = "(//label[normalize-space()='Sort by'])/parent::div")
    WebElement dropdown_SortBy;

    @FindBy(xpath = "//nav[@aria-label='pagination navigation']")
    WebElement nav_Pagination;

    @FindBy(xpath = "//button[@aria-label='Go to next page']")
    WebElement btn_NavNextPage;

    String questionID = null;

    public static List<String> QuestionIDsOnOpenAssignment = new ArrayList<>();
    public static List<String> QuestionIDsPreviewGradeBook = new ArrayList<>();

    CorrectAnswerExecutor_PF correctAnswerExecutor_pf;
    AssignAssessment_PF assignAssessment_pf;

    @FindBy(xpath = "//span[normalize-space()='Export']")
    WebElement btn_export;
    Actions actions;

    public  PositiveTestCaseGradeBook_PF(WebDriver driver){
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        helper = new Helper();
        PageFactory.initElements(driver, this);
        correctAnswerExecutor_pf = new CorrectAnswerExecutor_PF(driver);
        assignAssessment_pf = new AssignAssessment_PF(driver);
        releaseAssignment_pf = new ReleaseAssignment_PF(driver);
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        actions = new Actions(driver);

    }

    List<String> assignmentNames = new ArrayList<>();
    List<String> assignmentNamesForDueDate = new ArrayList<>();
    List<String> assignmentNamesForTitle = new ArrayList<>();


    public void GetStudentListAndIconPresent() throws InterruptedException {
        Thread.sleep(5000);

        WebElement searchBar = driver.findElement(By.xpath("//input[@placeholder='Search Student']"));

        if (searchBar.isDisplayed()) {

            String specificStudentName = "RAB STD";
            searchBar.clear();
            searchBar.sendKeys(specificStudentName);
            Thread.sleep(2000);

            List<WebElement> listStudent = driver.findElements(By.xpath("//div[contains(@class, 'item undefined')]"));

            boolean isStudentFound = false;

            for (WebElement student : listStudent) {
                String studentName = student.getText().trim();
                System.out.println("Student Name is: " + studentName);

                if (studentName.equals(specificStudentName)) {
                    System.out.println("Specific Student '" + specificStudentName + "' is found in the list.");
                    TestRunner.getTest().log(Status.INFO, "Specific Student " + specificStudentName + "is found in the list");

                    TestRunner.getTest().log(Status.PASS, "Testcase Passed   :  Student Name is found in the list successfully");


                    WebElement icon = student.findElement(By.xpath("//div[contains(@class,'item undefined')]//div[contains(@class, 'AvatarsWithDescriptionWrapper')]/following-sibling::img"));

                    if (icon.isDisplayed()) {
                        TestRunner.getTest().log(Status.PASS, "Testcase Passed   :  Icon Display successfully for student" +  specificStudentName);

                    } else {
                        TestRunner.getTest().log(Status.FAIL, "Testcase Failed   :  Icon not displayed for student "+  specificStudentName);
//                        throw new RuntimeException("Icon not displayed for student " + specificStudentName);
                    }

                    isStudentFound = true;
                    break;
                }
            }

            if (!isStudentFound) {
                TestRunner.getTest().log(Status.INFO, "Specific Student " + specificStudentName + "is not  found in the list");
                TestRunner.getTest().log(Status.FAIL, "Testcase Failed   :  Specific student" + specificStudentName + "is not found in the list");
//                throw new RuntimeException("Specific student '" + specificStudentName + "' is not found in the list.");
            }
        } else {
//
            TestRunner.getTest().log(Status.FAIL, "Testcase Failed   :  Search bar is not displayed.");
//            throw new RuntimeException("Search bar is not displayed.");
        }

    }

    public void ClickOnCollapseCheckBox() throws InterruptedException{
        if (collapse_checkbox.isDisplayed()){
            collapse_checkbox.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed   : Collapse Checkbox is Displayed and working successfully");

        }
        else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : Collapse Checkbox not found");

        }
    }

    public void selectValueFromDropDownExport() {
        try {
            // Wait until export button is clickable
            WebElement exportButton = wait.until(ExpectedConditions.elementToBeClickable(btn_export));

            // Click the export button
            try {
                exportButton.click();
            } catch (ElementClickInterceptedException e) {
                // If normal click fails, use JS click
                ((JavascriptExecutor) driver).executeScript("arguments[0].click();", exportButton);
            }

            // Wait for dropdown list to appear
            WebElement listExport = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[contains(@role,'menu')]")));
            List<WebElement> optionsExport = listExport.findElements(By.xpath(".//li"));

            System.out.println("Export List is: " + optionsExport.size());

            if (optionsExport.isEmpty()) {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: No options found in the export dropdown.");
                return;
            }

            System.out.println("Export Options:");
            for (WebElement optionExport : optionsExport) {
                System.out.println(optionExport.getText());
            }

            // Select a random option
            Random random = new Random();
            int randomIndex = random.nextInt(optionsExport.size());
            WebElement selectedOption = optionsExport.get(randomIndex);

            // Scroll into view
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", selectedOption);
            Thread.sleep(300); // optional, allow animation

            // Click option safely
            try {
                wait.until(ExpectedConditions.elementToBeClickable(selectedOption));
                selectedOption.click();
            } catch (ElementClickInterceptedException e) {
                // Fallback: JS click
                ((JavascriptExecutor) driver).executeScript("arguments[0].click();", selectedOption);
            }

            String selectedValue = selectedOption.getText();
            System.out.println("Selected Export Value: " + selectedValue);
            TestRunner.getTest().log(Status.INFO, "Selected Export is: " + selectedValue);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Export option clicked successfully");

        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Error occurred while selecting export option - on Report ");

        }
    }


    public void ClickAndValidateRefreshButton() throws InterruptedException{
        WebElement btn_Refresh= driver.findElement(By.xpath("//button[contains(@aria-label,'Refresh')]//*[name()='svg']"));
        if (btn_Refresh.isDisplayed()){
            btn_Refresh.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  Refresh Button click successfully");

        }else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : Refresh button not found.");

        }
    }

    public void ClickIIconGradeBook() throws InterruptedException{
        WebElement iconGradeBook= driver.findElement(By.xpath("//span[@aria-label='content description or help']//*[name()='svg']"));
        if (iconGradeBook.isDisplayed() && iconGradeBook.isEnabled()){
            iconGradeBook.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  I Icon on Grade Book Found and clicked");


            WebElement modalDialog = driver.findElement(By.xpath("//div[@role='dialog']"));

            List<WebElement> paragraphs = modalDialog.findElements(By.tagName("p"));

            for (WebElement paragraph : paragraphs) {
                System.out.println(paragraph.getText());
            }
            actions.sendKeys(Keys.ESCAPE).build().perform();
        }else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  I icon on GradeBook not found");

        }
    }

    public void VerifyViewPercentOption()throws InterruptedException{
       percent_view.isDisplayed();
       percent_view.click();

        try {
            Thread.sleep(3000);

            WebElement table = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class, 'StudentListingAndTableWrapper')]")));

            List<WebElement> totalCollapseButton = table.findElements(By.xpath(".//div[contains(@class,'CollapseTable Wrapper')]//table//tbody//tr[2]//td"));
            int numberOfCollapseButtons = totalCollapseButton.size();
            System.out.println("Total Collapse Buttons are:" + numberOfCollapseButtons);


            for (int i = 0; i < numberOfCollapseButtons; i++) {
                List<WebElement> totalCollapseButtons = table.findElements(By.xpath(".//div[contains(@class,'CollapseTable Wrapper')]//table//tbody//tr[2]//td"));
                WebElement btn_Collapse = totalCollapseButtons.get(i);
                System.out.println("Row data " + btn_Collapse.getText());
                TestRunner.getTest().log(Status.INFO, "Percent View data In Table: " + btn_Collapse.getText());
            }
            TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  % View show successfully ");

        }
        catch (Exception e) {
            e.printStackTrace();
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  % view not visible");

        }
    }

    public void VerifyViewPointsOption() throws InterruptedException{
        try {
            WebElement pointBtn= driver.findElement(By.xpath("//button[contains(@value,'point')]"));
            pointBtn.click();

            Thread.sleep(1000);

            WebElement table = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class, 'StudentListingAndTableWrapper')]")));

            List<WebElement> totalViewPoints = table.findElements(By.xpath(".//div[contains(@class,'CollapseTable Wrapper')]//table//tbody//tr[1]//td"));
            int numberOfViewpoints = totalViewPoints.size();
            System.out.println("Total Collapse Buttons are:" + numberOfViewpoints);


            for (int i = 0; i < numberOfViewpoints; i++) {
                List<WebElement> totalCollapseButtons = table.findElements(By.xpath(".//div[contains(@class,'CollapseTable Wrapper')]//table//tbody//tr[1]//td"));
                WebElement btn_Collapse = totalCollapseButtons.get(i);
                System.out.println("Row data " + btn_Collapse.getText());
                TestRunner.getTest().log(Status.INFO, "Point View data In Table: " + btn_Collapse.getText());

            }
            TestRunner.getTest().log(Status.PASS, "Test Case Passed   : Total Possible Points View  show successfully ");

        }
        catch (Exception e) {
            e.printStackTrace();
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  Points view not visible");
        }
    }

    public void SortByStartDate() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm in to select value from sort By dropdown");

        dropdown_SortBy.click();
        Thread.sleep(500);

        WebElement listClasses = driver.findElement(By.xpath("//ul[@role='listbox']"));
        List<WebElement> optionsClasses = listClasses.findElements(By.xpath("//ul[@role='listbox']//li"));

        System.out.println("Sort By List is: " + optionsClasses.size());

        if (optionsClasses.isEmpty()) {
            System.out.println("No options found in the Sort by dropdown.");
            TestRunner.getTest().log(Status.FAIL, "Testcase Failed   :  No options found in the Sort by dropdown.");
//            throw new RuntimeException("No Sort By option found in dropdown");

        } else {
            System.out.println("Sort By:");

            for (WebElement classes : optionsClasses) {
                System.out.println(classes.getText());
            }
            if (!optionsClasses.isEmpty()) {
                Random random = new Random();
                int randomIndex = random.nextInt(optionsClasses.size());
                WebElement selectedOption = optionsClasses.get(randomIndex);
                String selectedSortBy = selectedOption.getText();
                selectedOption.click();
                System.out.println("Selected Sort By Value: " + selectedSortBy);
                TestRunner.getTest().log(Status.INFO, "Sort By Value selected:" +  selectedSortBy);
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: Sort By Value selected successfully:" +  selectedSortBy);


                switch (selectedSortBy) {
                    case "StartDate":
                        getAssignmentNames();
                        break;
                    case "DueDate":
                        GetAllAssignmentNamesByDuedate();
                        break;
                    case "Title":
                        GetAllAssignmentNamesTitle();
                        break;
                    default:
                        System.out.println("No specific function defined for Sort By Value: " + selectedSortBy);
                        TestRunner.getTest().log(Status.FAIL, "Testcase Failed   :No specific function defined for Sort By new option.");

                        break;
                }
            } else {
                TestRunner.getTest().log(Status.FAIL, "Testcase Failed   :No options found in the Sort by dropdown.");
//                throw new RuntimeException("No Sort By option found in dropdown");
            }
        }
    }

    public void getAssignmentNames() {

        TestRunner.getTest().log(Status.INFO, "I'm into get Assignment Names By Start Date");
        System.out.println("I'm into get Assignment Names By  Start Date");

        WebDriverWait wait = new WebDriverWait(this.driver, Duration.ofSeconds(10));

        try {
            WebElement assignmentTable = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class, 'StudentListingAndTableWrapper')]")));

            for (int attempt = 0; attempt < 3; attempt++) {
                try {
                    List<WebElement> assignmentContainers = assignmentTable.findElements(By.xpath(".//thead//tr//th"));

                    for (WebElement assignment : assignmentContainers) {
                        String assignmentName = assignment.getText();
                        assignmentNames.add(assignmentName);
                        System.out.println("Assignment Name: " + assignmentName);
                        TestRunner.getTest().log(Status.INFO, "Assignment Names By Start date:" +  assignmentName);
                    }
                    break;
                } catch (StaleElementReferenceException e) {
                    System.out.println("Caught StaleElementReferenceException. Retrying...");
                    assignmentTable = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class, 'StudentListingAndTableWrapper')]")));
                }
            }
        } catch (Exception e) {
            System.out.println("An error occurred: " + e.getMessage());
        }

    }

    public void GetAllAssignmentNamesByDuedate() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm into get Assignment Names By Due Date");
        System.out.println("I'm into get Assignment Names By Due Date");

            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

            try {
                WebElement assignmentTable = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class, 'StudentListingAndTableWrapper')]")));

                for (int attempt = 0; attempt < 3; attempt++) {
                    try {
                        List<WebElement> assignmentContainers = assignmentTable.findElements(By.xpath(".//thead//tr//th"));

                        for (WebElement assignment : assignmentContainers) {
                            String assignmentName = assignment.getText();
                            assignmentNamesForDueDate.add(assignmentName); // Add assignment name to the list
                            System.out.println("Assignment Name: " + assignmentName);
                            TestRunner.getTest().log(Status.INFO, "Assignment Names by Due date:" +  assignmentName);
                        }
                        break;
                    } catch (StaleElementReferenceException e) {
                        System.out.println("Caught StaleElementReferenceException. Retrying...");
                        assignmentTable = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class, 'StudentListingAndTableWrapper')]")));
                    }
                }
            } catch (Exception e) {
                System.out.println("An error occurred: " + e.getMessage());
            }

    }

    public void GetAllAssignmentNamesTitle() throws InterruptedException{

        TestRunner.getTest().log(Status.INFO, "I'm into get Assignment Names By Title");
        System.out.println("I'm into get Assignment Names By Title");

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        try {
            WebElement assignmentTable = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class, 'StudentListingAndTableWrapper')]")));

            for (int attempt = 0; attempt < 3; attempt++) {
                try {
                    List<WebElement> assignmentContainers = assignmentTable.findElements(By.xpath(".//thead//tr//th"));

                    for (WebElement assignment : assignmentContainers) {
                        String assignmentName = assignment.getText();
                        assignmentNamesForTitle.add(assignmentName);
                        System.out.println("Assignment Name: " + assignmentName);
                        TestRunner.getTest().log(Status.INFO, "Assignment Names By Title:" +  assignmentName);
                    }
                    break;
                } catch (StaleElementReferenceException e) {
                    System.out.println("Caught StaleElementReferenceException. Retrying...");
                    assignmentTable = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class, 'StudentListingAndTableWrapper')]")));
                }
            }
        } catch (Exception e) {
            System.out.println("An error occurred: " + e.getMessage());
        }
    }

    public void SearchNewCreatedAssignment(String assignmentName) throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm into Search Newly Created Assignment in GradeBook");
        System.out.println("I'm into Search Newly Created Assignment in GradeBook");

//        driver.navigate().refresh();

        WebElement search_box = driver.findElement(By.xpath("//div[contains(@class,'MuiOutlinedInput-root')]//input[@placeholder='Search by name or keyword']"));
        search_box.click();

        try {
            if (search_box.isDisplayed()) {
                search_box.sendKeys(assignmentName);
                TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  Assignment Name  Search in Search box Successfully");
            }

        } catch (NoSuchElementException e) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  Search box not  found on gradeBook Dashboard");

        }

    }

    public void VerifyNewlyCreatedAssignmentOnGradeBookDashBoard(String assignmentName) throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "Verify Newly Created Assignment On GradeBook DashBoard");
        System.out.println("Verify Newly Created Assignment On GradeBook DashBoard");

        WebElement assignmentTable = wait.until(ExpectedConditions.visibilityOf(studentAssignmentTable));

        List<WebElement> assignmentContainers = assignmentTable.findElements(By.xpath(".//thead//tr//th"));
        System.out.println("Total Assignment Names are: " + assignmentContainers.size());
        TestRunner.getTest().log(Status.INFO, "Total Assignment Names are :"+ assignmentContainers.size());


        for (WebElement assignment : assignmentContainers) {
            String assignmentsName = assignment.getText();
            System.out.println("Assignment Name: " + assignmentsName);

            if (assignmentsName.equalsIgnoreCase(assignmentName)) {
                System.out.println("Found assignment: " + assignmentsName);

                try {
//                    helper.scrollToElement(driver, assignment);
                    Thread.sleep(2000);
                    assignment.click();
                    System.out.println("Assignment found");
                    TestRunner.getTest().log(Status.INFO, "Assignment found Successfully " + assignmentsName);

                    verifyDiableButtons();

                } catch (NoSuchElementException e) {
                    System.out.println("For New Assignment that student is not yet attempt Grade is Enable: " + assignmentName);
                    TestRunner.getTest().log(Status.FAIL, "Test Case Failed : For New Assignment that student is not yet attempt Grade is Enable: " + assignmentName);
                    return;
                }
                break;
            } else {
                System.out.println("Assignment not found: " + assignmentName);
            }
        }
    }

    public void verifyDiableButtons() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm verifying Grade, View, and UnSubmit buttons before Student attempts the Assignment");
        System.out.println("I'm verifying Grade, View, and UnSubmit buttons before Student attempts the Assignment");

        List<WebElement> listAssignment = driver.findElements(By.xpath("//ul[@role='menu']"));
        boolean gradeButtonFound = false;
        boolean viewButtonFound = false;
        boolean unsubmitButtonFound = false;

        for (WebElement option : listAssignment) {
            List<WebElement> menuItems = option.findElements(By.tagName("li"));

            for (WebElement menuItem : menuItems) {
                // Check if the <li> contains the "Grade", "View", or "UnSubmit" button
                String menuItemText = menuItem.getText().trim();

                if (menuItemText.equals("Grade") || menuItemText.equals("View") || menuItemText.equals("Unsubmit")) {
                    // Set flags when buttons are found
                    if (menuItemText.equals("Grade")) gradeButtonFound = true;
                    if (menuItemText.equals("View")) viewButtonFound = true;
                    if (menuItemText.equals("Unsubmit")) unsubmitButtonFound = true;

                    // Check if the button has the 'Mui-disabled' class or 'aria-disabled="true"'
                    String classAttribute = menuItem.getAttribute("class");
                    String ariaDisabled = menuItem.getAttribute("aria-disabled");

                    if (classAttribute.contains("Mui-disabled") && "true".equals(ariaDisabled)) {
                        System.out.println(menuItemText + " button is disabled as expected.");
                        TestRunner.getTest().log(Status.PASS, "Test Case Passed: " + menuItemText + " button is correctly disabled.");
                    } else {
                        // Fail if the button is not disabled
                        System.out.println(menuItemText + " button is enabled but it should be disabled.");
                        TestRunner.getTest().log(Status.FAIL, "Test Case Failed: " + menuItemText + " button is enabled, but it should be disabled.");
                        throw new AssertionError("Test Case Failed: " + menuItemText + " button is enabled, but it should be disabled.");
                    }
                }
            }
        }

// Fail the test if any button was not found in the menu
        if (!gradeButtonFound) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Grade button not found.");
            throw new AssertionError("Test Case Failed: Grade button not found.");
        }
        if (!viewButtonFound) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: View button not found.");
            throw new AssertionError("Test Case Failed: View button not found.");
        }
        if (!unsubmitButtonFound) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Unsubmit button not found.");
            throw new AssertionError("Test Case Failed: Unsubmit button not found.");
        }

    }


    // For Preview

    @FindBy(xpath = "//div[contains(text(),'Unit 1 Vocabulary Quiz')]/ancestor::div[4] | //img[contains(@src,'cardimage-vocabulary_quiz.png')]/ancestor::div[2]")
    public WebElement rowCourseVQ;

    public void OpenAssignmentTypeVQForPreview() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO,"Open Assignment Type VQ For Correct Answer");
        System.out.println("Open Assignment Type VQ for Correct Answer");
        Thread.sleep(2000);
//        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        // Find all units (even hidden)
        List<WebElement> totalUnits = driver.findElements(
                By.xpath("(//div[contains(@class, 'navigation')])[2]//a//span[contains(text(),'Unit 1')]")
        );

        String totalUnitName = null;

        for (WebElement unit : totalUnits) {
            // Get textContent instead of getText()
            totalUnitName = unit.getAttribute("textContent").trim();
            System.out.println("Unit Name: " + totalUnitName);

            if (totalUnitName.contains("Unit 1")) {
                // Expand parent panels if needed
                ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", unit);
                ((JavascriptExecutor) driver).executeScript("arguments[0].click();", unit); // JS click works even if hidden

                break;
            }
        }

        TestRunner.getTest().log(Status.PASS, "Test Case passed: " + totalUnitName + " selected successfully");

        Thread.sleep(2000);
        WebElement listContentPlayer = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@id='ContentPlayerMainPanel']")));

        if (listContentPlayer.isDisplayed() && listContentPlayer.isEnabled()) {
            WebElement btnOpenForSpecificAssignment = listContentPlayer.findElement(By.xpath("(//div[contains(@class, 'MuiBox-root')]//button[contains(text(), 'Open')])[13]"));
            btnOpenForSpecificAssignment.click();
            System.out.println("Specific Assignment Type VQ Open Successfully");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed : Specific Assignment Type VQ Open Successfully");

            Thread.sleep(3000);
            TestRunner.getTest().log(Status.INFO, "I'm into get Open Assignment Questions");
            Thread.sleep(3000);
            GetOpenAssignmentQuestion();

            if (listContentPlayer.isDisplayed() && listContentPlayer.isEnabled()) {
//                WebElement btnAssignForSpecificAssignment = listContentPlayer.findElement(By.xpath("(//div[contains(@class, 'MuiBox-root')]//button[contains(text(), 'Assign')])"));
//                btnAssignForSpecificAssignment.click();
                WebElement btnAssignForSpecificAssignment = rowCourseVQ.findElement(By.xpath(".//button[normalize-space(text())='Assign']"));
                btnAssignForSpecificAssignment.click();


                WebElement dialogAssignment = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@role='dialog']")));
                if (dialogAssignment.isDisplayed()) {
                    getAssignmentTypeFromAssignment();
                    correctAnswerExecutor_pf.EnterAssignmentTitleForCorrectAnswers();
                    correctAnswerExecutor_pf.selectSpecificClasses();
                    assignAssessment_pf.setDateTimeAndCategory();
                    assignAssessment_pf.enterAdditionalSettings();
//                    assignAssessment_pf.enterWeightPercentage();
                    releaseAssignment_pf.AdvancedGradingOptions();
                    assignAssessment_pf.assignAssignment();
                    assignAssessment_pf.verifyDialogBox();
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed : Specific Assignment Type VQ Released Successfully");
                }
            }
        }
    }

    public void getAssignmentTypeFromAssignment() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into Get Assignment type From Assignment");
        System.out.println("I'm into Get Assignment type From Assignment");

        WebElement Assignment_type_From_Assignment = driver.findElement(By.xpath("//div[contains(@class, 'MuiBox-root')]//span[contains(@class, 'css-di0a22')]"));

        assignmentTypeFromAssignment = Assignment_type_From_Assignment.getText();
        System.out.println("Assignment Type from Release Assignment is: " + assignmentTypeFromAssignment);

        TestRunner.getTest().log(Status.INFO, "Assignment Type from Release Assignment is: " + assignmentTypeFromAssignment);
        TestRunner.getTest().log(Status.PASS, "Test Case Passed : Assignment Type from Release Assignment is: " + assignmentTypeFromAssignment);

    }

        public void OpenAssignmentTypeETForPreview() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO,"Open Assignment Type ET");
        System.out.println("Open Assignment Type ET");
        Thread.sleep(2000);
        List<WebElement> totalUnits = driver.findElements(By.xpath("(//div[contains(@class, 'navigation')])[2]//a"));

        String totalUnitName = null;
        for (WebElement unit : totalUnits) {
            totalUnitName = unit.getText();
            System.out.println("Unit Name: " + totalUnitName);

            if (totalUnitName.contains("Unit 1")) {
                unit.click();
                break;
            }
        }
        TestRunner.getTest().log(Status.PASS, "Test Case passed : " + totalUnitName + " Select Successfully");

        Thread.sleep(2000);
        WebElement listContentPlayer = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@id='ContentPlayerMainPanel']")));

        if (listContentPlayer.isDisplayed() && listContentPlayer.isEnabled()) {
            WebElement btnOpenForSpecificAssignment = listContentPlayer.findElement(By.xpath("(//div[contains(@class, 'MuiBox-root')]//button[contains(text(), 'Open')])[12]"));
            btnOpenForSpecificAssignment.click();
            System.out.println("Specific Assignment Type ET Open Successfully");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed : Specific Assignment Type ET Open Successfully");

            Thread.sleep(3000);
            TestRunner.getTest().log(Status.INFO, "I'm into get Open Assignment Questions");
            Thread.sleep(3000);
            GetOpenAssignmentQuestion();

            if (listContentPlayer.isDisplayed() && listContentPlayer.isEnabled()) {
                WebElement btnAssignForSpecificAssignment = listContentPlayer.findElement(By.xpath("(//div[contains(@class, 'MuiBox-root')]//button[contains(text(), 'Assign')])"));
                btnAssignForSpecificAssignment.click();

                WebElement dialogAssignment = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@role='dialog']")));
                if (dialogAssignment.isDisplayed()) {
                    getAssignmentTypeFromAssignment();
                    correctAnswerExecutor_pf.EnterAssignmentTitleForCorrectAnswers();
                    correctAnswerExecutor_pf.selectSpecificClasses();
                    assignAssessment_pf.setDateTimeAndCategory();
                    assignAssessment_pf.enterAdditionalSettings();
//                    assignAssessment_pf.enterWeightPercentage();
                    releaseAssignment_pf.AdvancedGradingOptions();
                    assignAssessment_pf.assignAssignment();
                    assignAssessment_pf.verifyDialogBox();
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed : Specific Assignment Type ET Released Successfully");
                }
            }
        }

    }


    public void OpenAssignmentTypeVBForPreview() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO,"Open Assignment Type VB");
        System.out.println("Open Assignment Type VB");
        Thread.sleep(2000);
        List<WebElement> totalUnits = driver.findElements(By.xpath("(//div[contains(@class, 'navigation')])[2]//a"));

        String totalUnitName = null;
        for (WebElement unit : totalUnits) {
            totalUnitName = unit.getText();
            System.out.println("Unit Name: " + totalUnitName);

            if (totalUnitName.contains("Unit 1")) {
                unit.click();
                break;
            }
        }
        TestRunner.getTest().log(Status.PASS, "Test Case passed : " + totalUnitName + " Select Successfully");

        Thread.sleep(2000);
        WebElement listContentPlayer = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@id='ContentPlayerMainPanel']")));

        if (listContentPlayer.isDisplayed() && listContentPlayer.isEnabled()) {
            WebElement btnOpenForSpecificAssignment = listContentPlayer.findElement(By.xpath("(//div[contains(@class, 'MuiBox-root')]//button[contains(text(), 'Open')])[4]"));
            btnOpenForSpecificAssignment.click();
            System.out.println("Specific Assignment Type VB Open Successfully");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed : Specific Assignment Type VB Open Successfully");

            Thread.sleep(3000);
            TestRunner.getTest().log(Status.INFO, "I'm into get Open Assignment Questions");
            Thread.sleep(3000);
            GetOpenAssignmentQuestion();

            if (listContentPlayer.isDisplayed() && listContentPlayer.isEnabled()) {
                WebElement btnAssignForSpecificAssignment = listContentPlayer.findElement(By.xpath("(//div[contains(@class, 'MuiBox-root')]//button[contains(text(), 'Assign')])"));
                btnAssignForSpecificAssignment.click();

                WebElement dialogAssignment = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@role='dialog']")));
                if (dialogAssignment.isDisplayed()) {
                    getAssignmentTypeFromAssignment();
                    correctAnswerExecutor_pf.EnterAssignmentTitleForCorrectAnswers();
                    correctAnswerExecutor_pf.selectSpecificClasses();
                    assignAssessment_pf.setDateTimeAndCategory();
                    assignAssessment_pf.enterAdditionalSettings();
//                    assignAssessment_pf.enterWeightPercentage();
                    releaseAssignment_pf.AdvancedGradingOptions();
                    assignAssessment_pf.assignAssignment();
                    assignAssessment_pf.verifyDialogBox();
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed : Specific Assignment Type VB Released Successfully");
                }
            }
        }

    }

    public void OpenAssignmentTypeDSBForPreview() throws InterruptedException{

        TestRunner.getTest().log(Status.INFO,"Open Assignment Type DSB");
        System.out.println("Open Assignment Type DSB");
        Thread.sleep(2000);
        List<WebElement> totalUnits = driver.findElements(By.xpath("(//div[contains(@class, 'navigation')])[2]//a"));

        String totalUnitName = null;
        for (WebElement unit : totalUnits) {
            totalUnitName = unit.getText();
            System.out.println("Unit Name: " + totalUnitName);

            if (totalUnitName.contains("Unit 1")) {
                unit.click();
                WebElement listContentPlayer = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@id='ContentPlayerMainPanel']")));
                if (listContentPlayer.isDisplayed() && listContentPlayer.isEnabled()) {
                    WebElement btnOpenForSpecificAssignment = listContentPlayer.findElement(By.xpath("(//div[contains(@class, 'MuiBox-root')]//button[contains(text(), 'Open')])[7]"));
                    btnOpenForSpecificAssignment.click();
                }
                break;
            }
        }

        TestRunner.getTest().log(Status.PASS, "Test Case passed : " + totalUnitName + " Select Successfully");

        Thread.sleep(2000);
        WebElement listContentPlayer = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@id='ContentPlayerMainPanel']")));

        helper.scrollToElement(driver,listContentPlayer);
        Thread.sleep(1000);

        if (listContentPlayer.isDisplayed() && listContentPlayer.isEnabled()) {
            WebElement btnOpenForSpecificAssignment = listContentPlayer.findElement(By.xpath("(//div[contains(@class, 'MuiBox-root')]//button[contains(text(), 'Open')])[1]"));
            btnOpenForSpecificAssignment.click();

            System.out.println("Specific Assignment Type DSB Open Successfully");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed : Specific Assignment Type DSB Open Successfully");

            Thread.sleep(3000);
            TestRunner.getTest().log(Status.INFO, "I'm into get Open Assignment Questions");
            Thread.sleep(3000);
            GetOpenAssignmentQuestion();

            if (listContentPlayer.isDisplayed() && listContentPlayer.isEnabled()) {
                WebElement btnAssignForSpecificAssignment = listContentPlayer.findElement(By.xpath("(//div[contains(@class, 'MuiBox-root')]//button[contains(text(), 'Assign')])"));
                btnAssignForSpecificAssignment.click();

                WebElement dialogAssignment = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@role='dialog']")));
                if (dialogAssignment.isDisplayed()) {
                    getAssignmentTypeFromAssignment();
                    correctAnswerExecutor_pf.EnterAssignmentTitleForCorrectAnswers();
                    correctAnswerExecutor_pf.selectSpecificClasses();
                    assignAssessment_pf.setDateTimeAndCategory();
                    assignAssessment_pf.enterAdditionalSettings();
//                    assignAssessment_pf.enterWeightPercentage();
                    releaseAssignment_pf.AdvancedGradingOptions();
                    assignAssessment_pf.assignAssignment();
                    assignAssessment_pf.verifyDialogBox();
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed : Specific Assignment Type DSB Released Successfully");
                }
            }
        }

    }


    public void GetOpenAssignmentQuestion() throws InterruptedException {
            if (!isPaginationDisplayed()) {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Pagination not display on Open Assignment ");
            }

            try {
                List<WebElement> questionButtons = nav_Pagination.findElements(By.xpath("//button[contains(@aria-label, 'Go to page')]"));

                for (WebElement questionButton : questionButtons) {
                    String questionText = questionButton.getText();
                    System.out.println("Question: " + questionText);
                    TestRunner.getTest().log(Status.INFO, "Total Questions: " + questionText);
                }
                QuestionIDsOnOpenAssignment.clear();

                TestRunner.startTest("Get All Questions From Open Assignment Button");

                boolean hasNextPage = true;
                while (hasNextPage) {
                    GetQuestionIDInOpenAssignment();

                    try {
                        WebElement btnNextPage = driver.findElement(By.xpath("//button[@aria-label='Go to next page']"));
                        if (btnNextPage.isEnabled()) {
                            btnNextPage.click();
                            TestRunner.getTest().log(Status.INFO, "Navigating to the next page.");
                            Thread.sleep(2000);
                        } else {
                            hasNextPage = false;
                        }
                    } catch (NoSuchElementException e) {
                        hasNextPage = false;
                        TestRunner.getTest().log(Status.INFO, "Reached the last page.");
                    }
                }

//                while (btn_NavNextPage.isEnabled()) {
//                    Thread.sleep(2000);
//                    GetQuestionIDInOpenAssignment();
//                    btn_NavNextPage.click();
//                    Thread.sleep(2000);
//                }

                System.out.println("All Assignment Questions get Successfully From Open Assignment");
                TestRunner.getTest().log(Status.INFO, "All Assignment Questions get Successfully From Open Assignment");
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: All Assignment Questions get Successfully From Open Assignment");

            } catch (NoSuchElementException | ElementNotInteractableException | TimeoutException e) {
                System.out.println("No Question found.");
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed : No Question found or Question not visible");
            }
        }

        private boolean isPaginationDisplayed() {
            try {
                return nav_Pagination.isDisplayed();
            } catch (NoSuchElementException | ElementNotInteractableException | TimeoutException e) {
                return false;
            }
    }

    public void GetQuestionIDInOpenAssignment() throws InterruptedException{
        Thread.sleep(3000);
        System.out.println("I'm in Getting all questions From Open Button");
        Thread.sleep(1000);

        WebElement questionPlayer = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("lesson-player-ifram")));
        driver.switchTo().frame(questionPlayer);
        WebElement QuestionBody = driver.findElement(By.xpath("//div[contains(@class, 'LessonPlayerRoot')]"));

        WebElement QuestionPlayer = null;

        try {
            List<WebElement> MultiParts = QuestionBody.findElements(By.xpath("//div[contains(@class, 'planComponentQuestion')]"));
            System.out.println("Total number of multi-part on this page: " + MultiParts.size());
            TestRunner.getTest().log(Status.INFO, "Total part of question (if multipart question exists): " + MultiParts.size());

            for (WebElement part : MultiParts) {
                QuestionPlayer = part.findElement(By.xpath(".//div[contains(@class, 'QuestionPlayer')]"));

                System.out.println("Question is found");
                String questionType = QuestionPlayer.getAttribute("data-type");
                System.out.println("Question Type is: " + questionType);
                TestRunner.getTest().log(Status.INFO, "Attempted question type is: " + questionType);

                WebElement questionRoot = QuestionPlayer.findElement(By.xpath(".//div[contains(@class, 'question-root')]"));
                questionID = questionRoot.getAttribute("data-question-id");
                System.out.println("Question ID is: " + questionID);
                TestRunner.getTest().log(Status.INFO, "Attempted question ID is: " + questionID);

                System.out.println("I'm in to store Question ID's In Open Assignment: " + questionID);
                TestRunner.getTest().log(Status.INFO, "I'm in to store Question ID's In Open Assignment : " + questionID);
                QuestionIDsOnOpenAssignment.add(questionID);
                System.out.println("Question ID's: " + QuestionIDsOnOpenAssignment);

            }
        } catch (NoSuchElementException e) {
            System.out.println("This is a content player question and have no any data type question");
            TestRunner.getTest().log(Status.INFO, "This is a content player question and have no any data type question");
            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
        } finally {
            driver.switchTo().defaultContent();
        }
    }


    public void OpenAssignmentTypeVQForPreviewFromGradeBook(String assignmentName) throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm into Open the Assignment For Preview");
        System.out.println("I'm into Open the Assignment For Preview");


        WebElement assignmentTable = wait.until(ExpectedConditions.visibilityOf(studentAssignmentTable));

        List<WebElement> assignmentContainers = assignmentTable.findElements(By.xpath(".//thead//tr//th"));
        System.out.println("Total Assignment Names are: " + assignmentContainers.size());

        for (int i = 0; i < assignmentContainers.size(); i++) {
            WebElement assignment = assignmentContainers.get(i);
            String assignmentsName = assignment.getText();
            System.out.println("Assignment Name: " + assignmentsName);

            if (assignmentsName.equalsIgnoreCase(assignmentName)) {
                System.out.println("Found assignment: " + assignmentsName);

                boolean staleElement = true;
                while (staleElement) {
                    try {
                        // Re-locate the assignment element to avoid stale element issues
                        assignmentContainers = assignmentTable.findElements(By.xpath(".//thead//tr//th"));
                        assignment = assignmentContainers.get(i);

                        // Wait until the assignment is clickable
                        wait.until(ExpectedConditions.elementToBeClickable(assignment));
                        assignment.click();
                        staleElement = false; // Break the loop as element is successfully clicked

                        System.out.println("Assignment found");
                        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Assignment found successfully " + assignmentsName);

                        // Perform other actions
                        Thread.sleep(1000);
//                        new WebDriverWait(driver, Duration.ofSeconds(20));
//                        clickGradeButton();
                        TestRunner.getTest().log(Status.INFO, "I'm in Preview on Button");
                        ClickOnPreviewButton();
                        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Click on Preview button successfully " + assignmentsName);

                    } catch (StaleElementReferenceException e) {
                        System.out.println("StaleElementReferenceException occurred. Retrying...");
                        staleElement = true; // Continue the loop to re-locate and retry
                    } catch (NoSuchElementException e) {
                        TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Preview button not found for assignment: " + assignmentName);
                        return;
                    }
                }
                break; // Exit loop once the desired assignment is found and processed
            }
        }
    }

    public void ClickOnPreviewButton() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm into Click on Preview Button");
        System.out.println("I'm into Click on Preview Button");

        List<WebElement> listAssignment = driver.findElements(By.xpath("//ul[@role='menu']"));

        for (WebElement option : listAssignment) {
            List<WebElement> buttons = option.findElements(By.tagName("button"));

            for (WebElement button : buttons) {
                String buttonText = button.getText().trim();

                if (buttonText.equals("Preview") && button.isEnabled() && button.isDisplayed()) {
                    button.click();
                    System.out.println("Clicked on Preview button.");
                    return;
                }
            }
        }
    }

    public void VerifyGradeBookPreviewQuestions() throws InterruptedException{
        TestRunner.startTest("I'm into Get All questions From Preview gradeBook");

        if (!isPaginationDisplayed()) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Pagination not display on Open Assignment ");
        }

        try {
            List<WebElement> questionButtons = nav_Pagination.findElements(By.xpath("//button[contains(@aria-label, 'Go to page')]"));

            for (WebElement questionButton : questionButtons) {
                String questionText = questionButton.getText();
                System.out.println("Question: " + questionText);
                TestRunner.getTest().log(Status.INFO, "Total Questions: " + questionText);
            }
            QuestionIDsPreviewGradeBook.clear();

            TestRunner.startTest("Get All Question From Preview GradeBook");

            boolean hasNextPage = true;
            while (hasNextPage) {
                GetQuestionIdsFromGradeBookPreview();

                try {
                    WebElement btnNextPage = driver.findElement(By.xpath("//button[@aria-label='Go to next page']"));
                    if (btnNextPage.isEnabled()) {
                        btnNextPage.click();
                        TestRunner.getTest().log(Status.INFO, "Navigating to the next page.");
                        Thread.sleep(2000);
                    } else {
                        hasNextPage = false;
                    }
                } catch (NoSuchElementException e) {
                    hasNextPage = false;
                    TestRunner.getTest().log(Status.INFO, "Reached the last page.");
                }
            }

            System.out.println("All Assignment Questions get Successfully From Preview GradBook");
            TestRunner.getTest().log(Status.INFO, "All Assignment Questions get Successfully From Preview GradBook");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: All Assignment Questions get Successfully From Preview GradBook");
            ClickOnCrossButton();

        } catch (NoSuchElementException | ElementNotInteractableException | TimeoutException e) {
            System.out.println("No Question found.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : No Question found or Question not visible");
        }
    }

    public void ClickOnCrossButton() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm into click on x button on Preview GradeBook");
        System.out.println("I'm into click on x button on Preview GradeBook");


        WebElement crossButton= driver.findElement(By.xpath("//button[@aria-label='close']"));
        if (crossButton.isDisplayed()){
            crossButton.click();
            System.out.println("X button Found and click successfully");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: X button click Successfully");
        }else {
            System.out.println("X button not found");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: X button Not Found");

        }
    }

    public void GetQuestionIdsFromGradeBookPreview() throws InterruptedException{
        Thread.sleep(3000);
        System.out.println("I'm in Getting all questions From Preview GradBook");
        Thread.sleep(1000);
//        new WebDriverWait(driver, Duration.ofSeconds(30));

        WebElement questionPlayer = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("lesson-player-ifram")));
        driver.switchTo().frame(questionPlayer);
        WebElement QuestionBody = driver.findElement(By.xpath("//div[contains(@class, 'LessonPlayerRoot')]"));

        WebElement QuestionPlayer = null;

        try {
            List<WebElement> MultiParts = QuestionBody.findElements(By.xpath("//div[contains(@class, 'planComponentQuestion')]"));
            System.out.println("Total number of multi-part on this page: " + MultiParts.size());
            TestRunner.getTest().log(Status.INFO, "Total part of question (if multipart question exists): " + MultiParts.size());

            for (WebElement part : MultiParts) {
                QuestionPlayer = part.findElement(By.xpath(".//div[contains(@class, 'QuestionPlayer')]"));

                System.out.println("Question is found");
                String questionType = QuestionPlayer.getAttribute("data-type");
                System.out.println("Question Type is: " + questionType);
                TestRunner.getTest().log(Status.INFO, "Attempted question type is: " + questionType);

                WebElement questionRoot = QuestionPlayer.findElement(By.xpath(".//div[contains(@class, 'question-root')]"));
                questionID = questionRoot.getAttribute("data-question-id");
                System.out.println("Question ID is: " + questionID);
                TestRunner.getTest().log(Status.INFO, "Attempted question ID is: " + questionID);

                System.out.println("I'm in to store Question ID's In Open Assignment: " + questionID);
                TestRunner.getTest().log(Status.INFO, "I'm in to store Question ID's In Open Assignment : " + questionID);
                QuestionIDsPreviewGradeBook.add(questionID);
                System.out.println("Question ID's: " + QuestionIDsPreviewGradeBook);

            }
        } catch (NoSuchElementException e) {
            System.out.println("This is a content player question and have no any data type question");
            TestRunner.getTest().log(Status.INFO, "This is a content player question and have no any data type question");

            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
        } finally {
            driver.switchTo().defaultContent();
        }
    }

    public void VerificationOfPreview() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm verifying that questions from Assignment Open Button and from Preview GradeBook match.");
        System.out.println("I'm verifying that questions from Assignment Open Button and from Preview GradeBook match.");

        // Assuming QuestionIDsOnOpenAssignment and QuestionIDsPreviewGradeBook are populated elsewhere
        if (QuestionIDsOnOpenAssignment.isEmpty() || QuestionIDsPreviewGradeBook.isEmpty()) {
            System.out.println("One of the lists is empty, cannot compare.");
            TestRunner.getTest().log(Status.FAIL, "One of the lists is empty, cannot compare.");
            return;
        }

        // Ensure both lists have the same size before comparing
        if (QuestionIDsOnOpenAssignment.size() != QuestionIDsPreviewGradeBook.size()) {
            System.out.println("The lists are of different sizes, comparison cannot be done.");
            TestRunner.getTest().log(Status.FAIL, "The lists are of different sizes, comparison cannot be done.");
            return;
        }

        // Compare lists index by index
        for (int i = 0; i < QuestionIDsOnOpenAssignment.size(); i++) {
            String idFromOpen = QuestionIDsOnOpenAssignment.get(i);
            String idFromPreview = QuestionIDsPreviewGradeBook.get(i);

            // Add 1 to the index in the output to start from 1
            if (idFromOpen.equals(idFromPreview)) {
                System.out.println("Question " + (i + 1) + ": IDs match (" + idFromOpen + ")");
                TestRunner.getTest().log(Status.PASS, "Question " + (i + 1) + ": IDs match (" + idFromOpen + ")");
            } else {
                System.out.println("Question " + (i + 1) + ": IDs do not match (Open: " + idFromOpen + ", Preview: " + idFromPreview + ")");
                TestRunner.getTest().log(Status.FAIL, "Question " + (i + 1) + ": IDs do not match (Open: " + idFromOpen + ", Preview: " + idFromPreview + ")");
            }
        }
    }

    public void VerificationOfPreviewAtStudentSide() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm verifying that questions from Assignment Open Button and Question At Student Side are same.");
        System.out.println("I'm verifying that questions from Assignment Open Button and Question At Student Side are same");

        if (QuestionIDsOnOpenAssignment.isEmpty() || QuestionIDsPreviewGradeBook.isEmpty()) {
            System.out.println("One of the lists is empty, cannot compare.");
            TestRunner.getTest().log(Status.FAIL, "One of the lists is empty, cannot compare.");
            return;
        }

        // Ensure both lists have the same size before comparing
        if (QuestionIDsOnOpenAssignment.size() != QuestionIDsPreviewGradeBook.size()) {
            System.out.println("The lists are of different sizes, comparison cannot be done.");
            TestRunner.getTest().log(Status.FAIL, "The lists are of different sizes, comparison cannot be done.");
            return;
        }

        // Compare lists index by index
        for (int i = 0; i < QuestionIDsOnOpenAssignment.size(); i++) {
            String idFromOpen = QuestionIDsOnOpenAssignment.get(i);
            List<String> questionIDsList = CorrectAnswerExecutor_PF.questionIDs.get();
            String idFromStudentSideQuestions = questionIDsList.get(i);

            // Add 1 to the index in the output to start from 1
            if (idFromOpen.equals(idFromStudentSideQuestions)) {
                System.out.println("Question " + (i + 1) + ": IDs match (" + idFromOpen + ")");
                TestRunner.getTest().log(Status.PASS, "Question " + (i + 1) + ": IDs match (" + idFromOpen + ")");
            } else {
                System.out.println("Question " + (i + 1) + ": IDs do not match (Open: " + idFromOpen + ", Preview: " + idFromStudentSideQuestions + ")");
                TestRunner.getTest().log(Status.FAIL, "Question " + (i + 1) + ": IDs do not match (Open: " + idFromOpen + ", Preview: " + idFromStudentSideQuestions + ")");
            }
        }

    }

}
