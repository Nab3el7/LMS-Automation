package pageFactory.Gradebook;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Assignmment.AdvancedGrading_PF;
import pageFactory.Assignmment.CorrectAnswerExecutor_PF;
import pageFactory.Assignmment.StudentExecutor_PF;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static pageFactory.Assignmment.InCorrectAnswerExecutor_PF.AssignmentNameForInCorrect;

public class AssignmentScoreVerification_PF {
    WebDriverWait wait;
    WebDriver driver;
    Helper helper;

//   public static String totalScore;
    public static ThreadLocal<String> totalQuestions = ThreadLocal.withInitial(() -> "");

    public static ThreadLocal<String> totalScore = ThreadLocal.withInitial(() -> "");


    StudentExecutor_PF studentExecutor;
    AdvancedGrading_PF advancedGrading_pf;
    ManualGrading_PF manualGrading_pf;
    CorrectAnswerExecutor_PF correctAnswerExecutor_pf;
    GradeBookView_PF gradeBookView_pf;

    @FindBy(xpath = "//div[@aria-labelledby='simple-tab-2']")
    WebElement panel_Assignments;

    public AssignmentScoreVerification_PF(WebDriver driver) {
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        helper = new Helper();
        studentExecutor = new StudentExecutor_PF(driver);
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        advancedGrading_pf = new AdvancedGrading_PF(driver);
        manualGrading_pf = new ManualGrading_PF(driver);
        correctAnswerExecutor_pf = new CorrectAnswerExecutor_PF(driver);
        gradeBookView_pf = new GradeBookView_PF(driver);
    }

    public void ReviewAttemptedCorrectAnswersAssignmentIntoClosedTab() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Review attempted Correct answers assignment in Closed tab");


        // Access the assignmentNameForCorrect value from CorrectAnswerExecutor_PF directly
        String searchingAssignmentName = CorrectAnswerExecutor_PF.assignmentNameForCorrect.get();
        System.out.println("Want to search assessment in closed tab: " + searchingAssignmentName);
        System.out.println("Another method" + CorrectAnswerExecutor_PF.getAssignmentName());


        TestRunner.getTest().log(Status.INFO, "Want to search assessment in closed tab: " + searchingAssignmentName);
        WebElement searchBar = driver.findElement(By.xpath("//input[@placeholder='Search Assignment by Title']"));  // Locate search bar
        searchBar.click();
        String os = System.getProperty("os.name").toLowerCase();
        Keys commandKey = os.contains("mac") ? Keys.COMMAND : Keys.CONTROL;
        searchBar.click();
        searchBar.sendKeys(Keys.chord(commandKey, "a"));
        searchBar.sendKeys(Keys.DELETE);
        Thread.sleep(500);
        searchBar.clear();

        searchBar.sendKeys(searchingAssignmentName);
        Thread.sleep(2000);

        WebElement searchBtn= driver.findElement(By.xpath("//button[contains(@class,'MuiButtonBase-root MuiIconButton-root MuiIconButton-edgeStart')]"));
        searchBtn.click();
        Thread.sleep(5000);

        WebElement myAssignmentGrid = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@aria-labelledby='simple-tab-2']")));
        boolean assignmentFound = false;

        if (myAssignmentGrid.isDisplayed() && myAssignmentGrid.isEnabled()) {
            WebElement btnClosed = driver.findElement(By.xpath("//button[@id='simple-tab-3']"));
            btnClosed.click();

            WebElement panelTabClosed = driver.findElement(By.xpath("//div[@id='simple-tabpanel-3']"));

            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='simple-tabpanel-3']")));
            Thread.sleep(3000);
//            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));  // Explicit wait


            String textClosedAssignments = panelTabClosed.getText();
            System.out.println("Closed Assignments are");
            System.out.println(textClosedAssignments);

            List<WebElement> totalAssignments = driver.findElements(By.xpath(".//div[contains(@class, 'MuiGrid-container')]"));
            System.out.println("Total Assignments: " + totalAssignments.size());

            for (WebElement assignment : totalAssignments) {
                try {
                    WebElement assignmentNameElement = assignment.findElement(By.xpath(".//div[contains(@class, 'notranslate')]"));
                    String assignmentsName = assignmentNameElement.getText();

                    if (assignmentsName.equals(searchingAssignmentName)) {
                        System.out.println("Found assignment: " + assignmentsName);
                        TestRunner.getTest().log(Status.INFO, "Assignment name in close tab: " + assignmentsName);
                        assignmentFound = true;
                        try {
                            WebElement reviewButton = assignment.findElement(By.xpath(".//button[.//span[contains(text(), 'Review')] and not(@disabled)]"));
                            TestRunner.getTest().log(Status.PASS, "Test Case Passed : Review button found and click on " + reviewButton.getText());
                            reviewButton.click();
                            System.out.println("Assignment open");
                            Thread.sleep(3000);
                            studentExecutor.handleTeacherInstructionsDialog();
                            getGradingsSummary();
                        } catch (NoSuchElementException e) {
                            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Review button not found for assignment: " + searchingAssignmentName);
                            return;
                        }
                        break;
                    } else {
                        System.out.println("Assignment not found: " + assignmentsName);
                    }
                } catch (NoSuchElementException e) {
                    // Assignment name element not found, skip this assignment and continue
                    continue;
                }
            }

        }else {

            System.out.println("Student dashboard not loaded");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Student dashboard not loaded");
        }

        if (!assignmentFound) {
            System.out.println("Assignment not found: " + searchingAssignmentName);
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Assignment not found: " + searchingAssignmentName);
        }

    }

//    AssignmentNameForInCorrect
    public void ReviewAttemptedInCorrectAnswersAssignmentIntoClosedTab() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Review attempted inCorrect answers assignment in Closed tab");

        WebElement myAssignmentGrid = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[@class='ScrollbarsCustom-Content'])[2]")));

        String assignmentNameForCorrect = CorrectAnswerExecutor_PF.assignmentNameForCorrect.get();
        System.out.println("Want to search assessment for review in closed tab: " + assignmentNameForCorrect);
        TestRunner.getTest().log(Status.INFO, "Want to search assessment for review in closed tab: " + assignmentNameForCorrect);


        if (myAssignmentGrid.isDisplayed() && myAssignmentGrid.isEnabled()) {
            WebElement btnClosed = driver.findElement(By.xpath("//button[@id='simple-tab-3']"));
            btnClosed.click();

            WebElement panelTabClosed = panel_Assignments.findElement(By.xpath("//div[@id='simple-tabpanel-3']"));

            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='simple-tabpanel-3']")));
            Thread.sleep(5000);

            String textClosedAssignments = panelTabClosed.getText();
            System.out.println("Closed Assignments are");
            System.out.println(textClosedAssignments);

            List<WebElement> totalAssignments = panel_Assignments.findElements(By.xpath(".//div[contains(@class, 'MuiGrid-container')]"));
            System.out.println("Total Assignments: " + totalAssignments.size());

            boolean assignmentFound = false;

            TestRunner.getTest().log(Status.INFO, "Want to search assessment in closed tab: " + AssignmentNameForInCorrect);

            for (WebElement assignment : totalAssignments) {
                WebElement assignmentNameElement = assignment.findElement(By.xpath(".//div[contains(@class, 'notranslate')]"));
                String assignmentsName = assignmentNameElement.getText();

                if (assignmentsName.equals(AssignmentNameForInCorrect)) {
                    System.out.println("Found assignment: " + assignmentsName);
                    assignmentFound = true;
                    try {
                        WebElement reviewButton = assignment.findElement(By.xpath(".//button[.//span[contains(text(), 'Review')] and not(@disabled)]"));
                        TestRunner.getTest().log(Status.PASS, "Test Case Passed : Review button found and click on " + reviewButton.getText());
                        reviewButton.click();
                        System.out.println("Assignment open");
                        Thread.sleep(3000);
                        studentExecutor.handleTeacherInstructionsDialog();
                        getGradingsSummary();
                    } catch (NoSuchElementException e) {

                        TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Review button not found for assignment: " + assignmentNameForCorrect);

                        return;
                    }
                    break;
                } else {

                    System.out.println("Assignment not found: " + assignmentNameForCorrect);
                }

            }

            if (!assignmentFound) {
                // Attempt to use the search bar to find the assignment
                System.out.println("Assignment not found in list, trying search bar: " + AssignmentNameForInCorrect);
                TestRunner.getTest().log(Status.INFO, "Assignment not found in list, trying search bar: " + AssignmentNameForInCorrect);

                try {
                    WebElement searchBar = driver.findElement(By.xpath("//input[@placeholder='Search Assignment by Keyword']"));
                    searchBar.clear();
                    searchBar.click();
                    searchBar.sendKeys(AssignmentNameForInCorrect);
                    searchBar.sendKeys(Keys.ENTER);
                    Thread.sleep(3000); // Wait for search results to load

                    List<WebElement> searchResults = panel_Assignments.findElements(By.xpath(".//div[contains(@class, 'MuiGrid-container')]"));

                    for (WebElement assignment : searchResults) {
                        WebElement assignmentNameElement = assignment.findElement(By.xpath(".//div[contains(@class, 'notranslate')]"));
                        String assignmentsName = assignmentNameElement.getText();

                        if (assignmentsName.equals(AssignmentNameForInCorrect)) {
                            System.out.println("Found assignment via search: " + assignmentsName);
                            assignmentFound = true;
                            WebElement reviewButton = assignment.findElement(By.xpath(".//button[.//span[contains(text(), 'Review')] and not(@disabled)]"));
                            TestRunner.getTest().log(Status.PASS, "Test Case Passed : Review button found and click on " + reviewButton.getText());
                            reviewButton.click();
                            System.out.println("Assignment open");
                            Thread.sleep(3000);
                            studentExecutor.handleTeacherInstructionsDialog();
                            getGradingsSummary();
                            break;
                        }
                    }

                    if (!assignmentFound) {
                        TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Assignment not found even after searching: " + AssignmentNameForInCorrect);
                    }

                } catch (NoSuchElementException e) {
                    TestRunner.getTest().log(Status.FAIL, "Search bar not found or assignment still not found: " + AssignmentNameForInCorrect);
                }

                TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Assignment not found: " + assignmentNameForCorrect);
            }
        } else {
            System.out.println("Student dashboard not loaded");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Student dashboard not loaded");
        }

    }

    public void getGradingsSummary() throws InterruptedException {
        TestRunner.startTest("Grading Summary in Closed Assignment");
        String contentTypeValue = "";
        try {
            WebElement controlPanel = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class,'ControlPanel')]")));

            String classAttribute = controlPanel.getAttribute("class");
            System.out.println("ControlPanel class attribute: " + classAttribute);

            Pattern pattern = Pattern.compile("contentType-\\d+");
            Matcher matcher = pattern.matcher(classAttribute);
            if (matcher.find()) {
                contentTypeValue = matcher.group();
                System.out.println("Extracted contentType: " + contentTypeValue);
                TestRunner.getTest().log(Status.INFO, "Extracted contentType: " + contentTypeValue);
            } else {
                System.out.println("contentType not found in class attribute");
                TestRunner.getTest().log(Status.WARNING, "contentType not found in class attribute");
            }

            WebElement questionPlayer = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("lesson-player-ifram")));
            driver.switchTo().frame(questionPlayer);

            if ("contentType-1".equals(contentTypeValue)) {
                WebElement totalScoreElement = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='pointWrapper']//span[1]")));
                String totalScoreText = totalScoreElement.getText().trim();
                System.out.println("Total Score from iframe (contentType-1): " + totalScoreText);
                setAssignmentScore(totalScoreText);
                TestRunner.getTest().log(Status.INFO, "Total Score: " + totalScoreText);

//                driver.switchTo().defaultContent();
            } else {
                WebElement overviewWrapper = driver.findElement(By.className("OverviewScreenWrapper"));

                totalQuestions.set(getElementTextByType(overviewWrapper, "totalquestion"));
                String answered = getElementTextByType(overviewWrapper, "answered");
                String unanswered = getElementTextByType(overviewWrapper, "unanswered");
                String flagged = getElementTextByType(overviewWrapper, "flagged");
                String correct = getElementTextByType(overviewWrapper, "correct");
                String incorrect = getElementTextByType(overviewWrapper, "Incorrect");
                String partial = getElementTextByType(overviewWrapper, "partial");

                System.out.println("Review Summary:");
                System.out.println("Total Questions: " + totalQuestions.get());
                System.out.println("Answered: " + answered);
                System.out.println("Unanswered: " + unanswered);
                System.out.println("Flagged: " + flagged);
                System.out.println("Correct: " + correct);
                System.out.println("Incorrect: " + incorrect);
                System.out.println("Partial: " + partial);

                TestRunner.getTest().log(Status.INFO, "Total Questions: " + totalQuestions.get() +
                        ", Answered: " + answered + ", Unanswered: " + unanswered +
                        ", Flagged: " + flagged +
                        ", Correct: " + correct + ", Incorrect: " + incorrect +
                        ", Partial: " + partial);

                try {
                    String assignmentTotalScore = overviewWrapper.findElement(By.xpath(".//div[@class='score']")).getText();
                    assignmentTotalScore.replaceAll("%", "").trim();
                    System.out.println("Total Score: " + assignmentTotalScore);

                    setAssignmentScore(assignmentTotalScore);
                    TestRunner.getTest().log(Status.INFO, "Total Score: " + totalScore.get());
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed : Grading summary available");
                } catch (Exception e) {
                    System.out.println(e);
                    TestRunner.getTest().log(Status.INFO, "Grades not available");
                }
            }
        } catch (NoSuchElementException e) {
            if (!"contentType-1".equals(contentTypeValue)) {
                System.out.println("Error retrieving data: Element not found. " + e.getMessage());
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Review Button Not Available");
            }
        } finally {
            driver.switchTo().defaultContent();
        }

        Thread.sleep(2000);
        WebElement btn_CloseReview = driver.findElement(By.xpath("//button[@id='closeReview-btn']"));
        helper.scrollToElement(driver, btn_CloseReview);
        Thread.sleep(1000);
        System.out.println("Clicked on close review");
        btn_CloseReview.click();
        TestRunner.getTest().log(Status.PASS, "Test Case Passed : Close Review of Assignment");
    }

    public static void setAssignmentScore(String assignmentScore) {
        totalScore.set(assignmentScore);
    }

    public static String getAssignmentScore() {
        return totalScore.get();
    }

    private String getElementTextByType(WebElement parent, String type) {
        try {
            return parent.findElement(By.xpath(".//div[@type='" + type + "']")).getText();
        } catch (NoSuchElementException e) {
            System.out.println("Element not found for type: " + type);
            return "N/A";
        }
    }

    public void ClickOnScoreViewIntoPoints() {
        WebElement headerGrading = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class, 'GradingHeaderWrapperAssignmentItem')]")));
        WebElement groupView = headerGrading.findElement(By.xpath(".//div[@aria-label='Platform']"));

        WebElement pointsButton = groupView.findElement(By.xpath(".//button[contains(@value, 'point')]"));

        String ariaPressed = pointsButton.getAttribute("aria-pressed");
        if (ariaPressed.equals("false")) {
            pointsButton.click();
        }
        TestRunner.getTest().log(Status.PASS, "Test Case Passed    :   Click On Score ViewIntoPoints Successfully ");

    }

    public void AssignmentScoresSummaryForVerification() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Getting Assignment Score for Verification Updated UI");

        Thread.sleep(1000);

        String teacher_score = ManualGrading_PF.highestScoreGradebookSummary.get();
        System.out.println("teacher side score: " + teacher_score);
        TestRunner.getTest().log(Status.INFO, "Teacher side score: " + teacher_score);

        String assignmentTotalScore = AssignmentScoreVerification_PF.totalScore.get();
        System.out.println("Assignment total score: " + assignmentTotalScore);
        TestRunner.getTest().log(Status.INFO, "Assignment total score: " + assignmentTotalScore);

        String cleanedTotalScore = assignmentTotalScore.replaceAll("%", "").trim();
        System.out.println("Total Score after we remove % : " + cleanedTotalScore);
        TestRunner.getTest().log(Status.INFO,"Total Score % : " + cleanedTotalScore);

        double scoreValue = Double.parseDouble(cleanedTotalScore);

        long roundedScore = Math.round(scoreValue);

        String roundedScoreStr = Long.toString(roundedScore);
        System.out.println("Rounded Total Score: " + roundedScoreStr);

        System.out.println("Highest Score: " + teacher_score);
        TestRunner.getTest().log(Status.INFO, " Highest Score: " + teacher_score);

        if (teacher_score.equals(roundedScoreStr)) {
            TestRunner.getTest().log(Status.INFO, "Teacher Side Score: " + teacher_score + " Student Side Score:"+ roundedScoreStr);
            TestRunner.getTest().log(Status.PASS, "Test case Passed: The highest score matches the total score.");
            System.out.println("The highest score matches the total score.");
        } else {
            TestRunner.getTest().log(Status.INFO, "Teacher Side Score:" + teacher_score + " Student Side Score"+ roundedScoreStr);
            TestRunner.getTest().log(Status.FAIL, "Test case Failed: The highest score does not match the total score.");
//            throw new RuntimeException("Highest score does not match the total score.");
        }
    }

    public void AssignmentScoresSummaryForVerificationUpdatedUI() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Getting Assignment Score for Verification Updated UI");

        Thread.sleep(1000);
//        WebElement assignmentSummary = driver.findElement(By.xpath("//div[contains(@class, 'AssignmentSummaryCountWrappe')]"));
//        WebElement countsSummary = assignmentSummary.findElement(By.xpath(".//div[contains(@class, 'AssCountWrapper')][span[text()='Highest Score']]/span[1]"));

        String teacher_score = ManualGrading_PF.highestScoreGradebookSummary.get();
        System.out.println("teacher side score: " + teacher_score);
        TestRunner.getTest().log(Status.INFO, "Teacher side score: " + teacher_score);

        String assignmentTotalScore = AssignmentScoreVerification_PF.totalScore.get();
        System.out.println("Assignment total score: " + assignmentTotalScore);
        TestRunner.getTest().log(Status.INFO, "Assignment total score: " + assignmentTotalScore);

        String cleanedTotalScore = assignmentTotalScore.replaceAll("%", "").trim();
        System.out.println("Total Score after we remove % : " + cleanedTotalScore);
        TestRunner.getTest().log(Status.INFO,"Total Score % : " + cleanedTotalScore);

        double scoreValue = Double.parseDouble(cleanedTotalScore);

        long roundedScore = Math.round(scoreValue);

        String roundedScoreStr = Long.toString(roundedScore);
        System.out.println("Rounded Total Score: " + roundedScoreStr);

        System.out.println("Highest Score: " + teacher_score);
        TestRunner.getTest().log(Status.INFO, " Highest Score: " + teacher_score);

        if (teacher_score.equals(roundedScoreStr)) {
            TestRunner.getTest().log(Status.INFO, "Teacher Side Score: " + teacher_score + " Student Side Score:"+ roundedScoreStr);
            TestRunner.getTest().log(Status.PASS, "Test case Passed: The highest score matches the total score.");
            System.out.println("The highest score matches the total score.");
        } else {
            TestRunner.getTest().log(Status.INFO, "Teacher Side Score:" + teacher_score + " Student Side Score"+ roundedScoreStr);
            TestRunner.getTest().log(Status.FAIL, "Test case Failed: The highest score does not match the total score.");
//            throw new RuntimeException("Highest score does not match the total score.");
        }
    }


    public void PrintAndVerifyStudentScoreWithAssignmentScore() throws InterruptedException {
        PrintAndVerifyTableInfo();
        PrintAndStoreTableInfo();
        TestRunner.getTest().log(Status.INFO, "Verify Student List and Scores");
        Thread.sleep(2000);
        WebElement table = driver.findElement(By.xpath("//div[contains(@class, 'StudentGradingWrapper')]"));
        List<WebElement> rows = table.findElements(By.xpath(".//tbody/tr"));

        for (WebElement row : rows) {
            WebElement studentCell = row.findElement(By.xpath(".//td[1]"));
            String studentName = studentCell.getText().trim();
            System.out.println("Students Name: " + studentName);
            TestRunner.getTest().log(Status.INFO, "Students Name: " + studentName);

            // Check the status of Student
            WebElement statusCell = row.findElement(By.xpath(".//td[2]//input"));
            String status = statusCell.getAttribute("value").trim();
            System.out.println("Student Status: " + status);
            TestRunner.getTest().log(Status.INFO, "Student Status: " + status);

            // Check if the status is 'Submitted' or 'Graded'
            if (status.equalsIgnoreCase("Submitted") || status.equalsIgnoreCase("Graded")) {
                WebElement scoreCell = row.findElement(By.xpath(".//td[3]"));
                String score = scoreCell.getText().trim();
                Thread.sleep(500);
                helper.scrollToElement(driver, scoreCell);
                Thread.sleep(2000);

                System.out.println("Student: " + studentName + " Status: " + status + " Original Score: " + score);
                TestRunner.getTest().log(Status.INFO, "Student: " + studentName + " Status: " + status + " Original Score: " + score);
                System.out.println("Total Assignment Score in Closed Assignment: " + totalScore.get());
                TestRunner.getTest().log(Status.INFO, "Total Assignment Score in Closed Assignment: " + totalScore.get());
                break;
            }
        }
    }

    public void PrintAndVerifyStudentScoreWithAssignmentScoreUpdatedUI() throws InterruptedException {
        PrintAndVerifyTableInfo();
        PrintAndStoreTableInfo();
        TestRunner.getTest().log(Status.INFO, "Verify Student List and Scores");
        Thread.sleep(2000);
        WebElement table = driver.findElement(By.xpath("//div[contains(@class, 'StudentGradingWrapper')]"));
        List<WebElement> rows = table.findElements(By.xpath(".//tbody/tr"));

        for (WebElement row : rows) {
            WebElement studentCell = row.findElement(By.xpath(".//td[1]"));
            String studentName = studentCell.getText().trim();
            System.out.println("Students Name: " + studentName);
            TestRunner.getTest().log(Status.INFO, "Students Name: " + studentName);

            // Check the status of Student
            WebElement statusCell = row.findElement(By.xpath(".//td[2]//input"));
            String status = statusCell.getAttribute("value").trim();
            System.out.println("Student Status: " + status);
            TestRunner.getTest().log(Status.INFO, "Student Status: " + status);

            // Check if the status is 'Submitted' or 'Graded'
            if (status.equalsIgnoreCase("Submitted") || status.equalsIgnoreCase("Graded")) {
                WebElement scoreCell = row.findElement(By.xpath(".//td[3]"));
                String score = scoreCell.getText().trim();
                Thread.sleep(500);
                helper.scrollToElement(driver, scoreCell);
                Thread.sleep(2000);

                System.out.println("Student: " + studentName + " Status: " + status + " Original Score: " + score);
                TestRunner.getTest().log(Status.INFO, "Student: " + studentName + " Status: " + status + " Original Score: " + score);
                System.out.println("Total Assignment Score in Closed Assignment: " + totalScore.get());
                TestRunner.getTest().log(Status.INFO, "Total Assignment Score in Closed Assignment: " + totalScore.get());

                WebElement addCommentCell = row.findElement(By.xpath(".//td[5]//button[@type='button'][normalize-space()='Add Comment']"));

                if (addCommentCell != null) {
                    String commentBtnText = addCommentCell.getText();
                    System.out.println("AddCommentCell text: " + commentBtnText);
                    TestRunner.getTest().log(Status.INFO, "AddCommentCell text: " + commentBtnText);

                    if (addCommentCell.isDisplayed() && addCommentCell.isEnabled()) {
                        addCommentCell.click();
                        System.out.println("Add Comment button clicked successfully");
                        TestRunner.getTest().log(Status.PASS, "Add Comment button clicked successfully");
                        gradeBookView_pf.TeacherAddAssignmentCommentsUpdatedUI();
                    } else {
                        System.out.println("Add Comment button is either not visible or not enabled.");
                        TestRunner.getTest().log(Status.FAIL, "Add Comment button is either not visible or not enabled.");
                    }
                } else {
                    System.out.println("Add Comment button element not found.");
                    TestRunner.getTest().log(Status.FAIL, "Add Comment button element not found.");
                }
                break;
            }
        }
    }

    public void PrintAndVerifyTableInfo() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Verifying Table Data");
        Thread.sleep(2000);

        WebElement table = driver.findElement(By.xpath("(//table[contains(@class, 'MuiTable-root')])[1]"));

        List<WebElement> rows = table.findElements(By.xpath(".//tbody/tr"));

        for (WebElement row : rows) {
            List<WebElement> columns = row.findElements(By.xpath(".//td"));

            StringBuilder rowData = new StringBuilder();
            for (WebElement column : columns) {
                rowData.append(column.getText()).append(" | ");
            }

            System.out.println(rowData.toString());
            TestRunner.getTest().log(Status.INFO, rowData.toString());
        }

        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Table data printed successfully.");
    }

    public void PrintAndStoreTableInfo() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Verifying table data in array form");

        Thread.sleep(2000);

        WebElement table = driver.findElement(By.xpath("(//table[contains(@class, 'MuiTable-root')])[1]"));
        List<WebElement> rows = table.findElements(By.xpath(".//tbody/tr"));

        List<String> questionTypes = new ArrayList<>();
        List<String> percentPossible = new ArrayList<>();
        List<String> overallAverage = new ArrayList<>();

        for (WebElement row : rows) {
            String rowHeader = row.findElement(By.xpath(".//td[1]")).getText().trim();
            List<WebElement> cells = row.findElements(By.xpath(".//td[position()>1]"));

            switch (rowHeader) {
                case "Question Type":
                    for (WebElement cell : cells) {
                        String data = cell.getText().trim();
                        questionTypes.add(data);
                    }
                    break;

                case "% Possible":
                    for (WebElement cell : cells) {
                        String data = cell.getText().trim();
                        percentPossible.add(data);
                    }
                    break;

                case "Overall Average":
                    for (WebElement cell : cells) {
                        String data = cell.getText().trim();
                        overallAverage.add(data);
                    }
                    break;

                default:
                    TestRunner.getTest().log(Status.INFO, "Unknown Row Header: " + rowHeader);
                    System.out.println("Unknown Row Header: " + rowHeader);
                    break;
            }
        }

        System.out.println("Question Types when Attempting Assignment: " + CorrectAnswerExecutor_PF.questionTypes.get());
        TestRunner.getTest().log(Status.INFO, "Question Types when Attempting Assignment: " + CorrectAnswerExecutor_PF.questionTypes.get());

        System.out.println("Question Types: " + questionTypes);
        TestRunner.getTest().log(Status.INFO, "Question Types: " + questionTypes);

        System.out.println("% Possible: " + percentPossible);
        TestRunner.getTest().log(Status.INFO, "% Possible: " + percentPossible);

        System.out.println("Overall Average: " + overallAverage);
        TestRunner.getTest().log(Status.INFO, "Overall Average: " + overallAverage);

        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Table data printed and stored successfully.");
    }

}