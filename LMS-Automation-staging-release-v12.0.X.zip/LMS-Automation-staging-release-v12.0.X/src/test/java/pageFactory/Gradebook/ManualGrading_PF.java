package pageFactory.Gradebook;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.StudentsModule.AddNewStudentSteps;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.sl.In;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Assignmment.CorrectAnswerExecutor_PF;
import pageFactory.Assignmment.InCorrectAnswerExecutor_PF;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

import static pageFactory.Assignmment.ReleaseAssignment_PF.referenceArray;


public class ManualGrading_PF {
    WebDriverWait wait;
    WebDriver driver;
    Helper helper;

    public static ThreadLocal<String> totalStudentsGradebookSummary = ThreadLocal.withInitial(() -> "");
    public static ThreadLocal<String> totalQuestionsGradebookSummary = ThreadLocal.withInitial(() -> "");
    public static ThreadLocal<String> gradedStudentsGradebookSummary = ThreadLocal.withInitial(() -> "");
    public static ThreadLocal<String> lowestScoreGradebookSummary = ThreadLocal.withInitial(() -> "");
    public static ThreadLocal<String> highestScoreGradebookSummary = ThreadLocal.withInitial(() -> "");
    public static ThreadLocal<String> totalPossiblePercentageGradebookSummary = ThreadLocal.withInitial(() -> "");

    @FindBy (xpath = "//span[normalize-space() = 'Summary']")
    WebElement tab_Summary;

    @FindBy (xpath = "//button[normalize-space()='Summary']")
    WebElement tab_SummaryUpdatedUI;

    @FindBy (xpath = "//button[normalize-space()='Preview Activity']")
    WebElement tab_PreviewUpdatedUI;

    @FindBy (xpath = "//button[normalize-space()='Grade by Student']")
    WebElement tab_GradeByStudentUpdatedUI;

    @FindBy (xpath = "//span[normalize-space() = 'Grading']")
    WebElement tab_Grading;

    @FindBy(xpath = "//button[normalize-space()='Selected Student']")
    WebElement tab_SelectedStudent;
    @FindBy(xpath = "//button[normalize-space()='Selected Student']")
    WebElement Student_Tab;

    @FindBy (xpath = "//div[@aria-label='Student Gradebook']")
    WebElement link_GradeBook;

    @FindBy(xpath = "//input[@name='points']")
    WebElement Student_Point;

    @FindBy(xpath = "//input[@name='points']")
    WebElement Next_Point;

    @FindBy(xpath = "//input[@name='comments']")
    WebElement Student_Comment;

    @FindBy(xpath = "//div[@aria-label='Kaleb  Lan']")
    WebElement Next_Student;

    @FindBy(xpath = "//button[@name='btn-submit-applyfilter']")
    WebElement Submit_btn;

    @FindBy(xpath = "//div[contains(@class, 'StudentListingAndTableWrapper')]//span[@role='progressbar']")
    WebElement Student_Progress;

    @FindBy(xpath = "//*[@id='grade']")
    WebElement btn_Grade;

    public ManualGrading_PF(WebDriver driver){
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        helper = new Helper();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
    }


    public void SideNavBarAndClickOnGradeBook() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Verifying the side navbar");
        System.out.println("I'm in checking the side navbar");
        TestRunner.getTest().log(Status.INFO, "I'm in checking the side navbar and click on My GradeBook");
        Thread.sleep(1000);

        List<WebElement> totalLinks = new ArrayList<>();
        
        // Strategy 1: Find navigation bar
        try {
            WebElement navBar = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class='navigation']")));
            totalLinks = navBar.findElements(By.tagName("a"));
        } catch (TimeoutException e) {
            // Strategy 2: Find Gradebook link directly
            try {
                WebElement gradebookLink = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//a[@href='/gradebook']")));
                totalLinks.add(gradebookLink);
            } catch (TimeoutException e2) {
                // Strategy 3: Find by button text
                try {
                    WebElement gradebookButton = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//a[.//span[contains(text(), 'Gradebook')]]")));
                    totalLinks.add(gradebookButton);
                } catch (TimeoutException e3) {
                    // Strategy 4: Find all links containing /gradebook
                    totalLinks = driver.findElements(By.xpath("//a[contains(@href, '/gradebook')]"));
                }
            }
        }

        // Click on Gradebook link
        for (WebElement link : totalLinks) {
            String hrefValue = link.getAttribute("href");
            if (hrefValue != null && hrefValue.contains("/gradebook")) {
                try {
                    // Try to find button inside anchor tag
                    WebElement button = null;
                    try {
                        button = link.findElement(By.tagName("button"));
                    } catch (NoSuchElementException e) {
                        // No button found, will click link directly
                    }

                    // Try JavaScript click on button
                    if (button != null) {
                        try {
                            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", button);
                            TestRunner.getTest().log(Status.PASS, "Testcase Passed   :  Side navbar shows and clicked on GradeBook");
                            return;
                        } catch (Exception e) {
                            // Continue to next strategy
                        }
                    }

                    // Try JavaScript click on link
                    try {
                        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", link);
                        TestRunner.getTest().log(Status.PASS, "Testcase Passed   :  Side navbar shows and clicked on GradeBook");
                        return;
                    } catch (Exception e) {
                        // Navigate directly
                        driver.navigate().to(hrefValue);
                        TestRunner.getTest().log(Status.PASS, "Testcase Passed   :  Side navbar shows and navigated to GradeBook");
                        return;
                    }
                } catch (Exception e) {
                    // Final fallback: Navigate directly
                    driver.navigate().to(hrefValue);
                    TestRunner.getTest().log(Status.PASS, "Testcase Passed   :  Side navbar shows and navigated to GradeBook");
                    return;
                }
            }
        }
    }

    public void GradeBookDashboard() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm in GradeBook dashboard");
        System.out.println("I'm in GradeBook dashboard");
        Thread.sleep(2000);

        WebDriverWait shortWait = new WebDriverWait(driver, Duration.ofSeconds(10));

        // Try to find breadcrumb with shorter wait
        try {
            WebElement breadCrumb = shortWait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ol[contains(@class, 'MuiBreadcrumbs')]")));
            System.out.println("BreadCrumb is: " + breadCrumb.getText());
            TestRunner.getTest().log(Status.INFO, "BreadCrumb is: " + breadCrumb.getText());
        } catch (TimeoutException e) {
            System.out.println("Breadcrumb not found, continuing with other elements");
            TestRunner.getTest().log(Status.INFO, "Breadcrumb not found, continuing with other elements");
        }

        // Wait for filter class element
        try {
            shortWait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class, 'filterClass')]")));
        } catch (TimeoutException e) {
            System.out.println("Filter class element not found");
            TestRunner.getTest().log(Status.WARNING, "Filter class element not found");
        }

        // Wait for classes container element
        try {
            shortWait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class, 'cleasses-container')]")));
        } catch (TimeoutException e) {
            System.out.println("Classes container element not found");
            TestRunner.getTest().log(Status.WARNING, "Classes container element not found");
        }

        System.out.println("Test Case Passed : GradeBook dashboard loaded");
        TestRunner.getTest().log(Status.PASS, "Test Case Passed : GradeBook dashboard loaded");

    }

    public void printStudentNames() {
        try {
            WebElement listStudent = wait.until(ExpectedConditions.visibilityOfElementLocated(
                    By.xpath("//div[contains(@class, 'StudentListingWrapper')]")));

            // Get all h6 elements first
            List<WebElement> allH6Elements = listStudent.findElements(By.tagName("h6"));

            if (allH6Elements.isEmpty()) {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed : GradeBook Students List is empty");
                return;
            }

            // Filter out non-student entries (like "All Students" and empty/hidden elements)
            List<String> actualStudentNames = new ArrayList<>();
            int maxRetries = 3;
            int totalElements = allH6Elements.size();

            // Iterate through all elements by index
            for (int i = 0; i < totalElements; i++) {
                boolean success = false;
                int retryCount = 0;

                while (!success && retryCount < maxRetries) {
                    try {
                        // Re-locate element to avoid stale reference
                        WebElement freshListStudent = wait.until(ExpectedConditions.visibilityOfElementLocated(
                                By.xpath("//div[contains(@class, 'StudentListingWrapper')]")));
                        
                        List<WebElement> freshElements = freshListStudent.findElements(By.tagName("h6"));
                        
                        if (i < freshElements.size()) {
                            WebElement studentElement = freshElements.get(i);
                            
                            // Check if element is visible (important for headless mode)
                            if (!studentElement.isDisplayed()) {
                                System.out.println("Skipping hidden element at index " + i);
                                success = true;
                                continue;
                            }
                            
                            String name = studentElement.getText().trim();
                            
                            // Skip empty names
                            if (name == null || name.isEmpty()) {
                                System.out.println("Skipping empty name at index " + i);
                                success = true;
                                continue;
                            }
                            
                            // Skip "All Students" entry (summary row, not an actual student)
                            if (name.equalsIgnoreCase("All Students")) {
                                System.out.println("Skipping 'All Students' summary entry");
                                success = true;
                                continue;
                            }
                            
                            // Valid student name found
                            actualStudentNames.add(name);
                            System.out.println("Student Name is: " + name);
                            TestRunner.getTest().log(Status.PASS, "Students name: " + name);
                            success = true;
                            
                        } else {
                            // No more elements to process
                            success = true;
                            break;
                        }
                    } catch (StaleElementReferenceException e) {
                        retryCount++;
                        System.out.println("Stale element detected at index " + i + ", retrying... attempt " + retryCount);
                        if (retryCount < maxRetries) {
                            try {
                                Thread.sleep(500);
                            } catch (InterruptedException ie) {
                                Thread.currentThread().interrupt();
                            }
                        } else {
                            // Skip this element and continue
                            System.out.println("Skipping element at index " + i + " after " + maxRetries + " retries");
                            success = true;
                        }
                    } catch (Exception e) {
                        System.out.println("Error processing element at index " + i + ": " + e.getMessage());
                        success = true; // Continue to next element
                    }
                }
            }

            // Final validation
            if (actualStudentNames.isEmpty()) {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed : No actual students found in GradeBook Students List");
                System.out.println("No actual students found");
            } else {
                System.out.println("Total actual students found: " + actualStudentNames.size());
                TestRunner.getTest().log(Status.PASS, "Test Case Passed : GradeBook students displayed successfully. Total students: " + actualStudentNames.size());
            }

        } catch (StaleElementReferenceException e) {
            TestRunner.getTest().log(Status.FAIL, "StaleElementReferenceException encountered: " + e.getMessage());
            System.out.println("StaleElementReferenceException: " + e.getMessage());
        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "Unexpected exception encountered: " + e.getMessage());
            System.out.println("Unexpected exception: " + e.getMessage());
        }
    }


    public void clickCollapseButtons() throws InterruptedException {
        Thread.sleep(1000);
        WebElement divQuiz = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class, 'StudentListingAndTableWrapper')]")));
        List<WebElement> totalCollapseButton = divQuiz.findElements(By.xpath("//span[contains(@class,'CollapseArrow collapse')]"));

        int numberOfCollapseButtons = totalCollapseButton.size();
        System.out.println("Total Collapse Buttons are: " + numberOfCollapseButtons);
        wait.until(ExpectedConditions.visibilityOf(divQuiz));

        for (WebElement btn_Collapse : totalCollapseButton) {
            if (btn_Collapse.isEnabled() && btn_Collapse.isDisplayed()) {
                ((JavascriptExecutor) driver).executeScript("arguments[0].click();", btn_Collapse);
                System.out.println("Clicked on the collapse button.");
                Thread.sleep(1000);
            } else {
                System.out.println("Collapse button is not clickable.");
            }
        }
    }

    public void selectRandomQuiz() throws InterruptedException {
        Thread.sleep(1000);
        WebElement divQuiz = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class, 'StudentListingAndTableWrapper')]")));
        List<WebElement> totalQuizzes = divQuiz.findElements(By.xpath("//div[contains(@class, 'QuizAverage')]"));

        int numberOfQuizzes = totalQuizzes.size();
        System.out.println("Number of Quizzes: " + numberOfQuizzes);

        List<String> excludedQuizTexts = Arrays.asList("CLASS AVERAGE", "DATE RANGE AVERAGE", "EXAM AVERAGE", "HOMEWORK AVERAGE", "PRACTICE AVERAGE", "QUIZ AVERAGE");

        boolean gradeButtonClicked = false;

        for (WebElement quiz : totalQuizzes) {
            String quizText = quiz.getText().trim();
            System.out.println("Quiz text is: " + quizText);

            if (!excludedQuizTexts.contains(quizText)) {
                WebElement theadQuiz = quiz.findElement(By.xpath(".//table/thead"));
                List<WebElement> quizzes = theadQuiz.findElements(By.xpath(".//span[contains(@class,'vertical-text-container')]"));

                for (WebElement selectedQuiz : quizzes) {
                    String selectedQuizText = selectedQuiz.getText().trim();
                    if (!excludedQuizTexts.contains(selectedQuizText)) {
//                        Thread.sleep(2000);
                        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", selectedQuiz);
                        Thread.sleep(1000);
                        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", selectedQuiz);

                        System.out.println("Text of Clicked Quiz: " + selectedQuizText);

                        if (isGradeButtonClickable()) {
                            System.out.println("Grade button is clickable.");
                            clickGradeButton();
                            gradeButtonClicked = true;
                            break;
                        } else {
                            System.out.println("Grade button is not clickable.");
                        }
                    }
                }
            }

            if (gradeButtonClicked) {
                break;
            }
        }
    }

    private boolean isGradeButtonClickable() {
        List<WebElement> listAssignment = driver.findElements(By.xpath("//ul[@role='menu']"));

        for (WebElement option : listAssignment) {
            List<WebElement> buttons = option.findElements(By.tagName("button"));

            for (WebElement button : buttons) {
                String buttonText = button.getText().trim();

                if (buttonText.equals("Grade") && button.isEnabled() && button.isDisplayed()) {
                    return true;
                }
            }
        }

        return false;
    }

    private void clickGradeButton() {
        List<WebElement> listAssignment = driver.findElements(By.xpath("//ul[@role='menu']"));

        for (WebElement option : listAssignment) {
            List<WebElement> buttons = option.findElements(By.tagName("button"));

            for (WebElement button : buttons) {
                String buttonText = button.getText().trim();

                if (buttonText.equals("Grade") && button.isEnabled() && button.isDisplayed()) {
                    button.click();
                    System.out.println("Clicked on Grade button.");
                    return;
                }
            }
        }
    }

//    Manual Grading on Summary Tab

    public void EnterSummaryScoreAndSelectTheCheckBox() throws InterruptedException {
        Thread.sleep(2000);
        WebElement tableSummary = driver.findElement(By.xpath("//div[contains(@class, 'StudentAssignmnetFooter')]"));
        List<WebElement> inputFields = tableSummary.findElements(By.xpath(".//table/tbody/tr//input[contains(@id, 'TextFieldInput')]"));

        System.out.println("Total number of input fields: " + inputFields.size());

        Random random = new Random();
        int enabledInputFieldCounter = 0;

        for (WebElement inputField : inputFields) {
            WebElement checkbox = inputField.findElement(By.xpath("./ancestor::tr//input[contains(@id, 'SingleCheckBox')]"));

            if (inputField.isEnabled()) {
                enabledInputFieldCounter++;

                inputField.clear();
                JavascriptExecutor js = (JavascriptExecutor) driver;
                js.executeScript("arguments[0].value='';", inputField);

                int randomScore = random.nextInt(4) + 1;
                inputField.sendKeys(Integer.toString(randomScore));
                Thread.sleep(500);

                checkbox.click();
            }
        }
        System.out.println("Total number of enabled input fields: " + enabledInputFieldCounter);
    }

    public void AssignmentScoresSummary() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm to Get Assignment Score Summary");

        Thread.sleep(1000);
        WebElement assignmentSummary = driver.findElement(By.xpath("//div[contains(@class, 'MuiAccordion-gutters')]"));
        List<WebElement> countsSummary = assignmentSummary.findElements(By.xpath(".//div[contains(@class, 'MuiGrid-item')]"));

        StringBuilder summaryLog = new StringBuilder("Assignment Scores Summary:\n");

        for (WebElement countSummary : countsSummary) {
            String valueText = countSummary.findElement(By.xpath(".//p[1]")).getText();
            String label = countSummary.findElement(By.xpath(".//p[2]")).getText();

            switch (label) {
                case "Students":
                    totalStudentsGradebookSummary.set(valueText);
                    break;
                case "Questions":
                    totalQuestionsGradebookSummary.set(valueText);
                    break;
                case "Graded Students":
                    gradedStudentsGradebookSummary.set(valueText);
                    break;
                case "Lowest Score":
                    lowestScoreGradebookSummary.set(valueText);
                    break;
                case "Highest Score":
                    highestScoreGradebookSummary.set(valueText);
                    break;
                case "Total Possible %":
                    totalPossiblePercentageGradebookSummary.set(valueText);
                    break;
                default:
                    System.out.println("Unknown label: " + label);
                    TestRunner.getTest().log(Status.INFO, "Unknown label encountered: " + label);
                    continue;
            }

            summaryLog.append(label).append(": ").append(valueText).append("\n");
            System.out.println(label + ": " + valueText);
            TestRunner.getTest().log(Status.INFO, label + ": " + valueText);
        }

        TestRunner.getTest().log(Status.INFO, summaryLog.toString());
        TestRunner.getTest().log(Status.PASS, "Test case Passed: Assignment Scores Summary Successfully retrieved.");
    }

    public void AssignmentScoresSummaryUpdatedUI() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm to Get Assignment Score Summary");

        Thread.sleep(1000);
        WebElement assignmentSummary = driver.findElement(By.xpath("//div[contains(@class, 'MuiAccordion-gutters')]"));
        List<WebElement> countsSummary = assignmentSummary.findElements(By.xpath(".//div[contains(@class, 'MuiGrid-item')]"));

        StringBuilder summaryLog = new StringBuilder("Assignment Scores Summary:\n");

        for (WebElement countSummary : countsSummary) {
            String valueText = countSummary.findElement(By.xpath(".//p[1]")).getText();
            String label = countSummary.findElement(By.xpath(".//p[2]")).getText();

            switch (label) {
                case "Students":
                    totalStudentsGradebookSummary.set(valueText);
                    break;
                case "Questions":
                    totalQuestionsGradebookSummary.set(valueText);
                    break;
                case "Graded Students":
                    gradedStudentsGradebookSummary.set(valueText);
                    break;
                case "Lowest Score":
                    lowestScoreGradebookSummary.set(valueText);
                    break;
                case "Highest Score":
                    highestScoreGradebookSummary.set(valueText);
                    break;
                case "Total Possible %":
                    totalPossiblePercentageGradebookSummary.set(valueText);
                    break;
                default:
                    System.out.println("Unknown label: " + label);
                    TestRunner.getTest().log(Status.INFO, "Unknown label encountered: " + label);
                    continue;
            }

            summaryLog.append(label).append(": ").append(valueText).append("\n");
            System.out.println(label + ": " + valueText);
            TestRunner.getTest().log(Status.INFO, label + ": " + valueText);
        }

        TestRunner.getTest().log(Status.INFO, summaryLog.toString());
        TestRunner.getTest().log(Status.PASS, "Test case Passed: Assignment Scores Summary Successfully retrieved.");
    }

//    Manual Grading on Grading Tab

    public void VerifyGradingScreen() throws InterruptedException{
        System.out.println("I'm in grading screen");
        Thread.sleep(1000);

        WebElement gradingNotFoundElement = null;
        try {
            gradingNotFoundElement = driver.findElement(By.xpath("//div[@class='gradingNotFound']//span"));
        } catch (Exception e) {
            System.out.println("Error: Grading element not found.");
        }

        if (gradingNotFoundElement != null) {
            String textGradingNotFound = gradingNotFoundElement.getText();
            System.out.println("Text is :  " + textGradingNotFound);
            if (textGradingNotFound.equals("All submitted questions have been scored. Please select either the Summary or Selected Student tabs to view results.")) {
                ClickOnSummaryTab();
            } else {
                System.out.println("Unexpected text found: " + textGradingNotFound);
            }
        } else {
            System.out.println("Grading element not found. Proceeding with default actions.");
        }
    }

    public void AssignmentSummaryCheckBoxOnSummaryTab() throws InterruptedException {
        Thread.sleep(1000);
        WebElement tableSummary = driver.findElement(By.xpath("//div[contains(@class, 'StudentAssignmnetFooter')]"));
        List<WebElement> checkboxesGraded = tableSummary.findElements(By.xpath(".//table/tbody/tr//input[contains(@id, 'SingleCheckBox')]"));

        System.out.println("Total number of graded checkboxes: " + checkboxesGraded.size());

        int enabledGradedCheckBoxCounter = 0;

        for (WebElement checkBox : checkboxesGraded) {

            if (checkBox.isEnabled()) {
                enabledGradedCheckBoxCounter++;
                Thread.sleep(500);

                checkBox.click();
                System.out.println("Unchecked the graded checkbox");
            }
        }
        System.out.println("Total number of enabled graded checkboxes: " + enabledGradedCheckBoxCounter);
    }

    public void updateStudentPointsAndComments() throws InterruptedException{
        Thread.sleep(2000);
        WebElement GradeAssignmentSection = driver.findElement(By.xpath("//div[@class='grade-actions ']"));
        helper.scrollToElement(driver, GradeAssignmentSection);

        WebElement pointsInput = GradeAssignmentSection.findElement(By.xpath("//input[@name='points']"));
        Thread.sleep(500);
        pointsInput.click();

        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].value='';", pointsInput);
        pointsInput.clear();

        Random random = new Random();
        int randomPoints = random.nextInt(50) + 1;
        pointsInput.sendKeys(Integer.toString(randomPoints));

        Thread.sleep(500);
        WebElement commentsInput = GradeAssignmentSection.findElement(By.xpath("//input[@name='comments']"));
        helper.scrollToElement(driver, commentsInput);
        Thread.sleep(500);
        js.executeScript("arguments[0].value='';", commentsInput);
        commentsInput.clear();

        commentsInput.sendKeys("Automated Comment");
        Thread.sleep(500);

        WebElement submitButton = GradeAssignmentSection.findElement(By.xpath("//button[@name='btn-submit-applyfilter']"));
        helper.scrollToElement(driver, submitButton);
        Thread.sleep(500);
        submitButton.click();
    }


//    Manual Grading on Selected Student Tab

    public void Student_tab() throws InterruptedException{
        Thread.sleep(2000);
        Student_Tab.click();
        Thread.sleep(2000);
        System.out.println("Click the Student Tab");
    }

    public void Student_Point() throws InterruptedException{

        wait.until(ExpectedConditions.visibilityOf(Student_Point));
        Student_Point.isDisplayed();
        JavascriptExecutor jsPostAction = (JavascriptExecutor) driver;  // object of javaScript
        jsPostAction.executeScript("arguments[0].scrollIntoView(true);", Student_Point); // This will scroll till the element is found
        Thread.sleep(3000);
        Student_Point.click();
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].value='';", Student_Point);
        Student_Point.sendKeys("75");
        Thread.sleep(4000);
        System.out.println("Click the Student Point");
    }

    public void Student_Comment() throws InterruptedException{
        Thread.sleep(3000);
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].text='';", Student_Comment);
        Student_Comment.sendKeys("Grade is update");
        Thread.sleep(3000);
        Student_Comment.click();
        Thread.sleep(3000);
        System.out.println("Student Comment is Click");
    }
    public void Next_Student() throws InterruptedException{
        JavascriptExecutor jsPostAction = (JavascriptExecutor) driver;  // object of javaScript
        jsPostAction.executeScript("arguments[0].scrollIntoView(true);", Next_Student);
        Thread.sleep(3000);
        Next_Student.click();
        Thread.sleep(3000);
    }
    public void Next_Point() throws InterruptedException{
        wait.until(ExpectedConditions.visibilityOf(Next_Point));
        Next_Point.isDisplayed();
        JavascriptExecutor jsPostAction = (JavascriptExecutor) driver;  // object of javaScript
        jsPostAction.executeScript("arguments[0].scrollIntoView(true);", Next_Point); // This will scroll till the element is found
        Thread.sleep(3000);
        Next_Point.click();
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].value='';", Next_Point);
        Next_Point.sendKeys("60");
        Thread.sleep(4000);
        System.out.println("Click the Next Student Point");
    }

    public void Submit_btn() throws InterruptedException{
        JavascriptExecutor jsPostAction = (JavascriptExecutor) driver;  // object of javaScript
        jsPostAction.executeScript("arguments[0].scrollIntoView(true);", Submit_btn); // This will scroll till the element is found
        Thread.sleep(3000);
        Submit_btn.click();
    }

    public void ClickOnSummaryTab() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Attempting to click on Summary Tab (Updated UI)");
        try {
            wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Summary']")));
            Thread.sleep(1000);

            if (tab_SummaryUpdatedUI.isDisplayed() && tab_SummaryUpdatedUI.isEnabled()) {
                tab_SummaryUpdatedUI.click();
                Thread.sleep(1000);

                TestRunner.getTest().log(Status.PASS, "Test Case Passed: Successfully clicked on Summary Tab.");
                System.out.println("Successfully clicked on the Summary Tab (Updated UI).");
            } else {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Summary Tab is not clickable.");
                System.out.println("Summary Tab is either not visible or not enabled.");
            }

        } catch (InterruptedException e) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Interrupted Exception occurred while clicking on Summary Tab. " + e.getMessage());
            System.out.println("Interrupted Exception occurred while clicking on the Summary Tab: " + e.getMessage());

        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception occurred while clicking on Summary Tab. " + e.getMessage());
            System.out.println("Exception occurred while clicking on the Summary Tab: " + e.getMessage());
        }
    }

    public void ClickOnSummaryTabUpdatedUI() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Attempting to click on Summary Tab");
        try {
            wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Summary']")));
            Thread.sleep(1000);

            if (tab_SummaryUpdatedUI.isDisplayed() && tab_SummaryUpdatedUI.isEnabled()) {
                tab_SummaryUpdatedUI.click();
                Thread.sleep(1000);

                TestRunner.getTest().log(Status.PASS, "Test Case Passed: Successfully clicked on Summary Tab.");
                System.out.println("Successfully clicked on the Summary Tab.");
            } else {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Summary Tab is not clickable.");
                System.out.println("Summary Tab is either not visible or not enabled.");
            }

        } catch (InterruptedException e) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Interrupted Exception occurred while clicking on Summary Tab. " + e.getMessage());
            System.out.println("Interrupted Exception occurred while clicking on the Summary Tab: " + e.getMessage());

        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception occurred while clicking on Summary Tab. " + e.getMessage());
            System.out.println("Exception occurred while clicking on the Summary Tab: " + e.getMessage());
        }
    }

    public void ClickOnPreviewTabActivity() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Attempting to click on Preview Activity Tab (Updated UI)");
        try {
            wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Preview Activity']")));
            Thread.sleep(1000);

            if (tab_PreviewUpdatedUI.isDisplayed() && tab_PreviewUpdatedUI.isEnabled()) {
                tab_PreviewUpdatedUI.click();
                Thread.sleep(1000);

                TestRunner.getTest().log(Status.PASS, "Test Case Passed: Successfully clicked on Preview Tab.");
                System.out.println("Successfully clicked on the Preview Tab (Updated UI).");
            } else {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Preview Tab is not clickable.");
                System.out.println("Preview Tab is either not visible or not enabled.");
            }

        } catch (InterruptedException e) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Interrupted Exception occurred while clicking on Preview Tab. " + e.getMessage());
            System.out.println("Interrupted Exception occurred while clicking on the Preview Tab: " + e.getMessage());

        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception occurred while clicking on Summary Tab. " + e.getMessage());
            System.out.println("Exception occurred while clicking on the Summary Tab: " + e.getMessage());
        }
    }

    public void ClickOnGradeByStudentTabActivity() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Attempting to click on Grade By Student Activity Tab (Updated UI)");
        try {
            wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[normalize-space()='Preview Activity']")));
            Thread.sleep(1000);

            if (tab_GradeByStudentUpdatedUI.isDisplayed() && tab_GradeByStudentUpdatedUI.isEnabled()) {
                tab_GradeByStudentUpdatedUI.click();
                Thread.sleep(1000);

                TestRunner.getTest().log(Status.PASS, "Test Case Passed: Successfully clicked on Grade By Student Tab.");
                System.out.println("Successfully clicked on the Grade By Student Tab.");
            } else {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Grade By Student Tab is not clickable.");
                System.out.println("Grade By Student Tab is either not visible or not enabled.");
            }

        } catch (InterruptedException e) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Interrupted Exception occurred while clicking on Grade By Student Tab. " + e.getMessage());
            System.out.println("Interrupted Exception occurred while clicking on the Grade By Student Tab: " + e.getMessage());

        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Exception occurred while clicking on Grade By Student Tab. " + e.getMessage());
            System.out.println("Exception occurred while clicking on the Grade By Student Tab: " + e.getMessage());
        }
    }

    public void ClickOnGradingTab() throws InterruptedException {
        Thread.sleep(1000);
        tab_Grading.click();
        Thread.sleep(1000);
    }

    public void ClickOnSelectedStudentTab() throws InterruptedException {
        Thread.sleep(1000);
        tab_SelectedStudent.click();
        Thread.sleep(1000);
    }

    public void CLickOnMarkAsGraded() throws InterruptedException {
        Thread.sleep(500);
        WebElement div_StudentGradeStatus = driver.findElement(By.xpath("//div[@class='student-grade-status']"));
        WebElement checkBox_MarkAsGraded = div_StudentGradeStatus.findElement(By.xpath(".//input[contains(@id, 'SingleCheckBox-SingleCheckBox')]"));

        if (checkBox_MarkAsGraded.isSelected()) {
            checkBox_MarkAsGraded.click();
            System.out.println("Mark as graded checkbox was selected. Now unselect it.");
        } else {
            System.out.println("Mark as graded checkbox was not selected.");
        }
    }

    public void ClickOnGradeBook() throws InterruptedException{
        Thread.sleep(2000);
        link_GradeBook.click();
        Thread.sleep(2000);
    }

    public void ClickOnQuestionMarkIcon() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into click on ? icon");
        Thread.sleep(1000);

        WebElement questionMarkIcon= driver.findElement(By.xpath("//div[@aria-label='Help/Instruction']//*[name()='svg']"));

        if (questionMarkIcon.isDisplayed()){
//            questionMarkIcon.click();
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", questionMarkIcon);

            TestRunner.getTest().log(Status.PASS,"Test Case Passed : ? Icon click successfully");
        }else {
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed: ? Icon not found");
        }
    }

    public void verifyGradingPrompt() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm Into Verify Prompt");

        Thread.sleep(2000);

        WebElement prompt = driver.findElement(By.xpath("//div[@role='dialog']"));
        boolean isDisplayed = prompt.isDisplayed();
        Assert.assertTrue("Prompt is not displayed.", isDisplayed);

        WebElement promptHeader = prompt.findElement(By.tagName("h2"));
        String headerText = promptHeader.getText();
        System.out.println("Prompt header text is: " + headerText);
        TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  Prompt Display Successfully");
    }

    public void verifyAndClickContinueToAssignmentGradingButton() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm into verify And Click on Continue To Assignment Grading Button");

        WebElement continueToAssignmentGradingButton= driver.findElement(By.xpath("//button[normalize-space()='Continue to Assignment Grading']"));

        if (continueToAssignmentGradingButton.isDisplayed() && continueToAssignmentGradingButton.isEnabled()){
            continueToAssignmentGradingButton.click();
            TestRunner.getTest().log(Status.PASS,"Test Case Passed : continue To Assignment Grading Button Click Successfully");
        }else {
            TestRunner.getTest().log(Status.FAIL, "continue To Assignment Grading Button not clickable/displayed");
        }
    }

    public void clickIIconBtn() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into verify and click on i icon");

        WebElement iIconBtn= driver.findElement(By.xpath("//div[@aria-label='Additional Information']//*[name()='svg']"));

        if (iIconBtn.isDisplayed()){
//            iIconBtn.click();
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", iIconBtn);
            TestRunner.getTest().log(Status.PASS,"Test Case Passed : i icon button click successfully");
        }else {
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed : i icon button not click/display");
        }
    }

    public void checkInstructionOnResourceDescriptionAndInstructionalStrategies() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm into check Instruction On Resource Description And Instructional Strategies on Prompt");

        List<WebElement> paragraphs = driver.findElements(By.cssSelector(".InfoDialogDialogBody p"));
        StringBuilder bodyText = new StringBuilder();
        for (WebElement p : paragraphs) {
            bodyText.append(p.getText()).append("\n\n");
        }
        System.out.println("Body Text:\n" + bodyText.toString());
        TestRunner.getTest().log(Status.INFO,"Body Text:\n" + bodyText.toString() );

        // -------- Get Heading --------
        String heading = driver.findElement(By.cssSelector("h3.resourceInfoHeading")).getText();
        System.out.println("Heading: " + heading);
        TestRunner.getTest().log(Status.INFO, "Heading: " + heading);

        TestRunner.getTest().log(Status.INFO,"I'm into click on X icon to close dialogue box");

        WebElement closeInstructionDialogueBox = driver.findElement(By.xpath("//button[@aria-label='close']//*[name()='svg']"));
        if (closeInstructionDialogueBox.isDisplayed()){
            closeInstructionDialogueBox.click();
            TestRunner.getTest().log(Status.PASS,"Test Case Passed:  X icon Display and click successfully");
        }else {
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed:  X icon Not Display");
        }
    }

    public void clickOnPrintIcon() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm into click On Print Icon");

        WebElement printIcon= driver.findElement(By.xpath("//span[@aria-label='attach document']"));

        if (printIcon.isDisplayed()){
            printIcon.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Print Icon Display/Enabled successfully");
        }else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Print Icon not Display");
        }
    }

    public void clickOnStandardIcon() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into click On Standard Icon");

        WebElement standard_icon= driver.findElement(By.xpath("//div[@aria-label='Standards']//*[name()='svg']"));
        if (standard_icon.isDisplayed()){
            standard_icon.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: standard icon displayed/click successfully");
        }else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: standard icon not display");
        }
    }

    public static ThreadLocal<List<String>> referenceArrayOnGradeByStudent = ThreadLocal.withInitial(ArrayList::new);

    public void getStandardsFromGradeByStudent() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into Get Standards From Grade By Student");
        System.out.println("Get Assignment Standards From Grade By Student");


        try {

            WebElement dialogAssignment = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@role='dialog']")));

            if (dialogAssignment.isDisplayed()) {

                List<WebElement> references = dialogAssignment.findElements(By.xpath("//table//tr//td[1]"));

                if (references.isEmpty()) {
                    System.out.println("No references found. Empty row data.");
                    TestRunner.getTest().log(Status.FAIL, "No references found. Empty row data.");
                    Thread.sleep(3000);
                    helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());

                    WebElement closeButton = dialogAssignment.findElement(By.xpath(".//button[@aria-label='close']"));
                    closeButton.click();
                    TestRunner.getTest().log(Status.PASS, "Dialog box closed successfully after failed attempt.");
                    return;
                }

                for (WebElement reference : references) {
                    referenceArrayOnGradeByStudent.get().add(reference.getText().trim());
                }

                for (String reference : referenceArrayOnGradeByStudent.get()) {
                    System.out.println("Reference: " + reference);
                    TestRunner.getTest().log(Status.INFO, "Reference: " + reference);
                }
                Thread.sleep(3000);
                helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());

                WebElement closeButton = dialogAssignment.findElement(By.xpath(".//button[@aria-label='close']"));
                closeButton.click();
                System.out.println("Dialog box closed successfully.");
                TestRunner.getTest().log(Status.PASS, "Dialog box closed successfully.");

            } else {
                TestRunner.getTest().log(Status.FAIL, "Dialog box not displayed.");
            }

        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "An error occurred while getting assignment standards.");
            e.printStackTrace();
        }
    }

     public void validateStandardMatch() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into validate Standard Match");
        System.out.println("I'm into validate Standard Match");

         List<String> arr1 = referenceArray.get();
         List<String> arr2 = referenceArrayOnGradeByStudent.get();

         if (arr1.size() != arr2.size()) {
             System.out.println("❌ Test Failed: Array sizes do not match!");
             TestRunner.getTest().log(Status.FAIL, "❌ Test Failed: Array sizes do not match!");
             System.out.println("Array1: " + arr1);
             TestRunner.getTest().log(Status.INFO, "Standard Array list from Content:" + arr1);
             System.out.println("Array2: " + arr2);
             TestRunner.getTest().log(Status.INFO, "Standard Array list from Grade By Student:" + arr2);
             return;
         }

         boolean allMatch = true;

         for (int i = 0; i < arr1.size(); i++) {
             String val1 = arr1.get(i);
             String val2 = arr2.get(i);

             if (!val1.equals(val2)) {
                 System.out.println("❌ Mismatch at index " + i +
                         " -> Expected: " + val1 +
                         ", Found: " + val2);
                 TestRunner.getTest().log(Status.FAIL, "❌ Mismatch at index " + i +
                         " -> Expected: " + val1 +
                         ", Found: " + val2);
                 allMatch = false;
             }
         }

         if (allMatch) {
             System.out.println("✅ Test Passed: Standard match on Grade By Student");
             TestRunner.getTest().log(Status.PASS, "Test Case Passed: Standard match on Grade By Student");
         } else {
             System.out.println("❌ Test Failed: One/more standard not match on Grade By Student.");
             TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Standard match on Grade By Student");
         }

     }

     public void assignmentNameVerification() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO,"I'm into Verify Assignment Name Match on Grade By Student");

         String assignmentName = driver.findElement(
                 By.cssSelector("p[aria-label]")).getAttribute("aria-label");

         System.out.println("Assignment name on Grade By Student Tab is: " + assignmentName);
         TestRunner.getTest().log(Status.INFO, "Assignment name on Grade By Student Tab is: " + assignmentName);


         String assignmentNameForCorrect = CorrectAnswerExecutor_PF.assignmentNameForCorrect.get();
         System.out.println("Assignment name From Assign: " + assignmentNameForCorrect);
         TestRunner.getTest().log(Status.INFO, "Assignment name From Assign: " + assignmentNameForCorrect);

         TestRunner.getTest().log(Status.INFO, "Assignment That is Release and Attempt By Student is: " + assignmentNameForCorrect);
         System.out.println("Assignment That is Release and Attempt By Student is: " + assignmentNameForCorrect);

         TestRunner.getTest().log(Status.INFO, "Verify Assignment Name is match with the Assignment that is created/Assign ");

         if (assignmentName.equalsIgnoreCase(assignmentNameForCorrect)){
             System.out.println("Assignment that is release and Attempt By student is Successfully open and name match in GradeByStudent tab");
             TestRunner.getTest().log(Status.INFO, "Assignment that is release: " + assignmentNameForCorrect +   " and Attempt By student is Successfully open and name match in GradeByStudent tab" + assignmentName);
             TestRunner.getTest().log(Status.PASS, "Test Case Passed: Assignment name Match " + assignmentName);
         }else {
             TestRunner.getTest().log(Status.INFO, "Assignment that is release: " + assignmentNameForCorrect +   " and Attempt By student is Successfully open and name match in GradeByStudent tab" + assignmentName);
             TestRunner.getTest().log(Status.PASS, "Test Case Failed: Assignment name Not Match " + assignmentName);
//            throw new RuntimeException("Wrong Assignment open in summary tab.");
         }
     }


     public void getStartAndDueDateOnGradeByStudent() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm Into get Start And Due Date On Grade By Student");

         // Find all elements inside the div
         String startDate = driver.findElement(
                 By.xpath("//div[contains(@class,'showDateFormat')]/*[1]")).getText();

         String dueDate = driver.findElement(
                 By.xpath("//div[contains(@class,'showDateFormat')]/*[2]")).getText();

         System.out.println("Start Date: " + dueDate);
         TestRunner.getTest().log(Status.INFO, "Start Date From Grade By Student: " + startDate);

         System.out.println("Due Date: " + startDate);
         TestRunner.getTest().log(Status.INFO, "Due Date From Grade By Student: " + dueDate);

         TestRunner.getTest().log(Status.PASS, "Start And Due Date Get Successfully");

     }

     public void clickOnArrowDropDownIcon() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into click On Arrow DropDown Icon");

         WebElement arrowDropDownIcon = driver.findElement(
                 By.xpath("(//button[contains(@class,'MuiButton-containedPrimary')]//*[name()='svg'])[2]/ancestor::button")
         );

         if (arrowDropDownIcon.isDisplayed() && arrowDropDownIcon.isEnabled()) {
             arrowDropDownIcon.click();
             System.out.println("Arrow DropDown Button is enabled and clicked successfully.");
             TestRunner.getTest().log(Status.PASS, "Test Case Passed: Arrow DropDown Button is enabled and clicked successfully.");
         } else {
             TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Arrow DropDown Button is either not displayed or not enabled");
             throw new AssertionError("Arrow DropDown Button is either not displayed or not enabled.");
         }

         TestRunner.getTest().log(Status.INFO, "I'm into get Menu Option from Dropdown");

         List<WebElement> menuOptions = driver.findElements(By.xpath("//ul[@role='menu']//li"));

         System.out.println("Validating that all options are enabled in Arrow Dropdown:");
         TestRunner.getTest().log(Status.INFO, "Validating that all options are enabled Arrow Dropdown:");

         boolean allEnabled = true;

         for (WebElement option : menuOptions) {
             String optionText = option.getText();
             boolean isEnabled = option.isEnabled();

             if (isEnabled) {
                 System.out.println(optionText + " Option is enabled.");
                 TestRunner.getTest().log(Status.INFO, optionText + " Option is enabled.");
             } else {
                 System.out.println(optionText + " Option is disabled.");
                 TestRunner.getTest().log(Status.INFO, optionText + " Option is disabled.");
                 allEnabled = false;
             }
         }

         if (allEnabled) {
             TestRunner.getTest().log(Status.PASS, "Testcase Passed: All menu options are enabled in Arrow Dropdown");
         } else {
             TestRunner.getTest().log(Status.FAIL, "Testcase Failed: Some menu options are disabled are in Arrow Dropdown.");
         }

         helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
     }

     public void clickOnAddAssignmentCommentOption() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into click On Add Assignment Comment Option");

         WebElement addAssignmentCommentOption = driver.findElement(
                 By.xpath("//li[normalize-space()='Add Assignment Comment']")
         );

         if (addAssignmentCommentOption.isDisplayed() && addAssignmentCommentOption.isEnabled()) {
             addAssignmentCommentOption.click();
             System.out.println("Add Assignment Comment Option clicked successfully.");
             TestRunner.getTest().log(Status.PASS,
                     "Test Case Passed: Add Assignment Comment Option clicked successfully.");
         } else {
             System.out.println("Add Assignment Comment Option is either not visible or disabled.");
             TestRunner.getTest().log(Status.FAIL,
                     "Test Case Failed: Add Assignment Comment Option is not Enabled/Displayed.");
         }
     }

    public static String assignmentCommentFromGradeByStudent = "Automated Assignment Comments by Teacher - Test";

     public void AddCommentAndClickSave() throws InterruptedException {

         TestRunner.getTest().log(Status.INFO, "I'm into Add Assignment comment on Grade By Student Activity");


         WebElement addCommentCell = driver.findElement(By.xpath("//label[normalize-space()='Assignment Comment']/following::textarea[1]"));


         if (addCommentCell != null) {
             String commentBtnText = addCommentCell.getText();
             System.out.println("AddCommentCell text: " + commentBtnText);
             TestRunner.getTest().log(Status.INFO, "AddCommentCell text: " + commentBtnText);

             if (addCommentCell.isDisplayed() && addCommentCell.isEnabled()) {
                 addCommentCell.click();
                 System.out.println("Add Comment button clicked successfully");
                 TestRunner.getTest().log(Status.PASS, "Add Comment button clicked successfully");
                 WebElement menuBox = wait.until(ExpectedConditions.visibilityOfElementLocated(
                         By.xpath("//div[contains(@class, 'MuiPopover-paper')]")));

                 WebElement commentTextArea = menuBox.findElement(By.xpath("//textarea[@aria-invalid='false' and not(@readonly)]"));

                 if (commentTextArea.isDisplayed() && commentTextArea.isEnabled()) {
                     commentTextArea.click();
                     Thread.sleep(2000);

                     // Select all and delete
                     commentTextArea.sendKeys(Keys.CONTROL + "a");
                     commentTextArea.sendKeys(Keys.BACK_SPACE);

                     // (Optional) small wait
                     Thread.sleep(500);

                     commentTextArea.sendKeys(assignmentCommentFromGradeByStudent);
                     JavascriptExecutor js = (JavascriptExecutor) driver;
                     System.out.println("Comment Entered successfully: " + assignmentCommentFromGradeByStudent);
                     TestRunner.getTest().log(Status.INFO, "Assignment Comment Entered: " + assignmentCommentFromGradeByStudent);
                     TestRunner.getTest().log(Status.PASS, "Test Case Passed: Assignment Comment Entered successfully");
                     Thread.sleep(5000);
                     helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());

                     String actualComment = (String) js.executeScript("return arguments[0].value;", commentTextArea);

                     if (assignmentCommentFromGradeByStudent.equals(actualComment)) {
                         System.out.println("Comment verified successfully before save.");
                         TestRunner.getTest().log(Status.PASS, "Comment verified via JS: " + actualComment);
                     } else {
                         System.out.println("Comment mismatch via JS. Expected: " + assignmentCommentFromGradeByStudent + ", Found: " + actualComment);
                         TestRunner.getTest().log(Status.FAIL, "Comment mismatch before save. Found: " + actualComment);
                     }

                     TestRunner.getTest().log(Status.INFO, "I'm in to Click on Save Button for Assignment Comments");
                     System.out.println("I'm in to Click on Save Button for Assignment Comments");

                     WebElement btn_save = menuBox.findElement(By.xpath("//button[normalize-space()='Save']"));

                     if (btn_save.isDisplayed() && btn_save.isEnabled()) {
                         if (assignmentCommentFromGradeByStudent.equals(actualComment)) {
                             System.out.println("Comment verified successfully after save.");
                             TestRunner.getTest().log(Status.PASS, "Comment verified via JS: " + actualComment);
                         } else {
                             System.out.println("Comment mismatch via JS. Expected: " + assignmentCommentFromGradeByStudent + ", Found: " + actualComment);
                             TestRunner.getTest().log(Status.FAIL, "Comment mismatch after save. Found: " + actualComment);
                         }
                         Thread.sleep(2000);
                         btn_save.click();
                         System.out.println("Save Button is enabled and clicked ");
                         TestRunner.getTest().log(Status.INFO, "Save Button is clicked successfully");
                         TestRunner.getTest().log(Status.PASS, "Test Case Passed: Save Button clicked successfully");

                         Thread.sleep(1000);
                     } else {
                         System.out.println("Save Button is disabled.");
                         TestRunner.getTest().log(Status.FAIL, "Save Button is disabled");
                     }

                 } else {
                     System.out.println("Add Comment dialog box is not visible or not enabled.");
                     TestRunner.getTest().log(Status.FAIL, "Add Comment dialog box is not visible or not enabled.");
                 }
             } else {
                 System.out.println("Add Comment button is either not visible or not enabled.");
                 TestRunner.getTest().log(Status.FAIL, "Add Comment button is either not visible or not enabled.");
             }
         } else {
             System.out.println("Add Comment button element not found.");
             TestRunner.getTest().log(Status.FAIL, "Add Comment button element not found.");
         }
     }

    public void VerificationOfTeacherCommentFromGradeByStudentOnStudentSide() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm in to Verify Teacher Comments From Grade By Student Show on Student Side");
        System.out.println("I'm in to Verify Teacher Comments From Grade By Student Show on Student Side");

        WebElement commentWrapper = driver.findElement(
                By.xpath("//div[contains(@class,'commentContainer')]")
        );

        if (commentWrapper.isDisplayed()) {
            // Get full text (comment + points)
            // Full text (comment + points with newlines)
            String fullText = commentWrapper.getText().trim();

// Remove trailing digits/slash parts (like "17 / 17")
            String currentComment = fullText.replaceAll("\\d+\\s*/\\s*\\d+$", "").trim();

            System.out.println("Comment on Student side: " + currentComment);
            System.out.println("Comment on Teacher side From Grade By Student: " + assignmentCommentFromGradeByStudent);

            TestRunner.getTest().log(Status.INFO, "Student Side Comment: " + currentComment);
            TestRunner.getTest().log(Status.INFO, "Teacher Side Comment From Grade By Student: " + assignmentCommentFromGradeByStudent);

            if (currentComment.equalsIgnoreCase(assignmentCommentFromGradeByStudent)) {
                System.out.println("The comments match: " + currentComment);
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: The comments match: " + currentComment);
            } else {
                System.out.println("The comments do not match. Teacher Side: "
                        + assignmentCommentFromGradeByStudent + ", Student Side: " + currentComment);
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: The comments do not match. Teacher Side: "
                        + assignmentCommentFromGradeByStudent + ", Student Side: " + currentComment);
            }
        } else {
            System.out.println("The Comments not displayed at Student Side");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: The Comments not displayed at Student Side");
        }

    }

}
