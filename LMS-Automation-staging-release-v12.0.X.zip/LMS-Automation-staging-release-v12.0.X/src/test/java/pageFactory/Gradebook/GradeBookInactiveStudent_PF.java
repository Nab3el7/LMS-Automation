package pageFactory.Gradebook;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

import static pageFactory.Gradebook.AssignmentVerification_PF.specificClasses;
import static pageFactory.StudentsModule.AddNewStudent_PF.FirstNameForNewStd;
import static pageFactory.StudentsModule.AddNewStudent_PF.randomClassNewStdEmail;
import static pageFactory.StudentsModule.ReadNewStdInfo_PF.updatedEmail;
import static pageFactory.StudentsModule.ReadNewStdInfo_PF.updatedName;

public class GradeBookInactiveStudent_PF {
    WebDriverWait wait;
    WebDriver driver;
    Helper helper;
    Actions actions;

    public  GradeBookInactiveStudent_PF(WebDriver driver){
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        helper = new Helper();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        actions = new Actions(driver);

    }

    public void searchClassByNameFOrNewStudent() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm in search Class By Name For New Student");
        WebElement right_panel= driver.findElement(By.xpath("//div[@class='right-panel']"));
        right_panel.isDisplayed();

        try {
            WebElement searchBox = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder='Search Class by keyword']")));
            if (searchBox.isDisplayed()) {
                searchBox.click();
                searchBox.clear();
                ((JavascriptExecutor) driver).executeScript("arguments[0].value='';", searchBox);
//                 = addClassPF.getClassName();
                System.out.println("Search by class name: " + specificClasses);
                TestRunner.getTest().log(Status.INFO, "Search by class name: " + specificClasses);
                searchBox.sendKeys(specificClasses);

                Actions actions = new Actions(driver);
                actions.sendKeys(Keys.ENTER).perform();
                TestRunner.getTest().log(Status.PASS, "Testcase Passed   : Enter Search Student keyword Successfully");

                waitForTableToRefresh();
            } else {
                System.out.println("Search box is not displayed.");
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : Search box is not displayed");
                throw new RuntimeException("Search Box not  Found.");
            }
        } catch (Exception e) {
            System.out.println("Search box is not available: " + e.getMessage());
        }

    }

    private void waitForTableToRefresh() {
        WebElement tableClasses = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class, 'ClassesDashboardRightPanel')]//tbody")));

        wait.until(ExpectedConditions.stalenessOf(tableClasses));

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(".//tr")));

        System.out.println("Table has refreshed.");
        TestRunner.getTest().log(Status.INFO, "Table has refreshed.");

    }

    public void VerifyThatStudentIsPresentInStudentList() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm into Find Specific Student");
        System.out.println("I'm into Find Specific Student ");

        WebElement stdTable = driver.findElement(By.xpath("//*[contains(@class, 'confirmStdTable')]"));
        List<WebElement> rows = stdTable.findElements(By.xpath(".//tbody/tr"));

        boolean studentFound = false;  // Flag to track if a student match is found

        for (WebElement row : rows) {
            WebElement studentCell = row.findElement(By.xpath(".//td[1]"));
            String studentName = studentCell.getText().trim();
            System.out.println("Student's Name: " + studentName);
            TestRunner.getTest().log(Status.INFO, "Student's Name: " + studentName);

            // Check if the student name matches
            if (studentName.contains(updatedName)) {
                studentFound = true;  // Set the flag to true if a student match is found
                System.out.println("Student: " + studentName + " matches with name: " + updatedName + " in the Student List table.");
                TestRunner.getTest().log(Status.PASS, "Student: " + studentName + " matches with name: " + updatedName + " in the Student List table.");

                // Retrieve the email from the next column (assuming it's in the second column)
                WebElement emailCell = row.findElement(By.xpath(".//td[2]"));
                String studentEmail = emailCell.getText().trim();
                System.out.println("Student's Email: " + studentEmail);
                TestRunner.getTest().log(Status.INFO, "Student's Email: " + studentEmail);
                System.out.println("Student's Email that we want to search: " + updatedEmail);
                TestRunner.getTest().log(Status.INFO, "Student's Email that we want to search: " + updatedEmail);

                // Check if the email matches
                if (studentEmail.equalsIgnoreCase(updatedEmail)) {
                    System.out.println("Student: " + studentName + " with email: " + studentEmail + " matches in the Student List table.");
                    TestRunner.getTest().log(Status.PASS, "Student: " + studentName + " with email: " + studentEmail + " matches in the Student List table.");


                    WebElement actionButton = row.findElement(By.xpath(".//td[6]//button"));


                    if (actionButton.isDisplayed() && actionButton.isEnabled()) {

                        helper.scrollToElement(driver,actionButton);
                        actionButton.click();
                        System.out.println("Clicked the button in the 6th column for student: " + studentName);
                        TestRunner.getTest().log(Status.INFO, "Clicked the button in the 6th column for student: " + studentName);
                        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Clicked the Edit  button for student: " + studentName);

                        TestRunner.getTest().log(Status.INFO, "I'm into change Status for Student: " + studentName);
                        VerifyInitialStatusIsActive(row);
//                        ChangeStudentStatusFromActiveToInActive(row);
                    } else {

                        System.out.println("Button is not clickable for student: " + studentName);
                        TestRunner.getTest().log(Status.FAIL, "Button is not clickable for student: " + studentName + " (either not displayed or not enabled).");
                    }
                } else {
                    // Log failure if the email doesn't match
                    System.out.println("Email for student: " + studentEmail + " does not match the expected email " + updatedEmail);
                    TestRunner.getTest().log(Status.FAIL, "Email for student: " + studentEmail + " does not match the expected email." + updatedEmail);
                }

                break;
            }
        }

        if (!studentFound) {
            System.out.println("No student found with the name: " + updatedName);
            TestRunner.getTest().log(Status.FAIL, "No student found with the name: " + updatedName + " in the Student List table.");
            throw new RuntimeException("Test failed: No matching student found in the list");
        }
    }

    public void VerifyInitialStatusIsActive(WebElement row) throws InterruptedException{
        Thread.sleep(3000);
        TestRunner.getTest().log(Status.INFO, "Checking if status is 'Active' in the 3rd column before changing it to 'Inactive'");
        System.out.println("Checking if status is 'Active' in the 3rd column before changing it to 'Inactive'");

        WebElement statusColumn = row.findElement(By.xpath(".//td[3]"));

        WebElement statusInput = statusColumn.findElement(By.xpath(".//input[contains(@class,'MuiSelect-nativeInput')]"));

        String currentStatusText = statusInput.getAttribute("value");
        System.out.println("Current status: " + currentStatusText);
        TestRunner.getTest().log(Status.INFO, "Current status: " + currentStatusText);

        if (currentStatusText.equalsIgnoreCase("Active")) {
            System.out.println("Initial status is 'Active'. Proceeding to change it to 'Inactive'.");
            TestRunner.getTest().log(Status.PASS, "Initial status is 'Active'. Proceeding to change it to 'Inactive'.");

            // Now, locate the dropdown button inside the 3rd column
            WebElement dropdown = statusColumn.findElement(By.xpath(".//div[@role='button' or @role='combobox' and @aria-haspopup='listbox']"));

            // Scroll to the dropdown and click it to open the options
            helper.scrollToElement(driver, dropdown);
            dropdown.click();  // Click to open the dropdown
            System.out.println("Dropdown in the 3rd column clicked successfully.");
            TestRunner.getTest().log(Status.PASS, "Dropdown in the 3rd column clicked successfully.");

            // Wait for the options to appear and select the "Inactive" option
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

            // Locate and click the "Inactive" option (modify the text if needed)
            WebElement inactiveOption = wait.until(ExpectedConditions.elementToBeClickable(
                    By.xpath("//li//span[text()='Inactive']")
            ));
            inactiveOption.click();  // Select the "Inactive" option
            System.out.println("Inactive option selected successfully.");
            TestRunner.getTest().log(Status.INFO, "Inactive option selected successfully.");
            TestRunner.getTest().log(Status.PASS, "Inactive option selected successfully.");

        } else {
            System.out.println("Initial status is not 'Active'. Test failed.");
            TestRunner.getTest().log(Status.FAIL, "Initial status is not 'Active'. Test failed.");
        }

    }

    public void ChangeStudentStatusFromActiveToInActive(WebElement row) throws InterruptedException {
        Thread.sleep(3000);
        TestRunner.getTest().log(Status.INFO, "I'm into change Status From Active to InActive");
        System.out.println("I'm into change Status From Active to InActive");


        // First, locate the 3rd column in the current row
        WebElement statusColumn = row.findElement(By.xpath(".//td[3]"));

        // Now, locate the dropdown inside the 3rd column
        WebElement dropdown = statusColumn.findElement(By.xpath(".//div[@role='button' or @role='combobox' and @aria-haspopup='listbox']"));

        if (dropdown.isDisplayed() && dropdown.isEnabled()) {
            helper.scrollToElement(driver, dropdown);
            dropdown.click();  // Click to open the dropdown
            System.out.println("Dropdown in the 3rd column clicked successfully.");
            TestRunner.getTest().log(Status.PASS, "Dropdown in the 3rd column clicked successfully.");

            // Wait for the options to appear and select the "Inactive" option
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

            // Locate and click the "Inactive" option (Modify the option text if different)
            WebElement inactiveOption = wait.until(ExpectedConditions.elementToBeClickable(
                    By.xpath("//li//span[text()='Inactive']")
            ));
            inactiveOption.click();  // Select the "Inactive" option
            System.out.println("Inactive option selected successfully.");
            TestRunner.getTest().log(Status.INFO, "Inactive option selected successfully" + updatedName);
            TestRunner.getTest().log(Status.PASS, "Inactive option selected successfully.");
        } else {
            System.out.println("Dropdown is not clickable in the 3rd column.");
            TestRunner.getTest().log(Status.FAIL, "Dropdown is not clickable in the 3rd column.");
        }
    }


    public void ClickOnNextBtnForStdInactive() throws InterruptedException{

        TestRunner.getTest().log(Status.INFO, "I'm into click on Next Button Class Step-I");
        System.out.println("I'm into click on Next Button Class Step-I");

        Thread.sleep(3000);
        WebElement btnNextClass= driver.findElement(By.xpath("//button[@id='btn-nextClasses']"));

        helper.scrollToElement(driver, btnNextClass);
        btnNextClass.click();

    }

    public void ClickOnSaveNextBtnForStdInactiveStepII() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm into click on SaveNext Button Class Step-II");
        System.out.println("I'm into click on SaveNext Button Class Step-I");
        Thread.sleep(3000);


        WebElement btnSaveNextClass= driver.findElement(By.xpath("//button[normalize-space()='Save/Next']"));

        helper.scrollToElement(driver, btnSaveNextClass);
        btnSaveNextClass.click();
    }

    public void VerifyThatStudentIsNotPresentActiveStudentListGradeBook() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm into verify Student is Not Present in Active Student List On GradeBook");
        System.out.println("I'm into verify Student is Not Present in Active Student List On GradeBook");
        Thread.sleep(3000);

        WebElement listStudent = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class, 'StudentListingWrapper')]")));

        List<WebElement> totalStudents = listStudent.findElements(By.tagName("h6"));
        System.out.println("Total Active students in class: " + totalStudents.size());
        TestRunner.getTest().log(Status.INFO, "Total Active students in class: " + totalStudents.size());

        boolean studentFound = false;

        for (WebElement student : totalStudents) {
            String studentName = student.getText().trim();
            System.out.println("Student Name is: " + studentName);
            TestRunner.getTest().log(Status.PASS, "Student in List: " + studentName);

            // Check if the student's name matches 'FirstNameForNewStd'
            if (studentName.contains(updatedName)) {
                studentFound = true;
                System.out.println("Inactive Student " + updatedName + " is found in the list.");
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Inactive Student " + updatedName + " is present in the list.");
                break; // Exit the loop if student is found
            }
        }

        if (!studentFound) {
            System.out.println("Inactive Student " + updatedName + " is not found in the list.");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Inactive Student " + updatedName + " is not present in the list.");
        } else {
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed: Inactive Student " + updatedName + " was found in In-Active Student List");
        }

        TestRunner.getTest().log(Status.PASS, "GradeBook students displayed successfully.");

    }


    public void VerifyStudentISPresentInInactiveStudentListGradeBook() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm into verify Student is Present In InActive Student List On GradeBook");
        System.out.println("I'm into verify Student is Present In InActive Student List On GradeBook");
        Thread.sleep(3000);

        WebElement listStudent = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class, 'StudentListingWrapper')]")));

        List<WebElement> totalStudents = listStudent.findElements(By.tagName("h6"));
        System.out.println("Total Inactive student in class: " + totalStudents.size());
        TestRunner.getTest().log(Status.INFO, "Total Inactive student in class: " + totalStudents.size());

        boolean studentFound = false;

        for (WebElement student : totalStudents) {
            String studentName = student.getText().trim();
            System.out.println("Student Name is: " + studentName);
            TestRunner.getTest().log(Status.PASS, "Student in List: " + studentName);

            // Check if the student's name matches 'FirstNameForNewStd'
            if (studentName.contains(updatedName)) {
                studentFound = true;
                System.out.println("InActive Student " + updatedName + " is found in the list.");
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: Inactive Student " + updatedName + " is present in the list.");
                break; // Exit the loop if student is found
            }
        }

        if (!studentFound) {
            System.out.println("Inactive Student " + updatedName + " is not found in the list.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Inactive Student " + updatedName + " is not present in the list.");
            throw new RuntimeException("Test Case Failed: Student " + updatedName + " not found.");
        }

        TestRunner.getTest().log(Status.PASS, "GradeBook students displayed successfully.");


    }


    public void SearchInactiveStudentGradeBook() throws InterruptedException{

        TestRunner.getTest().log(Status.INFO, "I'm into verify search Inactive Student in GradeBook search bar");
        System.out.println("I'm into verify search Inactive Student in GradeBook search ba");
        Thread.sleep(3000);

        TestRunner.getTest().log(Status.INFO, "Verifying the search for Inactive Student in the GradeBook search bar");
        System.out.println("Verifying the search for Inactive Student in the GradeBook search bar");
        Thread.sleep(3000);

        WebElement searchInactiveStd = driver.findElement(By.xpath("//input[@placeholder='Search Student']"));
        if (searchInactiveStd.isDisplayed()) {
            searchInactiveStd.click();
            System.out.println("Searching for Inactive Student");
            TestRunner.getTest().log(Status.INFO, "Searching for Inactive Student from the Search bar: " + updatedName);
            searchInactiveStd.sendKeys(updatedName);
            Thread.sleep(2000);

            // Retrieve the list of students
            List<WebElement> listStudent = driver.findElements(By.xpath("//div[contains(@class, 'item undefined')]"));

            boolean isStudentFound = false;

            // Iterate over each student in the list
            for (WebElement student : listStudent) {
                String studentName = student.getText().trim();
                System.out.println("Inactive Student Name: " + studentName);
                TestRunner.getTest().log(Status.INFO, "Student Name found: " + studentName);

                // Check if the current student matches the one we are searching for
                if (studentName.contains(updatedName)) {
                    System.out.println("Inactive Student '" + updatedName + "' found in the list.");
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed: Inactive Student '" + updatedName + "' found in the list successfully.");
                    isStudentFound = true;
                    break; // Stop the loop once the student is found
                }
            }

            // If the student is not found, fail the test case
            if (!isStudentFound) {
                System.out.println("Inactive Student '" + updatedName + "' is not found in the list.");
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Inactive Student '" + updatedName + "' not found in the list.");
                throw new RuntimeException("Inactive Student '" + updatedName + "' not found in the list.");
            }

        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Search bar is not displayed.");
            throw new RuntimeException("Search bar is not displayed.");
        }

    }

}
