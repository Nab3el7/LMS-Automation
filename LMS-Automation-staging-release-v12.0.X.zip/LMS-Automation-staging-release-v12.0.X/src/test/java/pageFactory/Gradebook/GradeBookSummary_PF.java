package pageFactory.Gradebook;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Assignmment.CorrectAnswerExecutor_PF;

import java.time.Duration;
import java.util.List;


public class GradeBookSummary_PF {
    WebDriverWait wait;
    WebDriver driver;
    Helper helper;
    Actions actions;

    @FindBy(xpath = "//div[@role='dialog']")
    WebElement delete_dialogue;

    @FindBy(xpath = "//div[@aria-labelledby='simple-tab-2']")
    WebElement panel_Assignments;

    public  GradeBookSummary_PF(WebDriver driver){
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        helper = new Helper();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        actions = new Actions(driver);

    }

    public void ChangeStudentStatus() throws InterruptedException{
        System.out.println("I'm in to select Student and change Status");
        TestRunner.getTest().log(Status.INFO, "I'm in to select Student and change Status");
        Thread.sleep(1000);
        
        // Locate the table
        WebElement table = driver.findElement(By.xpath("//div[contains(@class, 'StudentGradingWrapper')]"));
        List<WebElement> rows = table.findElements(By.xpath(".//tbody/tr"));

        String targetStudentName = "David Warner";
        
        for (WebElement row : rows) {
            String studentName;
            try {
                // Find the student name from the <p> tag within the first cell
                WebElement studentNameElement = row.findElement(By.xpath(".//td[1]//p[contains(@class,'MuiTypography-body1')]"));
                studentName = studentNameElement.getText().trim();
            } catch (NoSuchElementException e) {
                // Fallback: get text from the cell directly if <p> tag not found
                WebElement studentCell = row.findElement(By.xpath(".//td[1]"));
                studentName = studentCell.getText().trim();
            }

            // First check if student name matches "David Warner"
            if (studentName.equalsIgnoreCase(targetStudentName)) {
                System.out.println("Found target student: " + studentName);
                TestRunner.getTest().log(Status.INFO, "Found target student: " + studentName);

                // Now check the status
                WebElement statusCell = row.findElement(By.xpath(".//input[@placeholder='Select']"));
                String currentStatusText = statusCell.getAttribute("value");
                System.out.println("Current status: " + currentStatusText);
                TestRunner.getTest().log(Status.INFO, "Current status: " + currentStatusText);
                System.out.println("Student Assignment Status: " + currentStatusText);

                // Check if status is Submitted or Graded
                if (currentStatusText.equalsIgnoreCase("Submitted") || currentStatusText.equalsIgnoreCase("Graded")) {
                    System.out.println("Student's Name: " + studentName);
                    TestRunner.getTest().log(Status.INFO, "Student's Name: " + studentName);

                    System.out.println("Student Status: " + currentStatusText);
                    TestRunner.getTest().log(Status.INFO, "Student Status: " + currentStatusText);

                    WebElement scoreCell = row.findElement(By.xpath(".//td[3]"));
                    String score = scoreCell.getText().trim();

                    helper.scrollToElement(driver, scoreCell);
                    Thread.sleep(2000);

                    System.out.println("Student: " + studentName + " Status: " + currentStatusText + " Original Score: " + score);
                    TestRunner.getTest().log(Status.INFO, "Student: " + studentName + " Status: " + currentStatusText + " Original Score: " + score);

                    // Change the status to "Started" for the selected student
                    changeStatusToStarted(row);
                    break; // Exit loop after finding and processing the target student
                } else {
                    System.out.println("Student " + studentName + " status is not Submitted or Graded. Current status: " + currentStatusText);
                    TestRunner.getTest().log(Status.INFO, "Student " + studentName + " status is not Submitted or Graded. Current status: " + currentStatusText);
                    break; // Exit loop even if status doesn't match, since we found the target student
                }
            }
        }
    }

    public void changeStatusToStarted(WebElement studentRow) throws InterruptedException {
        System.out.println("Now change Status to Started");
        TestRunner.getTest().log(Status.INFO, "Now change Status to Started");

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        // Locate the dropdown specific to this student's row and click to open it
        WebElement dropdown = wait.until(ExpectedConditions.elementToBeClickable(
                studentRow.findElement(By.xpath(".//input[@placeholder='Select']/parent::div"))
        ));
        dropdown.click();
        System.out.println("Status DropDown clicked ");
        TestRunner.getTest().log(Status.INFO, "Status DropDown clicked ");

        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//ul[@role='listbox']//li")));

        List<WebElement> StatusOption = driver.findElements(By.xpath("//ul[@role='listbox']//li"));
        System.out.println("Total status options: " + StatusOption.size());

        for (WebElement option : StatusOption) {
            String optionText = option.getText().trim();
            System.out.println("Option found: " + optionText);

            if (optionText.equalsIgnoreCase("Started")) {
                option.click(); // Click on the "Started" option
                System.out.println("Clicked on the 'Started' option.");
                TestRunner.getTest().log(Status.INFO, "Clicked on the 'Started' option.");
                TestRunner.getTest().log(Status.PASS, "Status Successfully change to Started");
                break;
            }else {
//                TestRunner.getTest().log(Status.FAIL, "Status option Started is not Enabled.");
                System.out.println("Status option Started is not Enabled.");
            }
        }
    }

    public void UnsubmittedDialogueBox() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "UnSubmit Dialogue Window pop-up");
        System.out.println("UnSubmit Dialogue Window pop-up");

        WebElement dialogBoxUnSubmitted = wait.until(ExpectedConditions.visibilityOf(delete_dialogue));
        if (dialogBoxUnSubmitted.isDisplayed()) {

            WebElement titleElement = dialogBoxUnSubmitted.findElement(By.xpath(".//h2[contains(@id, 'customized-dialog-title')]"));
            String titleText = titleElement.getText().trim();
            System.out.println("Dialog Title: " + titleText);
            TestRunner.getTest().log(Status.INFO, "Dialog Title: " + titleText);


            WebElement descriptionElement1 = dialogBoxUnSubmitted.findElement(By.xpath(".//div[contains(@class,'MuiDialogContent-root')]//h2[1]"));
            String descriptionText1 = descriptionElement1.getText().trim();
            System.out.println("Description 1: " + descriptionText1);
            TestRunner.getTest().log(Status.INFO, "Description 1: " + descriptionText1);

            WebElement descriptionElement2 = dialogBoxUnSubmitted.findElement(By.xpath(".//div[contains(@class,'MuiDialogContent-root')]//h2[2]"));
            String descriptionText2 = descriptionElement2.getText().trim();
            System.out.println("Description 2: " + descriptionText2);
            TestRunner.getTest().log(Status.INFO, "Description 2: " + descriptionText2);

            System.out.println("All Information get Successfully from Un-Submitted Dialogue Box");
            TestRunner.getTest().log(Status.PASS, "All Information get Successfully from Un-Submitted Dialogue Box");
        }else {
            TestRunner.getTest().log(Status.FAIL, "Un-Submitted. Assessment Dialogue Box not appear.");
            System.out.println("Un-Submitted. Assessment Dialogue Box not appear.");
        }
    }

    public void ClickSaveBtn() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm in to click on Save Button in Un-Submitted Dialogue Box");
        System.out.println("I'm in to click on Save Button in Un-Submitted Dialogue Box");

        WebElement saveBtn= driver.findElement(By.xpath("//button[normalize-space()='Save']"));

        if (saveBtn.isDisplayed() && saveBtn.isEnabled()){
            saveBtn.click();
            System.out.println("Un-Submitted Dialogue Box Save Button Click Successfully");
            TestRunner.getTest().log(Status.PASS, "Un-Submitted Dialogue Box Save Button Click Successfully");
        }else {
            TestRunner.getTest().log(Status.FAIL, "Un-Submitted Dialogue Box Save Button is Disable/Not found.");
            System.out.println("Un-Submitted Dialogue Box Save Button is Disable/Not found");
        }
    }

    public void VerifyStatusChangeAssessmentInToCloseTab() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm in to find status change assessment is found in close tab or not");
        System.out.println("I'm in to find status change assessment is found in close tab or not");

        String assignmentNameForCorrect = CorrectAnswerExecutor_PF.assignmentNameForCorrect.get();
        System.out.println("Want to search assessment to verify status change in closed tab: " + assignmentNameForCorrect);
        TestRunner.getTest().log(Status.INFO, "Want to search assessment to verify status change in closed tab: " + assignmentNameForCorrect);

        TestRunner.getTest().log(Status.INFO, "Want to search assessment in closed tab: " + assignmentNameForCorrect);

        WebElement searchBar = driver.findElement(By.xpath("//input[@placeholder='Search Assignment by Title']"));
        searchBar.clear();
        searchBar.click();
        searchBar.sendKeys(assignmentNameForCorrect);
        searchBar.sendKeys(Keys.ENTER);

        Thread.sleep(3000);

        WebElement searchBtn = driver.findElement(By.xpath("//button[contains(@class,'MuiButtonBase-root MuiIconButton-root MuiIconButton-edgeStart')]"));
        searchBtn.click();

        Thread.sleep(3000);

        WebElement myAssignmentGrid = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@aria-labelledby='simple-tab-2']")));

        if (myAssignmentGrid.isDisplayed() && myAssignmentGrid.isEnabled()) {
            WebElement btnClosed = driver.findElement(By.xpath("//button[@id='simple-tab-3']"));
            btnClosed.click();

            WebElement panelTabClosed = driver.findElement(By.xpath("//div[@id='simple-tabpanel-3']"));
            wait.until(ExpectedConditions.visibilityOf(panelTabClosed));
            Thread.sleep(5000);

            String textClosedAssignments = panelTabClosed.getText();
            System.out.println("Closed Assignments are:");
            System.out.println(textClosedAssignments);

            // Check if "Assignments not found!" message is displayed
            if (textClosedAssignments.contains("Assignments not found!")) {
                System.out.println("No assignments found in the Closed tab - Test Case Passed.");
                TestRunner.getTest().log(Status.PASS, "No assignments found in the Closed tab.");
            } else {
                System.out.println("Assignments found in the Closed tab - Test Case Failed.");
                TestRunner.getTest().log(Status.FAIL, "Assignments found in the Closed tab.");
            }
        } else {
            System.out.println("Closed tab is not displayed or not enabled.");
            TestRunner.getTest().log(Status.FAIL, "Closed tab is not displayed or not enabled.");
        }

        driver.navigate().refresh();
        Thread.sleep(2000);
    }

    public void BulkStatusChangeToGradeAll() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm in to change Bulk Status For All Students");
        System.out.println("I'm in to change Bulk Status For All Students");

        WebElement tableInputCheckbox = driver.findElement(By.xpath("//div[contains(@class, 'StudentGradingWrapper')]//table//th[1]//input"));
        tableInputCheckbox.click();

        TestRunner.getTest().log(Status.PASS, "Clicked on all student checkbox");

        WebElement bulkStatusDropdown = wait.until(ExpectedConditions.elementToBeClickable(
                driver.findElement(By.xpath("//input[@placeholder='Select Status']/parent::div"))));

        bulkStatusDropdown.click();
        TestRunner.getTest().log(Status.PASS, "Bulk Status DropDown clicked ");

        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//ul[@role='listbox']//li")));

        List<WebElement> StatusOption = driver.findElements(By.xpath("//ul[@role='listbox']//li"));
        System.out.println("Total status options: " + StatusOption.size());

        for (WebElement option : StatusOption) {
            String optionText = option.getText().trim();
            System.out.println("Option found: " + optionText);

            if (optionText.equalsIgnoreCase("Grade All")) {
                option.click();
                System.out.println("Clicked on the 'Grade All' option.");
                TestRunner.getTest().log(Status.INFO, "Clicked on the 'Grade All' option.");
                TestRunner.getTest().log(Status.PASS, "Bulk Status Successfully change to Grade All for All Students");
                break;
            } else {
                System.out.println("Status option Grade All is not Enabled.");
            }
        }

        WebElement btnApplyBulkStatus = driver.findElement(By.xpath("//div[contains(@class, 'StudentGradingWrapper')]//table//th[2]//button[normalize-space()='Apply']"));

        if (btnApplyBulkStatus.isDisplayed() && btnApplyBulkStatus.isEnabled()) {
            btnApplyBulkStatus.click();
            TestRunner.getTest().log(Status.PASS, "Clicked on Apply Bulk Status button");
            System.out.println("Clicked on Apply Bulk Status button");
        } else {
            TestRunner.getTest().log(Status.FAIL, "Apply Bulk Status button is not enabled or not visible");
            System.out.println("Apply Bulk Status button is not enabled or not visible");
        }
    }

    public void verifyBulkStatusChangedToGradeAll() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm in to verify Bulk Status changed For all students");
        System.out.println("I'm in to verify Bulk Status changed For all students");

        wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//input[@placeholder='Select']/parent::div")));

        Thread.sleep(1000); // Small wait for page to stabilize

        // Get the count of dropdowns first
        List<WebElement> assignmentStatusDropdowns = driver.findElements(
                By.xpath("//input[@placeholder='Select']/parent::div"));

        int totalStudents = assignmentStatusDropdowns.size();
        TestRunner.getTest().log(Status.INFO, "Total students assignments: " + totalStudents);
        System.out.println("Total students assignments: " + totalStudents);

        // Re-locate elements inside the loop to avoid stale element references
        for (int i = 0; i < totalStudents; i++) {
            try {
                // Re-locate all dropdowns fresh for each iteration
                List<WebElement> freshDropdowns = driver.findElements(
                        By.xpath("//input[@placeholder='Select']/parent::div"));

                if (i < freshDropdowns.size()) {
                    WebElement dropdown = freshDropdowns.get(i);
                    
                    // Get text from the input element inside the dropdown to avoid stale reference
                    WebElement inputElement = dropdown.findElement(By.xpath(".//input[@placeholder='Select']"));
                    String dropdownText = inputElement.getAttribute("value").trim();

                    // If value attribute is empty, try getting text from dropdown
                    if (dropdownText == null || dropdownText.isEmpty()) {
                        dropdownText = dropdown.getText().trim();
                    }

                    TestRunner.getTest().log(Status.INFO, "Student " + (i + 1) + " status: " + dropdownText);
                    System.out.println("Student " + (i + 1) + " status: " + dropdownText);

                    if (!dropdownText.equals("Graded")) {
                        TestRunner.getTest().log(Status.FAIL, "Student " + (i + 1) + " status is not Graded, found: " + dropdownText);
                    }
                }
            } catch (StaleElementReferenceException e) {
                System.out.println("Stale element detected for student " + (i + 1) + ", retrying...");
                Thread.sleep(500);
                i--; // Retry the same index
            } catch (Exception e) {
                System.out.println("Error verifying status for student " + (i + 1) + ": " + e.getMessage());
                TestRunner.getTest().log(Status.WARNING, "Error verifying status for student " + (i + 1) + ": " + e.getMessage());
            }
        }

        TestRunner.getTest().log(Status.PASS, "All students' statuses are successfully set to Graded");
        System.out.println("All students' statuses are successfully set to Graded");
    }

    public void SubmittedAssessmentDialogueBox() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "Submit Assessment Window pop-up");
        System.out.println("Submit Assessment Window pop-up");

        WebElement dialogBoxUnSubmitted = wait.until(ExpectedConditions.visibilityOf(delete_dialogue));
        if (dialogBoxUnSubmitted.isDisplayed()) {

            WebElement titleElement = dialogBoxUnSubmitted.findElement(By.xpath(".//h2[contains(@id, 'customized-dialog-title')]"));
            String titleText = titleElement.getText().trim();
            System.out.println("Dialog Title: " + titleText);
            TestRunner.getTest().log(Status.INFO, "Dialog Title: " + titleText);


            WebElement descriptionElement1 = dialogBoxUnSubmitted.findElement(By.xpath(".//div[contains(@class,'MuiDialogContent-root')]//h2[1]"));
            String descriptionText1 = descriptionElement1.getText().trim();
            System.out.println("Description 1: " + descriptionText1);
            TestRunner.getTest().log(Status.INFO, "Description 1: " + descriptionText1);

            WebElement descriptionElement2 = dialogBoxUnSubmitted.findElement(By.xpath(".//div[contains(@class,'MuiDialogContent-root')]//h2[2]"));
            String descriptionText2 = descriptionElement2.getText().trim();
            System.out.println("Description 2: " + descriptionText2);
            TestRunner.getTest().log(Status.INFO, "Description 2: " + descriptionText2);

            System.out.println("All Information get Successfully from Submit Assessment Dialogue Box");
            TestRunner.getTest().log(Status.PASS, "All Information get Successfully from Submit Assessment Dialogue Box");
        }else {
            TestRunner.getTest().log(Status.FAIL, "Submitted Assessment Dialogue Box not appear.");
            System.out.println("Submit Assessment Dialogue Box not appear.");
        }
    }

    public void VerifyStartedStatusChangeAssessmentInToOpenTab() throws InterruptedException{
        if (!panel_Assignments.isDisplayed()) {
            throw new NoSuchElementException("Assignments panel is not displayed");
        }

        String assignmentNameForCorrect = CorrectAnswerExecutor_PF.assignmentNameForCorrect.get();
        System.out.println("Want to search assessment to verify the started status change: " + assignmentNameForCorrect);
        TestRunner.getTest().log(Status.INFO, "Want to search assessment to verify the started status change: " + assignmentNameForCorrect);

        System.out.println("Searching for assignment: " + assignmentNameForCorrect);
        TestRunner.getTest().log(Status.INFO, "Searching for assignment: " + assignmentNameForCorrect);
        WebElement searchBar = driver.findElement(By.xpath("//input[@placeholder='Search Assignment by Title']"));
//        searchBar.clear();
//        searchBar.click();
        // Click to focus
        searchBar.click();
        searchBar.sendKeys(Keys.CONTROL + "a");   // Select all text
        searchBar.sendKeys(Keys.BACK_SPACE);

        searchBar.sendKeys(assignmentNameForCorrect);
        searchBar.sendKeys(Keys.ENTER);
        Thread.sleep(2000);
        WebElement searchBtn = searchBar.findElement(By.xpath("./parent::div//button"));
        searchBtn.click();
        Thread.sleep(3000);

        By assignmentTabLocator = By.xpath("//div[@aria-labelledby='simple-tab-2']");
        wait.until(ExpectedConditions.visibilityOfElementLocated(assignmentTabLocator));
        wait.until(ExpectedConditions.elementToBeClickable(assignmentTabLocator));
        Thread.sleep(2000);

        List<WebElement> totalAssignments = panel_Assignments.findElements(By.xpath(".//div[contains(@class, 'MuiGrid-container')]"));
        System.out.println("Total Assignments: " + totalAssignments.size());
        System.out.println("Attempting to find assignment: " + assignmentNameForCorrect);
        TestRunner.getTest().log(Status.INFO, "Looking for assignment: " + assignmentNameForCorrect);

        boolean assignmentFound = false;

        for (WebElement assignment : totalAssignments) {
            WebElement assignmentNameElement = assignment.findElement(By.xpath(".//div[contains(@class, 'notranslate')]"));
            String assignmentName = assignmentNameElement.getText();
            System.out.println("Assignment Name: " + assignmentName);

            if (assignmentName.equals(assignmentNameForCorrect)) {
                System.out.println("Found assignment: " + assignmentName);
                assignmentFound = true;

                try {
                    WebElement startOrResumeButton = assignment.findElement(By.xpath(".//div[@statustype='START' or @statustype='RESUME']"));

                    if (startOrResumeButton.isDisplayed() && startOrResumeButton.isEnabled()) {
                        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Successfully started status assignment found: " + assignmentName);
                        System.out.println("Assignment status started: " + assignmentName);
                    } else {
                        TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Assignment status is not 'START' for assignment: " + assignmentName);
                        System.out.println("Assignment status is not 'START' for: " + assignmentName);
                    }
                    Thread.sleep(2000);
                } catch (NoSuchElementException e) {
                    TestRunner.getTest().log(Status.FAIL, "Test Case Failed: START/RESUME button not found for assignment: " + assignmentName);
                    System.out.println("START/RESUME button not found for assignment: " + assignmentName);
                }

                break;
            } else {
                System.out.println("Assignment not found: " + assignmentName);
            }
        }

        if (!assignmentFound) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Assignment not found: " + assignmentNameForCorrect);
            System.out.println("Assignment not found: " + assignmentNameForCorrect);
        }

        Thread.sleep(2000);

    }

    public void VerifyBulkStatusChangeAssessmentInToOpenTab() throws InterruptedException{

        if (!panel_Assignments.isDisplayed()) {
            throw new NoSuchElementException("Assignments panel is not displayed");
        }

        String assignmentNameForCorrect = CorrectAnswerExecutor_PF.assignmentNameForCorrect.get();
        System.out.println("Want to search assessment to verify the bulk status: " + assignmentNameForCorrect);
        TestRunner.getTest().log(Status.INFO, "Want to search assessment to verify the bulk status: " + assignmentNameForCorrect);

        System.out.println("Searching for assignment: " + assignmentNameForCorrect);
        TestRunner.getTest().log(Status.INFO, "Searching for assignment: " + assignmentNameForCorrect);
        WebElement searchBar = driver.findElement(By.xpath("//input[@placeholder='Search Assignment by Title']"));
        searchBar.clear();
        searchBar.click();
        searchBar.sendKeys(assignmentNameForCorrect);
        searchBar.sendKeys(Keys.ENTER);

        Thread.sleep(3000);

        WebElement searchBtn = driver.findElement(By.xpath("//button[contains(@class,'MuiButtonBase-root MuiIconButton-root MuiIconButton-edgeStart')]"));
        searchBtn.click();
        Thread.sleep(3000);

        WebElement myAssignmentGrid = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@aria-labelledby='simple-tab-2']")));

        if (myAssignmentGrid.isDisplayed() && myAssignmentGrid.isEnabled()) {

            WebElement panelTabOpenTab = driver.findElement(By.xpath("//div[@id='simple-tabpanel-2']"));
            wait.until(ExpectedConditions.visibilityOf(panelTabOpenTab));
            Thread.sleep(5000);

            String textOpenAssignments = panelTabOpenTab.getText();
            System.out.println("Open Assignments are:");
            System.out.println(textOpenAssignments);

            if (textOpenAssignments.contains("Assignments not found!")) {
                System.out.println("No assignments found in the Open tab - Test Case Passed.");
                TestRunner.getTest().log(Status.PASS, "No assignments found in the Open tab.");
            } else {
                System.out.println("Assignments found in the Open tab - Test Case Failed.");
                TestRunner.getTest().log(Status.FAIL, "Assignments found in the Open tab.");
            }
        } else {
            System.out.println("Open tab is not displayed or not enabled.");
            TestRunner.getTest().log(Status.FAIL, "Open tab is not displayed or not enabled.");
        }
        Thread.sleep(2000);

    }


    public void VerifyBulkStatusChangeAssessmentInToCloseTab() throws InterruptedException {
        TestRunner.startTest("Verify if the assessment is found in the closed tab After bulk Status Change to Submit-All");
        System.out.println("Verify if the assessment is found in the closed tab After bulk Status Change to Submit-All");

        String assignmentNameForCorrect = CorrectAnswerExecutor_PF.assignmentNameForCorrect.get();
        System.out.println("Want to search assessment to verify status change in closed tab: " + assignmentNameForCorrect);
        TestRunner.getTest().log(Status.INFO, "Want to search assessment to verify status change in closed tab: " + assignmentNameForCorrect);

        TestRunner.getTest().log(Status.INFO, "Want to search assessment in closed tab: " + assignmentNameForCorrect);
        WebElement searchBar = driver.findElement(By.xpath("//input[@placeholder='Search Assignment by Title']"));

// Click to focus
        searchBar.click();
        searchBar.sendKeys(Keys.CONTROL + "a");   // Select all text
        searchBar.sendKeys(Keys.BACK_SPACE);      // Delete

        searchBar.sendKeys(assignmentNameForCorrect);  // Enter the assignment name in the search bar
        searchBar.sendKeys(Keys.ENTER);

        Thread.sleep(3000);

        WebElement myAssignmentGrid = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@aria-labelledby='simple-tab-2']")));

        if (myAssignmentGrid.isDisplayed() && myAssignmentGrid.isEnabled()) {
            WebElement btnClosed = driver.findElement(By.xpath("//button[@id='simple-tab-3']"));
            btnClosed.click();

            WebElement panelTabClosed = driver.findElement(By.xpath("//div[@id='simple-tabpanel-3']"));
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='simple-tabpanel-3']")));

            String textClosedAssignments = panelTabClosed.getText();
            System.out.println("Closed Assignments are");
            System.out.println(textClosedAssignments);

            List<WebElement> totalAssignments = driver.findElements(By.xpath(".//div[contains(@class, 'MuiGrid-container')]"));
            System.out.println("Total Assignments: " + totalAssignments.size());

            TestRunner.getTest().log(Status.INFO, "Searching for assessment in the closed tab: " + assignmentNameForCorrect);

            for (WebElement assignment : totalAssignments) {
                WebElement assignmentNameElement = assignment.findElement(By.xpath(".//div[contains(@class, 'notranslate')]"));
                String assignmentsName = assignmentNameElement.getText();

                if (assignmentsName.equals(assignmentNameForCorrect)) {
                    System.out.println("Found assignment: " + assignmentsName);
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed: Assignment found in the closed tab: " + assignmentNameForCorrect);
                    return;
                }
            }

            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Assignment not found in the closed tab: " + assignmentNameForCorrect);

        } else {
            System.out.println("Student dashboard not loaded");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Student dashboard not loaded");
        }
    }


}
