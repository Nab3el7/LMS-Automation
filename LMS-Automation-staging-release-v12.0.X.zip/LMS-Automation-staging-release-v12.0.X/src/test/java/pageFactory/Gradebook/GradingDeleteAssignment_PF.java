package pageFactory.Gradebook;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Assignmment.CorrectAnswerExecutor_PF;
import pageFactory.Assignmment.StudentExecutor_PF;

import java.awt.*;
import java.time.Duration;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

import static pageFactory.Assignmment.CorrectAnswerExecutor_PF.assignmentNameForCorrect;

public class GradingDeleteAssignment_PF {
    WebDriverWait wait;
    WebDriver driver;
    Helper helper;
    String baseUrl = Configurations.App_url;

    private static String assignmentName;

    @FindBy(xpath = "//div[contains(@class, 'AssignmentWrapper')]")
    WebElement card_MyAssignment;

    @FindBy(xpath = "//div[@aria-labelledby='simple-tab-2']")
    WebElement panel_Assignments;

    @FindBy(xpath = "//div[contains(@class, 'StudentListingAndTableWrapper')]")
    WebElement studentAssignmentTable;


    @FindBy(xpath = "//nav[@aria-label='pagination navigation']")
    WebElement nav_Pagination;

    @FindBy(xpath = "//button[@aria-label='Go to next page']")
    WebElement btn_NavNextPage;

    CorrectAnswerExecutor_PF correctAnswerExecutor_pf;
    StudentExecutor_PF studentExecutor;

    public GradingDeleteAssignment_PF (WebDriver driver) {
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        helper = new Helper();
        correctAnswerExecutor_pf = new CorrectAnswerExecutor_PF(driver);
        studentExecutor = new StudentExecutor_PF(driver);
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
    }

    public void gotoURL() throws InterruptedException {
        Thread.sleep(3000);
        driver.get("https://staging.gallopade.com/gradebook/da334581-f649-45a9-a9d3-e12d32355b78/editAssignment/8c81e807-9be8-4583-ae4d-f0a75de765ea?classId=da334581-f649-45a9-a9d3-e12d32355b78&districtId=100&orgId=101&teacherId=&currentPage=1&totalRecords=20&totalPages=2&pageSize=10");
        Thread.sleep(2000);
    }

    public void selectQuizForDelete () throws InterruptedException {
        Thread.sleep(1000);
        WebElement divQuiz = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class, 'StudentListingAndTableWrapper')]")));
        List<WebElement> totalQuizzes = divQuiz.findElements(By.xpath("//div[contains(@class, 'QuizAverage')]"));

        int numberOfQuizzes = totalQuizzes.size();
        System.out.println("Number of Quizzes: " + numberOfQuizzes);

        List<String> excludedQuizTexts = Arrays.asList("CLASS AVERAGE", "DATE RANGE AVERAGE", "EXAM AVERAGE", "HOMEWORK AVERAGE", "PRACTICE AVERAGE", "QUIZ AVERAGE");

        for (WebElement quiz : totalQuizzes) {
            String quizText = quiz.getText().trim();
            System.out.println("Quiz text is: " + quizText);

            if (!excludedQuizTexts.contains(quizText)) {
                WebElement theadQuiz = quiz.findElement(By.xpath(".//table/thead"));
                List<WebElement> quizzes = theadQuiz.findElements(By.xpath(".//span[contains(@class,'vertical-text-container')]"));

                for (WebElement selectedQuiz : quizzes) {
                    String selectedQuizText = selectedQuiz.getText().trim();
                    if (!excludedQuizTexts.contains(selectedQuizText)) {
                        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", selectedQuiz);
                        Thread.sleep(1000);
                        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", selectedQuiz);

                        System.out.println("Text of Clicked Quiz: " + selectedQuizText);

                        if (isDeleteButtonClickable()) {
                            System.out.println("Delete button is clickable.");
                            clickDeleteButton();
                            return; // Break out of the loop and return
                        } else {
                            System.out.println("Delete button is not clickable, clicking next quiz.");
                            break; // Continue to the next quiz
                        }
                    }
                }
            }
        }
    }

    private boolean isDeleteButtonClickable() {
        List<WebElement> listAssignment = driver.findElements(By.xpath("//ul[@role='menu']"));

        for (WebElement option : listAssignment) {
            List<WebElement> buttons = option.findElements(By.tagName("li"));

            for (WebElement button : buttons) {
                String buttonText = button.getText().trim();
                boolean isEnabled = button.isEnabled();
                boolean isDisplayed = button.isDisplayed();

                System.out.println("Button Text: " + buttonText);
                System.out.println("Is Enabled: " + isEnabled);
                System.out.println("Is Displayed: " + isDisplayed);

                if (buttonText.equals("Delete") && isEnabled && isDisplayed) {
                    return true;
                }
            }
        }

        return false;
    }


    private void clickDeleteButton () {
        List<WebElement> listAssignment = driver.findElements(By.xpath("//ul[@role='menu']"));

        for (WebElement option : listAssignment) {
            List<WebElement> buttons = option.findElements(By.tagName("button"));

            for (WebElement button : buttons) {
                String buttonText = button.getText().trim();

                if (buttonText.equals("Delete") && button.isEnabled() && button.isDisplayed()) {
                    button.click();
                    System.out.println("Clicked on Delete button.");
                    return;
                }
            }
        }
    }

    public void verifyPrompt() throws InterruptedException{
        Thread.sleep(2000);

        WebElement prompt = driver.findElement(By.xpath("//div[@role='dialog']"));
        boolean isDisplayed = prompt.isDisplayed();
        Assert.assertTrue("Prompt is not displayed.", isDisplayed);

        WebElement promptHeader = prompt.findElement(By.tagName("h2"));
        String headerText = promptHeader.getText();
        System.out.println("Prompt header text is: " + headerText);
        TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  Prompt Display Successfully");
    }

    public String getAssignmentName() {
        if (assignmentName == null) {
            try {
                WebElement prompt = driver.findElement(By.xpath("//div[@role='dialog']"));
                WebElement headerAssignmentText = prompt.findElement(By.xpath(".//div[contains(@class, 'header-student')]"));
                System.out.println("Assignment header: " + headerAssignmentText.getText());
                WebElement assignmentNamePrompt = headerAssignmentText.findElement(By.xpath(".//span[contains(@class, 'ListItemText-title')]"));
                assignmentName = assignmentNamePrompt.getText();
                System.out.println("Assignment Name is: " + assignmentName);
            } catch (NoSuchElementException e) {
                System.out.println("Dialog element not found.");
            }

        }
        return assignmentName;
    }

    public void DeleteAssignmentForAllStudent() {
        WebElement prompt = driver.findElement(By.xpath("//div[@role='dialog']"));

        WebElement headerAssignmentText = prompt.findElement(By.xpath(".//div[contains(@class, 'header-student')]"));
        System.out.println("Assignment header: " + headerAssignmentText.getText());

        WebElement assignmentNamePrompt = headerAssignmentText.findElement(By.xpath(".//span[contains(@class, 'ListItemText-title')]"));
        String assignmentName = assignmentNamePrompt.getText();
        System.out.println("Assignment Name is: " + assignmentName);

        WebElement tableStudent = prompt.findElement(By.xpath("//div[@class='studentTable']//table"));

        WebElement rowsStudentTableHeader = tableStudent.findElement(By.xpath(".//thead/tr"));

        System.out.println("Student table header: " + rowsStudentTableHeader.getText());

        WebElement promptFooter = prompt.findElement(By.xpath("//div[contains(@class,'btn-footer')]"));

        WebElement yesButton = promptFooter.findElement(By.xpath("//button[contains(text(), 'Yes')]"));
        System.out.println("Button text is: " + yesButton.getText());
        yesButton.click();

        // Simulate pressing the ESC key
//        Actions actions = new Actions(driver);
//        actions.sendKeys(Keys.ESCAPE).build().perform();
    }

    public void DeleteAssignmentForParticularStudent() throws InterruptedException{
        WebElement prompt = driver.findElement(By.xpath("//div[@role='dialog']"));

        WebElement headerAssignmentText = prompt.findElement(By.xpath("//div[contains(@class, 'header-student')]"));
        System.out.println("Assignment Name is: " + headerAssignmentText.getText());

        WebElement tableStudent = prompt.findElement(By.xpath("//div[@class='studentTable']//table"));

        List<WebElement> rowsStudents = tableStudent.findElements(By.xpath(".//tbody/tr"));
        int totalStudents = rowsStudents.size();
        System.out.println("Total students: " + totalStudents);

        for (WebElement rowStudent : rowsStudents) {
            System.out.println("Student row: " + rowStudent.getText());
        }

        for (WebElement rowStudent : rowsStudents) {
            WebElement inputCheckbox = rowStudent.findElement(By.xpath(".//input[@type='checkbox']"));
            if (inputCheckbox.isSelected()) {
                inputCheckbox.click();
            }
        }

        Random rand = new Random();
        int randomStudentIndex = rand.nextInt(totalStudents);

        WebElement randomStudentRow = rowsStudents.get(randomStudentIndex);
        WebElement inputCheckbox = randomStudentRow.findElement(By.xpath(".//input[@type='checkbox']"));
        inputCheckbox.click();

        Thread.sleep(1000);
        WebElement promptFooter = prompt.findElement(By.xpath("//div[contains(@class,'btn-footer')]"));

        WebElement yesButton = promptFooter.findElement(By.xpath("//button[contains(text(), 'Yes')]"));
        System.out.println("Button text is: " + yesButton.getText());
        yesButton.click();

        // Simulate pressing the ESC key
//        Actions actions = new Actions(driver);
//        actions.sendKeys(Keys.ESCAPE).build().perform();

    }

    public void searchDeletedAssignmentIntoStudentPanel() throws InterruptedException {
        String searchAssignmentName = assignmentName;
        System.out.println("Search assignment name: " + searchAssignmentName);

        if (panel_Assignments.isDisplayed()){
            WebElement tab_Assignment = card_MyAssignment.findElement(By.xpath("//div[@aria-label='wrapped label tabs example']"));

            List<WebElement> AssignmentTabs = tab_Assignment.findElements(By.xpath(".//button"));
            System.out.println("Total tabs: " + AssignmentTabs.size());

            boolean assignmentFound = false;

            for (WebElement AssignmentTab : AssignmentTabs) {
                String tabText = AssignmentTab.getText();
                String[] tabParts = tabText.split(":");
                String tabName = tabParts[0].trim();
                System.out.println("Assignment Tab Text: " + tabName);

                AssignmentTab.click();

                Thread.sleep(2000);

//                List<WebElement> tabPanels = panel_Assignments.findElements(By.xpath(".//div[@id='simple-tabpanel-2']"));
                List<WebElement> tabPanels = panel_Assignments.findElements(By.xpath(".//div[@role='tabpanel']"));
                System.out.println("Total Assignments into panel: " + tabPanels.size());
                for (WebElement tabPanel : tabPanels) {
                    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[@class='ScrollbarsCustom-Content'])[2]")));
                    Thread.sleep(1000);
                    String panelText = tabPanel.getText();
                    System.out.println("Panel Text: " + panelText);

                    if (tabName.equals("Open")) {
                        if (panelText.contains(searchAssignmentName)) {
                            System.out.println("Test case passed: Resubmitted assignment shows into Open tab");
                            assignmentFound = true;
                        }
                    } else {
                        if (panelText.contains(searchAssignmentName)) {
                            System.out.println("Test case passed but Assignment shows into '" + tabName + "' tab ");
                            assignmentFound = true;
                        }
                    }
                }

            }

            if (!assignmentFound) {
                System.out.println("Test case passed: Assignment not found in any panel");
            }
        }
    }


    // deletion for specific student

    public void searchAssignmentNames(String assignmentName) throws InterruptedException {
        WebElement assignmentTable = wait.until(ExpectedConditions.visibilityOf(studentAssignmentTable));

        List<WebElement> assignmentContainers = assignmentTable.findElements(By.xpath(".//thead//tr//th"));
        System.out.println("Total Assignment Names are: " + assignmentContainers.size());

        for (int i = 0; i < assignmentContainers.size(); i++) {
            WebElement assignment = assignmentContainers.get(i);
            String assignmentsName = assignment.getText();
            System.out.println("Assignment Name: " + assignmentsName);

            if (assignmentsName.equalsIgnoreCase(assignmentName)) {
                System.out.println("Found assignment: " + assignmentsName);

                boolean staleElement = true;
                while (staleElement) {
                    try {
                        // Re-locate the assignment element to avoid stale element issues
                        assignmentContainers = assignmentTable.findElements(By.xpath(".//thead//tr//th"));
                        assignment = assignmentContainers.get(i);

                        // Wait until the assignment is clickable
                        wait.until(ExpectedConditions.elementToBeClickable(assignment));
                        assignment.click();
                        staleElement = false; // Break the loop as element is successfully clicked

                        System.out.println("Assignment found");
                        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Assignment found successfully " + assignmentsName);

                        // Perform other actions
                        Thread.sleep(2000);
//                        clickGradeButton();
                        TestRunner.getTest().log(Status.INFO, "I'm in Click on Delete Button");
                        ClickDeleteButton();
                        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Click on Delete button successfully " + assignmentsName);

//                        wait.until(ExpectedConditions.invisibilityOf(progressBar));
//                        manualGrading_PF.ClickOnSummaryTab();
//                        manualGrading_PF.AssignmentScoresSummary();
//                        wait.until(ExpectedConditions.invisibilityOf(progressBar));
//                        Thread.sleep(2000);
//                        assignmentScoreVerification_PF.PrintAndVerifyStudentScoreWithAssignmentScore();
//                        Thread.sleep(2000);
//                        assignmentScoreVerification_PF.AssignmentScoresSummaryForVerification();

                    } catch (StaleElementReferenceException e) {
                        System.out.println("StaleElementReferenceException occurred. Retrying...");
                        staleElement = true; // Continue the loop to re-locate and retry
                    } catch (NoSuchElementException e) {
                        TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Delete button not found for assignment: " + assignmentName);
                        return;
                    }
                }
                break; // Exit loop once the desired assignment is found and processed
            }
        }
    }

    public void ClickDeleteButton() throws InterruptedException{

        TestRunner.getTest().log(Status.INFO, "I'm in to select Delete Option from Menu");
        System.out.println("Delete button");
        Thread.sleep(2000);

        List<WebElement> listAssignment = driver.findElements(By.xpath("//ul[@role='menu']"));
        System.out.println("I'm in to click on Delete button");

        for (WebElement option : listAssignment) {
            List<WebElement> buttons = option.findElements(By.tagName("button"));

            for (WebElement button : buttons) {
                String buttonText = button.getText().trim();

                if (buttonText.equals("Delete") && button.isEnabled() && button.isDisplayed()) {
                    button.click();
                    System.out.println("Clicked on Delete button.");
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed: Grade Button Click Successfully");
                    return;
                }
            }
        }

    }

    public void VerifyAssignmentName() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm in to Verify Assignment Name on Delete Dialogue Box");
        System.out.println("I'm in to Verify Assignment Name on Delete Dialogue Box");

        WebElement prompt = driver.findElement(By.xpath("//div[@role='dialog']"));
        WebElement headerAssignmentText = prompt.findElement(By.xpath(".//div[contains(@class, 'header-student')]"));
        System.out.println("Assignment header: " + headerAssignmentText.getText());
        WebElement assignmentNamePrompt = headerAssignmentText.findElement(By.xpath(".//span[contains(@class, 'ListItemText-title')]"));
        assignmentName = assignmentNamePrompt.getText();
        System.out.println("Assignment Name is: " + assignmentName);

        TestRunner.getTest().log(Status.INFO, "I'm in to Compare Assignment Names");
        System.out.println("I'm in to Compare Assignment Names");

        String assignmentNameForCorrect = CorrectAnswerExecutor_PF.assignmentNameForCorrect.get();
        System.out.println("Want to search assessment delete dialogue box: " + assignmentNameForCorrect);
        TestRunner.getTest().log(Status.INFO, "Want to search assessment delete dialogue box: " + assignmentNameForCorrect);

        if (assignmentName.equalsIgnoreCase(assignmentNameForCorrect)){
            System.out.println("Assignment That You Want to Delete Title Match on Delete Dialogue Box");
            TestRunner.getTest().log(Status.INFO, assignmentName + " Name on Delete Dialogue Window match with Assignment name " + assignmentNameForCorrect );
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Assignment That You Want to Delete Title Match on Delete Dialogue Box");
        }else {
            System.out.println("Assignment That You Want to Delete Title Miss Match on Delete Dialogue Box");
            TestRunner.getTest().log(Status.INFO, assignmentName + " Name on Delete Dialogue Window Miss Match with Assignment name " + assignmentNameForCorrect );
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Assignment That You Want to Delete Title Miss Match on Delete Dialogue Box");
//            throw new RuntimeException("Assignment That You Want to Delete Title Miss Match on Delete Dialogue Box.");
        }

    }

    public void VerifyAssignmentNameForUnSubmit() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm in to Verify Assignment Name on UnSubmit Dialogue Box");
        System.out.println("I'm in to Verify Assignment Name on UnSubmit Dialogue Box");

        WebElement prompt = driver.findElement(By.xpath("//div[@role='dialog']"));
        WebElement headerAssignmentText = prompt.findElement(By.xpath(".//div[contains(@class, 'header-student')]"));
        System.out.println("Assignment header: " + headerAssignmentText.getText());
        WebElement assignmentNamePrompt = headerAssignmentText.findElement(By.xpath(".//span[contains(@class, 'ListItemText-title')]"));
        assignmentName = assignmentNamePrompt.getText();
        System.out.println("Assignment Name is: " + assignmentName);

        TestRunner.getTest().log(Status.INFO, "I'm in to Compare Assignment Names");
        System.out.println("I'm in to Compare Assignment Names");

        String assignmentNameForCorrect = CorrectAnswerExecutor_PF.assignmentNameForCorrect.get();
        System.out.println("Want to search assessment unSubmit dialogue box: " + assignmentNameForCorrect);
        TestRunner.getTest().log(Status.INFO, "Want to search assessment unSubmit dialogue box: " + assignmentNameForCorrect);

        if (assignmentName.equalsIgnoreCase(assignmentNameForCorrect)){
            System.out.println("Assignment That You Want to UnSubmit Title Match on UnSubmit Dialogue Box");
            TestRunner.getTest().log(Status.INFO, assignmentName + " Name on UnSubmit Dialogue Window match with Assignment name " + assignmentNameForCorrect );
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Assignment That You Want to UnSubmit Title Match on UnSubmit Dialogue Box");
        }else {
            System.out.println("Assignment That You Want to UnSubmit Title Miss Match on Delete Dialogue Box");
            TestRunner.getTest().log(Status.INFO, assignmentName + " Name on UnSubmit Dialogue Window Miss Match with Assignment name " + assignmentNameForCorrect );
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Assignment That You Want to UnSubmit Title Miss Match on UnSubmit Dialogue Box");
//            throw new RuntimeException("Assignment That You Want to UnSubmit Title Miss Match on UnSubmit Dialogue Box.");
        }

    }

    public void DeleteAssignmentForSpecificStudent() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm in to Delete Assignment for specific student");
        System.out.println("I'm in to Delete Assignment for specific student");

        WebElement prompt = driver.findElement(By.xpath("//div[@role='dialog']"));

        WebElement headerAssignmentText = prompt.findElement(By.xpath("//div[contains(@class, 'header-student')]"));
        System.out.println("Assignment Name is: " + headerAssignmentText.getText());
        TestRunner.getTest().log(Status.INFO, "Assignment Name is: " + headerAssignmentText.getText());

        WebElement tableStudent = prompt.findElement(By.xpath("//div[@class='studentTable']//table"));

        List<WebElement> rowsStudents = tableStudent.findElements(By.xpath(".//tbody/tr"));
        int totalStudents = rowsStudents.size();
        System.out.println("Total students: " + totalStudents);

        for (WebElement rowStudent : rowsStudents) {
            System.out.println("Student row: " + rowStudent.getText());
            TestRunner.getTest().log(Status.INFO, "Student Name: " + rowStudent.getText());
        }

        for (WebElement rowStudent : rowsStudents) {
            WebElement inputCheckbox = rowStudent.findElement(By.xpath(".//input[@type='checkbox']"));

            // If the checkbox is selected, deselect it and select it again
            if (inputCheckbox.isSelected()) {
                // Deselect the checkbox
                inputCheckbox.click();
                TestRunner.getTest().log(Status.INFO, "Checkbox was selected, so it was deselected.");

                // Select the checkbox again
                inputCheckbox.click();
                TestRunner.getTest().log(Status.PASS, "Tes Case Passed: Checkbox was re-selected for student.");
            } else {
                // Select the checkbox if it's not already selected
                inputCheckbox.click();
                TestRunner.getTest().log(Status.PASS, " Tes Case Passed: Checkbox was selected for student.");
            }
        }
    }

    public void DeleteAssignmentYesButton() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm in to click on Yes Button for Delete Assignment");
        System.out.println("I'm in to Delete Assignment for specific student");

        WebElement prompt = driver.findElement(By.xpath("//div[@role='dialog']"));
        WebElement promptFooter = prompt.findElement(By.xpath("//div[contains(@class,'btn-footer')]"));

        WebElement yesButton = promptFooter.findElement(By.xpath("//button[contains(text(), 'Yes')]"));
        System.out.println("Button text is: " + yesButton.getText());

        if (yesButton.isDisplayed() && yesButton.isEnabled()) {
            yesButton.click();
            TestRunner.getTest().log(Status.PASS, " Tes Case Passed: Yes Button is Click Successfully.");

        }else {
            System.out.println("Yes Button is not Enable Because Student is not selected");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Yes Button is Disable because No Student is selected ");
//            throw new RuntimeException("Yes Button is not Enable Because Student is not selected.");
        }
    }

    public void searchAssignmentThatIsDeleted(String assignmentName) throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm into Verify that Deleted Assignment Also Delete from GradeBook");
        System.out.println("I'm into Verify that Deleted Assignment Also Delete from GradeBook");


        WebElement search_box = driver.findElement(By.xpath("//div[contains(@class,'MuiOutlinedInput-root')]//input[@placeholder='Search by name or keyword']"));
        search_box.click();

        if (search_box.isDisplayed()) {
            search_box.sendKeys(assignmentName);
            TestRunner.getTest().log(Status.PASS, " Tes Case Passed: Assignment Name Search in Search box Successfully." + assignmentName);
            verifyAssignmentFoundOrNot();
        } else {

            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Search box not found on gradeBook Dashboard");
//            throw new RuntimeException("Search box not found on gradeBook Dashboard");
        }
    }

    public void verifyAssignmentFoundOrNot() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm into Verify that Deleted Assignment is Deleted Or Not");
        System.out.println("I'm into Verify that Deleted Assignment is Deleted Or Not");

        WebElement notFoundBox = driver.findElement(By.xpath("//div[@class='boxListNotFount']"));
        if (notFoundBox.isDisplayed()) {
            String notFoundMessage = notFoundBox.getText();
            String messageColor = notFoundBox.getCssValue("color");

            System.out.println("Message displayed: " + notFoundMessage);
            System.out.println("Message color: " + messageColor);

            Assert.assertTrue("Expected message not displayed.", notFoundMessage.contains("Assessment Not Found"));
            TestRunner.getTest().log(Status.INFO, "Delete Assignment also Deleted from GradeBook ");
            TestRunner.getTest().log(Status.PASS, "Testcase Passed   : 'Assessment Not Found' message is displayed correctly. Because Deleted Assignment not Present In GradeBook");
            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());

        } else {
            TestRunner.getTest().log(Status.FAIL, "Testcase Failed   : 'Assessment Not Found' message is not displayed. Delete Assessment Found in GradeBook");
//            throw new RuntimeException("Delete Assessment Found in GradeBook");
        }

    }


    // delete Assignment before student attempt

    public void NewAssignmentInOpenTab() throws InterruptedException{

        if (!panel_Assignments.isDisplayed()) {
            throw new NoSuchElementException("Assignments panel is not displayed");
        }

        WebElement searchBar = driver.findElement(By.xpath("//input[@placeholder='Search Assignment by Title']"));
        searchBar.clear();
        searchBar.click();
        searchBar.sendKeys(assignmentNameForCorrect.get()); // Enter assignment name
        searchBar.sendKeys(Keys.ENTER);
        Thread.sleep(3000);

        WebElement searchBtn= driver.findElement(By.xpath("//button[contains(@class,'MuiButtonBase-root MuiIconButton-root MuiIconButton-edgeStart')]"));
        searchBtn.click();
        System.out.println("Search Button Click Successfully");
        Thread.sleep(3000);

        // Wait for search results to load and get assignments from search results
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@aria-labelledby='simple-tab-2']")));
        Thread.sleep(2000);
        List<WebElement> totalAssignments = panel_Assignments.findElements(By.xpath(".//div[contains(@class, 'MuiGrid-container')]"));
        System.out.println("Total Assignments: " + totalAssignments.size());
        System.out.println("Attempting to find assignment: " + assignmentNameForCorrect.get());
        TestRunner.getTest().log(Status.INFO, "Looking for assignment: " + assignmentNameForCorrect.get());

        boolean assignmentFound = false;
        // Loop through filtered assignments to find the correct one
        for (WebElement assignment : totalAssignments) {
            WebElement assignmentNameElement = assignment.findElement(By.xpath(".//div[contains(@class, 'notranslate')]"));
            String assignmentName = assignmentNameElement.getText();
            System.out.println("Assignment Name: " + assignmentName);

            if (assignmentName.equals(assignmentNameForCorrect.get())) {
                System.out.println("Found assignment: " + assignmentName);
                assignmentFound = true;

                TestRunner.getTest().log(Status.PASS, "Successfully assignment Found: " + assignmentName);
                break;
            } else {
                System.out.println("Assignment not found: " + assignmentName);
            }
        }

        if (!assignmentFound) {
            System.out.println("Assignment not found : " + assignmentNameForCorrect.get());
            TestRunner.getTest().log(Status.FAIL, "Assignment not found in the list. Using search bar to find: " + assignmentNameForCorrect.get());
        }

    }

    public void SelectAssignmentForCorrectAnswersAndResume() throws InterruptedException , AWTException{
        if (!panel_Assignments.isDisplayed()) {
            throw new NoSuchElementException("Assignments panel is not displayed");
        }

        String assignmentNameForCorrect = CorrectAnswerExecutor_PF.assignmentNameForCorrect.get();
        System.out.println("Want to search assessment to attempt: " + assignmentNameForCorrect);
        TestRunner.getTest().log(Status.INFO, "Want to search assessment to attempt: " + assignmentNameForCorrect);

        System.out.println("Attempting to find assignment: " + assignmentNameForCorrect);
        TestRunner.getTest().log(Status.INFO, "Looking for assignment: " + assignmentNameForCorrect);

        WebElement searchBar = driver.findElement(By.xpath("//input[@placeholder='Search Assignment by Title']"));
        searchBar.clear();
        searchBar.click();
        searchBar.sendKeys(assignmentNameForCorrect); // Enter assignment name
        searchBar.sendKeys(Keys.ENTER); // Trigger search

        Thread.sleep(3000);
        WebElement searchBtn= driver.findElement(By.xpath("//button[contains(@class,'MuiButtonBase-root MuiIconButton-root MuiIconButton-edgeStart')]"));
        searchBtn.click();
        System.out.println("Search Button Click Successfully");
        Thread.sleep(3000);

        WebElement panelTabOpen = driver.findElement(By.xpath("//div[@aria-labelledby='simple-tab-2']"));
        wait.until(ExpectedConditions.visibilityOf(panelTabOpen));
        Thread.sleep(2000);
        List<WebElement> totalAssignments = panel_Assignments.findElements(By.xpath(".//div[contains(@class, 'MuiGrid-container')]"));
        System.out.println("Total Assignments: " + totalAssignments.size());

        for (WebElement assignment : totalAssignments) {
            WebElement assignmentNameElement = assignment.findElement(By.xpath(".//div[contains(@class, 'notranslate')]"));
            String assignmentName = assignmentNameElement.getText();
            System.out.println("Assignment Name: " + assignmentName);

            if (assignmentName.equals(assignmentNameForCorrect)) {
                System.out.println("Found assignment: " + assignmentName);
                try {
                    WebElement startOrResumeButton = assignment.findElement(By.xpath(".//div[@statustype='START' or @statustype='RESUME']"));
                    startOrResumeButton.click();
                    TestRunner.getTest().log(Status.PASS, "Successfully started assignment: " + assignmentName);
                    System.out.println("Assignment started");
                    Thread.sleep(3000);
                    studentExecutor.handleTeacherInstructionsDialog();
                    AttemptAssignmentForResumeStatusWithCorrectAnswers();
                    Thread.sleep(2000);
                } catch (NoSuchElementException e) {
                    System.out.println("START/RESUME button not found for assignment: " + assignmentName);
                    return;
                }

                refreshPage();
                Thread.sleep(3000);
                studentExecutor.dialogBox_ImpAnnouncement();

                try {
                    WebElement tabOpenPanel = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[@class='ScrollbarsCustom-Content'])[2]")));
                    WebElement tabOpenAssignments = driver.findElement(By.xpath("//div[@aria-labelledby='simple-tab-2']"));

                    List<WebElement> totalAssignment = tabOpenAssignments.findElements(By.xpath(".//div[contains(@class, 'notranslate')]"));
                    System.out.println("Total Assignments after refresh: " + totalAssignment.size());

                    if (!totalAssignment.isEmpty()) {
                        for (WebElement assignmentText : totalAssignment) {
                            System.out.println("Assignment Text: " + assignmentText.getText());
                        }
                    }
                } catch (TimeoutException te) {
                    System.out.println("Failed to load assignments after refresh. Retrying...");
                }
                break;
            } else {
                System.out.println("Assignment not found: " + assignmentName);
            }
        }
    }

    private void refreshPage() {
        driver.navigate().to(baseUrl);
    }

    public void AttemptAssignmentForResumeStatusWithCorrectAnswers() throws InterruptedException, AWTException {
        if (!isPaginationDisplayed()) {
//            studentExecutor.AssignmentSubmitAsCompleted();
            return;
        }

        try {
            List<WebElement> questionButtons = nav_Pagination.findElements(By.xpath("//button[contains(@aria-label, 'Go to page')]"));

            for (WebElement questionButton : questionButtons) {
                String questionText = questionButton.getText();
                System.out.println("Question: " + questionText);
                TestRunner.getTest().log(Status.INFO, "Total Questions: " + questionText);
            }


            TestRunner.startTest("Attempt assignment with all correct answers");
            while (btn_NavNextPage.isEnabled()) {
                Thread.sleep(2000);
                correctAnswerExecutor_pf.AttemptAssignmentWithCorrectAnswers();
                btn_NavNextPage.click();
                Thread.sleep(2000);
            }

            System.out.println("Assignment attempted with all correct answers. Now Resume that assignment");
            TestRunner.getTest().log(Status.INFO, "Assignment attempted with all correct answers. Now Resume that assignment");

            WebElement dialogIframe = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("lesson-player-ifram")));
            driver.switchTo().frame(dialogIframe);

            WebElement closeReview = driver.findElement(By.xpath("//button[normalize-space()='Close Review']"));

            if (closeReview.isDisplayed()){
//                helper.scrollToElement(driver,closeReview);
                closeReview.click();
                TestRunner.getTest().log(Status.PASS, "Test Case Passed :Close Review Button Found and click successfully " );
                TestRunner.getTest().log(Status.INFO, "Assignment attempted with all correct answers. Now Resume");
            }else {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed :Close Review Button not Found" );
//                throw new RuntimeException("Close Review Button not Found");
            }

        } catch (NoSuchElementException | ElementNotInteractableException | TimeoutException e) {
            System.out.println("No Question found.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : No Question found or Question not visible");
        }
    }

    private boolean isPaginationDisplayed() {
        try {
            return nav_Pagination.isDisplayed();
        } catch (NoSuchElementException | ElementNotInteractableException | TimeoutException e) {
            return false;
        }
    }

    // Assignment Delete for All students


    public void AssignmentDeleteForAllStudents() throws InterruptedException {
        try {
            TestRunner.getTest().log(Status.INFO, "Starting Assignment Deletion for All Students");
            System.out.println("Starting Assignment Deletion for All Students");

            WebElement prompt = driver.findElement(By.xpath("//div[@role='dialog']"));

            // Get Assignment Name
            WebElement headerAssignmentText = prompt.findElement(By.xpath("//div[contains(@class, 'header-student')]"));
            String assignmentName = headerAssignmentText.getText();
            System.out.println("Assignment Name is: " + assignmentName);
            TestRunner.getTest().log(Status.INFO, "Assignment Name is: " + assignmentName);

            // Get total pages of students for deletion
            List<WebElement> studentsPagination = driver.findElements(By.xpath("//button[contains(@aria-label, 'Go to page')]"));
            for (WebElement pageButton : studentsPagination) {
                String pageNumber = pageButton.getText();
                System.out.println("Pages: " + pageNumber);
                TestRunner.getTest().log(Status.INFO, "Total Pages: " + pageNumber);
            }

            TestRunner.startTest("Delete Assignment for all students");

            boolean hasNextPage = true;
            while (hasNextPage) {
                getAllStudentsFromPagination();

                try {
                    WebElement btnNextPage = driver.findElement(By.xpath("//button[@aria-label='Go to next page']"));
                    if (btnNextPage.isEnabled()) {
                        btnNextPage.click();
                        TestRunner.getTest().log(Status.INFO, "Navigating to the next page.");
                        Thread.sleep(2000);
                    } else {
                        hasNextPage = false;
                    }
                } catch (NoSuchElementException e) {
                    hasNextPage = false;
                    TestRunner.getTest().log(Status.INFO, "Reached the last page.");
                }
            }
        } catch (NoSuchElementException e) {
            TestRunner.getTest().log(Status.FAIL, "Error occurred: " + e.getMessage());
            System.out.println("Element not found: " + e.getMessage());
        }
    }

    public void getAllStudentsFromPagination() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Getting All Students on the Current Page");
        System.out.println("Getting All Students on the Current Page");
        try {
            WebElement prompt = driver.findElement(By.xpath("//div[@role='dialog']"));

            // Fetching the student rows
            WebElement tableStudent = prompt.findElement(By.xpath("//div[@class='studentTable']//table"));
            List<WebElement> rowsStudents = tableStudent.findElements(By.xpath(".//tbody/tr"));
            int totalStudents = rowsStudents.size();
            System.out.println("Total students on this page: " + totalStudents);
            TestRunner.getTest().log(Status.INFO, "Total students on this page: " + totalStudents);

            // Log and interact with each student
            for (WebElement rowStudent : rowsStudents) {
                String studentInfo = rowStudent.getText();
                System.out.println("Student row: " + studentInfo);
                TestRunner.getTest().log(Status.INFO, "Student Name: " + studentInfo);

                WebElement inputCheckbox = rowStudent.findElement(By.xpath(".//input[@type='checkbox']"));
                if (inputCheckbox.isSelected()) {
                    inputCheckbox.click();
                    TestRunner.getTest().log(Status.INFO, "Checkbox was selected, deselecting it.");
                }

                // Select checkbox
                inputCheckbox.click();
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: Checkbox was selected/re-selected for student.");
            }
        } catch (NoSuchElementException e) {
            TestRunner.getTest().log(Status.FAIL, "Error occurred while fetching students: " + e.getMessage());
            System.out.println("Element not found: " + e.getMessage());
        }
    }



    // UnSubmit Assignment

    public void SearchAssignmentForUnSubmit(String assignmentName) throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into Search the Assignment That I want to  UnSubmit");
        System.out.println("I'm into Search the Assignment That I want to  UnSubmit");


        WebElement assignmentTable = wait.until(ExpectedConditions.visibilityOf(studentAssignmentTable));

        List<WebElement> assignmentContainers = assignmentTable.findElements(By.xpath(".//thead//tr//th"));
        System.out.println("Total Assignment Names are: " + assignmentContainers.size());

        for (int i = 0; i < assignmentContainers.size(); i++) {
            WebElement assignment = assignmentContainers.get(i);
            String assignmentsName = assignment.getText();
            System.out.println("Assignment Name: " + assignmentsName);

            if (assignmentsName.equalsIgnoreCase(assignmentName)) {
                System.out.println("Found assignment: " + assignmentsName);

                boolean staleElement = true;
                while (staleElement) {
                    try {
                        // Re-locate the assignment element to avoid stale element issues
                        assignmentContainers = assignmentTable.findElements(By.xpath(".//thead//tr//th"));
                        assignment = assignmentContainers.get(i);

                        // Wait until the assignment is clickable
                        wait.until(ExpectedConditions.elementToBeClickable(assignment));
                        assignment.click();
                        staleElement = false; // Break the loop as element is successfully clicked

                        System.out.println("Assignment found");
                        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Assignment found successfully " + assignmentsName);

                        // Perform other actions
                        Thread.sleep(2000);
//                        clickGradeButton();
                        TestRunner.getTest().log(Status.INFO, "I'm in Click on UnSubmit Button");
                        ClickUnSubmitButton();
                        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Click on UnSubmit button successfully " + assignmentsName);

                    } catch (StaleElementReferenceException e) {
                        System.out.println("StaleElementReferenceException occurred. Retrying...");
                        staleElement = true; // Continue the loop to re-locate and retry
                    } catch (NoSuchElementException e) {
                        TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Delete button not found for assignment: " + assignmentName);
                        return;
                    }
                }
                break; // Exit loop once the desired assignment is found and processed
            }
        }
    }

    public void ClickUnSubmitButton() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm into Click on UnSubmit Button");
        System.out.println("I'm into Click on UnSubmit Button");

        List<WebElement> listAssignment = driver.findElements(By.xpath("//ul[@role='menu']"));

        for (WebElement option : listAssignment) {
            List<WebElement> buttons = option.findElements(By.tagName("button"));

            for (WebElement button : buttons) {
                String buttonText = button.getText().trim();

                if (buttonText.equals("Unsubmit") && button.isEnabled() && button.isDisplayed()) {
                    button.click();
                    System.out.println("Clicked on UnSubmit button.");
                    return;
                }
            }
        }
    }

    public void AssignmentUnSubmitForAllStudents() throws InterruptedException{

        try {
            TestRunner.getTest().log(Status.INFO, "Starting Assignment UnSubmit for All Students");
            System.out.println("Starting Assignment UnSubmit for All Students");

            WebElement prompt = driver.findElement(By.xpath("//div[@role='dialog']"));

            // Get Assignment Name
            WebElement headerAssignmentText = prompt.findElement(By.xpath("//div[contains(@class, 'header-student')]"));
            String assignmentName = headerAssignmentText.getText();
            System.out.println("Assignment Name is: " + assignmentName);
            TestRunner.getTest().log(Status.INFO, "Assignment Name is: " + assignmentName);

            // Get total pages of students for deletion
            List<WebElement> studentsPagination = driver.findElements(By.xpath("//button[contains(@aria-label, 'Go to page')]"));
            for (WebElement pageButton : studentsPagination) {
                String pageNumber = pageButton.getText();
                System.out.println("Pages: " + pageNumber);
                TestRunner.getTest().log(Status.INFO, "Total Pages: " + pageNumber);
            }

            TestRunner.startTest("UnSubmit Assignment for all students");

            boolean hasNextPage = true;
            while (hasNextPage) {
                getAllStudentsFromPagination();

                try {
                    WebElement btnNextPage = driver.findElement(By.xpath("//button[@aria-label='Go to next page']"));
                    if (btnNextPage.isEnabled()) {
                        btnNextPage.click();
                        TestRunner.getTest().log(Status.INFO, "Navigating to the next page.");
                        Thread.sleep(2000);
                    } else {
                        hasNextPage = false;
                    }
                } catch (NoSuchElementException e) {
                    hasNextPage = false;
                    TestRunner.getTest().log(Status.INFO, "Reached the last page.");
                }
            }
        } catch (NoSuchElementException e) {
            TestRunner.getTest().log(Status.FAIL, "Error occurred: " + e.getMessage());
            System.out.println("Element not found: " + e.getMessage());
        }
    }

    // Assignment UnSubmit For Specific Student
//    public void AssignmentUnSubmitForSpecificStudent() throws InterruptedException{
//        TestRunner.getTest().log(Status.INFO, "I'm into UnSubmit Assignment for Specific Student");
//        System.out.println("I'm into UnSubmit Assignment for Specific Student");
//
//        WebElement prompt = driver.findElement(By.xpath("//div[@role='dialog']"));
//
//        WebElement headerAssignmentText = prompt.findElement(By.xpath("//div[contains(@class, 'header-student')]"));
//        System.out.println("Assignment Name is: " + headerAssignmentText.getText());
//        TestRunner.getTest().log(Status.INFO, "Assignment Name is: " + headerAssignmentText.getText());
//
//        WebElement tableStudent = prompt.findElement(By.xpath("//div[@class='studentTable']//table"));
//
//        List<WebElement> rowsStudents = tableStudent.findElements(By.xpath(".//tbody/tr"));
//        int totalStudents = rowsStudents.size();
//        System.out.println("Total students: " + totalStudents);
//
//        String targetStudentName = "Mary Johansen"; // Replace with the student name you want to match
//
//        for (WebElement rowStudent : rowsStudents) {
//            // Get the student's name from the second column (td[2])
//            WebElement studentNameElement = rowStudent.findElement(By.xpath(".//td[2]"));
//            String studentName = studentNameElement.getText();
//
//            System.out.println("Student Name: " + studentName);
//            TestRunner.getTest().log(Status.INFO, "Student Name: " + studentName);
//
//            // If the student name matches the target name
//            if (studentName.equalsIgnoreCase(targetStudentName)) {
//                WebElement inputCheckbox = rowStudent.findElement(By.xpath(".//input[@type='checkbox']"));
//
//                // If the checkbox is selected, deselect it and select it again
//                if (inputCheckbox.isSelected()) {
//                    // Deselect the checkbox
//                    inputCheckbox.click();
//                    TestRunner.getTest().log(Status.INFO, "Checkbox was selected, so it was deselected.");
//
//                    // Select the checkbox again
//                    inputCheckbox.click();
//                    TestRunner.getTest().log(Status.PASS, "Test Case Passed: Checkbox was re-selected for student " + studentName);
//                } else {
//                    // Select the checkbox if it's not already selected
//                    inputCheckbox.click();
//                    TestRunner.getTest().log(Status.PASS, "Test Case Passed: Checkbox was selected for student " + studentName);
//                }
//                break; // Exit loop once the target student is found
//            }
//        }
//
//
//    }



    public void AssignmentUnSubmitForSpecificStudent() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into UnSubmit Assignment for Specific Student");
        System.out.println("I'm into UnSubmit Assignment for Specific Student");

        try {
            WebElement prompt = driver.findElement(By.xpath("//div[@role='dialog']"));

            WebElement headerAssignmentText = prompt.findElement(By.xpath("//div[contains(@class, 'header-student')]"));
            System.out.println("Assignment Name is: " + headerAssignmentText.getText());
            TestRunner.getTest().log(Status.INFO, "Assignment Name is: " + headerAssignmentText.getText());

            WebElement tableStudent = prompt.findElement(By.xpath("//div[@class='studentTable']//table"));

            List<WebElement> rowsStudents = tableStudent.findElements(By.xpath(".//tbody/tr"));
            int totalStudents = rowsStudents.size();
            System.out.println("Total students: " + totalStudents);

            String targetStudentName = "Mary Johansen"; // Replace with the student name you want to match
            boolean studentFound = false;

            for (WebElement rowStudent : rowsStudents) {
                // Get the student's name from the second column (td[2])
                WebElement studentNameElement = rowStudent.findElement(By.xpath(".//td[2]"));
                String studentName = studentNameElement.getText();

                System.out.println("Student Name: " + studentName);
                TestRunner.getTest().log(Status.INFO, "Student Name: " + studentName);

                // If the student name matches the target name
                if (studentName.equalsIgnoreCase(targetStudentName)) {
                    studentFound = true; // Mark the student as found
                    WebElement inputCheckbox = rowStudent.findElement(By.xpath(".//input[@type='checkbox']"));

                    // If the checkbox is selected, deselect it and select it again
                    if (inputCheckbox.isSelected()) {
                        // Deselect the checkbox
                        inputCheckbox.click();
                        TestRunner.getTest().log(Status.INFO, "Checkbox was selected, so it was deselected.");

                        // Select the checkbox again
                        inputCheckbox.click();
                        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Checkbox was re-selected for student " + studentName);
                    } else {
                        // Select the checkbox if it's not already selected
                        inputCheckbox.click();
                        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Checkbox was selected for student " + studentName);
                    }
                    break; // Exit loop once the target student is found
                }
            }

            // If the student is not found, throw an exception
            if (!studentFound) {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Student " + targetStudentName + " is not found");
                throw new Exception("Student not found: " + targetStudentName);
            }

        } catch (Exception e) {
            // Log the error and fail the test if the student is not found or any other issue occurs
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: " + e.getMessage());
            throw new AssertionError("Test Case Failed: " + e.getMessage());
        }
    }



}