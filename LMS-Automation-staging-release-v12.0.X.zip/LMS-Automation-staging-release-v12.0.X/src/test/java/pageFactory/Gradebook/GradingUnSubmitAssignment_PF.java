package pageFactory.Gradebook;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class GradingUnSubmitAssignment_PF {

    WebDriverWait wait;
    WebDriver driver;
    Helper helper;

    private static String assignmentName;

    @FindBy(xpath = "//div[contains(@class, 'AssignmentWrapper')]")
    WebElement card_MyAssignment;

    @FindBy(xpath = "(//div[@class='ScrollbarsCustom-Content'])[2]")
    WebElement panel_Assignments;

    public GradingUnSubmitAssignment_PF(WebDriver driver){
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        helper = new Helper();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
    }

    public void selectQuizForUnSubmit() throws InterruptedException {
        Thread.sleep(1000);
        WebElement divQuiz = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class, 'StudentListingAndTableWrapper')]")));
        List<WebElement> totalQuizzes = divQuiz.findElements(By.xpath("//div[contains(@class, 'QuizAverage')]"));

        int numberOfQuizzes = totalQuizzes.size();
        System.out.println("Number of Quizzes: " + numberOfQuizzes);

        List<String> excludedQuizTexts = Arrays.asList("CLASS AVERAGE", "DATE RANGE AVERAGE", "EXAM AVERAGE", "HOMEWORK AVERAGE", "PRACTICE AVERAGE", "QUIZ AVERAGE");

        for (WebElement quiz : totalQuizzes) {
            String quizText = quiz.getText().trim();
            System.out.println("Quiz text is: " + quizText);

            if (!excludedQuizTexts.contains(quizText)) {
                WebElement theadQuiz = quiz.findElement(By.xpath(".//table/thead"));
                List<WebElement> quizzes = theadQuiz.findElements(By.xpath(".//span[contains(@class,'vertical-text-container')]"));

                for (WebElement selectedQuiz : quizzes) {
                    String selectedQuizText = selectedQuiz.getText().trim();
                    if (!excludedQuizTexts.contains(selectedQuizText)) {
                        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", selectedQuiz);
                        Thread.sleep(1000);
                        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", selectedQuiz);

                        System.out.println("Text of Clicked Quiz: " + selectedQuizText);

                        if (isUnSubmitButtonClickable()) {
                            System.out.println("Unsubmit button is clickable.");
                            clickUnSubmitButton();
                            return; // Break out of the loop and return
                        } else {
                            System.out.println("Unsubmit button is not clickable, clicking next quiz.");
                            break; // Continue to the next quiz
                        }
                    }
                }
            }
        }
    }

    private boolean isUnSubmitButtonClickable() {
        List<WebElement> listAssignment = driver.findElements(By.xpath("//ul[@role='menu']"));

        for (WebElement option : listAssignment) {
            List<WebElement> buttons = option.findElements(By.tagName("li"));

            for (WebElement button : buttons) {
                String buttonText = button.getText().trim();
                boolean isEnabled = button.isEnabled();
                boolean isDisplayed = button.isDisplayed();

                System.out.println("Button Text: " + buttonText);
                System.out.println("Is Enabled: " + isEnabled);
                System.out.println("Is Displayed: " + isDisplayed);

                if (buttonText.equals("Unsubmit") && isEnabled && isDisplayed) {
                    return true;
                }
            }
        }

        return false;
    }


    private void clickUnSubmitButton() {
        List<WebElement> listAssignment = driver.findElements(By.xpath("//ul[@role='menu']"));

        for (WebElement option : listAssignment) {
            List<WebElement> buttons = option.findElements(By.tagName("button"));

            for (WebElement button : buttons) {
                String buttonText = button.getText().trim();

                if (buttonText.equals("Unsubmit") && button.isEnabled() && button.isDisplayed()) {
                    button.click();
                    System.out.println("Clicked on Unsubmit button.");
                    return;
                }
            }
        }
    }

    public void verifyPrompt() throws InterruptedException{
        Thread.sleep(2000);

        WebElement prompt = driver.findElement(By.xpath("//div[@role='dialog']"));
        boolean isDisplayed = prompt.isDisplayed();
        Assert.assertTrue("Prompt is not displayed.", isDisplayed);

        WebElement promptHeader = prompt.findElement(By.tagName("h2"));
        String headerText = promptHeader.getText();
        System.out.println("Prompt header text is: " + headerText);
    }

    public String getAssignmentName() {
        if (assignmentName == null) {
            try {
                WebElement prompt = driver.findElement(By.xpath("//div[@role='dialog']"));
                WebElement headerAssignmentText = prompt.findElement(By.xpath(".//div[contains(@class, 'header-student')]"));
                System.out.println("Assignment header: " + headerAssignmentText.getText());
                WebElement assignmentNamePrompt = headerAssignmentText.findElement(By.xpath(".//span[contains(@class, 'ListItemText-title')]"));
                assignmentName = assignmentNamePrompt.getText();
                System.out.println("Assignment Name is: " + assignmentName);
            } catch (NoSuchElementException e) {
                System.out.println("Dialog element not found.");
            }
//            WebElement prompt = driver.findElement(By.xpath("//div[@role='dialog']"));
//            WebElement headerAssignmentText = prompt.findElement(By.xpath(".//div[contains(@class, 'header-student')]"));
//            System.out.println("Assignment header: " + headerAssignmentText.getText());
//            WebElement assignmentNamePrompt = headerAssignmentText.findElement(By.xpath(".//span[contains(@class, 'ListItemText-title')]"));
//            assignmentName = assignmentNamePrompt.getText();
//            System.out.println("Assignment Name is: " + assignmentName);

        }
        return assignmentName;
    }

    public void UnSubmitAssignmentForAllStudent() {
        WebElement prompt = driver.findElement(By.xpath("//div[@role='dialog']"));

        WebElement headerAssignmentText = prompt.findElement(By.xpath(".//div[contains(@class, 'header-student')]"));
        System.out.println("Assignment header: " + headerAssignmentText.getText());

        WebElement assignmentNamePrompt = headerAssignmentText.findElement(By.xpath(".//span[contains(@class, 'ListItemText-title')]"));
        String assignmentName = assignmentNamePrompt.getText();
        System.out.println("Assignment Name is: " + assignmentName);

        WebElement tableStudent = prompt.findElement(By.xpath("//div[@class='studentTable']//table"));

        WebElement rowsStudentTableHeader = tableStudent.findElement(By.xpath(".//thead/tr"));

        System.out.println("Student table header: " + rowsStudentTableHeader.getText());

        WebElement headerCheckbox = rowsStudentTableHeader.findElement(By.xpath(".//input[@type='checkbox']"));
        headerCheckbox.click();

        WebElement promptFooter = prompt.findElement(By.xpath("//div[contains(@class,'btn-footer')]"));

        WebElement yesButton = promptFooter.findElement(By.xpath("//button[contains(text(), 'Yes')]"));
        System.out.println("Button text is: " + yesButton.getText());
        yesButton.click();

        // Simulate pressing the ESC key
//        Actions actions = new Actions(driver);
//        actions.sendKeys(Keys.ESCAPE).build().perform();

    }

    public void UnSubmitAssignmentForParticularStudent() throws InterruptedException{
        WebElement prompt = driver.findElement(By.xpath("//div[@role='dialog']"));

        WebElement headerAssignmentText = prompt.findElement(By.xpath("//div[contains(@class, 'header-student')]"));
        System.out.println("Assignment Name is: " + headerAssignmentText.getText());

        WebElement tableStudent = prompt.findElement(By.xpath("//div[@class='studentTable']//table"));

        List<WebElement> rowsStudents = tableStudent.findElements(By.xpath(".//tbody/tr"));
        int totalStudents = rowsStudents.size();
        System.out.println("Total students: " + totalStudents);

        for (WebElement rowStudent : rowsStudents) {
            System.out.println("Student row: " + rowStudent.getText());
        }

        Random rand = new Random();
        int randomStudentIndex = rand.nextInt(totalStudents);

        WebElement randomStudentRow = rowsStudents.get(randomStudentIndex);
        WebElement inputCheckbox = randomStudentRow.findElement(By.xpath(".//input[@type='checkbox']"));
        inputCheckbox.click();

        Thread.sleep(1000);
        WebElement promptFooter = prompt.findElement(By.xpath("//div[contains(@class,'btn-footer')]"));

        WebElement yesButton = promptFooter.findElement(By.xpath("//button[contains(text(), 'Yes')]"));
        System.out.println("Button text is: " + yesButton.getText());
        yesButton.click();

        // Simulate pressing the ESC key
//        Actions actions = new Actions(driver);
//        actions.sendKeys(Keys.ESCAPE).build().perform();

    }

    public void searchUnSubmittedAssignmentIntoStudentPanel() throws InterruptedException {
        String searchAssignmentName = assignmentName;
        System.out.println("Search assignment name: " + searchAssignmentName);

        if (panel_Assignments.isDisplayed()){
            WebElement tab_Assignment = card_MyAssignment.findElement(By.xpath("//div[@aria-label='wrapped label tabs example']"));

            List<WebElement> AssignmentTabs = tab_Assignment.findElements(By.xpath(".//button"));
            System.out.println("Total tabs: " + AssignmentTabs.size());

            boolean assignmentFound = false;

            for (WebElement AssignmentTab : AssignmentTabs) {
                String tabText = AssignmentTab.getText();
                String[] tabParts = tabText.split(":");
                String tabName = tabParts[0].trim();
                System.out.println("Assignment Tab Text: " + tabName);

                AssignmentTab.click();

                Thread.sleep(2000);

//                List<WebElement> tabPanels = panel_Assignments.findElements(By.xpath(".//div[@id='simple-tabpanel-2']"));
                List<WebElement> tabPanels = panel_Assignments.findElements(By.xpath(".//div[@role='tabpanel']"));
                System.out.println("Total Assignments into panel: " + tabPanels.size());
                for (WebElement tabPanel : tabPanels) {
                    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[@class='ScrollbarsCustom-Content'])[2]")));
                    Thread.sleep(1000);
                    String panelText = tabPanel.getText();
                    System.out.println("Panel Text: " + panelText);

                    if (tabName.equals("Open")) {
                        if (panelText.contains(searchAssignmentName)) {
                            System.out.println("Test case passed: Resubmitted assignment shows into Open tab");
                            assignmentFound = true;
                        }
                    } else {
                        if (panelText.contains(searchAssignmentName)) {
                            System.out.println("Test case passed but Assignment shows into '" + tabName + "' tab ");
                            assignmentFound = true;
                        }
                    }
                }

            }

            if (!assignmentFound) {
                System.out.println("Test case passed: Assignment not found in any panel");
            }
        }
    }

}
