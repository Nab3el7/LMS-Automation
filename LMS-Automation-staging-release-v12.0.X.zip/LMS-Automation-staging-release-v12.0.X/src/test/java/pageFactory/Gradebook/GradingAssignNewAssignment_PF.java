package pageFactory.Gradebook;

import StepDefinitions.Configurations;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Assignmment.CorrectAnswerExecutor_PF;
import pageFactory.MyContent.AssignAssessment_PF;

import java.time.Duration;
import java.util.List;
import java.util.Random;

public class GradingAssignNewAssignment_PF {
    WebDriverWait wait;
    WebDriver driver;
    JavascriptExecutor js;
    Random random;
    AssignAssessment_PF assignAssessment;
    CorrectAnswerExecutor_PF correctAnswerExecutor;


    @FindBy(xpath = "//button[normalize-space()='Assign New']")
    WebElement buttonAssignNew;

    @FindBy(xpath = "//div[@class='tabelbodydata-Container']//table//tbody")
    WebElement tableAssignNew;

    @FindBy(xpath = "//button[normalize-space()='Next']")
    WebElement buttonNext;

    public GradingAssignNewAssignment_PF(WebDriver driver) {
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        js = (JavascriptExecutor) driver;
        random = new Random();
        assignAssessment = new AssignAssessment_PF(driver);
        correctAnswerExecutor = new CorrectAnswerExecutor_PF(driver);
    }

    public void ClickOnAssignNewAssignmentButton(){
        wait.until(ExpectedConditions.elementToBeClickable(buttonAssignNew));
        buttonAssignNew.click();
        TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  Assign New button Clicked Successfully");

    }

    public void SelectAssignmentInShowAllTab() {
        WebElement tableNewAssignment = wait.until(ExpectedConditions.elementToBeClickable(tableAssignNew));
        List<WebElement> selectAssignmentCheckBoxes = tableNewAssignment.findElements(By.xpath(".//td[contains(@class,'checkboxSelectionTableCell')]//input"));

        System.out.println("Total assignments are: " + selectAssignmentCheckBoxes.size());

        if (!selectAssignmentCheckBoxes.isEmpty()) {
            int randomAssignment = random.nextInt(selectAssignmentCheckBoxes.size());
            WebElement randomCheckbox = selectAssignmentCheckBoxes.get(randomAssignment);

            js.executeScript("arguments[0].click();", randomCheckbox);
            System.out.println("A random checkbox has been selected.");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed   :   Assignment Select Successfully ");

        } else {
            System.out.println("No checkboxes found.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  No Assignment Found to Select ");

        }
    }

    public void ClickOnNextButton() {
        wait.until(ExpectedConditions.elementToBeClickable(buttonNext));
        if (buttonNext.isDisplayed() && buttonNext.isEnabled()) {
            buttonNext.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  Next button clicked successfully");

        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  Next Button not Display or clickable ");

        }
    }

}
