package pageFactory.Gradebook;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Assignmment.NegativeTestCasesAssignmentRelease_PF;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import static pageFactory.StudentsModule.ReadNewStdInfo_PF.updatedName;

public class GradeBookStudent_PF {
    WebDriverWait wait;
    WebDriver driver;
    Helper helper;

    @FindBy(xpath = "//input[@name='stdConfirmPassword']")
    WebElement edt_NewStdConfirmPassword;

    @FindBy(xpath = "//input[@name='stdPassword']")
    WebElement edt_NewStdPassword;

    @FindBy(xpath = "//label[normalize-space()='Select Grade']/parent::div")
    WebElement edt_select_grade;

    private Random random = new Random();

    public static String studentGrade;
    public static String selectedGrade;


    public  GradeBookStudent_PF(WebDriver driver){
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        helper = new Helper();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
    }


    public void GetStudentListAndClickIcon() throws InterruptedException {
        Thread.sleep(5000);

        WebElement searchBar = driver.findElement(By.xpath("//input[@placeholder='Search Student']"));

        if (searchBar.isDisplayed()) {

//            String specificStudentName = "RAB STD";
            searchBar.clear();
            searchBar.sendKeys(updatedName);
            Thread.sleep(2000);

            List<WebElement> listStudent = driver.findElements(By.xpath("//div[contains(@class, 'item undefined')]"));

            boolean isStudentFound = false;

            for (WebElement student : listStudent) {
                String studentName = student.getText().trim();
                System.out.println("Student Name is: " + studentName);
                TestRunner.getTest().log(Status.INFO, "Student Name is: " + studentName);

                if (studentName.contains(updatedName)) {
                    System.out.println("Specific Student '" + updatedName + "' is found in the list.");
                    TestRunner.getTest().log(Status.INFO, "Specific Student '" + updatedName + "' is found in the list.");
                    TestRunner.getTest().log(Status.PASS, "Testcase Passed   : Student Name is found in the list successfully");


                    WebElement icon = student.findElement(By.xpath("//div[contains(@class,'item undefined')]//div[contains(@class, 'AvatarsWithDescriptionWrapper')]/following-sibling::img"));

                    if (icon.isDisplayed()) {
                        icon.click();
//                        logger.info("Test Case Passed: Icon clicked successfully for student {}", specificStudentName);
                        TestRunner.getTest().log(Status.PASS, "Testcase Passed   : Icon clicked successfully for student " +  updatedName);

                    } else {
//                        logger.warn("Test Case Failed: Icon not displayed for student {}", specificStudentName);
                        TestRunner.getTest().log(Status.FAIL, "Testcase Failed   : Icon not Display for student " +  updatedName);
//                        throw new RuntimeException("Icon not displayed for student " + updatedName);
                    }

                    isStudentFound = true;
                    break;
                }
            }

            if (!isStudentFound) {
                System.out.println("Specific Student '" + updatedName + "' is not found in the list.");
//                logger.warn("Test Case Failed: Specific student '{}' is not found in the list.", specificStudentName);
                TestRunner.getTest().log(Status.FAIL, "Testcase Failed   : Specific student "+ updatedName +  "is not found in the list ");
//                throw new RuntimeException("Specific student '" + updatedName + "' is not found in the list.");
            }
        } else {
//            logger.warn("Test Case Failed: Search bar is not displayed.");
            TestRunner.getTest().log(Status.FAIL, "Testcase Failed   :  Search bar is not displayed.");
//            throw new RuntimeException("Search bar is not displayed.");
        }

    }

    public void GetStudentFromGradeBookAndClickIcon() throws InterruptedException{

        WebElement searchBar = driver.findElement(By.xpath("//input[@placeholder='Search Student']"));

        if (searchBar.isDisplayed()) {

            String specificStudentName = "RAB STD";
            searchBar.clear();
            searchBar.sendKeys(specificStudentName);
//            WebDriverWait wait = new WebDriverWait(driver, 20);


            List<WebElement> listStudent = driver.findElements(By.xpath("//div[contains(@class, 'item undefined')]"));

            boolean isStudentFound = false;

            for (WebElement student : listStudent) {
                String studentName = student.getText().trim();
                System.out.println("Student Name is: " + studentName);
                TestRunner.getTest().log(Status.INFO, "Student Name is: " + studentName);

                if (studentName.equals(specificStudentName)) {
                    System.out.println("Specific Student '" + specificStudentName + "' is found in the list.");
                    TestRunner.getTest().log(Status.INFO, "Specific Student '" + specificStudentName + "' is found in the list.");
                    TestRunner.getTest().log(Status.PASS, "Testcase Passed   : Student Name is found in the list successfully");


                    WebElement icon = student.findElement(By.xpath("//div[contains(@class,'item undefined')]//div[contains(@class, 'AvatarsWithDescriptionWrapper')]/following-sibling::img"));

                    if (icon.isDisplayed()) {
                        icon.click();
//                        logger.info("Test Case Passed: Icon clicked successfully for student {}", specificStudentName);
                        TestRunner.getTest().log(Status.PASS, "Testcase Passed   : Icon clicked successfully for student " +  specificStudentName);

                    } else {
//                        logger.warn("Test Case Failed: Icon not displayed for student {}", specificStudentName);
                        TestRunner.getTest().log(Status.FAIL, "Testcase Failed   : Icon not Display for student " +  specificStudentName);
//                        throw new RuntimeException("Icon not displayed for student " + specificStudentName);
                    }

                    isStudentFound = true;
                    break;
                }
            }

            if (!isStudentFound) {
                System.out.println("Specific Student '" + specificStudentName + "' is not found in the list.");
//                logger.warn("Test Case Failed: Specific student '{}' is not found in the list.", specificStudentName);
                TestRunner.getTest().log(Status.FAIL, "Testcase Failed   : Specific student "+ specificStudentName +  "is not found in the list ");
//                throw new RuntimeException("Specific student '" + specificStudentName + "' is not found in the list.");
            }
        } else {
//            logger.warn("Test Case Failed: Search bar is not displayed.");
            TestRunner.getTest().log(Status.FAIL, "Testcase Failed   :  Search bar is not displayed.");
//            throw new RuntimeException("Search bar is not displayed.");
        }


    }


    public void StudentInfoDialogueBox () throws InterruptedException{
          WebElement dialogueBox= driver.findElement(By.xpath("//div[@aria-labelledby='customized-dialog-title']"));
          if (dialogueBox.isDisplayed()){

              WebElement studentInfo = dialogueBox.findElement(By.xpath("//div[contains(@class, 'imageWithContent')]"));

              String fullText = studentInfo.getText().trim();
              System.out.println("Full Text: " + fullText);
              TestRunner.getTest().log(Status.INFO, "Student Information Full Text: " + fullText);

              studentGrade = studentInfo.findElement(By.xpath(".//span[2]")).getText().trim();
              System.out.println("Student Grade is: " + studentGrade);
              TestRunner.getTest().log(Status.INFO, "Student Garde Select " + studentGrade);
              TestRunner.getTest().log(Status.PASS, "Test Case Passed   : Student Grade Get successfully");


          }else {
              TestRunner.getTest().log(Status.FAIL, "Testcase Failed   :  Specific student Dialogue box not appear./ Grade not found on ");
//              throw new RuntimeException("Specific student Dialogue box not appear.");
          }
    }

    public void EnterPassword() throws InterruptedException{
        edt_NewStdPassword.click();
        ((JavascriptExecutor) driver).executeScript("arguments[0].value='';", edt_NewStdPassword);
        edt_NewStdPassword.sendKeys("Fltester22");
        TestRunner.getTest().log(Status.PASS, "Test Case Passed   : Password  Enter successfully");

    }

    public void EnterConfirmPassword() throws InterruptedException{
        edt_NewStdConfirmPassword.click();
        ((JavascriptExecutor) driver).executeScript("arguments[0].value='';", edt_NewStdConfirmPassword);
        edt_NewStdConfirmPassword.sendKeys("Fltester22");
        TestRunner.getTest().log(Status.PASS, "Test Case Passed   : Confirm Password  Enter successfully");
    }

    public void updateBtnStdDialogueBox() throws InterruptedException{

        WebElement updateBtnStd= driver.findElement(By.xpath("//button[normalize-space()='Update']"));
        if (updateBtnStd.isDisplayed() && updateBtnStd.isEnabled()){
            updateBtnStd.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed   : Update Button click Successfully");
        }
        else {
            TestRunner.getTest().log(Status.FAIL, "Test Case failed : Update Button not found");

//            throw new RuntimeException("Update  Button not found.");

        }
    }

    public void ViewFullDetailButton() throws InterruptedException{
        WebElement btn_Full_Detail= driver.findElement(By.xpath("//button[normalize-space()='View Full Details']"));
        if (btn_Full_Detail.isDisplayed() && btn_Full_Detail.isEnabled()){
            btn_Full_Detail.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed   : View Full Details Button click Successfully ");

        }
        else {
            TestRunner.getTest().log(Status.FAIL, "Test Case failed : View Full Detail Button not found");
//            throw new RuntimeException("View Full Detail Button not found.");

        }
    }

    public void EditGrdaesOption() throws InterruptedException{
        String oldGrade= edt_select_grade.getText();
        System.out.println("Old grade is: " + oldGrade);

        edt_select_grade.click();
        WebElement listGrade = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[contains(@role, 'listbox')]")));
        List<WebElement> optionsGrade = listGrade.findElements(By.xpath(".//li"));

        System.out.println("Grades List is: " + optionsGrade.size());

        if (optionsGrade.isEmpty()) {
            System.out.println("No options found in the Grades dropdown.");
            TestRunner.getTest().log(Status.FAIL, "Test Case failed : No options found in the Grades dropdown.");

            return;
        }
        List<WebElement> filteredOptions = new ArrayList<>();
        List<String> excludedValues = List.of("Unknown", "Other", "Ungraded");

        for (WebElement option : optionsGrade) {
            String text = option.getText();
            if (!excludedValues.contains(text)) {
                filteredOptions.add(option);
            }
        }

        System.out.println("Filtered Grades:");

        if (filteredOptions.isEmpty()) {
            System.out.println("No valid options available after filtering.");
            return;
        }

        for (WebElement option : filteredOptions) {
            System.out.println(option.getText());
        }

        WebElement selectedOption = filteredOptions.get(random.nextInt(filteredOptions.size()));
        selectedOption.click();
        selectedGrade = selectedOption.getText();
        System.out.println("Selected Grade: " + selectedGrade);
        TestRunner.getTest().log(Status.INFO, "Selected Grade In edit screen " + selectedGrade);
        TestRunner.getTest().log(Status.PASS, "Test Case Passed : Grade  Select successfully");
        if (oldGrade.equals(selectedGrade)) {
            System.out.println("Grade selection did not change.");
            TestRunner.getTest().log(Status.FAIL, "Test Case failed : Grade selection did not change");

        } else {
            System.out.println("Grade selection changed from '" + oldGrade + "' to '" + selectedGrade + "'.");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed : Grade  Edit successfully");
            TestRunner.getTest().log(Status.INFO, "Grade selection changed from '" + oldGrade + "' to '" + selectedGrade + "'.");

        }
    }

    public void ClickUpdateButton() throws InterruptedException{
        WebElement btn_update= driver.findElement(By.xpath("//button[contains(@name,'btn-signin')]"));

        if (btn_update.isDisplayed() && btn_update.isEnabled()){
            btn_update.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed : Update Button is clicked Successfully");

        }else {
            TestRunner.getTest().log(Status.FAIL, "Test Case failed : Update Button is not Display nor Enable");
//            throw new RuntimeException("Update Button is not Display nor Enable");
        }
    }

    public void CancelButtonCLicked() throws InterruptedException{
        Thread.sleep(500);
        WebElement cancel_btn= driver.findElement(By.xpath("//button[normalize-space()='Cancel']"));
        if (cancel_btn.isEnabled() && cancel_btn.isDisplayed()) {
            cancel_btn.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed : Cancel button clicks successfully");

        }else {
            TestRunner.getTest().log(Status.FAIL, "Test Case failed : Cancel button Not Display/Enable");
//            throw new RuntimeException("Cancel Button is not Display nor Enable");
        }
    }

    public void VerifyEditInfo() throws InterruptedException{
        System.out.println("Student Grade is " + studentGrade);
        System.out.println("Selected Grade from Edit Profile: " + selectedGrade);
        if (studentGrade.equals(selectedGrade)){
            TestRunner.getTest().log(Status.INFO, "Student Grade" + studentGrade + " Garde after we change from edit" + selectedGrade);
            System.out.println("Test Case Passed: Student Information successfully change on Student Information Modal");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Student Information successfully change on Student Information Modal");

        }else {
            System.out.println("Test Case Failed  : Grade not change at student Information Modal in GradeBook");
            TestRunner.getTest().log(Status.INFO, "Student Grade" + studentGrade + " Garde after we change from edit" + selectedGrade);
            TestRunner.getTest().log(Status.FAIL, "Test Case failed : Grade not change at student Information Modal in GradeBook");
//            throw new RuntimeException(" Edited Information still not reflect on Student Information Modal ");
        }
    }
}

