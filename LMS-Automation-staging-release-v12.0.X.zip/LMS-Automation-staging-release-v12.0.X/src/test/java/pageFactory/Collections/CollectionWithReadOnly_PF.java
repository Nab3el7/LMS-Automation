package pageFactory.Collections;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.sl.In;
import org.junit.Assert;
import org.junit.Test;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.Date;
import java.util.List;
import java.util.Random;

import static StepDefinitions.Collections.CollectionWithReadOnlySteps.staffName;

public class CollectionWithReadOnly_PF {
    WebDriverWait wait;
    WebDriver driver;
    Helper helper;
    JavascriptExecutor js;
    Actions actions;

    public static final String BASE_NAME = Configurations.getDotEnv().get("SITE_COLLECTION_NAME-_READ_ONlY");


    public static ThreadLocal<String> collectionNameForReadOnly = ThreadLocal.withInitial(() -> "");

    public CollectionWithReadOnly_PF(WebDriver driver) {
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        helper = new Helper();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        js = (JavascriptExecutor) driver;
        actions = new Actions(driver);
    }

    public static String selectedState;

    public static String selectedGradeLevel;
    public static String selectedDistrict;
    public static String selectedOrganizationName;
    public static String selectedSchool;
    public static String selectedCollectionRight;
    public static String selectedLevel;
    public static String selectedStatus;


    @FindBy(xpath = "//span[normalize-space()='Collections']")
    WebElement collections_button;

    @FindBy(xpath = "//button[normalize-space()='Add New']")
    WebElement add_new_btn;

    @FindBy(xpath = "//label[text()='Status']/following-sibling::div//div[@role='button' or @role='combobox']")
    WebElement dropDown_Status;

    @FindBy(xpath = "//label[text()='State']/following-sibling::div//div[@role='button' or @role='combobox']")
    WebElement dropDown_state;

    @FindBy(xpath = "//label[text()='Collection Level']/following-sibling::div//div[@role='button' or @role='combobox']")
    WebElement collection_level;

    @FindBy(xpath = "//label[text()='Grade Level']/following-sibling::div//div[@role='button' or @role='combobox']")
    WebElement Grade_level;

    @FindBy(xpath = "//label[text()='Default Collection Rights']/following-sibling::div//div[@role='button' or @role='combobox']")
    WebElement default_collection_rights;

    @FindBy(xpath = "//button[@type='button'][normalize-space()='Next']")
    WebElement btn_next;

    @FindBy(xpath = "(//label[normalize-space()='District Filter']/parent::div)")
    WebElement district_filter;

    @FindBy(xpath = "//div[@class='btn-group']//button[@id='btn-saveNext']")
    WebElement next_button_step;

    @FindBy(xpath = "(//label[normalize-space()='Select School']/parent::div)[2]")
    WebElement dropDown_School;

    @FindBy(xpath = "(//label[normalize-space()='Role']/parent::div)[2]")
    WebElement roleDropdown;

    @FindBy(xpath = "//label[normalize-space()='Select District']/parent::div")
    WebElement filter_select_district;

    @FindBy(xpath = "//div[contains(@class,'left-panel')]")
    WebElement left_Panel;

    @FindBy(xpath = "//label[normalize-space()='Select School']/parent::div")
    WebElement filter_select_school;

    @FindBy(xpath = "//label[normalize-space()='Levels']/parent::div")
    WebElement filter_select_levels;

    @FindBy(xpath = "//div[contains(text(),'Status')]/following-sibling::div//div[@role='button' or @role='combobox']")
    WebElement filter_select_status;

    @FindBy(xpath = "//div[contains(@class, 'right-panel')]")
    WebElement collectionTable;

    @FindBy(xpath = "//button[normalize-space()='Apply Filters']")
    WebElement apply_filter_button;

    public static String collectionName;


    @FindBy(xpath = "//div[contains(@class, 'right-panel')]//tbody")
    WebElement assessmentContainerTable;

    public static String assessmentsTitle;

    public void ClickOnCollectionsTabButton() throws InterruptedException {
        System.out.println("I'm in Click on Collections Tab");
        TestRunner.getTest().log(Status.INFO, "I'm in Click on Collections Tab");

        // Wait for toast/overlay messages (top-right container) to disappear if they exist
        try {
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector(".top-right")));
        } catch (TimeoutException ignored) {
            TestRunner.getTest().log(Status.INFO, "Toast container still visible, proceeding with cautious click");
        } catch (NoSuchElementException ignored) {
            // Container never appeared; safe to continue
        }

        try {
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[normalize-space()='Collections']")));
            helper.scrollToElement(driver, collections_button);

            // Try regular click first
            wait.until(ExpectedConditions.elementToBeClickable(collections_button)).click();
            TestRunner.getTest().log(Status.PASS, "Testcase Passed   :  Collection button clicked successfully");
        } catch (ElementClickInterceptedException e) {
            TestRunner.getTest().log(Status.WARNING, "Native click intercepted, trying JavaScript click: " + e.getMessage());
            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", collections_button);
            TestRunner.getTest().log(Status.PASS, "Testcase Passed   :  Collection button clicked via JavaScript");
        } catch (TimeoutException e) {
            TestRunner.getTest().log(Status.FAIL, "Testcase Failed   : Collections Button not Display or clickable - " + e.getMessage());
        }
    }

    public void clickOnAddNewButton() throws InterruptedException {

        System.out.println("I'm in Click on Add New Button +");
        TestRunner.getTest().log(Status.INFO, "I'm in Click on Add New Button + ");

        if (add_new_btn.isDisplayed()) {
            add_new_btn.click();
            TestRunner.getTest().log(Status.PASS, "Testcase Passed   :  Add New button clicked successfully");
        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Failed: Add NewButton is Not Display/Enable");
        }
    }

    public void ValidateAndAddCollectionTitle() throws InterruptedException {

        System.out.println("I'm into Enter Collection Title");
        TestRunner.getTest().log(Status.INFO, "I'm in to Enter Collection Title");

        WebElement collectionTitleField = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//input[@placeholder='Collection Title' and @name='name']")
        ));

        collectionTitleField.click();

        String collectionName = BASE_NAME + "_" + new Date();
        setCollectionName(collectionName);

        System.out.println("Enter Assignment Title Successfully: " + collectionNameForReadOnly.get());
        collectionTitleField.sendKeys(collectionNameForReadOnly.get());
        TestRunner.getTest().log(Status.INFO, "Collection title: " + collectionNameForReadOnly.get());

    }

    public static void setCollectionName(String assignmentName) {
        collectionNameForReadOnly.set(assignmentName);
    }

    public static String getAssignmentName() {
        return collectionNameForReadOnly.get();
    }

    public void SelectActiveStatus() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into selecting Status For Collection");
        System.out.println("I'm into selecting Status For Collection");

        dropDown_Status.click();

        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//ul[@role='listbox']//li")));
        List<WebElement> ClassStatusOptions = driver.findElements(By.xpath("//ul[@role='listbox']//li"));

        System.out.println("Available Status Options For Collection:");
        for (WebElement option : ClassStatusOptions) {
            System.out.println(option.getText());
        }

        for (WebElement option : ClassStatusOptions) {
            if (option.getText().equalsIgnoreCase("Active")) {
                selectedStatus = option.getText();
                option.click();
                System.out.println("Selected: " + selectedStatus + " status");
                break;
            }
        }

        System.out.println("Stored Selected Status: " + selectedStatus);
        TestRunner.getTest().log(Status.PASS, "Test Case Passed: New Active status '" + selectedStatus + "' selected successfully for Collection");
    }


    public void validateAndSelectStateForCollection() {
        TestRunner.getTest().log(Status.INFO, "Select State");

        dropDown_state.click();

        WebElement listDistrict = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[contains(@role, 'listbox')]")));
        List<WebElement> optionsDistrict = listDistrict.findElements(By.xpath(".//li"));

        System.out.println("State List is: " + optionsDistrict.size());

        if (optionsDistrict.isEmpty()) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: No options found in the State dropdown");
            System.out.println("No options found in the State dropdown.");
            throw new RuntimeException("No State Value found in dropdown");

        } else {
            System.out.println("State:");

            for (WebElement district : optionsDistrict) {
                System.out.println(district.getText());
            }
            if (!optionsDistrict.isEmpty()) {
                Random random = new Random();
                int randomCourse = random.nextInt(optionsDistrict.size());
                WebElement selectedOption = optionsDistrict.get(randomCourse);
                selectedState = selectedOption.getText();
                selectedOption.click();
                System.out.println("Selected State: " + selectedState);
                TestRunner.getTest().log(Status.INFO, "Selected state is: " + selectedState);
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: state select successfully");
            }
        }
    }

    public void SelectCollectionLevelFromDropdown() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into selecting Collection Level For Collection");
        System.out.println("I'm into selecting Collection Level For Collection");

        collection_level.click();

        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//ul[@role='listbox']//li")));
        List<WebElement> ClassStatusOptions = driver.findElements(By.xpath("//ul[@role='listbox']//li"));

        System.out.println("Available Collection Level Options For Collection:");
        for (WebElement option : ClassStatusOptions) {
            System.out.println(option.getText());
        }

        for (WebElement option : ClassStatusOptions) {
            if (option.getText().equalsIgnoreCase("Teacher Level")) {
                selectedLevel = option.getText(); // Store the selected level
                option.click();
                System.out.println("Selected: " + selectedLevel + " collection level");
                break;
            }
        }

        // Log or use selectedLevel later
        System.out.println("Stored Selected Level: " + selectedLevel);
        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Collection Level '" + selectedLevel + "' selected successfully");
    }


    public void SelectCollectionGradeLevelFromDropdown() {
        TestRunner.getTest().log(Status.INFO, "Select Grade Level");

        Grade_level.click();

        WebElement listDistrict = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[contains(@role, 'listbox')]")));
        List<WebElement> optionsDistrict = listDistrict.findElements(By.xpath(".//li"));

        System.out.println("State List is: " + optionsDistrict.size());

        if (optionsDistrict.isEmpty()) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: No options found in the Grade Level dropdown");
            System.out.println("No options found in the Grade Level dropdown.");
            throw new RuntimeException("No Grade Level Value found in dropdown");

        } else {
            System.out.println("Grade Level:");

            for (WebElement district : optionsDistrict) {
                System.out.println(district.getText());
            }
            if (!optionsDistrict.isEmpty()) {
                Random random = new Random();
                int randomCourse = random.nextInt(optionsDistrict.size());
                WebElement selectedOption = optionsDistrict.get(randomCourse);
                selectedGradeLevel = selectedOption.getText();
                selectedOption.click();
                System.out.println("Selected Grade Level: " + selectedGradeLevel);
                TestRunner.getTest().log(Status.INFO, "Selected Grade Level is: " + selectedGradeLevel);
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: Grade Level select successfully");
            }
        }
    }

    public void ValidateAndSelectReadOnlyCollectionRight() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into selecting Default Collection Rights For Collection");
        System.out.println("I'm into selecting Default Collection Rights For Collection");

        // Click to open the dropdown
        default_collection_rights.click();

        // Wait for the dropdown options to become clickable
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//ul[@role='listbox']//li")));
        List<WebElement> collectionRightsOptions = driver.findElements(By.xpath("//ul[@role='listbox']//li"));

        // Print all available options
        System.out.println("Available Default Collection Rights Options For Collection:");
        for (WebElement option : collectionRightsOptions) {
            System.out.println(option.getText());
        }


        // Iterate through the options and select "Read Only"
        for (WebElement option : collectionRightsOptions) {
            if (option.getText().equalsIgnoreCase("Read Only")) {
                option.click();
                selectedCollectionRight = option.getText(); // Store the selected option
                System.out.println("Selected: " + selectedCollectionRight + " Default Collection Rights");
                break;
            }
        }

        // Validate the selection and log accordingly
        if (selectedCollectionRight != null) {
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Default Collection Rights selected successfully - " + selectedCollectionRight);
        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: 'Read Only' option not found in the dropdown.");
            throw new NoSuchElementException("'Read Only' option not found in the dropdown.");
        }
    }


    public void ClickNextButton() throws InterruptedException {

        TestRunner.getTest().log(Status.INFO, "I'm into click on Next Button");
        System.out.println("I'm into click on Next Button");

        if (btn_next.isDisplayed() && btn_next.isEnabled()) {
            btn_next.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  Next button clicked successfully");
        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Failed: Next Button is Not Display/Enable");
        }
    }


    public void validateAndSelectDistrictFilter() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into select District Filter");
        System.out.println("I'm into select District Filter");

        district_filter.click();

        WebElement listDistrict = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[contains(@role, 'listbox')]")));
        List<WebElement> optionsDistrict = listDistrict.findElements(By.xpath(".//li"));

        System.out.println("District List is: " + optionsDistrict.size());

        if (optionsDistrict.isEmpty()) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: No options found in the  District dropdown");
            System.out.println("No options found in the District dropdown.");
            throw new RuntimeException("No District Value found in dropdown");

        } else {
            System.out.println("District Filter:");

            for (WebElement district : optionsDistrict) {
                System.out.println(district.getText());
            }
            if (!optionsDistrict.isEmpty()) {
                Random random = new Random();
                int randomCourse = random.nextInt(optionsDistrict.size());
                WebElement selectedOption = optionsDistrict.get(randomCourse);
                selectedDistrict = selectedOption.getText();
                selectedOption.click();
                System.out.println("Selected District: " + selectedDistrict);
                TestRunner.getTest().log(Status.INFO, "Selected District is: " + selectedDistrict);
                TestRunner.getTest().log(Status.PASS, "Test Case Passed:  District Filter select successfully");
            }
        }
    }

    public void validateAndSelectOrganizationNameFromDropdown() {
        TestRunner.getTest().log(Status.INFO, "Select Organization Name");

        try {
            WebElement organizationDropdown = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(@class, 'MuiAutocomplete-inputRoot')]//input[contains(@class, 'MuiAutocomplete-input')])[2]")));
            organizationDropdown.click();

            WebElement listOrganization = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[contains(@role, 'listbox')]")));

            List<WebElement> optionsOrganization = listOrganization.findElements(By.xpath(".//li"));

            System.out.println("Organization List is: " + optionsOrganization.size());

            if (optionsOrganization.isEmpty()) {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: No options found in the Organization Name dropdown");
                System.out.println("No options found in the Organization Name dropdown.");
                throw new RuntimeException("No Organization Name found in dropdown");
            } else {
                System.out.println("Available Organizations Name:");

                for (WebElement organization : optionsOrganization) {
                    System.out.println(organization.getText());
                }

                Random random = new Random();
                int randomOrganization = random.nextInt(optionsOrganization.size());
                WebElement selectedOption = optionsOrganization.get(randomOrganization);

                selectedOrganizationName = selectedOption.getText();
                selectedOption.click();

                System.out.println("Selected Organization: " + selectedOrganizationName);
                TestRunner.getTest().log(Status.INFO, "Selected Organization is: " + selectedOrganizationName);
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: Organization Name selected successfully");
            }
        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "No Value found in Organization Name dropdown ");
        }
    }

    public void ValidateAndClickNextButtonStepII() throws InterruptedException {

        TestRunner.getTest().log(Status.INFO, "I'm into click on Next Button");
        System.out.println("I'm into click on Next Button");

        if (next_button_step.isDisplayed() && next_button_step.isEnabled()) {
            next_button_step.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  Next button clicked successfully");
        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Failed: Next Button is Not Display/Enable");
        }
    }

    public void ClickOnAddExistingAssessmentButton() throws InterruptedException {

        TestRunner.getTest().log(Status.INFO, "I'm into click on Add Existing Assessment Button");
        System.out.println("I'm into click on Add Existing Assessment Button");

        WebElement addExistingAssessmentButton = driver.findElement(By.xpath("//button[normalize-space()='Add Existing Assessment']"));

        if (addExistingAssessmentButton.isDisplayed() && addExistingAssessmentButton.isEnabled()) {
            addExistingAssessmentButton.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed   : Add Existing Assessment Button clicked successfully");
        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Failed: Add Existing Assessment Button is Not Display/Enable");
        }
    }

    public void verifyPrompt() throws InterruptedException {

        WebElement prompt = driver.findElement(By.xpath("//div[@role='dialog']"));
        boolean isDisplayed = prompt.isDisplayed();
        Assert.assertTrue("Prompt is not displayed.", isDisplayed);

        WebElement promptHeader = prompt.findElement(By.tagName("h2"));
        String headerText = promptHeader.getText();
        System.out.println("Prompt header text is: " + headerText);
        TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  Prompt Display Successfully");
    }

    public void selectAllCheckboxesInsideAssessment() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Selecting all checkboxes inside Assessment");

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));

        WebElement btn_Assessment = driver.findElement(By.xpath("//div[@aria-label='Platform']//button[.//span[contains(text(), 'My Assessments')]]"));
        btn_Assessment.click();
        TestRunner.getTest().log(Status.INFO, "My Assessment clicked successfully in assessment grid");

        Thread.sleep(3000);

        List<WebElement> checkboxes = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(
                By.xpath("//div[@id='Assessment-content']//span[@role='checkbox']")));

        System.out.println("Total checkboxes found: " + checkboxes.size());
        TestRunner.getTest().log(Status.INFO, "Total checkboxes found in Assessment: " + checkboxes.size());

        for (WebElement checkBox : checkboxes) {
            boolean isChecked = checkBox.isSelected();
            if (isChecked) {
                System.out.println("Checkbox is already selected.");
            } else {
                checkBox.click();
                System.out.println("Checkbox is now selected.");
            }
        }

    }

    public void clickApplyFilterButton() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Click on Apply Filter Button");

        WebElement applyFilter = driver.findElement(By.xpath("//div[@class='searchFilter']//button[@id='btn-saveNext']"));

        if (applyFilter.isDisplayed() && applyFilter.isEnabled()) {
            applyFilter.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed   : Apply filter Button clicked successfully");
        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Failed: Apply filter Button is Not Display/Enable");
        }

    }

    public void selectAssessment() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Select Assessment");
        System.out.println("Select Assessment");

        WebElement checkBox = driver.findElement(By.xpath("(//div[contains(@class, 'CheckboxesGroupWrapper')])[2]"));

        if (checkBox != null) {
            System.out.println("Checkbox found.");
            TestRunner.getTest().log(Status.INFO, "Checkbox found.");

            // Check if the checkbox is displayed
            if (checkBox.isDisplayed()) {
                boolean isChecked = checkBox.isSelected();
                if (isChecked) {
                    System.out.println("Checkbox is already selected.");
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  Checkbox select Successfully");
                } else {
                    checkBox.click();
                    System.out.println("Checkbox is now selected.");
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  Checkbox select Successfully");
                }
            } else {
                System.out.println("Checkbox is not visible, skipping.");
                TestRunner.getTest().log(Status.FAIL, "Test Failed: Checkbox is not visible, skipping");
            }
        } else {
            System.out.println("Checkbox not found.");
            TestRunner.getTest().log(Status.FAIL, "Test Failed: Checkbox is not visible, skipping");
        }
    }

    public void ClickSaveButton() throws InterruptedException {

        TestRunner.getTest().log(Status.INFO, "I'm into click on save button");
        System.out.println("I'm into click on save button");

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));

        WebElement buttonSaveNext = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='courseClass']//button[@id='btn-saveNext']")));

        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].scrollIntoView(true);", buttonSaveNext);

        if (buttonSaveNext.isDisplayed() && buttonSaveNext.isEnabled()) {
            buttonSaveNext.click();
            TestRunner.getTest().log(Status.INFO, "Clicked on the 'Save Next' button.");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  save button click Successfully");
        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  Save button not found select Successfully");
        }

    }

    public int storedHeaderCount;

    public void VerifyAssessmentCountMatch() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Verify Count of Assessment match");
        System.out.println("Verify Count of Assessment match");

        int totalRowCount = AssignmentDeleteForAllStudents();

        System.out.println("Total Assessment that we are adding in collection: " + totalRowCount);

        storedHeaderCount = getDisplayedCountFromHeader();

        System.out.println("Total Stored Header Count is: " + storedHeaderCount);
        TestRunner.getTest().log(Status.INFO, "Total Stored Header Count is: " + storedHeaderCount);

        if (totalRowCount == storedHeaderCount) {
            TestRunner.getTest().log(Status.PASS, "Row count matches the displayed count: " + totalRowCount);
            System.out.println("Row count matches the displayed count: " + totalRowCount);
        } else {
            TestRunner.getTest().log(Status.FAIL, "Row count mismatch! Displayed: " + storedHeaderCount + ", Calculated: " + totalRowCount);
            System.out.println("Row count mismatch! Displayed: " + storedHeaderCount + ", Calculated: " + totalRowCount);
        }

    }

    public int getDisplayedCountFromHeader() {
        int displayedCount = 0;

        try {

            WebElement headerElement = driver.findElement(By.xpath("//div/h1"));
            String headerText = headerElement.getText(); // Example: "Count: 20"


            displayedCount = Integer.parseInt(headerText.replaceAll("[^0-9]", ""));
            TestRunner.getTest().log(Status.INFO, "Extracted count from header: " + displayedCount);
            System.out.println("Extracted count from header: " + displayedCount);

        } catch (NoSuchElementException | NumberFormatException e) {
            TestRunner.getTest().log(Status.FAIL, "Failed to extract count from header: " + e.getMessage());
            System.out.println("Error extracting count: " + e.getMessage());
        }

        return displayedCount;
    }


    public int AssignmentDeleteForAllStudents() throws InterruptedException {
        int totalRowsCount = 0;

        try {
            TestRunner.getTest().log(Status.INFO, "Starting Getting All Assessments");
            System.out.println("Starting Getting All Assessments");

            List<WebElement> studentsPagination = driver.findElements(By.xpath("//button[contains(@aria-label, 'Go to page')]"));
            int totalPages = studentsPagination.size();
            System.out.println("Total Pages: " + totalPages);
            TestRunner.getTest().log(Status.INFO, "Total Pages: " + totalPages);

            TestRunner.startTest("Getting All Rows");

            boolean hasNextPage = true;

            while (hasNextPage) {
                int rowsOnCurrentPage = getAllStudentsFromPagination();
                totalRowsCount += rowsOnCurrentPage;

                try {
                    WebElement btnNextPage = driver.findElement(By.xpath("//button[@aria-label='Go to next page']"));
                    if (btnNextPage.isEnabled()) {
                        btnNextPage.click();
                        TestRunner.getTest().log(Status.INFO, "Navigating to the next page.");
                        Thread.sleep(2000);
                    } else {
                        hasNextPage = false;
                        TestRunner.getTest().log(Status.INFO, "Reached the last page.");
                    }
                } catch (NoSuchElementException e) {
                    hasNextPage = false;
                    TestRunner.getTest().log(Status.INFO, "Reached the last page.");
                }
            }

            System.out.println("Total Rows Across All Pages: " + totalRowsCount);
            TestRunner.getTest().log(Status.INFO, "Total Rows Across All Pages: " + totalRowsCount);

        } catch (NoSuchElementException e) {
            TestRunner.getTest().log(Status.FAIL, "Error occurred: " + e.getMessage());
            System.out.println("Element not found: " + e.getMessage());
        }

        return totalRowsCount;
    }

    public int getAllStudentsFromPagination() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Getting All Assessments on the Current Page");
        System.out.println("Getting All Assessments on the Current Page");

        int rowsCount = 0;

        try {
            List<WebElement> rowsStudents = driver.findElements(By.xpath("//table[contains(@class,'MuiTable-root')]/tbody/tr"));
            rowsCount = rowsStudents.size();

            System.out.println("Total students on this page: " + rowsCount);
            TestRunner.getTest().log(Status.INFO, "Total students on this page: " + rowsCount);

            for (WebElement rowStudent : rowsStudents) {
                String studentInfo = rowStudent.getText();
                System.out.println("Student row: " + studentInfo);
                TestRunner.getTest().log(Status.INFO, "Assessment Name: " + studentInfo);
            }
        } catch (NoSuchElementException e) {
            TestRunner.getTest().log(Status.FAIL, "Error occurred while fetching students: " + e.getMessage());
            System.out.println("Element not found: " + e.getMessage());
        }

        return rowsCount;
    }

    public void ClickOnAddStaffMembersButton() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into click on Add Staff Members Button");
        System.out.println("I'm into click on Add Staff Members Button");

        WebElement addStaffBtn = driver.findElement(By.xpath("//button[normalize-space()='Add Staff Members']"));

        if (addStaffBtn.isDisplayed() && addStaffBtn.isEnabled()) {
            addStaffBtn.click();

            TestRunner.getTest().log(Status.INFO, "Clicked on the 'Add Staff Members' button.");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed   : Add Staff Members button click Successfully");

        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : Add Staff Members button is not Display/Enabled");

        }
    }

    public void SelectDistrictFromDropdown() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into select District from Staff Selection Prompt");
        System.out.println("I'm into select District from Staff Selection Prompt");

        try {
            WebElement districtDropdown = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//label[normalize-space()='District']/parent::div)")));
            districtDropdown.click();

            WebElement listOrganization = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[contains(@role, 'listbox')]")));

            List<WebElement> optionsDistrict = listOrganization.findElements(By.xpath(".//li"));

            System.out.println("District List is: " + optionsDistrict.size());

            if (optionsDistrict.isEmpty()) {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: No options found in the District Name dropdown");
                System.out.println("No options found in the District Name dropdown.");
                throw new RuntimeException("No District Name found in dropdown");
            } else {
                System.out.println("Available District Name:");

                for (WebElement organization : optionsDistrict) {
                    System.out.println(organization.getText());
                }

                Random random = new Random();
                int randomOrganization = random.nextInt(optionsDistrict.size());
                WebElement selectedOption = optionsDistrict.get(randomOrganization);

                String district = selectedOption.getText();
                selectedOption.click();

                System.out.println("Selected District: " + district);
                TestRunner.getTest().log(Status.INFO, "Selected District is: " + district);
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: District selected successfully");
            }
        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "No Value found in district dropdown ");
        }
    }

    public void SelectSchoolFromDropDown() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into select School from Staff Selection Prompt");
        System.out.println("I'm into select School from Staff Selection Prompt");

        // Click on the dropdown to expand it
        dropDown_School.click();

        // Wait until the dropdown options are visible
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//ul[@role='listbox']//li")));
        List<WebElement> ClassStatusOptions = driver.findElements(By.xpath("//ul[@role='listbox']//li"));

        // Print all available school options
        System.out.println("Available School Options For Collection:");
        for (WebElement option : ClassStatusOptions) {
            System.out.println(option.getText());
        }

        // Initialize a variable to store the selected school

        // Iterate through options and select the desired school
        for (WebElement option : ClassStatusOptions) {
            if (option.getText().equalsIgnoreCase("Florida ES")) {
                option.click();
                selectedSchool = option.getText(); // Store the selected school
                System.out.println("Selected: " + selectedSchool + " School");
                break;
            }
        }

        // Check if a school was successfully selected
        if (selectedSchool != null) {
            TestRunner.getTest().log(Status.PASS, "Test Case Passed   : School selected successfully - " + selectedSchool);
        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : Desired school not found in the dropdown.");
            throw new NoSuchElementException("Desired school not found in the dropdown.");
        }
    }


    public void validateAndSelectRoleFromDropdown() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into select Role from Staff Selection Prompt");
        System.out.println("I'm into select Role from Staff Selection Prompt");

        roleDropdown.click();

        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//ul[@role='listbox']//li")));
        List<WebElement> ClassStatusOptions = driver.findElements(By.xpath("//ul[@role='listbox']//li"));

        System.out.println("Available Role Options For Collection:");
        for (WebElement option : ClassStatusOptions) {
            System.out.println(option.getText());
        }

        for (WebElement option : ClassStatusOptions) {
            if (option.getText().equalsIgnoreCase("All")) {
                option.click();
                System.out.println("Selected: " + option.getText() + " Role");
                break;
            }
        }
        TestRunner.getTest().log(Status.PASS, "Test Case Passed   : Role selected successfully for Collection");

    }

    public void searchStaffByName(String staffName) throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into search staff By Name in Search Box");
        System.out.println("I'm into search staff By Name in Search Box");

        try {
            WebElement searchInput = driver.findElement(By.xpath("//input[@placeholder='Search Staff by Name']"));

            if (searchInput.isDisplayed() && searchInput.isEnabled()) {
                System.out.println("Search box is displayed and enabled.");

                searchInput.click();

                searchInput.clear();

                searchInput.sendKeys(staffName);
                System.out.println("Entered name: " + staffName);
                TestRunner.getTest().log(Status.INFO, "Entered Staff name is: " + staffName);
                TestRunner.getTest().log(Status.PASS, "Test Case Passed   : Staff Name Enter successfully for Collection");
            } else {
                System.out.println("Search box is not displayed or not enabled.");
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : Search box is not displayed or not enabled.");
                return;
            }

            TestRunner.getTest().log(Status.INFO, "I'm into click on Apply Filter Button");

            // Locate the "Apply Filters" button
            WebElement applyFiltersButton = driver.findElement(By.xpath("//div[@class='searchFilter']//button[@id='btn-saveNext']"));

            // Check if the button is displayed and enabled
            if (applyFiltersButton.isDisplayed() && applyFiltersButton.isEnabled()) {
                System.out.println("Apply Filters button is displayed and enabled.");
                TestRunner.getTest().log(Status.INFO, "Apply Filters button is displayed and enabled");


                // Click the "Apply Filters" button
                applyFiltersButton.click();
                System.out.println("Clicked on Apply Filters button.");
                TestRunner.getTest().log(Status.PASS, "Test Case Passed   : Clicked on Apply Filters button Successfully");
            } else {
                System.out.println("Apply Filters button is not displayed or not enabled.");
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : Apply Filters button is not displayed or not enabled.");
            }

        } catch (NoSuchElementException e) {
            System.out.println("Element not found: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("An error occurred: " + e.getMessage());
        }
    }


    public void selectStaff() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Select Staff");
        System.out.println("Select Staff");

        WebElement checkBox = driver.findElement(By.xpath("(//div[contains(@class, 'CheckboxesGroupWrapper')])[2]"));

        if (checkBox != null) {
            System.out.println("Checkbox found.");
            TestRunner.getTest().log(Status.INFO, "Checkbox found.");

            // Check if the checkbox is displayed
            if (checkBox.isDisplayed()) {
                boolean isChecked = checkBox.isSelected();
                if (isChecked) {
                    System.out.println("Checkbox is already selected.");
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  Checkbox select Successfully");
                } else {
                    checkBox.click();
                    System.out.println("Checkbox is now selected.");
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  Checkbox select Successfully");
                }
            } else {
                System.out.println("Checkbox is not visible, skipping.");
                TestRunner.getTest().log(Status.FAIL, "Test Failed: Checkbox is not visible, skipping");
            }
        } else {
            System.out.println("Checkbox not found.");
            TestRunner.getTest().log(Status.FAIL, "Test Failed: Checkbox is not visible, skipping");
        }
    }

    public void SaveStaffSelection() throws InterruptedException {

        TestRunner.getTest().log(Status.INFO, "I'm into click on save button From Staff Selection");
        System.out.println("I'm into click on save button From Staff Selection");

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));

        WebElement buttonSaveNext = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='flex flex-row justify-between']//button[@id='btn-saveNext']")));

        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].scrollIntoView(true);", buttonSaveNext);

        if (buttonSaveNext.isDisplayed() && buttonSaveNext.isEnabled()) {
            buttonSaveNext.click();
            TestRunner.getTest().log(Status.INFO, "Click on save button From Staff Selection");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  Click on save button From Staff Selection Successfully");
        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  save button From Staff Selection not found");
        }

    }

    public void validateStaffAndCollectionRights() {
        TestRunner.getTest().log(Status.INFO, "I'm into validating staff name and collection rights");
        System.out.println("I'm into validating staff name and collection rights");


        // Locate the rows in the table (tbody)
        List<WebElement> rows = driver.findElements(By.xpath("//table[contains(@class, 'MuiTable-root')]//tbody//tr"));

        boolean isMatchFound = false;  // Flag to track if a match is found

        // Iterate over each row in the table
        for (WebElement row : rows) {
            // Get the staff name (first column)
            String staffNameFromTable = row.findElement(By.xpath(".//td[1]//div")).getText();

            System.out.println("Staff Name From Table: " + staffNameFromTable);
            TestRunner.getTest().log(Status.INFO, "Staff Name From Table: " + staffNameFromTable);

            // Get the collection rights (last column)
            String collectionRights = row.findElement(By.xpath("(.//td[5]//div//span)[2]")).getText();
            System.out.println("Default Collection Right From Table: " + collectionRights);
            TestRunner.getTest().log(Status.INFO, "Default Collection Right From Table: " + collectionRights);


            System.out.println("Default Collection Right from step 1: " + selectedCollectionRight);
            TestRunner.getTest().log(Status.INFO, "Default Collection Right from step 1: " + selectedCollectionRight);

            System.out.println("Staff Name that we selected Before: " + staffName);
            TestRunner.getTest().log(Status.INFO, "Staff Name that we selected Before: " + staffName);

            // Check if both the name and collection rights match
            if (staffNameFromTable.equalsIgnoreCase(staffName) && collectionRights.equalsIgnoreCase(selectedCollectionRight)) {
                System.out.println("Found matching staff and collection rights: " + staffName + " - " + collectionRights);
                TestRunner.getTest().log(Status.PASS, "Staff: " + staffName + " and Collection Rights: " + collectionRights + " match successfully.");
                isMatchFound = true;  // Update the flag if match is found
                break; // Exit the loop once match is found
            }
        }

        if (!isMatchFound) {
            System.out.println("No matching staff and collection rights found.");
            TestRunner.getTest().log(Status.FAIL, staffName + " and Collection Right" + selectedCollectionRight + "not match");
        }
    }


    public void VerifySelectedUserCountAndTableRowsCountMatch() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into Validate Selected User Count and Table Rows Count Match");
        System.out.println("I'm into Validate Selected User Count and Table Rows Count Match");


        // Step 1: Locate all the rows in the table body
        List<WebElement> tableRows = driver.findElements(By.xpath("//table[contains(@class, 'MuiTable-root')]//tbody//tr"));

// Step 2: Get the total number of rows
        int totalRows = tableRows.size();
        System.out.println("Total Rows in Table: " + totalRows);
        TestRunner.getTest().log(Status.INFO, "Total Rows in Table: " + totalRows);

// Step 3: Locate the Selected User Count element and extract the count
        WebElement selectedUserElement = driver.findElement(By.xpath("//div[contains(@class, 'headingstyle') and contains(text(), 'Selected User:')]"));
        String selectedUserText = selectedUserElement.getText();
        int selectedUserCount = Integer.parseInt(selectedUserText.replaceAll("[^0-9]", ""));
        System.out.println("Selected User Count: " + selectedUserCount);
        TestRunner.getTest().log(Status.INFO, "Selected User Count: " + selectedUserCount);

        if (totalRows == selectedUserCount) {
            System.out.println("The total rows in the table match the Selected User Count.");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  The total rows in the table match the Selected User Count.");
        } else {
            System.out.println("Mismatch: Total Rows (" + totalRows + ") do not match Selected User Count (" + selectedUserCount + ").");

            TestRunner.getTest().log(Status.PASS, "Test Case Passed   : Mismatch: Total Rows (" + totalRows + ") do not match Selected User Count (" + selectedUserCount + ").");
        }
    }

    public void ValidateAndClickSaveAndExitButton() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into Click on Save And Exit Button to Save Collection");
        System.out.println("I'm into Click on Save And Exit Button to Save Collection");

        WebElement save_exit_btn = driver.findElement(By.xpath("//button[@id='btn-publish']"));

        if (save_exit_btn.isEnabled() && save_exit_btn.isDisplayed()) {
            save_exit_btn.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  Click on save and Exit button Successfully");
        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  Save and Exit button Not Display/Enabled");
        }
    }

    public void FilterVerificationOnContentCollection() throws InterruptedException {
        TestRunner.startTest(" Filters On Content Collection Dashboard");
        TestRunner.getTest().log(Status.INFO, "I'm To fill Filters Information On Content Collection Dashboard");

        Thread.sleep(100);
        left_Panel.isDisplayed();

        select_DistrictFilter(selectedDistrict);
        select_SchoolFilter(selectedSchool);
        select_statusFilter(selectedStatus);
        select_LevelFilter(selectedLevel);
        TestRunner.getTest().log(Status.INFO, "All Filters Information Filled successfully");
    }

    public void select_DistrictFilter(String selectedDistrict) {
        TestRunner.getTest().log(Status.INFO, "I'm in to select District on Content Collection Dashboard");
        filter_select_district.click();
        WebElement listDistrict = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//ul[@role='listbox']")));

        List<WebElement> optionsDistrict = listDistrict.findElements(By.xpath(".//li"));

        System.out.println("District List is: " + optionsDistrict.size());

        if (optionsDistrict.isEmpty()) {
            System.out.println("No options found in the District dropdown.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : No options found in the District dropdown.");

        } else {
            System.out.println("District:");

            for (WebElement district : optionsDistrict) {
                System.out.println(district.getText());
                if (district.getText().equals(selectedDistrict)) {
                    district.click();
                    TestRunner.getTest().log(Status.INFO, "Clicked on District: " + selectedDistrict);
                    System.out.println("Clicked on District: " + selectedDistrict);
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  District selected successfully");
                    break;
                }
            }
        }

        Actions actions = new Actions(driver);
        actions.sendKeys(Keys.ESCAPE).build().perform();

    }

    public void select_SchoolFilter(String selectedSchool) throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm in to select School on Content Collection Dashboard");
        filter_select_school.click();

        WebElement listSchool = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//ul[@role='listbox']")));

        List<WebElement> optionsSchool = listSchool.findElements(By.xpath(".//li"));

        System.out.println("District List is: " + optionsSchool.size());

        if (optionsSchool.isEmpty()) {
            System.out.println("No options found in the School dropdown.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : No options found in the School dropdown.");

        } else {
            System.out.println("School:");

            for (WebElement school : optionsSchool) {
                System.out.println(school.getText());
                if (school.getText().equals(selectedSchool)) {
                    school.click();
                    TestRunner.getTest().log(Status.INFO, "Clicked on School: " + selectedSchool);
                    System.out.println("Clicked on School: " + selectedSchool);
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  School selected successfully");
                    break;
                }
            }
        }

        Actions actions = new Actions(driver);
        actions.sendKeys(Keys.ESCAPE).build().perform();

    }

    public void select_LevelFilter(String selectedLevel) throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm in to select Level on Content Collection Dashboard");
        filter_select_levels.click();

        WebElement listLevel = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//ul[@role='listbox']")));

        List<WebElement> optionsLevels = listLevel.findElements(By.xpath(".//li"));

        System.out.println("Levels List is: " + optionsLevels.size());

        if (optionsLevels.isEmpty()) {
            System.out.println("No options found in the Levels dropdown.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : No options found in the Levels dropdown.");

        } else {
            System.out.println("Levels:");

            for (WebElement levels : optionsLevels) {
                System.out.println(levels.getText());
                if (levels.getText().equals(selectedLevel)) {
                    levels.click();
                    TestRunner.getTest().log(Status.INFO, "Clicked on Level: " + selectedLevel);
                    System.out.println("Clicked on Level: " + selectedLevel);
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  Level selected successfully");
                    break;
                }
            }
        }

        Actions actions = new Actions(driver);
        actions.sendKeys(Keys.ESCAPE).build().perform();
    }

    public void select_statusFilter(String selectedStatus) throws InterruptedException {

        TestRunner.getTest().log(Status.INFO, "I'm in to select Status on Content Collection Dashboard");
        filter_select_status.click();

        WebElement listLevel = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//ul[@role='listbox']")));

        List<WebElement> optionsLevels = listLevel.findElements(By.xpath(".//li"));

        System.out.println("Status List is: " + optionsLevels.size());

        if (optionsLevels.isEmpty()) {
            System.out.println("No options found in the Status dropdown.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : No options found in the Status dropdown.");

        } else {
            System.out.println("Status:");

            for (WebElement levels : optionsLevels) {
                System.out.println(levels.getText());
                if (levels.getText().equals(selectedStatus)) {
                    levels.click();
                    TestRunner.getTest().log(Status.INFO, "Clicked on Status: " + selectedStatus);
                    System.out.println("Clicked on Status: " + selectedStatus);
                    TestRunner.getTest().log(Status.PASS, "Testcase Passed   :  StatusS selected successfully");
                    break;
                }
            }
        }

        Actions actions = new Actions(driver);
        actions.sendKeys(Keys.ESCAPE).build().perform();

    }

    public void ApplyFilterButtonContentCollection() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm in to Click on Apply Filter Button on Content Collection Dashboard");

        if (apply_filter_button.isDisplayed() && apply_filter_button.isEnabled()) {
            apply_filter_button.click();
            System.out.println("Test Case Passed: Apply Filter Button Click Successfully");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Apply Filter Button Click Successfully");
        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Apply Filter Button is not Enable/Display");
        }
    }


    public void SearchCollectionNameReadOnlyInSearchBox() throws InterruptedException {
        System.out.println("Search Collection is: " + collectionNameForReadOnly.get());
        TestRunner.getTest().log(Status.INFO, "Search Collection is: " + collectionNameForReadOnly.get());

        WebElement right_panel = driver.findElement(By.xpath("//div[contains(@class,'right-panel')]"));
        right_panel.isDisplayed();

        try {
            WebElement searchBox = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder='Search Collections']")));
            if (searchBox.isDisplayed()) {
                searchBox.click();
                searchBox.clear();
                ((JavascriptExecutor) driver).executeScript("arguments[0].value='';", searchBox);
                Thread.sleep(2000);

                String collectionNameReadOnly = collectionNameForReadOnly.get();
                System.out.println("Search by Collections name: " + collectionNameReadOnly);
                TestRunner.getTest().log(Status.INFO, "Search by Collections name: " + collectionNameReadOnly);
                searchBox.sendKeys(collectionNameReadOnly);

                TestRunner.getTest().log(Status.INFO, "Search Collection is: " + collectionNameReadOnly);
                System.out.println("Search Collection is: " + collectionNameReadOnly);
                Actions actions = new Actions(driver);
                actions.sendKeys(Keys.ENTER).perform();


                TestRunner.getTest().log(Status.PASS, "Testcase Passed   :   Enter Search Collection Successfully");

                waitForTableToRefresh();
            } else {
                System.out.println("Search box is not displayed.");
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : Search box is not displayed.");
//                throw new RuntimeException("Search Box not  Found.");
            }
        } catch (Exception e) {
            System.out.println("Search box is not available: " + e.getMessage());
        }
    }

    private void waitForTableToRefresh() {

        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class, 'right-panel')]//tbody")));

        System.out.println("Collections Table has refreshed.");
        TestRunner.getTest().log(Status.PASS, "Testcase Passed : Collections Table has refreshed");


    }

    public void showsCollectionIntoTable() throws InterruptedException {
//        Thread.sleep(3000);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class, 'right-panel')]//tbody")));

        List<WebElement> rows = collectionTable.findElements(By.xpath(".//tbody/tr"));

        if (!rows.isEmpty()) {
            System.out.println("Collection found in the table:");
            TestRunner.getTest().log(Status.INFO, "Collection found in the table:");
            for (int i = 0; i < rows.size(); i++) {
                WebElement row = rows.get(i);

                try {
                    WebElement classNameElement = row.findElement(By.xpath(".//td[contains(@class, 'MuiTableCell-body')]//div[contains(@class,'content-collection-title')]"));
                    collectionName = classNameElement.getText();
                    System.out.println("Collection Name: " + collectionName);
                    TestRunner.getTest().log(Status.INFO, "Collection Name: " + collectionName);

                    List<WebElement> cells = row.findElements(By.xpath(".//td"));
                    for (WebElement cell : cells) {
                        System.out.print(cell.getText() + "\t");
                    }
                    System.out.println();
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed   : Collection Found in Table  Successfully");

                } catch (StaleElementReferenceException e) {
                    System.out.println("Stale element found, retrying...");

                    rows = collectionTable.findElements(By.xpath(".//tbody/tr"));
                    row = rows.get(i);

                    WebElement classNameElement = row.findElement(By.xpath(".//td[contains(@class, 'MuiTableCell-body')]//div[contains(@class,'content-collection-title')]"));
                    String className = classNameElement.getText();
                    System.out.println("Collection Name: " + className);
                    TestRunner.getTest().log(Status.INFO, "Collection Name: " + className);

                    List<WebElement> cells = row.findElements(By.xpath(".//td"));
                    for (WebElement cell : cells) {
                        System.out.print(cell.getText() + "\t");
                    }
                    System.out.println();
                    TestRunner.getTest().log(Status.PASS, "Testcase Passed   : Collection Found in Table  Successfully");
                }
            }
        } else {
            System.out.println("No searched Collection found in the table.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : No New Collection found in the table by searching");
        }
        helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());

    }


    public void verifySearchedCollectionByTitleIntoTable() {
        if (collectionName.contains(collectionNameForReadOnly.get())) {
            System.out.println("Searched Collection found");
            TestRunner.getTest().log(Status.INFO, "Searched Collection found: " + collectionNameForReadOnly.get());
            TestRunner.getTest().log(Status.PASS, "Test Case Passed   : Search Collection by Title found Successfully");

        } else {
            System.out.println("Searched Collection not found and search filter not working");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : Searched Collection not found and search filter not working");
        }
    }

    public void CollectionEllipseButton() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm in to Click Collection Ellipse Button");
        Thread.sleep(500);

        WebElement collectionEllipseDots = driver.findElement(By.xpath("//button[@aria-label='DropDownButtom']"));
        collectionEllipseDots.click();

        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//ul[@role='menu']//li")));

        List<WebElement> menuOptions = driver.findElements(By.xpath("//ul[@role='menu']//li"));

        System.out.println("Available Options in Collection Ellipse Menu For Author:");
        TestRunner.getTest().log(Status.INFO, "Available Options in Collection Ellipse Menu For Author:");
        for (WebElement option : menuOptions) {
            System.out.println(option.getText());
            TestRunner.getTest().log(Status.INFO, "Collection Ellipse Menu: " + option.getText());
        }

        helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());

        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Collection Ellipse button clicked successfully and options printed");


    }

    public void ValidateEllipseOptionForAuthor() throws InterruptedException {
        System.out.println("I'm into validate the Ellipse Options for Author");
        TestRunner.getTest().log(Status.INFO, "I'm into validate the Ellipse Options for Author");

        List<WebElement> menuOptions = driver.findElements(By.xpath("//ul[@role='menu']//li"));

        System.out.println("Validating that all options are enabled for Author:");
        TestRunner.getTest().log(Status.INFO, "Validating that all options are enabled for Author:");

        boolean allEnabled = true;

        for (WebElement option : menuOptions) {
            String optionText = option.getText();
            boolean isEnabled = option.isEnabled();

            if (isEnabled) {
                System.out.println(optionText + " Option is enabled.");
                TestRunner.getTest().log(Status.INFO, optionText + " Option is enabled.");
            } else {
                System.out.println(optionText + " Option is disabled.");
                TestRunner.getTest().log(Status.INFO, optionText + " Option is disabled.");
                allEnabled = false;
            }
        }

        if (allEnabled) {
            TestRunner.getTest().log(Status.PASS, "Testcase Passed: All menu options are enabled for Author.");
        } else {
            TestRunner.getTest().log(Status.FAIL, "Testcase Failed: Some menu options are disabled for Author.");
        }

        helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
    }


    public void assessment_dashboard() throws InterruptedException {
        System.out.println("I'm in Custom Content Module --- Assessment dashboard");
        TestRunner.getTest().log(Status.INFO, "I'm in Custom Content Module --- Assessment dashboard");

        Thread.sleep(1000);

        WebElement breadCrumbOfMyContent = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ol[contains(@class, 'MuiBreadcrumbs')]")));
        System.out.println("My Content BreadCrumb is: " + breadCrumbOfMyContent.getText());

        WebElement dropdownCourses = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class, 'selectTextFieldsWrapper')]")));
        WebElement assessmentDashboard = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class, 'AssessmentDashboardContainer')]")));
        WebElement assessmentFilter = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class, 'AssessmentDashboardLeftPanel')]")));
        WebElement assessmentTable = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class, 'AssessmentDashboardRightPanel')]")));

        if (dropdownCourses.isDisplayed() && assessmentDashboard.isDisplayed() && assessmentFilter.isDisplayed() && assessmentTable.isDisplayed()) {
            TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  Custom Content Module --- Assessment Dashboard all elements are Visible");
        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   :  Custom Content Module --- Assessment Dashboard all elements are not Visible");
        }
    }


    @FindBy(xpath = "//div[@id='Assessments-header']")
    WebElement div_Assessment;


    public void left_panel_Collections_section() throws InterruptedException {

        TestRunner.getTest().log(Status.INFO, "I'm Verify Left panel Assessment Section and Click on Collections sections");
        WebElement gridAssessmentContent = wait.until(ExpectedConditions.visibilityOf(div_Assessment));

        helper.scrollToElement(driver, gridAssessmentContent);

        WebElement btn_collections = driver.findElement(By.xpath("//div[@id='Assessments-content']//button[.//span[contains(text(), 'Collections')]]"));
        btn_collections.click();

        WebElement collectionNames = driver.findElement(By.xpath("(//div[@aria-labelledby='Assessments-header']//div[contains(@class, 'treeViewCheckbox') and contains(@class, 'false')])[3]"));
        List<WebElement> totalCollectionNames = collectionNames.findElements(By.tagName("li"));

        System.out.println("Total Collections are: " + totalCollectionNames.size());
        TestRunner.getTest().log(Status.INFO, "Total Collections are: " + totalCollectionNames.size());

        boolean collectionFound = false;

        for (WebElement typeName : totalCollectionNames) {
            // Scroll the element into view
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", typeName);
            Thread.sleep(500); // Wait for UI to load

            String collectionNameText = typeName.findElement(By.xpath(".//span[@class='text']")).getText();
            System.out.println("Collection name is: " + collectionNameText);

            if (collectionNameText.equals(collectionNameForReadOnly.get())) {
                collectionFound = true;

                WebElement checkBox = typeName.findElement(By.xpath(".//span[@role='checkbox']"));
                boolean isChecked = checkBox.isSelected();

                if (isChecked) {
                    System.out.println("Checkbox for " + collectionNameForReadOnly.get() + " is already selected.");
                    TestRunner.getTest().log(Status.INFO, "Checkbox for " + collectionNameForReadOnly.get() + " is already selected.");
                } else {
                    checkBox.click();
                    System.out.println("Checkbox for " + collectionNameForReadOnly.get() + " is now selected.");
                    TestRunner.getTest().log(Status.INFO, "Checkbox for " + collectionNameForReadOnly.get() + " is now selected.");
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed: Collection is selected successfully.");
                }
                break; // Exit loop after selecting the correct collection
            }
        }

        if (!collectionFound) {
            System.out.println("Collection name not found: " + collectionNameForReadOnly.get());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Collection name not found - " + collectionNameForReadOnly.get());
            Assert.fail("Collection name not found: " + collectionNameForReadOnly.get());
        }

    }

    public void applyFilterButtonCLick() throws InterruptedException {
        System.out.println("I'm into click on Apply Filter Button");
        TestRunner.getTest().log(Status.INFO, "I'm into click on Apply Filter Button");

        WebElement apply_filter_button = driver.findElement(By.xpath("//button[normalize-space()='Apply Filter']"));

        if (apply_filter_button.isDisplayed() && apply_filter_button.isEnabled()) {
            apply_filter_button.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Apply Filter Button Click Successfully");
        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Apply Filter button not Displayed/Enabled");
        }

    }


    public void showsCollectionAssessmentIntoTable() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm in Show Collection Assessments Into table");
        Thread.sleep(5000);
        try {
            WebElement assessmentTable = wait.until(ExpectedConditions.visibilityOf(assessmentContainerTable));

            if (assessmentTable != null) {
                List<WebElement> assessmentRows = assessmentTable.findElements(By.xpath(".//tr"));

                if (!assessmentRows.isEmpty()) {
                    System.out.println("Collection Assessment found in the table:");
                    TestRunner.getTest().log(Status.INFO, "Collection Assessment found in the table:");
                    Thread.sleep(5000);

                    boolean allRowsProcessedSuccessfully = true;

                    for (int i = 0; i < assessmentRows.size(); i++) {
                        WebElement questionRow = assessmentRows.get(i);

                        int retryCount = 0;
                        boolean success = false;

                        while (retryCount < 6) {
                            try {
                                WebElement assessmentTitleElement = questionRow.findElement(By.xpath(".//td[contains(@class, 'cell-0')]/div"));
                                assessmentsTitle = assessmentTitleElement.getText();
                                System.out.println("Assessment Title: " + assessmentsTitle);
                                TestRunner.getTest().log(Status.INFO, "Assessment Title: " + assessmentsTitle);

                                List<WebElement> assessmentTitleCells = questionRow.findElements(By.xpath(".//td"));
                                for (WebElement assessmentTitleCell : assessmentTitleCells) {
                                    System.out.print(assessmentTitleCell.getText() + "\t");
                                }
                                System.out.println();

                                success = true;
                                break;

                            } catch (StaleElementReferenceException e) {
                                System.out.println("Stale element found, retrying...");

                                assessmentRows = assessmentTable.findElements(By.xpath(".//tbody//tr"));

                                if (i >= assessmentRows.size()) {
                                    System.out.println("Row index " + i + " is out of bounds after refresh.");
                                    break;
                                }

                                questionRow = assessmentRows.get(i);
                                retryCount++;
                            } catch (NoSuchElementException e) {
                                System.out.println("Element not found in the row: " + e.getMessage());
                                break;
                            }
                        }

                        if (!success) {
                            System.out.println("Failed to retrieve Assessment row after several attempts.");
                            allRowsProcessedSuccessfully = false;
                        }
                    }

                    if (allRowsProcessedSuccessfully) {
                        TestRunner.getTest().log(Status.PASS, "Test Case Passed  : Collection Assessments Shows Into Table Successfully");
                    } else {
                        TestRunner.getTest().log(Status.FAIL, "Test Case Failed  : One or more Collection Assessment could not be processed.");
                    }
                } else {
                    TestRunner.getTest().log(Status.FAIL, "Test Case Failed  : No Collection Assessment found in the table.");
                    throw new RuntimeException("No Collection Assessment found in the table");
                }
            } else {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Collection Assessment table is not visible.");
                throw new RuntimeException("Collection Assessment table is not visible");

            }
        } catch (TimeoutException e) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Timeout waiting for table to be visible or accessible. " + e.getMessage());
        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: An unexpected error occurred. " + e.getMessage());
        }
    }


    public void SelectCollectionAssessmentToVerifyAuthorRights() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into Select Collection Assessment to Verify Right");
        System.out.println("I'm into Select Collection Assessment to Verify Right");

        WebElement questionsTable = wait.until(ExpectedConditions.visibilityOf(assessmentContainerTable));
        helper.scrollToElement(driver, questionsTable);

        if (questionsTable != null) {
            List<WebElement> questionRows = questionsTable.findElements(By.xpath(".//tr"));

            if (!questionRows.isEmpty()) {
                System.out.println("Collections Assessment found in the table:");
                TestRunner.getTest().log(Status.INFO, "Collections Assessment  found in the table:");

                // Variable to track if the cell was successfully processed
                boolean cellProcessedSuccessfully = false;

                if (questionRows.size() >= 2) { // Ensure there are at least 2 rows
                    WebElement questionRow = questionRows.get(1);  // Accessing the 2nd row (index 1)
                    int retryCount = 0;

                    while (retryCount < 6) {
                        try {
                            // Retrieve text from the 1st column in the 2nd row
                            WebElement firstColumn = questionRow.findElement(By.xpath(".//td[2]"));
                            String questionText = firstColumn.getText();
                            System.out.println("Collection Assessment Title Text in 1st column: " + questionText);
                            TestRunner.getTest().log(Status.INFO, "Collection Assessment Title Text in 1st column: " + questionText);

                            // Find the 8th column in the 2nd row
                            WebElement targetCell = questionRow.findElement(By.xpath(".//td[8]"));
                            WebElement targetButton = targetCell.findElement(By.tagName("button"));

                            // Scroll to the button if needed
                            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", targetButton);
                            Thread.sleep(500);

                            // Click the button
                            targetButton.click();
                            System.out.println("Button in 2nd row, 8th column clicked successfully.");
                            TestRunner.getTest().log(Status.INFO, "Button in 2nd row, 8th column clicked successfully.");
                            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Button in 2nd row, 8th column clicked successfully.");

                            // Set to true if successful
                            cellProcessedSuccessfully = true;
                            break;

                        } catch (StaleElementReferenceException e) {
                            System.out.println("Stale element found, retrying...");

                            questionRows = questionsTable.findElements(By.xpath(".//tr"));
                            if (questionRows.size() <= 1) {
                                System.out.println("2nd row not available after refresh.");
                                break;
                            }
                            questionRow = questionRows.get(1); // Re-access the 2nd row after refreshing
                            retryCount++;
                        } catch (NoSuchElementException e) {
                            System.out.println("8th column not found in the 2nd row: " + e.getMessage());
                            break;
                        }
                    }

                    if (cellProcessedSuccessfully) {
                        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Successfully accessed and processed the 2nd row, 8th column.");
                    } else {
                        TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Could not process the 2nd row, 8th column after several attempts.");
                    }
                } else {
                    TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Less than 2 rows found in the table.");
                }
            } else {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: No Collection Assessment found in the table.");
            }
        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Collection Assessment table is not visible.");

        }

    }


    public void ValidateDropDownOptionsForAuthor() {
        TestRunner.getTest().log(Status.INFO, "Verifying dropdown options in the 2nd row, 8th column.");
        System.out.println("Validating Preview and Publish options are enabled for Author in DropDown");

        try {
            WebElement questionsTable = wait.until(ExpectedConditions.visibilityOf(assessmentContainerTable));
            helper.scrollToElement(driver, questionsTable);

            if (questionsTable != null) {
                List<WebElement> questionRows = questionsTable.findElements(By.xpath(".//tr"));

                if (questionRows.size() >= 2) { // Ensure at least 2 rows
                    WebElement questionRow = questionRows.get(1); // 2nd row (index 1)
                    WebElement targetCell = questionRow.findElement(By.xpath(".//td[8]"));

                    // Wait for dropdown options to appear
                    WebElement previewOption = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("preview")));
                    WebElement publishOption = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("publish")));

                    boolean isPreviewEnabled = previewOption.isEnabled();
                    boolean isPublishEnabled = publishOption.isEnabled();

                    if (isPreviewEnabled && isPublishEnabled) {
                        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Preview and Publish options are enabled for Author.");
                    } else {
                        TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Preview or Publish is disabled For Author.");
                    }

                    // Verify other buttons (Edit, Copy, Delete) are disabled
                    String[] disabledOptions = {"edit", "copy", "delete"};
                    boolean allDisabled = true;

                    for (String optionId : disabledOptions) {
                        WebElement option = wait.until(ExpectedConditions.presenceOfElementLocated(By.id(optionId)));
                        boolean isDisabled = option.getAttribute("aria-disabled") != null && option.getAttribute("aria-disabled").equals("true");

                        if (!isDisabled) {
                            allDisabled = false;
                            TestRunner.getTest().log(Status.FAIL, optionId + " button is not disabled.");
                        }
                    }

                    if (allDisabled) {
                        TestRunner.getTest().log(Status.PASS, "Test Case Passed: All other buttons (Edit, Copy, Delete) are disabled.");
                    }

                } else {
                    TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Less than 2 rows found in the table.");
                }
            } else {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Assessment Collection table is not visible.");
            }
        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "An error occurred: " + e.getMessage());
        }
    }

    public void verifyTotalAssessmentCollectionCount() throws InterruptedException {
        System.out.println("I'm into Verify Total Number of Collections Assessment on Assessment Tab");
        TestRunner.getTest().log(Status.INFO, "I'm into Verify Total Number of Collections Assessment on Assessment Tab");


        WebElement countElement = driver.findElement(By.xpath("//div[@class='count']"));
        String countText = countElement.getText();
        TestRunner.getTest().log(Status.INFO, "Total Number of Collections Assessment : " + countText);
        System.out.println("Total Number of Collections Assessment : " + countText);

        // Extract the number
        int TotalCollectionAssessmentCount = Integer.parseInt(countText.replaceAll("[^0-9]", ""));
        TestRunner.getTest().log(Status.INFO, "Total Number of Collections Assessment : " + TotalCollectionAssessmentCount);
        System.out.println("Total Number of Collections Assessment " + TotalCollectionAssessmentCount);


        if (TotalCollectionAssessmentCount == storedHeaderCount) {
            TestRunner.getTest().log(Status.PASS, "Displayed count matches stored count: " + storedHeaderCount);
            System.out.println("Displayed count matches stored count: " + storedHeaderCount);
        } else {
            TestRunner.getTest().log(Status.FAIL, "Displayed count does not match stored count! Displayed: " + TotalCollectionAssessmentCount + ", Stored: " + storedHeaderCount);
            System.out.println("Displayed count does not match stored count! Displayed: " + TotalCollectionAssessmentCount + ", Stored: " + storedHeaderCount);
        }
    }


//    For other Staff Read Only Collection Rights

    public void EllipseButtonForOtherStaff() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm in to Click Collection Ellipse Button FOr Other Staff");
        Thread.sleep(500);

        WebElement collectionEllipseDots = driver.findElement(By.xpath("//button[@aria-label='DropDownButtom']"));
        collectionEllipseDots.click();

        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//ul[@role='menu']//li")));

        List<WebElement> menuOptions = driver.findElements(By.xpath("//ul[@role='menu']//li"));

        System.out.println("Available Options in Collection Ellipse Menu For Other Staff is:");
        TestRunner.getTest().log(Status.INFO, "Available Options in Collection Ellipse Menu For Other Staff Is:");
        for (WebElement option : menuOptions) {
            System.out.println(option.getText());
            TestRunner.getTest().log(Status.INFO, "Collection Ellipse Menu: " + option.getText());
        }

        helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());

        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Collection Ellipse button clicked successfully and options printed");

    }


    public void ValidateEllipseOptionForOtherStaffWithReadOnlyRights() throws InterruptedException {

        System.out.println("Validating Ellipse Options for Other Staff with Read-Only Rights...");
        TestRunner.getTest().log(Status.INFO, "Validating Ellipse Options for Other Staff with Read-Only Rights...");

        List<WebElement> menuOptions = driver.findElements(By.xpath("//ul[@role='menu']//li"));

        System.out.println("Validating that Only Preview option is enabled for Read-Only Rights:");
        TestRunner.getTest().log(Status.INFO, "Validating that Only Preview option is enabled for Read-Only Rights:");

        boolean onlyPreviewEnabled = true;

        for (WebElement option : menuOptions) {
            String optionText = option.getText().trim();
            boolean isEnabled = option.isEnabled();
            String ariaDisabled = option.getAttribute("aria-disabled");

            // Check the Preview button
            if (optionText.equalsIgnoreCase("Preview")) {
                if (isEnabled) {
                    System.out.println(optionText + " is enabled as expected for Read-Only Rights.");
                    TestRunner.getTest().log(Status.INFO, optionText + " is enabled as expected for Read-Only Rights.");
                } else {
                    System.out.println(optionText + " should be enabled but is disabled!");
                    TestRunner.getTest().log(Status.FAIL, optionText + " should be enabled but is disabled!");
                    onlyPreviewEnabled = false;
                }
            }
            // Check other options (Edit and Delete) should be disabled
            else {
                // Ensure that aria-disabled is "true" for disabled options
                if (ariaDisabled != null && ariaDisabled.equals("true")) {
                    System.out.println(optionText + " is correctly disabled and has aria-disabled='true' for Read-Only Rights.");
                    TestRunner.getTest().log(Status.INFO, optionText + " is correctly disabled and has aria-disabled='true' for Read-Only Rights.");
                } else {
                    System.out.println(optionText + " should be disabled (aria-disabled='true') but is enabled or missing the attribute!");
                    TestRunner.getTest().log(Status.FAIL, optionText + " should be disabled (aria-disabled='true') but is enabled or missing the attribute!");
                    onlyPreviewEnabled = false;
                }
            }
        }

        if (onlyPreviewEnabled) {
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Only the Preview button is enabled for Read-Only Rights, and all others are disabled.");
        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Some buttons are incorrectly enabled/disabled for Read-Only Rights.");
        }

    }

    public void ValidateDropDownOptionsForReadOnlyRights() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "Validate Only Preview Option is Enabled for Staff in DropDown For Read Only Rights");
        System.out.println("Validate Only Preview Option is Enabled for Staff in DropDown For Read Only Rights");

        try {
            WebElement questionsTable = wait.until(ExpectedConditions.visibilityOf(assessmentContainerTable));
            helper.scrollToElement(driver, questionsTable);

            if (questionsTable != null) {
                List<WebElement> questionRows = questionsTable.findElements(By.xpath(".//tr"));

                if (questionRows.size() >= 2) {
                    WebElement questionRow = questionRows.get(1);
                    WebElement targetCell = questionRow.findElement(By.xpath(".//td[8]"));

                    WebElement previewOption = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("preview")));

                    boolean isPreviewEnabled = previewOption.isEnabled();

                    if (isPreviewEnabled) {
                        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Preview options is enabled for Other Staff with Read Only Rights.");
                    } else {
                        TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Preview option is disabled For Other Staff with Read Only Rights . It should be Enabled.");
                    }

                    String[] disabledOptions = {"publish","edit", "copy", "delete"};
                    boolean allDisabled = true;

                    for (String optionId : disabledOptions) {
                        WebElement option = wait.until(ExpectedConditions.presenceOfElementLocated(By.id(optionId)));
                        boolean isDisabled = option.getAttribute("aria-disabled") != null && option.getAttribute("aria-disabled").equals("true");

                        if (!isDisabled) {
                            allDisabled = false;
                            TestRunner.getTest().log(Status.FAIL, optionId + " button is not disabled.");
                        }
                    }

                    if (allDisabled) {
                        TestRunner.getTest().log(Status.PASS, "Test Case Passed: All other buttons (Publish ,Edit, Copy, Delete) are disabled For Read Only Rights.");
                    }

                } else {
                    TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Less than 2 rows found in the table.");
                }
            } else {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Assessment Collections table is not visible.");
            }
        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "An error occurred: " + e.getMessage());
        }
    }

    public void VerifyCollectionNameMatch() throws InterruptedException{
        System.out.println("I'm Into Validate Collection Name Matches On Assessment Screen ");
        TestRunner.getTest().log(Status.INFO , "I'm Into Validate Collection Name Matches On Assessment Screen");

        String originalCollectionName = collectionNameForReadOnly.get();
        System.out.println("Original Collection Name: " + originalCollectionName);
        TestRunner.getTest().log(Status.INFO, "Original Collection Name: " + originalCollectionName);

        WebElement collectionNameOnAssessmentScreen = driver.findElement(By.xpath("//div[contains(@class, 'status-count-container')]//div[contains(@class,'title')]"));

        if (collectionNameOnAssessmentScreen.isDisplayed()) {
            String titleText = collectionNameOnAssessmentScreen.getText().trim();
            System.out.println("Collections Name On Assessment Screen: " + titleText);
            TestRunner.getTest().log(Status.INFO, "Collections Name On Assessment Screen: " + titleText);

            // Compare the values
            if (originalCollectionName.equals(titleText)) {
                System.out.println("Collection names match!");
                TestRunner.getTest().log(Status.PASS, "Collection names match.");
            } else {
                System.out.println("Original Collection Name: " + originalCollectionName + " Not Match with the Collection Name on Assessment Screen: " + titleText);
                TestRunner.getTest().log(Status.FAIL, "Collection names do NOT match. Expected: " + originalCollectionName + ", Found: " + titleText);
            }
        }

    }
}
