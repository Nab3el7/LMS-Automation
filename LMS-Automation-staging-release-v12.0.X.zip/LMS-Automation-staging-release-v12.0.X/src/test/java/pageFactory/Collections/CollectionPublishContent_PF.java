package pageFactory.Collections;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.sl.In;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

import static StepDefinitions.Collections.CollectionWithReadOnlySteps.staffName;

public class CollectionPublishContent_PF {
    WebDriverWait wait;
    WebDriver driver;
    Helper helper;
    JavascriptExecutor js;
    Actions actions;


    public CollectionPublishContent_PF(WebDriver driver) {
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        helper = new Helper();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        js = (JavascriptExecutor) driver;
        actions = new Actions(driver);
    }

    @FindBy(xpath = "//ul[@role='menu']")
    WebElement editMenu;

    public void ClickPublishButton() throws InterruptedException {
        System.out.println("I'm into Click Publish Button From Dropdown");
        TestRunner.getTest().log(Status.INFO, "I'm into click Publish Button From Dropdown");


        Thread.sleep(500);

        WebElement editDots= driver.findElement(By.xpath("//button[@aria-label='DropDownButtom']"));
        editDots.click();

        WebElement menuOptions = wait.until(ExpectedConditions.elementToBeClickable(editMenu));
        List<WebElement> optionsQuestions = menuOptions.findElements(By.xpath(".//li"));

        for (WebElement option : optionsQuestions) {
            if (option.getText().equalsIgnoreCase("Publish")) {
                if(option.isEnabled() && wait.until(ExpectedConditions.elementToBeClickable(option)) != null) {
                    option.click();
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  Edit button click successfully");

                } else {
                    TestRunner.getTest().log(Status.FAIL, "Test Case Failed  : The 'Edit' option is either not enabled or not clickable.");

                }
                break;
            }
        }

    }

    @FindBy(xpath = "(//div//table[contains(@class, 'MuiTable-root')])[2]")
    WebElement contentCollectionContainerTable;

    public String content_collection;


    public void getAllCollectionFromPublishContent() throws InterruptedException {
        System.out.println("I'm Into Get All Collection From Publish Content");
        TestRunner.getTest().log(Status.INFO, "I'm Into Get All Collection From Publish Content");

        Thread.sleep(5000);
        try {
            WebElement assessmentTable = wait.until(ExpectedConditions.visibilityOf(contentCollectionContainerTable));

            if (assessmentTable != null) {
                List<WebElement> assessmentRows = assessmentTable.findElements(By.xpath(".//tbody//tr"));

                if (!assessmentRows.isEmpty()) {
                    System.out.println("Content Collection found in the table:");
                    TestRunner.getTest().log(Status.INFO, "Content Collection found in the table:");
                    Thread.sleep(5000);

                    for (int i = 0; i < assessmentRows.size(); i++) {
                        boolean rowProcessed = false;
                        int retryCount = 0;

                        while (!rowProcessed && retryCount < 10) {
                            try {
                                // Refresh the list of rows if retrying due to a stale element
                                assessmentRows = assessmentTable.findElements(By.xpath(".//tbody//tr"));
                                if (i >= assessmentRows.size()) {
                                    System.out.println("Row index " + i + " is out of bounds after refresh.");
                                    break;
                                }
                                WebElement questionRow = assessmentRows.get(i);

                                // Locate elements within the current row using relative XPath
                                WebElement assessmentTitleElement = questionRow.findElement(By.xpath(".//td[contains(@class, 'cell-0')]/div"));
                                content_collection = assessmentTitleElement.getText();
                                System.out.println("Content Collection Title: " + content_collection);
                                TestRunner.getTest().log(Status.INFO, "Content Collection Title: " + content_collection);

                                List<WebElement> assessmentTitleCells = questionRow.findElements(By.xpath(".//td"));
                                for (WebElement assessmentTitleCell : assessmentTitleCells) {
                                    System.out.print(assessmentTitleCell.getText() + "\t");
                                }
                                System.out.println();

                                rowProcessed = true; // Successfully processed row
                            } catch (StaleElementReferenceException e) {
                                System.out.println("Stale element found, retrying... Attempt: " + (retryCount + 1));
                                retryCount++;
                            } catch (NoSuchElementException e) {
                                System.out.println("Element not found in the row: " + e.getMessage());
                                break;
                            }
                        }

                        if (!rowProcessed) {
                            System.out.println("Failed to retrieve Content Collection row after several attempts.");
                            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: One or more Content Collection could not be processed.");
                        }
                    }

                    TestRunner.getTest().log(Status.PASS, "Test Case Passed: Content Collection displayed in table successfully.");
                } else {
                    TestRunner.getTest().log(Status.FAIL, "Test Case Failed: No Content Collection found in the table.");
                    throw new RuntimeException("No Content Collection found in the table");
                }
            } else {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Content Collection table is not visible.");
                throw new RuntimeException("Content Collection table is not visible");
            }
        } catch (TimeoutException e) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Timeout waiting for table to be visible. " + e.getMessage());
        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: An unexpected error occurred. " + e.getMessage());
        }
    }

    public void ClickAddExistingButtonOnPublishContentPrompt() throws InterruptedException{

        System.out.println("I'm into click on Add Existing Button ");
        TestRunner.getTest().log(Status.INFO, "I'm into click on Add Existing Button");

        WebElement addExistingBtn= driver.findElement(By.xpath("//button[normalize-space()='Add Existing']"));

        if (addExistingBtn.isEnabled() && addExistingBtn.isDisplayed()){
            addExistingBtn.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Add Existing Button click Successfully");
            System.out.println("Add Existing Button click Successfully");
        }else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Add Existing Button Is Not Displayed/Enabled");
            System.out.println("Add Existing Button Is Not Displayed/Enabled");
        }
    }
    @FindBy(xpath = "//label[text()='Select Collection']/following-sibling::div//div[@role='button' or @role='combobox']")
    WebElement dropDown_Select_Collection;

    public String SelectedContentCollectionName;

    public void validateAndSelectCollectionFromDropdown() {
        TestRunner.getTest().log(Status.INFO, "Select Collection From Dropdown");

        WebElement saveBtn = driver.findElement(By.xpath("//button[normalize-space()='Save']"));

        helper.scrollToElement(driver,saveBtn);

        try {
            dropDown_Select_Collection.click();

            WebElement listOrganization = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[contains(@role, 'listbox')]")));

            List<WebElement> optionsOrganization = listOrganization.findElements(By.xpath(".//li"));

            System.out.println("Total options in the Select Collection dropdown: " + optionsOrganization.size());

            if (optionsOrganization.isEmpty()) {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: No options found in the Select Collection dropdown");
                throw new RuntimeException("No Select Collection found in dropdown");
            }

            // 🔹 **Filter options containing "CollectionPublishRights _"**
            List<WebElement> filteredOptions = optionsOrganization.stream()
                    .filter(option -> option.getText().contains("CollectionPublishRights __"))
                    .collect(Collectors.toList());

            if (filteredOptions.isEmpty()) {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: No options contain 'CollectionPublishRights __'");
                throw new RuntimeException("No matching options found in dropdown");
            }

            // 🔹 **Select a random filtered option**
            Random random = new Random();
            WebElement selectedOption = filteredOptions.get(random.nextInt(filteredOptions.size()));

            SelectedContentCollectionName = selectedOption.getText();
            selectedOption.click();

            System.out.println("Selected Collection: " + SelectedContentCollectionName);
            TestRunner.getTest().log(Status.INFO, "Selected Collection is: " + SelectedContentCollectionName);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Select Collection selected successfully");

        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "No Value found in Select Collection dropdown ");
        }
    }



    public void clickSaveButton() throws InterruptedException{
        System.out.println("I'm into click on Save Button");
        TestRunner.getTest().log(Status.INFO, "I'm into click on Save Button");

//        WebElement saveBtn= driver.findElement(By.xpath("//button[normalize-space()='Save']"));
//
//        if (saveBtn.isDisplayed() && saveBtn.isEnabled()){
//            saveBtn.click();
//            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Save Button click Successfully");
//            System.out.println("Save Button click Successfully");
//        }else {
//            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Save Button Is Not Displayed/Enabled");
//            System.out.println("Save Button Is Not Displayed/Enabled");
//        }


        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

// Wait for the overlay to disappear
        wait.until(ExpectedConditions.invisibilityOfElementLocated(By.className("MuiBackdrop-root")));

        WebElement saveBtn = driver.findElement(By.xpath("//button[normalize-space()='Save']"));

// Scroll into view
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", saveBtn);

// Attempt to click
        try {
            saveBtn.click();
        } catch (ElementClickInterceptedException e) {
            // If click still gets intercepted, use JavaScript click
            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", saveBtn);
        }


    }


    public void searchCollectionInWhichContentPublish() throws InterruptedException {
        System.out.println("I'm into search collection in which content is published: " +  SelectedContentCollectionName);
        TestRunner.getTest().log(Status.INFO, "I'm into search collection in which content is published: " +  SelectedContentCollectionName);

        WebElement right_panel = driver.findElement(By.xpath("//div[contains(@class,'right-panel')]"));
        right_panel.isDisplayed();

        try {
            WebElement searchBox = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder='Search Collections']")));
            if (searchBox.isDisplayed()) {
                searchBox.click();
                searchBox.clear();
                ((JavascriptExecutor) driver).executeScript("arguments[0].value='';", searchBox);
                Thread.sleep(2000);

                String collectionNameReadOnly = SelectedContentCollectionName;
                System.out.println("Search by Collections name: " + collectionNameReadOnly);
                TestRunner.getTest().log(Status.INFO, "Search by Collections name: " + collectionNameReadOnly);
                searchBox.sendKeys(collectionNameReadOnly);

                TestRunner.getTest().log(Status.INFO, "Search Collection is: " + collectionNameReadOnly);
                System.out.println("Search Collection is: " + collectionNameReadOnly);
                Actions actions = new Actions(driver);
                actions.sendKeys(Keys.ENTER).perform();


                TestRunner.getTest().log(Status.PASS, "Testcase Passed   :   Enter Search Collection Successfully");

                waitForTableToRefresh();
            } else {
                System.out.println("Search box is not displayed.");
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : Search box is not displayed.");
//                throw new RuntimeException("Search Box not  Found.");
            }
        } catch (Exception e) {
            System.out.println("Search box is not available: " + e.getMessage());
        }
    }

    private void waitForTableToRefresh() {

        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class, 'right-panel')]//tbody")));

        System.out.println("Collections Table has refreshed.");
        TestRunner.getTest().log(Status.PASS, "Testcase Passed : Collections Table has refreshed");

    }


    public String collectionName;

    @FindBy(xpath = "//div[contains(@class, 'right-panel')]")
    WebElement collectionTable;

    public void VerifyShowsCollectionIntoTable() throws InterruptedException {
//        Thread.sleep(3000);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class, 'right-panel')]//tbody")));

        List<WebElement> rows = collectionTable.findElements(By.xpath(".//tbody/tr"));

        if (!rows.isEmpty()) {
            System.out.println("Collection found in the table:");
            TestRunner.getTest().log(Status.INFO, "Collection found in the table:");
            for (int i = 0; i < rows.size(); i++) {
                WebElement row = rows.get(i);

                try {
                    WebElement classNameElement = row.findElement(By.xpath(".//td[contains(@class, 'MuiTableCell-body')]//div[contains(@class,'content-collection-title')]"));
                    collectionName = classNameElement.getText();
                    System.out.println("Collection Name: " + collectionName);
                    TestRunner.getTest().log(Status.INFO, "Collection Name: " + collectionName);

                    List<WebElement> cells = row.findElements(By.xpath(".//td"));
                    for (WebElement cell : cells) {
                        System.out.print(cell.getText() + "\t");
                    }
                    System.out.println();
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed   : Collection Found in Table  Successfully");

                } catch (StaleElementReferenceException e) {
                    System.out.println("Stale element found, retrying...");

                    rows = collectionTable.findElements(By.xpath(".//tbody/tr"));
                    row = rows.get(i);

                    WebElement classNameElement = row.findElement(By.xpath(".//td[contains(@class, 'MuiTableCell-body')]//div[contains(@class,'content-collection-title')]"));
                    String className = classNameElement.getText();
                    System.out.println("Collection Name: " + className);
                    TestRunner.getTest().log(Status.INFO, "Collection Name: " + className);

                    List<WebElement> cells = row.findElements(By.xpath(".//td"));
                    for (WebElement cell : cells) {
                        System.out.print(cell.getText() + "\t");
                    }
                    System.out.println();
                    TestRunner.getTest().log(Status.PASS, "Testcase Passed   : Collection Found in Table  Successfully");
                }
            }
        } else {
            System.out.println("No searched Collection found in the table.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : No New Collection found in the table by searching");
        }
        helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());

    }


    public void verifySearchedCollectionByTitleIntoTable() {
        if (collectionName.contains(SelectedContentCollectionName)) {
            System.out.println("Searched Collection found");
            TestRunner.getTest().log(Status.INFO, "Searched Collection found: " + SelectedContentCollectionName);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed   : Search Collection by Title found Successfully");

        } else {
            System.out.println("Searched Collection not found and search filter not working");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : Searched Collection not found and search filter not working");
        }
    }


    public void clickEditButton() throws InterruptedException{
        System.out.println("I'm Into Click on Edit Option From Dropdown Menu");
        TestRunner.getTest().log(Status.INFO,"I'm Into Click on Edit Option From Dropdown Menu");

        WebElement editOption = driver.findElement(By.id("edit"));

        if (editOption.isDisplayed() && editOption.isEnabled()) {
            editOption.click();
            System.out.println("Edit option clicked successfully.");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed:  Edit option clicked successfully.");
        } else {
            System.out.println("Edit option is either not visible or disabled.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed:  Edit option is not Enabled/Displayed.");
        }
    }


    @FindBy(xpath = "//div[contains(@class, 'right-panel')]//tbody")
    WebElement assessmentContainerTable;


    public void VerifyAndSearchQuestionInSearchBox() throws InterruptedException {
        System.out.println("I'm into Search Question in Collection To Verify Publish Rights " +  titleForCopyRandomQuestion);
        TestRunner.getTest().log(Status.INFO, "I'm into Search Question in Collection To Verify Publish Rights: " +  titleForCopyRandomQuestion);

        try {
            WebElement searchBox = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder='Search question by keyword']")));
            if (searchBox.isDisplayed()) {
                searchBox.click();
                searchBox.clear();
                ((JavascriptExecutor) driver).executeScript("arguments[0].value='';", searchBox);
                Thread.sleep(2000);

                String collectionNameReadOnly = titleForCopyRandomQuestion;
                System.out.println("Search by Question By Keyword: " + collectionNameReadOnly);
                TestRunner.getTest().log(Status.INFO, "Search by Question By Keyword: " + collectionNameReadOnly);
                searchBox.sendKeys(collectionNameReadOnly);

                TestRunner.getTest().log(Status.INFO, "Search Collection is: " + collectionNameReadOnly);
                System.out.println("Search Collection is: " + collectionNameReadOnly);
                Actions actions = new Actions(driver);
                actions.sendKeys(Keys.ENTER).perform();


                TestRunner.getTest().log(Status.PASS, "Testcase Passed   :   Enter Search Collection Successfully");

                waitForTableToRefreshForQuestion();
            } else {
                System.out.println("Search box is not displayed.");
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : Search box is not displayed.");
//                throw new RuntimeException("Search Box not  Found.");
            }
        } catch (Exception e) {
            System.out.println("Search box is not available: " + e.getMessage());
        }
    }

    private void waitForTableToRefreshForQuestion() {

        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//table[contains(@class, 'MuiTable-root')]//tbody//tr")));

        System.out.println("Collections Table For Questions has refreshed.");
        TestRunner.getTest().log(Status.PASS, "Testcase Passed : Collections Table For Questions has refreshed");

    }


    public void VerifyQuestionTitleMatchWithPublishQuestionTitle() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Verifying Question Title Match With Published Question Title");
        System.out.println("Verifying Question Title Match With Published Question Title");

        String publishQuestionTitle = titleForCopyRandomQuestion;
        System.out.println("Publish Question Title From Questions Screen: " + publishQuestionTitle);
        TestRunner.getTest().log(Status.INFO, "Publish Question Title From Questions Screen: " + publishQuestionTitle);

        Thread.sleep(2000);
        // Locate the table body
        WebElement tableBody = driver.findElement(By.xpath("//table[contains(@class, 'MuiTable-root')]//tbody"));

        boolean isMatchFound = false;  // Flag to track if a match is found
        int retryCount = 0;

        while (retryCount < 5) { // Retry up to 5 times in case of a stale element issue
            try {
                // Retrieve the rows again in each loop iteration to avoid stale elements
                List<WebElement> rows = tableBody.findElements(By.xpath(".//tr"));

                for (WebElement row : rows) {
                    // Get the question title from the first column (td[1])
                    String questionTitleFromTable = row.findElement(By.xpath(".//td[1]")).getText();

                    System.out.println("Question Title From Table: " + questionTitleFromTable);
                    TestRunner.getTest().log(Status.INFO, "Question Title From Table: " + questionTitleFromTable);

                    // Compare with the selected question
                    if (questionTitleFromTable.contains(titleForCopyRandomQuestion)) {
                        System.out.println("Match Found: " + questionTitleFromTable);
                        TestRunner.getTest().log(Status.PASS, "Question Title: " + questionTitleFromTable + " matches successfully.");
                        TestRunner.getTest().log(Status.PASS, "Publish Rights Verify Successfully");
                        isMatchFound = true;
                        break; // Exit loop once match is found
                    }
                }

                if (!isMatchFound) {
                    System.out.println("No matching question title found.");
                    TestRunner.getTest().log(Status.FAIL, "No matching question title found for: " + titleForCopyRandomQuestion);
                }

                break; // Exit while loop if execution is successful

            } catch (StaleElementReferenceException e) {
                System.out.println("Stale element encountered, retrying... Attempt: " + (retryCount + 1));
                retryCount++;

                // Re-locate the table body before retrying
                tableBody = driver.findElement(By.xpath("//table[contains(@class, 'MuiTable-root')]//tbody"));
            }
        }

    }

    @FindBy(xpath = "//div[contains(@class, 'QuestionDashboardContainer')]//tbody")
    WebElement questionsContainerTable;

    public String questionName;


    public void showsQuestionsIntoTable() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm in Show Questions Into table");
        Thread.sleep(5000);
        try {
            WebElement questionsTable = wait.until(ExpectedConditions.visibilityOf(questionsContainerTable));

            if (questionsTable != null) {
                List<WebElement> questionRows = questionsTable.findElements(By.xpath(".//tr"));

                if (!questionRows.isEmpty()) {
                    System.out.println("Questions found in the table:");
                    TestRunner.getTest().log(Status.INFO, "Questions found in the table:");
                    Thread.sleep(5000);

                    boolean allRowsProcessedSuccessfully = true;

                    for (int i = 0; i < questionRows.size(); i++) {
                        WebElement questionRow = questionRows.get(i);

                        int retryCount = 0;
                        boolean success = false;

                        while (retryCount < 6) {
                            try {
                                WebElement questionNameElement = questionRow.findElement(By.xpath(".//td[contains(@class, 'cell-0')]"));
                                questionName = questionNameElement.getText();
                                System.out.println("Question Name: " + questionName);
                                TestRunner.getTest().log(Status.INFO, "Question Name: " + questionName);

                                List<WebElement> questionNameCells = questionRow.findElements(By.xpath(".//td"));
                                for (WebElement questionNameCell : questionNameCells) {
                                    System.out.print(questionNameCell.getText() + "\t");
                                }
                                System.out.println();

                                success = true;
                                break;

                            } catch (StaleElementReferenceException e) {
                                System.out.println("Stale element found, retrying...");

                                questionRows = questionsTable.findElements(By.xpath(".//tbody//tr"));

                                if (i >= questionRows.size()) {
                                    System.out.println("Row index " + i + " is out of bounds after refresh.");
                                    break;
                                }

                                questionRow = questionRows.get(i);
                                retryCount++;
                            } catch (NoSuchElementException e) {
                                System.out.println("Element not found in the row: " + e.getMessage());
                                break;
                            }
                        }

                        if (!success) {
                            System.out.println("Failed to retrieve question row after several attempts.");
                            allRowsProcessedSuccessfully = false;
                        }
                    }

                    if (allRowsProcessedSuccessfully) {
                        TestRunner.getTest().log(Status.PASS, "Test Case Passed  : Question Shows Into Table Successfully");
                    } else {
                        TestRunner.getTest().log(Status.FAIL, "Test Case Failed  : One or more questions could not be processed.");
                    }
                } else {
                    TestRunner.getTest().log(Status.FAIL, "Test Case Failed  : No questions found in the table.");
                    throw new RuntimeException("No questions found in the table");
                }
            } else {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Questions table is not visible.");
                throw new RuntimeException("Questions table is not visible");

            }
        } catch (TimeoutException e) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Timeout waiting for table to be visible or accessible. " + e.getMessage());
        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: An unexpected error occurred. " + e.getMessage());
        }
    }

    public void copyQuestion() throws InterruptedException{

        TestRunner.getTest().log(Status.INFO, "Verifying dropdown options in the 2nd row, 8th column.");
        System.out.println("Validating Copy  options are enabled in DropDown");

        try {
            WebElement questionsTable = wait.until(ExpectedConditions.visibilityOf(assessmentContainerTable));
            helper.scrollToElement(driver, questionsTable);

            if (questionsTable != null) {
                List<WebElement> questionRows = questionsTable.findElements(By.xpath(".//tr"));

                if (questionRows.size() >= 2) { // Ensure at least 2 rows
                    WebElement questionRow = questionRows.get(0); // 2nd row (index 1)
                    WebElement targetCell = questionRow.findElement(By.xpath(".//td[8]"));
                    WebElement targetButton = targetCell.findElement(By.tagName("button"));

                    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", targetButton);
                    Thread.sleep(2000);

                    targetButton.click();

                    // Wait for dropdown options to appear
                    WebElement previewOption = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("copy")));

                    boolean isPreviewEnabled = previewOption.isEnabled();

                    if (isPreviewEnabled) {
                        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Copy options is enabled.");
                    } else {
                        TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Copy options is disabled.");
                    }

                    // Verify other buttons (Edit, Copy, Delete) are disabled
                    String[] disabledOptions = {"publish","edit", "delete"};
                    boolean allDisabled = true;

                    for (String optionId : disabledOptions) {
                        WebElement option = wait.until(ExpectedConditions.presenceOfElementLocated(By.id(optionId)));
                        boolean isDisabled = option.getAttribute("aria-disabled") != null && option.getAttribute("aria-disabled").equals("true");

                        if (!isDisabled) {
                            allDisabled = false;
                            TestRunner.getTest().log(Status.FAIL, optionId + " button is not disabled.");
                        }
                    }

                    if (allDisabled) {
                        TestRunner.getTest().log(Status.PASS, "Test Case Passed: All other buttons (Edit, Copy, Delete) are disabled.");
                    }

                } else {
                    TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Less than 2 rows found in the table.");
                }
            } else {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Assessment Collection table is not visible.");
            }
        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "An error occurred: " + e.getMessage());
        }
    }


    public void selectCopyOption() throws InterruptedException{
        System.out.println("I'm into click on Copy Option From Dropdown");
        TestRunner.getTest().log(Status.INFO, "I'm into click on Copy Option From Dropdown");


        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

// Wait for the Publish button to be visible and clickable
        WebElement publishButton = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//span[normalize-space()='Copy']")));

// Click on the Publish button
        publishButton.click();

        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Publish Button Click successfully");

    }

    @FindBy(xpath = "//div[@aria-labelledby='customized-dialog-title']")
    WebElement customizedDialogTitle;

    public String titleForCopyRandomQuestion;

    public void CopyQuestionModalBox() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm into Add title for Copy Question");
        System.out.println("I'm into Add title for Copy Question");

        WebElement promptCopyQuestion = wait.until(ExpectedConditions.elementToBeClickable(customizedDialogTitle));

        if(promptCopyQuestion.isDisplayed() && promptCopyQuestion.isEnabled()){
            WebElement TitleForCopyQuestion = promptCopyQuestion.findElement(By.xpath("//input[contains(@id, 'TextFieldInput')]"));
            TitleForCopyQuestion.click();

            titleForCopyRandomQuestion = "AutoCopyQuestion " + new Date();
            System.out.println("Generated Title: " + titleForCopyRandomQuestion);
            TitleForCopyQuestion.sendKeys(titleForCopyRandomQuestion);
            WebElement btnSaveYes = promptCopyQuestion.findElement(By.xpath(".//button[normalize-space()='Save']"));

            if(btnSaveYes.isEnabled()){
                btnSaveYes.click();
                TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  Copy Question successfully");
            }
        }

    }

    @FindBy(xpath = "//label[normalize-space(text())='Status']/following-sibling::div//div[@role='button' or @role='combobox']")
    WebElement statusDropdown;

    public void SelectQuestionStatus() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm Select New Question Status");
        wait.until(ExpectedConditions.elementToBeClickable(statusDropdown));
        statusDropdown.click();
        Thread.sleep(3000);

        List<WebElement> QuestionStatusOptions = driver.findElements(By.xpath("//ul[@role='listbox']//li"));

        System.out.println("Available Question Status Options:");
        for (WebElement option : QuestionStatusOptions) {
            System.out.println(option.getText());
        }

        for (WebElement option : QuestionStatusOptions) {
            if (option.getText().equalsIgnoreCase("Active")) {
                option.click();
                System.out.println("Selected " + option.getText() + " status");
                break;
            }
        }
        TestRunner.getTest().log(Status.PASS, "Test Case Passed   : New question status selected successfully");
    }

    @FindBy(xpath = "//div[contains(@class, 'QuestionDashboardContainer')]//div[contains(@class, 'right-panel')]")
    WebElement questionsContainerRightPanel;
    public String searchQuestionByName;


    public void searchQuestionByName(){
        TestRunner.getTest().log(Status.INFO, "Search Question By Name");
        WebElement right_panel= wait.until(ExpectedConditions.elementToBeClickable(questionsContainerRightPanel));
        right_panel.isDisplayed();

        try {
            WebElement questionSearchBox = right_panel.findElement(By.xpath("//input[@placeholder='Search Questions']"));
            if (questionSearchBox.isDisplayed() && questionSearchBox.isEnabled()) {
                questionSearchBox.click();
                questionSearchBox.clear();
                ((JavascriptExecutor) driver).executeScript("arguments[0].value='';", questionSearchBox);
                searchQuestionByName = titleForCopyRandomQuestion;
                System.out.println("Search by question name: " + searchQuestionByName);
                TestRunner.getTest().log(Status.INFO, "Search by question name: " + searchQuestionByName);
                questionSearchBox.sendKeys(searchQuestionByName);

                Actions actions = new Actions(driver);
                actions.sendKeys(Keys.ENTER).perform();

                waitForTableToRefreshForQuestions();
                TestRunner.getTest().log(Status.PASS, "Test Case Passed  : Search question Successfully");
            } else {
                System.out.println("Search box is not displayed.");
            }
        } catch (Exception e) {
            System.out.println("Search box is not available: " + e.getMessage());
        }
    }

    private void waitForTableToRefreshForQuestions() throws InterruptedException{
        try {
            WebElement questionsTable = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class, 'QuestionDashboardContainer')]//tbody")));

            List<WebElement> rowsBeforeRefresh = questionsTable.findElements(By.xpath(".//tr"));
            System.out.println("Number of rows before refresh: " + rowsBeforeRefresh.size());

            Thread.sleep(2000);

            List<WebElement> rowsAfterRefresh = questionsTable.findElements(By.xpath(".//tr"));
            System.out.println("Number of rows after refresh: " + rowsAfterRefresh.size());

            if (rowsBeforeRefresh.size() != rowsAfterRefresh.size()) {
                System.out.println("Table has refreshed. Number of rows before refresh: " + rowsBeforeRefresh.size() + ", after refresh: " + rowsAfterRefresh.size());
                TestRunner.getTest().log(Status.INFO, "Table has refreshed. Number of rows before refresh: " + rowsBeforeRefresh.size() + ", after refresh: " + rowsAfterRefresh.size());
            } else {
                System.out.println("Table did not refresh as expected. Rows before: " + rowsBeforeRefresh.size() + ", Rows after: " + rowsAfterRefresh.size());
            }

            for (WebElement row : rowsAfterRefresh) {
                System.out.println("Table Row: " + row.getText());
            }

        } catch (NoSuchElementException | TimeoutException e) {
            try {
                WebElement noDataFound = driver.findElement(By.xpath("//div[contains(@class, 'QuestionDashboardContainer')]//div[contains(text(),'No Detail Found')]"));
                String statusHaveNoData = noDataFound.getText();
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: 'No Detail Found' message is displayed as expected. " + statusHaveNoData);
                System.out.println("Test Case Passed: 'No Detail Found' message is displayed. " + statusHaveNoData);
            } catch (NoSuchElementException nestedException) {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Neither table data nor 'No Detail Found' message found.");
                System.out.println("Test Case Failed: Neither table data nor 'No Detail Found' message found.");
            }
        }
    }


    public void verifySearchedQuestionByNameIntoTable(){
        if (questionName.contains(searchQuestionByName)){
            TestRunner.getTest().log(Status.INFO, "Search by question name into table: " + searchQuestionByName);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed  : Searched question found Successfully");
        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed  : Searched question not found and search filter not working");
        }
    }


    public void ValidateAndSelectMyQuestionFilter() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "Select Question Custom Filter");
        Thread.sleep(2000);


        WebElement filterContainer = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@aria-labelledby='Questions-header']")));


        WebElement btnMyQuestions = filterContainer.findElement(By.xpath("//button[@value = 'myQuestions']"));
        wait.until(ExpectedConditions.elementToBeClickable(btnMyQuestions));
        btnMyQuestions.click();
        Thread.sleep(2000);


        WebElement typeMyQuestions = driver.findElement(By.xpath("(//div[@aria-labelledby='Questions-header']//div[contains(@class, 'treeViewCheckbox') and contains(@class, 'false')])[2]"));
        List<WebElement> allCheckboxes = typeMyQuestions.findElements(By.xpath(".//span[@role='checkbox']"));

        System.out.println("Total Question Type checkboxes found: " + allCheckboxes.size());
        TestRunner.getTest().log(Status.INFO, "Total Question Type checkboxes found: " + allCheckboxes.size());


        for (WebElement checkBox : allCheckboxes) {
            wait.until(ExpectedConditions.elementToBeClickable(checkBox));

            boolean isChecked = checkBox.isSelected();

            if (!isChecked) {
                checkBox.click();
                Thread.sleep(500);
                System.out.println("Checkbox selected.");
                TestRunner.getTest().log(Status.INFO, "Checkbox selected.");
            } else {
                System.out.println("Checkbox already selected.");
                TestRunner.getTest().log(Status.INFO, "Checkbox already selected.");
            }
        }

        TestRunner.getTest().log(Status.PASS, "Test Case Passed: All checkboxes selected successfully");

    }

}
