package pageFactory.Collections;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.Date;
import java.util.List;
import java.util.Random;

public class CollectionInactiveStatusProcess_PF {
    WebDriverWait wait;
    WebDriver driver;
    Helper helper;
    JavascriptExecutor js;
    Actions actions;



    public CollectionInactiveStatusProcess_PF (WebDriver driver) {
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        helper = new Helper();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        js = (JavascriptExecutor) driver;
        actions = new Actions(driver);
    }

    public static final String BASE_NAME = Configurations.getDotEnv().get("SITE_COLLECTION_NAME_FOR_INACTIVE_STATUS");


    public static ThreadLocal<String> collectionNameForInactiveStatus = ThreadLocal.withInitial(() -> "");


    public void ValidateAndEnterCollectionTitleForInactiveStatus() throws InterruptedException {

        System.out.println("I'm into Enter Collection Title For Inactive Collection");
        TestRunner.getTest().log(Status.INFO, "I'm in to Enter Collection  Inactive Collection");

        WebElement collectionTitleField = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//input[@placeholder='Collection Title' and @name='name']")
        ));

        collectionTitleField.click();

        String collectionName = BASE_NAME + " __" + new Date();
        setCollectionName(collectionName);

        System.out.println("Enter Collection Title Successfully: " + collectionNameForInactiveStatus.get());
        collectionTitleField.sendKeys(collectionNameForInactiveStatus.get());
        TestRunner.getTest().log(Status.INFO, "Collection title: " + collectionNameForInactiveStatus.get());

    }

    public static void setCollectionName(String assignmentName) {
        collectionNameForInactiveStatus.set(assignmentName);
    }

    public static String getAssignmentName() {
        return collectionNameForInactiveStatus.get();
    }

    @FindBy(xpath = "//button[@id='btn-previous']")
    WebElement btn_previous;

    public void ClickOnPreviousButton() throws InterruptedException{
        Thread.sleep(2000);

        System.out.println("I'm into Click on Previous Button");
        TestRunner.getTest().log(Status.INFO, "I'm in to Click on Previous Button");

        if (btn_previous.isDisplayed()) {
            btn_previous.click();
            TestRunner.getTest().log(Status.PASS, "Testcase Passed   :  Previous button clicked successfully");
        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Failed: Previous Button is Not Display/Enable");
        }

    }

    @FindBy(xpath = "//label[text()='Status']/following-sibling::div//div[@role='button' or @role='combobox']")
    WebElement dropDown_Status;

    public String selectedStatusInactive;

    public void SelectInactiveStatusStepI() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into selecting Inactive Status For Collection");
        System.out.println("I'm into selecting Inactive Status For Collection");

        dropDown_Status.click();

        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//ul[@role='listbox']//li")));
        List<WebElement> ClassStatusOptions = driver.findElements(By.xpath("//ul[@role='listbox']//li"));

        System.out.println("Available Status Options For Collection:");
        for (WebElement option : ClassStatusOptions) {
            System.out.println(option.getText());
        }

        for (WebElement option : ClassStatusOptions) {
            if (option.getText().equalsIgnoreCase("Inactive")) {
                selectedStatusInactive = option.getText();
                option.click();
                System.out.println("Selected: " + selectedStatusInactive + " status");
                break;
            }
        }

        System.out.println("Stored Selected Status: " + selectedStatusInactive);
        TestRunner.getTest().log(Status.PASS, "Test Case Passed: In-Active status '" + selectedStatusInactive + "' selected successfully for Collection");
    }

    @FindBy(xpath = "//label[text()='Collection Level']/following-sibling::div//div[@role='button' or @role='combobox']")
    WebElement collection_level;
    public String selectedCollectionLevelInActiveCollection;

    public void SelectCollectionLevelFromDropdown() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into selecting Collection Level For Publish Rights");
        System.out.println("I'm into selecting Collection Level For Publish Rights");

        collection_level.click();

        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//ul[@role='listbox']//li")));
        List<WebElement> ClassStatusOptions = driver.findElements(By.xpath("//ul[@role='listbox']//li"));

        System.out.println("Available Collection Level Options For Collection:");
        for (WebElement option : ClassStatusOptions) {
            System.out.println(option.getText());
        }

        for (WebElement option : ClassStatusOptions) {
            if (option.getText().equalsIgnoreCase("Teacher Level")) {
                selectedCollectionLevelInActiveCollection = option.getText(); // Store the selected level
                option.click();
                System.out.println("Selected: " + selectedCollectionLevelInActiveCollection + " collection level");
                break;
            }
        }

        // Log or use selectedLevel later
        System.out.println("Stored Selected Level: " + selectedCollectionLevelInActiveCollection);
        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Collection Level '" + selectedCollectionLevelInActiveCollection + "' selected successfully");
    }

    @FindBy(xpath = "(//label[normalize-space()='District Filter']/parent::div)")
    WebElement district_filter;

    public String selectedDistrictForInactiveCollection;


    public void validateAndSelectDistrictFilterForInactiveCollection() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into select District Filter For Publish Right Collection");
        System.out.println("I'm into select District Filter For Publish Right Collection");

        district_filter.click();

        WebElement listDistrict = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[contains(@role, 'listbox')]")));
        List<WebElement> optionsDistrict = listDistrict.findElements(By.xpath(".//li"));

        System.out.println("District List is: " + optionsDistrict.size());

        if (optionsDistrict.isEmpty()) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: No options found in the  District dropdown");
            System.out.println("No options found in the District dropdown.");
            throw new RuntimeException("No District Value found in dropdown");

        } else {
            System.out.println("District Filter:");

            for (WebElement district : optionsDistrict) {
                System.out.println(district.getText());
            }
            if (!optionsDistrict.isEmpty()) {
                Random random = new Random();
                int randomCourse = random.nextInt(optionsDistrict.size());
                WebElement selectedOption = optionsDistrict.get(randomCourse);
                selectedDistrictForInactiveCollection = selectedOption.getText();
                selectedOption.click();
                System.out.println("Selected District: " + selectedDistrictForInactiveCollection);
                TestRunner.getTest().log(Status.INFO, "Selected District is: " + selectedDistrictForInactiveCollection);
                TestRunner.getTest().log(Status.PASS, "Test Case Passed:  District Filter select successfully");
            }
        }
    }

    public String selectedSchoolForInactiveCollection;
    @FindBy(xpath = "(//label[normalize-space()='Select School']/parent::div)[2]")
    WebElement dropDown_School;

    public void SelectSchoolForInactiveCollection() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into select School from Staff Selection Prompt");
        System.out.println("I'm into select School from Staff Selection Prompt");

        // Click on the dropdown to expand it
        dropDown_School.click();

        // Wait until the dropdown options are visible
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//ul[@role='listbox']//li")));
        List<WebElement> ClassStatusOptions = driver.findElements(By.xpath("//ul[@role='listbox']//li"));

        // Print all available school options
        System.out.println("Available School Options For Collection:");
        for (WebElement option : ClassStatusOptions) {
            System.out.println(option.getText());
        }

        // Initialize a variable to store the selected school

        // Iterate through options and select the desired school
        for (WebElement option : ClassStatusOptions) {
            if (option.getText().equalsIgnoreCase("Florida ES")) {
                option.click();
                selectedSchoolForInactiveCollection = option.getText(); // Store the selected school
                System.out.println("Selected: " + selectedSchoolForInactiveCollection + " School");
                break;
            }
        }

        // Check if a school was successfully selected
        if (selectedSchoolForInactiveCollection != null) {
            TestRunner.getTest().log(Status.PASS, "Test Case Passed   : School selected successfully - " + selectedSchoolForInactiveCollection);
        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : Desired school not found in the dropdown.");
            throw new NoSuchElementException("Desired school not found in the dropdown.");
        }
    }

    @FindBy(xpath = "//label[normalize-space()='Select District']/parent::div")
    WebElement filter_select_district;

    @FindBy(xpath = "//div[contains(@class,'left-panel')]")
    WebElement left_Panel;

    @FindBy(xpath = "//label[normalize-space()='Select School']/parent::div")
    WebElement filter_select_school;

    @FindBy(xpath = "//label[normalize-space()='Levels']/parent::div")
    WebElement filter_select_levels;

    @FindBy(xpath = "//div[contains(text(),'Status')]/following-sibling::div//div[@role='button' or @role='combobox']")
    WebElement filter_select_status;



    public void FilterVerificationForInactiveCollectionOnContentCollection() throws InterruptedException {
        TestRunner.startTest(" Filter Verification For Inactive Collection on Content Collection Dashboard");
        TestRunner.getTest().log(Status.INFO, "Filter Verification For Inactive Collection on Content Collection Dashboard");

        Thread.sleep(100);
        left_Panel.isDisplayed();

        select_DistrictFilter(selectedDistrictForInactiveCollection);
        select_SchoolFilter(selectedSchoolForInactiveCollection);
        select_statusFilter(selectedStatusInactive);
        select_LevelFilter(selectedCollectionLevelInActiveCollection);
        TestRunner.getTest().log(Status.INFO, "All Filters Information Filled successfully");
    }


    public void select_DistrictFilter(String selectedDistrictForInactiveCollection) {
        TestRunner.getTest().log(Status.INFO, "I'm in to select District on Content Collection Dashboard");
        filter_select_district.click();
        WebElement listDistrict = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//ul[@role='listbox']")));

        List<WebElement> optionsDistrict = listDistrict.findElements(By.xpath(".//li"));

        System.out.println("District List is: " + optionsDistrict.size());

        if (optionsDistrict.isEmpty()) {
            System.out.println("No options found in the District dropdown.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : No options found in the District dropdown.");

        } else {
            System.out.println("District:");

            for (WebElement district : optionsDistrict) {
                System.out.println(district.getText());
                if (district.getText().equals(selectedDistrictForInactiveCollection)) {
                    district.click();
                    TestRunner.getTest().log(Status.INFO, "Clicked on District: " + selectedDistrictForInactiveCollection);
                    System.out.println("Clicked on District: " + selectedDistrictForInactiveCollection);
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  District selected successfully");
                    break;
                }
            }
        }

        Actions actions = new Actions(driver);
        actions.sendKeys(Keys.ESCAPE).build().perform();

    }

    public void select_SchoolFilter(String selectedSchoolForInactiveCollection) throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm in to select School on Content Collection Dashboard");
        filter_select_school.click();

        WebElement listSchool = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//ul[@role='listbox']")));

        List<WebElement> optionsSchool = listSchool.findElements(By.xpath(".//li"));

        System.out.println("District List is: " + optionsSchool.size());

        if (optionsSchool.isEmpty()) {
            System.out.println("No options found in the School dropdown.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : No options found in the School dropdown.");

        } else {
            System.out.println("School:");

            for (WebElement school : optionsSchool) {
                System.out.println(school.getText());
                if (school.getText().equals(selectedSchoolForInactiveCollection)) {
                    school.click();
                    TestRunner.getTest().log(Status.INFO, "Clicked on School: " + selectedSchoolForInactiveCollection);
                    System.out.println("Clicked on School: " + selectedSchoolForInactiveCollection);
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  School selected successfully");
                    break;
                }
            }
        }

        Actions actions = new Actions(driver);
        actions.sendKeys(Keys.ESCAPE).build().perform();

    }

    public void select_LevelFilter(String selectedCollectionLevelInActiveCollection) throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm in to select Level on Content Collection Dashboard");
        filter_select_levels.click();

        WebElement listLevel = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//ul[@role='listbox']")));

        List<WebElement> optionsLevels = listLevel.findElements(By.xpath(".//li"));

        System.out.println("Levels List is: " + optionsLevels.size());

        if (optionsLevels.isEmpty()) {
            System.out.println("No options found in the Levels dropdown.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : No options found in the Levels dropdown.");

        } else {
            System.out.println("Levels:");

            for (WebElement levels : optionsLevels) {
                System.out.println(levels.getText());
                if (levels.getText().equals(selectedCollectionLevelInActiveCollection)) {
                    levels.click();
                    TestRunner.getTest().log(Status.INFO, "Clicked on Level: " + selectedCollectionLevelInActiveCollection);
                    System.out.println("Clicked on Level: " + selectedCollectionLevelInActiveCollection);
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  Level selected successfully");
                    break;
                }
            }
        }

        Actions actions = new Actions(driver);
        actions.sendKeys(Keys.ESCAPE).build().perform();
    }

    public void select_statusFilter(String selectedStatusInactive) throws InterruptedException {

        TestRunner.getTest().log(Status.INFO, "I'm in to select Status on Content Collection Dashboard");
        filter_select_status.click();

        WebElement listLevel = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//ul[@role='listbox']")));

        List<WebElement> optionsLevels = listLevel.findElements(By.xpath(".//li"));

        System.out.println("Status List is: " + optionsLevels.size());

        if (optionsLevels.isEmpty()) {
            System.out.println("No options found in the Status dropdown.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : No options found in the Status dropdown.");

        } else {
            System.out.println("Status:");

            for (WebElement levels : optionsLevels) {
                System.out.println(levels.getText());
                if (levels.getText().equals(selectedStatusInactive)) {
                    levels.click();
                    TestRunner.getTest().log(Status.INFO, "Clicked on Status: " + selectedStatusInactive);
                    System.out.println("Clicked on Status: " + selectedStatusInactive);
                    TestRunner.getTest().log(Status.PASS, "Testcase Passed   :  StatusS selected successfully");
                    break;
                }
            }
        }

        Actions actions = new Actions(driver);
        actions.sendKeys(Keys.ESCAPE).build().perform();

    }




    public void SearchCollectionNameWithInactiveStatusInSearchBox() throws InterruptedException {
        System.out.println("Search Collection is: " + collectionNameForInactiveStatus.get());
        TestRunner.getTest().log(Status.INFO, "Search Collection is: " + collectionNameForInactiveStatus.get());

        WebElement right_panel = driver.findElement(By.xpath("//div[contains(@class,'right-panel')]"));
        right_panel.isDisplayed();

        try {
            WebElement searchBox = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder='Search Collections']")));
            if (searchBox.isDisplayed()) {
                searchBox.click();
                searchBox.clear();
                ((JavascriptExecutor) driver).executeScript("arguments[0].value='';", searchBox);
                Thread.sleep(2000);

                String collectionNameReadOnly = collectionNameForInactiveStatus.get();
                System.out.println("Search by Collections name: " + collectionNameReadOnly);
                TestRunner.getTest().log(Status.INFO, "Search by Collections name: " + collectionNameReadOnly);
                searchBox.sendKeys(collectionNameReadOnly);

                TestRunner.getTest().log(Status.INFO, "Search Collection is: " + collectionNameReadOnly);
                System.out.println("Search Collection is: " + collectionNameReadOnly);
                Actions actions = new Actions(driver);
                actions.sendKeys(Keys.ENTER).perform();


                TestRunner.getTest().log(Status.PASS, "Testcase Passed   :   Enter Search Collection Successfully");

                waitForTableToRefresh();
            } else {
                System.out.println("Search box is not displayed.");
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : Search box is not displayed.");
//                throw new RuntimeException("Search Box not  Found.");
            }
        } catch (Exception e) {
            System.out.println("Search box is not available: " + e.getMessage());
        }
    }

    private void waitForTableToRefresh() {

        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class, 'right-panel')]//tbody")));

        System.out.println("Collections Table has refreshed.");
        TestRunner.getTest().log(Status.PASS, "Testcase Passed : Collections Table has refreshed");


    }


    public String collectionName;

    @FindBy(xpath = "//div[contains(@class, 'right-panel')]")
    WebElement collectionTable;

    public void showsCollectionIntoTable() throws InterruptedException {
//        Thread.sleep(3000);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class, 'right-panel')]//tbody")));

        List<WebElement> rows = collectionTable.findElements(By.xpath(".//tbody/tr"));

        if (!rows.isEmpty()) {
            System.out.println("Collection found in the table:");
            TestRunner.getTest().log(Status.INFO, "Collection found in the table:");
            for (int i = 0; i < rows.size(); i++) {
                WebElement row = rows.get(i);

                try {
                    WebElement classNameElement = row.findElement(By.xpath(".//td[contains(@class, 'MuiTableCell-body')]//div[contains(@class,'content-collection-title')]"));
                    collectionName = classNameElement.getText();
                    System.out.println("Collection Name: " + collectionName);
                    TestRunner.getTest().log(Status.INFO, "Collection Name: " + collectionName);

                    List<WebElement> cells = row.findElements(By.xpath(".//td"));
                    for (WebElement cell : cells) {
                        System.out.print(cell.getText() + "\t");
                    }
                    System.out.println();
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed   : Collection Found in Table  Successfully");

                } catch (StaleElementReferenceException e) {
                    System.out.println("Stale element found, retrying...");

                    rows = collectionTable.findElements(By.xpath(".//tbody/tr"));
                    row = rows.get(i);

                    WebElement classNameElement = row.findElement(By.xpath(".//td[contains(@class, 'MuiTableCell-body')]//div[contains(@class,'content-collection-title')]"));
                    String className = classNameElement.getText();
                    System.out.println("Collection Name: " + className);
                    TestRunner.getTest().log(Status.INFO, "Collection Name: " + className);

                    List<WebElement> cells = row.findElements(By.xpath(".//td"));
                    for (WebElement cell : cells) {
                        System.out.print(cell.getText() + "\t");
                    }
                    System.out.println();
                    TestRunner.getTest().log(Status.PASS, "Testcase Passed   : Collection Found in Table  Successfully");
                }
            }
        } else {
            System.out.println("No searched Collection found in the table.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : No New Collection found in the table by searching");
        }
        helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());

    }


    public void verifySearchedCollectionByTitleIntoTable() {
        if (collectionName.contains(collectionNameForInactiveStatus.get())) {
            System.out.println("Searched Collection found");
            TestRunner.getTest().log(Status.INFO, "Searched Collection found: " + collectionNameForInactiveStatus.get());
            TestRunner.getTest().log(Status.PASS, "Test Case Passed   : Search Collection by Title found Successfully");

        } else {
            System.out.println("Searched Collection not found and search filter not working");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : Searched Collection not found and search filter not working");
        }
    }


    @FindBy(xpath = "//div[@id='Questions-header']")
    WebElement div_Questions;


    public void left_panel_Collections_section_In_Questions() throws InterruptedException {

        TestRunner.getTest().log(Status.INFO, "I'm Verify Left panel Question Section and Click on Collections sections");
        WebElement gridQuestionsContent = wait.until(ExpectedConditions.visibilityOf(div_Questions));

        helper.scrollToElement(driver, gridQuestionsContent);

        WebElement btn_collections = driver.findElement(By.xpath("//div[@id='Questions-content']//button[.//span[contains(text(), 'Collections')]]"));
        btn_collections.click();

        WebElement collectionNames = driver.findElement(By.xpath("(//div[@aria-labelledby='Questions-header']//div[contains(@class, 'treeViewCheckbox') and contains(@class, 'false')])[3]"));
        List<WebElement> totalCollectionNames = collectionNames.findElements(By.tagName("li"));

        System.out.println("Total Collections are: " + totalCollectionNames.size());
        TestRunner.getTest().log(Status.INFO, "Total Collections are: " + totalCollectionNames.size());

        boolean collectionFound = false;

        for (WebElement typeName : totalCollectionNames) {
            // Scroll the element into view
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", typeName);
            Thread.sleep(500); // Wait for UI to load

            String collectionNameText = typeName.findElement(By.xpath(".//span[@class='text']")).getText();
            System.out.println("Collection name is: " + collectionNameText);

            if (collectionNameText.equals(collectionNameForInactiveStatus.get())) {
                collectionFound = true;

                WebElement checkBox = typeName.findElement(By.xpath(".//span[@role='checkbox']"));
                boolean isChecked = checkBox.isSelected();

                if (isChecked) {
                    System.out.println("Checkbox for " + collectionNameForInactiveStatus.get() + " is already selected.");
                    TestRunner.getTest().log(Status.INFO, "Checkbox for " + collectionNameForInactiveStatus.get() + " is already selected.");
                } else {
                    checkBox.click();
                    System.out.println("Checkbox for " + collectionNameForInactiveStatus.get() + " is now selected.");
                    TestRunner.getTest().log(Status.INFO, "Checkbox for " + collectionNameForInactiveStatus.get() + " is now selected.");
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed: Inactive Collection is Found And selected successfully.");
                }
                break; // Exit loop after selecting the correct collection
            }
        }

        if (!collectionFound) {
            System.out.println("Collection name not found: " + collectionNameForInactiveStatus.get());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Inactive Collection name not found - " + collectionNameForInactiveStatus.get());
            Assert.fail("Collection name not found: " + collectionNameForInactiveStatus.get());
        }

    }


    public void SelectFilterToValidateInactiveCollectionIsNotInActiveCollection() throws InterruptedException{

        TestRunner.startTest(" Select Filter To Validate Inactive Collection is not In Active Collection");
        TestRunner.getTest().log(Status.INFO, "Select Filter To Validate Inactive Collection is not In Active Collection");

        Thread.sleep(100);
        left_Panel.isDisplayed();

        select_DistrictFilter(selectedDistrictForInactiveCollection);
        select_SchoolFilter(selectedSchoolForInactiveCollection);
        select_ActiveStatusFilter();
        select_LevelFilter(selectedCollectionLevelInActiveCollection);
        TestRunner.getTest().log(Status.INFO, "All Filters Information Filled successfully");
    }

    public String ActiveStatus;

    public void select_ActiveStatusFilter() {
        TestRunner.getTest().log(Status.INFO, "Select Active Status ");
        System.out.println("I'm into select Active Status");

        filter_select_status.click();

        WebElement listLevel = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//ul[@role='listbox']")));

        List<WebElement> optionsLevels = listLevel.findElements(By.xpath(".//li"));

        System.out.println("Status List is: " + optionsLevels.size());

        System.out.println("Available Status Options For Collection:");
        for (WebElement option : optionsLevels) {
            System.out.println(option.getText());
        }

        for (WebElement option : optionsLevels) {
            if (option.getText().equalsIgnoreCase("Active")) {
                ActiveStatus = option.getText();
                option.click();
                System.out.println("Selected: " + ActiveStatus + " status");
                break;
            }
        }

        System.out.println("Stored Selected Status: " + ActiveStatus);
        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Active status '" + ActiveStatus + "' selected successfully for Collection");
    }


    public void ValidateInactiveCollectionInActiveCollectionInTable() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Verifying That Inactive Collection is not found in Active Collection List.");

        System.out.println("I'm Into Verifying That Inactive Collection is not found in Active Collection List");
        TestRunner.getTest().log(Status.INFO, "I'm Into Verifying That Inactive Collection is not found in Active Collection List");

        try {
            WebElement noDetailsMessage = driver.findElement(By.xpath("//div[contains(text(), 'No Detail Found')]"));

            if (noDetailsMessage.isDisplayed()) {
                System.out.println("No Detail Found message is displayed. InActive Collection is not Found in Active Collection List.");
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: InActive Collection is not Found in Active Collection List.");
            } else {
                System.out.println("No Detail Found message is NOT displayed. InActive Collection is Found in Active Collection List.");
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: InActive Collection is Found in Active Collection List.");
                Assert.fail("InActive Collection is Found in Active Collection List.");
            }
        } catch (NoSuchElementException e) {
            System.out.println("No Detail Found message is NOT displayed. InActive Collection is Still Found in Active Collection List");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: InActive Collection is Found in Active Collection List.");
            Assert.fail("InActive Collection is Found in Active Collection List.");
        }
    }

}
