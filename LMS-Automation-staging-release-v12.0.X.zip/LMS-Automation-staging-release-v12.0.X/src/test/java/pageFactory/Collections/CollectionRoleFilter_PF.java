package pageFactory.Collections;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

import static StepDefinitions.Collections.CollectionWithReadOnlySteps.staffName;
import static pageFactory.StudentsModule.ReadNewStdInfo_PF.updatedEmail;
import static pageFactory.StudentsModule.ReadNewStdInfo_PF.updatedName;

public class CollectionRoleFilter_PF {

    WebDriverWait wait;
    WebDriver driver;
    Helper helper;
    JavascriptExecutor js;
    Actions actions;



    public CollectionRoleFilter_PF(WebDriver driver) {
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        helper = new Helper();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        js = (JavascriptExecutor) driver;
        actions = new Actions(driver);
    }

    @FindBy(xpath = "//table[contains(@class, 'MuiTable-root')]//tbody//tr")
    WebElement questionsContainerTable;

    private void waitForTableToRefresh() throws InterruptedException{
        try {
            WebElement questionsTable = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//table[contains(@class, 'MuiTable-root')]//tbody")));

            List<WebElement> rowsBeforeRefresh = questionsTable.findElements(By.xpath(".//tr"));
            System.out.println("Number of rows before refresh: " + rowsBeforeRefresh.size());

            Thread.sleep(2000);

            List<WebElement> rowsAfterRefresh = questionsTable.findElements(By.xpath(".//tr"));
            System.out.println("Number of rows after refresh: " + rowsAfterRefresh.size());

            System.out.println("Table refresh. Rows before: " + rowsBeforeRefresh.size() + ", Rows after: " + rowsAfterRefresh.size());
            TestRunner.getTest().log(Status.INFO, "Table refresh. Rows before: " + rowsBeforeRefresh.size() + ", Rows after: " + rowsAfterRefresh.size());

            for (WebElement row : rowsAfterRefresh) {
                System.out.println("Table Row: " + row.getText());
                TestRunner.getTest().log(Status.INFO, " Table Row: "+ row.getText());
            }

        } catch (NoSuchElementException | TimeoutException e) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: No Data Found In Table.");
            System.out.println("Test Case Failed: Test Case Failed: No Data Found In Table.");
        }
    }

    public void filterRoleOnStaffMembers() throws InterruptedException {
        System.out.println("I'm Into Apply Role Filter on Staff Members");
        TestRunner.getTest().log(Status.INFO, "I'm Into Apply Role Filter on Staff Members");

        String[] statusArray = {"Campus Admin", "Teacher"};

        for (String status : statusArray) {
            TestRunner.getTest().log(Status.INFO, "Filtering Role For Staff : " + status);

            try {
                WebElement statusDropdown = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(@class, 'MuiSelect-select') and @role='button' or @role='combobox'])[3]")));
                statusDropdown.click();

                List<WebElement> statusOptions = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//ul[@role='listbox']//li")));
                boolean statusFound = false;

                for (WebElement option : statusOptions) {
                    String optionText = option.getText().trim();
                    if (optionText.equalsIgnoreCase(status)) {
                        option.click();
                        statusFound = true;
                        TestRunner.getTest().log(Status.INFO, "Selected Role: " + optionText);
                        break;
                    }
                }

                if (!statusFound) {
                    TestRunner.getTest().log(Status.FAIL, "Role not found in the dropdown: " + status);
                    throw new RuntimeException("Role not found in the dropdown: " + status);
                }

                Thread.sleep(2000);

                // Check if "Selected User: 0" appears
                WebElement selectedUserText = driver.findElement(By.xpath("//div[contains(@class,'headingstyle')]"));
                String userCount = selectedUserText.getText().trim();

                if (userCount.equalsIgnoreCase("Selected User: 0")) {
                    System.out.println("We have no records for the filter: " + status);
                    TestRunner.getTest().log(Status.INFO, "We have no records for the filter: " + status);
                    driver.navigate().refresh();
                    Thread.sleep(3000);
                    continue; // Skip checking the table and move to the next filter
                }

                waitForTableToRefresh();

                // Check if pagination exists
                List<WebElement> paginationButtons = driver.findElements(By.xpath("//button[contains(@aria-label, 'Go to page')]"));
                boolean isPaginationPresent = !paginationButtons.isEmpty();

                if (isPaginationPresent) {
                    TestRunner.getTest().log(Status.INFO, "Pagination detected. Iterating through pages...");
                    verifyStatusOnAllPages(status);
                } else {
                    TestRunner.getTest().log(Status.INFO, "No pagination detected. Verifying records on the current page...");
                    verifyStatusOnCurrentPage(status);
                }
                driver.navigate().refresh();

            } catch (NoSuchElementException e) {
                TestRunner.getTest().log(Status.WARNING, "Table did not load in the current timeframe: " + e.getMessage());
            }
        }
    }


    public void verifyStatusOnAllPages(String status) throws InterruptedException {
        boolean hasNextPage = true;

        while (hasNextPage) {
            verifyStatusOnCurrentPage(status);

            try {
                WebElement btnNextPage = driver.findElement(By.xpath("//button[@aria-label='Go to next page']"));
                if (btnNextPage.isEnabled()) {
                    btnNextPage.click();
                    TestRunner.getTest().log(Status.INFO, "Navigating to the next page.");
                    Thread.sleep(2000);
                } else {
                    hasNextPage = false;
                    TestRunner.getTest().log(Status.INFO, "Reached the last page.");
                }
            } catch (NoSuchElementException e) {
                hasNextPage = false;
                TestRunner.getTest().log(Status.INFO, "Reached the last page.");
            }
        }
    }

    public void verifyStatusOnCurrentPage(String status) {
        WebElement questionsTable = wait.until(ExpectedConditions.visibilityOf(questionsContainerTable));
        List<WebElement> questionRows = questionsTable.findElements(By.xpath(".//tr"));

        boolean allRowsMatchStatus = true;

        for (WebElement row : questionRows) {
            WebElement secondColumnCell = row.findElement(By.xpath(".//td[2]")); // Extract second column
            String columnText = secondColumnCell.getText().trim();

            if (!columnText.equalsIgnoreCase(status)) {
                allRowsMatchStatus = false;
                System.out.println("Row second column is: " + columnText);
                TestRunner.getTest().log(Status.FAIL, "Mismatch found in second column: " + columnText);
            } else {
                TestRunner.getTest().log(Status.INFO, "Second column matches selected status: " + columnText);
            }
        }

        if (allRowsMatchStatus) {
            TestRunner.getTest().log(Status.PASS, "All rows in the second column match the selected status: " + status);
        } else {
            TestRunner.getTest().log(Status.FAIL, "Some rows in the second column do not match the selected status: " + status);
        }
    }

    @FindBy(xpath = "(//label[normalize-space()='Role']/parent::div)[2]")
    WebElement roleDropdown;

    public void selectCampusAdmin() throws InterruptedException{
        System.out.println("I'm into select Campus Admin From Dropdown option");
        TestRunner.getTest().log(Status.INFO, "I'm into select Campus Admin From Dropdown option");

            roleDropdown.click();

            wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//ul[@role='listbox']//li")));
            List<WebElement> ClassStatusOptions = driver.findElements(By.xpath("//ul[@role='listbox']//li"));

            System.out.println("Available Role Options For Collection:");
            for (WebElement option : ClassStatusOptions) {
                System.out.println(option.getText());
            }

            for (WebElement option : ClassStatusOptions) {
                if (option.getText().equalsIgnoreCase("Campus Admin")) {
                    option.click();
                    System.out.println("Selected: " + option.getText() + " Role");
                    break;
                }
            }
            TestRunner.getTest().log(Status.PASS, "Test Case Passed   : Role 'Campus Admin' selected successfully for Collection");

    }

    public void selectTeacherDropdown() throws InterruptedException{
        System.out.println("I'm into select Teacher From Dropdown option");
        TestRunner.getTest().log(Status.INFO, "I'm into select Teacher From Dropdown option");

        roleDropdown.click();

        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//ul[@role='listbox']//li")));
        List<WebElement> ClassStatusOptions = driver.findElements(By.xpath("//ul[@role='listbox']//li"));

        System.out.println("Available Role Options For Collection:");
        for (WebElement option : ClassStatusOptions) {
            System.out.println(option.getText());
        }

        for (WebElement option : ClassStatusOptions) {
            if (option.getText().equalsIgnoreCase("Teacher")) {
                option.click();
                System.out.println("Selected: " + option.getText() + " Role");
                break;
            }
        }
        TestRunner.getTest().log(Status.PASS, "Test Case Passed   : Role  'Teacher' selected successfully for Collection");

    }

    public void ClickSaveButtonToSaveData() throws InterruptedException{
        System.out.println("Click On Save Button To Save Data on StepIII");
        TestRunner.getTest().log(Status.INFO, "Click On Save Button To Save Data on StepIII");

        WebElement save_btn= driver.findElement(By.xpath("//div[@class='controls-container']//button[@id='btn-saveNext']"));

        if (save_btn.isDisplayed() && save_btn.isEnabled()){
            save_btn.click();
            System.out.println("Test Case Passed: Save Button click successfully");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Save Button Click Successfully");
        }else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Save Button is not displayed/Enabled");
        }
    }


    public void ChangeActiveStatusToArchiveStatus() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into Change Publish Status For Questions");
        System.out.println("I'm into Change Publish Status For Questions ");

        WebElement stdTable = driver.findElement(By.xpath("//table[contains(@class, 'MuiTable-root')]"));
        List<WebElement> rows = stdTable.findElements(By.xpath(".//tbody/tr"));

        // Limit to first 3 rows
        int maxRows = Math.min(3, rows.size());  // Ensure we don't go beyond available rows

        // Iterate over the first 3 rows in the table
        for (int i = 0; i < maxRows; i++) {
            WebElement row = rows.get(i);

            // Get the question title (assuming it's in the first column)
            WebElement studentCell = row.findElement(By.xpath(".//td[1]"));
            String questionTitle = studentCell.getText().trim();
            System.out.println("Question Title: " + questionTitle);
            TestRunner.getTest().log(Status.INFO, "Question Title: " + questionTitle);

            // Retrieve the status from the 4th column (dropdown)
            WebElement publishedCell = row.findElement(By.xpath(".//td[4]//div[contains(@class, 'MuiSelect-select')]"));
            String studentEmail = publishedCell.getText().trim();
            System.out.println("Published Status: " + studentEmail);
            TestRunner.getTest().log(Status.INFO, "Published Status: " + studentEmail);

            // Change the status from Active to Archived
            ChangeStudentStatusFromActiveToInActive(row);
            Thread.sleep(1000);

        }
    }

    public void ChangeStudentStatusFromActiveToInActive(WebElement row) throws InterruptedException {
        Thread.sleep(3000);
        TestRunner.getTest().log(Status.INFO, "I'm into change Status From Active to Archive");
        System.out.println("I'm into change Status From Active to Archive");

        // First, locate the 4th column in the current row
        WebElement statusColumn = row.findElement(By.xpath(".//td[4]"));

        // Now, locate the dropdown inside the 4th column
        WebElement dropdown = statusColumn.findElement(By.xpath(".//div[@role='button' or @role='combobox' and @aria-haspopup='listbox']"));

        if (dropdown.isDisplayed() && dropdown.isEnabled()) {
            helper.scrollToElement(driver, dropdown);
            dropdown.click();  // Click to open the dropdown
            System.out.println("Dropdown in the 4th column clicked successfully.");
            TestRunner.getTest().log(Status.PASS, "Dropdown in the 4th column clicked successfully.");

            // Wait for the options to appear and select the "Archived" option
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

            // Locate and click the "Archived" option
            WebElement archivedOption = wait.until(ExpectedConditions.elementToBeClickable(
                    By.xpath("//li//span[text()='Archived']")
            ));
            archivedOption.click();  // Select the "Archived" option
            System.out.println("Archived option selected successfully.");
            TestRunner.getTest().log(Status.INFO, "Archived option selected successfully");
            TestRunner.getTest().log(Status.PASS, "Archived option selected successfully.");
        } else {
            System.out.println("Dropdown is not clickable in the 4th column.");
            TestRunner.getTest().log(Status.FAIL, "Dropdown is not clickable in the 4th column.");
        }
    }

    public void statusFilterOnAssociatedContent() throws InterruptedException{
        System.out.println("Select Status Filter For Associated Content");
        TestRunner.getTest().log(Status.INFO, "Select Status Filter For Associated Content");

        driver.navigate().refresh();
        Thread.sleep(1000);

        String[] statusArray = {"Active", "Archived"};

        for (String status : statusArray) {
            TestRunner.getTest().log(Status.INFO, "Filtering Status For Associated Content : " + status);

            try {
                WebElement statusDropdown = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(@class, 'MuiSelect-select') and @role='button' or @role='combobox'])[2]")));
                statusDropdown.click();

                List<WebElement> statusOptions = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//ul[@role='listbox']//li")));
                boolean statusFound = false;

                for (WebElement option : statusOptions) {
                    String optionText = option.getText().trim();
                    if (optionText.equalsIgnoreCase(status)) {
                        option.click();
                        statusFound = true;
                        TestRunner.getTest().log(Status.INFO, "Selected Status: " + optionText);
                        break;
                    }
                }

                if (!statusFound) {
                    TestRunner.getTest().log(Status.FAIL, "Status not found in the dropdown: " + status);
                    throw new RuntimeException("Status not found in the dropdown: " + status);
                }

                Thread.sleep(2000);

                waitForTableToRefresh();

                // Check if pagination exists
                List<WebElement> paginationButtons = driver.findElements(By.xpath("//button[contains(@aria-label, 'Go to page')]"));
                boolean isPaginationPresent = !paginationButtons.isEmpty();

                if (isPaginationPresent) {
                    TestRunner.getTest().log(Status.INFO, "Pagination detected. Iterating through pages...");
                    verifyStatusInTable(status);
                } else {
                    TestRunner.getTest().log(Status.INFO, "No pagination detected. Verifying records on the current page...");
                    currentPageVerifyStatus(status);
                }
                driver.navigate().refresh();

            } catch (NoSuchElementException e) {
                TestRunner.getTest().log(Status.WARNING, "Table did not load in the current timeframe: " + e.getMessage());
            }
        }
    }


    public void verifyStatusInTable(String status) throws InterruptedException {
        boolean hasNextPage = true;

        while (hasNextPage) {
            currentPageVerifyStatus(status);

            try {
                WebElement btnNextPage = driver.findElement(By.xpath("//button[@aria-label='Go to next page']"));
                if (btnNextPage.isEnabled()) {
                    btnNextPage.click();
                    TestRunner.getTest().log(Status.INFO, "Navigating to the next page.");
                    Thread.sleep(2000);
                } else {
                    hasNextPage = false;
                    TestRunner.getTest().log(Status.INFO, "Reached the last page.");
                }
            } catch (NoSuchElementException e) {
                hasNextPage = false;
                TestRunner.getTest().log(Status.INFO, "Reached the last page.");
            }
        }
    }

    public void currentPageVerifyStatus(String status) {
        WebElement questionsTable = wait.until(ExpectedConditions.visibilityOf(questionsContainerTable));
        List<WebElement> questionRows = questionsTable.findElements(By.xpath(".//tr"));

        boolean allRowsMatchStatus = true;

        for (WebElement row : questionRows) {
            WebElement fourthColumnCell = row.findElement(By.xpath(".//td[4]")); // Extract second column
            String columnText = fourthColumnCell.getText().trim();

            if (!columnText.equalsIgnoreCase(status)) {
                allRowsMatchStatus = false;
                System.out.println("Row second column is: " + columnText);
                TestRunner.getTest().log(Status.FAIL, "Mismatch found in Fourth column: " + columnText);
            } else {
                TestRunner.getTest().log(Status.INFO, "Fourth column matches selected status: " + columnText);
            }
        }

        if (allRowsMatchStatus) {
            TestRunner.getTest().log(Status.PASS, "All rows in the Fourth column match the selected status: " + status);
        } else {
            TestRunner.getTest().log(Status.FAIL, "Some rows in the Fourth column do not match the selected status: " + status);
        }
    }
}

