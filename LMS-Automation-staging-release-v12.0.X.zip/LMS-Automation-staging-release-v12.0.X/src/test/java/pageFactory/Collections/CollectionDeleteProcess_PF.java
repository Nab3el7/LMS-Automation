package pageFactory.Collections;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

import static pageFactory.Collections.CollectionWithPublishRights_PF.collectionNameForPublishRights;

public class CollectionDeleteProcess_PF {

    WebDriverWait wait;
    WebDriver driver;
    Helper helper;
    JavascriptExecutor js;
    Actions actions;



    public CollectionDeleteProcess_PF(WebDriver driver) {
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        helper = new Helper();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        js = (JavascriptExecutor) driver;
        actions = new Actions(driver);
    }

    public void ClickDeleteOptionFromDropdown() throws InterruptedException{
        System.out.println("I'm into Click on Delete Option From Dropdown");
        TestRunner.getTest().log(Status.INFO, "I'm into Click on Delete Option From Dropdown");


        WebElement deleteOption = driver.findElement(By.xpath("//span[normalize-space()='Delete']"));

        if (deleteOption.isDisplayed() && deleteOption.isEnabled()) {
            deleteOption.click();
            System.out.println("Delete option clicked successfully.");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed:  Delete option clicked successfully.");
        } else {
            System.out.println("Delete option is either not visible or disabled.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed:  Delete option is not Enabled/Displayed.");
        }
    }

    public void VerifyDeleteDialogPrompt() {
        System.out.println("I'm into verify Delete Content-Collection Prompt");
        TestRunner.getTest().log(Status.INFO, "I'm into verify Delete Content-Collection Prompt");

        WebElement prompt = driver.findElement(By.xpath("//div[@role='dialog']"));
        boolean isDisplayed = prompt.isDisplayed();
        Assert.assertTrue("Prompt is not displayed.", isDisplayed);

        WebElement promptHeader = prompt.findElement(By.tagName("h2"));
        String headerText = promptHeader.getText();
        System.out.println("Prompt header text is: " + headerText);
        TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  Prompt Display Successfully");
    }

    public void verifyCollectionNameOnDeleteCollectionPrompt() throws InterruptedException{
        System.out.println("I'm into Verify Collection Name On Delete Collection Prompt");
        TestRunner.getTest().log(Status.INFO,"I'm into Verify Collection Name On Delete Collection Prompt");

        String collectionNameAtTimeOfCreation= CollectionWithPublishRights_PF.collectionNameForPublishRights.get();
        System.out.println("collection Name At Time Of Creation: " + collectionNameAtTimeOfCreation);
        TestRunner.getTest().log(Status.INFO, "collection Name At Time Of Creation: " + collectionNameAtTimeOfCreation);

        WebElement nameOnPrompt= driver.findElement(By.xpath("//span[@class='collectionName']"));

        String nameOfCollection= nameOnPrompt.getText();
        System.out.println("collection Name On Delete Prompt: " + nameOfCollection);
        TestRunner.getTest().log(Status.INFO, "collection Name On Delete Prompt: " + nameOfCollection);

        if (nameOfCollection.equals(collectionNameAtTimeOfCreation)){
            System.out.println("Test Case Passed: Collection Name Match on Delete Content Collection");

            TestRunner.getTest().log(Status.INFO, "Collection Name At Time Of Creation:" + collectionNameAtTimeOfCreation + " Matches with Collection Name On Delete Prompt: " + nameOfCollection);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Collection Name Match on Delete Content Collection");

        }else {
            TestRunner.getTest().log(Status.INFO, "Collection Name At Time Of Creation:" + collectionNameAtTimeOfCreation + " Not Matches with Collection Name On Delete Prompt: " + nameOfCollection);
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Collection Name Not Match on Delete Content Collection");

        }

    }

    public void clickYesButton() {
        System.out.println("I'm into Click on Yes Button");
        TestRunner.getTest().log(Status.INFO,"I'm into Click on Yes Button");

        WebElement yesOption = driver.findElement(By.xpath("//button[normalize-space()='Yes']"));

        if (yesOption.isDisplayed() && yesOption.isEnabled()) {
            yesOption.click();
            System.out.println("Yes option clicked successfully.");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed:  Yes option clicked successfully.");
        } else {
            System.out.println("Yes option is either not visible or disabled.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed:  Yes option is not Enabled/Displayed.");
        }
    }

    @FindBy(xpath = "//div[@id='Questions-header']")
    WebElement div_Questions;

    public void VerifyDeleteCollectionInQuestionsUnderCollectionSection() throws InterruptedException {

        System.out.println("I'm Into Verify That Delete Collection Is Not Found In Associated Content Collection List");
        TestRunner.getTest().log(Status.INFO, "I'm Into Verify That Delete Collection Is Not Found In Associated Content Collection List");

        String CollectionDeleteByAuthor= CollectionWithPublishRights_PF.collectionNameForPublishRights.get();

        System.out.println("Collection That Is Deleted By Author: " + CollectionDeleteByAuthor);
        TestRunner.getTest().log(Status.INFO, "Collection That Is Deleted By Author: " + CollectionDeleteByAuthor);


        WebElement gridQuestionsContent = wait.until(ExpectedConditions.visibilityOf(div_Questions));

        helper.scrollToElement(driver, gridQuestionsContent);

        WebElement btn_collections = driver.findElement(By.xpath("//div[@id='Questions-content']//button[.//span[contains(text(), 'Collections')]]"));
        btn_collections.click();

        WebElement collectionNames = driver.findElement(By.xpath("(//div[@aria-labelledby='Questions-header']//div[contains(@class, 'treeViewCheckbox') and contains(@class, 'false')])[3]"));
        List<WebElement> totalCollectionNames = collectionNames.findElements(By.tagName("li"));

        System.out.println("Total Collections are: " + totalCollectionNames.size());
        TestRunner.getTest().log(Status.INFO, "Total Collections are: " + totalCollectionNames.size());

        boolean collectionFound = false;

        for (WebElement typeName : totalCollectionNames) {
            // Scroll the element into view
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", typeName);
            Thread.sleep(500); // Wait for UI to load

            String collectionNameText = typeName.findElement(By.xpath(".//span[@class='text']")).getText();
            System.out.println("Collection name is: " + collectionNameText);

            if (collectionNameText.equals(CollectionDeleteByAuthor)) {
                collectionFound = true;
                break; // Exit loop as soon as we find the deleted collection
            }
        }

        if (collectionFound) {
            System.out.println("Deleted Collection still exists: " + CollectionDeleteByAuthor);
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Deleted Collection still exists - " + CollectionDeleteByAuthor);
            Assert.fail("Deleted Collection still exists: " + CollectionDeleteByAuthor);
        } else {
            System.out.println("Test Case Passed: Deleted Collection not found." + CollectionDeleteByAuthor);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Deleted Collection is not present in the list:" + CollectionDeleteByAuthor);
            TestRunner.getTest().log(Status.PASS, " Test Case Passed: Collection Successfully Delete From Associated Content");
        }
    }


    public void ValidateDeleteCollectionInTable() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Verifying if deleted collection is removed from the table.");

        System.out.println("I'm Into Validate Delete Collection In Table");
        TestRunner.getTest().log(Status.INFO, "I'm Into Validate Delete Collection In Table");

        try {
            WebElement noDetailsMessage = driver.findElement(By.xpath("//div[contains(text(), 'No Detail Found')]"));

            if (noDetailsMessage.isDisplayed()) {
                System.out.println("No Detail Found message is displayed. Collection deleted successfully.");
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: Collection deleted successfully.");
            } else {
                System.out.println("No Detail Found message is NOT displayed. Deleted collection is still present.");
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Deleted collection is still present in the table.");
                Assert.fail("Deleted collection is still present in the table.");
            }
        } catch (NoSuchElementException e) {
            System.out.println("No Detail Found message is NOT displayed. Deleted collection is still present.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Deleted collection is still present in the table.");
            Assert.fail("Deleted collection is still present in the table.");
        }
    }


    public void refreshCollectionScreen() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm Into Refresh Collections Screen After we Delete Any Collection");
        System.out.println("I'm Into Refresh Collections Screen After we Delete Any Collection");

        Thread.sleep(200);

        driver.navigate().refresh();

        System.out.println("Collections Screen Refresh Successfully.");
        TestRunner.getTest().log(Status.PASS, "Collections Screen Refresh Successfully");
    }
}
