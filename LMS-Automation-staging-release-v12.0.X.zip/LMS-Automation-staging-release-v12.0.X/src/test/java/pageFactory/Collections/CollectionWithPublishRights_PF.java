package pageFactory.Collections;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.Date;
import java.util.List;
import java.util.Random;

import static StepDefinitions.Collections.CollectionWithReadOnlySteps.staffName;

public class CollectionWithPublishRights_PF {

    WebDriverWait wait;
    WebDriver driver;
    Helper helper;
    JavascriptExecutor js;
    Actions actions;

    public static final String BASE_NAME = Configurations.getDotEnv().get("SITE_COLLECTION_NAME_PUBLISH_RIGHTS");


    public static ThreadLocal<String> collectionNameForPublishRights = ThreadLocal.withInitial(() -> "");

    public CollectionWithPublishRights_PF(WebDriver driver) {
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        helper = new Helper();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        js = (JavascriptExecutor) driver;
        actions = new Actions(driver);
    }

    @FindBy(xpath = "//label[text()='Status']/following-sibling::div//div[@role='button' or @role='combobox']")
    WebElement dropDown_Status;

    @FindBy(xpath = "//label[text()='State']/following-sibling::div//div[@role='button' or @role='combobox']")
    WebElement dropDown_state;

    @FindBy(xpath = "//label[text()='Collection Level']/following-sibling::div//div[@role='button' or @role='combobox']")
    WebElement collection_level;

    @FindBy(xpath = "//label[text()='Grade Level']/following-sibling::div//div[@role='button' or @role='combobox']")
    WebElement Grade_level;

    @FindBy(xpath = "//label[text()='Default Collection Rights']/following-sibling::div//div[@role='button' or @role='combobox']")
    WebElement default_collection_rights;

    public String selectedStateForPublishRights;

    public String selectedGradeLevelForPublishRights;
    public String selectedDistrictForPublishRights;
    public String selectedOrganizationNameForPublishRights;
    public String selectedCollectionRightForPublishRights;
    public String selectedCollectionLevelForPublishRights;
    public String selectedSchoolForPublishRight;


    public void ValidateAndEnterCollectionTitle() throws InterruptedException {

        System.out.println("I'm into Enter Collection Title For Publish Rights");
        TestRunner.getTest().log(Status.INFO, "I'm in to Enter Collection Title For Publish Rights");

        WebElement collectionTitleField = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//input[@placeholder='Collection Title' and @name='name']")
        ));

        collectionTitleField.click();

        String collectionName = BASE_NAME + " __" + new Date();
        setCollectionName(collectionName);

        System.out.println("Enter Assignment Title Successfully: " + collectionNameForPublishRights.get());
        collectionTitleField.sendKeys(collectionNameForPublishRights.get());
        TestRunner.getTest().log(Status.INFO, "Collection title: " + collectionNameForPublishRights.get());

    }

    public static void setCollectionName(String assignmentName) {
        collectionNameForPublishRights.set(assignmentName);
    }

    public static String getAssignmentName() {
        return collectionNameForPublishRights.get();
    }


    public void validateAndSelectStateForCollection() {
        TestRunner.getTest().log(Status.INFO, "Select State for Collection with Publish Rights");

        dropDown_state.click();

        WebElement listDistrict = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[contains(@role, 'listbox')]")));
        List<WebElement> optionsDistrict = listDistrict.findElements(By.xpath(".//li"));

        System.out.println("State List is: " + optionsDistrict.size());

        if (optionsDistrict.isEmpty()) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: No options found in the State dropdown");
            System.out.println("No options found in the State dropdown.");
            throw new RuntimeException("No State Value found in dropdown");

        } else {
            System.out.println("State:");

            for (WebElement district : optionsDistrict) {
                System.out.println(district.getText());
            }
            if (!optionsDistrict.isEmpty()) {
                Random random = new Random();
                int randomCourse = random.nextInt(optionsDistrict.size());
                WebElement selectedOption = optionsDistrict.get(randomCourse);
                selectedStateForPublishRights = selectedOption.getText();
                selectedOption.click();
                System.out.println("Selected State: " + selectedStateForPublishRights);
                TestRunner.getTest().log(Status.INFO, "Selected state is: " + selectedStateForPublishRights);
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: state select successfully");
            }
        }
    }

    public void SelectCollectionLevelFromDropdown() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into selecting Collection Level For Publish Rights");
        System.out.println("I'm into selecting Collection Level For Publish Rights");

        collection_level.click();

        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//ul[@role='listbox']//li")));
        List<WebElement> ClassStatusOptions = driver.findElements(By.xpath("//ul[@role='listbox']//li"));

        System.out.println("Available Collection Level Options For Collection:");
        for (WebElement option : ClassStatusOptions) {
            System.out.println(option.getText());
        }

        for (WebElement option : ClassStatusOptions) {
            if (option.getText().equalsIgnoreCase("Teacher Level")) {
                selectedCollectionLevelForPublishRights = option.getText(); // Store the selected level
                option.click();
                System.out.println("Selected: " + selectedCollectionLevelForPublishRights + " collection level");
                break;
            }
        }

        // Log or use selectedLevel later
        System.out.println("Stored Selected Level: " + selectedCollectionLevelForPublishRights);
        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Collection Level '" + selectedCollectionLevelForPublishRights + "' selected successfully");
    }


    public void SelectCollectionGradeLevelFromDropdown() {
        TestRunner.getTest().log(Status.INFO, "Select Collection Grade Level For Publish Rights");

        Grade_level.click();

        WebElement listDistrict = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[contains(@role, 'listbox')]")));
        List<WebElement> optionsDistrict = listDistrict.findElements(By.xpath(".//li"));

        System.out.println("State List is: " + optionsDistrict.size());

        if (optionsDistrict.isEmpty()) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: No options found in the Grade Level dropdown");
            System.out.println("No options found in the Grade Level dropdown.");
            throw new RuntimeException("No Grade Level Value found in dropdown");

        } else {
            System.out.println("Grade Level:");

            for (WebElement district : optionsDistrict) {
                System.out.println(district.getText());
            }
            if (!optionsDistrict.isEmpty()) {
                Random random = new Random();
                int randomCourse = random.nextInt(optionsDistrict.size());
                WebElement selectedOption = optionsDistrict.get(randomCourse);
                selectedGradeLevelForPublishRights = selectedOption.getText();
                selectedOption.click();
                System.out.println("Selected Grade Level: " + selectedGradeLevelForPublishRights);
                TestRunner.getTest().log(Status.INFO, "Selected Grade Level is: " + selectedGradeLevelForPublishRights);
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: Grade Level select successfully");
            }
        }
    }

    public void ValidateAndSelectPublishCollectionRightFromDropdown() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into Selecting Default Collection Rights dropdown Select Publish Right");
        System.out.println("I'm into Selecting Default Collection Rights dropdown Select Publish Right");

        default_collection_rights.click();

        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//ul[@role='listbox']//li")));
        List<WebElement> collectionRightsOptions = driver.findElements(By.xpath("//ul[@role='listbox']//li"));

        System.out.println("Available Default Collection Rights Options For Collection:");
        for (WebElement option : collectionRightsOptions) {
            System.out.println(option.getText());
        }


        for (WebElement option : collectionRightsOptions) {
            if (option.getText().equalsIgnoreCase("Publish")) {
                option.click();
                selectedCollectionRightForPublishRights = option.getText();
                System.out.println("Selected: " + selectedCollectionRightForPublishRights + " Default Collection Rights");
                break;
            }
        }

        if (selectedCollectionRightForPublishRights != null) {
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Default Collection Rights selected successfully - " + selectedCollectionRightForPublishRights);
        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: 'Publish' option not found in the dropdown.");
            throw new NoSuchElementException("'Publish' option not found in the dropdown.");
        }
    }

    @FindBy(xpath = "(//label[normalize-space()='District Filter']/parent::div)")
    WebElement district_filter;

    public void validateAndSelectDistrictFilterForPublishCollection() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into select District Filter For Publish Right Collection");
        System.out.println("I'm into select District Filter For Publish Right Collection");

        district_filter.click();

        WebElement listDistrict = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[contains(@role, 'listbox')]")));
        List<WebElement> optionsDistrict = listDistrict.findElements(By.xpath(".//li"));

        System.out.println("District List is: " + optionsDistrict.size());

        if (optionsDistrict.isEmpty()) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: No options found in the  District dropdown");
            System.out.println("No options found in the District dropdown.");
            throw new RuntimeException("No District Value found in dropdown");

        } else {
            System.out.println("District Filter:");

            for (WebElement district : optionsDistrict) {
                System.out.println(district.getText());
            }
            if (!optionsDistrict.isEmpty()) {
                Random random = new Random();
                int randomCourse = random.nextInt(optionsDistrict.size());
                WebElement selectedOption = optionsDistrict.get(randomCourse);
                selectedDistrictForPublishRights = selectedOption.getText();
                selectedOption.click();
                System.out.println("Selected District: " + selectedDistrictForPublishRights);
                TestRunner.getTest().log(Status.INFO, "Selected District is: " + selectedDistrictForPublishRights);
                TestRunner.getTest().log(Status.PASS, "Test Case Passed:  District Filter select successfully");
            }
        }
    }


    public void validateAndSelectOrganizationNameForPublishRights() {
        TestRunner.getTest().log(Status.INFO, "Select Organization Name For Publish Rights Collection");

        try {
            WebElement organizationDropdown = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(@class, 'MuiAutocomplete-inputRoot')]//input[contains(@class, 'MuiAutocomplete-input')])[2]")));
            organizationDropdown.click();

            WebElement listOrganization = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[contains(@role, 'listbox')]")));

            List<WebElement> optionsOrganization = listOrganization.findElements(By.xpath(".//li"));

            System.out.println("Organization List is: " + optionsOrganization.size());

            if (optionsOrganization.isEmpty()) {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: No options found in the Organization Name dropdown");
                System.out.println("No options found in the Organization Name dropdown.");
                throw new RuntimeException("No Organization Name found in dropdown");
            } else {
                System.out.println("Available Organizations Name:");

                for (WebElement organization : optionsOrganization) {
                    System.out.println(organization.getText());
                }

                Random random = new Random();
                int randomOrganization = random.nextInt(optionsOrganization.size());
                WebElement selectedOption = optionsOrganization.get(randomOrganization);

                selectedOrganizationNameForPublishRights = selectedOption.getText();
                selectedOption.click();

                System.out.println("Selected Organization: " + selectedOrganizationNameForPublishRights);
                TestRunner.getTest().log(Status.INFO, "Selected Organization is: " + selectedOrganizationNameForPublishRights);
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: Organization Name selected successfully");
            }
        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "No Value found in Organization Name dropdown ");
        }
    }

    public String selectedStatusForPublishRights;

    public void SelectActiveStatusForPublishRightCollection() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into selecting Active Status for Collection For Publish Rights Collection");
        System.out.println("I'm into selecting Active Status for Collection For Publish Rights Collection");

        dropDown_Status.click();

        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//ul[@role='listbox']//li")));
        List<WebElement> ClassStatusOptions = driver.findElements(By.xpath("//ul[@role='listbox']//li"));

        System.out.println("Available Status Options For Collection:");
        for (WebElement option : ClassStatusOptions) {
            System.out.println(option.getText());
        }

        for (WebElement option : ClassStatusOptions) {
            if (option.getText().equalsIgnoreCase("Active")) {
                selectedStatusForPublishRights = option.getText();
                option.click();
                System.out.println("Selected: " + selectedStatusForPublishRights + " status");
                break;
            }
        }

        System.out.println("Stored Selected Status: " + selectedStatusForPublishRights);
        TestRunner.getTest().log(Status.PASS, "Test Case Passed: New Active status '" + selectedStatusForPublishRights + "' selected successfully for Collection");
    }

    @FindBy(xpath = "(//label[normalize-space()='Select School']/parent::div)[2]")
    WebElement dropDown_School;


    public void SelectSchoolForPublishRightCollection() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into select School from Staff Selection Prompt");
        System.out.println("I'm into select School from Staff Selection Prompt");

        // Click on the dropdown to expand it
        dropDown_School.click();

        // Wait until the dropdown options are visible
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//ul[@role='listbox']//li")));
        List<WebElement> ClassStatusOptions = driver.findElements(By.xpath("//ul[@role='listbox']//li"));

        // Print all available school options
        System.out.println("Available School Options For Collection:");
        for (WebElement option : ClassStatusOptions) {
            System.out.println(option.getText());
        }

        // Initialize a variable to store the selected school

        // Iterate through options and select the desired school
        for (WebElement option : ClassStatusOptions) {
            if (option.getText().equalsIgnoreCase("Florida ES")) {
                option.click();
                selectedSchoolForPublishRight = option.getText(); // Store the selected school
                System.out.println("Selected: " + selectedSchoolForPublishRight + " School");
                break;
            }
        }

        // Check if a school was successfully selected
        if (selectedSchoolForPublishRight != null) {
            TestRunner.getTest().log(Status.PASS, "Test Case Passed   : School selected successfully - " + selectedSchoolForPublishRight);
        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : Desired school not found in the dropdown.");
            throw new NoSuchElementException("Desired school not found in the dropdown.");
        }
    }

    public void ValidateAndClickQuestionsTabButton() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm into click on Questions Tab Button");
        System.out.println("I'm into click on Questions Tab Button");
        Thread.sleep(2000);

        WebElement QuestionsButton = driver.findElement(By.xpath("//button[@value='question']"));

        if (QuestionsButton.isDisplayed()) {
            QuestionsButton.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed   : Questions Tab Button clicked successfully");
        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Failed: Questions Tab Button is Not Displayed");
        }
    }


    public void ClickOnAddExistingQuestionButton() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm into click on Add Existing Question Button");
        System.out.println("I'm into click on Add Existing Question Button");

        WebElement addExistingQuestionsButton = driver.findElement(By.xpath("//button[normalize-space()='Add Existing Question']"));

        if (addExistingQuestionsButton.isDisplayed() && addExistingQuestionsButton.isEnabled()) {
            addExistingQuestionsButton.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed   : Add Existing Question Button clicked successfully");
        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Failed: Add Existing Question Button is Not Display/Enable");
        }
    }

    public void verifyPromptQuestionSelectionPrompt() throws InterruptedException {

        WebElement prompt = driver.findElement(By.xpath("//div[@role='dialog']"));
        boolean isDisplayed = prompt.isDisplayed();
        Assert.assertTrue("Prompt is not displayed.", isDisplayed);

        WebElement promptHeader = prompt.findElement(By.tagName("h2"));
        String headerText = promptHeader.getText();
        System.out.println("Prompt header text is: " + headerText);
        TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  Prompt Display Successfully");
    }


    public void selectAllCheckboxesInsideQuestion() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Selecting all checkboxes inside Question");

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));

        WebElement btn_Assessment = driver.findElement(By.xpath("//div[@aria-label='Platform']//button[.//span[contains(text(), 'My Questions')]]"));
        btn_Assessment.click();
        TestRunner.getTest().log(Status.INFO, "My Questions clicked successfully in question grid");

        Thread.sleep(3000);

        List<WebElement> checkboxes = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(
                By.xpath("//div[@id='Question-content']//span[@role='checkbox']")));

        System.out.println("Total checkboxes found: " + checkboxes.size());
        TestRunner.getTest().log(Status.INFO, "Total checkboxes found in Questions: " + checkboxes.size());

        if (checkboxes.size() > 0) {
            System.out.println("Skipping the first checkbox.");
            TestRunner.getTest().log(Status.INFO, "Skipping the first checkbox.");
        }

        // Loop starting from index 1 to skip the first checkbox
        for (int i = 1; i < checkboxes.size(); i++) {
            WebElement checkBox = checkboxes.get(i);
            if (checkBox.isEnabled() && !checkBox.isSelected()) {
                checkBox.click();
                System.out.println("Checkbox at index " + i + " is now selected.");
                TestRunner.getTest().log(Status.INFO, "Checkbox at index " + i + " selected.");
            } else {
                System.out.println("Checkbox at index " + i + " is already selected or disabled.");
                TestRunner.getTest().log(Status.WARNING, "Checkbox at index " + i + " skipped.");
            }
        }
    }



    public void selectQuestions() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Select Questions");
        System.out.println("Select Questions");

        WebElement checkBox = driver.findElement(By.xpath("(//div[contains(@class, 'CheckboxesGroupWrapper')])[2]"));

        if (checkBox != null) {
            System.out.println("Checkbox found.");
            TestRunner.getTest().log(Status.INFO, "Checkbox found.");

            // Check if the checkbox is displayed
            if (checkBox.isDisplayed()) {
                boolean isChecked = checkBox.isSelected();
                if (isChecked) {
                    System.out.println("Checkbox is already selected.");
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  Checkbox select Successfully");
                } else {
                    checkBox.click();
                    System.out.println("Checkbox is now selected.");
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  Checkbox select Successfully");
                }
            } else {
                System.out.println("Checkbox is not visible, skipping.");
                TestRunner.getTest().log(Status.FAIL, "Test Failed: Checkbox is not visible, skipping");
            }
        } else {
            System.out.println("Checkbox not found.");
            TestRunner.getTest().log(Status.FAIL, "Test Failed: Checkbox is not visible, skipping");
        }
    }

    public void validateStaffAndCollectionRights() {
        TestRunner.getTest().log(Status.INFO, "I'm into validating staff name and collection rights");
        System.out.println("I'm into validating staff name and collection rights");


        // Locate the rows in the table (tbody)
        List<WebElement> rows = driver.findElements(By.xpath("//table[contains(@class, 'MuiTable-root')]//tbody//tr"));

        boolean isMatchFound = false;  // Flag to track if a match is found

        // Iterate over each row in the table
        for (WebElement row : rows) {
            // Get the staff name (first column)
            String staffNameFromTable = row.findElement(By.xpath(".//td[1]//div")).getText();

            System.out.println("Staff Name From Table: " + staffNameFromTable);
            TestRunner.getTest().log(Status.INFO, "Staff Name From Table: " + staffNameFromTable);

            // Get the collection rights (last column)
            String collectionRights = row.findElement(By.xpath("(.//td[5]//div//span)[2]")).getText();
            System.out.println("Default Collection Right From Table: " + collectionRights);
            TestRunner.getTest().log(Status.INFO, "Default Collection Right From Table: " + collectionRights);


            System.out.println("Default Collection Right from step 1: " + selectedCollectionRightForPublishRights);
            TestRunner.getTest().log(Status.INFO, "Default Collection Right from step 1: " + selectedCollectionRightForPublishRights);

            System.out.println("Staff Name that we selected Before: " + staffName);
            TestRunner.getTest().log(Status.INFO, "Staff Name that we selected Before: " + staffName);

            // Check if both the name and collection rights match
            if (staffNameFromTable.equalsIgnoreCase(staffName) && collectionRights.equalsIgnoreCase(selectedCollectionRightForPublishRights)) {
                System.out.println("Found matching staff and collection rights: " + staffName + " - " + collectionRights);
                TestRunner.getTest().log(Status.PASS, "Staff: " + staffName + " and Collection Rights: " + collectionRights + " match successfully.");
                isMatchFound = true;  // Update the flag if match is found
                break; // Exit the loop once match is found
            }
        }

        if (!isMatchFound) {
            System.out.println("No matching staff and collection rights found.");
            TestRunner.getTest().log(Status.FAIL, staffName + " and Collection Right" + selectedCollectionRightForPublishRights + "not match");
        }
    }


    public void SearchCollectionNameWithPublishRightsInSearchBox() throws InterruptedException {
        System.out.println("Search Collection is: " + collectionNameForPublishRights.get());
        TestRunner.getTest().log(Status.INFO, "Search Collection is: " + collectionNameForPublishRights.get());

        WebElement right_panel = driver.findElement(By.xpath("//div[contains(@class,'right-panel')]"));
        right_panel.isDisplayed();

        try {
            WebElement searchBox = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder='Search Collections']")));
            if (searchBox.isDisplayed()) {
                searchBox.click();
                searchBox.clear();
                ((JavascriptExecutor) driver).executeScript("arguments[0].value='';", searchBox);
                Thread.sleep(2000);

                String collectionNameReadOnly = collectionNameForPublishRights.get();
                System.out.println("Search by Collections name: " + collectionNameReadOnly);
                TestRunner.getTest().log(Status.INFO, "Search by Collections name: " + collectionNameReadOnly);
                searchBox.sendKeys(collectionNameReadOnly);

                TestRunner.getTest().log(Status.INFO, "Search Collection is: " + collectionNameReadOnly);
                System.out.println("Search Collection is: " + collectionNameReadOnly);
                Actions actions = new Actions(driver);
                actions.sendKeys(Keys.ENTER).perform();


                TestRunner.getTest().log(Status.PASS, "Testcase Passed   :   Enter Search Collection Successfully");

                waitForTableToRefresh();
            } else {
                System.out.println("Search box is not displayed.");
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : Search box is not displayed.");
//                throw new RuntimeException("Search Box not  Found.");
            }
        } catch (Exception e) {
            System.out.println("Search box is not available: " + e.getMessage());
        }
    }

    private void waitForTableToRefresh() {

        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class, 'right-panel')]//tbody")));

        System.out.println("Collections Table has refreshed.");
        TestRunner.getTest().log(Status.PASS, "Testcase Passed : Collections Table has refreshed");


    }
    public String collectionName;

    @FindBy(xpath = "//div[contains(@class, 'right-panel')]")
    WebElement collectionTable;

    public void showsCollectionIntoTable() throws InterruptedException {
//        Thread.sleep(3000);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class, 'right-panel')]//tbody")));

        List<WebElement> rows = collectionTable.findElements(By.xpath(".//tbody/tr"));

        if (!rows.isEmpty()) {
            System.out.println("Collection found in the table:");
            TestRunner.getTest().log(Status.INFO, "Collection found in the table:");
            for (int i = 0; i < rows.size(); i++) {
                WebElement row = rows.get(i);

                try {
                    WebElement classNameElement = row.findElement(By.xpath(".//td[contains(@class, 'MuiTableCell-body')]//div[contains(@class,'content-collection-title')]"));
                    collectionName = classNameElement.getText();
                    System.out.println("Collection Name: " + collectionName);
                    TestRunner.getTest().log(Status.INFO, "Collection Name: " + collectionName);

                    List<WebElement> cells = row.findElements(By.xpath(".//td"));
                    for (WebElement cell : cells) {
                        System.out.print(cell.getText() + "\t");
                    }
                    System.out.println();
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed   : Collection Found in Table  Successfully");

                } catch (StaleElementReferenceException e) {
                    System.out.println("Stale element found, retrying...");

                    rows = collectionTable.findElements(By.xpath(".//tbody/tr"));
                    row = rows.get(i);

                    WebElement classNameElement = row.findElement(By.xpath(".//td[contains(@class, 'MuiTableCell-body')]//div[contains(@class,'content-collection-title')]"));
                    String className = classNameElement.getText();
                    System.out.println("Collection Name: " + className);
                    TestRunner.getTest().log(Status.INFO, "Collection Name: " + className);

                    List<WebElement> cells = row.findElements(By.xpath(".//td"));
                    for (WebElement cell : cells) {
                        System.out.print(cell.getText() + "\t");
                    }
                    System.out.println();
                    TestRunner.getTest().log(Status.PASS, "Testcase Passed   : Collection Found in Table  Successfully");
                }
            }
        } else {
            System.out.println("No searched Collection found in the table.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : No New Collection found in the table by searching");
        }
        helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());

    }


    public void verifySearchedCollectionByTitleIntoTable() {
        if (collectionName.contains(collectionNameForPublishRights.get())) {
            System.out.println("Searched Collection found");
            TestRunner.getTest().log(Status.INFO, "Searched Collection found: " + collectionNameForPublishRights.get());
            TestRunner.getTest().log(Status.PASS, "Test Case Passed   : Search Collection by Title found Successfully");

        } else {
            System.out.println("Searched Collection not found and search filter not working");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : Searched Collection not found and search filter not working");
        }
    }

    @FindBy(xpath = "//label[normalize-space()='Select District']/parent::div")
    WebElement filter_select_district;

    @FindBy(xpath = "//div[contains(@class,'left-panel')]")
    WebElement left_Panel;

    @FindBy(xpath = "//label[normalize-space()='Select School']/parent::div")
    WebElement filter_select_school;

    @FindBy(xpath = "//label[normalize-space()='Levels']/parent::div")
    WebElement filter_select_levels;

    @FindBy(xpath = "//div[contains(text(),'Status')]/following-sibling::div//div[@role='button' or @role='combobox']")
    WebElement filter_select_status;


    public void FilterVerificationOnContentCollection() throws InterruptedException {
        TestRunner.startTest(" Filters On Content Collection Dashboard");
        TestRunner.getTest().log(Status.INFO, "I'm To fill Filters Information On Content Collection Dashboard");

        Thread.sleep(100);
        left_Panel.isDisplayed();

        select_DistrictFilter(selectedDistrictForPublishRights);
        select_SchoolFilter(selectedSchoolForPublishRight);
        select_statusFilter(selectedStatusForPublishRights);
        select_LevelFilter(selectedCollectionLevelForPublishRights);
        TestRunner.getTest().log(Status.INFO, "All Filters Information Filled successfully");
    }

    public void select_DistrictFilter(String selectedDistrictForPublishRights) {
        TestRunner.getTest().log(Status.INFO, "I'm in to select District on Content Collection Dashboard");
        filter_select_district.click();
        WebElement listDistrict = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//ul[@role='listbox']")));

        List<WebElement> optionsDistrict = listDistrict.findElements(By.xpath(".//li"));

        System.out.println("District List is: " + optionsDistrict.size());

        if (optionsDistrict.isEmpty()) {
            System.out.println("No options found in the District dropdown.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : No options found in the District dropdown.");

        } else {
            System.out.println("District:");

            for (WebElement district : optionsDistrict) {
                System.out.println(district.getText());
                if (district.getText().equals(selectedDistrictForPublishRights)) {
                    district.click();
                    TestRunner.getTest().log(Status.INFO, "Clicked on District: " + selectedDistrictForPublishRights);
                    System.out.println("Clicked on District: " + selectedDistrictForPublishRights);
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  District selected successfully");
                    break;
                }
            }
        }

        Actions actions = new Actions(driver);
        actions.sendKeys(Keys.ESCAPE).build().perform();

    }

    public void select_SchoolFilter(String selectedSchoolForPublishRight) throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm in to select School on Content Collection Dashboard");
        filter_select_school.click();

        WebElement listSchool = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//ul[@role='listbox']")));

        List<WebElement> optionsSchool = listSchool.findElements(By.xpath(".//li"));

        System.out.println("District List is: " + optionsSchool.size());

        if (optionsSchool.isEmpty()) {
            System.out.println("No options found in the School dropdown.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : No options found in the School dropdown.");

        } else {
            System.out.println("School:");

            for (WebElement school : optionsSchool) {
                System.out.println(school.getText());
                if (school.getText().equals(selectedSchoolForPublishRight)) {
                    school.click();
                    TestRunner.getTest().log(Status.INFO, "Clicked on School: " + selectedSchoolForPublishRight);
                    System.out.println("Clicked on School: " + selectedSchoolForPublishRight);
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  School selected successfully");
                    break;
                }
            }
        }

        Actions actions = new Actions(driver);
        actions.sendKeys(Keys.ESCAPE).build().perform();

    }

    public void select_LevelFilter(String selectedCollectionLevelForPublishRights) throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm in to select Level on Content Collection Dashboard");
        filter_select_levels.click();

        WebElement listLevel = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//ul[@role='listbox']")));

        List<WebElement> optionsLevels = listLevel.findElements(By.xpath(".//li"));

        System.out.println("Levels List is: " + optionsLevels.size());

        if (optionsLevels.isEmpty()) {
            System.out.println("No options found in the Levels dropdown.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : No options found in the Levels dropdown.");

        } else {
            System.out.println("Levels:");

            for (WebElement levels : optionsLevels) {
                System.out.println(levels.getText());
                if (levels.getText().equals(selectedCollectionLevelForPublishRights)) {
                    levels.click();
                    TestRunner.getTest().log(Status.INFO, "Clicked on Level: " + selectedCollectionLevelForPublishRights);
                    System.out.println("Clicked on Level: " + selectedCollectionLevelForPublishRights);
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  Level selected successfully");
                    break;
                }
            }
        }

        Actions actions = new Actions(driver);
        actions.sendKeys(Keys.ESCAPE).build().perform();
    }

    public void select_statusFilter(String selectedStatusForPublishRights) throws InterruptedException {

        TestRunner.getTest().log(Status.INFO, "I'm in to select Status on Content Collection Dashboard");
        filter_select_status.click();

        WebElement listLevel = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//ul[@role='listbox']")));

        List<WebElement> optionsLevels = listLevel.findElements(By.xpath(".//li"));

        System.out.println("Status List is: " + optionsLevels.size());

        if (optionsLevels.isEmpty()) {
            System.out.println("No options found in the Status dropdown.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : No options found in the Status dropdown.");

        } else {
            System.out.println("Status:");

            for (WebElement levels : optionsLevels) {
                System.out.println(levels.getText());
                if (levels.getText().equals(selectedStatusForPublishRights)) {
                    levels.click();
                    TestRunner.getTest().log(Status.INFO, "Clicked on Status: " + selectedStatusForPublishRights);
                    System.out.println("Clicked on Status: " + selectedStatusForPublishRights);
                    TestRunner.getTest().log(Status.PASS, "Testcase Passed   :  StatusS selected successfully");
                    break;
                }
            }
        }

        Actions actions = new Actions(driver);
        actions.sendKeys(Keys.ESCAPE).build().perform();

    }



    @FindBy(xpath = "//div[@id='Questions-header']")
    WebElement div_Questions;


    public void left_panel_Collections_section_In_Questions() throws InterruptedException {

        TestRunner.getTest().log(Status.INFO, "I'm Verify Left panel Question Section and Click on Collections sections");
        WebElement gridQuestionsContent = wait.until(ExpectedConditions.visibilityOf(div_Questions));

        helper.scrollToElement(driver, gridQuestionsContent);

        WebElement btn_collections = driver.findElement(By.xpath("//div[@id='Questions-content']//button[.//span[contains(text(), 'Collections')]]"));
        btn_collections.click();

        WebElement collectionNames = driver.findElement(By.xpath("(//div[@aria-labelledby='Questions-header']//div[contains(@class, 'treeViewCheckbox') and contains(@class, 'false')])[3]"));
        List<WebElement> totalCollectionNames = collectionNames.findElements(By.tagName("li"));

        System.out.println("Total Collections are: " + totalCollectionNames.size());
        TestRunner.getTest().log(Status.INFO, "Total Collections are: " + totalCollectionNames.size());

        boolean collectionFound = false;

        for (WebElement typeName : totalCollectionNames) {
            // Scroll the element into view
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", typeName);
            Thread.sleep(500); // Wait for UI to load

            String collectionNameText = typeName.findElement(By.xpath(".//span[@class='text']")).getText();
            System.out.println("Collection name is: " + collectionNameText);

            if (collectionNameText.equals(collectionNameForPublishRights.get())) {
                collectionFound = true;

                WebElement checkBox = typeName.findElement(By.xpath(".//span[@role='checkbox']"));
                boolean isChecked = checkBox.isSelected();

                if (isChecked) {
                    System.out.println("Checkbox for " + collectionNameForPublishRights.get() + " is already selected.");
                    TestRunner.getTest().log(Status.INFO, "Checkbox for " + collectionNameForPublishRights.get() + " is already selected.");
                } else {
                    checkBox.click();
                    System.out.println("Checkbox for " + collectionNameForPublishRights.get() + " is now selected.");
                    TestRunner.getTest().log(Status.INFO, "Checkbox for " + collectionNameForPublishRights.get() + " is now selected.");
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed: Collection is selected successfully.");
                }
                break; // Exit loop after selecting the correct collection
            }
        }

        if (!collectionFound) {
            System.out.println("Collection name not found: " + collectionNameForPublishRights.get());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Collection name not found - " + collectionNameForPublishRights.get());
            Assert.fail("Collection name not found: " + collectionNameForPublishRights.get());
        }

    }

    @FindBy(xpath = "//div[contains(@class, 'right-panel')]//tbody")
    WebElement questionContainerTable;


    public void ValidateDropDownOptionsForPublishRights() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "Validate Only Preview and Publish Option is Enabled for Staff in DropDown For Publish Rights");
        System.out.println("Validate Only Preview and Publish Option is Enabled for Staff in DropDown For Publish Rights");

        try {
            WebElement questionsTable = wait.until(ExpectedConditions.visibilityOf(questionContainerTable));
            helper.scrollToElement(driver, questionsTable);

            if (questionsTable != null) {
                List<WebElement> questionRows = questionsTable.findElements(By.xpath(".//tr"));

                if (questionRows.size() >= 2) {
                    WebElement questionRow = questionRows.get(1);
                    WebElement targetCell = questionRow.findElement(By.xpath(".//td[8]"));

                    WebElement previewOption = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("preview")));
                    WebElement publishOption = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("publish")));

                    boolean isPreviewEnabled = previewOption.isEnabled();
                    boolean isPublishEnabled = publishOption.isEnabled();

                    if (isPreviewEnabled) {
                        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Preview options is enabled for Other Staff with Publish Rights.");
                    } else {
                        TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Preview option is disabled For Other Staff with Publish Rights . It should be Enabled.");
                    }

                    if (isPublishEnabled) {
                        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Publish options is enabled for Other Staff with Publish Rights.");
                    } else {
                        TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Publish option is disabled For Other Staff with Publish Rights . It should be Enabled.");
                    }

                    String[] disabledOptions = {"edit", "copy", "delete"};
                    boolean allDisabled = true;

                    for (String optionId : disabledOptions) {
                        WebElement option = wait.until(ExpectedConditions.presenceOfElementLocated(By.id(optionId)));
                        boolean isDisabled = option.getAttribute("aria-disabled") != null && option.getAttribute("aria-disabled").equals("true");

                        if (!isDisabled) {
                            allDisabled = false;
                            TestRunner.getTest().log(Status.FAIL, optionId + " button is not disabled.");
                        }
                    }

                    if (allDisabled) {
                        TestRunner.getTest().log(Status.PASS, "Test Case Passed: All other buttons (Edit, Copy, Delete) are disabled For Publish Rights.");
                    }

                } else {
                    TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Less than 2 rows found in the table.");
                }
            } else {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Questions Collections table is not visible.");
            }
        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "An error occurred: " + e.getMessage());
        }
    }
}
