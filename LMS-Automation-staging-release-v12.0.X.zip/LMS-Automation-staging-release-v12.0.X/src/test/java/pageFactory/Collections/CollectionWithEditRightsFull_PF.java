package pageFactory.Collections;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.Date;
import java.util.List;
import java.util.Random;


public class CollectionWithEditRightsFull_PF {

    WebDriverWait wait;
    WebDriver driver;
    Helper helper;
    JavascriptExecutor js;
    Actions actions;

    public static final String BASE_NAME = Configurations.getDotEnv().get("SITE_COLLECTION_NAME_EDIT_RIGHTS_FULL");
//    Sophie Teacher
    public static String staffName ="Automation-QA Teacher";


    public static ThreadLocal<String> collectionNameForEditRightsFull= ThreadLocal.withInitial(() -> "");

    public CollectionWithEditRightsFull_PF(WebDriver driver) {
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        helper = new Helper();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        js = (JavascriptExecutor) driver;
        actions = new Actions(driver);
    }

    @FindBy(xpath = "//label[text()='Default Collection Rights']/following-sibling::div//div[@role='button' or @role='combobox']")
    WebElement default_collection_rights;

    @FindBy(xpath = "//label[text()='Collection Level']/following-sibling::div//div[@role='button' or @role='combobox']")
    WebElement collection_level;

    @FindBy(xpath = "(//label[normalize-space()='District Filter']/parent::div)")
    WebElement district_filter;

    @FindBy(xpath = "//label[text()='Status']/following-sibling::div//div[@role='button' or @role='combobox']")
    WebElement dropDown_Status;

    @FindBy(xpath = "//div[contains(@class, 'right-panel')]//tbody")
    WebElement resourcesContainerTable;

    public static String resourcesTitle;

    @FindBy(xpath = "//div[@id='Resources-header']")
    WebElement div_Resources;

    @FindBy(xpath = "//div[@role='group']//button[.//span[text()='Resources']]")
    WebElement tabResources;

    @FindBy(xpath = "//div[contains(@class, 'MuiAccordionSummary-content')][text()='Standards']")
    WebElement standardsElement;

    @FindBy(xpath = "//div[contains(@class, 'MuiAccordionSummary-content')][text()='Resources']")
    WebElement resourcesElement;

    @FindBy(xpath = "//div[@aria-labelledby='Resources-header']")
    WebElement resourcesContentContainer;

    @FindBy(xpath = "//div[contains(@class, 'tabelbodydata')]")
    WebElement tableResourcesContainer;

    @FindBy(xpath = "//label[normalize-space()='Select District']/parent::div")
    WebElement filter_select_district;

    @FindBy(xpath = "//div[contains(@class,'left-panel')]")
    WebElement left_Panel;

    @FindBy(xpath = "//label[normalize-space()='Select School']/parent::div")
    WebElement filter_select_school;

    @FindBy(xpath = "//label[normalize-space()='Levels']/parent::div")
    WebElement filter_select_levels;

    @FindBy(xpath = "//div[contains(text(),'Status')]/following-sibling::div//div[@role='button' or @role='combobox']")
    WebElement filter_select_status;

    @FindBy(xpath = "//div[contains(@class, 'right-panel')]")
    WebElement collectionTable;

    public static String collectionName;

    public String selectedStatusForEditRightsFullCollection;
    public String selectedDistrictForEditRightsFullCollection;
    public String selectedCollectionLevelForEditRightsFull;
    public String selectedCollectionRightForEditRightsFull;
    public String selectedOrganizationNameForEditRightsCollection;

    public void VerifyAndAddCollectionTitleForEditRightsCollection() throws InterruptedException {
        System.out.println("I'm Into Add Title For Collection With Edit Rights Full");
        TestRunner.getTest().log(Status.INFO,"I'm into Add Title For Collection With Edit Rights Full");


        WebElement collectionTitleField = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//input[@placeholder='Collection Title' and @name='name']")
        ));

        collectionTitleField.click();

        String collectionName = BASE_NAME + "_" + new Date();
        setCollectionName(collectionName);

        System.out.println("Enter Assignment Title Successfully: " + collectionNameForEditRightsFull.get());
        collectionTitleField.sendKeys(collectionNameForEditRightsFull.get());
        TestRunner.getTest().log(Status.INFO, "Collection title: " + collectionNameForEditRightsFull.get());

    }

    public static void setCollectionName(String assignmentName) {
        collectionNameForEditRightsFull.set(assignmentName);
    }

    public static String getAssignmentName() {
        return collectionNameForEditRightsFull.get();
    }


    public void selectCollectionLevelForEditRightsFullCollection() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO,"I'm Into Select Collection Level From Dropdown For Edit Rights Full Collection");
        System.out.println("I'm Into Select Collection Level From Dropdown For Edit Rights Full Collection");
        collection_level.click();

        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//ul[@role='listbox']//li")));
        List<WebElement> ClassStatusOptions = driver.findElements(By.xpath("//ul[@role='listbox']//li"));

        System.out.println("Available Collection Level Options For Collection:");
        for (WebElement option : ClassStatusOptions) {
            System.out.println(option.getText());
        }

        for (WebElement option : ClassStatusOptions) {
            if (option.getText().equalsIgnoreCase("Teacher Level")) {
                selectedCollectionLevelForEditRightsFull = option.getText(); // Store the selected level
                option.click();
                System.out.println("Selected: " + selectedCollectionLevelForEditRightsFull + " collection level");
                break;
            }
        }

        // Log or use selectedLevel later
        System.out.println("Stored Selected Level: " + selectedCollectionLevelForEditRightsFull);
        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Collection Level ' " + selectedCollectionLevelForEditRightsFull + " ' selected successfully");
    }


    public void ValidateAndSelectEditRightsFullFromDropdown() throws InterruptedException {
        System.out.println("I'm Into Select Edit Rights Full From Default Collection Rights Dropdown");
        TestRunner.getTest().log(Status.INFO, "I'm Into Select Edit Rights Full From Default Collection Rights Dropdown");

        default_collection_rights.click();

        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//ul[@role='listbox']//li")));
        List<WebElement> collectionRightsOptions = driver.findElements(By.xpath("//ul[@role='listbox']//li"));

        System.out.println("Available Default Collection Rights Options For Collection:");
        for (WebElement option : collectionRightsOptions) {
            System.out.println(option.getText());
        }


        for (WebElement option : collectionRightsOptions) {
            if (option.getText().equalsIgnoreCase("Edit Rights (Full)")) {
                option.click();
                selectedCollectionRightForEditRightsFull = option.getText();
                System.out.println("Selected: " + selectedCollectionRightForEditRightsFull + " Default Collection Rights");
                break;
            }
        }

        if (selectedCollectionRightForEditRightsFull != null) {
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Default Collection Rights selected successfully - " + selectedCollectionRightForEditRightsFull);
        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: 'Edit Rights (Full)' option not found in the dropdown.");
            throw new NoSuchElementException("'Edit Rights (Full)' option not found in the dropdown.");
        }
    }


    public void validateAndSelectDistrictFilterForEditRightsFullCollection() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO,"I'm Into Select District Filter For Edit Rights (Full) Collection");
        System.out.println("I'm Into Select District Filter For Edit Rights (Full) Collection");

        district_filter.click();

        WebElement listDistrict = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[contains(@role, 'listbox')]")));
        List<WebElement> optionsDistrict = listDistrict.findElements(By.xpath(".//li"));

        System.out.println("District List is: " + optionsDistrict.size());

        if (optionsDistrict.isEmpty()) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: No options found in the  District dropdown");
            System.out.println("No options found in the District dropdown.");
            throw new RuntimeException("No District Value found in dropdown");

        } else {
            System.out.println("District Filter:");

            for (WebElement district : optionsDistrict) {
                System.out.println(district.getText());
            }
            if (!optionsDistrict.isEmpty()) {
                Random random = new Random();
                int randomCourse = random.nextInt(optionsDistrict.size());
                WebElement selectedOption = optionsDistrict.get(randomCourse);
                selectedDistrictForEditRightsFullCollection = selectedOption.getText();
                selectedOption.click();
                System.out.println("Selected District: " + selectedDistrictForEditRightsFullCollection);
                TestRunner.getTest().log(Status.INFO, "Selected District is: " + selectedDistrictForEditRightsFullCollection);
                TestRunner.getTest().log(Status.PASS, "Test Case Passed:  District Filter select successfully");
            }
        }
    }


    public void validateAndSelectOrganizationNameForEditRightsFullCollection() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO,"I'm Into Select Organization Name For Edit Rights (Full) Collection");
        System.out.println("I'm Into Select Organization Name For Edit Rights (Full) Collection");

        try {
            WebElement organizationDropdown = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(@class, 'MuiAutocomplete-inputRoot')]//input[contains(@class, 'MuiAutocomplete-input')])[2]")));
            organizationDropdown.click();

            WebElement listOrganization = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[contains(@role, 'listbox')]")));

            List<WebElement> optionsOrganization = listOrganization.findElements(By.xpath(".//li"));

            System.out.println("Organization List is: " + optionsOrganization.size());

            if (optionsOrganization.isEmpty()) {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: No options found in the Organization Name dropdown");
                System.out.println("No options found in the Organization Name dropdown.");
                throw new RuntimeException("No Organization Name found in dropdown");
            } else {
                System.out.println("Available Organizations Name:");

                for (WebElement organization : optionsOrganization) {
                    System.out.println(organization.getText());
                }

                Random random = new Random();
                int randomOrganization = random.nextInt(optionsOrganization.size());
                WebElement selectedOption = optionsOrganization.get(randomOrganization);

                selectedOrganizationNameForEditRightsCollection = selectedOption.getText();
                selectedOption.click();

                System.out.println("Selected Organization: " + selectedOrganizationNameForEditRightsCollection);
                TestRunner.getTest().log(Status.INFO, "Selected Organization is: " + selectedOrganizationNameForEditRightsCollection);
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: Organization Name selected successfully");
            }
        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "No Value found in Organization Name dropdown ");
        }
    }


    public void SelectActiveStatusForEditRightsFullCollection() throws InterruptedException {
        System.out.println("I'm Into Select Active Status For Edit Rights (Full) Collection");
        TestRunner.getTest().log(Status.INFO,"I'm Into Select Active Status For Edit Rights (Full) Collection");

        dropDown_Status.click();

        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//ul[@role='listbox']//li")));
        List<WebElement> ClassStatusOptions = driver.findElements(By.xpath("//ul[@role='listbox']//li"));

        System.out.println("Available Status Options For Collection:");
        for (WebElement option : ClassStatusOptions) {
            System.out.println(option.getText());
        }

        for (WebElement option : ClassStatusOptions) {
            if (option.getText().equalsIgnoreCase("Active")) {
                selectedStatusForEditRightsFullCollection = option.getText();
                option.click();
                System.out.println("Selected: " + selectedStatusForEditRightsFullCollection + " status");
                break;
            }
        }

        System.out.println("Stored Selected Status: " + selectedStatusForEditRightsFullCollection);
        TestRunner.getTest().log(Status.PASS, "Test Case Passed: New Active status '" + selectedStatusForEditRightsFullCollection + "' selected successfully for Collection");
    }

    public void ValidateAndClickResourcesTabButton() throws InterruptedException {
        System.out.println("I'm Into Validate and Click on Resources Tab");
        TestRunner.getTest().log(Status.INFO,"I'm Into Validate and Click on Resources Tab");

        WebElement ResourceButton = driver.findElement(By.xpath("//button[@value='resource']"));

        if (ResourceButton.isDisplayed()) {
            ResourceButton.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed   : Resources Tab Button clicked successfully");
        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Failed: Resources Tab Button is Not Displayed");
        }
    }

    public void ClickOnAddExistingResourcesButton() throws InterruptedException {
        System.out.println("I'm Into Click on Add Existing Resource Button");
        TestRunner.getTest().log(Status.INFO,"I'm Into Click on Add Existing Resource Button");

        WebElement addExistingResourceButton = driver.findElement(By.xpath("//button[normalize-space()='Add Existing Resource']"));

        if (addExistingResourceButton.isDisplayed() && addExistingResourceButton.isEnabled()) {
            addExistingResourceButton.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed   : Add Existing Resource Button clicked successfully");
        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Failed: Add Existing Resource Button is Not Display/Enable");
        }
    }

    public void verifyPromptResourceSelectionPrompt() throws InterruptedException {
        System.out.println("I'm Into Verify That Resource Selection Prompt is Display ");
        TestRunner.getTest().log(Status.INFO,"I'm Into Verify That Resource Selection Prompt is Display");


        WebElement prompt = driver.findElement(By.xpath("//div[@role='dialog']"));
        boolean isDisplayed = prompt.isDisplayed();
        Assert.assertTrue("Resource Selection Prompt is not displayed.", isDisplayed);

        WebElement promptHeader = prompt.findElement(By.tagName("h2"));
        String headerText = promptHeader.getText();
        System.out.println("Prompt header text is: " + headerText);
        TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  Resource Selection Prompt Display Successfully");
    }


    public void selectAllCheckboxesInsideResource() throws InterruptedException {
        System.out.println("I'm Into Select All Checkbox inside My Resources Section");
        TestRunner.getTest().log(Status.INFO,"I'm Into Select All Checkbox inside My Resources Section");

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));

        WebElement btn_Resources = driver.findElement(By.xpath("//div[@aria-label='Platform']//button[.//span[contains(text(), 'My Resources')]]"));
        btn_Resources.click();
        TestRunner.getTest().log(Status.INFO, "My Resources clicked successfully in Resources grid");

        Thread.sleep(3000);

        List<WebElement> checkboxes = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(
                By.xpath("//div[@id='Resource-content']//span[@role='checkbox']")));

        System.out.println("Total checkboxes found: " + checkboxes.size());
        TestRunner.getTest().log(Status.INFO, "Total checkboxes found in My Resources: " + checkboxes.size());

        // Loop starting from index 1 to skip the first checkbox
        for (int i = 0; i < checkboxes.size(); i++) {
            WebElement checkBox = checkboxes.get(i);
            if (checkBox.isEnabled() && !checkBox.isSelected()) {
                checkBox.click();
                System.out.println("Checkbox at index " + i + " is now selected.");
                TestRunner.getTest().log(Status.INFO, "Checkbox at index " + i + " selected.");
            } else {
                System.out.println("Checkbox at index " + i + " is already selected or disabled.");
                TestRunner.getTest().log(Status.WARNING, "Checkbox at index " + i + " skipped.");
            }
        }
    }

    public void selectAllResources() throws InterruptedException {
        System.out.println("I'm Into Selecting All Resources After Filter Apply ");
        TestRunner.getTest().log(Status.INFO ,"I'm Into Selecting All Resources After Filter Apply");

        WebElement checkBox = driver.findElement(By.xpath("(//div[contains(@class, 'CheckboxesGroupWrapper')])[2]"));

        if (checkBox != null) {
            System.out.println("Checkbox found.");
            TestRunner.getTest().log(Status.INFO, "Checkbox found.");

            // Check if the checkbox is displayed
            if (checkBox.isDisplayed()) {
                boolean isChecked = checkBox.isSelected();
                if (isChecked) {
                    System.out.println("Checkbox is already selected.");
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  Checkbox select Successfully");
                } else {
                    checkBox.click();
                    System.out.println("Checkbox is now selected.");
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  Checkbox select Successfully");
                }
            } else {
                System.out.println("Checkbox is not visible, skipping.");
                TestRunner.getTest().log(Status.FAIL, "Test Failed: Checkbox is not visible, skipping");
            }
        } else {
            System.out.println("Checkbox not found.");
            TestRunner.getTest().log(Status.FAIL, "Test Failed: Checkbox is not visible, skipping");
        }

    }

    public int storedHeaderCount;

    public void VerifyResourcesCountMatch() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Verify Count of Resources match");
        System.out.println("Verify Count of Resources match");

        int totalRowCount = AssignmentDeleteForAllStudents();

        System.out.println("Total Resources that we are adding in collection: " + totalRowCount);

        storedHeaderCount = getDisplayedCountFromHeader();

        System.out.println("Total Stored Header Count is: " + storedHeaderCount);
        TestRunner.getTest().log(Status.INFO, "Total Stored Header Count is: " + storedHeaderCount);

        if (totalRowCount == storedHeaderCount) {
            TestRunner.getTest().log(Status.PASS, "Row count matches the displayed count: " + totalRowCount);
            System.out.println("Row count matches the displayed count: " + totalRowCount);
        } else {
            TestRunner.getTest().log(Status.FAIL, "Row count mismatch! Displayed: " + storedHeaderCount + ", Calculated: " + totalRowCount);
            System.out.println("Row count mismatch! Displayed: " + storedHeaderCount + ", Calculated: " + totalRowCount);
        }

    }

    public int getDisplayedCountFromHeader() {
        int displayedCount = 0;

        try {

            WebElement headerElement = driver.findElement(By.xpath("//div/h1"));
            String headerText = headerElement.getText(); // Example: "Count: 20"


            displayedCount = Integer.parseInt(headerText.replaceAll("[^0-9]", ""));
            TestRunner.getTest().log(Status.INFO, "Extracted count from header: " + displayedCount);
            System.out.println("Extracted count from header: " + displayedCount);

        } catch (NoSuchElementException | NumberFormatException e) {
            TestRunner.getTest().log(Status.FAIL, "Failed to extract count from header: " + e.getMessage());
            System.out.println("Error extracting count: " + e.getMessage());
        }

        return displayedCount;
    }

    public int AssignmentDeleteForAllStudents() throws InterruptedException {
        int totalRowsCount = 0;

        try {
            TestRunner.getTest().log(Status.INFO, "Starting Getting All Resources");
            System.out.println("Starting Getting All Resources");

            List<WebElement> studentsPagination = driver.findElements(By.xpath("//button[contains(@aria-label, 'Go to page')]"));
            int totalPages = studentsPagination.size();
            System.out.println("Total Pages: " + totalPages);
            TestRunner.getTest().log(Status.INFO, "Total Pages: " + totalPages);

            TestRunner.startTest("Getting All Rows");

            boolean hasNextPage = true;

            while (hasNextPage) {
                int rowsOnCurrentPage = getAllStudentsFromPagination();
                totalRowsCount += rowsOnCurrentPage;

                try {
                    WebElement btnNextPage = driver.findElement(By.xpath("//button[@aria-label='Go to next page']"));
                    if (btnNextPage.isEnabled()) {
                        btnNextPage.click();
                        TestRunner.getTest().log(Status.INFO, "Navigating to the next page.");
                        Thread.sleep(2000);
                    } else {
                        hasNextPage = false;
                        TestRunner.getTest().log(Status.INFO, "Reached the last page.");
                    }
                } catch (NoSuchElementException e) {
                    hasNextPage = false;
                    TestRunner.getTest().log(Status.INFO, "Reached the last page.");
                }
            }

            System.out.println("Total Rows Across All Pages: " + totalRowsCount);
            TestRunner.getTest().log(Status.INFO, "Total Rows Across All Pages: " + totalRowsCount);

        } catch (NoSuchElementException e) {
            TestRunner.getTest().log(Status.FAIL, "Error occurred: " + e.getMessage());
            System.out.println("Element not found: " + e.getMessage());
        }

        return totalRowsCount;
    }

    public int getAllStudentsFromPagination() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Getting All Resources on the Current Page");
        System.out.println("Getting All Resources on the Current Page");

        int rowsCount = 0;

        try {
            List<WebElement> rowsStudents = driver.findElements(By.xpath("//table[contains(@class,'MuiTable-root')]/tbody/tr"));
            rowsCount = rowsStudents.size();

            System.out.println("Total students on this page: " + rowsCount);
            TestRunner.getTest().log(Status.INFO, "Total students on this page: " + rowsCount);

            for (WebElement rowStudent : rowsStudents) {
                String studentInfo = rowStudent.getText();
                System.out.println("Student row: " + studentInfo);
                TestRunner.getTest().log(Status.INFO, "Assessment Name: " + studentInfo);
            }
        } catch (NoSuchElementException e) {
            TestRunner.getTest().log(Status.FAIL, "Error occurred while fetching students: " + e.getMessage());
            System.out.println("Element not found: " + e.getMessage());
        }

        return rowsCount;
    }


    public void validateStaffAndCollectionRightsForEditRightsFull() {
        TestRunner.getTest().log(Status.INFO, "I'm into validating staff name and collection rights");
        System.out.println("I'm into validating staff name and collection rights");


        // Locate the rows in the table (tbody)
        List<WebElement> rows = driver.findElements(By.xpath("//table[contains(@class, 'MuiTable-root')]//tbody//tr"));

        boolean isMatchFound = false;  // Flag to track if a match is found

        // Iterate over each row in the table
        for (WebElement row : rows) {
            // Get the staff name (first column)
            String staffNameFromTable = row.findElement(By.xpath(".//td[1]//div")).getText();

            System.out.println("Staff Name From Table: " + staffNameFromTable);
            TestRunner.getTest().log(Status.INFO, "Staff Name From Table: " + staffNameFromTable);

            // Get the collection rights (last column)
            String collectionRights = row.findElement(By.xpath("(.//td[5]//div//span)[2]")).getText();
            System.out.println("Default Collection Right From Table: " + collectionRights);
            TestRunner.getTest().log(Status.INFO, "Default Collection Right From Table: " + collectionRights);


            System.out.println("Default Collection Right from step 1: " + selectedCollectionRightForEditRightsFull);
            TestRunner.getTest().log(Status.INFO, "Default Collection Right from step 1: " + selectedCollectionRightForEditRightsFull);

            System.out.println("Staff Name that we selected Before: " + staffName);
            TestRunner.getTest().log(Status.INFO, "Staff Name that we selected Before: " + staffName);

            // Check if both the name and collection rights match
            if (staffNameFromTable.equalsIgnoreCase(staffName) && collectionRights.equalsIgnoreCase(selectedCollectionRightForEditRightsFull)) {
                System.out.println("Found matching staff and collection rights: " + staffName + " - " + collectionRights);
                TestRunner.getTest().log(Status.PASS, "Staff: " + staffName + " and Collection Rights: " + collectionRights + " match successfully.");
                isMatchFound = true;  // Update the flag if match is found
                break; // Exit the loop once match is found
            }
        }

        if (!isMatchFound) {
            System.out.println("No matching staff and collection rights found.");
            TestRunner.getTest().log(Status.FAIL, staffName + " and Collection Right" + selectedCollectionRightForEditRightsFull + "not match");
        }
    }


    public void filterVerificationOnEditRightsFullCollection() throws InterruptedException {
        System.out.println("I'm Into Validate Filters on Edit Rights (Full) Collection");
        TestRunner.getTest().log(Status.INFO,"I'm into verify Filter For Edit Rights Full Collection");

        Thread.sleep(100);
        left_Panel.isDisplayed();

        select_DistrictFilterForEditRightsFullCollection(selectedDistrictForEditRightsFullCollection);
        select_SchoolFilterForEditRightsFullCollection(selectedOrganizationNameForEditRightsCollection);
        select_statusFilterForEditRightsFullCollection(selectedStatusForEditRightsFullCollection);
        select_LevelFilterForEditRightsFullCollection(selectedCollectionLevelForEditRightsFull);

        TestRunner.getTest().log(Status.INFO, "All Filters Information Filled successfully");
    }

    public void select_DistrictFilterForEditRightsFullCollection(String selectedDistrict) {
        TestRunner.getTest().log(Status.INFO, "I'm in to select District on Content Collection Dashboard");
        filter_select_district.click();
        WebElement listDistrict = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//ul[@role='listbox']")));

        List<WebElement> optionsDistrict = listDistrict.findElements(By.xpath(".//li"));

        System.out.println("District List is: " + optionsDistrict.size());

        if (optionsDistrict.isEmpty()) {
            System.out.println("No options found in the District dropdown.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : No options found in the District dropdown.");

        } else {
            System.out.println("District:");

            for (WebElement district : optionsDistrict) {
                System.out.println(district.getText());
                if (district.getText().equals(selectedDistrict)) {
                    district.click();
                    TestRunner.getTest().log(Status.INFO, "Clicked on District: " + selectedDistrict);
                    System.out.println("Clicked on District: " + selectedDistrict);
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  District selected successfully");
                    break;
                }
            }
        }

        Actions actions = new Actions(driver);
        actions.sendKeys(Keys.ESCAPE).build().perform();

    }

    public void select_SchoolFilterForEditRightsFullCollection(String selectedSchool) throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm in to select School on Content Collection Dashboard");
        filter_select_school.click();

        WebElement listSchool = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//ul[@role='listbox']")));

        List<WebElement> optionsSchool = listSchool.findElements(By.xpath(".//li"));

        System.out.println("District List is: " + optionsSchool.size());

        if (optionsSchool.isEmpty()) {
            System.out.println("No options found in the School dropdown.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : No options found in the School dropdown.");

        } else {
            System.out.println("School:");

            for (WebElement school : optionsSchool) {
                System.out.println(school.getText());
                if (school.getText().equals(selectedSchool)) {
                    school.click();
                    TestRunner.getTest().log(Status.INFO, "Clicked on School: " + selectedSchool);
                    System.out.println("Clicked on School: " + selectedSchool);
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  School selected successfully");
                    break;
                }
            }
        }

        Actions actions = new Actions(driver);
        actions.sendKeys(Keys.ESCAPE).build().perform();

    }

    public void select_statusFilterForEditRightsFullCollection(String selectedStatus) throws InterruptedException {

        TestRunner.getTest().log(Status.INFO, "I'm in to select Status on Content Collection Dashboard");
        filter_select_status.click();

        WebElement listLevel = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//ul[@role='listbox']")));

        List<WebElement> optionsLevels = listLevel.findElements(By.xpath(".//li"));

        System.out.println("Status List is: " + optionsLevels.size());

        if (optionsLevels.isEmpty()) {
            System.out.println("No options found in the Status dropdown.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : No options found in the Status dropdown.");

        } else {
            System.out.println("Status:");

            for (WebElement levels : optionsLevels) {
                System.out.println(levels.getText());
                if (levels.getText().equals(selectedStatus)) {
                    levels.click();
                    TestRunner.getTest().log(Status.INFO, "Clicked on Status: " + selectedStatus);
                    System.out.println("Clicked on Status: " + selectedStatus);
                    TestRunner.getTest().log(Status.PASS, "Testcase Passed   :  StatusS selected successfully");
                    break;
                }
            }
        }

        Actions actions = new Actions(driver);
        actions.sendKeys(Keys.ESCAPE).build().perform();

    }

    public void select_LevelFilterForEditRightsFullCollection(String selectedLevel) throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm in to select Level on Content Collection Dashboard");
        filter_select_levels.click();

        WebElement listLevel = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//ul[@role='listbox']")));

        List<WebElement> optionsLevels = listLevel.findElements(By.xpath(".//li"));

        System.out.println("Levels List is: " + optionsLevels.size());

        if (optionsLevels.isEmpty()) {
            System.out.println("No options found in the Levels dropdown.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : No options found in the Levels dropdown.");

        } else {
            System.out.println("Levels:");

            for (WebElement levels : optionsLevels) {
                System.out.println(levels.getText());
                if (levels.getText().equals(selectedLevel)) {
                    levels.click();
                    TestRunner.getTest().log(Status.INFO, "Clicked on Level: " + selectedLevel);
                    System.out.println("Clicked on Level: " + selectedLevel);
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  Level selected successfully");
                    break;
                }
            }
        }

        Actions actions = new Actions(driver);
        actions.sendKeys(Keys.ESCAPE).build().perform();
    }

    public void SearchCollectionNameEditRightsFullInSearchBox() throws InterruptedException {
        System.out.println("Search Collection is: " + collectionNameForEditRightsFull.get());
        TestRunner.getTest().log(Status.INFO, "Search Collection is: " + collectionNameForEditRightsFull.get());

        WebElement right_panel = driver.findElement(By.xpath("//div[contains(@class,'right-panel')]"));
        right_panel.isDisplayed();

        try {
            WebElement searchBox = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder='Search Collections']")));
            if (searchBox.isDisplayed()) {
                searchBox.click();
                searchBox.clear();
                ((JavascriptExecutor) driver).executeScript("arguments[0].value='';", searchBox);
                Thread.sleep(2000);

                String collectionNameReadOnly = collectionNameForEditRightsFull.get();
                System.out.println("Search by Collections name: " + collectionNameReadOnly);
                TestRunner.getTest().log(Status.INFO, "Search by Collections name: " + collectionNameReadOnly);
                searchBox.sendKeys(collectionNameReadOnly);

                TestRunner.getTest().log(Status.INFO, "Search Collection is: " + collectionNameReadOnly);
                System.out.println("Search Collection is: " + collectionNameReadOnly);
                Actions actions = new Actions(driver);
                actions.sendKeys(Keys.ENTER).perform();


                TestRunner.getTest().log(Status.PASS, "Testcase Passed   :   Enter Search Collection Successfully");

                waitForTableToRefresh();
            } else {
                System.out.println("Search box is not displayed.");
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : Search box is not displayed.");
//                throw new RuntimeException("Search Box not  Found.");
            }
        } catch (Exception e) {
            System.out.println("Search box is not available: " + e.getMessage());
        }
    }

    private void waitForTableToRefresh() {

        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class, 'right-panel')]//tbody")));

        System.out.println("Collections Table has refreshed.");
        TestRunner.getTest().log(Status.PASS, "Testcase Passed : Collections Table has refreshed");


    }

    public void verifyEditRightsCollectionShowsIntoTable() throws InterruptedException {
//        Thread.sleep(3000);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class, 'right-panel')]//tbody")));

        List<WebElement> rows = collectionTable.findElements(By.xpath(".//tbody/tr"));

        if (!rows.isEmpty()) {
            System.out.println("Collection found in the table:");
            TestRunner.getTest().log(Status.INFO, "Collection found in the table:");
            for (int i = 0; i < rows.size(); i++) {
                WebElement row = rows.get(i);

                try {
                    WebElement classNameElement = row.findElement(By.xpath(".//td[contains(@class, 'MuiTableCell-body')]//div[contains(@class,'content-collection-title')]"));
                    collectionName = classNameElement.getText();
                    System.out.println("Collection Name: " + collectionName);
                    TestRunner.getTest().log(Status.INFO, "Collection Name: " + collectionName);

                    List<WebElement> cells = row.findElements(By.xpath(".//td"));
                    for (WebElement cell : cells) {
                        System.out.print(cell.getText() + "\t");
                    }
                    System.out.println();
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed   : Collection Found in Table  Successfully");

                } catch (StaleElementReferenceException e) {
                    System.out.println("Stale element found, retrying...");

                    rows = collectionTable.findElements(By.xpath(".//tbody/tr"));
                    row = rows.get(i);

                    WebElement classNameElement = row.findElement(By.xpath(".//td[contains(@class, 'MuiTableCell-body')]//div[contains(@class,'content-collection-title')]"));
                    String className = classNameElement.getText();
                    System.out.println("Collection Name: " + className);
                    TestRunner.getTest().log(Status.INFO, "Collection Name: " + className);

                    List<WebElement> cells = row.findElements(By.xpath(".//td"));
                    for (WebElement cell : cells) {
                        System.out.print(cell.getText() + "\t");
                    }
                    System.out.println();
                    TestRunner.getTest().log(Status.PASS, "Testcase Passed   : Collection Found in Table  Successfully");
                }
            }
        } else {
            System.out.println("No searched Collection found in the table.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : No New Collection found in the table by searching");
        }
        helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());

    }

    public void verifySearchedEditRightsFullCollectionByTitleIntoTable() {
        if (collectionName.contains(collectionNameForEditRightsFull.get())) {
            System.out.println("Searched Collection found");
            TestRunner.getTest().log(Status.INFO, "Searched Collection found: " + collectionNameForEditRightsFull.get());
            TestRunner.getTest().log(Status.PASS, "Test Case Passed   : Search Collection by Title found Successfully");

        } else {
            System.out.println("Searched Collection not found and search filter not working");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : Searched Collection not found and search filter not working");
        }
    }

    public void clickOnResourcesTab() throws InterruptedException {
        System.out.println("I'm in to click on the Resources tab");
        TestRunner.getTest().log(Status.INFO, "I'm in to click on the Resources tab");

        wait.until(ExpectedConditions.elementToBeClickable(tabResources));
        tabResources.click();
        TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  Resources tab button click successfully");


        System.out.println("Waiting for Resources dashboard visible...");
        wait.until(ExpectedConditions.visibilityOf(standardsElement));
        wait.until(ExpectedConditions.visibilityOf(resourcesElement));
        wait.until(ExpectedConditions.visibilityOf(resourcesContentContainer));
        wait.until(ExpectedConditions.visibilityOf(tableResourcesContainer));

        System.out.println("Resources dashboard are visible, actions can be performed.");
        TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  Resources dashboard are visible, actions can be performed");

    }


    public void left_panel_Collections_section_In_Resources() throws InterruptedException {

        TestRunner.getTest().log(Status.INFO, "I'm Verify Left panel Resources Section and Click on Collections sections");
        WebElement gridQuestionsContent = wait.until(ExpectedConditions.visibilityOf(div_Resources));

        helper.scrollToElement(driver, gridQuestionsContent);

        WebElement btn_collections = driver.findElement(By.xpath("//div[@id='Resources-content']//button[.//span[contains(text(), 'Collections')]]"));
        btn_collections.click();

        WebElement collectionNames = driver.findElement(By.xpath("(//div[@aria-labelledby='Resources-header']//div[contains(@class, 'treeViewCheckbox') and contains(@class, 'false')])[3]"));
        List<WebElement> totalCollectionNames = collectionNames.findElements(By.tagName("li"));

        System.out.println("Total Collections are: " + totalCollectionNames.size());
        TestRunner.getTest().log(Status.INFO, "Total Collections are: " + totalCollectionNames.size());

        boolean collectionFound = false;

        for (WebElement typeName : totalCollectionNames) {
            // Scroll the element into view
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", typeName);
            Thread.sleep(500); // Wait for UI to load

            String collectionNameText = typeName.findElement(By.xpath(".//span[@class='text']")).getText();
            System.out.println("Collection name is: " + collectionNameText);

            if (collectionNameText.equals(collectionNameForEditRightsFull.get())) {
                collectionFound = true;

                WebElement checkBox = typeName.findElement(By.xpath(".//span[@role='checkbox']"));
                boolean isChecked = checkBox.isSelected();

                if (isChecked) {
                    System.out.println("Checkbox for " + collectionNameForEditRightsFull.get() + " is already selected.");
                    TestRunner.getTest().log(Status.INFO, "Checkbox for " + collectionNameForEditRightsFull.get() + " is already selected.");
                } else {
                    checkBox.click();
                    System.out.println("Checkbox for " + collectionNameForEditRightsFull.get() + " is now selected.");
                    TestRunner.getTest().log(Status.INFO, "Checkbox for " + collectionNameForEditRightsFull.get() + " is now selected.");
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed: Collection is selected successfully.");
                }
                break; // Exit loop after selecting the correct collection
            }
        }

        if (!collectionFound) {
            System.out.println("Collection name not found: " + collectionNameForEditRightsFull.get());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Collection name not found - " + collectionNameForEditRightsFull.get());
            Assert.fail("Collection name not found: " + collectionNameForEditRightsFull.get());
        }

    }


    public void showsCollectionResourcesIntoTable() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm in Show Collection Resources Into table");
        Thread.sleep(5000);
        try {
            WebElement assessmentTable = wait.until(ExpectedConditions.visibilityOf(resourcesContainerTable));

            if (assessmentTable != null) {
                List<WebElement> assessmentRows = assessmentTable.findElements(By.xpath(".//tr"));

                if (!assessmentRows.isEmpty()) {
                    System.out.println("Collection Resources found in the table:");
                    TestRunner.getTest().log(Status.INFO, "Collection Resources found in the table:");
                    Thread.sleep(5000);

                    boolean allRowsProcessedSuccessfully = true;

                    for (int i = 0; i < assessmentRows.size(); i++) {
                        WebElement questionRow = assessmentRows.get(i);

                        int retryCount = 0;
                        boolean success = false;

                        while (retryCount < 6) {
                            try {
                                WebElement assessmentTitleElement = questionRow.findElement(By.xpath(".//td[contains(@class, 'cell-0')]/div"));
                                resourcesTitle = assessmentTitleElement.getText();
                                System.out.println("Resources Title: " + resourcesTitle);
                                TestRunner.getTest().log(Status.INFO, "Resources Title: " + resourcesTitle);

                                List<WebElement> assessmentTitleCells = questionRow.findElements(By.xpath(".//td"));
                                for (WebElement assessmentTitleCell : assessmentTitleCells) {
                                    System.out.print(assessmentTitleCell.getText() + "\t");
                                }
                                System.out.println();

                                success = true;
                                break;

                            } catch (StaleElementReferenceException e) {
                                System.out.println("Stale element found, retrying...");

                                assessmentRows = assessmentTable.findElements(By.xpath(".//tbody//tr"));

                                if (i >= assessmentRows.size()) {
                                    System.out.println("Row index " + i + " is out of bounds after refresh.");
                                    break;
                                }

                                questionRow = assessmentRows.get(i);
                                retryCount++;
                            } catch (NoSuchElementException e) {
                                System.out.println("Element not found in the row: " + e.getMessage());
                                break;
                            }
                        }

                        if (!success) {
                            System.out.println("Failed to retrieve Resources row after several attempts.");
                            allRowsProcessedSuccessfully = false;
                        }
                    }

                    if (allRowsProcessedSuccessfully) {
                        TestRunner.getTest().log(Status.PASS, "Test Case Passed  : Collection Resources Shows Into Table Successfully");
                    } else {
                        TestRunner.getTest().log(Status.FAIL, "Test Case Failed  : One or more Collection Resources could not be processed.");
                    }
                } else {
                    TestRunner.getTest().log(Status.FAIL, "Test Case Failed  : No Collection Resources found in the table.");
                    throw new RuntimeException("No Collection Resources found in the table");
                }
            } else {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Collection Resources table is not visible.");
                throw new RuntimeException("Collection Resources table is not visible");

            }
        } catch (TimeoutException e) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Timeout waiting for table to be visible or accessible. " + e.getMessage());
        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: An unexpected error occurred. " + e.getMessage());
        }
    }


    public void SelectCollectionResourcesToVerifyAuthorRights() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into Select Collection Resources to Verify Right");
        System.out.println("I'm into Select Collection Resources to Verify Right");

        WebElement questionsTable = wait.until(ExpectedConditions.visibilityOf(resourcesContainerTable));
        helper.scrollToElement(driver, questionsTable);

        if (questionsTable != null) {
            List<WebElement> questionRows = questionsTable.findElements(By.xpath(".//tr"));

            if (!questionRows.isEmpty()) {
                System.out.println("Collections Resources found in the table:");
                TestRunner.getTest().log(Status.INFO, "Collections Resources found in the table:");

                // Variable to track if the cell was successfully processed
                boolean cellProcessedSuccessfully = false;

                if (questionRows.size() >= 2) { // Ensure there are at least 2 rows
                    WebElement questionRow = questionRows.get(1);  // Accessing the 2nd row (index 1)
                    int retryCount = 0;

                    while (retryCount < 6) {
                        try {
                            // Retrieve text from the 1st column in the 2nd row
                            WebElement firstColumn = questionRow.findElement(By.xpath(".//td[1]"));
                            String questionText = firstColumn.getText();
                            System.out.println("Collection Resource Title Text in 1st column: " + questionText);
                            TestRunner.getTest().log(Status.INFO, "Collection Resource Title Text in 1st column: " + questionText);

                            // Find the 8th column in the 2nd row
                            WebElement targetCell = questionRow.findElement(By.xpath(".//td[6]"));
                            WebElement targetButton = targetCell.findElement(By.tagName("button"));

                            // Scroll to the button if needed
                            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", targetButton);
                            Thread.sleep(500);

                            // Click the button
                            targetButton.click();
                            System.out.println("Button in 2nd row, 8th column clicked successfully.");
                            TestRunner.getTest().log(Status.INFO, "Button in 2nd row, 6th column clicked successfully.");
                            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Button in 2nd row, 6th column clicked successfully.");

                            // Set to true if successful
                            cellProcessedSuccessfully = true;
                            break;

                        } catch (StaleElementReferenceException e) {
                            System.out.println("Stale element found, retrying...");

                            questionRows = questionsTable.findElements(By.xpath(".//tr"));
                            if (questionRows.size() <= 1) {
                                System.out.println("2nd row not available after refresh.");
                                break;
                            }
                            questionRow = questionRows.get(1);
                            retryCount++;
                        } catch (NoSuchElementException e) {
                            System.out.println("8th column not found in the 2nd row: " + e.getMessage());
                            break;
                        }
                    }

                    if (cellProcessedSuccessfully) {
                        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Successfully accessed and processed the 2nd row, 6th column.");
                    } else {
                        TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Could not process the 2nd row, 6th column after several attempts.");
                    }
                } else {
                    TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Less than 2 rows found in the table.");
                }
            } else {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: No Collection Resource found in the table.");
            }
        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Collection Resources table is not visible.");

        }

    }

    public void ValidateDropDownOptionsForAuthorForEditRightsFullCollection() {
        TestRunner.getTest().log(Status.INFO, "Verifying dropdown options in the 2nd row, 6th column.");
        System.out.println("Validating Preview, Publish and Assign options are enabled for Author in DropDown");

        try {
            WebElement questionsTable = wait.until(ExpectedConditions.visibilityOf(resourcesContainerTable));
            helper.scrollToElement(driver, questionsTable);

            if (questionsTable != null) {
                List<WebElement> questionRows = questionsTable.findElements(By.xpath(".//tr"));

                if (questionRows.size() >= 2) { // Ensure at least 2 rows
                    WebElement questionRow = questionRows.get(1); // 2nd row (index 1)
                    WebElement targetCell = questionRow.findElement(By.xpath(".//td[6]"));

                    // Wait for dropdown options to appear
                    WebElement previewOption = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("preview")));
                    WebElement publishOption = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("publish")));
                    WebElement assignOption = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("assign")));

                    boolean isPreviewEnabled = previewOption.isEnabled();
                    boolean isPublishEnabled = publishOption.isEnabled();
                    boolean isAssignEnabled = assignOption.isEnabled();

                    if (isPreviewEnabled && isPublishEnabled && isAssignEnabled) {
                        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Preview, Publish And Assign options are enabled for Author.");
                    } else {
                        TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Preview, Publish And Assign is disabled For Author.");
                    }

                    // Verify other buttons (Edit, Copy, Delete) are disabled
                    String[] disabledOptions = {"edit", "copy", "delete"};
                    boolean allDisabled = true;

                    for (String optionId : disabledOptions) {
                        WebElement option = wait.until(ExpectedConditions.presenceOfElementLocated(By.id(optionId)));
                        boolean isDisabled = option.getAttribute("aria-disabled") != null && option.getAttribute("aria-disabled").equals("true");

                        if (!isDisabled) {
                            allDisabled = false;
                            TestRunner.getTest().log(Status.FAIL, optionId + " button is not disabled.");
                        }
                    }

                    if (allDisabled) {
                        TestRunner.getTest().log(Status.PASS, "Test Case Passed: All other buttons (Edit, Copy, Delete) are disabled.");
                    }

                } else {
                    TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Less than 2 rows found in the table.");
                }
            } else {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Resources Collection table is not visible.");
            }
        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "An error occurred: " + e.getMessage());
        }
    }


    public void ValidateEllipseOptionForOtherStaffWithEditRightsFull() throws InterruptedException {

        System.out.println("Validating Ellipse Options for Other Staff with Edit Rights (Full) ");
        TestRunner.getTest().log(Status.INFO, "Validating Ellipse Options for Other Staff with Edit Rights (Full)");

        List<WebElement> menuOptions = driver.findElements(By.xpath("//ul[@role='menu']//li"));

        System.out.println("Validating that Only Preview and Edit options are enabled for Edit Rights (Full)");
        TestRunner.getTest().log(Status.INFO, "Validating that Only Preview and Edit options are enabled for Edit Rights (Full)");

        boolean isValidationCorrect = true;

        for (WebElement option : menuOptions) {
            String optionText = option.getText().trim();
            boolean isEnabled = option.isEnabled();
            String ariaDisabled = option.getAttribute("aria-disabled");

            // **Check Preview and Edit buttons**
            if (optionText.equalsIgnoreCase("Preview") || optionText.equalsIgnoreCase("Edit")) {
                if (isEnabled) {
                    System.out.println(optionText + " is enabled as expected for Edit Rights (Full).");
                    TestRunner.getTest().log(Status.INFO, optionText + " is enabled as expected for Edit Rights (Full).");
                } else {
                    System.out.println(optionText + " should be enabled but is disabled!");
                    TestRunner.getTest().log(Status.FAIL, optionText + " should be enabled but is disabled!");
                    isValidationCorrect = false;
                }
            }
            else {
                if (ariaDisabled != null && ariaDisabled.equals("true")) {
                    System.out.println(optionText + " is correctly disabled and has aria-disabled='true' for Edit Rights (Full).");
                    TestRunner.getTest().log(Status.INFO, optionText + " is correctly disabled and has aria-disabled='true' for Edit Rights (Full).");
                } else {
                    System.out.println(optionText + " should be disabled (aria-disabled='true') but is enabled or missing the attribute!");
                    TestRunner.getTest().log(Status.FAIL, optionText + " should be disabled (aria-disabled='true') but is enabled or missing the attribute!");
                    isValidationCorrect = false;
                }
            }
        }

        if (isValidationCorrect) {
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Only the Preview and Edit buttons are enabled for Edit Rights (Full), and all others are disabled.");
        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Some buttons are incorrectly enabled/disabled for Edit Rights (Full).");
        }
    }



    public void validateEmptyTitleField() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into Validate Empty Title Show Validation For Collection");
        System.out.println("I'm into Validate Empty Title Show Validation For Collection");

        try {

            WebElement collectionTitle = driver.findElement(By.xpath("//input[@placeholder='Collection Title' and @name='name']"));
            collectionTitle.clear();

            // Check for validation error
            WebElement titleError = driver.findElement(By.xpath("//p[contains(text(),'Title is Required.')]"));

            if (titleError.isDisplayed()) {
                System.out.println("Test Passed : Validation error displayed: 'Title is Required'.");
                TestRunner.getTest().log(Status.PASS, "Test Passed : Validation error for 'Title is Required.' is correctly displayed.");
            } else {
                System.out.println("Validation error not displayed. Test Failed.");
                TestRunner.getTest().log(Status.FAIL, "Validation error for 'Title is Required.' is not displayed.");
                assert false;  // Fail the test
            }

        } catch (NoSuchElementException e) {
            // If the element is not found, the validation failed
            System.out.println("Validation error not found. Test Failed.");
            TestRunner.getTest().log(Status.FAIL, "Validation error for 'Title is Required.' is not found.");
            assert false;  // Fail the test
        }

    }

    public void verifyStatusDropdownDisable() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO,"I'm Into Validate That Status DropDown Is Disable At Step-I");
        System.out.println("I'm Into Validate That Status Dropdown Is Disable at Step-I");


        WebElement statusDropdown = driver.findElement(By.xpath("//label[text()='Status']/following-sibling::div//div[@role='button' or @role='combobox']"));
        String isDisabled = statusDropdown.getAttribute("aria-disabled");

        if ("true".equals(isDisabled)) {
            System.out.println("Status dropdown is disabled.");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Status Dropdown is Disable As expected on Step-I");
        } else {
            System.out.println("Status dropdown is enabled.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Status Dropdown is Enable on Step-I");

        }
    }

}

