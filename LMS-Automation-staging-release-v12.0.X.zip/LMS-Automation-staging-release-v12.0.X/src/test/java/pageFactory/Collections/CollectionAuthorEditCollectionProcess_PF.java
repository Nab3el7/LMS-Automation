package pageFactory.Collections;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.Date;
import java.util.List;

import static pageFactory.Collections.CollectionWithPublishRights_PF.collectionNameForPublishRights;

public class CollectionAuthorEditCollectionProcess_PF {

    WebDriverWait wait;
    WebDriver driver;
    Helper helper;
    JavascriptExecutor js;
    Actions actions;

    public CollectionAuthorEditCollectionProcess_PF(WebDriver driver) {
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        helper = new Helper();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        js = (JavascriptExecutor) driver;
        actions = new Actions(driver);
    }


    public void ClickEditOption() throws InterruptedException{
        System.out.println("I'm Into Click on Edit Option From Dropdown Menu");
        TestRunner.getTest().log(Status.INFO,"I'm Into Click on Edit Option From Dropdown Menu");

        WebElement previewOption = driver.findElement(By.id("edit"));

        if (previewOption.isDisplayed() && previewOption.isEnabled()) {
            previewOption.click();
            System.out.println("Edit option clicked successfully.");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed:  Edit option clicked successfully.");
        } else {
            System.out.println("Edit option is either not visible or disabled.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed:  Edit option is not Enabled/Displayed.");
        }
    }

    public String EditCollectionTitle;


    public void editCollectionTitle() throws InterruptedException{
        System.out.println("I'm into Edit Collection Title");
        TestRunner.getTest().log(Status.INFO,"I'm into Edit Collection Title");

        // Wait until the element is visible
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement edt_CollectionTitle = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder='Collection Title' and @name='name']")));

        Thread.sleep(3000);
        // Get the old title
        String oldTitle = edt_CollectionTitle.getAttribute("value");
        System.out.println("Old Title: " + oldTitle);
        TestRunner.getTest().log(Status.INFO, "Collection Previous Title: " + oldTitle);
        edt_CollectionTitle.click();


        Actions actions = new Actions(driver);
        for (int i = 0; i < oldTitle.length(); i++) {
            actions.sendKeys(Keys.BACK_SPACE).perform();
        }

        ((JavascriptExecutor) driver).executeScript("arguments[0].value='';", edt_CollectionTitle);
        Thread.sleep(1000);

        // Set the thread-local variable with a unique assignment name
        String newAssignmentName = "Collection" + "_Edt_" + new Date();
        EditCollectionTitle = setAssignmentName(newAssignmentName);
        System.out.println("Edit Collection Title is: " + EditCollectionTitle);

        // Enter the new title
        edt_CollectionTitle.sendKeys(EditCollectionTitle);

        System.out.println("Edit Collection Title Successfully: " + EditCollectionTitle);
        TestRunner.getTest().log(Status.INFO, "Edit Collection Title edit successfully: " + EditCollectionTitle);
    }

    public static String setAssignmentName(String assignmentName) {
        collectionNameForPublishRights.set(assignmentName);
        return assignmentName;
    }



    public void ChangeDefaultRightsForOtherStaff() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Author Change Staff Publish Right to Read only From Default Collection Rights Dropdown");
        System.out.println("Author Change Staff Publish Right to Read only From Default Collection Rights Dropdown ");

        WebElement stdTable = driver.findElement(By.xpath("//table[contains(@class, 'MuiTable-root')]"));
        List<WebElement> rows = stdTable.findElements(By.xpath(".//tbody/tr"));

        // Limit to first 3 rows
        int maxRows = Math.min(3, rows.size());  // Ensure we don't go beyond available rows

        // Iterate over the first 3 rows in the table
        for (int i = 0; i < maxRows; i++) {
            WebElement row = rows.get(i);

            // Get the question title (assuming it's in the first column)
            WebElement nameCell = row.findElement(By.xpath(".//td[1]"));
            String staffName = nameCell.getText().trim();
            System.out.println("Staff Name: " + staffName);
            TestRunner.getTest().log(Status.INFO, "Staff Name: " + staffName);

            // Retrieve the status from the 4th column (dropdown)
            WebElement defaultCollectionRightsCell = row.findElement(By.xpath(".//td[5]//div[contains(@class, 'MuiSelect-select')]"));
            String collectionRights = defaultCollectionRightsCell.getText().trim();
            System.out.println("Previous Collection Rights For Staff: " + collectionRights);
            TestRunner.getTest().log(Status.INFO, "Previous Collection Rights For Staff: " + collectionRights);

            // Change the status from Active to Archived
            ChangeCollectionRightsFromPublishToReadOnly(row);
            Thread.sleep(1000);

        }
    }

    public void ChangeCollectionRightsFromPublishToReadOnly(WebElement row) throws InterruptedException {
        Thread.sleep(3000);
        TestRunner.getTest().log(Status.INFO, "I'm into change Default Rights From Publish to read only");
        System.out.println("I'm into change Default Rights From Publish to read only");

        // First, locate the 4th column in the current row
        WebElement statusColumn = row.findElement(By.xpath(".//td[5]"));

        // Now, locate the dropdown inside the 4th column
        WebElement dropdown = statusColumn.findElement(By.xpath(".//div[@role='button' or @role='combobox' and @aria-haspopup='listbox']"));

        if (dropdown.isDisplayed() && dropdown.isEnabled()) {
            helper.scrollToElement(driver, dropdown);
            dropdown.click();  // Click to open the dropdown
            System.out.println("Dropdown in the 5th column clicked successfully.");
            TestRunner.getTest().log(Status.PASS, "Dropdown in the 5th column clicked successfully.");

            // Wait for the options to appear and select the "Archived" option
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

            // Locate and click the "Archived" option
            WebElement archivedOption = wait.until(ExpectedConditions.elementToBeClickable(
                    By.xpath("//li//span[text()='Read Only']")
            ));
            archivedOption.click();  // Select the "Archived" option
            System.out.println("Read Only option selected successfully.");
            TestRunner.getTest().log(Status.INFO, "Read Only option selected successfully");
            TestRunner.getTest().log(Status.PASS, "Read Only option selected successfully.");
            TestRunner.getTest().log(Status.PASS, "Author Successfully change staff rights from Publish to Read Only");
        } else {
            System.out.println("Dropdown is not clickable in the 5th column.");
            TestRunner.getTest().log(Status.FAIL, "Dropdown is not clickable in the 5th column.");
        }
    }


    public void SearchEditedCollectionNameInSearchBox() throws InterruptedException {
        System.out.println("Search Edited Collection is: " + EditCollectionTitle);
        TestRunner.getTest().log(Status.INFO, "Search Edited Collection is: " + EditCollectionTitle);

        WebElement right_panel = driver.findElement(By.xpath("//div[contains(@class,'right-panel')]"));
        right_panel.isDisplayed();

        try {
            WebElement searchBox = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder='Search Collections']")));
            if (searchBox.isDisplayed()) {
                searchBox.click();
                searchBox.clear();
                ((JavascriptExecutor) driver).executeScript("arguments[0].value='';", searchBox);
                Thread.sleep(2000);

                String editCollectionName = EditCollectionTitle;
                System.out.println("Search by Collections name: " + editCollectionName);
                TestRunner.getTest().log(Status.INFO, "Search by Collections name: " + editCollectionName);
                searchBox.sendKeys(editCollectionName);

                TestRunner.getTest().log(Status.INFO, "Search Collection is: " + editCollectionName);
                System.out.println("Search Collection is: " + editCollectionName);
                Actions actions = new Actions(driver);
                actions.sendKeys(Keys.ENTER).perform();


                TestRunner.getTest().log(Status.PASS, "Testcase Passed   :   Enter Search Collection Successfully");

                waitForTableToRefresh();
            } else {
                System.out.println("Search box is not displayed.");
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : Search box is not displayed.");
//                throw new RuntimeException("Search Box not  Found.");
            }
        } catch (Exception e) {
            System.out.println("Search box is not available: " + e.getMessage());
        }
    }

    private void waitForTableToRefresh() {

        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class, 'right-panel')]//tbody")));

        System.out.println("Collections Table has refreshed.");
        TestRunner.getTest().log(Status.PASS, "Testcase Passed : Collections Table has refreshed");


    }

    public String collectionName;

    @FindBy(xpath = "//div[contains(@class, 'right-panel')]")
    WebElement collectionTable;

    public void verifyAfterEditShowsCollectionIntoTable() throws InterruptedException {
        Thread.sleep(3000);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class, 'right-panel')]//tbody")));

        List<WebElement> rows = collectionTable.findElements(By.xpath(".//tbody/tr"));

        if (!rows.isEmpty()) {
            System.out.println("Collection found in the table:");
            TestRunner.getTest().log(Status.INFO, "Collection found in the table:");
            for (int i = 0; i < rows.size(); i++) {
                WebElement row = rows.get(i);

                try {
                    WebElement classNameElement = row.findElement(By.xpath(".//td[contains(@class, 'MuiTableCell-body')]//div[contains(@class,'content-collection-title')]"));
                    collectionName = classNameElement.getText();
                    System.out.println("Collection Name: " + collectionName);
                    TestRunner.getTest().log(Status.INFO, "Collection Name: " + collectionName);

                    List<WebElement> cells = row.findElements(By.xpath(".//td"));
                    for (WebElement cell : cells) {
                        System.out.print(cell.getText() + "\t");
                    }
                    System.out.println();
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed   : Edit Collection Found in Table  Successfully");

                } catch (StaleElementReferenceException e) {
                    System.out.println("Stale element found, retrying...");

                    rows = collectionTable.findElements(By.xpath(".//tbody/tr"));
                    row = rows.get(i);

                    WebElement classNameElement = row.findElement(By.xpath(".//td[contains(@class, 'MuiTableCell-body')]//div[contains(@class,'content-collection-title')]"));
                    String className = classNameElement.getText();
                    System.out.println("Collection Name: " + className);
                    TestRunner.getTest().log(Status.INFO, "Collection Name: " + className);

                    List<WebElement> cells = row.findElements(By.xpath(".//td"));
                    for (WebElement cell : cells) {
                        System.out.print(cell.getText() + "\t");
                    }
                    System.out.println();
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed   : Edit Collection Found in Table  Successfully");
                }
            }
        } else {
            System.out.println("No searched Collection found in the table.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : No Edit Collection found in the table by searching");
        }
        helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());

    }


    public void verifySearchedCollectionByTitleIntoTableAfterEdit() {
        if (collectionName.contains(EditCollectionTitle)) {
            System.out.println("Searched Collection found");
            TestRunner.getTest().log(Status.INFO, "Searched Collection found: " + EditCollectionTitle);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed   : Search Collection by Title found Successfully");

        } else {
            System.out.println("Searched Collection not found and search filter not working");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : Searched Collection not found and search filter not working");
        }
    }


    @FindBy(xpath = "//div[@id='Questions-header']")
    WebElement div_Questions;


    public void left_panel_Edit_Collections_section_In_Questions() throws InterruptedException {

        TestRunner.getTest().log(Status.INFO, "I'm Verify Left panel Question Section and Click on Collections sections and Find Edit Collection in List");
        WebElement gridQuestionsContent = wait.until(ExpectedConditions.visibilityOf(div_Questions));

        helper.scrollToElement(driver, gridQuestionsContent);

        WebElement btn_collections = driver.findElement(By.xpath("//div[@id='Questions-content']//button[.//span[contains(text(), 'Collections')]]"));
        btn_collections.click();

        WebElement collectionNames = driver.findElement(By.xpath("(//div[@aria-labelledby='Questions-header']//div[contains(@class, 'treeViewCheckbox') and contains(@class, 'false')])[3]"));
        List<WebElement> totalCollectionNames = collectionNames.findElements(By.tagName("li"));

        System.out.println("Total Collections are: " + totalCollectionNames.size());
        TestRunner.getTest().log(Status.INFO, "Total Collections are: " + totalCollectionNames.size());

        boolean collectionFound = false;

        for (WebElement typeName : totalCollectionNames) {
            // Scroll the element into view
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", typeName);
            Thread.sleep(500); // Wait for UI to load

            String collectionNameText = typeName.findElement(By.xpath(".//span[@class='text']")).getText();
            System.out.println("Collection name is: " + collectionNameText);

            if (collectionNameText.equals(EditCollectionTitle)) {
                collectionFound = true;

                WebElement checkBox = typeName.findElement(By.xpath(".//span[@role='checkbox']"));
                boolean isChecked = checkBox.isSelected();

                if (isChecked) {
                    System.out.println("Checkbox for " + EditCollectionTitle + " is already selected.");
                    TestRunner.getTest().log(Status.INFO, "Checkbox for " + EditCollectionTitle + " is already selected.");
                } else {
                    checkBox.click();
                    System.out.println("Checkbox for " + EditCollectionTitle + " is now selected.");
                    TestRunner.getTest().log(Status.INFO, "Checkbox for " + EditCollectionTitle + " is now selected.");
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed: Edit Collection Name is selected successfully.");
                }
                break; // Exit loop after selecting the correct collection
            }
        }

        if (!collectionFound) {
            System.out.println("Collection name not found: " + EditCollectionTitle);
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Edit Collection name not found - " + EditCollectionTitle);
            Assert.fail("Edit Collection name not found: " + EditCollectionTitle);
        }

    }
}
