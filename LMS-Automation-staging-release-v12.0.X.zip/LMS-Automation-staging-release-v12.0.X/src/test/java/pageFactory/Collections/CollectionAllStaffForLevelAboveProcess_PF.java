package pageFactory.Collections;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.Date;
import java.util.List;
import java.util.Random;

import static pageFactory.Collections.CollectionWithReadOnly_PF.selectedStatus;

public class CollectionAllStaffForLevelAboveProcess_PF {

    WebDriverWait wait;
    WebDriver driver;
    Helper helper;
    JavascriptExecutor js;
    Actions actions;

    public static final String BASE_NAME = Configurations.getDotEnv().get("SITE_COLLECTION_NAME_FOR_ALL_STAFF_FOR_LEVEL_ABOVE");


    public static ThreadLocal<String> collectionNameForAllStaffLevelAbove = ThreadLocal.withInitial(() -> "");

    public CollectionAllStaffForLevelAboveProcess_PF(WebDriver driver) {
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        helper = new Helper();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        js = (JavascriptExecutor) driver;
        actions = new Actions(driver);
    }

    @FindBy(xpath = "//span[contains(text(),'All Staff for level above have access to collectio')]")
    WebElement all_staff_level_above_checkbox;

    @FindBy(xpath = "//label[normalize-space()='Select District']/parent::div")
    WebElement filter_select_district;

    @FindBy(xpath = "//div[contains(@class,'left-panel')]")
    WebElement left_Panel;

    @FindBy(xpath = "//label[normalize-space()='Select School']/parent::div")
    WebElement filter_select_school;

    @FindBy(xpath = "//label[normalize-space()='Levels']/parent::div")
    WebElement filter_select_levels;

    @FindBy(xpath = "//div[contains(text(),'Status')]/following-sibling::div//div[@role='button' or @role='combobox']")
    WebElement filter_select_status;

    @FindBy(xpath = "//div[contains(@class, 'selectTextFieldsWrapper')]")
    WebElement dropDown_SelectCourse;

    @FindBy(xpath = "//label[text()='Collection Level']/following-sibling::div//div[@role='button' or @role='combobox']")
    WebElement collection_level;

    public String selectedCollectionLevelFromDistrict;

    @FindBy(xpath = "(//label[normalize-space()='District Filter']/parent::div)")
    WebElement district_filter;

    public String SelectedDistrictFromDistrict;
    public String selectedOrganizationNameFromDistrict;

    @FindBy(xpath = "//div[contains(@class, 'right-panel')]")
    WebElement collectionTable;

    public  String collectionName;

    @FindBy(xpath = "//div[@id='Assessments-header']")
    WebElement div_Assessment;

    public void EnterCollectionTitleForDistrictCollection() throws InterruptedException {

        System.out.println("I'm into Enter Collection Title");
        TestRunner.getTest().log(Status.INFO, "I'm in to Enter Collection Title");

        WebElement collectionTitleField = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//input[@placeholder='Collection Title' and @name='name']")
        ));

        collectionTitleField.click();

        String collectionName = BASE_NAME + "_" + new Date();
        setCollectionName(collectionName);

        System.out.println("Enter Collection Title Successfully: " + collectionNameForAllStaffLevelAbove.get());
        collectionTitleField.sendKeys(collectionNameForAllStaffLevelAbove.get());
        TestRunner.getTest().log(Status.INFO, "Collection title: " + collectionNameForAllStaffLevelAbove.get());

    }

    public static void setCollectionName(String assignmentName) {
        collectionNameForAllStaffLevelAbove.set(assignmentName);
    }

    public static String getAssignmentName() {
        return collectionNameForAllStaffLevelAbove.get();
    }


    public void selectCollectionLevelFromDropdown()  throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into selecting Collection Level For Collection From District Admin");
        System.out.println("I'm into selecting Collection Level For Collection From District Admin");

        collection_level.click();

        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//ul[@role='listbox']//li")));
        List<WebElement> ClassStatusOptions = driver.findElements(By.xpath("//ul[@role='listbox']//li"));

        System.out.println("Available Collection Level Options For Collection:");
        for (WebElement option : ClassStatusOptions) {
            System.out.println(option.getText());
        }

        for (WebElement option : ClassStatusOptions) {
            if (option.getText().equalsIgnoreCase("District Level")) {
                selectedCollectionLevelFromDistrict = option.getText(); // Store the selected level
                option.click();
                System.out.println("Selected: " + selectedCollectionLevelFromDistrict + " collection level");
                break;
            }
        }

        // Log or use selectedLevel later
        System.out.println("Stored Selected Level: " + selectedCollectionLevelFromDistrict);
        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Collection Level '" + selectedCollectionLevelFromDistrict + "' selected successfully");
    }


    public void clickOnAllStaffForLevelHaveAccessCheckbox() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Select All Staff for level above have access to collection From District Admin");
        System.out.println("Select All Staff for level above have access to collection District Admin");

            all_staff_level_above_checkbox.click();
            TestRunner.getTest().log(Status.PASS,"Test Case Passed: All staff level above checkbox Checked successfully");
            System.out.println("Test Case Passed: All staff level above checkbox Checked successfully");
    }



    public void VerifyAllStaffCheckBoxAndTextIsPresent() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm into Validate that Text is present on Step-II");
        System.out.println("I'm into Validate that Text is present on Step-II");

        // Locate the banner text element
        WebElement bannerTextElement = driver.findElement(By.xpath("//div[contains(@class, 'bannerText')]"));

// Expected text
        String expectedText = "This collection is set to not require adding specific members. However, " +
                "you may add individual staff if you wish them to have a different right to the collection than the default set in Step 1.";

// Check if the element is displayed
        if (bannerTextElement.isDisplayed()) {
            String actualText = bannerTextElement.getText().trim();

            // Validate the text
            if (actualText.equals(expectedText)) {
                System.out.println("Test Case Passed: Banner text is displayed and matches the expected text.");
                TestRunner.getTest().log(Status.PASS,"Test Case Passed: Banner text is displayed and matches the expected text.");
            } else {
                System.out.println("Test Case Failed: Banner text does not match. Expected: " + expectedText + " | Actual: " + actualText);
                TestRunner.getTest().log(Status.FAIL,"Test Case Failed: Banner text does not match. Expected: " + expectedText + " | Actual: " + actualText);
            }
        } else {
            System.out.println("Test Case Failed: Banner text is not displayed.");
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed: Banner text is not displayed.");
        }


        TestRunner.getTest().log(Status.INFO, "I'm into Validate that CheckBox is Already Checked And Disable on Step-II");
        System.out.println("I'm into Validate that CheckBox is Already Checked And Disable on Step-II");

        // Locate the checkbox input element
        WebElement checkbox = driver.findElement(By.xpath("//input[@type='checkbox' and contains(@id, 'SingleCheckBox-SingleCheckBox')]"));

// Check if the checkbox is disabled
        boolean isDisabled = !checkbox.isEnabled();

// Check if the checkbox is checked (using class attribute)
        WebElement checkboxWrapper = driver.findElement(By.xpath("//span[contains(@class, 'Mui-checked')]"));
        boolean isChecked = checkboxWrapper.isDisplayed();

        if (isChecked && isDisabled) {
            System.out.println("Test Case Passed: Checkbox is checked and disabled.");
            TestRunner.getTest().log(Status.PASS,"Test Case Passed: Checkbox is checked and disabled.");
        } else if (!isChecked) {
            System.out.println("Test Case Failed: Checkbox is not checked.");
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed: Checkbox is not checked");
        } else if (!isDisabled) {
            System.out.println("Test Case Failed: Checkbox is not disabled.");
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed: Checkbox is not disabled.");
        }

    }


    public void selectDistrictFilterOnStepII() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm into Select District Filter For District Admin");
        System.out.println("I'm into Select District Filter For District Admin");


        district_filter.click();

        WebElement listDistrict = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[contains(@role, 'listbox')]")));
        List<WebElement> optionsDistrict = listDistrict.findElements(By.xpath(".//li"));

        System.out.println("District List is: " + optionsDistrict.size());

        if (optionsDistrict.isEmpty()) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: No options found in the  District dropdown");
            System.out.println("No options found in the District dropdown.");
            throw new RuntimeException("No District Value found in dropdown");

        } else {
            System.out.println("District Filter:");

            for (WebElement district : optionsDistrict) {
                System.out.println(district.getText());
            }
            if (!optionsDistrict.isEmpty()) {
                Random random = new Random();
                int randomCourse = random.nextInt(optionsDistrict.size());
                WebElement selectedOption = optionsDistrict.get(randomCourse);
                SelectedDistrictFromDistrict = selectedOption.getText();
                selectedOption.click();
                System.out.println("Selected District: " + SelectedDistrictFromDistrict);
                TestRunner.getTest().log(Status.INFO, "Selected District is: " + SelectedDistrictFromDistrict);
                TestRunner.getTest().log(Status.PASS, "Test Case Passed:  District Filter select successfully");
            }
        }
    }

    public void validateAndSelectOrganizationNameFromDropdownForDistrictAdmin() {
        TestRunner.getTest().log(Status.INFO, "Select Organization Name");

        try {
            WebElement organizationDropdown = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(@class, 'MuiAutocomplete-inputRoot')]//input[contains(@class, 'MuiAutocomplete-input')])[2]")));
            organizationDropdown.click();

            WebElement listOrganization = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[contains(@role, 'listbox')]")));
            List<WebElement> optionsOrganization = listOrganization.findElements(By.xpath(".//li"));

            System.out.println("Organization List is: " + optionsOrganization.size());

            if (optionsOrganization.isEmpty()) {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: No options found in the Organization Name dropdown");
                System.out.println("No options found in the Organization Name dropdown.");
                throw new RuntimeException("No Organization Name found in dropdown");
            } else {
                System.out.println("Available Organizations Name:");

                for (WebElement organization : optionsOrganization) {
                    System.out.println(organization.getText());

                    // Check if the organization name is "Florida ES"
                    if (organization.getText().trim().equalsIgnoreCase("Florida ES")) {
                        selectedOrganizationNameFromDistrict = organization.getText();
                        organization.click();

                        System.out.println("Selected Organization: " + selectedOrganizationNameFromDistrict);
                        TestRunner.getTest().log(Status.INFO, "Selected Organization is: " + selectedOrganizationNameFromDistrict);
                        TestRunner.getTest().log(Status.PASS, "Test Case Passed: Organization Name selected successfully");
                        return; // Exit once Florida ES is selected
                    }
                }

                // If Florida ES is not found, log failure
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Florida ES not found in the dropdown");
                throw new RuntimeException("Florida ES not found in the Organization Name dropdown");
            }
        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "No Value found in Organization Name dropdown ");
        }
    }


    public void FilterVerificationForDistrictAdminCollection() throws InterruptedException {
        TestRunner.startTest(" Filters On Content Collection Dashboard For District Admin Collection");
        TestRunner.getTest().log(Status.INFO, "I'm To fill Filters Information On Content Collection Dashboard For District Admin Collection");

        Thread.sleep(100);
        left_Panel.isDisplayed();

        select_DistrictFilter(SelectedDistrictFromDistrict);
        select_SchoolFilter(selectedOrganizationNameFromDistrict);
        select_statusFilter(selectedStatus);
        select_LevelFilter(selectedCollectionLevelFromDistrict);
        TestRunner.getTest().log(Status.INFO, "All Filters Information Filled successfully");
    }

    public void select_DistrictFilter(String selectedDistrict) {
        TestRunner.getTest().log(Status.INFO, "I'm in to select District on Content Collection Dashboard For District Admin Collection");
        filter_select_district.click();
        WebElement listDistrict = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//ul[@role='listbox']")));

        List<WebElement> optionsDistrict = listDistrict.findElements(By.xpath(".//li"));

        System.out.println("District List is: " + optionsDistrict.size());

        if (optionsDistrict.isEmpty()) {
            System.out.println("No options found in the District dropdown.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : No options found in the District dropdown.");

        } else {
            System.out.println("District:");

            for (WebElement district : optionsDistrict) {
                System.out.println(district.getText());
                if (district.getText().equals(selectedDistrict)) {
                    district.click();
                    TestRunner.getTest().log(Status.INFO, "Clicked on District: " + selectedDistrict);
                    System.out.println("Clicked on District: " + selectedDistrict);
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  District selected successfully");
                    break;
                }
            }
        }

        Actions actions = new Actions(driver);
        actions.sendKeys(Keys.ESCAPE).build().perform();

    }

    public void select_SchoolFilter(String selectedSchool) throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm in to select School on Content Collection Dashboard For District Admin Collection");
        filter_select_school.click();

        WebElement listSchool = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//ul[@role='listbox']")));

        List<WebElement> optionsSchool = listSchool.findElements(By.xpath(".//li"));

        System.out.println("District List is: " + optionsSchool.size());

        if (optionsSchool.isEmpty()) {
            System.out.println("No options found in the School dropdown.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : No options found in the School dropdown.");

        } else {
            System.out.println("School:");

            for (WebElement school : optionsSchool) {
                System.out.println(school.getText());
                if (school.getText().equals(selectedSchool)) {
                    school.click();
                    TestRunner.getTest().log(Status.INFO, "Clicked on School: " + selectedSchool);
                    System.out.println("Clicked on School: " + selectedSchool);
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  School selected successfully");
                    break;
                }
            }
        }

        Actions actions = new Actions(driver);
        actions.sendKeys(Keys.ESCAPE).build().perform();

    }

    public void select_LevelFilter(String selectedLevel) throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm in to select Level on Content Collection Dashboard For District Admin Collection");
        filter_select_levels.click();

        WebElement listLevel = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//ul[@role='listbox']")));

        List<WebElement> optionsLevels = listLevel.findElements(By.xpath(".//li"));

        System.out.println("Levels List is: " + optionsLevels.size());

        if (optionsLevels.isEmpty()) {
            System.out.println("No options found in the Levels dropdown.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : No options found in the Levels dropdown.");

        } else {
            System.out.println("Levels:");

            for (WebElement levels : optionsLevels) {
                System.out.println(levels.getText());
                if (levels.getText().equals(selectedLevel)) {
                    levels.click();
                    TestRunner.getTest().log(Status.INFO, "Clicked on Level: " + selectedLevel);
                    System.out.println("Clicked on Level: " + selectedLevel);
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  Level selected successfully");
                    break;
                }
            }
        }

        Actions actions = new Actions(driver);
        actions.sendKeys(Keys.ESCAPE).build().perform();
    }

    public void select_statusFilter(String selectedStatus) throws InterruptedException {

        TestRunner.getTest().log(Status.INFO, "I'm in to select Status on Content Collection Dashboard For District Admin Collection");
        filter_select_status.click();

        WebElement listLevel = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//ul[@role='listbox']")));

        List<WebElement> optionsLevels = listLevel.findElements(By.xpath(".//li"));

        System.out.println("Status List is: " + optionsLevels.size());

        if (optionsLevels.isEmpty()) {
            System.out.println("No options found in the Status dropdown.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : No options found in the Status dropdown.");

        } else {
            System.out.println("Status:");

            for (WebElement levels : optionsLevels) {
                System.out.println(levels.getText());
                if (levels.getText().equals(selectedStatus)) {
                    levels.click();
                    TestRunner.getTest().log(Status.INFO, "Clicked on Status: " + selectedStatus);
                    System.out.println("Clicked on Status: " + selectedStatus);
                    TestRunner.getTest().log(Status.PASS, "Testcase Passed   :  StatusS selected successfully");
                    break;
                }
            }
        }

        Actions actions = new Actions(driver);
        actions.sendKeys(Keys.ESCAPE).build().perform();

    }


    public void SearchDistrictAdminCollectionNameInSearchBox() throws InterruptedException {
        System.out.println("Search Collection is: " + collectionNameForAllStaffLevelAbove.get());
        TestRunner.getTest().log(Status.INFO, "Search Collection is: " + collectionNameForAllStaffLevelAbove.get());

        WebElement right_panel = driver.findElement(By.xpath("//div[contains(@class,'right-panel')]"));
        right_panel.isDisplayed();

        try {
            WebElement searchBox = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder='Search Collections']")));
            if (searchBox.isDisplayed()) {
                searchBox.click();
                searchBox.clear();
                ((JavascriptExecutor) driver).executeScript("arguments[0].value='';", searchBox);
                Thread.sleep(2000);

                String collectionNameReadOnly = collectionNameForAllStaffLevelAbove.get();
                System.out.println("Search by Collections name: " + collectionNameReadOnly);
                TestRunner.getTest().log(Status.INFO, "Search by Collections name: " + collectionNameReadOnly);
                searchBox.sendKeys(collectionNameReadOnly);

                TestRunner.getTest().log(Status.INFO, "Search Collection is: " + collectionNameReadOnly);
                System.out.println("Search Collection is: " + collectionNameReadOnly);
                Actions actions = new Actions(driver);
                actions.sendKeys(Keys.ENTER).perform();

                TestRunner.getTest().log(Status.PASS, "Testcase Passed   :   Enter Search Collection Successfully");

                waitForTableToRefresh();
            } else {
                System.out.println("Search box is not displayed.");
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : Search box is not displayed.");
            }
        } catch (Exception e) {
            System.out.println("Search box is not available: " + e.getMessage());
        }
    }

    private void waitForTableToRefresh() {

        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class, 'right-panel')]//tbody")));

        System.out.println("Collections Table has refreshed.");
        TestRunner.getTest().log(Status.PASS, "Testcase Passed : Collections Table has refreshed");


    }


    public void districtAdminCollectionsShowsIntoTable() throws InterruptedException {

        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class, 'right-panel')]//tbody")));

        List<WebElement> rows = collectionTable.findElements(By.xpath(".//tbody/tr"));

        if (!rows.isEmpty()) {
            System.out.println("Collection found in the table:");
            TestRunner.getTest().log(Status.INFO, "Collection found in the table:");
            for (int i = 0; i < rows.size(); i++) {
                WebElement row = rows.get(i);

                try {
                    WebElement classNameElement = row.findElement(By.xpath(".//td[contains(@class, 'MuiTableCell-body')]//div[contains(@class,'content-collection-title')]"));
                    collectionName = classNameElement.getText();
                    System.out.println("Collection Name: " + collectionName);
                    TestRunner.getTest().log(Status.INFO, "Collection Name: " + collectionName);

                    List<WebElement> cells = row.findElements(By.xpath(".//td"));
                    for (WebElement cell : cells) {
                        System.out.print(cell.getText() + "\t");
                    }
                    System.out.println();
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed   : Collection Found in Table  Successfully");

                } catch (StaleElementReferenceException e) {
                    System.out.println("Stale element found, retrying...");

                    rows = collectionTable.findElements(By.xpath(".//tbody/tr"));
                    row = rows.get(i);

                    WebElement classNameElement = row.findElement(By.xpath(".//td[contains(@class, 'MuiTableCell-body')]//div[contains(@class,'content-collection-title')]"));
                    String className = classNameElement.getText();
                    System.out.println("Collection Name: " + className);
                    TestRunner.getTest().log(Status.INFO, "Collection Name: " + className);

                    List<WebElement> cells = row.findElements(By.xpath(".//td"));
                    for (WebElement cell : cells) {
                        System.out.print(cell.getText() + "\t");
                    }
                    System.out.println();
                    TestRunner.getTest().log(Status.PASS, "Testcase Passed   : Collection Found in Table  Successfully");
                }
            }
        } else {
            System.out.println("No searched Collection found in the table.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : No New Collection found in the table by searching");
        }
        helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());

    }


    public void verifyDistrictAdminSearchedCollectionByTitleIntoTable() {
        if (collectionName.contains(collectionNameForAllStaffLevelAbove.get())) {
            System.out.println("Searched Collection found");
            TestRunner.getTest().log(Status.INFO, "Searched Collection found: " + collectionNameForAllStaffLevelAbove.get());
            TestRunner.getTest().log(Status.PASS, "Test Case Passed   : Search Collection by Title found Successfully");

        } else {
            System.out.println("Searched Collection not found and search filter not working");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : Searched Collection not found and search filter not working");
        }
    }


    public void left_panel_district_Admin_Collections_section() throws InterruptedException {

        TestRunner.getTest().log(Status.INFO, "I'm Verify Left panel Assessment Section and Click on Collections sections");
        WebElement gridAssessmentContent = wait.until(ExpectedConditions.visibilityOf(div_Assessment));

        helper.scrollToElement(driver, gridAssessmentContent);

        WebElement btn_collections = driver.findElement(By.xpath("//div[@id='Assessments-content']//button[.//span[contains(text(), 'Collections')]]"));
        btn_collections.click();

        WebElement collectionNames = driver.findElement(By.xpath("(//div[@aria-labelledby='Assessments-header']//div[contains(@class, 'treeViewCheckbox') and contains(@class, 'false')])[3]"));
        List<WebElement> totalCollectionNames = collectionNames.findElements(By.tagName("li"));

        System.out.println("Total Collections are: " + totalCollectionNames.size());
        TestRunner.getTest().log(Status.INFO, "Total Collections are: " + totalCollectionNames.size());

        boolean collectionFound = false;

        for (WebElement typeName : totalCollectionNames) {

            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", typeName);
            Thread.sleep(500);

            String collectionNameText = typeName.findElement(By.xpath(".//span[@class='text']")).getText();
            System.out.println("Collection name is: " + collectionNameText);

            if (collectionNameText.equals(collectionNameForAllStaffLevelAbove.get())) {
                collectionFound = true;

                WebElement checkBox = typeName.findElement(By.xpath(".//span[@role='checkbox']"));
                boolean isChecked = checkBox.isSelected();

                if (isChecked) {
                    System.out.println("Checkbox for " + collectionNameForAllStaffLevelAbove.get() + " is already selected.");
                    TestRunner.getTest().log(Status.INFO, "Checkbox for " + collectionNameForAllStaffLevelAbove.get() + " is already selected.");
                } else {
                    checkBox.click();
                    System.out.println("Checkbox for " + collectionNameForAllStaffLevelAbove.get() + " is now selected.");
                    TestRunner.getTest().log(Status.INFO, "Checkbox for " + collectionNameForAllStaffLevelAbove.get() + " is now selected.");
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed: Collection is selected successfully.");
                }
                break;
            }
        }

        if (!collectionFound) {
            System.out.println("Collection name not found: " + collectionNameForAllStaffLevelAbove.get());
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Collection name not found - " + collectionNameForAllStaffLevelAbove.get());
            Assert.fail("Collection name not found: " + collectionNameForAllStaffLevelAbove.get());
        }

    }

    public void VerifySelectCourse() throws InterruptedException{
        System.out.println("I'm into Select Course");
        TestRunner.getTest().log(Status.INFO,"I'm into  Select Course");

        dropDown_SelectCourse.click();
        Thread.sleep(1000);

        WebElement listCourse = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[@role='listbox']")));
        List<WebElement> optionsCourses = listCourse.findElements(By.xpath(".//li"));

        System.out.println("Courses List is: " + optionsCourses.size());
        TestRunner.getTest().log(Status.INFO, "Courses List is: " + optionsCourses.size());

        if (optionsCourses.isEmpty()) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: No options found in the courses dropdown");
            throw new RuntimeException("No options found in the courses dropdown");
        } else {
            System.out.println("Courses:");

            for (WebElement course : optionsCourses) {
                System.out.println(course.getText());
                if (course.getText().trim().equalsIgnoreCase("Florida 1st Grade Social Studies")) {
                    course.click();
                    String selectedCourse = course.getText();
                    System.out.println("Selected Course: " + selectedCourse);
                    TestRunner.getTest().log(Status.INFO, "Selected Course on Assessment dashboard: " + selectedCourse);
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed: Course Selected Successfully on Assessment Dashboard");
                    return;
                }
            }

            // If course is not found
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: 'Florida 1st Grade Social Studies' not found in dropdown");

        }
    }
}

