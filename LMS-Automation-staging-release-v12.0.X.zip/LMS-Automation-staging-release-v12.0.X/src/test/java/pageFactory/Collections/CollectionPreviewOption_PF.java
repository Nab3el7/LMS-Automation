package pageFactory.Collections;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class CollectionPreviewOption_PF {
    WebDriverWait wait;
    WebDriver driver;
    Helper helper;
    JavascriptExecutor js;
    Actions actions;

    public static final String BASE_NAME = Configurations.getDotEnv().get("SITE_COLLECTION_NAME-_READ_ONlY");

    public static ThreadLocal<String> collectionNameForReadOnly = ThreadLocal.withInitial(() -> "");

    public CollectionPreviewOption_PF(WebDriver driver) {
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        helper = new Helper();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        js = (JavascriptExecutor) driver;
        actions = new Actions(driver);
    }

    public void ClickPreviewOption() throws InterruptedException{
        System.out.println("I'm Into Click on Preview Option From Dropdown Menu");
        TestRunner.getTest().log(Status.INFO,"I'm Into Click on Preview Option From Dropdown Menu");

        WebElement previewOption = driver.findElement(By.id("preview"));

        if (previewOption.isDisplayed() && previewOption.isEnabled()) {
            previewOption.click();
            System.out.println("Preview option clicked successfully.");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed:  Preview option clicked successfully.");
        } else {
            System.out.println("Preview option is either not visible or disabled.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed:  Preview option is not Enabled/Displayed.");
        }
    }

    public void ValidateTitleFiledDisable() throws InterruptedException {
        System.out.println("I'm Into Check Collection Title Field is Disable on Step-I");
        TestRunner.getTest().log(Status.INFO, " I'm Into Check Collection Title Field is Disable on Step-I");

        try {

            WebElement collectionTitleField = driver.findElement(By.xpath("//input[@placeholder='Collection Title']"));

            boolean isDisabled = !collectionTitleField.isEnabled();

            boolean isReadOnly = collectionTitleField.getAttribute("readonly") != null;

            String pointerEvents = collectionTitleField.getCssValue("pointer-events");
            boolean isCSSDisabled = pointerEvents.equals("none");

            if (isDisabled || isReadOnly || isCSSDisabled) {
                TestRunner.getTest().log(Status.PASS, "Collection Title field is disabled as expected.");
            } else {
                TestRunner.getTest().log(Status.FAIL, "Collection Title field is unexpectedly enabled.");
            }
        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "An error occurred while verifying the Collection Title field: " + e.getMessage());
        }
    }

    public void ValidateStateDropdownDisable() throws InterruptedException{

        System.out.println("I'm Into Check Collection State Dropdown is Disable on Step-I");
        TestRunner.getTest().log(Status.INFO, " I'm Into Check Collection State Dropdown is Disable on Step-I");

        try {

            WebElement stateDropdown = driver.findElement(By.xpath("//label[text()='State']/following-sibling::div//input"));

            boolean isDisabled = !stateDropdown.isEnabled();

            boolean isReadOnly = stateDropdown.getAttribute("readonly") != null;

            String pointerEvents = stateDropdown.getCssValue("pointer-events");
            boolean isCSSDisabled = pointerEvents.equals("none");

            if (isDisabled || isReadOnly || isCSSDisabled) {
                TestRunner.getTest().log(Status.PASS, "State dropdown is disabled as expected.");
            } else {
                TestRunner.getTest().log(Status.FAIL, "State dropdown is unexpectedly enabled.");
            }
        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "An error occurred while verifying the State dropdown: " + e.getMessage());
        }
    }

    public void ValidateGradeLevelDropdownDisable() throws InterruptedException{

        System.out.println("I'm Into Check Collection GradeLevel Dropdown is Disable on Step-I");
        TestRunner.getTest().log(Status.INFO, " I'm Into Check Collection GradeLevel Dropdown is Disable on Step-I");

        try {

            WebElement gradeLevelDropdown = driver.findElement(By.xpath("//label[text()='Grade Level']/following-sibling::div//input"));

            boolean isDisabled = !gradeLevelDropdown.isEnabled();

            boolean isReadOnly = gradeLevelDropdown.getAttribute("readonly") != null;

            String pointerEvents = gradeLevelDropdown.getCssValue("pointer-events");
            boolean isCSSDisabled = pointerEvents.equals("none");

            if (isDisabled || isReadOnly || isCSSDisabled) {
                TestRunner.getTest().log(Status.PASS, "Grade Level dropdown is disabled as expected.");
            } else {
                TestRunner.getTest().log(Status.FAIL, "Grade Level dropdown is unexpectedly enabled.");
            }
        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "An error occurred while verifying the Grade Level dropdown: " + e.getMessage());
        }

    }

    public void ValidateCollectionLevelDropdownDisable() throws InterruptedException{

        System.out.println("I'm Into Check Collection Level Dropdown is Disable on Step-I");
        TestRunner.getTest().log(Status.INFO, " I'm Into Check Collection Level Dropdown is Disable on Step-I");

        try {

            WebElement collectionLevelDropdown = driver.findElement(By.xpath("//label[text()='Collection Level']/following-sibling::div//input"));

            boolean isDisabled = !collectionLevelDropdown.isEnabled();

            boolean isReadOnly = collectionLevelDropdown.getAttribute("readonly") != null;

            String pointerEvents = collectionLevelDropdown.getCssValue("pointer-events");
            boolean isCSSDisabled = pointerEvents.equals("none");

            if (isDisabled || isReadOnly || isCSSDisabled) {
                TestRunner.getTest().log(Status.PASS, "Collection Level dropdown is disabled as expected.");
            } else {
                TestRunner.getTest().log(Status.FAIL, "Collection Level dropdown is unexpectedly enabled.");
            }
        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "An error occurred while verifying the Collection Level dropdown: " + e.getMessage());
        }

    }

    public void DefaultCollectionRightsDropdownDisable() throws InterruptedException{

        System.out.println("I'm Into Check Default Collection Rights Dropdown is Disable on Step-I");
        TestRunner.getTest().log(Status.INFO, " I'm Into Check Default Collection Rights Dropdown is Disable on Step-I");

        try {
            WebElement defaultCollectionRightsDropdown = driver.findElement(By.xpath("//label[text()='Default Collection Rights']/following-sibling::div//input"));

            boolean isDisabled = !defaultCollectionRightsDropdown.isEnabled();

            boolean isReadOnly = defaultCollectionRightsDropdown.getAttribute("readonly") != null;

            String pointerEvents = defaultCollectionRightsDropdown.getCssValue("pointer-events");
            boolean isCSSDisabled = pointerEvents.equals("none");

            if (isDisabled || isReadOnly || isCSSDisabled) {
                TestRunner.getTest().log(Status.PASS, "Default Collection Rights dropdown is disabled as expected.");
            } else {
                TestRunner.getTest().log(Status.FAIL, "Default Collection Rights dropdown is unexpectedly enabled.");
            }
        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "An error occurred while verifying the Default Collection Rights dropdown: " + e.getMessage());
        }

    }

    public void ValidateDistrictFilterDropdownDisable() throws InterruptedException{
        System.out.println("I'm into Validate District Filter Dropdown Disable on Step-II");
        TestRunner.getTest().log(Status.INFO, "I'm into Validate District Filter Dropdown Disable on Step-II");

        try {
            WebElement defaultCollectionRightsDropdown = driver.findElement(By.xpath("//label[text()='District Filter']/following-sibling::div//input"));

            boolean isDisabled = !defaultCollectionRightsDropdown.isEnabled();

            boolean isReadOnly = defaultCollectionRightsDropdown.getAttribute("readonly") != null;

            String pointerEvents = defaultCollectionRightsDropdown.getCssValue("pointer-events");
            boolean isCSSDisabled = pointerEvents.equals("none");

            if (isDisabled || isReadOnly || isCSSDisabled) {
                TestRunner.getTest().log(Status.PASS, "District Filter dropdown is disabled as expected.");
            } else {
                TestRunner.getTest().log(Status.FAIL, "District Filter dropdown is unexpectedly enabled.");
            }
        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "An error occurred while verifying the District Filter dropdown: " + e.getMessage());
        }
    }

    public void ValidateOrganizationNameAndStatusDropdownDisable() throws InterruptedException {
        System.out.println("I'm into Validate Organization Name And Status Dropdown Disable on Step-II");
        TestRunner.getTest().log(Status.INFO, "I'm into Validate Organization Name And Status Dropdown Disable on Step-II");

        try {
            WebElement organizationNameField = driver.findElement(By.xpath("(//td//div[contains(@class, 'selectTextFieldsWrapper')]//input)[1]"));

            boolean isOrganizationNameDisabled = !organizationNameField.isEnabled();

            boolean isOrganizationNameReadOnly = organizationNameField.getAttribute("readonly") != null;

            String organizationNamePointerEvents = organizationNameField.getCssValue("pointer-events");
            boolean isOrganizationNameCSSDisabled = organizationNamePointerEvents.equals("none");

            WebElement statusDropdown = driver.findElement(By.xpath("(//td//div[contains(@class, 'selectTextFieldsWrapper')]//input)[2]"));

            boolean isStatusDisabled = !statusDropdown.isEnabled();

            boolean isStatusReadOnly = statusDropdown.getAttribute("readonly") != null;

            String statusPointerEvents = statusDropdown.getCssValue("pointer-events");
            boolean isStatusCSSDisabled = statusPointerEvents.equals("none");

            if (isOrganizationNameDisabled || isOrganizationNameReadOnly || isOrganizationNameCSSDisabled) {
                System.out.println("Organization Name field is disabled.");
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: Organization Name Dropdown is disabled");
            } else {
                System.out.println("Organization Name field is enabled.");
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Organization Name dropdown is unexpectedly enabled");
            }

            if (isStatusDisabled || isStatusReadOnly || isStatusCSSDisabled) {
                System.out.println("Status dropdown is disabled.");
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: Status dropdown is disabled.");
            } else {
                System.out.println("Status dropdown is enabled.");
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Status dropdown is enabled unexpectedly");
            }

        } catch (Exception e) {
            System.out.println("Error occurred while checking field statuses: " + e.getMessage());
        }
    }

    public void saveButtonDisable() throws InterruptedException {
        System.out.println("Checking if the Save button is disabled...");
        TestRunner.getTest().log(Status.INFO, "Checking if the Save button is disabled...");

        try {

            WebElement saveButton = driver.findElement(By.xpath("//div[@class='controls-container']//button[@id='btn-saveNext']"));

            boolean isSaveButtonDisabled = !saveButton.isEnabled();

            if (isSaveButtonDisabled) {
                System.out.println("Save button is disabled.");
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: Save button is disabled.");
            } else {
                System.out.println("Save button is enabled.");
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Save button is unexpectedly enabled.");
            }

        } catch (Exception e) {
            System.out.println("Error occurred while checking Save button status: " + e.getMessage());
        }
    }

    public void VerifyAddStaffMembersButtonIsDisable() throws InterruptedException{
        System.out.println("Checking Add Staff Members Button is Disable...");
        TestRunner.getTest().log(Status.INFO, "Checking Add Staff Members Button is Disable..");

        try {

            WebElement addStaffMemberButton = driver.findElement(By.xpath("//button[normalize-space()='Add Staff Members']"));

            if (addStaffMemberButton.isEnabled()) {
                System.out.println("Add Staff Member button is Enable In Preview Mode.");
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Add Staff Member button is Enable In Preview Mode");
            } else {
                System.out.println("Add Staff Member button is Disable.");
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: Add Staff Member button is Disable As expected In Preview Mode.");
            }

        } catch (Exception e) {
            System.out.println("Error occurred while checking Add Staff Members button status: " + e.getMessage());
        }
    }

    public void verifyAddExistingAssessmentButtonDisable() throws InterruptedException{

        System.out.println("Checking Add Existing Assessment Button is Disable...");
        TestRunner.getTest().log(Status.INFO, "Check and  Validate Add Existing Assessment Button is Disable..");

        try {

            WebElement addExistingAssessmentButton = driver.findElement(By.xpath("//button[normalize-space()='Add Existing Assessment']"));

            if (addExistingAssessmentButton.isEnabled()) {
                System.out.println("Add Existing Assessment button is Enable In Preview Mode.");
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Add Existing Assessment  button is Enable In Preview Mode");
            } else {
                System.out.println("Add Existing Assessment Button is disable.");
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: Add Existing Assessment  button is Disable As expected In Preview Mode.");
            }

        } catch (Exception e) {
            System.out.println("Error occurred while checking Add Existing Assessment button status: " + e.getMessage());
        }

    }

    public void validateSearchContainerDisabled() {
        System.out.println("Checking if the Search container is disabled...");
        TestRunner.getTest().log(Status.INFO, "Checking if the Search container is disabled...");

        try {

            WebElement searchInput = driver.findElement(By.xpath("//div[contains(@class,'SearchContainer')]//input"));

            boolean isDisabled = !searchInput.isEnabled();

            boolean isReadOnly = searchInput.getAttribute("readonly") != null;

            String pointerEvents = searchInput.getCssValue("pointer-events");
            boolean isCSSDisabled = pointerEvents.equals("none");

            if (isDisabled || isReadOnly || isCSSDisabled) {
                TestRunner.getTest().log(Status.PASS, "Search container is disabled as expected.");
            } else {
                TestRunner.getTest().log(Status.FAIL, "Search container is unexpectedly enabled.");
            }

        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "An error occurred while verifying the Search container: " + e.getMessage());
        }
    }

    public void validateStatusDropdownDisabled() {
        System.out.println("Checking if the Status dropdown is disabled...");
        TestRunner.getTest().log(Status.INFO, "Checking if the Status dropdown is disabled...");

        try {
            WebElement statusDropdown = driver.findElement(By.xpath("(//div[contains(@class, 'MuiFormControl-root')]//label[text()='Status']//following-sibling::div//input)[1]"));

            boolean isDisabled = !statusDropdown.isEnabled();

            boolean isReadOnly = statusDropdown.getAttribute("readonly") != null;

            String pointerEvents = statusDropdown.getCssValue("pointer-events");
            boolean isCSSDisabled = pointerEvents.equals("none");

            if (isDisabled || isReadOnly || isCSSDisabled) {
                TestRunner.getTest().log(Status.PASS, "Status dropdown is disabled as expected.");
            } else {
                TestRunner.getTest().log(Status.FAIL, "Status dropdown is unexpectedly enabled.");
            }
        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "An error occurred while verifying the Status dropdown: " + e.getMessage());
        }
    }

    public void ValidateSelectSchoolDropdownDisable() throws InterruptedException{
        System.out.println("I'm into validate that Select School DropDown Disable");
        TestRunner.getTest().log(Status.INFO, "I'm into validate Select School dropdown Disable");

        try {

            WebElement selectSchoolDropdown = driver.findElement(By.xpath("//label[text()='Select School']/following-sibling::div//input"));

            boolean isDisabled = !selectSchoolDropdown.isEnabled();

            boolean isReadOnly = selectSchoolDropdown.getAttribute("readonly") != null;

            String pointerEvents = selectSchoolDropdown.getCssValue("pointer-events");
            boolean isCSSDisabled = pointerEvents.equals("none");

            if (isDisabled || isReadOnly || isCSSDisabled) {
                TestRunner.getTest().log(Status.PASS, "Select School dropdown is disabled as expected.");
            } else {
                TestRunner.getTest().log(Status.FAIL, "Select School dropdown is unexpectedly enabled.");
            }
        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "An error occurred while verifying the Select School dropdown: " + e.getMessage());
        }

    }

    public void ValidateRoleDropdownDisable() throws InterruptedException{

        System.out.println("I'm into validate that Role DropDown Disable");
        TestRunner.getTest().log(Status.INFO, "I'm into validate Role dropdown Disable");

        try {
            WebElement roleDropdown = driver.findElement(By.xpath("//label[text()='Role']/following-sibling::div//input"));

            boolean isDisabled = !roleDropdown.isEnabled();

            boolean isReadOnly = roleDropdown.getAttribute("readonly") != null;

            String pointerEvents = roleDropdown.getCssValue("pointer-events");
            boolean isCSSDisabled = pointerEvents.equals("none");

            if (isDisabled || isReadOnly || isCSSDisabled) {
                TestRunner.getTest().log(Status.PASS, "Role dropdown is disabled as expected.");
            } else {
                TestRunner.getTest().log(Status.FAIL, "Role dropdown is unexpectedly enabled.");
            }
        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "An error occurred while verifying the Role dropdown: " + e.getMessage());
        }
    }


}
