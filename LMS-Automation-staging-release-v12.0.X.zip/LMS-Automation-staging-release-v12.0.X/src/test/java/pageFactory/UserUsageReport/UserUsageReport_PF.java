package pageFactory.UserUsageReport;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.asserts.SoftAssert;

import java.time.Duration;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class UserUsageReport_PF {

    WebDriverWait wait;
    WebDriver driver;
    Helper helper;
    Actions actions;
    JavascriptExecutor js;
    SoftAssert softAssert;
    private String appliedFilterName = "Default";


    public UserUsageReport_PF(WebDriver driver, SoftAssert softAssert) {
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        this.softAssert = softAssert;
        helper = new Helper();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        actions = new Actions(driver);
        js = (JavascriptExecutor) driver;
    }

    public void VerifyAndClickOnUserUsageReport() throws InterruptedException {
        System.out.println("I'm Into Click on User Usage Report From Favourite Reports");
        TestRunner.getTest().log(Status.INFO,"I'm Into Click on User Usage Report From Favourite Reports");

        WebElement userUsageReport= driver.findElement(By.xpath("//box[normalize-space()='User Usage Report']"));

        if (userUsageReport.isDisplayed()){
            userUsageReport.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: User Usage Report Click Successfully");
        }else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: User Usage Report Not Found on Reports Dashboard");
        }
    }

    public void verifyBreadcrumbOnUserUsageReport() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into verify Bread crumb On User Usage Report");

        helper.waitForPageToLoad();

        WebElement breadcrumb = driver.findElement(By.xpath("//nav[@aria-label='breadcrumb']"));
        String actualBreadcrumb = breadcrumb.getText().trim().replaceAll("\\s+", " ");
        String expectedBreadcrumb = "Home / Reports / User Usage";

        if (actualBreadcrumb.equalsIgnoreCase(expectedBreadcrumb)) {
            System.out.println("✅ Test Passed: Breadcrumb is correct → " + actualBreadcrumb);
            TestRunner.getTest().log(Status.PASS, "✅ Test Passed: Breadcrumb is correct and Matched → " + actualBreadcrumb);
        } else {
            System.out.println("❌ Test Failed: Expected '" + expectedBreadcrumb + "' but found '" + actualBreadcrumb + "'");
            TestRunner.getTest().log(Status.FAIL, "❌ Test Failed: Expected '" + expectedBreadcrumb + "' but found '" + actualBreadcrumb + "'");
        }
    }

    public void verifyMetricsTextAndPrintButtonPresence() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into verify Metrics Text and Print Button Presence");

        WebElement metricsText = driver.findElement(By.xpath("//p[contains(text(),'Customize the metrics you want to view in the Report Builder.')]"));
        WebElement printButton = driver.findElement(By.xpath("//button[contains(.,'Print')]"));

        if (metricsText.isDisplayed()) {
            System.out.println("✅ Test Passed: Metrics text is displayed → " + metricsText.getText());
            TestRunner.getTest().log(Status.PASS, "✅ Test Passed: Metrics text is displayed → " + metricsText.getText());
        } else {
            System.out.println("❌ Test Failed: Metrics text is not displayed");
            TestRunner.getTest().log(Status.FAIL, "❌ Test Failed: Metrics text is not displayed");
        }

        if (printButton.isDisplayed()) {
            System.out.println("✅ Test Passed: Print button is displayed");
            TestRunner.getTest().log(Status.PASS, "✅ Test Passed: Print button is displayed");
        } else {
            System.out.println("❌ Test Failed: Print button is not displayed");
            TestRunner.getTest().log(Status.FAIL, "❌ Test Failed: Print button is not displayed");
        }
    }
    public void verifyHighLevelStatsCards() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into verify High Level Stats Cards");

        WebElement highLevelStatsHeading = driver.findElement(By.xpath("//p[contains(text(),'High Level Stats')]"));

        if (highLevelStatsHeading.isDisplayed()) {
            System.out.println("✅ Test Passed: High Level Stats heading is displayed");
            TestRunner.getTest().log(Status.PASS, "✅ Test Passed: High Level Stats heading is displayed");
        } else {
            System.out.println("❌ Test Failed: High Level Stats heading is missing or not visible");
            TestRunner.getTest().log(Status.FAIL, "❌ Test Failed: High Level Stats heading is missing or not visible");
            softAssert.fail("High Level Stats heading not found");
        }

        String[] cardNames = {"Individual Users", "Total Logins", "Average Session Length", "Total Assignments Created"};

        for (String cardName : cardNames) {
            WebElement card = driver.findElement(By.xpath("//p[text()='" + cardName + "']/ancestor::div[contains(@class, 'bg-white')]"));

            // Extracting the numeric value (the first <p> tag in the container)
            WebElement valueElement = card.findElement(By.xpath(".//p[1]"));
            String cardValue = valueElement.getText().trim();
            String fullCardText = card.getText().trim().replaceAll("\\s+", " ");

            if (card.isDisplayed()) {
                if (cardValue == null || cardValue.isEmpty() || cardValue.equals("0") || cardValue.equalsIgnoreCase("0s")) {
                    System.out.println("❌ Test Failed: " + cardName + " has an invalid or zero value → " + cardValue);
                    TestRunner.getTest().log(Status.FAIL, "❌ Test Failed: " + cardName + " has an invalid or zero value → " + cardValue);
                    softAssert.fail(cardName + " card has invalid/zero value: " + cardValue);
                } else {
                    System.out.println("✅ Test Passed: " + cardName + " card is displayed with value: " + fullCardText);
                    TestRunner.getTest().log(Status.PASS, "✅ Test Passed: " + cardName + " card is displayed with value: " + fullCardText);
                }
            } else {
                System.out.println("❌ Test Failed: " + cardName + " card is missing or not visible");
                TestRunner.getTest().log(Status.FAIL, "❌ Test Failed: " + cardName + " card is missing or not visible");
                softAssert.fail(cardName + " card not found or not visible");
            }
        }
    }
    public void verifyUsageTableData() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into verify Usage Table Data");

        WebElement classHeader = driver.findElement(By.xpath("//div[@id='usage-dashboard-table-scroll']//div[text()='Class']"));
        WebElement individualUsersHeader = driver.findElement(By.xpath("//div[@id='usage-dashboard-table-scroll']//div[text()='Individual Users']"));

        if (classHeader.isDisplayed() && individualUsersHeader.isDisplayed()) {
            System.out.println("✅ Test Passed: Table headers 'Class' and 'Individual Users' are displayed");
            TestRunner.getTest().log(Status.PASS, "✅ Test Passed: Table headers 'Class' and 'Individual Users' are displayed");
        } else {
            System.out.println("❌ Test Failed: Table headers are missing or not visible");
            TestRunner.getTest().log(Status.FAIL, "❌ Test Failed: Table headers are missing or not visible");
            softAssert.fail("Usage Table headers not found");
        }

        java.util.List<WebElement> rows = driver.findElements(By.xpath("//div[@id='usage-dashboard-table-scroll']/div/div[2]/div"));

        if (!rows.isEmpty()) {
            System.out.println("✅ Test Passed: " + rows.size() + " data rows found in Usage Table");
            TestRunner.getTest().log(Status.PASS, "✅ Test Passed: " + rows.size() + " data rows found in Usage Table");

            for (int i = 0; i < rows.size(); i++) {
                WebElement row = rows.get(i);
                String rowText = row.getText().trim().replaceAll("\\s+", " ");

                if (!rowText.isEmpty()) {
                    System.out.println("✅ Row " + (i + 1) + " Data: " + rowText);
                    TestRunner.getTest().log(Status.INFO, "Row " + (i + 1) + " Data: " + rowText);
                } else {
                    System.out.println("❌ Test Failed: Row " + (i + 1) + " is empty");
                    TestRunner.getTest().log(Status.FAIL, "❌ Test Failed: Row " + (i + 1) + " is empty");
                    softAssert.fail("Empty data row found at index " + (i + 1));
                }
            }
        } else {
            System.out.println("❌ Test Failed: No data rows found in Usage Table");
            TestRunner.getTest().log(Status.FAIL, "❌ Test Failed: No data rows found in Usage Table");
            softAssert.fail("No data rows found in Usage Table");
        }
    }

    public void verifyIndividualUsersInfoDialog() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into verify Individual Users Info Dialog");

        try {
            WebElement infoIcon = driver.findElement(By.xpath("//p[text()='Individual Users']/following-sibling::button"));
            if (infoIcon.isDisplayed()) {
                infoIcon.click();
                Thread.sleep(1000); // Wait for animation

                WebElement dialogTitle = driver.findElement(By.xpath("//*[@id='dialog-title']/h2"));
                WebElement dialogSubtext = driver.findElement(By.xpath("//*[@id='dialog-title']/following-sibling::div//p"));
                WebElement closeButton = driver.findElement(By.xpath("//*[@id='dialog-title']/button"));

                if (dialogTitle.isDisplayed() && dialogSubtext.isDisplayed()) {
                    String title = dialogTitle.getText();
                    String subtext = dialogSubtext.getText();
                    System.out.println("✅ Info Dialog Title: " + title);
                    System.out.println("✅ Info Dialog Subtext: " + subtext);
                    TestRunner.getTest().log(Status.PASS, "✅ Info Dialog Title: " + title);
                    TestRunner.getTest().log(Status.PASS, "✅ Info Dialog Subtext: " + subtext);

                    closeButton.click();
                    Thread.sleep(1000); // Wait for dialog to close
                } else {
                    System.out.println("❌ Test Failed: Info dialog title or subtext is not visible for Individual Users");
                    TestRunner.getTest().log(Status.FAIL, "❌ Test Failed: Info dialog title or subtext is not visible for Individual Users");
                    softAssert.fail("Info dialog title or subtext is not visible for Individual Users");
                }
            } else {
                System.out.println("❌ Test Failed: Individual Users Info Icon is not displayed for Individual Users");
                TestRunner.getTest().log(Status.FAIL, "❌ Test Failed: Individual Users Info Icon is not displayed for Individual Users");
                softAssert.fail("Individual Users Info Icon is not displayed");
            }
        } catch (Exception e) {
            System.out.println("❌ Exception in for Individual Users Info Dialog verification: " + e.getMessage());
            TestRunner.getTest().log(Status.FAIL, "❌ Exception in for Individual Users Info Dialog verification: " + e.getMessage());
            softAssert.fail("Exception in for Individual Users Info Dialog verification: " + e.getMessage());
        }
    }

    public void verifyTotalLoginInfoDialog() throws InterruptedException {

        TestRunner.getTest().log(Status.INFO, "I'm into verify Total Logins Info Dialog");

        try {
            WebElement infoIcon = driver.findElement(By.xpath("//p[text()='Total Logins']/following-sibling::button"));
            if (infoIcon.isDisplayed()) {
                infoIcon.click();
                Thread.sleep(1000); // Wait for animation

                WebElement dialogTitle = driver.findElement(By.xpath("//*[@id='dialog-title']/h2"));
                WebElement dialogSubtext = driver.findElement(By.xpath("//*[@id='dialog-title']/following-sibling::div//p"));
                WebElement closeButton = driver.findElement(By.xpath("//*[@id='dialog-title']/button"));

                if (dialogTitle.isDisplayed() && dialogSubtext.isDisplayed()) {
                    String title = dialogTitle.getText();
                    String subtext = dialogSubtext.getText();
                    System.out.println("✅ Info Dialog Title: " + title);
                    System.out.println("✅ Info Dialog Subtext: " + subtext);
                    TestRunner.getTest().log(Status.PASS, "✅ Info Dialog Title: " + title);
                    TestRunner.getTest().log(Status.PASS, "✅ Info Dialog Subtext: " + subtext);

                    closeButton.click();
                    Thread.sleep(1000); // Wait for dialog to close
                } else {
                    System.out.println("❌ Test Failed: Info dialog title or subtext is not visible for Total Logins");
                    TestRunner.getTest().log(Status.FAIL, "❌ Test Failed: Info dialog title or subtext is not visible Total Logins");
                    softAssert.fail("Info dialog title or subtext is not visible Total Logins");
                }
            } else {
                System.out.println("❌ Test Failed: Total Logins Info Icon is not displayed");
                TestRunner.getTest().log(Status.FAIL, "❌ Test Failed: Total Logins Info Icon is not displayed");
                softAssert.fail("Individual Users Info Icon is not displayed");
            }
        } catch (Exception e) {
            System.out.println("❌ Exception in  Total Logins Info Dialog verification: " + e.getMessage());
            TestRunner.getTest().log(Status.FAIL, "❌ Exception in Total Logins Info Dialog verification: " + e.getMessage());
            softAssert.fail("Exception in Total Logins Info Dialog verification: " + e.getMessage());
        }
    }

    public void selectAllClassesFromClassDropdown() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO,"I'm into Select All Classes From Select Class Dropdown in Filters Section");
        System.out.println("I'm into Select All Classes From Select Class Dropdown in Filters Section");

        try {
            WebElement classDropdown = driver.findElement(By.xpath("//label[text()='Select Class']/parent::div"));

            if (classDropdown.isDisplayed()) {
                classDropdown.click();
                Thread.sleep(1000); // Wait for dropdown to open

                WebElement allClassesOption = driver.findElement(By.xpath("//li[contains(., 'All Classes')] | //div[contains(text(), 'All Classes')] | //p[contains(text(), 'All Classes')]"));

                if (allClassesOption.isDisplayed()) {
                    allClassesOption.click();
                    appliedFilterName = "All Classes";
                    System.out.println("✅ Test Passed: 'All Classes' option selected successfully");
                    TestRunner.getTest().log(Status.PASS, "✅ Test Passed: 'All Classes' option selected successfully");
                    Thread.sleep(1000); // Wait for selection to process

                    // Close the dropdown after selection
                    actions.sendKeys(Keys.ESCAPE).build().perform();
                    Thread.sleep(1000);
                } else {
                    System.out.println("❌ Test Failed: 'All Classes' option not found or visible");
                    TestRunner.getTest().log(Status.FAIL, "❌ Test Failed: 'All Classes' option not found or visible");
                    softAssert.fail("'All Classes' option not found or visible");
                }
            } else {
                System.out.println("❌ Test Failed: Select Class dropdown is not displayed");
                TestRunner.getTest().log(Status.FAIL, "❌ Test Failed: Select Class dropdown is not displayed");
                softAssert.fail("Select Class dropdown is not displayed");
            }
        } catch (Exception e) {
            System.out.println("❌ Exception in selecting All Classes: " + e.getMessage());
            TestRunner.getTest().log(Status.FAIL, "❌ Exception in selecting All Classes: " + e.getMessage());
            softAssert.fail("Exception in selecting All Classes: " + e.getMessage());
        }
    }

    public void selectTeacherCheckBoxFromCoursesViews() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into Select Teacher CheckBox From Courses Views");
        System.out.println("I'm into Select Teacher CheckBox From Courses Views");

        try {
            WebElement teacherSelfOption = driver.findElement(By.xpath("//p[text()='Course Views']/following-sibling::div//span[text()='Teacher (Self)']/ancestor::label"));

            if (teacherSelfOption.isDisplayed()) {
                teacherSelfOption.click();
                appliedFilterName = "Course Views: Teacher (Self)";
                System.out.println("✅ Test Passed: 'Teacher (Self)' course view checkbox selected successfully");
                TestRunner.getTest().log(Status.PASS, "✅ Test Passed: 'Teacher (Self)' course view checkbox selected successfully");
                Thread.sleep(1000); // Wait for selection to process
            } else {
                System.out.println("❌ Test Failed: 'Teacher (Self)' course view option is not displayed");
                TestRunner.getTest().log(Status.FAIL, "❌ Test Failed: 'Teacher (Self)' course view option is not displayed");
                softAssert.fail("'Teacher (Self)' course view option is not displayed");
            }
        } catch (Exception e) {
            System.out.println("❌ Exception in selecting Teacher (Self) course view checkbox: " + e.getMessage());
            TestRunner.getTest().log(Status.FAIL, "❌ Exception in selecting Teacher (Self) course view checkbox: " + e.getMessage());
            softAssert.fail("Exception in selecting Teacher (Self) course view checkbox: " + e.getMessage());
        }
    }

    public void clickRunReportButton() throws InterruptedException {
        WebElement runReportButton = driver.findElement(By.xpath("//button[contains(@class, 'applyButton') and contains(., 'Run Report')]"));
        scrollToAndClick(runReportButton, "Run Report Button");
    }

    public void scrollToAndClick(WebElement element, String elementName) throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into click on " + elementName);
        System.out.println("I'm into click on " + elementName);

        try {
            helper.scrollToElement(driver, element);
            Thread.sleep(1000); // Wait for scroll and animation

            if (element.isDisplayed() && element.isEnabled()) {
                element.click();
                System.out.println("✅ Test Passed: '" + elementName + "' is enabled and clicked successfully");
                TestRunner.getTest().log(Status.PASS, "✅ Test Passed: '" + elementName + "' is enabled and clicked successfully");
                Thread.sleep(2000); // Wait for action to process
            } else {
                System.out.println("❌ Test Failed: '" + elementName + "' is found but not enabled or visible");
                TestRunner.getTest().log(Status.FAIL, "❌ Test Failed: '" + elementName + "' is found but not enabled or visible");
                softAssert.fail("'" + elementName + "' is not enabled or visible");
            }
        } catch (Exception e) {
            System.out.println("❌ Exception in clicking '" + elementName + "': " + e.getMessage());
            TestRunner.getTest().log(Status.FAIL, "❌ Exception in clicking '" + elementName + "': " + e.getMessage());
            softAssert.fail("Exception in clicking '" + elementName + "': " + e.getMessage());
        }
    }

    public void verifyDataPopulation() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into verify that After Filter [" + appliedFilterName + "] Apply Data is Populated on Right Side");
        System.out.println("I'm into verify that After Filter [" + appliedFilterName + "] Apply Data is Populated on Right Side");

        try {
            WebElement tableContainer = driver.findElement(By.id("usage-report-table-container"));

            if (tableContainer.isDisplayed()) {
                // Print Table Headers and verify visibility
                List<WebElement> headers = tableContainer.findElements(By.xpath(".//thead//th"));
                System.out.println("--- Table Headers ---");
                TestRunner.getTest().log(Status.INFO, "--- Table Headers ---");
                
                for (WebElement header : headers) {
                    if (header.isDisplayed()) {
                        String headerText = header.getText().trim().replaceAll("\\s+", " ");
                        if (!headerText.isEmpty()) {
                            System.out.println("✅ Header Visible: " + headerText);
                            TestRunner.getTest().log(Status.PASS, "✅ Header Visible: " + headerText);
                        }
                    } else {
                        System.out.println("❌ Test Failed: A table header is not visible on UI");
                        TestRunner.getTest().log(Status.FAIL, "❌ Test Failed: A table header is not visible on UI");
                        softAssert.fail("Table header not visible");
                    }
                }

                List<WebElement> rows = tableContainer.findElements(By.xpath(".//tbody/tr"));

                if (!rows.isEmpty()) {
                    System.out.println("✅ Test Passed: Table is displayed and contains " + rows.size() + " data rows for filter: " + appliedFilterName);
                    TestRunner.getTest().log(Status.PASS, "✅ Test Passed: Table is displayed and contains data rows for filter: " + appliedFilterName);

                    System.out.println("--- Table Data Rows ---");
                    TestRunner.getTest().log(Status.INFO, "--- Table Data Rows ---");
                    for (int i = 0; i < rows.size(); i++) {
                        List<WebElement> cells = rows.get(i).findElements(By.xpath("./td"));
                        StringBuilder rowData = new StringBuilder("Row " + (i + 1) + ": ");
                        
                        for (int j = 0; j < cells.size(); j++) {
                            String cellText = cells.get(j).getText().trim().replaceAll("\\s+", " ");
                            rowData.append("[Column ").append(j + 1).append(": ").append(cellText).append("]");
                            if (j < cells.size() - 1) {
                                rowData.append(" | ");
                            }
                        }
                        
                        if (rowData.length() > ("Row " + (i + 1) + ": ").length()) {
                            System.out.println(rowData.toString());
                            TestRunner.getTest().log(Status.PASS, rowData.toString());
                        }
                    }
                } else {
                    System.out.println("❌ Test Failed: Table is displayed but no data rows found for filter: " + appliedFilterName);
                    TestRunner.getTest().log(Status.FAIL, "❌ Test Failed: Table is displayed but no data rows found for filter: " + appliedFilterName);
                    softAssert.fail("Table is displayed but no data rows found for filter: " + appliedFilterName);
                }
            } else {
                System.out.println("❌ Test Failed: Usage report table container is not displayed for filter: " + appliedFilterName);
                TestRunner.getTest().log(Status.FAIL, "❌ Test Failed: Usage report table container is not displayed for filter: " + appliedFilterName);
                softAssert.fail("Usage report table container is not displayed for filter: " + appliedFilterName);
            }
        } catch (Exception e) {
            System.out.println("❌ Exception in verifying data population: " + e.getMessage());
            TestRunner.getTest().log(Status.FAIL, "❌ Exception in verifying data population: " + e.getMessage());
            softAssert.fail("Exception in verifying data population: " + e.getMessage());
        }
    }

    public void selectSpecificClassFromClassDropdown() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO,"I'm into Select Specific Class From Select Class Dropdown in Filters Section");
        System.out.println("I'm into Select Specific Class From Select Class Dropdown in Filters Section");

        try {
            WebElement classDropdown = driver.findElement(By.xpath("//label[text()='Select Class']/parent::div"));

            if (classDropdown.isDisplayed()) {
                classDropdown.click();
                Thread.sleep(1000); // Wait for dropdown to open

                WebElement specificClassOption = driver.findElement(By.xpath("//li[contains(., 'FL Grade 5')] | //div[contains(text(), 'FL Grade 5')] | //p[contains(text(), 'FL Grade 5')]"));

                if (specificClassOption.isDisplayed()) {
                    specificClassOption.click();
                    appliedFilterName = "Specific Class (FL Grade 5)";
                    System.out.println("✅ Test Passed: 'Specific Class' option selected successfully");
                    TestRunner.getTest().log(Status.PASS, "✅ Test Passed: 'Specific Class' option selected successfully");
                    Thread.sleep(1000); // Wait for selection to process

                    // Close the dropdown after selection
                    actions.sendKeys(Keys.ESCAPE).build().perform();
                    Thread.sleep(1000);
                } else {
                    System.out.println("❌ Test Failed: 'Specific Class' option not found or visible");
                    TestRunner.getTest().log(Status.FAIL, "❌ Test Failed: 'Specific Class' option not found or visible");
                    softAssert.fail("'Specific Class' option not found or visible");
                }
            } else {
                System.out.println("❌ Test Failed: Select Class dropdown is not displayed");
                TestRunner.getTest().log(Status.FAIL, "❌ Test Failed: Select Class dropdown is not displayed");
                softAssert.fail("Select Class dropdown is not displayed");
            }
        } catch (Exception e) {
            System.out.println("❌ Exception in selecting Specific Class: " + e.getMessage());
            TestRunner.getTest().log(Status.FAIL, "❌ Exception in selecting Specific Class: " + e.getMessage());
            softAssert.fail("Exception in selecting Specific Class: " + e.getMessage());
        }
    }

    public void selectAllStudentsFromStudentDropdown() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into Select All Students From Select Student Dropdown");

        System.out.println("I'm into Select All Students From Select Student Dropdown");

        try {
            WebElement studentDropdown = driver.findElement(By.xpath("//label[text()='Select Student']/parent::div"));

            if (studentDropdown.isDisplayed()) {
                studentDropdown.click();
                Thread.sleep(1000); // Wait for dropdown to open

                WebElement allStudentsOption = driver.findElement(By.xpath("//li[contains(., 'All Students')] | //div[contains(text(), 'All Students')] | //p[contains(text(), 'All Students')]"));

                if (allStudentsOption.isDisplayed()) {
                    allStudentsOption.click();
                    appliedFilterName = "All Students";
                    System.out.println("✅ Test Passed: 'All Students' option selected successfully");
                    TestRunner.getTest().log(Status.PASS, "✅ Test Passed: 'All Students' option selected successfully");
                    Thread.sleep(1000); // Wait for selection to process

                    // Close the dropdown after selection
                    actions.sendKeys(Keys.ESCAPE).build().perform();
                    Thread.sleep(1000);

                    clickRunReportButton();
                    verifyDataPopulation();

                } else {
                    System.out.println("❌ Test Failed: 'All Students' option not found or visible");
                    TestRunner.getTest().log(Status.FAIL, "❌ Test Failed: 'All Students' option not found or visible");
                    softAssert.fail("'All Classes' option not found or visible");
                }
            } else {
                System.out.println("❌ Test Failed: Select Student dropdown is not displayed");
                TestRunner.getTest().log(Status.FAIL, "❌ Test Failed: Select Student dropdown is not displayed");
                softAssert.fail("Select Student dropdown is not displayed");
            }
        } catch (Exception e) {
            System.out.println("❌ Exception in selecting All Students: " + e.getMessage());
            TestRunner.getTest().log(Status.FAIL, "❌ Exception in selecting All Students: " + e.getMessage());
            softAssert.fail("Exception in selecting All Students: " + e.getMessage());
        }
    }

    public void selectSpecificStudentFromStudentDropdown() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into Select Specific Student From Select Student Dropdown ");
        System.out.println("I'm into Select Specific Student From Select Student Dropdown");

        try {
            WebElement studentDropdown = driver.findElement(By.xpath("//label[text()='Select Student']/parent::div"));

            if (studentDropdown.isDisplayed()) {
                studentDropdown.click();
                Thread.sleep(1000); // Wait for dropdown to open

                WebElement specificStudentOption = driver.findElement(By.xpath("//li[contains(., 'David Warner')] | //div[contains(text(), 'David Warner')] | //p[contains(text(), 'David Warner')]"));

                if (specificStudentOption.isDisplayed()) {
                    specificStudentOption.click();
                    appliedFilterName = "Specific Student (David Warner)";
                    System.out.println("✅ Test Passed: 'Specific Student' option selected successfully");
                    TestRunner.getTest().log(Status.PASS, "✅ Test Passed: 'Specific Student' option selected successfully");
                    Thread.sleep(1000); // Wait for selection to process

                    // Close the dropdown after selection
                    actions.sendKeys(Keys.ESCAPE).build().perform();
                    Thread.sleep(1000);

                    clickRunReportButton();
                    verifyDataPopulation();
                } else {
                    System.out.println("❌ Test Failed: 'Specific Student' option not found or visible");
                    TestRunner.getTest().log(Status.FAIL, "❌ Test Failed: 'Specific Student' option not found or visible");
                    softAssert.fail("'Specific Student' option not found or visible");
                }
            } else {
                System.out.println("❌ Test Failed: Select Student dropdown is not displayed");
                TestRunner.getTest().log(Status.FAIL, "❌ Test Failed: Select Student dropdown is not displayed");
                softAssert.fail("Select Student dropdown is not displayed");
            }
        } catch (Exception e) {
            System.out.println("❌ Exception in selecting Specific Student: " + e.getMessage());
            TestRunner.getTest().log(Status.FAIL, "❌ Exception in selecting Specific Student: " + e.getMessage());
            softAssert.fail("Exception in selecting Specific Student: " + e.getMessage());
        }

    }

    public void clickLoginsIndividualUsersCheckbox(String checkboxName) throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into Click on '" + checkboxName + "' Checkbox from Logins: Individual Users");
        System.out.println("I'm into Click on '" + checkboxName + "' Checkbox from Logins: Individual Users");

        try {
            WebElement checkboxLabel = driver.findElement(By.xpath("//p[text()='Logins: Individual Users']/following-sibling::div//span[text()='" + checkboxName + "']/ancestor::label"));
            
            if (checkboxLabel.isDisplayed()) {
                checkboxLabel.click();
                appliedFilterName = "Logins: " + checkboxName;
                System.out.println("✅ Test Passed: '" + checkboxName + "' checkbox clicked successfully");
                TestRunner.getTest().log(Status.PASS, "✅ Test Passed: '" + checkboxName + "' checkbox clicked successfully");
                Thread.sleep(1000); // Wait for selection to process
            } else {
                System.out.println("❌ Test Failed: '" + checkboxName + "' checkbox is not displayed");
                TestRunner.getTest().log(Status.FAIL, "❌ Test Failed: '" + checkboxName + "' checkbox is not displayed");
                softAssert.fail("'" + checkboxName + "' checkbox is not displayed");
            }
        } catch (Exception e) {
            System.out.println("❌ Exception in clicking '" + checkboxName + "' checkbox: " + e.getMessage());
            TestRunner.getTest().log(Status.FAIL, "❌ Exception in clicking '" + checkboxName + "' checkbox: " + e.getMessage());
            softAssert.fail("Exception in clicking '" + checkboxName + "' checkbox: " + e.getMessage());
        }
    }

    public void SelectLoginsIndividualUsersCheckbox() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into Select and Validate Logins: Individual Users Scenarios");
        System.out.println("I'm into Select and Validate Logins: Individual Users Scenarios");

        // 1. Click on All Individual users
        clickLoginsIndividualUsersCheckbox("All Individual Users");
        // then click on Run Report button
        clickRunReportButton();
        // then validate data populated in table
        verifyDataPopulation();

        // then uncheck All individual users check box
        clickLoginsIndividualUsersCheckbox("All Individual Users");

        // then select the Teacher(Self) checkbox
        clickLoginsIndividualUsersCheckbox("Teacher (Self)");
        // then click on Run report
        clickRunReportButton();
        // and then validate Data populated in Table
        verifyDataPopulation();

        // then uncheck this Teacher(Self) checkbox
        clickLoginsIndividualUsersCheckbox("Teacher (Self)");

        // and then Click on Students from Logins: Individual Users
        clickLoginsIndividualUsersCheckbox("Students");
        // then run report
        clickRunReportButton();
        // and validate data populated
        verifyDataPopulation();
    }

    public void clickTotalLoginsCheckbox(String checkboxName) throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into Click on '" + checkboxName + "' Checkbox from Total Logins");
        System.out.println("I'm into Click on '" + checkboxName + "' Checkbox from Total Logins");

        try {
            WebElement checkboxLabel = driver.findElement(By.xpath("//p[text()='Total Logins']/following-sibling::div//span[text()='" + checkboxName + "']/ancestor::label"));

            if (checkboxLabel.isDisplayed()) {
                checkboxLabel.click();
                appliedFilterName = "Total Logins: " + checkboxName;
                System.out.println("✅ Test Passed: '" + checkboxName + "' checkbox clicked successfully");
                TestRunner.getTest().log(Status.PASS, "✅ Test Passed: '" + checkboxName + "' checkbox clicked successfully");
                Thread.sleep(1000); // Wait for selection to process
            } else {
                System.out.println("❌ Test Failed: '" + checkboxName + "' checkbox is not displayed");
                TestRunner.getTest().log(Status.FAIL, "❌ Test Failed: '" + checkboxName + "' checkbox is not displayed");
                softAssert.fail("'" + checkboxName + "' checkbox is not displayed");
            }
        } catch (Exception e) {
            System.out.println("❌ Exception in clicking '" + checkboxName + "' checkbox: " + e.getMessage());
            TestRunner.getTest().log(Status.FAIL, "❌ Exception in clicking '" + checkboxName + "' checkbox: " + e.getMessage());
            softAssert.fail("Exception in clicking '" + checkboxName + "' checkbox: " + e.getMessage());
        }
    }

    public void SelectTotalLoginsCheckbox() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into Select and Validate Total Logins Scenarios");
        System.out.println("I'm into Select and Validate Total Logins Scenarios");

        // 1. Click on All Logins
        clickTotalLoginsCheckbox("All Logins");
        // then click on Run Report button
        clickRunReportButton();
        // then validate data populated in table
        verifyDataPopulation();

        // then uncheck All Logins
        clickTotalLoginsCheckbox("All Logins");

        // then select the Teacher(Self) checkbox
        clickTotalLoginsCheckbox("Teacher (Self)");
        // then click on Run report
        clickRunReportButton();
        // and then validate Data populated in Table
        verifyDataPopulation();

        // then uncheck this Teacher(Self) checkbox
        clickTotalLoginsCheckbox("Teacher (Self)");

        // and then Click on Students from Total Logins
        clickTotalLoginsCheckbox("Students");
        // then run report
        clickRunReportButton();
        verifyDataPopulation();
        
        // then uncheck Students
        clickTotalLoginsCheckbox("Students");
    }

    public void clickAssignmentsCheckbox(String checkboxName) throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into Click on '" + checkboxName + "' Checkbox from Assignments Section");
        System.out.println("I'm into Click on '" + checkboxName + "' Checkbox from Assignments Section");

        try {
            WebElement checkboxLabel = driver.findElement(By.xpath("//p[text()='Assignments']/following-sibling::div//span[text()='" + checkboxName + "']/ancestor::label"));

            if (checkboxLabel.isDisplayed()) {
                checkboxLabel.click();
                appliedFilterName = "Assignments: " + checkboxName;
                System.out.println("✅ Test Passed: '" + checkboxName + "' checkbox clicked successfully");
                TestRunner.getTest().log(Status.PASS, "✅ Test Passed: '" + checkboxName + "' checkbox clicked successfully");
                Thread.sleep(1000); // Wait for selection to process
            } else {
                System.out.println("❌ Test Failed: '" + checkboxName + "' checkbox is not displayed");
                TestRunner.getTest().log(Status.FAIL, "❌ Test Failed: '" + checkboxName + "' checkbox is not displayed");
                softAssert.fail("'" + checkboxName + "' checkbox is not displayed");
            }
        } catch (Exception e) {
            System.out.println("❌ Exception in clicking '" + checkboxName + "' checkbox: " + e.getMessage());
            TestRunner.getTest().log(Status.FAIL, "❌ Exception in clicking '" + checkboxName + "' checkbox: " + e.getMessage());
            softAssert.fail("Exception in clicking '" + checkboxName + "' checkbox: " + e.getMessage());
        }
    }

    public void SelectAssignmentsCheckbox() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into Select and Validate Assignments Scenarios (Cumulative)");
        System.out.println("I'm into Select and Validate Assignments Scenarios (Cumulative)");

        String[] assignments = {
                "Assignments Created",
                "Assignments Started",
                "Assignments Submitted",
                "Assignments Graded",
                "Average Assignment Time"
        };

        for (String assignment : assignments) {
            // Click to check (cumulative - we don't uncheck previous ones)
            clickAssignmentsCheckbox(assignment);
            
            // then click on Run Report button
            clickRunReportButton();
            
            // then validate data populated in table
            verifyDataPopulation();
        }
    }

    public void SelectTotalLoginsCheckboxWithoutCoursesViewCheckbox() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into Apply Total Logins Filter Checkbox");
        System.out.println("I'm into Apply Total Logins Filter Checkbox");

        // 1. Click on All Logins
        clickTotalLoginsCheckbox("All Logins");
        // then click on Run Report button
        clickRunReportButton();
        // then validate data populated in table
        verifyDataPopulation();
        validateUnderlinedValuesAndDetailsDialog("Total Logins");

        // then uncheck All Logins
        clickTotalLoginsCheckbox("All Logins");

        // then select the Teacher(Self) checkbox
        clickTotalLoginsCheckbox("Teacher (Self)");
        // then click on Run report
        clickRunReportButton();
        // and then validate Data populated in Table
        verifyDataPopulation();
        validateUnderlinedValuesAndDetailsDialog("Total Logins");

        // then uncheck this Teacher(Self) checkbox
        clickTotalLoginsCheckbox("Teacher (Self)");

        // and then Click on Students from Total Logins
        clickTotalLoginsCheckbox("Students");
        // then run report
        clickRunReportButton();
        // and validate data populated
        verifyDataPopulation();
        validateUnderlinedValuesAndDetailsDialog("Total Logins");

        // then uncheck Students
        clickTotalLoginsCheckbox("Students");

    }

    public void selectSpecificStudent() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into Select Specific Student");
        System.out.println("I'm into Select Specific Student");

        try {
            WebElement studentDropdown = driver.findElement(By.xpath("//label[text()='Select Student']/parent::div"));

            if (studentDropdown.isDisplayed()) {
                studentDropdown.click();
                Thread.sleep(1000); // Wait for dropdown to open

                WebElement specificStudentOption = driver.findElement(By.xpath("//li[contains(., 'David Warner')] | //div[contains(text(), 'David Warner')] | //p[contains(text(), 'David Warner')]"));

                if (specificStudentOption.isDisplayed()) {
                    specificStudentOption.click();
                    appliedFilterName = "Specific Student (David Warner)";
                    System.out.println("✅ Test Passed: 'Specific Student' option selected successfully");
                    TestRunner.getTest().log(Status.PASS, "✅ Test Passed: 'Specific Student' option selected successfully");
                    Thread.sleep(1000); // Wait for selection to process

                    // Close the dropdown after selection
                    actions.sendKeys(Keys.ESCAPE).build().perform();
                    Thread.sleep(1000);

                } else {
                    System.out.println("❌ Test Failed: 'Specific Student' option not found or visible");
                    TestRunner.getTest().log(Status.FAIL, "❌ Test Failed: 'Specific Student' option not found or visible");
                    softAssert.fail("'Specific Student' option not found or visible");
                }
            } else {
                System.out.println("❌ Test Failed: Select Student dropdown is not displayed");
                TestRunner.getTest().log(Status.FAIL, "❌ Test Failed: Select Student dropdown is not displayed");
                softAssert.fail("Select Student dropdown is not displayed");
            }
        } catch (Exception e) {
            System.out.println("❌ Exception in selecting Specific Student: " + e.getMessage());
            TestRunner.getTest().log(Status.FAIL, "❌ Exception in selecting Specific Student: " + e.getMessage());
            softAssert.fail("Exception in selecting Specific Student: " + e.getMessage());
        }

    }

    public void validateUnderlinedValuesAndDetailsDialog(String baseContext) throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into Validate Underlined Values and Details Dialog with base context: " + baseContext);
        System.out.println("I'm into Validate Underlined Values and Details Dialog with base context: " + baseContext);

        try {
            WebElement tableContainer = driver.findElement(By.id("usage-report-table-container"));
            
            // Get Headers to dynamically map columns
            List<WebElement> headers = tableContainer.findElements(By.xpath(".//thead/tr/th"));
            if (headers.isEmpty()) {
                headers = tableContainer.findElements(By.xpath(".//tbody/tr[1]/th")); // Fallback for some table structures
            }

            List<WebElement> rows = tableContainer.findElements(By.xpath(".//tbody/tr"));

            if (rows.isEmpty()) {
                System.out.println("ℹ️ Info: No data rows found in the table for validation.");
                TestRunner.getTest().log(Status.INFO, "ℹ️ Info: No data rows found in the table for validation.");
                return;
            }

            // Limit to first 2 rows for performance
            int rowLimit = Math.min(rows.size(), 2);
            for (int i = 0; i < rowLimit; i++) {
                // Re-find rows to avoid stale element after closing dialog
                rows = tableContainer.findElements(By.xpath(".//tbody/tr"));
                WebElement row = rows.get(i);
                
                // Extract User Name from the first column
                String userName = row.findElement(By.xpath("./td[1]")).getText().trim();
                
                // Iterate through cells starting from the second column
                List<WebElement> cells = row.findElements(By.xpath("./td"));

                for (int j = 1; j < cells.size(); j++) {
                    // Re-locate cell to prevent stale exception
                    cells = row.findElements(By.xpath("./td"));
                    WebElement cell = cells.get(j);
                    
                    // Determine category from header (aligned with category cells starting at index 1)
                    // We use the last row of headers which contains the specific categories
                    List<WebElement> catHeaders = tableContainer.findElements(By.xpath(".//thead/tr[last()]/th"));
                    // If USERS column is a rowspan, catHeaders.get(0) corresponds to cells.get(1)
                    String rawHeader = "";
                    if (catHeaders.size() < cells.size()) {
                        rawHeader = catHeaders.get(j-1).getText().trim().toUpperCase();
                    } else {
                        rawHeader = catHeaders.get(j).getText().trim().toUpperCase();
                    }
                    
                    String categoryContext = "";
                    boolean isAllLogins = false;
                    
                    if (rawHeader.contains("TEACHER")) categoryContext = "Teachers";
                    else if (rawHeader.contains("STUDENT")) categoryContext = "Students";
                    else if (rawHeader.contains("ALL LOGINS")) {
                        categoryContext = "All Logins";
                        isAllLogins = true;
                    }
                    else categoryContext = rawHeader; 

                    List<WebElement> underlinedSpans = cell.findElements(By.xpath(".//span[contains(@style, 'text-decoration: underline')]"));

                    if (!underlinedSpans.isEmpty()) {
                        WebElement valueToClick = underlinedSpans.get(0);
                        String valueText = valueToClick.getText().trim();
                        
                        System.out.println("🖱️ Clicking [" + valueText + "] in column [" + rawHeader + "] for User: " + userName);
                        TestRunner.getTest().log(Status.INFO, "🖱️ Clicking [" + valueText + "] in column [" + rawHeader + "] for User: " + userName);
                        
                        valueToClick.click();
                        Thread.sleep(2000); // Wait for dialog to open

                        // Verify Dialog Title - handles different heading tags (h2/h6)
                        WebElement dialogTitleElement = driver.findElement(By.xpath("//div[@id='dialog-title']//*[self::h2 or self::h6]"));
                        String dialogTitle = dialogTitleElement.getText().trim();
                        
                        System.out.println("📋 Dialog Title Found: " + dialogTitle);
                        TestRunner.getTest().log(Status.INFO, "📋 Dialog Title Found: " + dialogTitle);

                        String expectedTitleContext = baseContext + " (" + categoryContext + ")";

                        // Fix for All Logins where the suffix might be omitted or title is simple
                        boolean titleMatches = dialogTitle.contains(userName) && 
                                             (dialogTitle.contains(expectedTitleContext) || (isAllLogins && dialogTitle.contains(baseContext)));

                        if (titleMatches) {
                            System.out.println("✅ Test Passed: Dialog title matches user [" + userName + "] and category context");
                            TestRunner.getTest().log(Status.PASS, "✅ Test Passed: Dialog title matches user [" + userName + "] and category context");
                        } else {
                            System.out.println("❌ Test Failed: Dialog title mismatch. Title: [" + dialogTitle + "], Expected User: [" + userName + "], Expected Category Context: [" + expectedTitleContext + "]");
                            TestRunner.getTest().log(Status.FAIL, "❌ Test Failed: Dialog title mismatch. Title: [" + dialogTitle + "], Expected User: [" + userName + "], Expected Category Context: [" + expectedTitleContext + "]");
                            softAssert.fail("Dialog title context mismatch for user: " + userName + ". Expected: "  + expectedTitleContext);
                        }

                        // Extract Data from Dialog Table with Scrolling
                        WebElement dialogScrollContainer = driver.findElement(By.id("student-details-scroll-container"));
                        Set<String> uniqueRecords = new HashSet<>();
                        long currentHeight = (long) js.executeScript("return arguments[0].scrollHeight", dialogScrollContainer);

                        while (true) {
                            List<WebElement> dialogRows = dialogScrollContainer.findElements(By.xpath(".//tbody/tr"));
                            for (WebElement dialogRow : dialogRows) {
                                String recordData = dialogRow.getText().trim().replaceAll("\\s+", " ");
                                if (!recordData.isEmpty()) {
                                    uniqueRecords.add(recordData);
                                }
                            }

                            js.executeScript("arguments[0].scrollTop = arguments[0].scrollHeight", dialogScrollContainer);
                            Thread.sleep(600); // Faster scroll wait

                            long lastHeight = currentHeight;
                            currentHeight = (long) js.executeScript("return arguments[0].scrollHeight", dialogScrollContainer);

                            long currentScrollTop = (long) js.executeScript("return Math.ceil(arguments[0].scrollTop + arguments[0].offsetHeight)", dialogScrollContainer);
                            if (currentScrollTop >= currentHeight || lastHeight == currentHeight) {
                                break;
                            }
                        }

                        System.out.println("📊 Total unique records found: " + uniqueRecords.size());
                        TestRunner.getTest().log(Status.PASS, "📊 Total unique records found: " + uniqueRecords.size());

                        // Log records for visibility (limited to 30 for speed)
                        int count = 1;
                        for (String record : uniqueRecords) {
                            System.out.println("   📄 Record " + count + ": " + record);
                            TestRunner.getTest().log(Status.INFO, "   📄 Record " + count + ": " + record);
                            count++;
                            if (count > 30) {
                                System.out.println("   ... (Logging limited to top 30 records for visibility)");
                                break;
                            }
                        }

                        // Close Dialog
                        WebElement closeButton = driver.findElement(By.xpath("//div[@id='dialog-title']//button"));
                        closeButton.click();
                        Thread.sleep(800); // Wait for dialog to close
                        
                        // Re-identify table parts after DOM change
                        tableContainer = driver.findElement(By.id("usage-report-table-container"));
                    }
                }
            }
        } catch (Exception e) {
            System.out.println("❌ Exception in validating underlined values and details dialog: " + e.getMessage());
            TestRunner.getTest().log(Status.FAIL, "❌ Exception in validating underlined values and details dialog: " + e.getMessage());
            softAssert.fail("Exception in validating underlined values and details dialog: " + e.getMessage());
        }
    }

    public void clearSelectStudentDropdown() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into clear Select Student Dropdown");
        System.out.println("I'm into clear Select Student Dropdown");

        try {
            WebElement clearButton = driver.findElement(By.xpath("//label[text()='Select Student']/parent::div//button[@aria-label='clear all selections']"));
            
            if (clearButton.isDisplayed()) {
                clearButton.click();
                System.out.println("✅ Test Passed: 'Select Student' dropdown cleared successfully");
                TestRunner.getTest().log(Status.PASS, "✅ Test Passed: 'Select Student' dropdown cleared successfully");
                Thread.sleep(1000);
            } else {
                System.out.println("ℹ️ Info: 'clear all selections' button is not displayed (likely no students selected)");
                TestRunner.getTest().log(Status.INFO, "ℹ️ Info: 'clear all selections' button is not displayed (likely no students selected)");
            }
        } catch (Exception e) {
            System.out.println("❌ Exception in clearing 'Select Student' dropdown: " + e.getMessage());
            TestRunner.getTest().log(Status.FAIL, "❌ Exception in clearing 'Select Student' dropdown: " + e.getMessage());
            softAssert.fail("Exception in clearing 'Select Student' dropdown: " + e.getMessage());
        }
    }

    public void checkLoginsIndividualUsersWithoutCourseView() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into Check Logins Individual Users Without CourseView");
        System.out.println("I'm into Check Logins Individual Users Without CourseView");

        // 1. Click on All Individual Users
        clickLoginsIndividualUsersCheckbox("All Individual Users");
        // then click on Run Report button
        clickRunReportButton();
        // then validate data populated in table
        verifyDataPopulation();

        // then uncheck All Individual Users
        clickLoginsIndividualUsersCheckbox("All Individual Users");

        // then select the Teacher(Self) checkbox
        clickLoginsIndividualUsersCheckbox("Teacher (Self)");
        // then click on Run report
        clickRunReportButton();
        // and then validate Data populated in Table
        verifyDataPopulation();
        validateUnderlinedValuesAndDetailsDialog("Individual Logins");

        // then uncheck this Teacher(Self) checkbox
        clickLoginsIndividualUsersCheckbox("Teacher (Self)");

        // and then Click on Students from Logins: Individual Users
        clickLoginsIndividualUsersCheckbox("Students");
        // then run report
        clickRunReportButton();
        // and validate data populated
        verifyDataPopulation();
        validateUnderlinedValuesAndDetailsDialog("Individual Logins");
    }

    public void validateExportFunctionalityWithMultipleFormats() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into Validate Export Functionality for both Excel and CSV formats");
        System.out.println("I'm into Validate Export Functionality for both Excel and CSV formats");

        try {
            // Refined Locators based on HTML structure
            By mainExportBtn = By.xpath("//button[contains(@class, 'exportButton') and contains(., 'Export')]");
            By dialogContainer = By.xpath("//div[@role='dialog' and .//h2[text()='Export Options']]");
            By excelOption = By.xpath("//div[@role='dialog']//span[text()='Excel']/ancestor::div[contains(@class, 'cursor-pointer')]");
            By csvOption = By.xpath("//div[@role='dialog']//span[text()='CSV']/ancestor::div[contains(@class, 'cursor-pointer')]");
            By dialogExportBtn = By.xpath("//div[contains(@class, 'bg-gray-50')]//button[contains(., 'Export')]");

            // --- 1. Excel Export Flow ---
            WebElement exportBtn = driver.findElement(mainExportBtn);
            scrollToAndClick(exportBtn, "Main Export Button");
            
            wait.until(ExpectedConditions.visibilityOfElementLocated(dialogContainer));
            System.out.println("✅ Export Options dialogue appeared");

            WebElement excelOpt = driver.findElement(excelOption);
            excelOpt.click();
            System.out.println("✅ Excel option selected");
            TestRunner.getTest().log(Status.PASS, "✅ Excel option selected");

            WebElement diagExpBtn = driver.findElement(dialogExportBtn);
            diagExpBtn.click();
            System.out.println("✅ Export button in dialogue clicked for Excel");
            TestRunner.getTest().log(Status.PASS, "✅ Export button in dialogue clicked for Excel");
            wait.until(ExpectedConditions.invisibilityOfElementLocated(dialogContainer));
            Thread.sleep(1000); // Extra buffer for UI stability

            // --- 2. CSV Export Flow ---
            exportBtn = driver.findElement(mainExportBtn);
            scrollToAndClick(exportBtn, "Main Export Button again");
            
            wait.until(ExpectedConditions.visibilityOfElementLocated(dialogContainer));
            System.out.println("✅ Export Options dialogue appeared again");

            WebElement csvOpt = driver.findElement(csvOption);
            csvOpt.click();
            System.out.println("✅ CSV option selected");
            TestRunner.getTest().log(Status.PASS, "✅ CSV option selected");

            diagExpBtn = driver.findElement(dialogExportBtn);
            diagExpBtn.click();
            System.out.println("✅ Export button in dialogue clicked for CSV");
            TestRunner.getTest().log(Status.PASS, "✅ Export button in dialogue clicked for CSV");
            Thread.sleep(2000); // Wait for dialogue to close and report to run

        } catch (Exception e) {
            System.out.println("❌ Exception in validating export functionality: " + e.getMessage());
            TestRunner.getTest().log(Status.FAIL, "❌ Exception in validating export functionality: " + e.getMessage());
            softAssert.fail("Exception in validating export functionality: " + e.getMessage());
        }
    }

    public void printUsageReport() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into Validate and Perform Printing on User Usage");
        System.out.println("I'm into Validate and Perform Printing on User Usage");

        try {
            WebElement printButton = driver.findElement(By.xpath("//button[contains(@class, 'printButton') and contains(., 'Print')]"));
            scrollToAndClick(printButton, "Print Button");
            
            System.out.println("✅ Test Passed: Print button clicked successfully");
            TestRunner.getTest().log(Status.PASS, "✅ Test Passed: Print button clicked successfully");
            ValidatePrintLoading();
        } catch (Exception e) {
            System.out.println("❌ Exception in clicking Print button: " + e.getMessage());
            TestRunner.getTest().log(Status.FAIL, "❌ Exception in clicking Print button: " + e.getMessage());
            softAssert.fail("Exception in clicking Print button: " + e.getMessage());
        }
    }

    public void ValidatePrintLoading() throws InterruptedException {
//        Thread.sleep(2000);
        WebElement loader = driver.findElement(By.xpath("//h6[contains(text(),'Printing process')]"));
        wait.until(ExpectedConditions.invisibilityOf(loader));
        TestRunner.getTest().log(Status.PASS, "Testcase Passed   :  Printing Action Perform successfully");
    }
}
