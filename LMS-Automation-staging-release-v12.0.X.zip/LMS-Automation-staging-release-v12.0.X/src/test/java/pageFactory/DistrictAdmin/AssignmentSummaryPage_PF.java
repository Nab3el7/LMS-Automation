package pageFactory.DistrictAdmin;
import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;
import java.util.Random;

public class AssignmentSummaryPage_PF {
    Helper helper;
    public WebDriverWait wait;
    WebDriver driver;
//    String district = "Florida Demo District";
//    String school = "Florida ES";
//    String staff = "Maria Gomez";
@FindBy(xpath = "(//div[contains(@class, 'UsageStatisticsWrapper')])[1]")
WebElement Card_UsageStatistics;
//
    String tab_assignment = "//div[@aria-label='Platform']";
//    @FindBy(xpath = "//label[contains(text(),'District')]/following-sibling::div")
//    WebElement Select_District;
    @FindBy(xpath = "//label[contains(text(),'School')]/following-sibling::div")
    WebElement dropDown_School;
    @FindBy(xpath = "//label[contains(text(),'Staff')]/following-sibling::div")
    WebElement dropDown_Staff;

    @FindBy(xpath = ".//button[@id='AssignmentsCreatedTable']")
    WebElement Icon_button;

    public AssignmentSummaryPage_PF(WebDriver driver) {
        this.driver = Configurations.getDriver();
        helper = new Helper();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));

    }

    public static String selectedDistrict;
    public static String selectedSchool;

    public void selectAssignmentTabs() throws InterruptedException{
        Card_UsageStatistics.isDisplayed();
        WebElement tab_Assignment = Card_UsageStatistics.findElement(By.xpath(tab_assignment));
        TestRunner.getTest().log(Status.PASS, "Test Case Passed : My Assignment grid shows successfully");
        tab_Assignment.click();

        List<WebElement> AssignmentTabs = tab_Assignment.findElements(By.xpath(".//button"));
        TestRunner.getTest().log(Status.INFO, "Total assignment tabs is : "+ AssignmentTabs.size());

        for (WebElement AssignmentTab : AssignmentTabs) {
            String tabText = AssignmentTab.getText();
            TestRunner.getTest().log(Status.INFO, "Assignment tab(s) name is: " +tabText);
            AssignmentTab.click();
            Thread.sleep(1000);
        }

        WebElement openTab = tab_Assignment.findElement(By.xpath(".//span[contains(text(), 'Today')]"));
        System.out.println("Click on Open tab " + openTab.getText());
        TestRunner.getTest().log(Status.PASS, "Test Case Passed : Open tab is selected successfully");
        openTab.click();
        Thread.sleep(1000);

        SelectDistrictFromDropdown();
        SelectSchoolFromDropDown();
        validateAndSelectStaffFromDropdown();
    }
public void SelectDistrictFromDropdown() throws InterruptedException {
    TestRunner.getTest().log(Status.INFO, "I'm into select District from Staff Selection Prompt");
    System.out.println("I'm into select District from Staff Selection Prompt");

    try {
        WebElement districtDropdown = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//label[contains(text(),'District')]/following-sibling::div")));
        districtDropdown.click();

        WebElement listOrganization = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[contains(@role, 'listbox')]")));

        List<WebElement> optionsDistrict = listOrganization.findElements(By.xpath(".//li"));

        System.out.println("District List is: " + optionsDistrict.size());

        if (optionsDistrict.isEmpty()) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: No options found in the District Name dropdown");
            System.out.println("No options found in the District Name dropdown.");
            throw new RuntimeException("No District Name found in dropdown");
        } else {
            System.out.println("Available District Name:");

            for (WebElement organization : optionsDistrict) {
                System.out.println(organization.getText());
            }

            Random random = new Random();
            int randomOrganization = random.nextInt(optionsDistrict.size());
            WebElement selectedOption = optionsDistrict.get(randomOrganization);

            String district = selectedOption.getText();
            selectedOption.click();

            System.out.println("Selected District: " + district);
            TestRunner.getTest().log(Status.INFO, "Selected District is: " + district);
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: District selected successfully");
        }
    } catch (Exception e) {
        TestRunner.getTest().log(Status.FAIL, "No Value found in district dropdown ");
    }
}

    public void SelectSchoolFromDropDown() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into select School from Staff Selection Prompt");
        System.out.println("I'm into select School from Staff Selection Prompt");

        // Click on the dropdown to expand it
        dropDown_School.click();

        // Wait until the dropdown options are visible
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//ul[@role='listbox']//li")));
        List<WebElement> ClassStatusOptions = driver.findElements(By.xpath("//ul[@role='listbox']//li"));

        // Print all available school options
        System.out.println("Available School Options For Collection:");
        for (WebElement option : ClassStatusOptions) {
            System.out.println(option.getText());
        }

        // Initialize a variable to store the selected school

        // Iterate through options and select the desired school
        for (WebElement option : ClassStatusOptions) {
            if (option.getText().equalsIgnoreCase("Florida ES")) {
                option.click();
                selectedSchool = option.getText(); // Store the selected school
                System.out.println("Selected: " + selectedSchool + " School");
                break;
            }
        }

        // Check if a school was successfully selected
        if (selectedSchool != null) {
            TestRunner.getTest().log(Status.PASS, "Test Case Passed   : School selected successfully - " + selectedSchool);
        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : Desired school not found in the dropdown.");
            throw new NoSuchElementException("Desired school not found in the dropdown.");
        }
    }


    public void validateAndSelectStaffFromDropdown() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into select Role from Staff Selection Prompt");
        System.out.println("I'm into select Role from Staff Selection Prompt");

        dropDown_Staff.click();

        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//ul[@role='listbox']//li")));
        List<WebElement> ClassStatusOptions = driver.findElements(By.xpath("//ul[@role='listbox']//li"));

        System.out.println("Available Role Options For Collection:");
        for (WebElement option : ClassStatusOptions) {
            System.out.println(option.getText());
        }

        for (WebElement option : ClassStatusOptions) {
            if (option.getText().equalsIgnoreCase("All")) {
                option.click();
                System.out.println("Selected: " + option.getText() + " Role");
                break;
            }
        }
        TestRunner.getTest().log(Status.PASS, "Test Case Passed   : Role selected successfully for Collection");

    }



    public void AssignmentIcon_Button() throws InterruptedException {
        TestRunner.startTest("Click Icon Button for Assignment Created");
        while (Icon_button.isEnabled()) {
            Thread.sleep(2000);
            Icon_button.click();

        }
        AssignmentSummaryStatus();
    }
        public void AssignmentSummaryStatus() {
            TestRunner.startTest("Assignment Summery List for Assignment Created");
            // Locate the Assignment Summary table
            List<WebElement> rows = driver.findElements(By.xpath("//span[contains(text(),'Assignments Created Summary')]/following-sibling::div"));

            System.out.println("Assignment Type\t\tTotal");

            for (WebElement row : rows) {
                List<WebElement> cells = row.findElements(By.tagName("td"));
                if (cells.size() == 2) {
                    String type = cells.get(0).getText().trim();
                    String total = cells.get(1).getText().trim();
                    System.out.println(type + "\t\t" + total);
                }
            }
        }

    public void exportUsageStatisticsData() throws InterruptedException {
        String[] tabs = {"Today", "This Week", "This Month", "This Year"};

        for (String tabName : tabs) {
            // Click on each tab using its visible text
            WebElement tab = driver.findElement(By.xpath("//button[normalize-space()='Export'" + tabName + "']"));
            tab.click();
            Thread.sleep(1500); // Wait for data to load

            System.out.println("Processing tab: " + tabName);

            // Export: User Logins
            WebElement userLoginExportBtn = driver.findElement(By.xpath("//p[contains(text(),'User Logins')]/following-sibling::a[text()='Export']"));
            userLoginExportBtn.click();
            System.out.println("Exported User Logins for: " + tabName);
            Thread.sleep(1000);

            // Export: Assignments Created
            WebElement assignmentCreatedExportBtn = driver.findElement(By.xpath("//p[contains(text(),'Assignments Created')]/following-sibling::a[text()='Export']"));
            assignmentCreatedExportBtn.click();
            System.out.println("Exported Assignments Created for: " + tabName);
            Thread.sleep(1000);

            // Export: Assignments Submitted
            WebElement assignmentSubmittedExportBtn = driver.findElement(By.xpath("//p[contains(text(),'Assignments Submitted')]/following-sibling::a[text()='Export']"));
            assignmentSubmittedExportBtn.click();
            System.out.println("Exported Assignments Submitted for: " + tabName);
            Thread.sleep(1000);
        }
    }


}


