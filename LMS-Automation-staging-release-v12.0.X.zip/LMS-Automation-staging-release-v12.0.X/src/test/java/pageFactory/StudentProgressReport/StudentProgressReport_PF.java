package pageFactory.StudentProgressReport;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Assignmment.CorrectAnswerExecutor_PF;

import java.time.Duration;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class StudentProgressReport_PF {

    WebDriverWait wait;
    WebDriver driver;
    Helper helper;
    Actions actions;
    JavascriptExecutor js;
    
    // Static variables to store assignment submitted count for comparison
    public static String initialAssignmentsSubmittedCount = "";
    public static int initialSubmittedCount = 0;
    public static int initialTotalCount = 0;


    public StudentProgressReport_PF(WebDriver driver) {
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        helper = new Helper();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        actions = new Actions(driver);
        js = (JavascriptExecutor) driver;
    }


    @FindBy(xpath = "//span[normalize-space(text())='Select Report']/ancestor::div[@role='combobox']")
    WebElement select_report;


    public void GetStudentListAndClickIconForStudentProgressReport() throws InterruptedException {
        Thread.sleep(5000);

        WebElement searchBar = driver.findElement(By.xpath("//input[@placeholder='Search Student']"));

        if (searchBar.isDisplayed()) {

            String specificStudentName = "David Warner";
            searchBar.clear();
            searchBar.sendKeys(specificStudentName);
            Thread.sleep(2000);

            List<WebElement> listStudent = driver.findElements(By.xpath("//div[contains(@class, 'item undefined')]"));

            boolean isStudentFound = false;

            for (WebElement student : listStudent) {
                String studentName = student.getText().trim();
                System.out.println("Student Name is: " + studentName);
                TestRunner.getTest().log(Status.INFO, "Student Name is: " + studentName);

                if (studentName.contains(specificStudentName)) {
                    System.out.println("Specific Student '" + specificStudentName + "' is found in the list.");
                    TestRunner.getTest().log(Status.INFO, "Specific Student '" + specificStudentName + "' is found in the list.");
                    TestRunner.getTest().log(Status.PASS, "Testcase Passed   : Student Name is found in the list successfully");


                    WebElement icon = student.findElement(By.xpath("//div[contains(@class,'item undefined')]//div[contains(@class, 'AvatarsWithDescriptionWrapper')]/following-sibling::img"));

                    if (icon.isDisplayed()) {
                        icon.click();
                        TestRunner.getTest().log(Status.PASS, "Testcase Passed   : Icon clicked successfully for student " +  specificStudentName);

                    } else {
                        TestRunner.getTest().log(Status.FAIL, "Testcase Failed   : Icon not Display for student " +  specificStudentName);
                    }

                    isStudentFound = true;
                    break;
                }
            }

            if (!isStudentFound) {
                System.out.println("Specific Student '" + specificStudentName + "' is not found in the list.");
                TestRunner.getTest().log(Status.FAIL, "Testcase Failed   : Specific student "+ specificStudentName +  "is not found in the list ");
            }
        } else {
            TestRunner.getTest().log(Status.FAIL, "Testcase Failed   :  Search bar is not displayed.");
        }

    }

    public String report_dropdown;

    public void selectReportFromDropDown() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO,"I'm into Select Report From Reports Dropdown");


        select_report.click();

        WebElement listDistrict = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[contains(@role, 'listbox')]")));
        List<WebElement> optionsDistrict = listDistrict.findElements(By.xpath(".//li"));
        Thread.sleep(1000);

        System.out.println("Available Report List is: " + optionsDistrict.size());

        if (optionsDistrict.isEmpty()) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: No options found in the Report dropdown");
            System.out.println("No options found in the Report dropdown.");
            throw new RuntimeException("No Report Value found in dropdown");

        } else {
            System.out.println("Report Dropdown:");

            boolean schoolFound = false;

            for (WebElement school : optionsDistrict) {
                String schoolName = school.getText();
                System.out.println(schoolName);

                if (schoolName.contains("Student Progress Report")) {
                    schoolFound = true;
                    school.click();
                    report_dropdown = schoolName;
                    System.out.println("Selected Report: " + report_dropdown);
                    TestRunner.getTest().log(Status.INFO, "Selected School: " + report_dropdown);
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed: Student Progress Report selected successfully");
                    break;
                }
            }

            Thread.sleep(1000);
            actions.sendKeys(Keys.ESCAPE).perform();

            if (!schoolFound) {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Report 'Student Progress Report' not found");
                System.out.println("Report 'Student Progress Report' not found in dropdown");
                throw new RuntimeException("Report 'Student Progress Report' not found in dropdown");
            }
        }
    }

    public void verifyBreadcrumbOnStudentProgressReport() throws InterruptedException {

        TestRunner.getTest().log(Status.INFO,"I'm into verify Breadcrumb on Student Progress Report");

        WebElement breadcrumb = driver.findElement(By.xpath("//nav[@aria-label='breadcrumb']"));
        String actualBreadcrumb = breadcrumb.getText().trim().replaceAll("\\s+", " ");
        String expectedBreadcrumb = "Home / gradebook / Student Progress / grades";

        if (actualBreadcrumb.equalsIgnoreCase(expectedBreadcrumb)) {
            System.out.println("✅ Test Passed: Breadcrumb is correct → " + actualBreadcrumb);
            TestRunner.getTest().log(Status.PASS, "✅ Test Passed: Breadcrumb is correct and Matched → " + actualBreadcrumb);
        } else {
            System.out.println("❌ Test Failed: Expected '" + expectedBreadcrumb + "' but found '" + actualBreadcrumb + "'");
            TestRunner.getTest().log(Status.FAIL, "❌ Test Failed: Expected '" + expectedBreadcrumb + "' but found '" + actualBreadcrumb + "'");
        }
    }


    public void validateStudentDataOnStudentProgressReport() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into Verify that Student Data is Visible and Present on Student Progress Report");

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

// Locate elements and get text
        String studentName = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//div[contains(@class,'AvatarWrapper')]//h2")
        )).getText().trim();

        String grade = driver.findElement(By.xpath("//div[contains(@class,'AvatarWrapper')]//p[b[normalize-space(text())='Grade:']]/span")).getText().trim();
        String teacher = driver.findElement(By.xpath("//div[contains(@class,'AvatarWrapper')]//p[b[normalize-space(text())='Teacher:']]/span")).getText().trim();
        String className = driver.findElement(By.xpath("//div[contains(@class,'AvatarWrapper')]//p[b[normalize-space(text())='Class:']]/span")).getText().trim();
        String reportGenerated = driver.findElement(By.xpath("//div[contains(@class,'AvatarWrapper')]//p[b[normalize-space(text())='Report Generated:']]/span")).getText().trim();
        String dateRange = driver.findElement(By.xpath("//div[contains(@class,'AvatarWrapper')]//p[b[normalize-space(text())='Date Range:']]/span")).getText().trim();

        boolean allPresent = true;

        if(studentName.isEmpty()) {
            System.out.println("❌ Student Name is missing!");
            TestRunner.getTest().log(Status.WARNING, "Student Name is missing! " + studentName);
            allPresent = false;
        }
        else {
            System.out.println("✅ Student Name: " + studentName);
            TestRunner.getTest().log(Status.PASS, "Student Name: " + studentName);
        }

        if(grade.isEmpty()) {
            System.out.println("❌ Grade is missing!");
            TestRunner.getTest().log(Status.WARNING, "Grade is missing" + grade);
            allPresent = false;
        }
        else {
            System.out.println("✅ Grade: " + grade);
            TestRunner.getTest().log(Status.PASS, "Grade: " + grade);
        }

        if(teacher.isEmpty()) {
            System.out.println("❌ Teacher is missing!");
            TestRunner.getTest().log(Status.WARNING, "Teacher is missing!" + teacher);
            allPresent = false;
        }
        else {
            System.out.println("✅ Teacher: " + teacher);
            TestRunner.getTest().log(Status.PASS, "Teacher: " + teacher);
        }

        if(className.isEmpty()) {
            System.out.println("❌ Class is missing!");
            TestRunner.getTest().log(Status.WARNING, "Class is missing!" + className);
            allPresent = false;
        }
        else {
            System.out.println("✅ Class: " + className);
            TestRunner.getTest().log(Status.PASS, "Class: " + className);
        }

        if(reportGenerated.isEmpty()) {
            System.out.println("❌ Report Generated is missing!");
            TestRunner.getTest().log(Status.WARNING, "Report Generated is missing!" + reportGenerated);
            allPresent = false;
        }
        else {
            System.out.println("✅ Report Generated: " + reportGenerated);
            TestRunner.getTest().log(Status.PASS, "Report Generated: " + reportGenerated);
        }

        if(dateRange.isEmpty()) {
            System.out.println("❌ Date Range is missing!");
            TestRunner.getTest().log(Status.WARNING, "Date Range is missing!" + dateRange);
            allPresent = false;
        }
        else {
            System.out.println("✅ Date Range: " + dateRange);
            TestRunner.getTest().log(Status.PASS, "Date Range:" + dateRange);
        }

// Final test result
        if(allPresent) {
            System.out.println("✅ Test Passed: All student information is displayed correctly.");
            TestRunner.getTest().log(Status.PASS,"Test Case Passed: All Student Information is present on Student Progress Report");
        } else {
            System.out.println("❌ Test Failed: Some student information is missing or broken.");
            TestRunner.getTest().log(Status.FAIL,"Test Failed: Some student information is missing or broken.");
        }

    }

    public void verifyViewGradeBookLink() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO," I'm Into Verify View GradeBook link is present");
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        try {
            // Wait until the button is visible
            WebElement viewGradebookBtn = wait.until(ExpectedConditions.visibilityOfElementLocated(
                    By.xpath("//button[normalize-space(text())='View Gradebook']")
            ));

            // If found, click the button
            viewGradebookBtn.click();
            System.out.println("✅ Test Passed: 'View Gradebook' button is present and clicked.");
            TestRunner.getTest().log(Status.PASS, "Test Passed: 'View Gradebook' button is present and clicked And Successfully redirect to GradeBook");

        } catch (TimeoutException e) {
            // If button not found within wait time, fail the test
            System.out.println("❌ Test Failed: 'View Gradebook' button is NOT present.");
            TestRunner.getTest().log(Status.PASS, "Test Failed: 'View Gradebook' button is NOT present..");
        }

    }

    /**
     * Selects an option from the Assignment Status dropdown
     * @param statusOption The status option to select (e.g., "Only Graded", "Only Started", etc.)
     */
    public void selectAssignmentStatusFromDropdown(String statusOption) throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Filtering Assignment By Status: " + statusOption);
        
        try {
            // Try clicking the toggle button first, if not found, click the container
            WebElement statusDropdown = null;
            try {
                // Try clicking the button with aria-label="toggle menu"
                statusDropdown = driver.findElement(By.xpath("//div[@class='statusHeadDropdown']//button[@aria-label='toggle menu']"));
                statusDropdown.click();
                System.out.println("Clicked dropdown using toggle button");
            } catch (Exception e) {
                // Fallback to clicking the container div
                statusDropdown = driver.findElement(By.xpath("//div[@class='statusHeadDropdown']//div[contains(@class, 'flex items-center')]"));
                statusDropdown.click();
                System.out.println("Clicked dropdown using container div");
            }
            
            Thread.sleep(1000); // Wait for dropdown to open
            
            // Wait for the dropdown ul to appear (it doesn't have role='listbox', it's a custom dropdown)
            WebDriverWait extendedWait = new WebDriverWait(driver, Duration.ofSeconds(10));
            List<WebElement> statusOptions = new java.util.ArrayList<>();
            
            try {
                // Wait for the ul with the specific classes (the dropdown menu)
                extendedWait.until(ExpectedConditions.presenceOfElementLocated(
                    By.xpath("//ul[contains(@class, 'absolute') and contains(@class, 'border-gray-300') and contains(@class, 'shadow-lg')]")
                ));
                
                // Find all li elements within the dropdown ul
                statusOptions = driver.findElements(By.xpath("//ul[contains(@class, 'absolute') and contains(@class, 'border-gray-300')]//li"));
                System.out.println("Found options using custom dropdown ul: " + statusOptions.size());
            } catch (TimeoutException e) {
                System.out.println("Custom dropdown ul not found, trying alternative search...");
                
                // Alternative: Find any visible ul with li elements that contain status options
                List<WebElement> allUls = driver.findElements(By.xpath("//ul[.//li]"));
                for (WebElement ul : allUls) {
                    try {
                        if (ul.isDisplayed()) {
                            List<WebElement> lis = ul.findElements(By.xpath(".//li"));
                            if (!lis.isEmpty()) {
                                // Check if any option matches expected status options
                                boolean hasMatchingOption = false;
                                for (WebElement li : lis) {
                                    String text = li.getText().trim().toLowerCase();
                                    if (text.contains("graded") || text.contains("started") || text.contains("submitted") || 
                                        text.contains("missing") || text.contains("late") || text.contains("all assignments")) {
                                        hasMatchingOption = true;
                                        break;
                                    }
                                }
                                if (hasMatchingOption) {
                                    statusOptions = lis;
                                    System.out.println("Found options using visible ul: " + statusOptions.size());
                                    break;
                                }
                            }
                        }
                    } catch (Exception e2) {
                        continue;
                    }
                }
            }
            
            if (statusOptions.isEmpty()) {
                // Take screenshot for debugging
                helper.takeScreenshot(driver, "dropdown_options_not_found");
                System.out.println("❌ No dropdown options found after clicking");
                TestRunner.getTest().log(Status.FAIL, "No dropdown options found. Screenshot saved.");
                throw new RuntimeException("No dropdown options found after clicking the dropdown");
            }
            
            boolean statusFound = false;
            
            // Check if the status is in the dropdown
            // The text is inside a <span> tag within each <li>
            for (WebElement option : statusOptions) {
                try {
                    // Get text from the span or directly from li
                    String optionText = option.getText().trim();
                    System.out.println("Found option: " + optionText);
                    if (optionText.equalsIgnoreCase(statusOption)) {
                        option.click();
                        statusFound = true;
                        System.out.println("✅ Selected Assignment Status: " + statusOption);
                        TestRunner.getTest().log(Status.INFO, "Selected Status: " + optionText);
                        break;
                    }
                } catch (StaleElementReferenceException e) {
                    System.out.println("Stale element encountered, continuing...");
                    continue;
                }
            }
            
            if (!statusFound) {
                System.out.println("❌ Option '" + statusOption + "' not found in dropdown");
                TestRunner.getTest().log(Status.FAIL, "Status not found in the dropdown: " + statusOption);
                throw new RuntimeException("Status not found in the dropdown: " + statusOption);
            }
            
            // Wait for table to update after selection
            Thread.sleep(3000);
            
        } catch (Exception e) {
            System.out.println("Error selecting Assignment Status: " + e.getMessage());
            TestRunner.getTest().log(Status.FAIL, "Exception occurred while filtering by status: " + statusOption + ". Error: " + e.getMessage());
            throw e;
        }
    }

    /**
     * Gets all status labels from the assignments table
     * @return List of status labels found in the table
     */
    public List<String> getAllStatusLabelsFromTable() throws InterruptedException {
        List<String> statusLabels = new java.util.ArrayList<>();
        
        try {
            // Wait for table to be present (check for any table in the report)
            wait.until(ExpectedConditions.presenceOfElementLocated(
                    By.xpath("//table[contains(@class, 'table-auto')]")
            ));

            // Find all status chips in all tables (including category accordions)
            // The status is displayed in a MuiChip component
            List<WebElement> statusChips = driver.findElements(
                    By.xpath("//table[contains(@class, 'table-auto')]//span[contains(@class, 'MuiChip-label')]")
            );

            for (WebElement chip : statusChips) {
                try {
                    String statusText = chip.getText().trim();
                    if (!statusText.isEmpty()) {
                        statusLabels.add(statusText);
                    }
                } catch (StaleElementReferenceException e) {
                    // If element becomes stale, skip it
                    System.out.println("Stale element encountered, skipping...");
                }
            }

            System.out.println("Found " + statusLabels.size() + " status labels in table");
            TestRunner.getTest().log(Status.INFO, "Found " + statusLabels.size() + " status labels in table: " + statusLabels);

        } catch (Exception e) {
            System.out.println("Error getting status labels: " + e.getMessage());
            TestRunner.getTest().log(Status.WARNING, "Error getting status labels: " + e.getMessage());
        }

        return statusLabels;
    }

    /**
     * Checks if the table has any data rows
     * @return true if table has data, false otherwise
     */
    public boolean hasTableData() throws InterruptedException {
        try {
            // Check if any table body has rows (excluding header)
            // This checks all tables including category accordions
            List<WebElement> tableRows = driver.findElements(
                    By.xpath("//table[contains(@class, 'table-auto')]//tbody//tr")
            );
            
            boolean hasData = !tableRows.isEmpty();
            System.out.println("Table has data: " + hasData + " (Rows: " + tableRows.size() + ")");
            TestRunner.getTest().log(Status.INFO, "Table has data: " + hasData + " (Rows: " + tableRows.size() + ")");
            
            return hasData;
        } catch (Exception e) {
            System.out.println("Error checking table data: " + e.getMessage());
            TestRunner.getTest().log(Status.WARNING, "Error checking table data: " + e.getMessage());
            return false;
        }
    }

    /**
     * Verifies that all status labels in the table match the expected status for the selected filter
     * @param selectedFilter The selected filter option (e.g., "Only Graded", "Only Started")
     * @param expectedStatuses Array of expected status labels that should appear
     */
    public void verifyStatusLabelsMatchFilter(String selectedFilter, String[] expectedStatuses) throws InterruptedException {
        System.out.println("\n========================================");
        System.out.println("VERIFYING FILTER: " + selectedFilter);
        System.out.println("Expected Status(es): " + String.join(", ", expectedStatuses));
        System.out.println("========================================\n");
        
        TestRunner.getTest().log(Status.INFO, "Verifying status labels for filter: " + selectedFilter);
        TestRunner.getTest().log(Status.INFO, "Expected Status(es): " + String.join(", ", expectedStatuses));
        
        // Check if table has data
        if (!hasTableData()) {
            System.out.println("⚠️ No data in table for filter: " + selectedFilter);
            TestRunner.getTest().log(Status.INFO, "No data in table for filter: " + selectedFilter + " - This is expected if no assignments match the filter");
            return;
        }

        // Get all table rows
        List<WebElement> tableRows = driver.findElements(
                By.xpath("//table[contains(@class, 'table-auto')]//tbody//tr")
        );

        if (tableRows.isEmpty()) {
            System.out.println("⚠️ No rows found in table");
            TestRunner.getTest().log(Status.WARNING, "No rows found in table");
            return;
        }

        System.out.println("Total rows found: " + tableRows.size() + "\n");

        // Verify each row's status matches expected values and print row data
        boolean allMatch = true;
        int rowNumber = 1;
        int processedRowsCount = 0; // Track rows that were actually processed (not skipped)
        
        for (WebElement row : tableRows) {
            try {
                // Get all cells in the row
                List<WebElement> cells = row.findElements(By.xpath(".//td"));
                
                if (cells.isEmpty()) {
                    continue; // Skip empty rows
                }
                
                // Extract row data
                String assignmentName = "";
                String score = "";
                String dueDate = "";
                String status = "";
                String comments = "";
                
                // Get data from each cell (columns: NAME, SCORE, DUE DATE, STATUS, COMMENTS)
                if (cells.size() > 0) {
                    // NAME column - get text from the first cell
                    assignmentName = cells.get(0).getText().trim();
                }
                if (cells.size() > 1) {
                    // SCORE column
                    score = cells.get(1).getText().trim();
                }
                if (cells.size() > 2) {
                    // DUE DATE column
                    dueDate = cells.get(2).getText().trim();
                }
                if (cells.size() > 3) {
                    // STATUS column - get text from MuiChip-label span
                    try {
                        WebElement statusCell = cells.get(3);
                        WebElement statusChip = statusCell.findElement(By.xpath(".//span[contains(@class, 'MuiChip-label')]"));
                        status = statusChip.getText().trim();
                    } catch (Exception e) {
                        // Fallback to cell text if chip not found
                        status = cells.get(3).getText().trim();
                    }
                }
                if (cells.size() > 4) {
                    // COMMENTS column
                    comments = cells.get(4).getText().trim();
                }
                
                // Skip empty rows silently - check if assignment name is empty or all fields are empty
                if (assignmentName.isEmpty() && score.isEmpty() && dueDate.isEmpty() && status.isEmpty()) {
                    continue; // Skip this empty row silently
                }
                
                // Also skip silently if assignment name is empty (main identifier)
                if (assignmentName.isEmpty()) {
                    continue; // Skip rows without assignment names silently
                }
                
                // Skip silently if status is empty (empty rows)
                if (status.isEmpty()) {
                    continue; // Skip rows without status silently
                }
                
                // Print whole row data (only for rows with data)
                System.out.println("\n--- Row " + rowNumber + " Data ---");
                System.out.println("Assignment Name: " + assignmentName);
                System.out.println("Score: " + score);
                System.out.println("Due Date: " + dueDate);
                System.out.println("Status: " + status);
                System.out.println("Comments: " + comments);
                
                TestRunner.getTest().log(Status.INFO, "Row " + rowNumber + " - Assignment: " + assignmentName + 
                    " | Score: " + score + " | Due Date: " + dueDate + " | Status: " + status);
                
                // Verify status matches expected values
                // Normalize both status and expected statuses for comparison (trim and handle variations)
                String normalizedStatus = status.trim().replaceAll("\\s+", " ");
                
                boolean matches = false;
                for (String expectedStatus : expectedStatuses) {
                    String normalizedExpected = expectedStatus.trim().replaceAll("\\s+", " ");
                    if (normalizedStatus.equalsIgnoreCase(normalizedExpected)) {
                        matches = true;
                        break;
                    }
                }
                
                if (!matches) {
                    allMatch = false;
                    System.out.println("❌ Row " + rowNumber + " - Unexpected status found: '" + status + "'" + 
                        " (Expected one of: " + String.join(", ", expectedStatuses) + ")");
                    System.out.println("   Debug - Normalized status: '" + normalizedStatus + "'");
                    // Build normalized expected statuses string for debugging
                    StringBuilder normalizedExpected = new StringBuilder();
                    for (int i = 0; i < expectedStatuses.length; i++) {
                        if (i > 0) normalizedExpected.append(", ");
                        normalizedExpected.append("'").append(expectedStatuses[i].trim().replaceAll("\\s+", " ")).append("'");
                    }
                    System.out.println("   Debug - Expected statuses (normalized): " + normalizedExpected.toString());
                    TestRunner.getTest().log(Status.FAIL, "Row " + rowNumber + " - Unexpected status found: '" + status + 
                        "' for filter: " + selectedFilter + ". Expected: " + String.join(", ", expectedStatuses));
                } else {
                    System.out.println("✅ Row " + rowNumber + " - Status matches: " + status);
                    TestRunner.getTest().log(Status.PASS, "Row " + rowNumber + " - Status matches: " + status);
                }
                
                processedRowsCount++; // Increment only for rows that were processed
                rowNumber++;
                
            } catch (StaleElementReferenceException e) {
                System.out.println("Stale element encountered for row " + rowNumber + ", skipping...");
                // Re-fetch rows if stale
                tableRows = driver.findElements(By.xpath("//table[contains(@class, 'table-auto')]//tbody//tr"));
                continue;
            } catch (Exception e) {
                System.out.println("Error processing row " + rowNumber + ": " + e.getMessage());
                TestRunner.getTest().log(Status.WARNING, "Error processing row " + rowNumber + ": " + e.getMessage());
                rowNumber++;
                continue;
            }
        }

        System.out.println("\n========================================");
        System.out.println("Total rows processed: " + processedRowsCount);
        System.out.println("Total rows found: " + tableRows.size());
        System.out.println("Empty rows skipped: " + (tableRows.size() - processedRowsCount));
        System.out.println("========================================");
        
        if (processedRowsCount == 0) {
            System.out.println("⚠️ No valid rows to verify");
            TestRunner.getTest().log(Status.WARNING, "No valid rows found to verify for filter: " + selectedFilter);
            return;
        }
        
        if (allMatch) {
            System.out.println("✅ VERIFICATION PASSED");
            System.out.println("All " + processedRowsCount + " row(s) have status labels matching expected values");
            System.out.println("Filter: " + selectedFilter);
            System.out.println("Expected Status(es): " + String.join(", ", expectedStatuses));
            System.out.println("========================================\n");
            TestRunner.getTest().log(Status.PASS, "All " + processedRowsCount + " row(s) have status labels matching expected values for filter: " + selectedFilter);
        } else {
            System.out.println("❌ VERIFICATION FAILED");
            System.out.println("Some rows do not have status labels matching expected values");
            System.out.println("Filter: " + selectedFilter);
            System.out.println("Expected Status(es): " + String.join(", ", expectedStatuses));
            System.out.println("========================================\n");
            TestRunner.getTest().log(Status.FAIL, "Some rows do not have status labels matching expected values for filter: " + selectedFilter);
        }
    }

    /**
     * Verifies Assignment Status filter functionality for all filter options
     */
    public void verifyAssignmentStatusFilter() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Verifying Assignment Status filter functionality");

        // Map of filter options to expected status labels
        Map<String, String[]> filterToExpectedStatuses = new LinkedHashMap<>();
        filterToExpectedStatuses.put("Only Graded", new String[]{"Graded"});
        filterToExpectedStatuses.put("Only Missing", new String[]{"Started"});
        filterToExpectedStatuses.put("Only Started", new String[]{"Started"});
        filterToExpectedStatuses.put("Only Submitted", new String[]{"Submitted"});
        filterToExpectedStatuses.put("Only Late", new String[]{"Submitted", "Started"});
        filterToExpectedStatuses.put("All Assignments", new String[]{"Submitted", "Started", "Graded" , "Not Started"});

        for (Map.Entry<String, String[]> entry : filterToExpectedStatuses.entrySet()) {
            String filterOption = entry.getKey();
            String[] expectedStatuses = entry.getValue();

            System.out.println("\n=== Testing filter: " + filterOption + " ===");
            TestRunner.getTest().log(Status.INFO, "Testing filter: " + filterOption);

            // Select the filter option
            selectAssignmentStatusFromDropdown(filterOption);

            // Verify status labels match expected values
            verifyStatusLabelsMatchFilter(filterOption, expectedStatuses);

            Thread.sleep(1000); // Small delay between filter changes
        }
    }

    /**
     * Inner class to represent an Assignment with all its details
     */
    public static class Assignment {
        private String category;
        private String name;
        private String score;
        private String dueDate;
        private String status;
        private String submittedDate;
        private String assignmentComment;
        private String noteFromStudent;

        public Assignment(String category, String name, String score, String dueDate, 
                         String status, String submittedDate, String assignmentComment, String noteFromStudent) {
            this.category = category;
            this.name = name;
            this.score = score;
            this.dueDate = dueDate;
            this.status = status;
            this.submittedDate = submittedDate;
            this.assignmentComment = assignmentComment;
            this.noteFromStudent = noteFromStudent;
        }

        // Getters
        public String getCategory() { return category; }
        public String getName() { return name; }
        public String getScore() { return score; }
        public String getDueDate() { return dueDate; }
        public String getStatus() { return status; }
        public String getSubmittedDate() { return submittedDate; }
        public String getAssignmentComment() { return assignmentComment; }
        public String getNoteFromStudent() { return noteFromStudent; }

        @Override
        public String toString() {
            return "Assignment{" +
                    "category='" + category + '\'' +
                    ", name='" + name + '\'' +
                    ", score='" + score + '\'' +
                    ", dueDate='" + dueDate + '\'' +
                    ", status='" + status + '\'' +
                    ", submittedDate='" + submittedDate + '\'' +
                    ", assignmentComment='" + assignmentComment + '\'' +
                    ", noteFromStudent='" + noteFromStudent + '\'' +
                    '}';
        }
    }

    /**
     * Gets all assignments from all categories on Student Progress Report
     * @return List of Assignment objects containing all assignment details
     */
    public List<Assignment> getAllAssignmentsFromAllCategories() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Retrieving all assignments from all categories");
        List<Assignment> allAssignments = new java.util.ArrayList<>();

        try {
            // Quick scroll to load all categories
            System.out.println("Loading all categories...");
            TestRunner.getTest().log(Status.INFO, "Loading all categories");
            
            // Wait for accordion sections to be present
            wait.until(ExpectedConditions.presenceOfElementLocated(
                    By.xpath("//div[contains(@class, 'customAccordian')]")
            ));
            
            // Instant scroll to bottom to ensure all categories are loaded
            js.executeScript("window.scrollTo(0, document.body.scrollHeight);");

            // Find all accordion sections (categories)
            List<WebElement> accordionButtons = driver.findElements(
                    By.xpath("//div[contains(@class, 'customAccordian')]//button[@type='button']")
            );

            System.out.println("\n========================================");
            System.out.println("RETRIEVING ALL ASSIGNMENTS FROM CATEGORIES");
            System.out.println("Total Categories Found: " + accordionButtons.size());
            System.out.println("========================================\n");
            TestRunner.getTest().log(Status.INFO, "Total Categories Found: " + accordionButtons.size());

            // Iterate through each category accordion
            for (int i = 0; i < accordionButtons.size(); i++) {
                try {
                    // Find all accordion sections (parent divs containing the button and table)
                    List<WebElement> accordionSections = driver.findElements(
                            By.xpath("//div[contains(@class, 'customAccordian')]")
                    );

                    if (i >= accordionSections.size()) {
                        break; // Safety check
                    }

                    WebElement accordionSection = accordionSections.get(i);

                    // Scroll the category into view instantly and wait for it to be visible
                    js.executeScript("arguments[0].scrollIntoView({block: 'center'});", accordionSection);
                    wait.until(ExpectedConditions.visibilityOf(accordionSection));

                    // Get category name from the h3 within this accordion section
                    String categoryName = "";
                    try {
                        WebElement categoryHeader = accordionSection.findElement(
                                By.xpath(".//button[@type='button']//h3")
                        );
                        categoryName = categoryHeader.getText().trim();
                    } catch (Exception e) {
                        try {
                            // Fallback: try to get any h3 text
                            categoryName = accordionSection.findElement(By.xpath(".//h3")).getText().trim();
                        } catch (Exception ex) {
                            categoryName = "Unknown Category";
                        }
                    }

                    System.out.println("\n--- Processing Category: " + categoryName + " ---");
                    TestRunner.getTest().log(Status.INFO, "Processing Category: " + categoryName);

                    // Note: Accordions are already expanded on page load, no need to expand them
                    
                    // Get all rows from the table within this accordion section
                    List<WebElement> rows = accordionSection.findElements(
                            By.xpath(".//table[contains(@class, 'table-auto')]//tbody//tr")
                    );

                    System.out.println("Found " + rows.size() + " assignments in category: " + categoryName);
                    TestRunner.getTest().log(Status.INFO, "Found " + rows.size() + " assignments in " + categoryName);

                    // Process each row
                    for (WebElement row : rows) {
                        try {
                            List<WebElement> cells = row.findElements(By.xpath(".//td"));

                            if (cells.size() < 5) {
                                continue; // Skip rows without enough columns
                            }

                            // Extract data from each cell
                            String assignmentName = "";
                            String score = "";
                            String dueDate = "";
                            String status = "";
                            String submittedDate = "";
                            String assignmentComment = "Not Available";
                            String noteFromStudent = "Not Available";

                            // Column 1: NAME (Assignment Name)
                            try {
                                WebElement nameElement = cells.get(0).findElement(
                                        By.xpath(".//p[contains(@class, 'css-zxaigw')]")
                                );
                                assignmentName = nameElement.getText().trim();
                            } catch (Exception e) {
                                assignmentName = cells.get(0).getText().trim();
                            }

                            // Skip if assignment name is empty
                            if (assignmentName.isEmpty()) {
                                continue;
                            }

                            // Column 2: SCORE
                            score = cells.get(1).getText().trim().replaceAll("\\s+", " ");

                            // Column 3: DUE DATE
                            dueDate = cells.get(2).getText().trim().replaceAll("\\s+", " ");

                            // Column 4: STATUS
                            try {
                                WebElement statusChip = cells.get(3).findElement(
                                        By.xpath(".//span[contains(@class, 'MuiChip-label')]")
                                );
                                status = statusChip.getText().trim();

                                // Get submitted/graded date if available
                                // Look for any paragraph element in the status cell (excluding the status chip)
                                List<WebElement> statusDates = cells.get(3).findElements(
                                        By.xpath(".//p[contains(@class, 'MuiTypography-root') and not(ancestor::span[contains(@class, 'MuiChip')])]")
                                );
                                if (!statusDates.isEmpty()) {
                                    submittedDate = statusDates.get(0).getText().trim();
                                } else {
                                    submittedDate = "--";
                                }
                            } catch (Exception e) {
                                status = cells.get(3).getText().trim();
                                submittedDate = "--";
                            }

                            // Column 5: COMMENTS
                            try {
                                List<WebElement> commentButtons = cells.get(4).findElements(By.xpath(".//button"));
                                
                                if (commentButtons.size() >= 1) {
                                    WebElement assignmentCommentBtn = commentButtons.get(0);
                                    assignmentComment = assignmentCommentBtn.isEnabled() ? "Available" : "Not Available";
                                }
                                
                                if (commentButtons.size() >= 2) {
                                    WebElement noteFromStudentBtn = commentButtons.get(1);
                                    noteFromStudent = noteFromStudentBtn.isEnabled() ? "Available" : "Not Available";
                                }
                            } catch (Exception e) {
                                // Keep default values
                            }

                            // Create Assignment object and add to list
                            Assignment assignment = new Assignment(
                                    categoryName,
                                    assignmentName,
                                    score,
                                    dueDate,
                                    status,
                                    submittedDate,
                                    assignmentComment,
                                    noteFromStudent
                            );

                            allAssignments.add(assignment);

                        } catch (Exception e) {
                            System.out.println("Error processing row in category " + categoryName + ": " + e.getMessage());
                            continue;
                        }
                    }

                } catch (Exception e) {
                    System.out.println("Error processing category: " + e.getMessage());
                    continue;
                }
            }

            // Print summary
            System.out.println("\n========================================");
            System.out.println("TOTAL ASSIGNMENTS RETRIEVED: " + allAssignments.size());
            System.out.println("========================================\n");
            TestRunner.getTest().log(Status.PASS, "Successfully retrieved " + allAssignments.size() + " assignments from all categories");

        } catch (Exception e) {
            System.out.println("Error retrieving assignments: " + e.getMessage());
            TestRunner.getTest().log(Status.FAIL, "Error retrieving assignments: " + e.getMessage());
            e.printStackTrace();
        }

        return allAssignments;
    }

    /**
     * Gets and displays all assignments from all categories with detailed information
     */
    public void displayAllAssignmentsFromAllCategories() throws InterruptedException {
        List<Assignment> assignments = getAllAssignmentsFromAllCategories();

        if (assignments.isEmpty()) {
            System.out.println("⚠️ No assignments found");
            TestRunner.getTest().log(Status.WARNING, "No assignments found in any category");
            return;
        }

        // Group assignments by category
        Map<String, List<Assignment>> assignmentsByCategory = new LinkedHashMap<>();
        for (Assignment assignment : assignments) {
            assignmentsByCategory.computeIfAbsent(assignment.getCategory(), k -> new java.util.ArrayList<>())
                    .add(assignment);
        }

        // Display assignments grouped by category
        System.out.println("\n╔════════════════════════════════════════════════════════════════════════════╗");
        System.out.println("║                     ALL ASSIGNMENTS BY CATEGORY                            ║");
        System.out.println("╚════════════════════════════════════════════════════════════════════════════╝\n");

        int totalCount = 0;
        for (Map.Entry<String, List<Assignment>> entry : assignmentsByCategory.entrySet()) {
            String category = entry.getKey();
            List<Assignment> categoryAssignments = entry.getValue();

            System.out.println("┌────────────────────────────────────────────────────────────────────────────┐");
            System.out.println("│ CATEGORY: " + String.format("%-66s", category) + "│");
            System.out.println("│ Total Assignments: " + String.format("%-57s", categoryAssignments.size()) + "│");
            System.out.println("└────────────────────────────────────────────────────────────────────────────┘");

            for (int i = 0; i < categoryAssignments.size(); i++) {
                Assignment assignment = categoryAssignments.get(i);
                totalCount++;

                System.out.println("\n  Assignment #" + (i + 1));
                System.out.println("  ─────────────────────────────────────────────────────────────────────────");
                System.out.println("  Name             : " + assignment.getName());
                System.out.println("  Score            : " + assignment.getScore());
                System.out.println("  Due Date         : " + assignment.getDueDate());
                System.out.println("  Status           : " + assignment.getStatus());
                System.out.println("  Submitted Date   : " + assignment.getSubmittedDate());
                System.out.println("  Assignment Comment: " + assignment.getAssignmentComment());
                System.out.println("  Note from Student: " + assignment.getNoteFromStudent());

                // Log to extent report
                TestRunner.getTest().log(Status.INFO, 
                    String.format("Assignment #%d [%s] - Name: %s | Score: %s | Status: %s | Due: %s",
                            totalCount, category, assignment.getName(), assignment.getScore(), 
                            assignment.getStatus(), assignment.getDueDate())
                );
            }
            System.out.println();
        }

        System.out.println("╔════════════════════════════════════════════════════════════════════════════╗");
        System.out.println("║ SUMMARY                                                                    ║");
        System.out.println("╠════════════════════════════════════════════════════════════════════════════╣");
        System.out.println("║ Total Categories: " + String.format("%-58s", assignmentsByCategory.size()) + "║");
        System.out.println("║ Total Assignments: " + String.format("%-57s", totalCount) + "║");
        System.out.println("╚════════════════════════════════════════════════════════════════════════════╝\n");

        TestRunner.getTest().log(Status.PASS, 
            "Displayed all assignments: " + totalCount + " assignments across " + assignmentsByCategory.size() + " categories");
    }

    /**
     * Verifies Display Class Average checkbox functionality
     * - Checks if checkbox is displayed and checked initially
     * - Verifies class average is displayed
     * - Prints class average value
     * - Unchecks the checkbox
     * - Verifies class average disappears
     */
    public void verifyDisplayClassAverageCheckboxFunctionality() {
        TestRunner.getTest().log(Status.INFO, "Verifying Display Class Average checkbox functionality");
        
        try {
            // Step 1: Verify checkbox is displayed and checked initially
            System.out.println("\n========================================");
            System.out.println("VERIFYING DISPLAY CLASS AVERAGE CHECKBOX");
            System.out.println("========================================\n");
            
            // This is a custom checkbox, not standard HTML input
            // Fast wait for better performance
            WebDriverWait fastWait = new WebDriverWait(driver, Duration.ofSeconds(5));
            
            // Check if Class Average is visible (indicates checkbox is checked)
            boolean isInitiallyChecked = false;
            List<WebElement> classAvgElements = driver.findElements(
                By.xpath("//p[contains(@class, 'StatLabel') and normalize-space(text())='Class Average']")
            );
            isInitiallyChecked = !classAvgElements.isEmpty() && classAvgElements.get(0).isDisplayed();
            
            WebElement checkboxLabel = null;
            
            if (isInitiallyChecked) {
                System.out.println("✅ Checkbox checked initially");
                TestRunner.getTest().log(Status.PASS, "Display Class Average checkbox is checked initially");
            } else {
                System.out.println("❌ Checkbox NOT checked - checking now");
                TestRunner.getTest().log(Status.INFO, "Checking Display Class Average checkbox");
                
                // Find and click checkbox
                checkboxLabel = fastWait.until(ExpectedConditions.elementToBeClickable(
                    By.xpath("//label[.//span[contains(text(), 'Display Class Average')]]")
                ));
                js.executeScript("arguments[0].click();", checkboxLabel);
                
                // Wait for Class Average to appear
                fastWait.until(ExpectedConditions.visibilityOfElementLocated(
                    By.xpath("//p[contains(@class, 'StatLabel') and normalize-space(text())='Class Average']")
                ));
                System.out.println("✅ Checkbox checked");
                TestRunner.getTest().log(Status.PASS, "Checkbox checked successfully");
                isInitiallyChecked = true;
            }
            
            // Step 2: Get Class Average value
            System.out.println("\nGetting Class Average value...");
            
            try {
                // Find the Class Average section
                WebElement classAverageBox = fastWait.until(ExpectedConditions.visibilityOfElementLocated(
                    By.xpath("//p[contains(@class, 'StatLabel') and normalize-space(text())='Class Average']/ancestor::div[contains(@class, 'ColumnInner')]")
                ));
                
                // Get all paragraph elements
                List<WebElement> statElements = classAverageBox.findElements(By.xpath(".//p"));
                String percentage = "";
                String points = "";
                
                for (WebElement element : statElements) {
                    String text = element.getText().trim();
                    if (text.contains("%")) percentage = text;
                    else if (text.contains("/") && !text.equals("Class Average")) points = text;
                }
                
                System.out.println("✅ Class Average: " + percentage + " | " + points);
                TestRunner.getTest().log(Status.PASS, "Class Average: " + percentage + " | " + points);
            } catch (Exception e) {
                System.out.println("⚠️ Could not get Class Average");
                TestRunner.getTest().log(Status.WARNING, "Could not get Class Average: " + e.getMessage());
            }
            
            // Step 3: Uncheck the checkbox
            System.out.println("\nUnchecking checkbox...");
            TestRunner.getTest().log(Status.INFO, "Unchecking Display Class Average checkbox");
            
            // Find and click checkbox to uncheck
            if (checkboxLabel == null) {
                checkboxLabel = fastWait.until(ExpectedConditions.elementToBeClickable(
                    By.xpath("//label[.//span[contains(text(), 'Display Class Average')]]")
                ));
            }
            js.executeScript("arguments[0].click();", checkboxLabel);
            
            // Step 4: Verify Class Average disappears
            try {
                boolean isHidden = fastWait.until(ExpectedConditions.invisibilityOfElementLocated(
                    By.xpath("//p[contains(@class, 'StatLabel') and normalize-space(text())='Class Average']")
                ));
                if (isHidden) {
                    System.out.println("✅ Checkbox unchecked - Class Average hidden");
                    TestRunner.getTest().log(Status.PASS, "Class Average disappears after unchecking");
                }
            } catch (Exception e) {
                System.out.println("✅ Class Average hidden");
                TestRunner.getTest().log(Status.PASS, "Class Average disappears after unchecking");
            }
            
            System.out.println("\n========================================");
            System.out.println("CHECKBOX VERIFICATION COMPLETE");
            System.out.println("========================================\n");
            TestRunner.getTest().log(Status.PASS, "Display Class Average checkbox functionality verified successfully");
            
        } catch (Exception e) {
            System.out.println("❌ Error verifying Display Class Average checkbox: " + e.getMessage());
            TestRunner.getTest().log(Status.FAIL, "Error verifying Display Class Average checkbox: " + e.getMessage());
        }
    }
    
    /**
     * Gets and stores the initial Assignments Submitted count for later comparison
     * Format: "X/Y" where X is submitted count and Y is total assignments
     */
    public void getAndStoreAssignmentsSubmittedCount() {
        try {
            System.out.println("\n=== Getting Assignments Submitted Count ===");
            TestRunner.getTest().log(Status.INFO, "Getting Assignments Submitted count");
            
            WebDriverWait fastWait = new WebDriverWait(driver, Duration.ofSeconds(5));
            
            // Find the Assignments Submitted section
            WebElement assignmentsSubmittedBox = fastWait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//p[contains(@class, 'StatLabel') and normalize-space(text())='Assignments Submitted']/ancestor::div[contains(@class, 'ColumnInner')]")
            ));
            
            // Get the count value (should be in format "X/Y")
            WebElement countElement = assignmentsSubmittedBox.findElement(
                By.xpath(".//p[contains(@class, 'StatValueLarge')]")
            );
            
            initialAssignmentsSubmittedCount = countElement.getText().trim();
            
            // Parse the count to extract submitted and total
            if (initialAssignmentsSubmittedCount.contains("/")) {
                String[] parts = initialAssignmentsSubmittedCount.split("/");
                initialSubmittedCount = Integer.parseInt(parts[0].trim());
                initialTotalCount = Integer.parseInt(parts[1].trim());
            }
            
            System.out.println("\n========== Assignments Submitted Count ==========");
            System.out.println("  Count: " + initialAssignmentsSubmittedCount);
            System.out.println("  Submitted: " + initialSubmittedCount);
            System.out.println("  Total: " + initialTotalCount);
            System.out.println("=================================================\n");
            
            TestRunner.getTest().log(Status.PASS, "Assignments Submitted Count Retrieved: " + initialAssignmentsSubmittedCount);
            TestRunner.getTest().log(Status.INFO, "Stored - Submitted: " + initialSubmittedCount + " | Total: " + initialTotalCount);
            
        } catch (Exception e) {
            System.out.println("❌ Error getting Assignments Submitted count: " + e.getMessage());
            TestRunner.getTest().log(Status.FAIL, "Error getting Assignments Submitted count: " + e.getMessage());
        }
    }
    
    /**
     * Gets the updated Assignments Submitted count and compares it with the initially stored count
     * Verifies that the count increased after assignment submission
     */
    public void getAndCompareAssignmentsSubmittedCount() {
        try {
            System.out.println("\n=== Comparing Assignments Submitted Count After Submission ===");
            TestRunner.getTest().log(Status.INFO, " Comparing Assignments Submitted Count After Submission  and Getting updated Assignments Submitted count for comparison");
            
            WebDriverWait fastWait = new WebDriverWait(driver, Duration.ofSeconds(5));
            
            // Find the Assignments Submitted section
            WebElement assignmentsSubmittedBox = fastWait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//p[contains(@class, 'StatLabel') and normalize-space(text())='Assignments Submitted']/ancestor::div[contains(@class, 'ColumnInner')]")
            ));
            
            // Get the updated count value
            WebElement countElement = assignmentsSubmittedBox.findElement(
                By.xpath(".//p[contains(@class, 'StatValueLarge')]")
            );
            
            String updatedAssignmentsSubmittedCount = countElement.getText().trim();
            int updatedSubmittedCount = 0;
            int updatedTotalCount = 0;
            
            // Parse the updated count
            if (updatedAssignmentsSubmittedCount.contains("/")) {
                String[] parts = updatedAssignmentsSubmittedCount.split("/");
                updatedSubmittedCount = Integer.parseInt(parts[0].trim());
                updatedTotalCount = Integer.parseInt(parts[1].trim());
            }
            
            // Calculate the difference
            int countDifference = updatedSubmittedCount - initialSubmittedCount;
            
            // Log the updated count in the same format as initial
            System.out.println("\nAssignments Submitted Count Retrieved After Submission: " + updatedAssignmentsSubmittedCount);
            TestRunner.getTest().log(Status.INFO, "Assignments Submitted Count Retrieved After Submission: " + updatedAssignmentsSubmittedCount);
            
            System.out.println("\n========== Assignment Submission Count Comparison ==========");
            TestRunner.getTest().log(Status.INFO, "========== Assignment Submission Count Comparison ==========");
            
            System.out.println("  BEFORE Submission:");
            System.out.println("    Count: " + initialAssignmentsSubmittedCount);
            System.out.println("    Submitted: " + initialSubmittedCount + " | Total: " + initialTotalCount);
            TestRunner.getTest().log(Status.INFO, "BEFORE Submission - Count: " + initialAssignmentsSubmittedCount + " (Submitted: " + initialSubmittedCount + " | Total: " + initialTotalCount + ")");
            
            System.out.println("\n  AFTER Submission:");
            System.out.println("    Count: " + updatedAssignmentsSubmittedCount);
            System.out.println("    Submitted: " + updatedSubmittedCount + " | Total: " + updatedTotalCount);
            TestRunner.getTest().log(Status.INFO, "AFTER Submission - Count: " + updatedAssignmentsSubmittedCount + " (Submitted: " + updatedSubmittedCount + " | Total: " + updatedTotalCount + ")");
            
            System.out.println("\n  DIFFERENCE:");
            System.out.println("    Submitted count increased by: " + countDifference);
            TestRunner.getTest().log(Status.INFO, "DIFFERENCE - Submitted count increased by: " + countDifference);
            
            System.out.println("===========================================================\n");
            
            // Verify the counts are different
            if (updatedSubmittedCount != initialSubmittedCount) {
                System.out.println("✅ VERIFICATION PASSED: Assignment submitted count changed!");
                System.out.println("   Expected: Count should be Increase After Assignment Submission");
                System.out.println("   Result: Initial = " + initialSubmittedCount + ", Updated = " + updatedSubmittedCount);
                
                TestRunner.getTest().log(Status.PASS, "Assignment submitted count increased from " + initialSubmittedCount + " to " + updatedSubmittedCount);
                TestRunner.getTest().log(Status.PASS, "Count After Assignment Submission: +" + countDifference + " assignment(s)");
                
                // Additional check: verify it increased by at least 1
                if (countDifference >= 1) {
                    System.out.println("✅ Assignment Submission Count increased by " + countDifference + " as expected After submission of assignment");
                    TestRunner.getTest().log(Status.PASS, "Assignment submission reflected in count (+"+countDifference+")");
                } else if (countDifference < 0) {
                    System.out.println("⚠️ WARNING: Count decreased by " + Math.abs(countDifference));
                    TestRunner.getTest().log(Status.WARNING, "Unexpected: Count decreased instead of increased");
                }
            } else {
                System.out.println("❌ VERIFICATION FAILED: Assignment submitted count did NOT change!");
                System.out.println("   Expected: Count should be DIFFERENT from " + initialSubmittedCount);
                System.out.println("   Actual: Count remained at " + updatedSubmittedCount);
                
                TestRunner.getTest().log(Status.FAIL, "Assignment submitted count did not change. Both before and after = " + initialSubmittedCount);
                throw new AssertionError("Assignment submitted count should have changed after submission but remained the same: " + initialSubmittedCount);
            }
            
        } catch (AssertionError ae) {
            throw ae; // Re-throw assertion errors
        } catch (Exception e) {
            System.out.println("❌ Error comparing Assignments Submitted count: " + e.getMessage());
            TestRunner.getTest().log(Status.FAIL, "Error comparing Assignments Submitted count: " + e.getMessage());
        }
    }
    
    /**
     * Finds and retrieves complete details of the submitted assignment
     * Uses the assignment name from CorrectAnswerExecutor_PF.assignmentNameForCorrect
     */
    public void findAndGetAssignmentDetails() {
        try {
            // Get the assignment name from CorrectAnswerExecutor_PF
            String assignmentNameToFind = CorrectAnswerExecutor_PF.assignmentNameForCorrect.get();
            
            System.out.println("\n=== Searching for Submitted Assignment ===");
            System.out.println("Attempting to find assignment: " + assignmentNameToFind);
            TestRunner.getTest().log(Status.INFO, "Looking for assignment: " + assignmentNameToFind);
            
            // First, scroll to load all content
            System.out.println("Scrolling to load all assignments...");
            TestRunner.getTest().log(Status.INFO, "Scrolling page to ensure all assignments are loaded");
            
            // Wait for accordion sections to be present
            wait.until(ExpectedConditions.presenceOfElementLocated(
                By.xpath("//div[contains(@class, 'customAccordian')]")
            ));
            
            // Scroll to the bottom of the page to load all content
            js.executeScript("window.scrollTo(0, document.body.scrollHeight);");
            
            boolean assignmentFound = false;
            
            // Find all accordion sections (categories) - using correct class name
            List<WebElement> accordionSections = driver.findElements(
                By.xpath("//div[contains(@class, 'customAccordian')]")
            );
            
            System.out.println("Searching through " + accordionSections.size() + " categories...");
            
            // Iterate through each category
            for (WebElement accordionSection : accordionSections) {
                try {
                    // Scroll the category into view
                    js.executeScript("arguments[0].scrollIntoView({block: 'center'});", accordionSection);
                    wait.until(ExpectedConditions.visibilityOf(accordionSection));
                    
                    // Get category name from the h3 within this accordion section
                    String categoryName = "";
                    try {
                        WebElement categoryHeader = accordionSection.findElement(
                            By.xpath(".//button[@type='button']//h3")
                        );
                        categoryName = categoryHeader.getText().trim();
                    } catch (Exception e) {
                        try {
                            categoryName = accordionSection.findElement(By.xpath(".//h3")).getText().trim();
                        } catch (Exception ex) {
                            categoryName = "Unknown Category";
                        }
                    }
                    
                    System.out.println("Searching in category: " + categoryName);
                    
                    // Get all rows from the table within this accordion section
                    List<WebElement> rows = accordionSection.findElements(
                        By.xpath(".//table[contains(@class, 'table-auto')]//tbody//tr")
                    );
                    
                    System.out.println("Found " + rows.size() + " assignments in this category");
                    
                    // Search through each assignment row
                    for (WebElement row : rows) {
                        try {
                            List<WebElement> cells = row.findElements(By.xpath(".//td"));
                            
                            if (cells.size() < 5) {
                                continue; // Skip rows without enough columns
                            }
                            
                            // Column 1: NAME (Assignment Name)
                            String assignmentName = "";
                            try {
                                WebElement nameElement = cells.get(0).findElement(
                                    By.xpath(".//p[contains(@class, 'css-zxaigw')]")
                                );
                                assignmentName = nameElement.getText().trim();
                            } catch (Exception e) {
                                assignmentName = cells.get(0).getText().trim();
                            }
                            
                            // Skip if assignment name is empty
                            if (assignmentName.isEmpty()) {
                                continue;
                            }
                            
                            // Check if this is the assignment we're looking for
                            if (assignmentName.contains(assignmentNameToFind) || 
                                assignmentNameToFind.contains(assignmentName)) {
                                
                                assignmentFound = true;
                                
                                // Extract all details from table cells
                                String score = "";
                                String dueDate = "";
                                String status = "";
                                String submittedDate = "";
                                String assignmentComment = "Not Available";
                                String noteFromStudent = "Not Available";
                                
                                // Column 2: SCORE
                                score = cells.get(1).getText().trim().replaceAll("\\s+", " ");
                                
                                // Column 3: DUE DATE
                                dueDate = cells.get(2).getText().trim().replaceAll("\\s+", " ");
                                
                                // Column 4: STATUS
                                try {
                                    WebElement statusChip = cells.get(3).findElement(
                                        By.xpath(".//span[contains(@class, 'MuiChip-label')]")
                                    );
                                    status = statusChip.getText().trim();
                                    
                                    // Get submitted/graded date if available
                                    // Look for any paragraph element in the status cell (excluding the status chip)
                                    List<WebElement> statusDates = cells.get(3).findElements(
                                        By.xpath(".//p[contains(@class, 'MuiTypography-root') and not(ancestor::span[contains(@class, 'MuiChip')])]")
                                    );
                                    if (!statusDates.isEmpty()) {
                                        submittedDate = statusDates.get(0).getText().trim();
                                    } else {
                                        submittedDate = "--";
                                    }
                                } catch (Exception e) {
                                    status = cells.get(3).getText().trim();
                                    submittedDate = "--";
                                }
                                
                                // Column 5: COMMENTS
                                try {
                                    List<WebElement> commentButtons = cells.get(4).findElements(By.xpath(".//button"));
                                    
                                    if (commentButtons.size() >= 1) {
                                        WebElement assignmentCommentBtn = commentButtons.get(0);
                                        assignmentComment = assignmentCommentBtn.isEnabled() ? "Available" : "Not Available";
                                    }
                                    
                                    if (commentButtons.size() >= 2) {
                                        WebElement noteFromStudentBtn = commentButtons.get(1);
                                        noteFromStudent = noteFromStudentBtn.isEnabled() ? "Available" : "Not Available";
                                    }
                                } catch (Exception e) {
                                    // Keep default values
                                }
                                
                                // Print complete details
                                System.out.println("\n✅ ASSIGNMENT FOUND!");
                                System.out.println("╔════════════════════════════════════════════════════════════════╗");
                                System.out.println("║           SUBMITTED ASSIGNMENT COMPLETE DETAILS                ║");
                                System.out.println("╠════════════════════════════════════════════════════════════════╣");
                                System.out.println("║ Category          : " + categoryName);
                                System.out.println("║ Assignment Name   : " + assignmentName);
                                System.out.println("║ Score             : " + score);
                                System.out.println("║ Due Date          : " + dueDate);
                                System.out.println("║ Status            : " + status);
                                System.out.println("║ Submitted Date    : " + submittedDate);
                                System.out.println("║ Assignment Comment: " + assignmentComment);
                                System.out.println("║ Note from Student : " + noteFromStudent);
                                System.out.println("╚════════════════════════════════════════════════════════════════╝\n");
                                
                                // Log to Extent Report
                                TestRunner.getTest().log(Status.PASS, "✅ Assignment Found: " + assignmentName);
                                TestRunner.getTest().log(Status.INFO, "Category: " + categoryName);
                                TestRunner.getTest().log(Status.INFO, "Score: " + score);
                                TestRunner.getTest().log(Status.INFO, "Due Date: " + dueDate);
                                TestRunner.getTest().log(Status.INFO, "Status: " + status);
                                TestRunner.getTest().log(Status.INFO, "Submitted Date: " + submittedDate);
                                TestRunner.getTest().log(Status.INFO, "Assignment Comment: " + assignmentComment);
                                TestRunner.getTest().log(Status.INFO, "Note from Student: " + noteFromStudent);
                                
                                break; // Found the assignment, exit inner loop
                            }
                        } catch (Exception e) {
                            // Skip this row if there's an issue
                            continue;
                        }
                    }
                    
                    if (assignmentFound) {
                        break; // Found the assignment, exit outer loop
                    }
                } catch (Exception e) {
                    // Skip this category if there's an issue
                    continue;
                }
            }
            
            if (!assignmentFound) {
                System.out.println("❌ Assignment NOT found: " + assignmentNameToFind);
                TestRunner.getTest().log(Status.WARNING, "Assignment not found in Student Progress Report: " + assignmentNameToFind);
            }
            
        } catch (Exception e) {
            System.out.println("❌ Error searching for assignment: " + e.getMessage());
            TestRunner.getTest().log(Status.FAIL, "Error searching for assignment: " + e.getMessage());
        }
    }

    /**
     * Clicks on the Standards tab in the Student Progress Report
     */
    public void clickOnStandardsTab() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Clicking on Standards tab");
        
        try {
            // Wait for the Standards tab to be visible and clickable
            WebElement standardsTab = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//button[contains(@role, 'tab') and normalize-space(text())='Standards']")
            ));
            
            // Scroll into view if needed
            js.executeScript("arguments[0].scrollIntoView({block: 'center'});", standardsTab);
            Thread.sleep(500);
            
            // Click the Standards tab
            standardsTab.click();
            Thread.sleep(1000);
            
            System.out.println("✅ Successfully clicked on Standards tab");
            TestRunner.getTest().log(Status.PASS, "Successfully clicked on Standards tab");
            
        } catch (Exception e) {
            System.out.println("❌ Error clicking on Standards tab: " + e.getMessage());
            TestRunner.getTest().log(Status.FAIL, "Error clicking on Standards tab: " + e.getMessage());
            throw e;
        }
    }

    /**
     * Verifies the breadcrumb on the Standards tab
     * Expected breadcrumb: "Home / Gradebook / Student Progress / Standards"
     */
    public void verifyBreadcrumbOnStandardsTab() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Verifying breadcrumb on Standards tab");
        
        try {
            WebElement breadcrumb = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//nav[@aria-label='breadcrumb']")
            ));
            
            String actualBreadcrumb = breadcrumb.getText().trim().replaceAll("\\s+", " ");
            String expectedBreadcrumb = "Home / Gradebook / Student Progress / Standards";
            
            // Also try alternative format (lowercase gradebook)
            String expectedBreadcrumbAlt = "Home / gradebook / Student Progress / Standards";
            
            if (actualBreadcrumb.equalsIgnoreCase(expectedBreadcrumb) || 
                actualBreadcrumb.equalsIgnoreCase(expectedBreadcrumbAlt)) {
                System.out.println("✅ Test Passed: Breadcrumb is correct → " + actualBreadcrumb);
                TestRunner.getTest().log(Status.PASS, "✅ Test Passed: Breadcrumb is correct and Matched → " + actualBreadcrumb);
            } else {
                System.out.println("❌ Test Failed: Expected '" + expectedBreadcrumb + "' but found '" + actualBreadcrumb + "'");
                TestRunner.getTest().log(Status.FAIL, "❌ Test Failed: Expected '" + expectedBreadcrumb + "' but found '" + actualBreadcrumb + "'");
            }
            
        } catch (Exception e) {
            System.out.println("❌ Error verifying breadcrumb: " + e.getMessage());
            TestRunner.getTest().log(Status.FAIL, "Error verifying breadcrumb: " + e.getMessage());
            throw e;
        }
    }

    /**
     * Verifies the text displayed on the right side of the Standards tab
     * Expected text: "Select a standards category to view individual content statements"
     */
    public void verifyTextOnRightSideOfStandardsTab() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Verifying text on right side of Standards tab");
        
        try {
            // Wait for the right panel to be visible (verify it exists)
            wait.until(ExpectedConditions.presenceOfElementLocated(
                By.xpath("//div[contains(@class, 'standards') or contains(@class, 'right')]")
            ));
            
            // Look for the expected text message
            String expectedText = "Select a standards category to view individual content statements";
            
            // Try to find the text in various possible locations
            List<WebElement> textElements = driver.findElements(
                By.xpath("//*[contains(text(), 'Select a standards category') or contains(text(), 'select a standards category')]")
            );
            
            boolean textFound = false;
            String actualText = "";
            
            for (WebElement element : textElements) {
                if (element.isDisplayed()) {
                    actualText = element.getText().trim();
                    if (actualText.contains("Select a standards category") || 
                        actualText.contains("select a standards category")) {
                        textFound = true;
                        break;
                    }
                }
            }
            
            if (textFound) {
                System.out.println("✅ Test Passed: Right side text is correct → " + actualText);
                TestRunner.getTest().log(Status.PASS, "✅ Test Passed: Right side text is correct → " + actualText);
            } else {
                System.out.println("❌ Test Failed: Expected text '" + expectedText + "' not found on right side");
                TestRunner.getTest().log(Status.FAIL, "❌ Test Failed: Expected text '" + expectedText + "' not found on right side");
            }
            
        } catch (Exception e) {
            System.out.println("❌ Error verifying right side text: " + e.getMessage());
            TestRunner.getTest().log(Status.FAIL, "Error verifying right side text: " + e.getMessage());
            throw e;
        }
    }

    /**
     * Validates all Standards headings on the left side, expands each one to get data, then unexpands them
     * Based on actual HTML structure: ul.MuiList-root > div.MuiBox-root > div.MuiListItemButton-root
     */
    public void validateAndExpandAllStandardsHeadings() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Validating and expanding all Standards headings");
        
        try {
            // Wait for the list container to be visible
            wait.until(ExpectedConditions.presenceOfElementLocated(
                By.xpath("//ul[contains(@class, 'MuiList-root')]")
            ));
            
            // Find all Standards heading buttons using the actual structure
            // Structure: ul.MuiList-root > div.MuiBox-root > div.MuiListItemButton-root
            List<WebElement> standardsHeadings = driver.findElements(
                By.xpath("//ul[contains(@class, 'MuiList-root')]//div[contains(@class, 'MuiListItemButton-root') and @role='button']")
            );
            
            System.out.println("\n========================================");
            System.out.println("VALIDATING STANDARDS HEADINGS");
            System.out.println("Total headings found: " + standardsHeadings.size());
            System.out.println("========================================\n");
            TestRunner.getTest().log(Status.INFO, "Total Standards headings found: " + standardsHeadings.size());
            
            if (standardsHeadings.isEmpty()) {
                System.out.println("❌ Could not find Standards headings");
                TestRunner.getTest().log(Status.FAIL, "Could not find Standards headings");
                return;
            }
            
            // Process each heading
            for (int i = 0; i < standardsHeadings.size(); i++) {
                try {
                    // Re-fetch headings to avoid stale element exceptions
                    List<WebElement> currentHeadings = driver.findElements(
                        By.xpath("//ul[contains(@class, 'MuiList-root')]//div[contains(@class, 'MuiListItemButton-root') and @role='button']")
                    );
                    
                    if (i >= currentHeadings.size()) {
                        break;
                    }
                    
                    WebElement headingButton = currentHeadings.get(i);
                    
                    // Scroll into view
                    js.executeScript("arguments[0].scrollIntoView({block: 'center'});", headingButton);
                    Thread.sleep(500);
                    
                    // Extract heading name from p tag with class css-1ditlz5
                    String headingName = "";
                    try {
                        WebElement nameElement = headingButton.findElement(
                            By.xpath(".//p[contains(@class, 'css-1ditlz5')]")
                        );
                        headingName = nameElement.getText().trim();
                    } catch (Exception e) {
                        // Fallback: get all text and extract name
                        String fullText = headingButton.getText().trim();
                        // Name is usually before the percentage
                        if (fullText.contains("%")) {
                            headingName = fullText.substring(0, fullText.indexOf("%")).trim();
                        } else {
                            headingName = fullText;
                        }
                    }
                    
                    // Extract percentage from p tag with class css-hyrp63
                    String percentage = "";
                    try {
                        WebElement percentageElement = headingButton.findElement(
                            By.xpath(".//p[contains(@class, 'css-hyrp63')]")
                        );
                        percentage = percentageElement.getText().trim();
                    } catch (Exception e) {
                        // Fallback: extract from full text
                        String fullText = headingButton.getText().trim();
                        if (fullText.contains("%")) {
                            percentage = fullText.substring(fullText.indexOf("%") - 3, fullText.indexOf("%") + 1).trim();
                        }
                    }
                    
                    String headingDisplayText = headingName + " - " + percentage;
                    System.out.println("\n--- Processing Heading " + (i + 1) + ": " + headingDisplayText + " ---");
                    TestRunner.getTest().log(Status.INFO, "Processing Heading " + (i + 1) + ": " + headingDisplayText);
                    
                    // Check if already expanded by checking the arrow icon direction
                    // When expanded, the arrow should point up (KeyboardArrowUpIcon), when collapsed it points down (KeyboardArrowDownIcon)
                    boolean isExpanded = false;
                    try {
                        // Check if there's an arrow up icon (expanded state)
                        List<WebElement> arrowUpIcons = headingButton.findElements(
                            By.xpath(".//svg[@data-testid='KeyboardArrowUpIcon']")
                        );
                        isExpanded = !arrowUpIcons.isEmpty();
                    } catch (Exception e) {
                        // If we can't determine, assume it's collapsed
                        isExpanded = false;
                    }
                    
                    // Expand if not already expanded
                    if (!isExpanded) {
                        System.out.println("  Expanding heading...");
                        // Use JavaScript click for reliability
                        try {
                            js.executeScript("arguments[0].scrollIntoView({block: 'center'});", headingButton);
                            Thread.sleep(200);
                            js.executeScript("arguments[0].click();", headingButton);
                        } catch (Exception e) {
                            headingButton.click();
                        }
                        
                        // Wait for collapse container to appear
                        WebDriverWait shortWait = new WebDriverWait(driver, Duration.ofSeconds(3));
                        try {
                            // Find parent box first
                            WebElement parentBox = headingButton.findElement(By.xpath("./ancestor::div[contains(@class, 'MuiBox-root') and contains(@class, 'css-0')][1]"));
                            // Wait for MuiCollapse to appear
                            shortWait.until(ExpectedConditions.presenceOfNestedElementLocatedBy(
                                parentBox, 
                                By.xpath(".//div[contains(@class, 'MuiCollapse-root')]")
                            ));
                            System.out.println("  ✓ Expansion confirmed");
                        } catch (TimeoutException e) {
                            System.out.println("  ⚠️ Expansion may not be complete, but continuing...");
                        }
                        
                        Thread.sleep(500); // Small wait for content to render
                    } else {
                        System.out.println("  Heading is already expanded");
                    }
                    
                    // Re-fetch heading button to avoid stale element (for use in extraction and unexpand)
                    List<WebElement> refreshedHeadings = driver.findElements(
                        By.xpath("//ul[contains(@class, 'MuiList-root')]//div[contains(@class, 'MuiListItemButton-root') and @role='button']")
                    );
                    WebElement currentHeadingButton = (i < refreshedHeadings.size()) ? refreshedHeadings.get(i) : headingButton;
                    
                    // Get all data under this heading
                    try {
                        
                        // Based on HTML structure: 
                        // div.MuiBox-root.css-0 contains:
                        //   - div.MuiListItemButton-root (the heading button)
                        //   - div.MuiCollapse-root (the expanded content, sibling of button)
                        //     - div.MuiCollapse-wrapperInner
                        //       - div.MuiListItemButton-root (sub-items)
                        
                        // Find the parent MuiBox-root that contains both the button and the collapse
                        WebElement parentBox = currentHeadingButton.findElement(By.xpath("./ancestor::div[contains(@class, 'MuiBox-root') and contains(@class, 'css-0')][1]"));
                        
                        // Look for MuiCollapse container that is a child of the same parentBox (sibling of button)
                        WebElement collapseContainer = null;
                        try {
                            collapseContainer = parentBox.findElement(By.xpath(".//div[contains(@class, 'MuiCollapse-root') and contains(@class, 'MuiCollapse-entered')]"));
                        } catch (Exception e1) {
                            // Try without the 'entered' class - might be transitioning
                            try {
                                collapseContainer = parentBox.findElement(By.xpath(".//div[contains(@class, 'MuiCollapse-root')]"));
                            } catch (Exception e2) {
                                // Try finding by following sibling
                                try {
                                    collapseContainer = headingButton.findElement(By.xpath("./following-sibling::div[contains(@class, 'MuiCollapse-root')]"));
                                } catch (Exception e3) {
                                    // Last resort: find any collapse near this heading
                                    List<WebElement> allCollapses = driver.findElements(By.xpath("//div[contains(@class, 'MuiCollapse-root')]"));
                                    for (WebElement collapse : allCollapses) {
                                        try {
                                            if (collapse.isDisplayed()) {
                                                // Check if this collapse is within the same parentBox
                                                WebElement collapseParent = collapse.findElement(By.xpath("./ancestor::div[contains(@class, 'MuiBox-root') and contains(@class, 'css-0')][1]"));
                                                if (collapseParent.equals(parentBox)) {
                                                    collapseContainer = collapse;
                                                    break;
                                                }
                                            }
                                        } catch (Exception e4) {
                                            continue;
                                        }
                                    }
                                }
                            }
                        }
                        
                        if (collapseContainer != null && collapseContainer.isDisplayed()) {
                            // Get all sub-items from the collapse container
                            // Sub-items are div.MuiListItemButton-root inside MuiCollapse-wrapperInner
                            List<WebElement> subItems = collapseContainer.findElements(
                                By.xpath(".//div[contains(@class, 'MuiListItemButton-root') and contains(@class, 'css-kqqq8k')]")
                            );
                            
                            // If not found with specific class, try more generic
                            if (subItems.isEmpty()) {
                                subItems = collapseContainer.findElements(
                                    By.xpath(".//div[contains(@class, 'MuiListItemButton-root')]")
                                );
                            }
                            
                            System.out.println("  Found " + subItems.size() + " sub-items");
                            TestRunner.getTest().log(Status.INFO, "Found " + subItems.size() + " sub-items under " + headingName);
                            
                            // Extract and display data from each sub-item
                            for (int j = 0; j < subItems.size(); j++) {
                                try {
                                    WebElement subItem = subItems.get(j);
                                    
                                    // Extract text from the sub-item
                                    // Structure: div.MuiBox-root.css-1w7q1gb contains:
                                    //   - p.css-lv9d4h (name)
                                    //   - p.css-lv9d4h (percentage)
                                    String subItemText = "";
                                    try {
                                        // Get all p elements with css-lv9d4h class
                                        List<WebElement> textElements = subItem.findElements(By.xpath(".//p[contains(@class, 'css-lv9d4h')]"));
                                        if (textElements.size() >= 2) {
                                            String name = textElements.get(0).getText().trim();
                                            String percent = textElements.get(1).getText().trim();
                                            subItemText = name + " - " + percent;
                                        } else if (textElements.size() == 1) {
                                            subItemText = textElements.get(0).getText().trim();
                                        } else {
                                            // Fallback to full text
                                            subItemText = subItem.getText().trim();
                                        }
                                    } catch (Exception e) {
                                        // Fallback to full text
                                        subItemText = subItem.getText().trim();
                                    }
                                    
                                    if (!subItemText.isEmpty() && 
                                        !subItemText.equals(headingName) && 
                                        !subItemText.equals(percentage) &&
                                        !subItemText.matches("^\\d+%$")) {
                                        System.out.println("    Sub-item " + (j + 1) + ": " + subItemText);
                                        TestRunner.getTest().log(Status.INFO, "Sub-item " + (j + 1) + ": " + subItemText);
                                    }
                                } catch (Exception e) {
                                    continue;
                                }
                            }
                        } else {
                            System.out.println("  No expanded content found or content not visible");
                            TestRunner.getTest().log(Status.WARNING, "No expanded content found for " + headingName);
                        }
                    } catch (Exception e) {
                        System.out.println("  Could not extract sub-items: " + e.getMessage());
                        TestRunner.getTest().log(Status.WARNING, "Could not extract sub-items for " + headingName + ": " + e.getMessage());
                        e.printStackTrace();
                    }
                    
                    // Unexpand the heading (click again to collapse)
                    System.out.println("  Unexpanding heading...");
                    try {
                        // Re-fetch button one more time before collapsing
                        refreshedHeadings = driver.findElements(
                            By.xpath("//ul[contains(@class, 'MuiList-root')]//div[contains(@class, 'MuiListItemButton-root') and @role='button']")
                        );
                        WebElement collapseButton = (i < refreshedHeadings.size()) ? refreshedHeadings.get(i) : currentHeadingButton;
                        js.executeScript("arguments[0].click();", collapseButton);
                    } catch (Exception e) {
                        currentHeadingButton.click();
                    }
                    Thread.sleep(500);
                    
                    System.out.println("  ✅ Completed processing heading: " + headingDisplayText);
                    TestRunner.getTest().log(Status.PASS, "Completed processing heading: " + headingDisplayText);
                    
                } catch (StaleElementReferenceException e) {
                    System.out.println("  Stale element encountered, continuing to next heading...");
                    continue;
                } catch (Exception e) {
                    System.out.println("  Error processing heading " + (i + 1) + ": " + e.getMessage());
                    TestRunner.getTest().log(Status.WARNING, "Error processing heading " + (i + 1) + ": " + e.getMessage());
                    e.printStackTrace();
                    continue;
                }
            }
            
            System.out.println("\n========================================");
            System.out.println("VALIDATION COMPLETE");
            System.out.println("Processed " + standardsHeadings.size() + " headings");
            System.out.println("========================================\n");
            TestRunner.getTest().log(Status.PASS, "Successfully validated and processed " + standardsHeadings.size() + " Standards headings");
            
        } catch (Exception e) {
            System.out.println("❌ Error validating Standards headings: " + e.getMessage());
            TestRunner.getTest().log(Status.FAIL, "Error validating Standards headings: " + e.getMessage());
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * Clicks on all sub-headings, opens "Assessed X Times" dialog, extracts assignment names,
     * and compares with the stored assignment name. Continues through all headings and sub-headings.
     * @param expectedAssignmentName The assignment name to compare against (from CorrectAnswerExecutor_PF)
     */
    public void clickSubHeadingsAndCompareAssignmentNames(String expectedAssignmentName) throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Clicking sub-headings and comparing assignment names");
        
        try {
            // Get the assignment name to find
            String assignmentNameToFind = expectedAssignmentName;
            if (assignmentNameToFind == null || assignmentNameToFind.isEmpty()) {
                try {
                    assignmentNameToFind = CorrectAnswerExecutor_PF.assignmentNameForCorrect.get();
                } catch (Exception e) {
                    System.out.println("⚠️ Could not get assignment name from CorrectAnswerExecutor_PF");
                    TestRunner.getTest().log(Status.WARNING, "Could not get assignment name from CorrectAnswerExecutor_PF");
                    return;
                }
            }
            
            System.out.println("\n========================================");
            System.out.println("SEARCHING FOR ASSIGNMENT: " + assignmentNameToFind);
            System.out.println("========================================\n");
            TestRunner.getTest().log(Status.INFO, "Searching for assignment: " + assignmentNameToFind);
            
            // Wait for the list container to be visible
            wait.until(ExpectedConditions.presenceOfElementLocated(
                By.xpath("//ul[contains(@class, 'MuiList-root')]")
            ));
            
            // Find all Standards heading buttons
            List<WebElement> standardsHeadings = driver.findElements(
                By.xpath("//ul[contains(@class, 'MuiList-root')]//div[contains(@class, 'MuiListItemButton-root') and @role='button']")
            );
            
            System.out.println("Total headings found: " + standardsHeadings.size());
            TestRunner.getTest().log(Status.INFO, "Total headings found: " + standardsHeadings.size());
            
            boolean assignmentFound = false;
            
            // Process each heading
            for (int i = 0; i < standardsHeadings.size(); i++) {
                try {
                    // Re-fetch headings to avoid stale elements
                    List<WebElement> currentHeadings = driver.findElements(
                        By.xpath("//ul[contains(@class, 'MuiList-root')]//div[contains(@class, 'MuiListItemButton-root') and @role='button']")
                    );
                    
                    if (i >= currentHeadings.size()) {
                        break;
                    }
                    
                    WebElement headingButton = currentHeadings.get(i);
                    
                    // Scroll into view
                    js.executeScript("arguments[0].scrollIntoView({block: 'center'});", headingButton);
                    Thread.sleep(300);
                    
                    // Extract heading name
                    String headingName = "";
                    try {
                        WebElement nameElement = headingButton.findElement(
                            By.xpath(".//p[contains(@class, 'css-1ditlz5')]")
                        );
                        headingName = nameElement.getText().trim();
                    } catch (Exception e) {
                        String fullText = headingButton.getText().trim();
                        if (fullText.contains("%")) {
                            headingName = fullText.substring(0, fullText.indexOf("%")).trim();
                        } else {
                            headingName = fullText;
                        }
                    }
                    
                    System.out.println("\n--- Processing Heading " + (i + 1) + ": " + headingName + " ---");
                    TestRunner.getTest().log(Status.INFO, "Processing Heading " + (i + 1) + ": " + headingName);
                    
                    // Check if already expanded
                    boolean isExpanded = false;
                    try {
                        List<WebElement> arrowUpIcons = headingButton.findElements(
                            By.xpath(".//svg[@data-testid='KeyboardArrowUpIcon']")
                        );
                        isExpanded = !arrowUpIcons.isEmpty();
                    } catch (Exception e) {
                        isExpanded = false;
                    }
                    
                    // Expand if not already expanded
                    if (!isExpanded) {
                        try {
                            js.executeScript("arguments[0].click();", headingButton);
                            Thread.sleep(800);
                        } catch (Exception e) {
                            headingButton.click();
                            Thread.sleep(800);
                        }
                    }
                    
                    // Find parent box and collapse container
                    WebElement parentBox = headingButton.findElement(By.xpath("./ancestor::div[contains(@class, 'MuiBox-root') and contains(@class, 'css-0')][1]"));
                    WebElement collapseContainer = null;
                    
                    try {
                        collapseContainer = parentBox.findElement(By.xpath(".//div[contains(@class, 'MuiCollapse-root') and contains(@class, 'MuiCollapse-entered')]"));
                    } catch (Exception e) {
                        try {
                            collapseContainer = parentBox.findElement(By.xpath(".//div[contains(@class, 'MuiCollapse-root')]"));
                        } catch (Exception ex) {
                            System.out.println("  ⚠️ Could not find collapse container for " + headingName);
                            continue;
                        }
                    }
                    
                    if (collapseContainer == null || !collapseContainer.isDisplayed()) {
                        System.out.println("  ⚠️ No expanded content found for " + headingName);
                        continue;
                    }
                    
                    // Get all sub-items
                    List<WebElement> subItems = collapseContainer.findElements(
                        By.xpath(".//div[contains(@class, 'MuiListItemButton-root')]")
                    );
                    
                    System.out.println("  Found " + subItems.size() + " sub-items");
                    
                    // Process each sub-item
                    for (int j = 0; j < subItems.size(); j++) {
                        try {
                            // Re-fetch sub-items to avoid stale elements
                            List<WebElement> refreshedSubItems = collapseContainer.findElements(
                                By.xpath(".//div[contains(@class, 'MuiListItemButton-root')]")
                            );
                            
                            if (j >= refreshedSubItems.size()) {
                                break;
                            }
                            
                            WebElement subItem = refreshedSubItems.get(j);
                            
                            // Extract sub-item name
                            String subItemName = "";
                            try {
                                List<WebElement> textElements = subItem.findElements(By.xpath(".//p[contains(@class, 'css-lv9d4h')]"));
                                if (textElements.size() > 0) {
                                    subItemName = textElements.get(0).getText().trim();
                                } else {
                                    subItemName = subItem.getText().trim();
                                }
                            } catch (Exception e) {
                                subItemName = subItem.getText().trim();
                            }
                            
                            System.out.println("    Clicking sub-item " + (j + 1) + ": " + subItemName);
                            TestRunner.getTest().log(Status.INFO, "Clicking sub-item " + (j + 1) + ": " + subItemName);
                            
                            // Click on sub-item
                            js.executeScript("arguments[0].scrollIntoView({block: 'center'});", subItem);
                            Thread.sleep(300);
                            js.executeScript("arguments[0].click();", subItem);
                            Thread.sleep(1500); // Wait for right panel to load
                            
                            // Wait for right panel to appear and extract information
                            String rightPanelHeading = "";
                            String standardNumber = "";
                            String contentStatement = "";
                            
                            try {
                                // Wait for the right panel breadcrumb to appear
                                WebElement breadcrumbContainer = wait.until(ExpectedConditions.visibilityOfElementLocated(
                                    By.xpath("//div[contains(@class, 'MuiGrid-grid-md-8')]//div[contains(@class, 'css-1r26z90')]")
                                ));
                                
                                // Extract the last breadcrumb item (the current sub-item name)
                                List<WebElement> breadcrumbItems = breadcrumbContainer.findElements(
                                    By.xpath(".//p[contains(@class, 'css-651036')]")
                                );
                                if (!breadcrumbItems.isEmpty()) {
                                    rightPanelHeading = breadcrumbItems.get(breadcrumbItems.size() - 1).getText().trim();
                                    System.out.println("      Right panel heading: " + rightPanelHeading);
                                    TestRunner.getTest().log(Status.INFO, "Right panel heading: " + rightPanelHeading);
                                }
                                
                                // Extract Standard Number and Content Statement
                                WebElement cardContent = wait.until(ExpectedConditions.visibilityOfElementLocated(
                                    By.xpath("//div[contains(@class, 'MuiGrid-grid-md-8')]//div[contains(@class, 'MuiCardContent-root')]")
                                ));
                                
                                // Get Standard Number
                                try {
                                    WebElement numberElement = cardContent.findElement(
                                        By.xpath(".//h6[contains(@class, 'css-j79jth')]//span")
                                    );
                                    standardNumber = numberElement.getText().trim();
                                    System.out.println("      Standard Number: " + standardNumber);
                                    TestRunner.getTest().log(Status.INFO, "Standard Number: " + standardNumber);
                                } catch (Exception e) {
                                    System.out.println("      ⚠️ Could not extract standard number");
                                }
                                
                                // Get Content Statement
                                try {
                                    WebElement contentElement = cardContent.findElement(
                                        By.xpath(".//p[contains(@class, 'css-16jm7t3')]//span")
                                    );
                                    contentStatement = contentElement.getText().trim();
                                    System.out.println("      Content Statement: " + contentStatement);
                                    TestRunner.getTest().log(Status.INFO, "Content Statement: " + contentStatement);
                                } catch (Exception e) {
                                    System.out.println("      ⚠️ Could not extract content statement");
                                }
                                
                            } catch (Exception e) {
                                System.out.println("      ⚠️ Could not extract right panel information: " + e.getMessage());
                            }
                            
                            // Find all cards in the right panel - there can be multiple cards
                            List<WebElement> rightPanelCards = new java.util.ArrayList<>();
                            try {
                                // Wait for right panel to load
                                wait.until(ExpectedConditions.presenceOfElementLocated(
                                    By.xpath("//div[contains(@class, 'MuiGrid-grid-md-8')]")
                                ));
                                
                                // Find all cards in the right panel
                                rightPanelCards = driver.findElements(
                                    By.xpath("//div[contains(@class, 'MuiGrid-grid-md-8')]//div[contains(@class, 'MuiCard-root')]")
                                );
                                
                                System.out.println("      Found " + rightPanelCards.size() + " card(s) in right panel");
                                TestRunner.getTest().log(Status.INFO, "Found " + rightPanelCards.size() + " card(s) in right panel");
                                
                            } catch (Exception e) {
                                System.out.println("      ⚠️ Could not find cards in right panel: " + e.getMessage());
                                continue;
                            }
                            
                            if (rightPanelCards.isEmpty()) {
                                System.out.println("      ⚠️ No cards found in right panel for " + subItemName);
                                continue;
                            }
                            
                            // Process each card
                            for (int cardIndex = 0; cardIndex < rightPanelCards.size(); cardIndex++) {
                                try {
                                    // Re-fetch cards to avoid stale elements
                                    List<WebElement> refreshedCards = driver.findElements(
                                        By.xpath("//div[contains(@class, 'MuiGrid-grid-md-8')]//div[contains(@class, 'MuiCard-root')]")
                                    );
                                    
                                    if (cardIndex >= refreshedCards.size()) {
                                        break;
                                    }
                                    
                                    WebElement card = refreshedCards.get(cardIndex);
                                    
                                    // Extract card information
                                    String cardNumber = "";
                                    String cardContentStatement = "";
                                    try {
                                        // Get Standard Number
                                        try {
                                            WebElement numberElement = card.findElement(
                                                By.xpath(".//h6[contains(@class, 'css-j79jth')]//span")
                                            );
                                            cardNumber = numberElement.getText().trim();
                                        } catch (Exception e) {
                                            // Ignore
                                        }
                                        
                                        // Get Content Statement
                                        try {
                                            WebElement contentElement = card.findElement(
                                                By.xpath(".//p[contains(@class, 'css-16jm7t3')]//span")
                                            );
                                            cardContentStatement = contentElement.getText().trim();
                                        } catch (Exception e) {
                                            // Ignore
                                        }
                                        
                                        System.out.println("        Card " + (cardIndex + 1) + ": " + cardNumber);
                                        if (!cardContentStatement.isEmpty()) {
                                            System.out.println("          Content: " + (cardContentStatement.length() > 80 ? cardContentStatement.substring(0, 80) + "..." : cardContentStatement));
                                        }
                                        
                                    } catch (Exception e) {
                                        System.out.println("        Card " + (cardIndex + 1) + ": Could not extract card info");
                                    }
                                    
                                    // Find "Assessed X Times" button in this card
                                    WebElement assessedButton = null;
                                    try {
                                        // Wait a bit for button to be rendered
                                        Thread.sleep(300);
                                        
                                        // Scroll card into view to ensure it's fully loaded
                                        js.executeScript("arguments[0].scrollIntoView({block: 'center'});", card);
                                        Thread.sleep(200);
                                        
                                        // Strategy 1: Look for button with text containing "Assessed" and "Times" (case-insensitive)
                                        List<WebElement> buttons = card.findElements(
                                            By.xpath(".//button[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), 'assessed') and contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), 'times')]")
                                        );
                                        
                                        // Strategy 2: If not found, try case-sensitive
                                        if (buttons.isEmpty()) {
                                            buttons = card.findElements(
                                                By.xpath(".//button[contains(text(), 'Assessed') and contains(text(), 'Times')]")
                                            );
                                        }
                                        
                                        // Strategy 3: Try finding button by class structure (css-2p3asc or MuiButton-textPrimary)
                                        if (buttons.isEmpty()) {
                                            buttons = card.findElements(
                                                By.xpath(".//button[contains(@class, 'MuiButton-textPrimary')] | .//button[contains(@class, 'css-2p3asc')]")
                                            );
                                            // Filter by text
                                            List<WebElement> filteredButtons = new java.util.ArrayList<>();
                                            for (WebElement btn : buttons) {
                                                try {
                                                    String btnText = btn.getText().trim().toLowerCase();
                                                    if (btnText.contains("assessed") && btnText.contains("times")) {
                                                        filteredButtons.add(btn);
                                                    }
                                                } catch (Exception e) {
                                                    continue;
                                                }
                                            }
                                            buttons = filteredButtons;
                                        }
                                        
                                        // Strategy 4: Try searching within MuiCardContent-root specifically
                                        if (buttons.isEmpty()) {
                                            try {
                                                WebElement cardContent = card.findElement(By.xpath(".//div[contains(@class, 'MuiCardContent-root')]"));
                                                buttons = cardContent.findElements(
                                                    By.xpath(".//button[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), 'assessed')]")
                                                );
                                            } catch (Exception e) {
                                                // Ignore
                                            }
                                        }
                                        
                                        // Strategy 5: Try finding any button in the card and check its text
                                        if (buttons.isEmpty()) {
                                            List<WebElement> allButtons = card.findElements(By.xpath(".//button"));
                                            for (WebElement btn : allButtons) {
                                                try {
                                                    String btnText = btn.getText().trim().toLowerCase();
                                                    if (btnText.contains("assessed") && btnText.contains("times")) {
                                                        buttons.add(btn);
                                                        break;
                                                    }
                                                } catch (Exception e) {
                                                    continue;
                                                }
                                            }
                                        }
                                        
                                        // Strategy 6: Try finding button in MuiBox-root css-1ytvbby (the container div)
                                        if (buttons.isEmpty()) {
                                            try {
                                                WebElement buttonContainer = card.findElement(By.xpath(".//div[contains(@class, 'css-1ytvbby')]"));
                                                buttons = buttonContainer.findElements(By.xpath(".//button"));
                                            } catch (Exception e) {
                                                // Ignore
                                            }
                                        }
                                        
                                        // Debug: Print all buttons found
                                        if (buttons.isEmpty()) {
                                            List<WebElement> allButtons = card.findElements(By.xpath(".//button"));
                                            System.out.println("        Debug: Found " + allButtons.size() + " button(s) in card");
                                            for (int btnIdx = 0; btnIdx < allButtons.size(); btnIdx++) {
                                                try {
                                                    String btnText = allButtons.get(btnIdx).getText().trim();
                                                    System.out.println("          Button " + (btnIdx + 1) + " text: '" + btnText + "'");
                                                } catch (Exception e) {
                                                    System.out.println("          Button " + (btnIdx + 1) + ": Could not get text");
                                                }
                                            }
                                        }
                                        
                                        if (!buttons.isEmpty()) {
                                            assessedButton = buttons.get(0);
                                            // Check if button is displayed and enabled
                                            if (!assessedButton.isDisplayed() || !assessedButton.isEnabled()) {
                                                System.out.println("        ⚠️ Button found but not visible/enabled");
                                                assessedButton = null;
                                            }
                                        }
                                    } catch (Exception e) {
                                        System.out.println("        ⚠️ Could not find button in card " + (cardIndex + 1) + ": " + e.getMessage());
                                        e.printStackTrace();
                                    }
                                    
                                    if (assessedButton == null) {
                                        System.out.println("        ⚠️ No 'Assessed X Times' button found in card " + (cardIndex + 1));
                                        // Try to find button in the entire right panel as fallback
                                        try {
                                            List<WebElement> fallbackButtons = driver.findElements(
                                                By.xpath("//div[contains(@class, 'MuiGrid-grid-md-8')]//button[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), 'assessed')]")
                                            );
                                            if (!fallbackButtons.isEmpty()) {
                                                System.out.println("        Found " + fallbackButtons.size() + " button(s) in right panel (fallback)");
                                                for (WebElement btn : fallbackButtons) {
                                                    String btnText = btn.getText().trim();
                                                    System.out.println("          Fallback button text: '" + btnText + "'");
                                                }
                                            }
                                        } catch (Exception e) {
                                            // Ignore fallback errors
                                        }
                                        continue;
                                    }
                                    
                                    String buttonText = assessedButton.getText().trim();
                                    System.out.println("        Clicking button: " + buttonText);
                                    TestRunner.getTest().log(Status.INFO, "Clicking 'Assessed X Times' button in card " + (cardIndex + 1) + ": " + buttonText);
                                    
                                    // Scroll button into view and click
                                    js.executeScript("arguments[0].scrollIntoView({block: 'center'});", assessedButton);
                                    Thread.sleep(300);
                                    js.executeScript("arguments[0].click();", assessedButton);
                                    Thread.sleep(1000); // Wait for dialog to appear
                                    
                                    // Wait for dialog to appear - custom dialog structure
                                    WebElement dialog = null;
                                    try {
                                        // Wait for dialog with role="dialog" and aria-modal="true"
                                        dialog = wait.until(ExpectedConditions.visibilityOfElementLocated(
                                            By.xpath("//div[@role='dialog' and @aria-modal='true']")
                                        ));
                                        
                                        // Verify dialog title is present
                                        WebElement dialogTitle = dialog.findElement(By.xpath(".//h2[@id='dialog-title'] | .//h2[contains(text(), 'Times Assessed')]"));
                                        String titleText = dialogTitle.getText().trim();
                                        System.out.println("        Dialog opened: " + titleText);
                                        TestRunner.getTest().log(Status.INFO, "Dialog opened: " + titleText);
                                        
                                    } catch (Exception e) {
                                        System.out.println("        ⚠️ Dialog did not appear for card " + (cardIndex + 1) + ": " + e.getMessage());
                                        continue;
                                    }
                                    
                                    // Extract ALL assignment names from dialog and compare each one
                                    // The dialog contains multiple accordions, each with an assignment name in h3
                                    try {
                                        // Find all accordion containers (div.customAccordian)
                                        List<WebElement> accordions = dialog.findElements(
                                            By.xpath(".//div[contains(@class, 'customAccordian')]")
                                        );
                                        
                                        System.out.println("        Found " + accordions.size() + " assignment(s) in dialog");
                                        TestRunner.getTest().log(Status.INFO, "Found " + accordions.size() + " assignment(s) in dialog");
                                        
                                        if (accordions.isEmpty()) {
                                            System.out.println("        ⚠️ No assignments found in dialog");
                                        } else {
                                            // Loop through each accordion and extract assignment name
                                            for (int accordionIndex = 0; accordionIndex < accordions.size(); accordionIndex++) {
                                                try {
                                                    WebElement accordion = accordions.get(accordionIndex);
                                                    
                                                    // Find the h3 element containing the assignment name
                                                    String assignmentNameFromDialog = "";
                                                    try {
                                                        WebElement h3Element = accordion.findElement(By.xpath(".//h3[contains(@class, 'text-[#1F44FF]')] | .//h3"));
                                                        assignmentNameFromDialog = h3Element.getText().trim();
                                                        
                                                        // Clean up assignment name - remove date patterns if any
                                                        // The assignment name is already clean in h3, but remove any trailing dates
                                                        assignmentNameFromDialog = assignmentNameFromDialog.replaceAll("\\s+\\d{1,2}[/-]\\d{1,2}([/-]\\d{2,4})?\\s*$", "").trim();
                                                        assignmentNameFromDialog = assignmentNameFromDialog.replaceAll("\\s+\\d{1,2}-\\d{1,2}-\\d{4}\\s*$", "").trim();
                                                        
                                                    } catch (Exception e) {
                                                        System.out.println("          ⚠️ Could not extract assignment name from accordion " + (accordionIndex + 1));
                                                        continue;
                                                    }
                                                    
                                                    if (!assignmentNameFromDialog.isEmpty()) {
                                                        System.out.println("          Assignment " + (accordionIndex + 1) + ": " + assignmentNameFromDialog);
                                                        TestRunner.getTest().log(Status.INFO, "Assignment " + (accordionIndex + 1) + ": " + assignmentNameFromDialog);
                                                        
                                                        // Compare assignment names
                                                        if (assignmentNameFromDialog.contains(assignmentNameToFind) || 
                                                            assignmentNameToFind.contains(assignmentNameFromDialog)) {
                                                            System.out.println("          ✅✅✅ MATCH FOUND! Assignment matches: " + assignmentNameFromDialog);
                                                            TestRunner.getTest().log(Status.PASS, "✅ Assignment match found: " + assignmentNameFromDialog);
                                                            assignmentFound = true;
                                                            break; // Break out of accordion loop since we found a match
                                                        } else {
                                                            System.out.println("          ⚠️ Assignment " + (accordionIndex + 1) + " does not match. Expected: " + assignmentNameToFind + ", Found: " + assignmentNameFromDialog);
                                                            TestRunner.getTest().log(Status.INFO, "Assignment " + (accordionIndex + 1) + " does not match. Expected: " + assignmentNameToFind + ", Found: " + assignmentNameFromDialog);
                                                        }
                                                    }
                                                    
                                                } catch (Exception e) {
                                                    System.out.println("          ⚠️ Error processing accordion " + (accordionIndex + 1) + ": " + e.getMessage());
                                                    continue;
                                                }
                                            }
                                            
                                            // If no match found after checking all assignments
                                            if (!assignmentFound) {
                                                System.out.println("        ⚠️ No matching assignment found in dialog after checking all " + accordions.size() + " assignment(s)");
                                            }
                                        }
                                        
                                    } catch (Exception e) {
                                        System.out.println("        ⚠️ Could not extract assignments from dialog: " + e.getMessage());
                                        e.printStackTrace();
                                        
                                        // Fallback: Try to get dialog text for debugging
                                        try {
                                            String dialogText = dialog.getText();
                                            System.out.println("        Dialog text preview: " + (dialogText.length() > 300 ? dialogText.substring(0, 300) + "..." : dialogText));
                                        } catch (Exception e2) {
                                            // Ignore
                                        }
                                    }
                                    
                                    // Close dialog after comparison - custom dialog structure
                                    // Close button has SVG with specific path: M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12 19 6.41z
                                    try {
                                        // The close button is in the header div with id="dialog-title"
                                        // Find button containing SVG with the specific close icon path
                                        WebElement closeButton = null;
                                        
                                        // Strategy 1: Find button in dialog-title div with SVG containing the close icon path
                                        // SVG path: M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12 19 6.41z
                                        try {
                                            WebElement dialogTitleDiv = dialog.findElement(By.xpath(".//div[@id='dialog-title']"));
                                            // Find button containing SVG with the close icon path
                                            List<WebElement> buttons = dialogTitleDiv.findElements(By.xpath(".//button"));
                                            for (WebElement btn : buttons) {
                                                try {
                                                    List<WebElement> svgPaths = btn.findElements(By.xpath(".//svg//path[@d]"));
                                                    for (WebElement path : svgPaths) {
                                                        String pathData = path.getAttribute("d");
                                                        // Check if path contains the close icon pattern
                                                        if (pathData != null && (pathData.contains("M19 6.41") || pathData.contains("19 6.41"))) {
                                                            closeButton = btn;
                                                            break;
                                                        }
                                                    }
                                                    if (closeButton != null) break;
                                                } catch (Exception e) {
                                                    continue;
                                                }
                                            }
                                        } catch (Exception e) {
                                            // Strategy 2: Find button with SVG in dialog header (any SVG)
                                            try {
                                                closeButton = dialog.findElement(
                                                    By.xpath(".//div[@id='dialog-title']//button[.//svg] | .//div[contains(@class, 'px-5')]//button[.//svg]")
                                                );
                                            } catch (Exception e2) {
                                                // Strategy 3: Generic button with SVG
                                                closeButton = dialog.findElement(By.xpath(".//button[.//svg]"));
                                            }
                                        }
                                        
                                        if (closeButton != null) {
                                            js.executeScript("arguments[0].click();", closeButton);
                                            Thread.sleep(300);
                                            
                                            // Wait for dialog to disappear
                                            try {
                                                WebDriverWait shortWait = new WebDriverWait(driver, Duration.ofSeconds(3));
                                                shortWait.until(ExpectedConditions.invisibilityOf(dialog));
                                                System.out.println("        ✅ Dialog closed successfully");
                                            } catch (TimeoutException e) {
                                                System.out.println("        ⚠️ Dialog may still be visible, but continuing...");
                                            }
                                        } else {
                                            throw new Exception("Close button not found");
                                        }
                                        
                                    } catch (Exception e) {
                                        // Try pressing ESC key as fallback
                                        try {
                                            actions.sendKeys(Keys.ESCAPE).perform();
                                            Thread.sleep(300);
                                            
                                            // Wait for dialog to disappear
                                            try {
                                                WebDriverWait shortWait = new WebDriverWait(driver, Duration.ofSeconds(3));
                                                shortWait.until(ExpectedConditions.invisibilityOfElementLocated(
                                                    By.xpath("//div[@role='dialog' and @aria-modal='true']")
                                                ));
                                                System.out.println("        ✅ Dialog closed using ESC key");
                                            } catch (TimeoutException e2) {
                                                System.out.println("        ⚠️ Dialog may still be visible after ESC, but continuing...");
                                            }
                                        } catch (Exception e2) {
                                            System.out.println("        ⚠️ Could not close dialog: " + e2.getMessage());
                                            // Force continue even if dialog couldn't be closed
                                        }
                                    }
                                    
                                    // Small wait before processing next card
                                    Thread.sleep(300);
                                    
                                    // If assignment found, STOP THE WHOLE PROCESS
                                    if (assignmentFound) {
                                        System.out.println("        ✅✅✅ ASSIGNMENT MATCH FOUND - STOPPING PROCESS ✅✅✅");
                                        TestRunner.getTest().log(Status.PASS, "✅ Assignment match found - Stopping search");
                                        // Break out of card loop
                                        break;
                                    }
                                    
                                } catch (StaleElementReferenceException e) {
                                    System.out.println("        Stale element encountered for card " + (cardIndex + 1));
                                    continue;
                                } catch (Exception e) {
                                    System.out.println("        Error processing card " + (cardIndex + 1) + ": " + e.getMessage());
                                    continue;
                                }
                            }
                            
                            // If assignment found, break out of card loop and sub-item loop
                            if (assignmentFound) {
                                System.out.println("      ✅✅✅ BREAKING OUT OF CARD LOOP - Assignment match found ✅✅✅");
                                break;
                            }
                            
                        } catch (StaleElementReferenceException e) {
                            System.out.println("      Stale element encountered for sub-item " + (j + 1));
                            continue;
                        } catch (Exception e) {
                            System.out.println("      Error processing sub-item " + (j + 1) + ": " + e.getMessage());
                            continue;
                        }
                    }
                    
                    // If assignment found, break out of sub-item loop and heading loop
                    if (assignmentFound) {
                        System.out.println("  ✅✅✅ BREAKING OUT OF SUB-ITEM LOOP - Assignment match found ✅✅✅");
                        break;
                    }
                    
                    // Collapse heading after processing all sub-items (only if assignment not found)
                    if (!assignmentFound) {
                        try {
                            List<WebElement> refreshedHeadings2 = driver.findElements(
                                By.xpath("//ul[contains(@class, 'MuiList-root')]//div[contains(@class, 'MuiListItemButton-root') and @role='button']")
                            );
                            if (i < refreshedHeadings2.size()) {
                                WebElement collapseButton = refreshedHeadings2.get(i);
                                js.executeScript("arguments[0].click();", collapseButton);
                                Thread.sleep(300);
                            }
                        } catch (Exception e) {
                            // Ignore collapse errors
                        }
                    }
                    
                } catch (StaleElementReferenceException e) {
                    System.out.println("  Stale element encountered for heading " + (i + 1));
                    continue;
                } catch (Exception e) {
                    System.out.println("  Error processing heading " + (i + 1) + ": " + e.getMessage());
                    e.printStackTrace();
                    continue;
                }
                
                // If assignment found, break out of heading loop
                if (assignmentFound) {
                    System.out.println("  ✅✅✅ BREAKING OUT OF HEADING LOOP - Assignment match found ✅✅✅");
                    break;
                }
            }
            
            System.out.println("\n========================================");
            if (assignmentFound) {
                System.out.println("✅ ASSIGNMENT FOUND AND MATCHED!");
                TestRunner.getTest().log(Status.PASS, "✅ Assignment found and matched: " + assignmentNameToFind);
            } else {
                System.out.println("⚠️ Assignment not found in any sub-heading");
                TestRunner.getTest().log(Status.WARNING, "Assignment not found in any sub-heading: " + assignmentNameToFind);
            }
            System.out.println("========================================\n");
            
        } catch (Exception e) {
            System.out.println("❌ Error clicking sub-headings and comparing assignment names: " + e.getMessage());
            TestRunner.getTest().log(Status.FAIL, "Error clicking sub-headings and comparing assignment names: " + e.getMessage());
            e.printStackTrace();
            throw e;
        }
    }

}

