package pageFactory.IndividualAssignmentReport;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import io.cucumber.java.sl.In;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Assignmment.CorrectAnswerExecutor_PF;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import static pageFactory.Assignmment.AdvancedGrading_PF.*;
import static pageFactory.Assignmment.CorrectAnswerExecutor_PF.addedNotes;
import static pageFactory.Gradebook.AssignmentScoreVerification_PF.totalScore;

public class IndividualAssignmentReport_PF {

    WebDriverWait wait;
    WebDriver driver;
    Helper helper;
    Actions actions;
    JavascriptExecutor js;


    public IndividualAssignmentReport_PF(WebDriver driver) {
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        helper = new Helper();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        actions = new Actions(driver);
        js = (JavascriptExecutor) driver;
    }

    @FindBy(xpath = "//div[contains(@class, 'StudentListingAndTableWrapper')]")
    WebElement studentAssignmentTable;

    public void searchAndOpenSpecificAssignmentForIndividualAssignmentReport(String assignmentName) throws InterruptedException {
        Thread.sleep(2000);
        helper.waitForPageToLoad();

        // Wait for table to be ready
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class, 'StudentListingAndTableWrapper')]//table")));
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(@class, 'StudentListingAndTableWrapper')]//table")));

        // Use locators instead of storing WebElement references to avoid stale elements
        By tableLocator = By.xpath("//div[contains(@class, 'StudentListingAndTableWrapper')]");
        By headerLocator = By.xpath(".//thead//tr//th");

        // Re-find table and get containers to avoid stale elements
        WebElement assignmentTable = wait.until(ExpectedConditions.visibilityOfElementLocated(tableLocator));
        List<WebElement> assignmentContainers = assignmentTable.findElements(headerLocator);
        System.out.println("Total Assignment Names are: " + assignmentContainers.size());
        TestRunner.getTest().log(Status.INFO, "Total Assignment Names are: " + assignmentContainers.size());

        for (int i = 0; i < assignmentContainers.size(); i++) {
            // Re-find table and containers for each iteration to avoid stale elements
            try {
                assignmentTable = wait.until(ExpectedConditions.visibilityOfElementLocated(tableLocator));
                assignmentContainers = assignmentTable.findElements(headerLocator);

                if (i >= assignmentContainers.size()) {
                    System.out.println("Index " + i + " out of bounds, breaking loop");
                    break;
                }

                WebElement assignment = assignmentContainers.get(i);
                String assignmentsName = assignment.getText().trim();
                System.out.println("Assignment Name: " + assignmentsName);

                if (assignmentsName.equalsIgnoreCase(assignmentName)) {
                    System.out.println("Found assignment: " + assignmentsName);

                    // Re-find elements before clicking to ensure they're not stale
                    boolean clicked = false;
                    int maxRetries = 3;
                    for (int retry = 0; retry < maxRetries && !clicked; retry++) {
                        try {
                            // Re-find the table element each time to avoid stale reference
                            assignmentTable = wait.until(ExpectedConditions.visibilityOfElementLocated(tableLocator));
                            assignmentContainers = assignmentTable.findElements(headerLocator);

                            if (i >= assignmentContainers.size()) {
                                throw new IndexOutOfBoundsException("Index " + i + " out of bounds after " + assignmentContainers.size() + " elements");
                            }

                            WebElement assignmentElement = assignmentContainers.get(i);

                            // Verify it's still the same assignment
                            String currentName = assignmentElement.getText().trim();
                            if (!currentName.equalsIgnoreCase(assignmentName)) {
                                System.out.println("Assignment name changed, retrying...");
                                Thread.sleep(500);
                                continue;
                            }

                            wait.until(ExpectedConditions.elementToBeClickable(assignmentElement));
                            assignmentElement.click();
                            clicked = true;

                            System.out.println("Assignment found and clicked");
                            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Assignment found successfully " + assignmentsName);

                            // Perform other actions
                            Thread.sleep(2000);
                            clickReportsAndIndividualReport();
                            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Click on Individual Assignment Report button successfully " + assignmentsName);

                            break;

                        } catch (StaleElementReferenceException e) {
                            System.out.println("StaleElementReferenceException on retry " + (retry + 1) + " of " + maxRetries + ": " + e.getMessage());
                            if (retry < maxRetries - 1) {
                                Thread.sleep(500);
                            } else {
                                throw new RuntimeException("Failed to click assignment after " + maxRetries + " retries due to stale elements", e);
                            }
                        } catch (IndexOutOfBoundsException e) {
                            System.out.println("Index out of bounds on retry " + (retry + 1) + ": " + e.getMessage());
                            if (retry < maxRetries - 1) {
                                Thread.sleep(500);
                            } else {
                                throw e;
                            }
                        }
                    }

                    if (!clicked) {
                        TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Could not click assignment after " + maxRetries + " retries");
//                        throw new RuntimeException("Failed to click assignment '" + assignmentName + "' after " + maxRetries + " retries");
                    }

                    return; // Successfully found and clicked, exit method
                }
            } catch (StaleElementReferenceException e) {
                System.out.println("StaleElementReferenceException at index " + i + ", continuing to next assignment...");
                // Continue to next iteration
            }
        }

        // If we reach here, assignment was not found
        TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Assignment '" + assignmentName + "' not found in the list");
        throw new RuntimeException("Assignment '" + assignmentName + "' not found in the table");
    }

    public void clickReportsAndIndividualReport() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO,
                "Attempting to click on Reports → Individual Assignment Report (Updated UI)");

        try {
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
            Actions actions = new Actions(driver);

            // Use the li with data-menu-item='reports' instead of the inner span
            By reportsLocator = By.cssSelector("li[data-menu-item='reports']");

            WebElement reportsBtn = wait.until(ExpectedConditions
                    .visibilityOfElementLocated(reportsLocator));

            // Ensure it's in view, then hover to open the side menu
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", reportsBtn);
            actions.moveToElement(reportsBtn).perform();
            Thread.sleep(1000);

            // Locator for the 'Individual Assignment Report' entry in the side menu
            By individualReportLocator = By.xpath(
                    "//li[@role='menuitem']//*[contains(normalize-space(),'Individual Assignment Report')]");

            WebElement individualReport = wait.until(ExpectedConditions
                    .visibilityOfElementLocated(individualReportLocator));

            wait.until(ExpectedConditions.elementToBeClickable(individualReport));
            individualReport.click();
            Thread.sleep(1000);

            TestRunner.getTest().log(Status.PASS,
                    "Test Case Passed: Successfully clicked on Individual Assignment Report.");
            System.out.println("Successfully clicked on Individual Assignment Report.");

        } catch (InterruptedException e) {
            TestRunner.getTest().log(Status.FAIL,
                    "Test Case Failed: Interrupted Exception occurred while clicking Reports. " + e.getMessage());
            System.out.println("Interrupted Exception occurred: " + e.getMessage());
            // Preserve interrupted status and fail the test
            Thread.currentThread().interrupt();
            throw e;
        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL,
                    "Test Case Failed: Exception occurred while clicking Reports. " + e.getMessage());
            System.out.println("Exception occurred while clicking Reports: " + e.getMessage());
            // Re-throw so the calling step can mark the scenario as failed
            throw new RuntimeException("Failed to click Reports → Individual Assignment Report", e);
        }
    }

    public void verifyBreadcrumbOnIndividualAssignmentReport() throws InterruptedException {

        TestRunner.getTest().log(Status.INFO, "I'm into verify Breadcrumb on Individual Assignment Report");
        helper.waitForPageToLoad();

        WebElement breadcrumb = driver.findElement(By.xpath("//nav[@aria-label='breadcrumb']"));
        String actualBreadcrumb = breadcrumb.getText().trim().replaceAll("\\s+", " ");
        String expectedBreadcrumb = "Home / Gradebook / FL Grade 5 / Individual Assignment Report / Individual Assignment Report";

        if (actualBreadcrumb.equalsIgnoreCase(expectedBreadcrumb)) {
            System.out.println("✅ Test Passed: Breadcrumb is correct → " + actualBreadcrumb);
            TestRunner.getTest().log(Status.PASS, "✅ Test Passed: Breadcrumb is correct and Matched → " + actualBreadcrumb);
        } else {
            System.out.println("❌ Test Failed: Expected '" + expectedBreadcrumb + "' but found '" + actualBreadcrumb + "'");
            TestRunner.getTest().log(Status.FAIL, "❌ Test Failed: Expected '" + expectedBreadcrumb + "' but found '" + actualBreadcrumb + "'");
        }

    }


    public void verifyReportGeneratedTime() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO,
                "Verifying Report Generated date and time on UI");

        try {
            // Wait for Report Generated label
            wait.until(ExpectedConditions.visibilityOfElementLocated(
                    By.xpath("//div[contains(text(),'Report Generated')]")
            ));
            Thread.sleep(1000);

            WebElement reportGeneratedElement = driver.findElement(
                    By.xpath("//div[contains(text(),'Report Generated')]")
            );

            if (reportGeneratedElement.isDisplayed()) {

                String reportGeneratedText = reportGeneratedElement.getText();

                TestRunner.getTest().log(Status.PASS,
                        "Test Case Passed: Report Generated text is displayed -> " + reportGeneratedText);

                System.out.println("Report Generated Info: " + reportGeneratedText);

            } else {
                TestRunner.getTest().log(Status.FAIL,
                        "Test Case Failed: Report Generated text is not displayed on UI");
                System.out.println("Report Generated text not visible on UI.");
            }

        } catch (InterruptedException e) {
            TestRunner.getTest().log(Status.FAIL,
                    "Test Case Failed: Interrupted Exception while verifying Report Generated text. "
                            + e.getMessage());
            System.out.println("Interrupted Exception: " + e.getMessage());

        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL,
                    "Test Case Failed: Exception while verifying Report Generated text. "
                            + e.getMessage());
            System.out.println("Exception: " + e.getMessage());
        }
    }

    public void viewGradebookButtonOnIndividualAssignmentReport() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Verify and Click on 'View Gradebook' Button on Individual Assignment Report");

        try {
            // Locate the button
            WebElement viewGradebookBtn = driver.findElement(By.xpath("//button[normalize-space()='View Gradebook']"));

            // Check if button is displayed and enabled
            if (viewGradebookBtn.isDisplayed() && viewGradebookBtn.isEnabled()) {
                viewGradebookBtn.click();
                TestRunner.getTest().log(Status.PASS, "'View Gradebook' button clicked successfully");
            } else {
                TestRunner.getTest().log(Status.FAIL, "'View Gradebook' button is not clickable");
                throw new AssertionError("'View Gradebook' button is not clickable");
            }
        } catch (NoSuchElementException e) {
            TestRunner.getTest().log(Status.FAIL, "'View Gradebook' button is not present on the page");
            // Let the step definition catch this and call Assert.fail()
            throw e;
        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "Exception occurred: " + e.getMessage());
            // Bubble up as runtime so the test fails instead of passing silently
            throw new RuntimeException("Failed while verifying/clicking 'View Gradebook' button", e);
        }

    }

    public void validateStudentDataOnIndividualAssignmentReport() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into Verify that Student Data is Visible and Present on Student Progress Report");

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

// Locate elements and get text
        String studentName = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//div[contains(@class,'AvatarWrapper')]//h2")
        )).getText().trim();

        String grade = driver.findElement(By.xpath("//div[contains(@class,'AvatarWrapper')]//p[b[normalize-space(text())='Grade:']]/span")).getText().trim();
        String teacher = driver.findElement(By.xpath("//div[contains(@class,'AvatarWrapper')]//p[b[normalize-space(text())='Teacher:']]/span")).getText().trim();
        String start = driver.findElement(By.xpath("//div[contains(@class,'AvatarWrapper')]//p[b[normalize-space(text())='Start:']]/span")).getText().trim();
        String submitted = driver.findElement(By.xpath("//div[contains(@class,'AvatarWrapper')]//p[b[normalize-space(text())='Submitted:']]/span")).getText().trim();

        boolean allPresent = true;

        if (studentName.isEmpty()) {
            System.out.println("❌ Student Name is missing!");
            TestRunner.getTest().log(Status.WARNING, "Student Name is missing! " + studentName);
            allPresent = false;
        } else {
            System.out.println("✅ Student Name: " + studentName);
            TestRunner.getTest().log(Status.PASS, "Student Name: " + studentName);
        }

        if (grade.isEmpty()) {
            System.out.println("❌ Grade is missing!");
            TestRunner.getTest().log(Status.WARNING, "Grade is missing" + grade);
            allPresent = false;
        } else {
            System.out.println("✅ Grade: " + grade);
            TestRunner.getTest().log(Status.PASS, "Grade: " + grade);
        }

        if (teacher.isEmpty()) {
            System.out.println("❌ Teacher is missing!");
            TestRunner.getTest().log(Status.WARNING, "Teacher is missing!" + teacher);
            allPresent = false;
        } else {
            System.out.println("✅ Teacher: " + teacher);
            TestRunner.getTest().log(Status.PASS, "Teacher: " + teacher);
        }

        if (start.isEmpty()) {
            System.out.println("❌ Start is missing!");
            TestRunner.getTest().log(Status.WARNING, "Start is missing!" + start);
            allPresent = false;
        } else {
            System.out.println("✅ Start: " + start);
            TestRunner.getTest().log(Status.PASS, "Start: " + start);
        }

        if (submitted.isEmpty()) {
            System.out.println("❌ Submitted is missing!");
            TestRunner.getTest().log(Status.WARNING, "Submitted is missing!" + submitted);
            allPresent = false;
        } else {
            System.out.println("✅ Submitted: " + submitted);
            TestRunner.getTest().log(Status.PASS, "Submitted: " + submitted);
        }

// Final test result
        if (allPresent) {
            System.out.println("✅ Test Passed: All student information is displayed correctly.");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: All Student Information is present on Student Progress Report");
        } else {
            System.out.println("❌ Test Failed: Some student information is missing or broken.");
            TestRunner.getTest().log(Status.FAIL, "Test Failed: Some student information is missing or broken.");
        }
    }


    public void validateAssignmentInformationOnIndividualAssignmentReport() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Check and validate Assignment Information On Individual Assignment Report");


        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

// Locate elements and get text
        String assignmentTitle = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//div[contains(@class,'AvatarWrapper AssignmentCardWrapper')]//p[1]/span")
        )).getText().trim();

        String originalTitle = driver.findElement(By.xpath("//div[contains(@class,'AvatarWrapper AssignmentCardWrapper')]//p[b[normalize-space(text())='Original Title:']]/span")).getText().trim();
        String subtitle = driver.findElement(By.xpath("//div[contains(@class,'AvatarWrapper AssignmentCardWrapper')]//div[contains(@class, 'DetailText')][b[normalize-space(text())='Subtitle:']]/span")).getText().trim();
        String due = driver.findElement(By.xpath("//div[contains(@class,'AvatarWrapper AssignmentCardWrapper')]//p[b[normalize-space(text())='Due:']]/span")).getText().trim();
        String auto_Graded = driver.findElement(By.xpath("//div[contains(@class,'AvatarWrapper AssignmentCardWrapper')]//div[normalize-space(text())='Auto-Graded']")).getText().trim();

        boolean allPresent = true;

        String assignmentNameForCorrect = CorrectAnswerExecutor_PF.assignmentNameForCorrect.get();
        System.out.println("Want to open attempted assignment: " + assignmentNameForCorrect);
        TestRunner.getTest().log(Status.INFO, "Want to open attempted assignment: " + assignmentNameForCorrect);

        if (assignmentTitle.equalsIgnoreCase(assignmentNameForCorrect)) {
            System.out.println("✅ Assignment name matched: " + assignmentTitle);
            TestRunner.getTest().log(Status.PASS,
                    "Assignment name matched: " + assignmentTitle);
        } else {
            System.out.println("❌ Expected: " + assignmentNameForCorrect + " but found: " + assignmentTitle);
            TestRunner.getTest().log(Status.FAIL,
                    "Expected: " + assignmentNameForCorrect + " but found: " + assignmentTitle);
        }

        if (assignmentTitle.isEmpty()) {
            System.out.println("❌ Assignment Name is missing!");
            TestRunner.getTest().log(Status.WARNING, "Assignment Name is missing! " + assignmentTitle);
            allPresent = false;
        } else {
            System.out.println("✅ Assignment Name: " + assignmentTitle);
            TestRunner.getTest().log(Status.PASS, "Assignment Name: " + assignmentTitle);
        }

        if (originalTitle.isEmpty()) {
            System.out.println("❌ Original Title is missing!");
            TestRunner.getTest().log(Status.WARNING, "Original Title is missing" + originalTitle);
            allPresent = false;
        } else {
            System.out.println("✅ Original Title: " + originalTitle);
            TestRunner.getTest().log(Status.PASS, "Original Title: " + originalTitle);
        }

        if (subtitle.isEmpty()) {
            System.out.println("❌ Subtitle is missing!");
            TestRunner.getTest().log(Status.WARNING, "Subtitle is missing!" + subtitle);
            allPresent = false;
        } else {
            System.out.println("✅ Subtitle: " + subtitle);
            TestRunner.getTest().log(Status.PASS, "Subtitle: " + subtitle);
        }

        if (due.isEmpty()) {
            System.out.println("❌ Due is missing!");
            TestRunner.getTest().log(Status.WARNING, "Due is missing!" + due);
            allPresent = false;
        } else {
            System.out.println("✅ Due: " + due);
            TestRunner.getTest().log(Status.PASS, "Due: " + due);
        }

        if (auto_Graded.isEmpty()) {
            System.out.println("❌ Auto-Graded is missing!");
            TestRunner.getTest().log(Status.WARNING, "Auto-Graded is missing!" + auto_Graded);
            allPresent = false;
        } else {
            System.out.println("✅ Auto-Graded: " + auto_Graded);
            TestRunner.getTest().log(Status.PASS, "Auto-Graded: " + auto_Graded);
        }

// Final test result
        if (allPresent) {
            System.out.println("✅ Test Passed: All student information is displayed correctly.");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: All Student Information is present on Student Progress Report");
        } else {
            System.out.println("❌ Test Failed: Some student information is missing or broken.");
            TestRunner.getTest().log(Status.FAIL, "Test Failed: Some student information is missing or broken.");
        }

    }

    @FindBy(xpath = "//div[contains(text(),'Checkpoint 01')]/ancestor::div[5] |//img[contains(@src,'cardimage-expertrack.png')]/ancestor::div[3]")
    public WebElement rowCourseET;

    public static ThreadLocal<List<String>> standardsReferenceArrayFromContent = ThreadLocal.withInitial(ArrayList::new);

    public void getAssignmentStandardsFromContent() {
        TestRunner.getTest().log(Status.INFO, "Get Assignment Standards From My Courses -- Content");
        System.out.println("Get Assignment Standards From My Courses --Content");

        try {
            WebElement btnStandardsSpecificAssignment = rowCourseET.findElement(By.xpath(".//span[@aria-label='attach standard']"));
            btnStandardsSpecificAssignment.click();

            WebElement dialogAssignment = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@role='dialog']")));

            if (dialogAssignment.isDisplayed()) {

                List<WebElement> references = dialogAssignment.findElements(By.xpath("//table//tr//td[1]"));

                if (references.isEmpty()) {
                    System.out.println("No references found. Empty row data.");
                    TestRunner.getTest().log(Status.FAIL, "No references found. Empty row data.");
                    Thread.sleep(3000);
                    helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());

                    WebElement closeButton = dialogAssignment.findElement(By.xpath(".//button[@aria-label='close']"));
                    closeButton.click();
                    TestRunner.getTest().log(Status.PASS, "Dialog box closed successfully after failed attempt.");
                    return;
                }

                for (WebElement reference : references) {
                    standardsReferenceArrayFromContent.get().add(reference.getText().trim());
                }

                for (String reference : standardsReferenceArrayFromContent.get()) {
                    System.out.println("Reference: " + reference);
                    TestRunner.getTest().log(Status.INFO, "Reference: " + reference);
                }
                Thread.sleep(3000);
                helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());

                WebElement closeButton = dialogAssignment.findElement(By.xpath(".//button[@aria-label='close']"));
                closeButton.click();
                System.out.println("Dialog box closed successfully.");
                TestRunner.getTest().log(Status.PASS, "Dialog box closed successfully.");

            } else {
                TestRunner.getTest().log(Status.FAIL, "Dialog box not displayed.");
            }

        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "An error occurred while getting assignment standards.");
            e.printStackTrace();
        }
    }

    public void clickStandardIconOnIndividualAssignmentReport() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO,
                "Verify and click 'standard' icon button on Individual Assignment Report card");

        By standardIconLocator = By.xpath(
                "//div[contains(@class,'AvatarWrapper AssignmentCardWrapper')]//button[@aria-label='Book icon']"
                // change 'Book icon' to 'Info icon' here if you meant the other one
        );

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        try {
            // Wait until the icon is visible and clickable
            WebElement standardIconBtn = wait.until(
                    ExpectedConditions.visibilityOfElementLocated(standardIconLocator)
            );
            wait.until(ExpectedConditions.elementToBeClickable(standardIconBtn));

            if (standardIconBtn.isDisplayed() && standardIconBtn.isEnabled()) {
                standardIconBtn.click();
                TestRunner.getTest().log(Status.PASS,
                        "'Standard' icon button is visible, clickable, and was clicked successfully");
                System.out.println("✅ Standard icon button clicked successfully.");
            } else {
                TestRunner.getTest().log(Status.FAIL,
                        "'Standard' icon button is not clickable (not displayed or disabled)");
                throw new AssertionError("'Standard' icon button is not clickable");
            }

        } catch (TimeoutException | NoSuchElementException e) {
            TestRunner.getTest().log(Status.FAIL,
                    "'Standard' icon button is not present or not visible on the page");
            System.out.println("❌ Standard icon button not found/visible: " + e.getMessage());
            throw e;  // let the step definition fail the test
        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL,
                    "Exception occurred while clicking 'Standard' icon button: " + e.getMessage());
            System.out.println("❌ Exception while clicking standard icon: " + e.getMessage());
            throw new RuntimeException("Failed to click 'Standard' icon button", e);
        }
    }

    public void verifyStandardsPromptOnIndividualAssignmentReport() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm Into Verify Standards Prompt On Individual Assignment Report");

        Thread.sleep(2000);

        WebElement prompt = driver.findElement(By.xpath("//div[@role='dialog']"));
        boolean isDisplayed = prompt.isDisplayed();
        Assert.assertTrue("Standards Prompt is not displayed.", isDisplayed);

        WebElement promptHeader = prompt.findElement(By.tagName("h2"));
        String headerText = promptHeader.getText();
        System.out.println("Prompt header text is: " + headerText);
        TestRunner.getTest().log(Status.PASS, "Test Case Passed   :  Standards Prompt Display Successfully");
    }

    public static ThreadLocal<List<String>> referenceArrayOnIndividualAssignmentReport = ThreadLocal.withInitial(ArrayList::new);

    public void getStandardsFromIndividualAssignmentReport() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into get Standards From Individual Assignment Report");

        System.out.println("I'm into get Standards From Individual Assignment Report");

        try {

            WebElement dialogAssignment = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@role='dialog']")));

            if (dialogAssignment.isDisplayed()) {

                List<WebElement> references = dialogAssignment.findElements(By.xpath(".//table//tr//td[1]"));

                if (references.isEmpty()) {
                    System.out.println("No references found. Empty row data.");
                    TestRunner.getTest().log(Status.FAIL, "No references found. Empty row data.");
                    Thread.sleep(3000);
                    helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());

                    WebElement closeButton = dialogAssignment.findElement(By.xpath(".//button[@aria-label='close']"));
                    closeButton.click();
                    TestRunner.getTest().log(Status.PASS, "Dialog box closed successfully after failed attempt.");
                    return;
                }

                for (WebElement reference : references) {
                    referenceArrayOnIndividualAssignmentReport.get().add(reference.getText().trim());
                }

                for (String reference : referenceArrayOnIndividualAssignmentReport.get()) {
                    System.out.println("Reference: " + reference);
                    TestRunner.getTest().log(Status.INFO, "Reference: " + reference);
                }
                Thread.sleep(3000);
                helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());

                WebElement closeButton = dialogAssignment.findElement(By.xpath(".//button[@aria-label='close']"));
                closeButton.click();
                System.out.println("Dialog box closed successfully.");
                TestRunner.getTest().log(Status.PASS, "Dialog box closed successfully.");

            } else {
                TestRunner.getTest().log(Status.FAIL, "Dialog box not displayed.");
            }

        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "An error occurred while getting assignment standards From Individual Assignment Report.");
            e.printStackTrace();
        }
    }

    public void validateStandardMatchOnIndividualAssignmentReport() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into validate Standard Match On Individual Assignment Report");
        System.out.println("I'm into validate Standard Match On Individual Assignment Report");

        List<String> arr1 = standardsReferenceArrayFromContent.get();
        List<String> arr2 = referenceArrayOnIndividualAssignmentReport.get();

        if (arr1.size() != arr2.size()) {
            System.out.println("❌ Test Failed: Array sizes do not match!");
            TestRunner.getTest().log(Status.FAIL, "❌ Test Failed: Array sizes do not match!");
            System.out.println("Array1: " + arr1);
            TestRunner.getTest().log(Status.INFO, "Standard Array list from Content:" + arr1);
            System.out.println("Array2: " + arr2);
            TestRunner.getTest().log(Status.INFO, "Standard Array list from  Individual Assignment Report:" + arr2);
            return;
        }

        boolean allMatch = true;

        for (int i = 0; i < arr1.size(); i++) {
            String val1 = arr1.get(i);
            String val2 = arr2.get(i);

            if (!val1.equals(val2)) {
                System.out.println("❌ Mismatch at index " + i +
                        " -> Expected: " + val1 +
                        ", Found: " + val2);
                TestRunner.getTest().log(Status.FAIL, "❌ Mismatch at index " + i +
                        " -> Expected: " + val1 +
                        ", Found: " + val2);
                allMatch = false;
            }
        }

        if (allMatch) {
            System.out.println("✅ Test Passed: Standard match on Individual Assignment Report");
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Standard match on Individual Assignment Report");
        } else {
            System.out.println("❌ Test Failed: One/more standard not match on Individual Assignment Report.");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Standard match on Individual Assignment Report");
        }
    }


    public void VerifyViewAssignmentNotesButtonOnIndividualAssignmentReport() throws InterruptedException {

        TestRunner.getTest().log(Status.INFO, "I'm into Verify and Click View Assignment Notes Button On Individual Assignment Report");

        try {

            WebElement viewNotesBtn = wait.until(
                    ExpectedConditions.presenceOfElementLocated(
                            By.xpath("//button[normalize-space()='View Assignment Notes']")
                    )
            );

            if (viewNotesBtn.isDisplayed()) {
                viewNotesBtn.click();
                TestRunner.getTest().log(Status.PASS,
                        "View Assignment Notes button is displayed and clicked successfully");
            } else {
                TestRunner.getTest().log(Status.FAIL,
                        "View Assignment Notes button is present but not visible");
                Assert.fail("View Assignment Notes button is not visible");
            }

        } catch (TimeoutException e) {
            TestRunner.getTest().log(Status.FAIL,
                    "View Assignment Notes button is NOT displayed on the page");
            Assert.fail("View Assignment Notes button not found");
        }
    }

    public void ValidateAssignmentNotesPrompt() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into Validate Assignment Notes Prompt");

        Thread.sleep(2000);

        WebElement prompt = driver.findElement(By.xpath("//div[@role='dialog']"));
        boolean isDisplayed = prompt.isDisplayed();
        Assert.assertTrue("Assignment Notes Prompt is not displayed.", isDisplayed);

        WebElement promptHeader = prompt.findElement(By.tagName("h2"));
        String headerText = promptHeader.getText();
        System.out.println("Prompt header text is: " + headerText);
        TestRunner.getTest().log(Status.PASS, "Test Case Passed   : Assignment Notes Prompt Display Successfully");

    }

    public static ThreadLocal<List<String>> savedNotesOnIndividualAssignmentReport = ThreadLocal.withInitial(ArrayList::new);


    public void GetAssignmentNotesFromIndividualAssignmentReport() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO,
                "Get Assignment Notes From Individual Assignment Report");

        try {
            // Wait for dialog
            WebElement dialog = wait.until(
                    ExpectedConditions.visibilityOfElementLocated(
                            By.xpath("//div[contains(@class,'IANotesDialogWrapper')]")
                    )
            );
            TestRunner.getTest().log(Status.INFO,
                    "Assignment Notes dialog is visible.");

            // Get all textarea notes
            List<WebElement> textAreas = dialog.findElements(
                    By.xpath(".//textarea[contains(@id,'addNotes')]")
            );

            if (textAreas.isEmpty()) {
                TestRunner.getTest().log(Status.FAIL,
                        "No assignment notes found in the dialog");
                Assert.fail("Assignment Notes list is empty");
            }

            for (WebElement textArea : textAreas) {
                String noteText = textArea.getText().trim(); // best for disabled textarea

                TestRunner.getTest().log(Status.INFO,
                        "Fetched Note: " + noteText);
                System.out.println("Fetched Note: " + noteText);

                savedNotesOnIndividualAssignmentReport.get().add(noteText);
            }

            TestRunner.getTest().log(Status.PASS,
                    "Successfully fetched all Assignment & Page notes");

            // Close dialog
//            WebElement closeButton = dialog.findElement(
//                    By.xpath("(.//button[contains(@class,'text-white')])[2]")
//            );
//            closeButton.click();

            TestRunner.getTest().log(Status.INFO,
                    "Closing the Assignment Notes Dialogue");

            actions.sendKeys(Keys.ESCAPE).perform();


            TestRunner.getTest().log(Status.PASS,
                    "Closed Assignment Notes dialog");

        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL,
                    "Exception while fetching assignment notes: " + e.getMessage());
            Assert.fail("Failed to fetch assignment notes");
        }
    }

    public void ValidateStudentAndTeacherNotesFromIndividualAssignmentReport() throws InterruptedException {
        if (savedNotesOnIndividualAssignmentReport.get().size() != addedNotes.get().size()) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: The number of notes does not match.");
            System.out.println("The number of notes does not match. Expected: " + addedNotes.get().size() + ", Found: " + savedNotesOnIndividualAssignmentReport.get().size());
            return;
        }

        for (int i = 0; i < savedNotesOnIndividualAssignmentReport.get().size(); i++) {
            String savedNote = savedNotesOnIndividualAssignmentReport.get().get(i);
            String addedNote = addedNotes.get().get(i);

            if (savedNote.equals(addedNote)) {
                System.out.println("Note " + (i + 1) + " matches: " + savedNote);
                TestRunner.getTest().log(Status.PASS, "Note " + (i + 1) + " matches: " + savedNote);
            } else {
                System.out.println("Note " + (i + 1) + " mismatch. Added: " + addedNote + ", Found: " + savedNote);
                TestRunner.getTest().log(Status.FAIL, "Note " + (i + 1) + " mismatch. Added: " + addedNote + ", Found: " + savedNote);
            }
        }

        TestRunner.getTest().log(Status.INFO, "Comparison between saved and added notes is completed.");
        System.out.println("Comparison between saved and added notes is completed.");
    }


    public void validateClassDropdown() throws InterruptedException {

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));

        TestRunner.getTest().log(Status.INFO, "Verifying selected class in Class dropdown");

        WebElement arrowElement = null; // store arrow for later

        try {
            // 1️⃣ Get selected class name
            By selectedClassInput = By.xpath("//input[@placeholder='Select Class...']");
            WebElement classInput = wait.until(
                    ExpectedConditions.visibilityOfElementLocated(selectedClassInput)
            );

            String selectedClassName = classInput.getAttribute("value").trim();
            TestRunner.getTest().log(Status.INFO, "Selected Class: " + selectedClassName);

            if (selectedClassName.isEmpty()) {
                TestRunner.getTest().log(Status.FAIL, "Selected class value is empty");
                return;
            }

            // 2️⃣ Click dropdown arrow to open
            By dropdownArrow = By.xpath("//input[@placeholder='Select Class...']/following-sibling::button");
            arrowElement = wait.until(ExpectedConditions.elementToBeClickable(dropdownArrow));
            arrowElement.click();
            TestRunner.getTest().log(Status.INFO, "Clicked Class dropdown");

            // 3️⃣ Get all class options
            By classOptions = By.xpath("//ul//li");
            List<WebElement> allClasses = wait.until(
                    ExpectedConditions.visibilityOfAllElementsLocatedBy(classOptions)
            );

            if (allClasses.isEmpty()) {
                TestRunner.getTest().log(Status.FAIL, "No classes found in dropdown");
                arrowElement.click(); // close dropdown
                return;
            }

            boolean isSelectedClassPresent = false;

            for (WebElement cls : allClasses) {
                String className = cls.getText().trim();
                if (!className.isEmpty()) {
                    // 🔹 Scroll the selected class into view
                    if (className.equals(selectedClassName)) {
                        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", cls);
                        TestRunner.getTest().log(Status.INFO, "Scrolled to selected class: " + className);
                    }

                    TestRunner.getTest().log(Status.INFO, "Dropdown Class: " + className);

                    if (className.equals(selectedClassName)) {
                        isSelectedClassPresent = true;
                    }
                }
            }

            // 4️⃣ Validation
            if (isSelectedClassPresent) {
                TestRunner.getTest().log(Status.PASS, "Selected class '" + selectedClassName + "' is present in dropdown");
            } else {
                TestRunner.getTest().log(Status.FAIL, "Selected class '" + selectedClassName + "' is NOT present in dropdown");
            }

        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "Exception while verifying class dropdown: " + e.getMessage());
        } finally {
            // 5️⃣ Close dropdown safely
            try {
                if (arrowElement != null && arrowElement.isDisplayed() && arrowElement.isEnabled()) {
                    arrowElement.click();
                    TestRunner.getTest().log(Status.INFO, "Closed Class dropdown");
                }
            } catch (Exception e) {
                TestRunner.getTest().log(Status.WARNING, "Failed to close dropdown: " + e.getMessage());
            }
        }
    }


    public void validateUserDropdown() throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));

        TestRunner.getTest().log(Status.INFO, "Verifying selected user in User dropdown");

        WebElement arrowElement = null; // store the dropdown arrow for later

        try {
            // 1️⃣ Get selected user name
            By selectedUserSpan = By.xpath("//div[@class='flex-1 relative']//span[contains(@class,'truncate') and contains(@class,'font-semibold')]");
            WebElement userElement = wait.until(ExpectedConditions.visibilityOfElementLocated(selectedUserSpan));

            String selectedUserName = userElement.getText().trim();
            TestRunner.getTest().log(Status.INFO, "Selected User: " + selectedUserName);

            if (selectedUserName.isEmpty()) {
                TestRunner.getTest().log(Status.FAIL, "Selected user value is empty");
                return;
            }

            // 2️⃣ Click dropdown arrow
            By dropdownArrow = By.xpath("//div[@class='flex-1 relative']//span[contains(@class,'transition-transform')]");
            arrowElement = wait.until(ExpectedConditions.elementToBeClickable(dropdownArrow));
            arrowElement.click();
            TestRunner.getTest().log(Status.INFO, "Clicked User dropdown");

            // 3️⃣ Wait for dropdown to render
            Thread.sleep(500); // small wait for animation

            // 4️⃣ Get all user options
            By userOptions = By.xpath("//div[contains(@class,'absolute top-full')]//div[contains(@class,'cursor-pointer')]/span[@class='truncate']");
            List<WebElement> allUsers = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(userOptions));

            if (allUsers.isEmpty()) {
                TestRunner.getTest().log(Status.FAIL, "No users found in dropdown");
                return;
            }

            boolean isSelectedUserPresent = false;

            for (WebElement user : allUsers) {
                String userName = user.getText().trim();
                if (!userName.isEmpty()) {
                    // 🔹 Scroll this user into view
                    if (userName.equals(selectedUserName)) {
                        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", user);
                        TestRunner.getTest().log(Status.INFO, "Scrolled to selected user: " + userName);
                    }
                    TestRunner.getTest().log(Status.INFO, "Dropdown User: " + userName);

                    if (userName.equals(selectedUserName)) {
                        isSelectedUserPresent = true;
                    }
                }
            }

            // 5️⃣ Validation
            if (isSelectedUserPresent) {
                TestRunner.getTest().log(Status.PASS, "Selected user '" + selectedUserName + "' is present in dropdown");
            } else {
                TestRunner.getTest().log(Status.FAIL, "Selected user '" + selectedUserName + "' is NOT present in dropdown");
            }

        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "Exception while verifying user dropdown: " + e.getMessage());
        } finally {
            // 6️⃣ Close dropdown safely
            try {
                if (arrowElement != null && arrowElement.isDisplayed() && arrowElement.isEnabled()) {
                    arrowElement.click();
                    TestRunner.getTest().log(Status.INFO, "Closed User dropdown");
                }
            } catch (Exception e) {
                TestRunner.getTest().log(Status.WARNING, "Failed to close dropdown: " + e.getMessage());
            }
        }
    }

    public void validateAssignmentDropdown() throws InterruptedException {

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));

        TestRunner.getTest().log(Status.INFO, "Verifying selected Assignment in Assignment dropdown");

        WebElement arrowElement = null;

        try {
            // 1️⃣ Get selected assignment name
            By selectedAssignmentInput = By.xpath("//input[@placeholder='Select Assignment...']");
            WebElement assignmentInput = wait.until(
                    ExpectedConditions.visibilityOfElementLocated(selectedAssignmentInput)
            );

            String selectedAssignmentName = assignmentInput.getAttribute("value").trim();
            TestRunner.getTest().log(Status.INFO, "Selected Assignment: " + selectedAssignmentName);

            if (selectedAssignmentName.isEmpty()) {
                TestRunner.getTest().log(Status.FAIL, "Selected Assignment value is empty");
                return;
            }

            // 2️⃣ Click dropdown arrow to open
            By dropdownArrow = By.xpath("//input[@placeholder='Select Assignment...']/following-sibling::button");
            arrowElement = wait.until(ExpectedConditions.elementToBeClickable(dropdownArrow));
            arrowElement.click();
            TestRunner.getTest().log(Status.INFO, "Clicked Assignment dropdown");

            // 3️⃣ Get all assignment options
            By assignmentOptions = By.xpath("//ul//li");
            List<WebElement> allAssignments = wait.until(
                    ExpectedConditions.visibilityOfAllElementsLocatedBy(assignmentOptions)
            );

            if (allAssignments.isEmpty()) {
                TestRunner.getTest().log(Status.FAIL, "No Assignments found in dropdown");
                arrowElement.click(); // close dropdown
                return;
            }

            boolean isSelectedAssignmentPresent = false;

            for (WebElement assignment : allAssignments) {
                String assignmentName = assignment.getText().trim();
                if (!assignmentName.isEmpty()) {
                    // Scroll this assignment into view
                    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", assignment);
                    TestRunner.getTest().log(Status.INFO, "Dropdown Assignment: " + assignmentName);

                    if (assignmentName.equals(selectedAssignmentName)) {
                        isSelectedAssignmentPresent = true;
                    }
                }
            }

            // 4️⃣ Validation via TestRunner
            if (isSelectedAssignmentPresent) {
                TestRunner.getTest().log(
                        Status.PASS,
                        "Selected Assignment '" + selectedAssignmentName + "' is present in dropdown"
                );
            } else {
                TestRunner.getTest().log(
                        Status.FAIL,
                        "Selected Assignment '" + selectedAssignmentName + "' is NOT present in dropdown"
                );
            }

        } catch (Exception e) {
            TestRunner.getTest().log(
                    Status.FAIL,
                    "Exception while verifying Assignment dropdown: " + e.getMessage()
            );
        } finally {
            // 5️⃣ Close dropdown
            try {
                if (arrowElement != null && arrowElement.isDisplayed() && arrowElement.isEnabled()) {
                    arrowElement.click();
                    TestRunner.getTest().log(Status.INFO, "Closed Assignment dropdown");
                }
            } catch (Exception e) {
                TestRunner.getTest().log(Status.WARNING, "Failed to close dropdown: " + e.getMessage());
            }
        }
    }


    public void statusOfAssignmentOnIndividualReport() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm Into Get STATUS On Individual Assignment Report");

        By statusValue = By.xpath("//p[normalize-space()='STATUS']/following-sibling::p[1]");

        try {
            WebElement statusElement = driver.findElement(statusValue);

            if (statusElement.isDisplayed()) {
                String status = statusElement.getText().trim();
                TestRunner.getTest().log(Status.INFO, "Status: " + status);
                TestRunner.getTest().log(Status.PASS, "Status is visible on UI");
            } else {
                TestRunner.getTest().log(Status.FAIL, "Status element is present but not visible on UI");
            }

        } catch (NoSuchElementException e) {
            TestRunner.getTest().log(Status.FAIL, "Status element is NOT present on UI");
        }

    }

    public void finalScoreOnIndividualAssignmentReport() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into getting Final Score on Individual Assignment Report");

        By finalScoreValue = By.xpath(
                "//p[normalize-space()='FINAL SCORE']/following-sibling::p[1]"
        );

        try {
            WebElement finalScoreElement = driver.findElement(finalScoreValue);

            if (finalScoreElement.isDisplayed()) {
                // Get text from UI
                String finalScore = finalScoreElement.getText().trim(); // e.g., "100%"

                // Remove percent sign if present
                finalScore = finalScore.replace("%", "").trim(); // now "100"

                TestRunner.getTest().log(Status.INFO, "FINAL SCORE on Report (without %): " + finalScore);

                // Now perform comparison with Close Assignment
                String finalScoreFromClose = totalScore.get();
                // Assuming you stored it in ThreadLocal earlier
                finalScoreFromClose = finalScoreFromClose.replace("%", "").trim(); // now "100"


                if (finalScore.equals(finalScoreFromClose)) {
                    TestRunner.getTest().log(Status.PASS,
                            "FINAL SCORE matches with Close Assignment | " + finalScore);
                } else {
                    TestRunner.getTest().log(Status.FAIL,
                            "Total Score does NOT match with Close Assignment | Report: "
                                    + finalScore + " | Close Assignment: " + finalScoreFromClose);
                }

            } else {
                TestRunner.getTest().log(Status.FAIL, "FINAL SCORE element is present but not visible on UI");
            }

        } catch (NoSuchElementException e) {
            TestRunner.getTest().log(Status.FAIL, "FINAL SCORE element is NOT present on UI");
        }
    }


    public void finalPointsOnIndividualAssignmentReport() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into getting FINAL POINTS on Individual Assignment Report");

        By finalPointsValue = By.xpath(
                "//p[normalize-space()='FINAL POINTS']/following-sibling::p[1]"
        );

        try {
            WebElement finalPointsElement = driver.findElement(finalPointsValue);

            if (finalPointsElement.isDisplayed()) {
                // Get text and remove spaces
                String finalPoints = finalPointsElement.getText().replaceAll("\\s+", ""); // "22.00/22.00"

                // Remove decimal part from each number
                // Split by "/", then remove everything after ".", then join back
                String[] parts = finalPoints.split("/");
                String scored = parts[0].split("\\.")[0]; // before "."
                String total = parts[1].split("\\.")[0];  // before "."

                String finalPointsClean = scored + "/" + total; // "22/22"

                TestRunner.getTest().log(Status.INFO, "Final Points on Report (cleaned): " + finalPointsClean);


                // Compare with Close Assignment value stored in ThreadLocal
                String finalPointsFromClose = pointsFromCloseAssignment.get();

                if (finalPointsClean.equals(finalPointsFromClose)) {
                    TestRunner.getTest().log(Status.PASS,
                            "Final Points match with Close Assignment | " + finalPointsClean);
                } else {
                    TestRunner.getTest().log(Status.FAIL,
                            "Final Points do NOT match with Close Assignment | Report: "
                                    + finalPointsClean + " | Close Assignment: " + finalPointsFromClose);
                }

            } else {
                TestRunner.getTest().log(Status.FAIL, "FINAL POINTS element is present but not visible on UI");
            }

        } catch (NoSuchElementException e) {
            TestRunner.getTest().log(Status.FAIL, "FINAL POINTS element is NOT present on UI");
        }
    }

    public void questionCorrectOnIndividualAssignment() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into getting QUESTIONS CORRECT on Individual Assignment Report");

        By questionsCorrectValueXpath = By.xpath(
                "//p[normalize-space()='QUESTIONS CORRECT']/following-sibling::p[1]"
        );

        try {
            WebElement questionsCorrectElement = driver.findElement(questionsCorrectValueXpath);

            if (questionsCorrectElement.isDisplayed()) {
                // Get UI value of questions correct (e.g., "9/9" or "09/09")
                String questionsCorrectUI = questionsCorrectElement.getText().replaceAll("\\s+", "");
                TestRunner.getTest().log(Status.INFO, "Questions Correct on Report (UI): " + questionsCorrectUI);

                // Get correct questions from your ThreadLocal
                String correctQuestionsValue = correctQuestions.get(); // could be "9" or "09"
                String totalQuestionsValue = totalQuestionInCloseAssignment.get(); // could be "09" etc.

                // Clean leading zeros
                correctQuestionsValue = correctQuestionsValue.replaceFirst("^0+", "");
                totalQuestionsValue = totalQuestionsValue.replaceFirst("^0+", "");

                // Build combined value: "correctQuestions / totalQuestions"
                String combinedValue = correctQuestionsValue + "/" + totalQuestionsValue;
                TestRunner.getTest().log(Status.INFO, "Combined value for comparison: " + combinedValue);

                // Compare with UI value
                if (combinedValue.equals(questionsCorrectUI)) {
                    TestRunner.getTest().log(Status.PASS,
                            "Questions Correct match | Combined: " + combinedValue + " | UI: " + questionsCorrectUI);
                } else {
                    TestRunner.getTest().log(Status.FAIL,
                            "Questions Correct do NOT match | Combined: " + combinedValue + " | UI: " + questionsCorrectUI);
                }

            } else {
                TestRunner.getTest().log(Status.FAIL, "QUESTIONS CORRECT element is present but not visible on UI");
            }

        } catch (NoSuchElementException e) {
            TestRunner.getTest().log(Status.FAIL, "QUESTIONS CORRECT element is NOT present on UI");
        }
    }


    public void verifyAssignmentSummaryOnIndividualAssignmentReport() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into Verify Assignment Summary On Individual Assignment Report");

        By assignmentSummaryButton = By.xpath(
                "//button[normalize-space()='Assignment Summary']"
        );

        try {
            WebElement button = driver.findElement(assignmentSummaryButton);

            if (button.isDisplayed()) {
                String ariaSelected = button.getAttribute("aria-selected");
                if ("true".equalsIgnoreCase(ariaSelected)) {
                    TestRunner.getTest().log(Status.PASS, "Assignment Summary button is already selected.");
                    getAssignmentSummaryOnIndividualAssignmentReport();
                } else {
                    TestRunner.getTest().log(Status.FAIL, "Assignment Summary button is NOT selected.");
                }
            } else {
                TestRunner.getTest().log(Status.FAIL, "Assignment Summary button is not visible on UI.");
            }

        } catch (NoSuchElementException e) {
            TestRunner.getTest().log(Status.FAIL, "Assignment Summary button is NOT present on UI.");
        }
    }

    public void getAssignmentSummaryOnIndividualAssignmentReport() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Get Assignment Summary On Individual Assignment Report");

        // Locator for the table, searching for a table that contains the header 'PERFORMANCE'
        By tableLocator = By.xpath("//table[.//th[contains(., 'PERFORMANCE')]]");

        try {
            // Wait for the table to be visible
            WebElement table = wait.until(ExpectedConditions.visibilityOfElementLocated(tableLocator));

            if (table.isDisplayed()) {
                TestRunner.getTest().log(Status.PASS, "Assignment Summary Table is visible on UI.");
                System.out.println("✅ Assignment Summary Table is visible.");

                // Get all rows from the table body
                List<WebElement> rows = table.findElements(By.xpath(".//tbody/tr"));

                if (rows.isEmpty()) {
                    String cleanMessage = "Assignment Summary Table is empty (no rows found).";
                    System.out.println("❌ " + cleanMessage);
                    TestRunner.getTest().log(Status.FAIL, cleanMessage);
                    Assert.fail(cleanMessage);
                }

                System.out.println("✅ Assignment Summary Table Data:");
                TestRunner.getTest().log(Status.INFO, "Fetching data from Assignment Summary Table...");

                // Iterate through each row and get column data
                for (int i = 0; i < rows.size(); i++) {
                    WebElement row = rows.get(i);
                    List<WebElement> columns = row.findElements(By.tagName("td"));

                    // Define columns based on the table structure:
                    // Col 0: #
                    // Col 1: PERFORMANCE
                    // Col 2: PTS EARNED
                    // Col 3: PTS POSSIBLE
                    // Col 4: Q. TYPE
                    // Col 5: STANDARDS

                    String rowNum = (columns.size() > 0) ? columns.get(0).getText().trim() : "N/A";
                    String performance = (columns.size() > 1) ? columns.get(1).getText().trim() : "N/A";
                    String ptsEarned = (columns.size() > 2) ? columns.get(2).getText().trim() : "N/A";
                    String ptsPossible = (columns.size() > 3) ? columns.get(3).getText().trim() : "N/A";
                    String qType = (columns.size() > 4) ? columns.get(4).getText().trim() : "N/A";
                    String standards = (columns.size() > 5) ? columns.get(5).getText().trim() : "N/A";

                    String rowData = "Row " + (i + 1) + " | " +
                            "#: " + rowNum + " | " +
                            "Performance: " + performance + " | " +
                            "Pts Earned: " + ptsEarned + " | " +
                            "Pts Possible: " + ptsPossible + " | " +
                            "Q. Type: " + qType + " | " +
                            "Standards: " + standards;

                    System.out.println(rowData);
                    TestRunner.getTest().log(Status.INFO, rowData);
                }

                TestRunner.getTest().log(Status.PASS, "Successfully retrieved all data from Assignment Summary Table.");

            } else {
                String errorMsg = "Assignment Summary Table is present but not visible on UI.";
                System.out.println("❌ " + errorMsg);
                TestRunner.getTest().log(Status.FAIL, errorMsg);
                Assert.fail(errorMsg);
            }

        } catch (TimeoutException | NoSuchElementException e) {
            String errorMsg = "Assignment Summary Table not found or not visible on UI.";
            System.out.println("❌ " + errorMsg);
            TestRunner.getTest().log(Status.FAIL, errorMsg);
            Assert.fail(errorMsg);
        } catch (Exception e) {
            String errorMsg = "An error occurred while getting Assignment Summary Table data: " + e.getMessage();
            System.out.println("❌ " + errorMsg);
            TestRunner.getTest().log(Status.FAIL, errorMsg);
            Assert.fail(errorMsg);
        }
    }
    public void clickStandardsInAssignmentSummaryTable() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Clicking Standards in Assignment Summary Table");

        By tableLocator = By.xpath("//table[.//th[contains(., 'PERFORMANCE')]]");

        try {
            WebElement table = wait.until(ExpectedConditions.visibilityOfElementLocated(tableLocator));

            List<WebElement> rows = table.findElements(By.xpath(".//tbody/tr"));

            if (rows.isEmpty()) {
                TestRunner.getTest().log(Status.FAIL, "Assignment Summary Table is empty.");
                return;
            }

            // User requested to process only the 1st row
            int rowLimit = Math.min(rows.size(), 1); 
            for (int i = 0; i < rowLimit; i++) {
                // Re-find rows to avoid StaleElementReferenceException
                rows = table.findElements(By.xpath(".//tbody/tr"));
                WebElement row = rows.get(i);
                List<WebElement> columns = row.findElements(By.tagName("td"));

                if (columns.size() > 5) {
                    WebElement standardsCell = columns.get(5);
                    // Find clickable elements (standard codes usually)
                    List<WebElement> standards = standardsCell.findElements(By.xpath(".//span[contains(@class, 'cursor-pointer')] | .//div[contains(@class, 'cursor-pointer')]"));

                    if (standards.isEmpty()) {
                        // verify if text itself is standard and clickable, sometimes it might be just text if not linked
                        // or maybe generic span
                         standards = standardsCell.findElements(By.tagName("span"));
                    }
                    
                    if (standards.isEmpty()) {
                         TestRunner.getTest().log(Status.INFO, "No clickable standards found in Row " + (i + 1));
                         continue;
                    }

                    for (int j = 0; j < standards.size(); j++) {
                         // Re-find standards in cell to avoid StaleElement
                         rows = table.findElements(By.xpath(".//tbody/tr"));
                         row = rows.get(i);
                         columns = row.findElements(By.tagName("td"));
                         standardsCell = columns.get(5);
                         // This specific locator might need adjustment based on valid standard class
                         standards = standardsCell.findElements(By.xpath(".//span[contains(@class, 'cursor-pointer')] | .//div[contains(@class, 'cursor-pointer')]"));
                         
                         // Fallback re-find
                         if(standards.isEmpty()) standards = standardsCell.findElements(By.tagName("span"));

                        if (j < standards.size()) {
                            WebElement standard = standards.get(j);
                            String stdText = standard.getText().trim();
                            if(!stdText.isEmpty()) {
                                System.out.println("Clicking Standard: " + stdText);
                                TestRunner.getTest().log(Status.INFO, "Clicking Standard: " + stdText);
                                
                                // scroll into view
                                ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", standard);
                                // Removed Thread.sleep(500) for optimization. 
                                // Explicitly wait for clickability if needed, though usually standard loop handles it.
                                wait.until(ExpectedConditions.elementToBeClickable(standard));
                                standard.click();

                                // Handle Dialog if it opens
                                try {
                                    WebElement dialog = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@role='dialog']")));
                                    if(dialog.isDisplayed()){
                                         TestRunner.getTest().log(Status.PASS, "Standard Dialog Opened for: " + stdText);

                                         getTimeAccessedModalData(stdText, (i + 1));

                                        actions.sendKeys(Keys.ESCAPE).perform();

                                         TestRunner.getTest().log(Status.INFO, "Standard Dialog Closed.");
                                    }
                                } catch (TimeoutException se) {
                                    // Maybe no dialog opens, or it's different. Just log and continue.
                                    TestRunner.getTest().log(Status.WARNING, "No dialog appeared for standard: " + stdText);
                                }
                            }
                        }
                    }
                }
            }

        } catch (Exception e) {
             TestRunner.getTest().log(Status.FAIL, "Exception clicking standards: " + e.getMessage());
             e.printStackTrace();
        }
    }

    public void getTimeAccessedModalData(String standardName, int rowNumber) throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Get Data From Time Accessed Modal used for: " + standardName + " (Row " + rowNumber + ")");

        try {
            // Wait for modal to be visible
            WebElement modal = wait.until(ExpectedConditions.visibilityOfElementLocated(
                    By.xpath("//div[contains(@class, 'IAStandardTimesAssessedDialogWrapper')]")));

            if (modal.isDisplayed()) {
                // 1. Get Title / Times Assessed Count
                try {
                    WebElement titleElement = driver.findElement(By.xpath("//div[@id='dialog-title']//h2"));
                    String titleText = titleElement.getText().trim();
                    System.out.println("Modal Title: " + titleText);
                    TestRunner.getTest().log(Status.INFO, "Modal Title: " + titleText);
                    TestRunner.getTest().log(Status.PASS, "Modal Title Display Successfully");
                } catch (NoSuchElementException e) {
                    TestRunner.getTest().log(Status.FAIL, "Modal title not found.");
                }

                // 2. Get Content Statement
                try {
                    WebElement contentStatement = modal.findElement(By.xpath(".//span[contains(@class, 'contentStatementDetail')]"));
                    String statementText = contentStatement.getText().trim();
                    System.out.println("Content Statement: " + statementText);
                    TestRunner.getTest().log(Status.INFO, "Content Statement: " + statementText);
                    TestRunner.getTest().log(Status.PASS, "Content Statement Display Successfully");
                } catch (NoSuchElementException e) {
                    TestRunner.getTest().log(Status.FAIL, "Content Statement not found.");
                }

                // 3. Get Question Rows
                List<WebElement> questionRows = modal.findElements(By.xpath(".//div[contains(@class, 'questionRow')]"));
                if (questionRows.isEmpty()) {
                    TestRunner.getTest().log(Status.INFO, "No question rows found in Times Assessed modal.");
                } else {
                    for (int i = 0; i < questionRows.size(); i++) {
                        WebElement row = questionRows.get(i);
                        String qLabel = "N/A";
                        String qStatus = "N/A";

                        try {
                            qLabel = row.findElement(By.xpath(".//span[contains(@class, 'questionLabel')]")).getText().trim();
                        } catch (Exception ignored) {}
                        
                        try {
                            qStatus = row.findElement(By.xpath(".//span[contains(@class, 'questionStatus')]")).getText().trim();
                        } catch (Exception ignored) {}

                        String rowLog = "Row " + (i + 1) + " | Label: " + qLabel + " | Status: " + qStatus;
                        System.out.println(rowLog);
                        TestRunner.getTest().log(Status.INFO, rowLog);
                    }
                }
                TestRunner.getTest().log(Status.PASS, "Successfully retrieved data from Times Assessed Modal.");

            } else {
                TestRunner.getTest().log(Status.FAIL, "Times Assessed Modal is not displayed.");
            }

        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "Error in get Time Accessed Modal Data: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public void verifyPrintButtonAndOptions() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Verify Print Button and Dropdown Options");

        try {
            // 1. Locate and Click Print Button
            By printBtnLocator = By.xpath("//button[contains(., 'Print')]");
            WebElement printBtn = wait.until(ExpectedConditions.elementToBeClickable(printBtnLocator));
            
            if (printBtn.isDisplayed()) {
                printBtn.click();
                TestRunner.getTest().log(Status.PASS, "Print button clicked successfully.");
            } else {
                TestRunner.getTest().log(Status.FAIL, "Print button is not visible.");
                return;
            }

            // 2. Verify Dropdown Options
            String[] options = {"Print Single Student", "Print Class", "Print By Group"};
            for (String option : options) {
                By optionLocator = By.xpath("//div[contains(text(), '" + option + "')]");
                WebElement optElement = wait.until(ExpectedConditions.visibilityOfElementLocated(optionLocator));
                if (optElement.isDisplayed()) {
                    TestRunner.getTest().log(Status.PASS, "Option visible: " + option);
                } else {
                    TestRunner.getTest().log(Status.FAIL, "Option NOT visible: " + option);
                }
            }

            // 3. Click 'Print Single Student'
            By printSingleStudentLocator = By.xpath("//div[contains(text(), 'Print Single Student')]");
            driver.findElement(printSingleStudentLocator).click();
            TestRunner.getTest().log(Status.INFO, "Clicked 'Print Single Student'.");

            // 4. Verify Modal Validation
            verifyPrintOptionsModalValidation();

        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "Exception in verifyPrintButtonAndOptions: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public void verifyPrintOptionsModalValidation() {
        TestRunner.getTest().log(Status.INFO, "Verifying Print Options Modal Validation");

        try {
            // Wait for Modal
            WebElement dialog = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@role='dialog']")));
            WebElement modal = dialog.findElement(By.xpath(".//div[contains(@class, 'PrintOptionsDialogWrapper')]"));
            
            // Verify Title
            WebElement titleElement = dialog.findElement(By.xpath(".//h2[contains(text(), 'Print Options')]"));
            if (titleElement.isDisplayed()) {
                TestRunner.getTest().log(Status.PASS, "Print Options modal displayed.");
            } else {
                TestRunner.getTest().log(Status.FAIL, "Print Options modal NOT displayed.");
                return;
            }

            // Locate Custom Checkbox Labels
            // HTML structure: <label ...><div ...><svg ...></div><span>Text</span></label>
            WebElement summaryLabelLoc = modal.findElement(By.xpath(".//label[.//span[contains(text(), 'Assignment Summary')]]"));
            WebElement standardsLabelLoc = modal.findElement(By.xpath(".//label[.//span[contains(text(), 'Standards')]]"));

            // Determine checked state (presence of SVG inside the label's div)
            boolean isSummaryChecked = !summaryLabelLoc.findElements(By.xpath(".//div")).isEmpty();
            boolean isStandardsChecked = !standardsLabelLoc.findElements(By.xpath(".//div")).isEmpty();

            // --- Test Case: Uncheck Both ---
            // If checked (SVG present), click to uncheck
            if (isSummaryChecked) {
                clickCheckboxWrapper(summaryLabelLoc);
            }
            if (isStandardsChecked) {
                clickCheckboxWrapper(standardsLabelLoc);
            }

            WebElement printModalBtn = driver.findElement(By.xpath("//button[@type='button'][normalize-space()='Print']"));
            // Verify Validation Message
            By errorMsgLoc = By.xpath("//div[contains(text(), 'Minimum one value is required!')] | //span[contains(text(), 'Minimum one value is required!')]");
            try {
                WebElement errorMsg = wait.until(ExpectedConditions.visibilityOfElementLocated(errorMsgLoc));
                if (errorMsg.isDisplayed()) {
                    TestRunner.getTest().log(Status.PASS, "Validation message displayed: " + errorMsg.getText());
                } else {
                    TestRunner.getTest().log(Status.FAIL, "Validation message NOT displayed when options unchecked.");
                }
            } catch (TimeoutException e) {
                 TestRunner.getTest().log(Status.FAIL, "Validation message NOT found.");
            }

            // Verify Button Disabled
            if (!printModalBtn.isEnabled()) {
                 TestRunner.getTest().log(Status.PASS, "Print button is disabled as expected.");
            } else {
                 TestRunner.getTest().log(Status.FAIL, "Print button is ENABLED but should be DISABLED.");
            }

            // --- Test Case: Check Both ---
            clickCheckboxWrapper(summaryLabelLoc);
            clickCheckboxWrapper(standardsLabelLoc);

            // Verify Button Enabled
             if (printModalBtn.isEnabled()) {
                 TestRunner.getTest().log(Status.PASS, "Print button is enabled as expected.");
            } else {
                 TestRunner.getTest().log(Status.FAIL, "Print button is DISABLED but should be ENABLED.");
            }

            // Click Print (commented out to avoid actual print if just testing validation, or keep it)
            printModalBtn.click();
            TestRunner.getTest().log(Status.PASS, "Clicked Print button in modal.");

            pressEscapeUsingRobot();
            actions.sendKeys(Keys.ESCAPE).perform();

        } catch (Exception e) {
             TestRunner.getTest().log(Status.FAIL, "Exception in verifyPrintOptionsModalValidation: " + e.getMessage());
             e.printStackTrace();
        }
    }

    public void clickCheckboxWrapper(WebElement checkbox) throws InterruptedException {
        try {
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", checkbox);
            Thread.sleep(200);
            checkbox.click();
            TestRunner.getTest().log(Status.INFO, "Clicked checkbox wrapper: " + checkbox.getText());
        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "Failed to click checkbox wrapper: " + e.getMessage());
        }
    }

    public void verifyPrintByGroupOption() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into Verify Printing By Using Print By Group Option");
        Thread.sleep(1000);

        try {

            By printBtnLocator = By.xpath("//button[contains(., 'Print')]");
            WebElement printBtn = wait.until(ExpectedConditions.elementToBeClickable(printBtnLocator));

            if (printBtn.isDisplayed()) {
                ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", printBtn);
                Thread.sleep(500);
                ((JavascriptExecutor) driver).executeScript("arguments[0].click();", printBtn);
                TestRunner.getTest().log(Status.PASS, "Print button clicked successfully using JavaScript.");
            } else {
                TestRunner.getTest().log(Status.FAIL, "Print button is not visible.");
                return;
            }


            By printSingleStudentLocator = By.xpath("//div[contains(text(), 'Print By Group')]");
            driver.findElement(printSingleStudentLocator).click();
            TestRunner.getTest().log(Status.INFO, "Clicked 'Print By Group'.");

            verifyPrintOptionsModalValidationForByGroup();

        } catch (Exception e) { 
            TestRunner.getTest().log(Status.FAIL, "Exception in verifyPrint Button And Options: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public void verifyPrintOptionsModalValidationForByGroup() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into Verifying Print Options Modal Validation for BY Group ");

        try {
            // Wait for Modal
            WebElement dialog = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@role='dialog']")));
            WebElement modal = dialog.findElement(By.xpath(".//div[contains(@class, 'PrintByGroupDialogWrapper ')]"));

            // Verify Title
            WebElement titleElement = dialog.findElement(By.xpath(".//h2[contains(text(), 'Print By Group')]"));
            if (titleElement.isDisplayed()) {
                TestRunner.getTest().log(Status.PASS, "Print Options modal displayed.");
            } else {
                TestRunner.getTest().log(Status.FAIL, "Print Options modal NOT displayed.");
                return;
            }

            // Locate all Custom Checkbox Labels
            // HTML structure: <label ...><div ...><svg ...></div><span>Text</span></label>
            List<WebElement> checkboxLabels = modal.findElements(By.xpath(".//label[.//span]"));
            
            if (checkboxLabels.isEmpty()) {
                TestRunner.getTest().log(Status.FAIL, "No checkboxes found in Print By Group modal.");
                return;
            }

            WebElement nextModalBtn = driver.findElement(By.xpath("//button[normalize-space()='Next']"));

            // --- Test Case: Check FIRST checkbox ---
            TestRunner.getTest().log(Status.INFO, "Checking the first checkbox: " + checkboxLabels.get(0).getText());
            clickCheckboxWrapper(checkboxLabels.get(0));

            // Verify Button Enabled
            if (nextModalBtn.isEnabled()) {
                TestRunner.getTest().log(Status.PASS, "Next button is enabled as expected.");
            } else {
                TestRunner.getTest().log(Status.FAIL, "Next button is DISABLED but should be ENABLED.");
            }

            // Click Print 
            nextModalBtn.click();
            TestRunner.getTest().log(Status.PASS, "Clicked Print button in modal.");

            verifyPrintOptionsModalValidation();

            pressEscapeUsingRobot();
            actions.sendKeys(Keys.ESCAPE).perform();

        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "Exception in verifyPrintOptionsModalValidation: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public void pressEscapeUsingRobot() {
        try {
            Thread.sleep(1000); // 1-second delay for focus/stabilization
            Robot robot = new Robot();
            robot.keyPress(KeyEvent.VK_ESCAPE);
            robot.keyRelease(KeyEvent.VK_ESCAPE);
            TestRunner.getTest().log(Status.INFO, "Pressed ESCAPE key using Robot.");
        } catch (Exception e) {
            TestRunner.getTest().log(Status.WARNING, "Failed to press ESCAPE key using Robot: " + e.getMessage());
        }
    }


    public void verifyClickOnStandardsTab() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Validate and Click on Standards Tab On Individual Assignment Report");
        System.out.println("Validate and Click on Standards Tab On Individual Assignment Report");

        try {
            // Locator for the Standards tab based on the provided HTML structure
            By standardsTabLocator = By.xpath("//button[@role='tab' and contains(normalize-space(), 'Standards')]");

            // Wait for the element to be visible
            WebElement standardsTab = wait.until(ExpectedConditions.visibilityOfElementLocated(standardsTabLocator));

            if (standardsTab.isDisplayed()) {
                wait.until(ExpectedConditions.elementToBeClickable(standardsTab));
                standardsTab.click();

                TestRunner.getTest().log(Status.PASS, "Test Case Passed: 'Standards' tab is displayed and clicked successfully.");
                System.out.println("✅ 'Standards' tab clicked successfully.");
            } else {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: 'Standards' tab is NOT displayed.");
                System.out.println("❌ 'Standards' tab is NOT displayed.");

            }

        } catch (TimeoutException | NoSuchElementException e) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: 'Standards' tab is NOT present or NOT visible on the page.");
            System.out.println("❌ 'Standards' tab NOT found/visible: " + e.getMessage());

        }
    }

    public void verifyHeadingFromStandardsTab() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Verify Heading is Present On UI ( On Standards Tab)");
        System.out.println("Verify Heading is Present On UI ( On Standards Tab)");

        try {

            By containerLocator = By.xpath("(//div[contains(@class, 'ReportingTabsContainer')]/following-sibling::div//div[p[1] and p[2]])[1]");

            WebElement container = wait.until(ExpectedConditions.visibilityOfElementLocated(containerLocator));

            if (container.isDisplayed()) {
                String headingName = container.findElement(By.xpath("./p[1]")).getText().trim();
                String headingPercentage = container.findElement(By.xpath("./p[2]")).getText().trim();

                TestRunner.getTest().log(Status.PASS, "Test Case Passed: Heading found in Standards section: '" + headingName + "' with value: '" + headingPercentage + "'");
                System.out.println("✅ Heading found in Standards section: " + headingName + " (" + headingPercentage + ")");
            } else {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Heading container in Standards section is present but not visible.");
                System.out.println("❌ Heading container in Standards section not visible.");

            }

        } catch (TimeoutException | NoSuchElementException e) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Heading container not found following the 'Standards' tab button.");
            System.out.println("❌ Heading NOT found near Standards tab: " + e.getMessage());

        }
    }

    public void verifyCardContent() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Verify Card Content on Standards Tab");
        System.out.println("Verify Card Content on Standards Tab");

        try {
            // Wait for cards to be visible
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class, 'MuiCardContent-root')]")));

            // Find all card content containers
            List<WebElement> cards = driver.findElements(By.xpath("//div[contains(@class, 'MuiCardContent-root')]"));

            if (cards.isEmpty()) {
                TestRunner.getTest().log(Status.FAIL, "No cards found on Standards Tab.");
                System.out.println("❌ No cards found on Standards Tab.");

            }

            System.out.println("Total cards found: " + cards.size());
            TestRunner.getTest().log(Status.INFO, "Total cards found: " + cards.size());

            boolean allValid = true;

            for (int i = 0; i < cards.size(); i++) {
                WebElement card = cards.get(i);
                try {
                    // Unique logic based on the provided HTML structure
                    WebElement numberElement = card.findElement(By.xpath(".//p[contains(.,'Number:')]/span"));
                    WebElement statementElement = card.findElement(By.xpath(".//p[contains(.,'Content Statement:')]/span"));

                    String numberText = numberElement.getText().trim();
                    String statementText = statementElement.getText().trim();

                    System.out.println("Card " + (i + 1) + " details:");
                    System.out.println(" - Number: " + numberText);
                    System.out.println(" - Content Statement: " + statementText);

                    TestRunner.getTest().log(Status.INFO, "Card " + (i + 1) + " details:");
                    TestRunner.getTest().log(Status.INFO, " Number: " + numberText);
                    TestRunner.getTest().log(Status.INFO, " Content Statement: " + statementText);

                    if (numberText.isEmpty()) {
                        TestRunner.getTest().log(Status.FAIL, "Card " + (i + 1) + ": Number is missing!");
                        allValid = false;
                    }

                    if (statementText.isEmpty()) {
                        TestRunner.getTest().log(Status.FAIL, "Card " + (i + 1) + ": Content Statement is missing!");
                        allValid = false;
                    }

                    if (!numberText.isEmpty() && !statementText.isEmpty()) {
                        TestRunner.getTest().log(Status.PASS, "Card " + (i+1) + " Validated -> Number: " + numberText + " | Content Statement: " + statementText);
                    }

                } catch (NoSuchElementException e) {
                    System.out.println("❌ Card " + (i + 1) + ": Required elements not found!");
                    TestRunner.getTest().log(Status.FAIL, "Card " + (i + 1) + ": Required elements not found!");
                    allValid = false;
                }
            }

            if (allValid) {
                TestRunner.getTest().log(Status.PASS, "Test Case Passed: All cards contain valid data.");
                System.out.println("✅ Test Passed: All cards contain valid data.");
            } else {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Some card data is missing.");
                System.out.println("❌ Test Failed: Some card data is missing.");
            }

        } catch (TimeoutException e) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Cards not displayed within timeout.");
            System.out.println("❌ Test Failed: Cards not displayed.");
        }
    }

    public void verifyAccessedTimesStandardsTab() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "Check and Verify Accessed Times Standards Tab");
        System.out.println("Check and Verify Accessed Times Standards Tab");

        try {
            // Find all cards
            List<WebElement> cards = driver.findElements(By.xpath("//div[contains(@class, 'MuiCardContent-root')]"));

            if (cards.isEmpty()) {
                TestRunner.getTest().log(Status.FAIL, "No cards found to verify assessed times.");
                System.out.println("❌ No cards found.");
                return;
            }

            int cardCount = cards.size();
            System.out.println("Total cards found for modal verification: " + cardCount);
            TestRunner.getTest().log(Status.INFO, "Total cards found for modal verification: " + cardCount);

            for (int i = 0; i < cardCount; i++) {
                // Re-fetch cards because the DOM might refresh after closing modals
                List<WebElement> currentCards = driver.findElements(By.xpath("//div[contains(@class, 'MuiCardContent-root')]"));
                WebElement card = currentCards.get(i);

                WebElement assessedBtn = card.findElement(By.xpath(".//button[contains(., 'Assessed')]"));
                String btnText = assessedBtn.getText().trim();

                System.out.println("Processing Card " + (i + 1) + ": Clicking '" + btnText + "'");
                assessedBtn.click();

                // Wait for the Modal/Dialog to appear
                WebElement modal = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@role='dialog']")));

                // Validate Modal Title
                WebElement modalTitle = modal.findElement(By.xpath(".//*[@id='dialog-title' or contains(@class, 'MuiDialogTitle')]"));
                String titleText = modalTitle.getText().trim();

                // Validate Content Statement in Modal
                WebElement modalContentStatement = modal.findElement(By.xpath(".//span[@class='contentStatementDetail']"));
                String statementText = modalContentStatement.getText().trim();

                // Validate Questions Table
                List<WebElement> questionRows = modal.findElements(By.xpath(".//div[@class='questionRow']"));

                System.out.println("  Modal Title: " + titleText);
                System.out.println("  Content Statement: " + statementText);
                System.out.println("  Questions found: " + questionRows.size());

                TestRunner.getTest().log(Status.INFO, "  Modal Title: " + titleText );
                TestRunner.getTest().log(Status.INFO, "  Content Statement: " + statementText);
                TestRunner.getTest().log(Status.INFO, "  Questions found: " + questionRows.size());

                boolean modalDataValid = true;
                if (titleText.isEmpty() || statementText.isEmpty() || questionRows.isEmpty()) {
                    modalDataValid = false;
                }

                // Verify each question row has a label and status
                for (int j = 0; j < questionRows.size(); j++) {
                    WebElement row = questionRows.get(j);
                    String qLabel = row.findElement(By.xpath(".//span[@class='questionLabel']")).getText().trim();
                    String qStatus = row.findElement(By.xpath(".//span[contains(@class, 'questionStatus')]")).getText().trim();
                    
                    if (qLabel.isEmpty() || qStatus.isEmpty()) {
                        System.out.println("    ❌ Question " + (j + 1) + " data is missing: Label='" + qLabel + "', Status='" + qStatus + "'");
                        TestRunner.getTest().log(Status.PASS, "    ❌ Question " + (j + 1) + " data is missing: Label='" + qLabel + "', Status='" + qStatus + "'");
                        modalDataValid = false;
                    } else {
                        System.out.println("    ✅ Question Row " + (j + 1) + ": " + qLabel + " -> " + qStatus);
                        TestRunner.getTest().log(Status.PASS, "✅ Question Row " + (j + 1) + ": " + qLabel + " -> " + qStatus);
                    }
                }

                if (!modalDataValid) {
                    TestRunner.getTest().log(Status.FAIL, "Modal for Card " + (i + 1) + " has missing or empty data.");
                    System.out.println("  ❌ Data validation failed for this modal.");
                    Assert.fail("Modal for Card " + (i + 1) + " has missing or empty data.");
                } else {
                    TestRunner.getTest().log(Status.PASS, "Modal for Card " + (i + 1) + " validated successfully: " + titleText + " with " + questionRows.size() + " questions.");
                    System.out.println("  ✅ Modal validated.");
                }

                // Close the Modal
                WebElement closeButton = modal.findElement(By.xpath(".//*[@id='dialog-title']//button"));
                closeButton.click();

                // Wait for modal to disappear
                wait.until(ExpectedConditions.invisibilityOf(modal));
                System.out.println("  Modal for Card " + (i + 1) + " closed.");
                TestRunner.getTest().log(Status.INFO, "  Modal for Card " + (i + 1) + " closed.");
                Thread.sleep(500);
            }

            TestRunner.getTest().log(Status.PASS, "Successfully verified assessment modals for all " + cardCount + " cards.");

        } catch (Exception e) {
            TestRunner.getTest().log(Status.FAIL, "An error occurred during modal validation: " + e.getMessage());
            System.out.println("❌ Error: " + e.getMessage());
        }
    }
}
