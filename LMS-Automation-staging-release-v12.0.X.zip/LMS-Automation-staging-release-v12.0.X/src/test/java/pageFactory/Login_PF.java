package pageFactory;


import java.time.Duration;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.junit.Assert;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;



public class Login_PF {


    String threadName = "";
    WebDriverWait wait;
    String actualResult;

    public String baseUrl = Configurations.App_url;

    @FindBy(xpath = "//input[@name='email']")
    WebElement txt_email;

    @FindBy(xpath = "//input[@name='password']")
    WebElement txt_password;

    @FindBy(xpath = "//button[@name='btn-signin']")
    WebElement btn_login;

    @FindBy(id = "to-reset")
    WebElement btn_forgotPassword;

    @FindBy(xpath = "//span[normalize-space()='Logout']")
    WebElement link_Logout;

    @FindBy(xpath = "//div[contains(@class, 'rashid')]")
    WebElement avatar_TeacherLogout;

    WebDriver driver;
    Helper helper;

    public Login_PF(WebDriver driver) { //constructor
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        helper = new Helper();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
    }

    public void enterUsername(String email) throws InterruptedException {
        txt_email.click();
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].value='';", txt_email);
        txt_email.sendKeys(email);
    }

    public void enterPassword(String pass) throws InterruptedException {
        txt_password.click();
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].value='';", txt_password);
        txt_password.sendKeys(pass);
    }

    public void clickOnLogin() {
        btn_login.click();
        TestRunner.getTest().log(Status.PASS, "Test Case Passed :  Teacher Login Successfully");

    }

    public void forgotPasswordButton() {
        btn_forgotPassword.click();
    }

    public void clickOnTeacherLogout() throws InterruptedException {
        Thread.sleep(1000);
        try {
            String DashboardUrl = baseUrl + "dashboard";
            driver.get(DashboardUrl);
            verifyTeacherDashboard();
            helper.scrollToElement(driver, avatar_TeacherLogout);
            Thread.sleep(500);
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
//            WebElement btnLogout = driver.findElement(By.xpath("//div[contains(@class,'rashid') and .//img[@alt='avatar']]"));

            WebElement btnLogout = driver.findElement(By.xpath("//div[contains(@class,'rashid')]//img[@alt='avatar']"));
            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", btnLogout);

//            btnLogout.click();
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[@role='menu']")));
            Thread.sleep(1000);
            WebElement logoutSpan = driver.findElement(By.xpath("//ul[@role='menu']//li/span[contains(text(), 'power_settings_new')]"));
            logoutSpan.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed :  Teacher Logout Successfully");
//            avatar_TeacherLogout.click();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed :  Teacher not Logout");
            Assert.fail();
        }
    }

    public void clickOnStudentLogout() throws InterruptedException {
        Thread.sleep(1000);
        try {
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class, 'studentPortal-header')]")));

            WebElement headerStudentPortal = driver.findElement(By.xpath("//div[contains(@class, 'studentPortal-header')]"));
            // Use relative XPath (./) instead of absolute (//) when finding within a container
            WebElement containerTopBar = headerStudentPortal.findElement(By.xpath(".//div[contains(@class, 'TopbarContainer')]"));

            WebElement avatarStudent = containerTopBar.findElement(By.xpath(".//div[contains(@class, 'MatxMenuContent')]"));
            
            // Scroll into view and click avatar
            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript("arguments[0].scrollIntoView({behavior: 'smooth', block: 'center'});", avatarStudent);
            Thread.sleep(500);
            
            // Wait for avatar to be clickable
            wait.until(ExpectedConditions.elementToBeClickable(avatarStudent));
            avatarStudent.click();

            // Wait for menu to be visible
            WebElement menu = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[@role='menu']")));
            Thread.sleep(1000);
            
            // Try multiple strategies to find and click logout
            WebElement logoutSpan = null;
            try {
                // Strategy 1: Find by icon text
                logoutSpan = wait.until(ExpectedConditions.elementToBeClickable(
                    By.xpath("//ul[@role='menu']//li//span[contains(text(), 'power_settings_new')]")
                ));
            } catch (Exception e1) {
                try {
                    // Strategy 2: Find by "Logout" text
                    logoutSpan = wait.until(ExpectedConditions.elementToBeClickable(
                        By.xpath("//ul[@role='menu']//li//span[normalize-space()='Logout']")
                    ));
                } catch (Exception e2) {
                    // Strategy 3: Find any span containing "Logout" in parent li
                    logoutSpan = wait.until(ExpectedConditions.elementToBeClickable(
                        By.xpath("//ul[@role='menu']//li[contains(.,'Logout')]//span")
                    ));
                }
            }
            
            // Scroll logout element into view
            js.executeScript("arguments[0].scrollIntoView({behavior: 'smooth', block: 'center'});", logoutSpan);
            Thread.sleep(500);
            
            // Wait for element to be clickable
            wait.until(ExpectedConditions.elementToBeClickable(logoutSpan));
            
            // Try regular click first, then JavaScript click as fallback
            try {
                logoutSpan.click();
            } catch (ElementNotInteractableException e) {
                // Use JavaScript click if regular click fails
                js.executeScript("arguments[0].click();", logoutSpan);
            }
            
            TestRunner.getTest().log(Status.PASS, "Test Case Passed :  Student Logout Successfully");
            
        } catch (TimeoutException e) {
            Actions action = new Actions(driver);
            action.sendKeys(Keys.ESCAPE).perform();
            Thread.sleep(1000);
            try {
                link_Logout.click();
            } catch (Exception ex) {
                JavascriptExecutor js = (JavascriptExecutor) driver;
                js.executeScript("arguments[0].click();", link_Logout);
            }
            TestRunner.getTest().log(Status.PASS,"Test Case Passed :  Student Logout Successfully");
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed :  Student Logout Failed - " + e.getMessage());
            throw e; // Re-throw to allow test to fail properly
        }
    }


    //Verify Invalid Login Validations
    public void verifyInValidLogin(String expectedResult, String loginType) {
        try {
            threadName = Thread.currentThread().getStackTrace()[1].getMethodName();
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@name='erroralert']")));
            WebElement get_ActualResult = driver.findElement(By.xpath("//div[@name='erroralert']"));
            actualResult = get_ActualResult.getText();
            System.out.println(actualResult);

            if (actualResult.equals(expectedResult)) {
                Assert.assertEquals(actualResult, expectedResult);
                System.out.println("Test Case Passed    :   Login Failed " + loginType);
            } else {
                Assert.assertEquals(actualResult, expectedResult);
                System.out.println("Test Case Failed    :   Login Successfully " + loginType);
            }
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);        // print Caught Exception
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());        // print line number where the exception is through
            System.out.println("Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }


    //Verify Valid Login Validations
    public void verifyValidLogin(String expectedResult, String loginType) {
        try {
            actualResult = driver.getTitle();
            if (actualResult.equals(expectedResult)) {
                Assert.assertEquals(actualResult, expectedResult);
                TestRunner.getTest().log(Status.PASS,"Test case Passed    :   Teacher login successfully with " + loginType);
            } else {
                Assert.assertEquals(actualResult, expectedResult);
                TestRunner.getTest().log(Status.FAIL,"Test case Failed    :   Teacher login Failed with " + loginType);
            }
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    public void verifyStudentDashboard(String expectedResult, String loginType) throws InterruptedException {

        try {
            actualResult = driver.getTitle();
            if (actualResult.equals(expectedResult)) {
                Assert.assertEquals(actualResult, expectedResult);
                TestRunner.getTest().log(Status.PASS,"Test case Passed    :   Student login successfully with " + loginType);
            } else {
                Assert.assertEquals(actualResult, expectedResult);
                TestRunner.getTest().log(Status.FAIL,"Test case Failed    :   Student login Failed with " + loginType);
            }
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed    :   Exception is found");
            Assert.fail();
        }

        verifyStudentDashboardGrids();
    }

    public void verifyStudentDashboardGrids() throws InterruptedException{
        By[] elementsToWaitFor = {
                By.xpath("//div[contains(@class,'navigation')]"),
                By.xpath("//div[contains(@class,'studentPortal-header')]"),
                By.xpath("//div[contains(@class,'AssignmentWrapper')]"),
                By.xpath("//div[contains(@class,'CoursesList')]")
        };
        try {
            for (By element : elementsToWaitFor) {
                wait.until(ExpectedConditions.visibilityOfElementLocated(element));
            }
            Thread.sleep(1000);
            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
            TestRunner.getTest().log(Status.WARNING,"Test Case Failed    :   Exception is found");
            Assert.fail();
        }
    }

    private void verifyTeacherDashboard() throws InterruptedException {
        By[] elementsToWaitFor = {
//				By.xpath("//img[contains(@alt,'logo image')]"),
                By.xpath("//div[contains(@class,'navigation')]"),
                By.xpath("//div[contains(@class,'staffDashboard')]"),
                By.xpath("//div[contains(@class,'CoursesWrapper')]"),
                By.xpath("//div[contains(@class,'NeedsParentGradingWrapper')]")
        };
        try {
            for (By element : elementsToWaitFor) {
                wait.until(ExpectedConditions.visibilityOfElementLocated(element));
            }
            Thread.sleep(1000);
            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
            System.out.println("Exception is found    :   Dashboard is not shows");
            Assert.fail();
        }
    }

    public void clickOnDistrictAdminLogout() throws InterruptedException {
        Thread.sleep(1000);
        try {
            String DashboardUrl = baseUrl + "dashboard";
            driver.get(DashboardUrl);
            verifyDistrictAdminDashboard();
            helper.scrollToElement(driver, avatar_TeacherLogout);
            Thread.sleep(500);
            WebElement btnLogout = driver.findElement(By.xpath("//div[contains(@class, 'rashid')]"));
            btnLogout.click();
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[@role='menu']")));
            Thread.sleep(1000);
            WebElement logoutSpan = driver.findElement(By.xpath("//ul[@role='menu']//li/span[contains(text(), 'power_settings_new')]"));
            logoutSpan.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed :  District Admin Logout Successfully");
//            avatar_TeacherLogout.click();
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed :  District Admin not Logout");
            Assert.fail();
        }
    }

    private void verifyDistrictAdminDashboard() throws InterruptedException {
        By[] elementsToWaitFor = {
//				By.xpath("//img[contains(@alt,'logo image')]"),
                By.xpath("//div[contains(@class,'navigation')]"),
                By.xpath("//div[contains(@class,'staffDashboard')]"),
                By.xpath("//div[contains(@class,'CoursesWrapper')]"),
        };
        try {
            for (By element : elementsToWaitFor) {
                wait.until(ExpectedConditions.visibilityOfElementLocated(element));
            }
            Thread.sleep(1000);
            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
            System.out.println("Exception is found    :   District Admin Dashboard is not shows");
            Assert.fail();
        }
    }

    /**
     * Closes the browser window.
     * 
     * NOTE: This method closes only the current window. The driver will be fully
     * closed and cleaned up by the @After hook after the scenario completes.
     * 
     * This method is thread-safe and only affects the current thread's driver.
     * 
     * IMPORTANT: If this is called before the scenario ends, the @After hook will
     * still attempt to take screenshots (if scenario failed) and close the driver.
     * This method is safe to call but the actual driver cleanup is handled by @After.
     */
    public void closeBrowser() {
        try {
            TestRunner.getTest().log(Status.INFO, "Closing the browser window (driver cleanup will be handled by @After hook)");

            // Get fresh driver reference in case it changed
            WebDriver currentDriver = Configurations.getDriver();

            if (currentDriver != null) {
                try {
                    // Check if driver is still valid before attempting to close
                    // This prevents errors if driver was already closed
                    currentDriver.getWindowHandles(); // This will throw if driver is invalid
                    
                    // Get current window handles to check if there are multiple windows
                    java.util.Set<String> windowHandles = currentDriver.getWindowHandles();
                    
                    if (windowHandles.size() > 1) {
                        // Multiple windows open - close only the current window
                        currentDriver.close();
                        TestRunner.getTest().log(Status.INFO, "Closed current browser window (multiple windows were open)");
                    } else {
                        // Only one window - just log that cleanup will happen in @After
                        // Don't close here to avoid issues with screenshot capture in @After
                        TestRunner.getTest().log(Status.INFO, "Browser window will be closed by @After hook after scenario completes");
                    }
                } catch (org.openqa.selenium.WebDriverException e) {
                    // Driver is already closed or invalid
                    TestRunner.getTest().log(Status.INFO, "Browser window is already closed or invalid - cleanup will be handled by @After hook");
                    System.out.println("Driver is already closed/invalid: " + e.getMessage());
                }
            } else {
                TestRunner.getTest().log(Status.INFO, "No driver instance found - cleanup will be handled by @After hook");
            }
            
            TestRunner.getTest().log(Status.PASS, "Browser close step completed (final cleanup in @After hook)");
        } catch (Exception e) {
            // Don't throw exception - let @After handle cleanup
            // Log the error but don't fail the test
            TestRunner.getTest().log(Status.WARNING, "Browser close step encountered an issue: " + e.getMessage() + " (cleanup will be handled by @After hook)");
            System.err.println("Error in closeBrowser(): " + e.getMessage());
            // Don't rethrow - @After will handle proper cleanup
        }
    }
}
