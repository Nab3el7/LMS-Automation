package pageFactory.Dashboard;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Assignmment.CorrectAnswerExecutor_PF;
import pageFactory.Assignmment.ReleaseAssignment_PF;
import pageFactory.MyContent.AssignAssessment_PF;

import java.time.Duration;
import java.util.List;

public class SearchWithinCourse_PF {
    WebDriverWait wait;
    WebDriver driver;
    Helper helper;
    Actions actions;
    CorrectAnswerExecutor_PF correctAnswerExecutor_pf;
    ReleaseAssignment_PF releaseAssignment_pf;
    AssignAssessment_PF assignAssessment_pf;

    public  SearchWithinCourse_PF(WebDriver driver){
//        this.driver = driver;
        this.driver = Configurations.getDriver();
        helper = new Helper();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        actions = new Actions(driver);
        correctAnswerExecutor_pf = new CorrectAnswerExecutor_PF(driver);
        releaseAssignment_pf = new ReleaseAssignment_PF(driver);
        assignAssessment_pf = new AssignAssessment_PF(driver);
    }

    private String quizTitle;


    public void GetAssignmentTypeName() throws InterruptedException {

        TestRunner.getTest().log(Status.INFO,"Click On Unit, Assignment, and Get Assignment Name");
        System.out.println("Click On Unit, Assignment, and Get Assignment Name");
        Thread.sleep(2000);
//        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        List<WebElement> totalUnits = driver.findElements(By.xpath("(//div[contains(@class, 'navigation')])[2]//a"));

        String totalUnitName = null;
        for (WebElement unit : totalUnits) {
            totalUnitName = unit.getText();
            System.out.println("Unit Name: " + totalUnitName);

            if (totalUnitName.contains("Unit 1")) {
                unit.click();
                break;
            }
        }
        TestRunner.getTest().log(Status.PASS, "Test Case passed : " + totalUnitName + " Select Successfully");

        Thread.sleep(2000);
        WebElement listContentPlayer = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@id='ContentPlayerMainPanel']")));

        if (listContentPlayer.isDisplayed() && listContentPlayer.isEnabled()) {
            WebElement btnOpenForSpecificAssignment = listContentPlayer.findElement(By.xpath("(//div[contains(@class, 'MuiBox-root')]//button[contains(text(), 'Open')])[13]"));

            String nameOfItemCard= btnOpenForSpecificAssignment.getText();
            System.out.println("Name of Chapter is: " + nameOfItemCard );


            // Locate the specific card by heading text
            WebElement quizCard = driver.findElement(By.xpath(
                    "//div[contains(@class, 'css-1i6mld8')][.//div[text()[normalize-space()='Unit 1 Vocabulary Quiz']]]"
            ));

// Now safely extract details inside the card
            quizTitle = quizCard.findElement(By.xpath(".//div[contains(@class, 'ContentHeading')]")).getText();
            String topic = quizCard.findElement(By.xpath(".//span[contains(@class, 'css-1plorem')]")).getText();
            String contentType = quizCard.findElement(By.xpath(".//span[contains(@class, 'ContentType')]")).getText();
            String gradingType = quizCard.findElement(By.xpath(".//span[contains(text(),'Auto-Graded')]")).getText();


// Logging or output
            System.out.println("Title: " + quizTitle);
            TestRunner.getTest().log(Status.INFO, "Title: " + quizTitle);

            System.out.println("Unit Name:: " + topic);
            TestRunner.getTest().log(Status.INFO, "Unit Name: " + topic);

            System.out.println("Content Type: " + contentType);
            TestRunner.getTest().log(Status.INFO, "Content Type: " + contentType);

            System.out.println("Grading: " + gradingType);
            TestRunner.getTest().log(Status.INFO, "Grading: " + gradingType);

        }

    }

    public static String searchQuizInSearchBox;

    public void searchAssignmentName() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into search Assignment Name in Search Box: " + quizTitle );
        System.out.println("I'm into search Assignment Name in Search Box: " + quizTitle);

        WebElement left_panel= driver.findElement(By.xpath("//div[contains(@class,'navigation')]"));
        left_panel.isDisplayed();

        try {
            WebElement searchBox = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder='Search within course']")));
            if (searchBox.isDisplayed()) {
                searchBox.click();
                searchBox.clear();
                ((JavascriptExecutor) driver).executeScript("arguments[0].value='';", searchBox);
                System.out.println("I'm into Search Assignment Name: " + quizTitle);
                TestRunner.getTest().log(Status.INFO, "I'm into Search Assignment Name: " + quizTitle);

                searchQuizInSearchBox = quizTitle;
                System.out.println("Search Assignment Name In search Box: " + searchQuizInSearchBox);
                TestRunner.getTest().log(Status.INFO, "Search Assignment Name In search Box: " + searchQuizInSearchBox);
                searchBox.sendKeys(searchQuizInSearchBox);

                Actions actions = new Actions(driver);
                actions.sendKeys(Keys.ENTER).perform();
                TestRunner.getTest().log(Status.PASS, "Testcase Passed   : Enter Search Assignment Name Successfully");

//                waitForTableToRefresh();
            } else {
                System.out.println("Search box is not displayed.");
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed   : Search box is not displayed");
//                throw new RuntimeException("Search Box not  Found.");
            }
        } catch (Exception e) {
            System.out.println("Search box is not available: " + e.getMessage());
        }

    }

    public void getAssignmentNameFromPanelAndPerformClick() throws InterruptedException {
        System.out.println("I'm Into Get Assignment name from Left Panel and click on that Assignment");
        TestRunner.getTest().log(Status.INFO, "I'm Into Get Assignment name from Left Panel and Click on that Assignment");
        Thread.sleep(2000);

        WebElement assignmentLink = driver.findElement(By.xpath(
                "//div[contains(@class,'expansion-panel submenu')]//a"
        ));

        WebElement assignmentLinkName = driver.findElement(By.xpath(
                "(//div[contains(@class,'expansion-panel submenu')]//a//.//span[contains(@class,'sidenavHoverShow ')])[2]"
        ));

        String assignmentName = assignmentLink.findElement(By.xpath(
                "(//div[contains(@class,'expansion-panel submenu')]//a//.//span[contains(@class,'sidenavHoverShow ')])[2]"
        )).getText().trim();

        System.out.println("Assignment Name: " + assignmentName);

        TestRunner.getTest().log(Status.INFO, "Assignment Name From Left Panel is : " + assignmentName);


        if (assignmentName.equalsIgnoreCase(searchQuizInSearchBox)){
            TestRunner.getTest().log(Status.PASS, "Test Case Passed : Unit Assignment Name Match: " +  assignmentName + " with: " + searchQuizInSearchBox );

            Thread.sleep(1000);
            assignmentLinkName.click();

        }else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : Unit Assignment Name Not Match: " +  assignmentName + " with: " + searchQuizInSearchBox );
        }


    }

    public void verifyAssignButton() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into verify and click on Assign Button");
        System.out.println("I'm into verify and click on Assign Button");

        WebElement assign_btn= driver.findElement(By.xpath("//button[normalize-space()='Assign']"));

        if (assign_btn.isDisplayed() && assign_btn.isEnabled()){
            assign_btn.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed : Assign Button Displayed/Enabled and click successfully");
        }else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Assign Button is Not Displayed/Enabled");
        }
    }

    public void assignAssignment() throws InterruptedException {
     TestRunner.getTest().log(Status.INFO, "I'm Into Assign Assignment");
     System.out.println("I'm into Assign Assignment ");

        WebElement dialogAssignment = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@role='dialog']")));
        if (dialogAssignment.isDisplayed()) {
            releaseAssignment_pf.validateAssignmentDialogData();
            correctAnswerExecutor_pf.EnterAssignmentTitleForCorrectAnswers();
            correctAnswerExecutor_pf.selectSpecificClasses();
            assignAssessment_pf.setDateTimeAndCategory();
            assignAssessment_pf.enterAdditionalSettings();
//                assignAssessment_pf.enterWeightPercentage();
            releaseAssignment_pf.AdvancedGradingOptions();
            assignAssessment_pf.assignAssignment();
            assignAssessment_pf.verifyDialogBox();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed : Specific Assignment Type ET Released Successfully");
        }

    }
}
