package pageFactory.Dashboard;

import StepDefinitions.Configurations;
import StepDefinitions.Helper;
import StepDefinitions.TestRunner;
import com.aventstack.extentreports.Status;
import org.junit.Assert;
import org.junit.Test;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageFactory.Assignmment.CorrectAnswerExecutor_PF;
import pageFactory.Assignmment.InCorrectAnswerExecutor_PF;
import pageFactory.Assignmment.ReleaseAssignment_PF;
import pageFactory.MyContent.AssignAssessment_PF;

import java.awt.*;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import static org.openqa.selenium.By.tagName;
import static pageFactory.Assignmment.CorrectAnswerExecutor_PF.assignmentNameForCorrect;
import static pageFactory.Gradebook.AssignmentVerification_PF.specificClasses;


public class TeacherDashboard_PF {
    WebDriverWait wait;
    WebDriver driver;
    Helper helper;
    JavascriptExecutor js;
    TeacherDashboard_PF teacherdashboard;
    TeacherDashboard_PF teacherDashboardPf;
    Actions actions;
    public static String specificClass = "FL Grade 5";
    @FindBy(xpath = "//div[contains(@class, 'CoursesWrapper')]")
    WebElement card_MyCourse;

    CorrectAnswerExecutor_PF correctAnswerExecutor_pf;

    AssignAssessment_PF assignAssessment_pf;
    ReleaseAssignment_PF releaseAssignment_pf;

    public static String ClickspecificClasses = "FL Grade 5";
    public TeacherDashboard_PF(WebDriver driver) {
        this.driver = Configurations.getDriver();
        helper = new Helper();
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        js = (JavascriptExecutor) driver;
//        teacherdashboard= new TeacherDashboard_PF(driver);
//        teacherDashboardPf = new TeacherDashboard_PF(driver);
        actions = new Actions(driver);
        correctAnswerExecutor_pf = new CorrectAnswerExecutor_PF(driver);
        assignAssessment_pf= new AssignAssessment_PF(driver);
        releaseAssignment_pf = new ReleaseAssignment_PF(driver);

    }
    @FindBy(xpath = "//div[contains(@class,'select-class')]")
    WebElement Click_allclasses;
    @FindBy(xpath = "//div[contains(@class,'CourseContainer')]")
    WebElement list_MyCourses;
    @FindBy(xpath = "//div[contains(@class, 'NeedsGradingWrapper')]")
    WebElement needgrading_Wight;
//    @FindBy(xpath = "(//div[contains(@class, 'bottomNavigationWraper')])[1]")
//    WebElement Nevigation_bar;
    @FindBy(xpath = "(.//div[@class='ScrollbarsCustom trackYVisible'])[3]")
        WebElement needgrading_Assignments;

    @FindBy(xpath = ".//div[contains(@class,'usageStatisticsTable-wrapper')]")
    WebElement Usage_Count;
    @FindBy(xpath = "(//div[contains(@class, 'UsageStatisticsWrapper')])[1]")
            WebElement usagestatistics;
    @FindBy(xpath = "//div[contains(@class,'StudentPerformanceWrapper')]")
            WebElement student_performance;
    @FindBy(xpath = "(.//div[@class='ScrollbarsCustom-Content'])[4]")
            WebElement Performence_percentage;
    @FindBy(xpath = "//div[contains(@class, 'StudentsWrapper')]")
            WebElement mystudent;
    @FindBy(xpath = "(.//div[@class='ScrollbarsCustom-Content'])[5]")
            WebElement mystudent_List;
    @FindBy(xpath = ".//button[contains(text(),'Name')]")
            WebElement btn_stdname;
    @FindBy(xpath = "(//div[contains(@class, 'calender-widget-calender-automation')])[2]")
            WebElement calandermodule;
//    @FindBy(xpath = "(//div[contains(@class, 'calender-widget-calender')])[3]")
//            WebElement CalanderDate;
    String Nevigation_bar = "(//div[contains(@class, 'bottomNavigationWraper')])[1]";
    String Usage_bar ="(//div[contains(@class,'bottomNavigationWraper')])[2]";
    String CalanderDate="(//div[contains(@class, 'calender-widget-calender')])[3]";
    String Student_bar ="//div[contains(@class,'data-grid myStudents-StudentList')]";

    public void verifyTeacherdashboard() throws InterruptedException {
        By[] elementsToWaitFor = {
//				By.xpath("//img[contains(@alt,'logo image')]"),
                By.xpath("//div[contains(@class,'navigation')]"),
                By.xpath("//div[contains(@class,'staffDashboard')]"),
                By.xpath("//div[contains(@class,'CoursesWrapper')]"),
                By.xpath("//div[contains(@class,'NeedsParentGradingWrapper')]"),
                By.xpath("//div[contains(@class,'StudentPerformanceWrapper')]"),
                By.xpath("//div[contains(@class,'StudentsWrapper')]"),
//                By.xpath("(//div[contains(@class,'RecentActivitiesWrapper')])[3]"),
                By.xpath("//div[contains(@class,'UsageStatisticsWrapperTop')]"),
        };
        try {
            for (By element : elementsToWaitFor) {
                wait.until(ExpectedConditions.visibilityOfElementLocated(element));
            }
            Thread.sleep(1000);
            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
        } catch (NoSuchElementException | ElementNotInteractableException e) {
            System.out.println(e);
            System.out.println("Exception line number : " + Thread.currentThread().getStackTrace()[1].getLineNumber());
            helper.takeScreenshot(driver, Thread.currentThread().getStackTrace()[1].getMethodName());
            System.out.println("Exception is found    :   Dashboard is not shows");
            Assert.fail();
        }
    }
    public void selectAllClassAndCourse() throws InterruptedException {
        int maxRetries = 5; // Maximum number of retry attempts
        int attemptCount = 0;
        
        while (attemptCount < maxRetries) {
            attemptCount++;
            System.out.println("Attempt " + attemptCount + " of " + maxRetries);
            
            SelectClass();
            
            // Wait a bit for the page to load after selecting class
            Thread.sleep(2000);
            
            if (CoursesFound()) {
                SelectCourse();
                break;
            } else {
                System.out.println("No courses found. Trying again...");
                if (attemptCount >= maxRetries) {
                    System.out.println("Maximum retry attempts reached. No courses found after " + maxRetries + " attempts.");
                    TestRunner.getTest().log(Status.FAIL, "Failed to find courses after " + maxRetries + " attempts");
                }
            }
        }
    }

    public boolean CoursesFound() {
        try {
            wait.until(ExpectedConditions.visibilityOf(list_MyCourses));
            WebElement courseContainer = list_MyCourses;
            // Use the same XPath as SelectCourse() to check for courses
            List<WebElement> courseLinks = courseContainer.findElements(By.xpath(".//div[contains(@class, 'CourseRoot')]"));
            boolean found = !courseLinks.isEmpty();
            System.out.println("Courses found: " + found + " (Count: " + courseLinks.size() + ")");
            return found;
        } catch (Exception e) {
            System.out.println("Error checking for courses: " + e.getMessage());
            return false;
        }
    }

    public void SelectClass() throws InterruptedException {
        Click_allclasses.click();
        Thread.sleep(1000);
        List<WebElement> SchoolStatusOptions = Click_allclasses.findElements(By.xpath("//ul[@role='listbox']"));
        helper.selectValueFromDropdown(SchoolStatusOptions);
    }

    public void SelectCourse() {
        TestRunner.getTest().log(Status.INFO, "I am in to select Course ");
        wait.until(ExpectedConditions.visibilityOf(list_MyCourses));

        WebElement courseContainer = list_MyCourses;
        List<WebElement> courseLinks = courseContainer.findElements(By.xpath(".//div[contains(@class, 'CourseRoot')]"));

        for (WebElement courseLink : courseLinks) {
            System.out.println("Course Name: " + courseLink.getText());
        }

        if (!courseLinks.isEmpty()) {
            WebElement firstCourse = courseLinks.get(0);
//            WebElement firstCourse = courseLinks.get(1);
            System.out.println("Selected Course: " + firstCourse.getText());
            firstCourse.click();
            TestRunner.getTest().log(Status.PASS, "Test Case Passed : Course Select Successfully");
        } else {
            System.out.println("No courses found");
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed : No courses found");
            throw new RuntimeException("No Course Found.");
        }

    }

    @FindBy(xpath = "//div[@aria-label='User Dashboard']")
    WebElement link_Dashboard;

    public void goToDashboardAgain() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm into Again Going Back to Dashboard");
        System.out.println("I'm into Again Going Back to Dashboard");

        Thread.sleep(2000);


        WebElement navBar = driver.findElement(By.xpath("//div[@class='navigation']"));

        List<WebElement> totalLinks = navBar.findElements(By.tagName("a"));

        for (WebElement link : totalLinks) {
            String hrefValue = link.getAttribute("href");
            System.out.println("Link is: " + hrefValue);

            if (hrefValue.contains("/dashboard")) {
                link.click();
                TestRunner.getTest().log(Status.PASS, "Testcase Passed   :  Side navbar shows and clicked on GradeBook");
                break; // Break the loop after finding and clicking the GradeBook link

            }
        }
    }

    public void ShowAllClasses() {
        TestRunner.getTest().log(Status.INFO, "Selecting a random class from the dropdown");

        Click_allclasses.click(); // Click to open the dropdown

        // Click to open the dropdown
        WebElement listClasses = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[@role='listbox']")));
        List<WebElement> optionsClasses = listClasses.findElements(By.xpath(".//li"));

        int classCount = optionsClasses.size();
        System.out.println("Classes List size: " + classCount);
        TestRunner.getTest().log(Status.INFO, "Number of classes available: " + classCount);

        if (classCount == 0) {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: No options found in the Classes dropdown");
            System.out.println("No options found in the Classes dropdown.");
            throw new RuntimeException("No Classes found in dropdown");

        } else {
            System.out.println("Classes available:");
            boolean classFound = false;

            for (WebElement option : optionsClasses) {
                String className = option.getText();
                System.out.println(className);

                if (className.equals(ClickspecificClasses)) {
                    option.click();  // Select the class by clicking on it
                    System.out.println("Selected Class: " + ClickspecificClasses);
                    TestRunner.getTest().log(Status.INFO, "Selected Class: " + ClickspecificClasses);
                    TestRunner.getTest().log(Status.PASS, "Test Case Passed: Class selected successfully");
                    classFound = true;
                    break;
                }
            }

            if (!classFound) {
                TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Specific class not found in the Classes dropdown");
                throw new RuntimeException("Specific class not found in dropdown: " + ClickspecificClasses);
            }
        }

    }
    public void SelectCalanderdate() throws InterruptedException{
        calandermodule.isDisplayed();
        WebElement CalanderWight = calandermodule.findElement(By.xpath(CalanderDate));
        TestRunner.getTest().log(Status.PASS,"Test Case Passed : Calander grid Shows Successfully");
        CalanderWight.click();

        List<WebElement> CoruseList = CalanderWight.findElements(By.xpath("(//div[contains(@class, 'CalenderContainer')])[18]"));
        TestRunner.getTest().log(Status.INFO,"Total Course List:: "+CoruseList.size());

    }
    public void selectNeedGrading() throws InterruptedException{
        needgrading_Wight.isDisplayed();
        WebElement NevigationWight = needgrading_Wight.findElement(By.xpath(Nevigation_bar));
        TestRunner.getTest().log(Status.PASS, "Test Case Passed : My Assignment grid shows successfully");
        NevigationWight.click();

        List<WebElement> AssignmentTabs = NevigationWight.findElements(By.xpath(".//button"));
        TestRunner.getTest().log(Status.INFO, "Total assignment tabs is : "+ AssignmentTabs.size());

        for (WebElement AssignmentTab : AssignmentTabs) {
            String tabText = AssignmentTab.getText();
            TestRunner.getTest().log(Status.INFO, "Assignment tab(s) name is: " +tabText);
            AssignmentTab.click();
            Thread.sleep(1000);
        }

        WebElement DueTab = NevigationWight.findElement(By.xpath(".//span[contains(text(), 'All Due')]"));
        System.out.println("Click on Open tab " + DueTab.getText());
        TestRunner.getTest().log(Status.PASS, "Test Case Passed : Open tab is selected successfully");
        DueTab.click();
        Thread.sleep(1000);
    }
    public void selectAssignmentIntoNeedGrading() throws InterruptedException, AWTException {
        if (needgrading_Assignments.isDisplayed()) {
            List<WebElement> tabPanels = needgrading_Assignments.findElements(By.xpath(".//div[@class='AssignmentRoot-container MuiBox-root css-1amd0p9']"));

            int totalAssignments = tabPanels.size();
            System.out.println("Total Assignments: " + totalAssignments);

            for (WebElement tabPanel : tabPanels) {
                processEditAssignmentPanel(tabPanel);
            }
        }
    }
    private void processEditAssignmentPanel(WebElement tabPanel) throws InterruptedException, AWTException {
//        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(.//div[@class='ScrollbarsCustom trackYVisible'])[3]")));
//        Thread.sleep(2000);
        String panelText = tabPanel.getText();
        System.out.println("Panel Text: " + panelText);

        String[] AssignmentInfo = panelText.split("\\n");

        for (String info : AssignmentInfo) {
            if (info.contains("INFO:") || info.contains("Start:") || info.contains("Due:")) {
                TestRunner.getTest().log(Status.INFO, "Open Assignments are: ");
                TestRunner.getTest().log(Status.INFO,  info.trim());
            }
        }

        try {
            WebElement btn_Edit = tabPanel.findElement(By.xpath("(.//span[@aria-label='upload picture'])[1]"));
//            WebElement btn_Start = tabPanel.findElement(By.xpath("(//div[@statustype='RESUME'])[3]"));
            btn_Edit.click();
            Thread.sleep(3000);

        } catch (NoSuchElementException e) {
            return;
        }
        refreshPage();
        Thread.sleep(3000);
//        dialogBox_ImpAnnouncement();

//        tabPanel = driver.findElement(By.xpath(".//div[@class='AssignmentRoot-container MuiBox-root css-1amd0p9']"));

//        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[@class='ScrollbarsCustom-Content'])[3]")));

        processEditAssignmentPanel(tabPanel);
    }

    private void refreshPage() {
        driver.navigate().refresh();
    }

    public void selectUsageStatistics() throws InterruptedException{

        usagestatistics.isDisplayed();
        WebElement NevigationWight = usagestatistics.findElement(By.xpath(Usage_bar));
        TestRunner.getTest().log(Status.PASS, "Test Case Passed : Usage Statistics shows successfully");
        NevigationWight.click();

        List<WebElement> AssignmentTabs = NevigationWight.findElements(By.xpath(".//button"));
        TestRunner.getTest().log(Status.INFO, "Total UsageStatistics is : "+ AssignmentTabs.size());

        for (WebElement AssignmentTab : AssignmentTabs) {
            String tabText = AssignmentTab.getText();
            TestRunner.getTest().log(Status.INFO, "UsageStatistics(s) name is: " +tabText);
            AssignmentTab.click();
            Thread.sleep(2000);

            WebElement usageContent = driver.findElement(By.cssSelector(".usageStatistics-container.flex"));
            String contentText = usageContent.getText().trim();

            TestRunner.getTest().log(Status.INFO, "Content for tab '" + tabText + "':\n" + contentText);

            Thread.sleep(2000);
        }

        WebElement TodayTab = driver.findElement(By.xpath("(.//span[contains(text(),'This Week')])[2]"));
        System.out.println("Click on This Week tab " + TodayTab.getText());
        TestRunner.getTest().log(Status.PASS, "Test Case Passed : This Week tab is selected successfully");
        TodayTab.click();
        Thread.sleep(1000);
    }


    public void selectUsage_Statistics_Count() throws InterruptedException, AWTException {
        helper.scrollToElement(driver, Usage_Count);

        if (Usage_Count.isDisplayed()) {
            List<WebElement> tabPanels = Usage_Count.findElements(By.xpath(".//div[contains(@class,'usageStatistics-container flex')]"));

            int totalUsage = tabPanels.size();
            System.out.println("Total Usage Panels Found: " + totalUsage);
            TestRunner.getTest().log(Status.INFO, "Total Usage Panels: " + totalUsage);

            for (WebElement tabPanel : tabPanels) {
                processUsagePanel(tabPanel);

                TestRunner.getTest().log(Status.PASS, " Test Case Passed : Usage Panel Found successfully");
            }
        } else {
            TestRunner.getTest().log(Status.WARNING, "Usage Count section is not visible.");
        }
    }

    private void processUsagePanel(WebElement usagePanel) throws InterruptedException, AWTException {
        String panelText = usagePanel.getText();
        System.out.println("Panel Text:\n" + panelText);
        TestRunner.getTest().log(Status.INFO, "Panel Text:\n" + panelText);

        String[] assignmentInfo = panelText.split("\\n");

        boolean hasInfo = false;
        for (String info : assignmentInfo) {
            if (info.contains("INFO:") || info.contains("Start:") || info.contains("Due:")) {
                if (!hasInfo) {
                    TestRunner.getTest().log(Status.INFO, "Usage Info:");
                    hasInfo = true;
                }
                TestRunner.getTest().log(Status.INFO, info.trim());
            }
        }

        try {
            WebElement btnUsage = usagePanel.findElement(By.xpath(".//button[@id='UserLoginsTable']"));
            btnUsage.click();
            Thread.sleep(3000);


            WebElement userLoginSummary= driver.findElement(By.xpath("//div[@class='UserLoginsTable-wrapper']"));

            String loginSummary= userLoginSummary.getText();

            TestRunner.getTest().log(Status.INFO, "User Login Summary: " + loginSummary);
            System.out.println("User Login Summary: " + loginSummary);


        } catch (NoSuchElementException e) {
            TestRunner.getTest().log(Status.INFO, "No 'UserLoginsTable' button found in this panel.");
            return;
        }

        Thread.sleep(3000);

    }



//    public void selectUsage_Statistics_Count() throws InterruptedException, AWTException {
//
//        helper.scrollToElement(driver, Usage_Count);
//
//        if (Usage_Count.isDisplayed()) {
//            List<WebElement> tabPanels = Usage_Count.findElements(By.xpath(".//div[contains(@class,'usageStatistics-container flex')]"));
//
//            int totalusage = tabPanels.size();
//            System.out.println("Total Usage: " + totalusage);
//
//            for (WebElement tabPanel : tabPanels) {
//                processUsagePanel(tabPanel);
//            }
//        }
//    }
//
//    private void processUsagePanel (WebElement usagePanel) throws InterruptedException, AWTException {
//
//        String panelText = usagePanel.getText();
//        System.out.println("Panel Text: " + panelText);
//
//        String[] AssignmentInfo = panelText.split("\\n");
//
//        for (String info : AssignmentInfo) {
//            if (info.contains("INFO:") || info.contains("Start:") || info.contains("Due:")) {
//                TestRunner.getTest().log(Status.INFO, " Usage are: ");
//                TestRunner.getTest().log(Status.INFO,  info.trim());
//            }
//        }
//
//        try {
//            WebElement btn_Usage = usagePanel.findElement(By.xpath(".//button[@id='UserLoginsTable']"));
//            btn_Usage.click();
//            Thread.sleep(3000);
//
//        } catch (NoSuchElementException e) {
//            return;
//        }
////        refreshPage();
//        Thread.sleep(3000);
////        dialogBox_ImpAnnouncement();
//
////        tabPanel = driver.findElement(By.xpath(".//div[@class='AssignmentRoot-container MuiBox-root css-1amd0p9']"));
//
////        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[@class='ScrollbarsCustom-Content'])[3]")));
//
//        processUsagePanel(usagePanel);
//    }
    public void selectAllClassAndStudentPerformance() throws InterruptedException{

        TestRunner.getTest().log(Status.INFO, "I'm Into Verify Student Performance");
        System.out.println("I'm Into verify Student Performance");

        while (true) {
            CheckPerformanceClass();

            if (PerformanceFound()) {
                selectStudent_Performance();
                break;
            } else {
                System.out.println("No Performance found. Trying again...");
            }
        }
    }
    public void CheckPerformanceClass() throws InterruptedException {
        Click_allclasses.click();
        Thread.sleep(1000);
        List<WebElement> SchoolStatusOptions = Click_allclasses.findElements(By.xpath("//ul[@role='listbox']"));
        helper.selectValueFromDropdown(SchoolStatusOptions);

    }

    public boolean PerformanceFound() {
//        wait.until(ExpectedConditions.visibilityOf(Performence_percentage));
        WebElement PercentageContainer = Performence_percentage;
        List<WebElement> Percentage = PercentageContainer.findElements(By.xpath(".//div[contains(@class,'inner-wrapper')]"));
        return !Percentage.isEmpty();
    }

    public void selectStudent_Performance() throws InterruptedException {
        if (student_performance.isDisplayed()) {
            List<WebElement> tabPercentage = student_performance.findElements(By.xpath(".//div[contains(@class,'inner-wrapper')]"));

// Now you can use this list
            for (WebElement tab : tabPercentage) {
                System.out.println(tab.getText());
                TestRunner.getTest().log(Status.INFO, "Student Performance is:  " + tab.getText());
            }


            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Student Performance found successfully");

        }else {

            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Student Performance Not found");

        }
    }

    public void selectMyStudent() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm Into verify My Students Widget On Dashboard");
        System.out.println("I'm Into verify My Students Widget On Dashboard");

        if (mystudent.isDisplayed()) {

            WebElement NevigationWight = mystudent.findElement(By.xpath(Student_bar));
            TestRunner.getTest().log(Status.PASS, "Test Case Passed : My Student grid shows successfully");
            NevigationWight.click();

            List<WebElement> AssignmentTabs = NevigationWight.findElements(By.xpath(".//button"));
            TestRunner.getTest().log(Status.INFO, "Total My Student tabs is : " + AssignmentTabs.size());

            for (WebElement AssignmentTab : AssignmentTabs) {
                String tabText = AssignmentTab.getText();
                TestRunner.getTest().log(Status.INFO, "Student tab(s) Names are: " + tabText);
                AssignmentTab.click();
                Thread.sleep(1000);


                List<WebElement> studentCards = driver.findElements(By.cssSelector(".student-data"));

                for (WebElement student : studentCards) {
                    try {
                        String lastName = student.findElement(By.cssSelector(".lastName")).getText().trim();
                        String lastLogin = student.findElement(By.cssSelector(".lastLogin")).getText().trim();
                        String percentage = student.findElement(By.cssSelector("div[value] > span")).getText().trim();

                        TestRunner.getTest().log(Status.INFO, "Student: " + lastName +
                                " | Last Login: " + lastLogin + " | Percentage: " + percentage);

                    } catch (NoSuchElementException e) {
                        TestRunner.getTest().log(Status.WARNING, "Incomplete student data, skipping...");
                    }
                }

                TestRunner.getTest().log(Status.PASS,"Test Case Passed: Student Names Display in My Students Widget");

//            WebElement student_name = NevigationWight.findElement(By.xpath(".//button[contains(text(),'Name')]"));
//            System.out.println("Click on Open tab " + student_name.getText());
//            TestRunner.getTest().log(Status.PASS, "Test Case Passed : Open tab is selected successfully");
//            student_name.click();
//            Thread.sleep(1000);
            }
        }else {
            TestRunner.getTest().log(Status.FAIL,"Test Case Failed: Student Names Not Display in My Students Widget");
        }
    }
    public void selectMyStudentList() throws InterruptedException, AWTException {
        if (mystudent_List.isDisplayed()) {
            List<WebElement> tabPanels = mystudent_List.findElements(By.xpath("(.//div[@class='ScrollbarsCustom trackYVisible'])[4]"));

            int totalAssignments = tabPanels.size();
            System.out.println("Total Student: " + totalAssignments);

        }
        btn_stdname.click();
        mystudent_List.findElements(By.xpath("(.//div[@class='ScrollbarsCustom trackYVisible'])[4]"));
    }


    public void verifyViewAllButtonStudentsWidget() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm Into Verify View All Button on My Students Widget");
        System.out.println("I'm into Verify View All Button on My Students Widget");

        WebElement viewAllBtn= driver.findElement(By.xpath("(//div[contains(@class,'MuiBox-root')]//button[@type='button'][normalize-space()='View All'])[2]"));

        if (viewAllBtn.isDisplayed() && viewAllBtn.isEnabled()){
            viewAllBtn.click();
            TestRunner.getTest().log(Status.PASS, "View All Button is Displayed/Enabled and Click Successfully");

            TestRunner.getTest().log(Status.INFO, "I'm Into Verify that View All Redirect to Students Dashboard");
            System.out.println("I'm Into Verify that View All Redirect to Students Dashboard");

            validateBreadcrumb("Home / students");

        }
    }

    public void validateBreadcrumb(String expectedBreadcrumb) {
        WebElement breadcrumbContainer = driver.findElement(By.cssSelector("ol.MuiBreadcrumbs-ol"));

        List<WebElement> breadcrumbItems = breadcrumbContainer.findElements(By.tagName("li"));
        StringBuilder actualBreadcrumb = new StringBuilder();

        for (WebElement item : breadcrumbItems) {
            String text = item.getText().trim();
            if (!text.equals("/")) { // Skip separators
                if (actualBreadcrumb.length() > 0) {
                    actualBreadcrumb.append(" / ");
                }
                actualBreadcrumb.append(text);
            }
        }

        String actualBreadcrumbText = actualBreadcrumb.toString();
        System.out.println("Actual Breadcrumb: " + actualBreadcrumbText);

        if (actualBreadcrumbText.equalsIgnoreCase(expectedBreadcrumb)) {
            TestRunner.getTest().log(Status.PASS, "Test Case Passed: Breadcrumb matched: " + actualBreadcrumbText);
        } else {
            TestRunner.getTest().log(Status.FAIL, "Test Case Failed: Breadcrumb mismatch. Expected: " + expectedBreadcrumb + " but found: " + actualBreadcrumbText);
        }
    }


    public void getRecentActivities() throws InterruptedException{

        TestRunner.getTest().log(Status.INFO, "I'm Into Validate Recent Activity");

        WebElement recentActivity= driver.findElement(By.xpath("(//div[contains(@class,'MuiBox-root')]//div[@class='title'][normalize-space()='Recent Activity'])[2]"));

        helper.scrollToElement(driver, recentActivity);
        Thread.sleep(500);

        // Try multiple ways to get the text
        String latest_text = recentActivity.getText().trim();
        if (latest_text.isEmpty()) {
            latest_text = recentActivity.getAttribute("textContent");
            if (latest_text != null) {
                latest_text = latest_text.trim();
            }
        }
        if (latest_text == null || latest_text.isEmpty()) {
            latest_text = recentActivity.getAttribute("innerText");
            if (latest_text != null) {
                latest_text = latest_text.trim();
            }
        }
        
        System.out.println("Heading of Tab is: " + latest_text);
        TestRunner.getTest().log(Status.INFO, "Heading of Tab is: " + latest_text);
        Thread.sleep(2000);

        // Wait for activity container to be present
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class='data-container RecentActivities']")));
        
        // Find all activity containers - direct children divs of data-container that contain anchor with h4 and have a span sibling
        List<WebElement> activityContainers = driver.findElements(
                By.xpath("//div[@class='data-container RecentActivities']/div[.//a[.//h4] and ./span]")
        );

        System.out.println("Total activity containers found: " + activityContainers.size());

        for (WebElement activity : activityContainers) {
            try {
                // Find h4 element for title (inside the anchor tag)
                WebElement titleElement = activity.findElement(By.xpath(".//h4"));
                
                // Find span for time - direct child span that doesn't contain anchor (sibling of the div containing anchor)
                WebElement timeElement = activity.findElement(By.xpath("./span[not(.//a)]"));

                // Try multiple ways to get text
                String titleText = titleElement.getText().trim();
                if (titleText.isEmpty()) {
                    titleText = titleElement.getAttribute("textContent");
                    if (titleText != null) {
                        titleText = titleText.trim();
                    }
                }
                
                String timeText = timeElement.getText().trim();
                if (timeText.isEmpty()) {
                    timeText = timeElement.getAttribute("textContent");
                    if (timeText != null) {
                        timeText = timeText.trim();
                    }
                }

                System.out.println("Debug - Title element found: " + (titleElement != null) + ", Time element found: " + (timeElement != null));
                System.out.println("Debug - Title text: '" + titleText + "', Time text: '" + timeText + "'");

                // Only log activities that have both title and time with actual content
                if (titleText != null && !titleText.isEmpty() && timeText != null && !timeText.isEmpty()) {
                    System.out.println("Activity: " + titleText + " | Time: " + timeText);
                    TestRunner.getTest().log(Status.INFO, "Recent Activity: " + titleText + " at " + timeText);
                    TestRunner.getTest().log(Status.PASS, "Recent Activity Data Found Successfully");
                } else {
                    System.out.println("Skipping empty activity (Title: '" + titleText + "', Time: '" + timeText + "')");
                }
            } catch (NoSuchElementException e) {
                System.out.println("Skipping activity - required elements not found: " + e.getMessage());
                TestRunner.getTest().log(Status.WARNING, "Recent Activity element not found: " + e.getMessage());
            }
        }
    }

    public void ViewAllRecentActivity() throws InterruptedException {

        TestRunner.getTest().log(Status.INFO, "I'm Into Click on View All on Recent Activity");

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));

        try {
            // First, locate the Recent Activity widget/container
            WebElement recentActivityWidget = wait.until(ExpectedConditions.presenceOfElementLocated(
                    By.xpath("//div[contains(@class,'RecentActivitiesWrapper')] | //div[contains(@class,'RecentActivities')]")
            ));

            // Scroll the widget into view first
            helper.scrollToElement(driver, recentActivityWidget);
            Thread.sleep(1000);

            // Find View All button within the Recent Activity widget
            WebElement viewAllBtnRecentActivity = null;
            
            // Try multiple XPath strategies
            try {
                // Strategy 1: Find button within Recent Activity widget
                viewAllBtnRecentActivity = recentActivityWidget.findElement(
                        By.xpath(".//button[@type='button'][normalize-space()='View All']")
                );
            } catch (NoSuchElementException e1) {
                try {
                    // Strategy 2: Find button that follows the data-container RecentActivities
                    viewAllBtnRecentActivity = wait.until(ExpectedConditions.presenceOfElementLocated(
                            By.xpath("//div[@class='data-container RecentActivities']/following-sibling::button[normalize-space()='View All']")
                    ));
                } catch (Exception e2) {
                    // Strategy 3: Find button within Recent Activity accordion
                    viewAllBtnRecentActivity = wait.until(ExpectedConditions.presenceOfElementLocated(
                            By.xpath("//div[contains(@class,'RecentActivities')]//button[normalize-space()='View All']")
                    ));
                }
            }

            // Scroll button into view
            helper.scrollToElement(driver, viewAllBtnRecentActivity);
            Thread.sleep(500);

            // Wait until clickable
            wait.until(ExpectedConditions.elementToBeClickable(viewAllBtnRecentActivity));

            // Click safely using Javascript
            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", viewAllBtnRecentActivity);
            TestRunner.getTest().log(Status.PASS, "View All Button is Displayed/Enabled and Clicked Successfully");
            
            Thread.sleep(2000); // Wait for navigation

        } catch (Exception ex) {
            System.out.println("Failed to click View All Button in Recent Activity: " + ex.getMessage());
            TestRunner.getTest().log(Status.FAIL, "Failed to click View All Button in Recent Activity: " + ex.getMessage());
        }

        TestRunner.getTest().log(Status.INFO, "I'm Into Verify that View All Redirect to User Accounts Usage Dashboard");
        System.out.println("I'm Into Verify that View All Redirect to User Accounts Usage Dashboard");

        validateBreadcrumb("Home / staff / usage");
    }



    public void getAccountUsageInformation() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm Into Get Account Usage Information");
        System.out.println("I'm Into Get Account Usage Information");

        WebElement AccountsUsageFor= driver.findElement(By.xpath("//div[contains(@class,'child1')]//div[@class='user-name-container']"));

        String userNameAccount= AccountsUsageFor.getText();

        System.out.println("Account Usage Information: " + userNameAccount);
        TestRunner.getTest().log(Status.INFO, "Account Usage Information: " + userNameAccount);

        WebElement roleName= driver.findElement(By.xpath("//div[contains(@class,'child1')]//div[@class='header2child2']"));

        String role= roleName.getText();

        System.out.println("Role: " + role);
        TestRunner.getTest().log(Status.INFO, "Role: " + role);

        WebElement usageData= driver.findElement(By.xpath("//div[contains(@class,'child1')]//div[contains(text(), 'Usage data is as of')]"));

        String dataUsage= usageData.getText();

        System.out.println("Usage Data: " + dataUsage);
        TestRunner.getTest().log(Status.INFO, "Usage Data: " + dataUsage);

    }

    public void validateNeedsGradingWidget() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into Validate Needs Grading Widget");
        System.out.println("I'm into Validate Needs Grading Widget");

        WebElement needsGrading= driver.findElement(By.xpath("//div[contains(@class,'NeedsGradingWrapper ')]"));

        helper.scrollToElement(driver, needsGrading);

        String latest_text= needsGrading.getText();
        System.out.println("Heading of Tab is: " + latest_text);
        TestRunner.getTest().log(Status.INFO, "Heading of Tab is: " + latest_text);
        Thread.sleep(2000);
    }


    public void clickThisWeekTab() throws InterruptedException {

        System.out.println("I'm Into Click on This Week Tab From Needs Grading widget");
        TestRunner.getTest().log(Status.INFO, "I'm Into Click on This Week Tab From Needs Grading Widget");

        WebElement WidgetNeedsGrading = needgrading_Wight.findElement(By.xpath(Nevigation_bar));

        WebElement thisWeekTab = WidgetNeedsGrading.findElement(By.xpath(".//span[contains(text(), 'This Week')]"));
        System.out.println("Click on Tab " + thisWeekTab.getText());
        TestRunner.getTest().log(Status.PASS, "Test Case Passed : This Week Tab is selected successfully");
        thisWeekTab.click();
        Thread.sleep(1000);
    }

    @FindBy(xpath = "//div[contains(@class,'AssignmentRoot-container')]")
    WebElement panel_Assignments;

    public void verifyAndSelectAssignment() throws InterruptedException {

        System.out.println("I'm Into verify And Select Assignment This Week Tab");
        TestRunner.getTest().log(Status.INFO, "I'm into verify And Select Assignment This Week Tab");

        System.out.println("Attempting to find assignment: " + assignmentNameForCorrect.get());
        TestRunner.getTest().log(Status.INFO, "Looking for assignment: " + assignmentNameForCorrect.get());

        String expectedAssignment =assignmentNameForCorrect.get();
        System.out.println("Looking for assignment: " + expectedAssignment);

        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(@class,'AssignmentRoot-container')]")));
        Thread.sleep(3000);
        List<WebElement> totalAssignments = panel_Assignments.findElements(By.xpath(".//div[contains(@class,'data-grid')]"));
        System.out.println("Total Assignments: " + totalAssignments.size());

        boolean assignmentFound = false;
        // Loop through filtered assignments to find the correct one
        for (WebElement assignment : totalAssignments) {
            WebElement assignmentNameElement = assignment.findElement(By.xpath(".//div[contains(@class,'assignmentName')]//div"));
            String assignmentName = assignmentNameElement.getText();
            System.out.println("Assignment Name: " + assignmentName);

            if (assignmentName.equals(expectedAssignment)) {
                System.out.println("Found assignment: " + assignmentName);
                assignmentFound = true;
                try {
                    WebElement startOrResumeButton = assignment.findElement(By.xpath(".//div[contains(@class,'assignment')]"));
                    startOrResumeButton.click();
                    TestRunner.getTest().log(Status.PASS, "Successfully Found Needs Grading Assignment : " + assignmentName);
                    System.out.println("Successfully Found Needs Grading Assignment : " + assignmentName);
                    Thread.sleep(3000);

                } catch (NoSuchElementException e) {
                    System.out.println("Button not found for assignment: " + assignmentName);
                    return;
                }


            }
        }
        if (!assignmentFound) {
            System.out.println("Assignment not found in Needs Grading Widget : " + expectedAssignment);
            TestRunner.getTest().log(Status.FAIL, "Assignment not found in the list of in Needs Grading Widget: " + expectedAssignment);
        }
    }


    public void viewGradingTab() throws InterruptedException {
        System.out.println("I'm into Verify Needs Grading Assignment Open in Grading Tab");
        TestRunner.getTest().log(Status.INFO, "I'm into Verify Needs Grading Assignment Open in Grading Tab");


//        WebElement viewAllBtnRecentActivity = driver.findElement(By.xpath("(//div[contains(@class,'MuiBox-root')]//button[@type='button'][normalize-space()='View All'])[6]"));
//
//        if (viewAllBtnRecentActivity.isDisplayed() && viewAllBtnRecentActivity.isEnabled()) {
//            viewAllBtnRecentActivity.click();
//            TestRunner.getTest().log(Status.PASS, "View All Button is Displayed/Enabled and Click Successfully");
//
//            TestRunner.getTest().log(Status.INFO, "I'm Into Verify that View All Redirect to User Accounts Usage Dashboard");
//            System.out.println("I'm Into Verify that View All Redirect to User Accounts Usage Dashboard");

            validateBreadcrumb("Home / Gradebook / FL Grade 5 /" + assignmentNameForCorrect.get());
//        }
    }

    public void verifyAssignmentNameOnGradingTab() throws InterruptedException {
        System.out.println("I'm Into Verify Assignment Name Match on Grading Tab: " + assignmentNameForCorrect.get());
        TestRunner.getTest().log(Status.INFO, "I'm into Verify Assignment Name Match On Grading Tab: " + assignmentNameForCorrect.get());

        WebElement assignmentNameFromGrading= driver.findElement(By.xpath("//p[@aria-label and contains(@class,'MuiTypography-body1')]"));

        String assignmentOnGrading= assignmentNameFromGrading.getText();

        TestRunner.getTest().log(Status.INFO, "Assignment Name From Grading Tab: " + assignmentOnGrading);
        System.out.println("Assignment Name From Grading Tab: " + assignmentOnGrading);

        if (assignmentOnGrading.equalsIgnoreCase(assignmentNameForCorrect.get())){
            TestRunner.getTest().log(Status.PASS, "Assignment Name on Grading Tab: " + assignmentOnGrading + " match with Assignment:   " + assignmentNameForCorrect.get());

        }else {
            TestRunner.getTest().log(Status.FAIL, "Assignment Name on Grading Tab: " + assignmentOnGrading + " Not match with Assignment:   " + assignmentNameForCorrect.get());

        }

    }

    public void viewAllNeedsGrading() throws InterruptedException {

        TestRunner.getTest().log(Status.INFO, "I'm Into Click on View All on Needs Grading");



        WebElement viewAllBtnRecentActivity= driver.findElement(By.xpath("(//div[contains(@class,'MuiBox-root')]//button[@type='button'][normalize-space()='View All'])[1]"));

        if (viewAllBtnRecentActivity.isDisplayed() && viewAllBtnRecentActivity.isEnabled()){
            viewAllBtnRecentActivity.click();
            TestRunner.getTest().log(Status.PASS, "View All Button is Displayed/Enabled and Click Successfully");

            TestRunner.getTest().log(Status.INFO, "I'm Into Verify that View All Redirect to  Dashboard");
            System.out.println("I'm Into Verify that View All Redirect to  Dashboard");

            validateBreadcrumbNeedsGrading(" Home / Assignments ");

        }
    }

    public void validateBreadcrumbNeedsGrading(String expectedBreadcrumb) {
        // Normalize expected breadcrumb (trim spaces and convert to lowercase)
        expectedBreadcrumb = expectedBreadcrumb.trim().replaceAll("\\s+", " ").toLowerCase();

        // Locate breadcrumb items using XPath
        List<WebElement> breadcrumbItems = driver.findElements(By.xpath("//ol[contains(@class, 'MuiBreadcrumbs-ol')]//li[not(@aria-hidden='true')]//a"));

        StringBuilder actualBreadcrumb = new StringBuilder();

        for (int i = 0; i < breadcrumbItems.size(); i++) {
            String text = breadcrumbItems.get(i).getText().trim().replaceAll("\\s+", " ").toLowerCase();
            actualBreadcrumb.append(text);
            if (i != breadcrumbItems.size() - 1) {
                actualBreadcrumb.append(" / ");
            }
        }

        String actual = actualBreadcrumb.toString().trim();

        if (!expectedBreadcrumb.equals(actual)) {
            System.out.println("❌ Test Case Failed: Breadcrumb mismatch.\nExpected: " + expectedBreadcrumb + "\nFound: " + actual);
            TestRunner.getTest().log(Status.FAIL, "Breadcrumb mismatch.\nExpected: " + expectedBreadcrumb + "\nFound: " + actual);
        } else {
            System.out.println("✅ Test Case Passed: Breadcrumb matches.");
            TestRunner.getTest().log(Status.PASS, "Breadcrumb matches: " + actual);
        }
    }

    @FindBy(xpath = "//div[contains(text(),'Unit 1 Vocabulary Quiz')]/ancestor::div[4] | //img[contains(@src,'cardimage-vocabulary_quiz.png')]/ancestor::div[2]")
    public WebElement rowCourseVQ;

    public void ReleaseAssignmentTypeVQForAssignmentsDue() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO,"Release Assignment Type VQ For Correct Answer");
        System.out.println("Release Assignment Type VQ for Correct Answer");
        selectUnitForReleaseAssignment();

        Thread.sleep(2000);
        WebElement listContentPlayer = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@id='ContentPlayerMainPanel']")));

        if (listContentPlayer.isDisplayed() && listContentPlayer.isEnabled()) {
//            WebElement btnAssignForSpecificAssignment = listContentPlayer.findElement(By.xpath("(//div[contains(@class, 'MuiBox-root')]//button[contains(text(), 'Assign')])[5]"));
//            btnAssignForSpecificAssignment.click();

            WebElement btnAssignForSpecificAssignment = rowCourseVQ.findElement(By.xpath(".//button[normalize-space(text())='Assign']"));
            btnAssignForSpecificAssignment.click();

            WebElement dialogAssignment = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@role='dialog']")));
            if (dialogAssignment.isDisplayed()) {
                correctAnswerExecutor_pf.EnterAssignmentTitleForCorrectAnswers();
                correctAnswerExecutor_pf.selectSpecificClasses();
                assignAssessment_pf.setDateTimeAndCategory();
                assignAssessment_pf.enterAdditionalSettings();
//                assignAssessment_pf.enterWeightPercentage();
                releaseAssignment_pf.AdvancedGradingOptions();
                GetEndDateTime();
                assignAssessment_pf.assignAssignment();
                assignAssessment_pf.verifyDialogBox();
                TestRunner.getTest().log(Status.PASS, "Test Case Passed : Specific Assignment Type VQ Released Successfully");
            }
        }
    }

    public static String  currentValueForAssignmentsDue;
    public void GetEndDateTime() throws InterruptedException{
        TestRunner.getTest().log(Status.INFO, "I'm into get End Date");
        System.out.println("I'm into get End Date");

        WebElement endDateTimeField = driver.findElement(By.id("end-date-time"));

        currentValueForAssignmentsDue = endDateTimeField.getAttribute("value");
        System.out.println("Current End Date & Time: " + currentValueForAssignmentsDue);
        TestRunner.getTest().log(Status.INFO, "Current End Date & Time: " + currentValueForAssignmentsDue);



    }

    public void selectUnitForReleaseAssignment() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        // Find all units (even hidden)
        List<WebElement> totalUnits = driver.findElements(
                By.xpath("(//div[contains(@class, 'navigation')])[2]//a//span[contains(text(),'Unit 1')]")
        );

        String totalUnitName = null;

        for (WebElement unit : totalUnits) {
            // Get textContent instead of getText()
            totalUnitName = unit.getAttribute("textContent").trim();
            System.out.println("Unit Name: " + totalUnitName);

            if (totalUnitName.contains("Unit 1")) {
                // Expand parent panels if needed
                ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", unit);
                ((JavascriptExecutor) driver).executeScript("arguments[0].click();", unit); // JS click works even if hidden

                break;
            }
        }

        TestRunner.getTest().log(Status.PASS, "Test Case passed: " + totalUnitName + " selected successfully");

    }

    public void selectDateFromAssignmentsDue(String EndDate) throws InterruptedException {
        Thread.sleep(2000);

        try {

            TestRunner.getTest().log(Status.INFO, "I'm Into Select Date From Assignments Due: " + EndDate);
            System.out.println("I'm into Select Date from Assignments Due: " + EndDate);

            // Convert input string to LocalDateTime
            LocalDateTime dateTime = LocalDateTime.parse(EndDate);
            String dayOnly = String.valueOf(dateTime.getDayOfMonth());
            System.out.println("Day Only: " + dayOnly);

            // First, wait for the Assignments Due calendar widget to be present
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
            WebElement calendarWidget = wait.until(ExpectedConditions.presenceOfElementLocated(
                By.xpath("(//div[contains(@class, 'calender-widget-calender-automation')])[2]")
            ));
            
            // Scroll calendar widget into view
            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript("arguments[0].scrollIntoView({behavior: 'smooth', block: 'center'});", calendarWidget);
            Thread.sleep(1000);
            
            // Find all date buttons within the calendar widget
            List<WebElement> dateButtons = calendarWidget.findElements(By.xpath(".//div[@role='cell']//button"));
            
            System.out.println("Total date buttons found: " + dateButtons.size());
            
            WebElement dateElement = null;
            for (WebElement button : dateButtons) {
                // Try multiple ways to get the text
                String buttonText = button.getText().trim();
                if (buttonText.isEmpty()) {
                    // Try textContent attribute
                    buttonText = button.getAttribute("textContent");
                    if (buttonText != null) {
                        buttonText = buttonText.trim();
                    } else {
                        // Try innerText
                        buttonText = button.getAttribute("innerText");
                        if (buttonText != null) {
                            buttonText = buttonText.trim();
                        } else {
                            // Try getting text from child elements
                            try {
                                WebElement child = button.findElement(By.xpath(".//*"));
                                buttonText = child.getText().trim();
                            } catch (Exception e) {
                                buttonText = "";
                            }
                        }
                    }
                }
                
                System.out.println("Button text found: '" + buttonText + "'");
                
                if (buttonText != null && (buttonText.equals(dayOnly) || buttonText.contains(dayOnly))) {
                    dateElement = button;
                    System.out.println("Matched date button: " + buttonText);
                    break;
                }
            }
            
            // If still not found, try finding by cell that contains the day number
            if (dateElement == null) {
                System.out.println("Trying alternative approach: finding by cell content");
                List<WebElement> cells = calendarWidget.findElements(By.xpath(".//div[@role='cell']"));
                for (WebElement cell : cells) {
                    String cellText = cell.getText().trim();
                    if (cellText.isEmpty()) {
                        cellText = cell.getAttribute("textContent");
                        if (cellText != null) {
                            cellText = cellText.trim();
                        }
                    }
                    if (cellText != null && (cellText.equals(dayOnly) || cellText.contains(dayOnly))) {
                        try {
                            dateElement = cell.findElement(By.xpath(".//button"));
                            System.out.println("Found date button via cell: " + cellText);
                            break;
                        } catch (Exception e) {
                            // Try clicking the cell itself if no button found
                            dateElement = cell;
                            System.out.println("Using cell as date element: " + cellText);
                            break;
                        }
                    }
                }
            }
            
            if (dateElement == null) {
                throw new Exception("Date button with day '" + dayOnly + "' not found in calendar. Checked " + dateButtons.size() + " buttons.");
            }
            
            // Scroll date element into view and click
            js.executeScript("arguments[0].scrollIntoView({behavior: 'smooth', block: 'center'});", dateElement);
            Thread.sleep(500);
            
            // Try regular click first, then JS click as fallback
            try {
                dateElement.click();
            } catch (Exception e) {
                js.executeScript("arguments[0].click();", dateElement);
            }

            System.out.println("Clicked on date: " + dayOnly);
            TestRunner.getTest().log(Status.PASS, "Successfully clicked on the date: " + dayOnly);

        } catch (Exception e) {
            System.out.println("Failed to click date using JavaScript: " + EndDate + " | Exception: " + e.getMessage());
            TestRunner.getTest().log(Status.FAIL, "Failed to click date using JavaScript: " + EndDate + " | Exception: " + e.getMessage());
        }
    }


    public void verifyAssignmentPresent() throws InterruptedException {
        Thread.sleep(3000);
        System.out.println("I'm into Verify that Assignment is Present in Assignments Due: " + assignmentNameForCorrect.get());
        TestRunner.getTest().log(Status.INFO, "I'm into Verify that Assignment is Present in Assignments Due: " + assignmentNameForCorrect.get());

        String expectedAssignment = assignmentNameForCorrect.get();
        System.out.println("Looking for assignment: " + expectedAssignment);

// Expand the correct accordion (if not already expanded)
        WebElement grade5Accordion = driver.findElement(
                By.xpath("(//h5[text()='FL Grade 5'])[2]/ancestor::div[contains(@class, 'MuiAccordionSummary')]")
        );

        String isExpanded = grade5Accordion.getAttribute("aria-expanded");
        System.out.println("Accordion expanded? " + isExpanded);
        TestRunner.getTest().log(Status.INFO, "Accordion Expanded: " + isExpanded);

// Expand if not already
        if (isExpanded == null || !isExpanded.equals("true")) {
            grade5Accordion.click();
            Thread.sleep(1000); // Or use WebDriverWait for better practice
        }

// Wait for accordion content to be visible
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='panel1bh-content']")));
        Thread.sleep(500);

// Now grab the assignment spans inside the expanded accordion
        List<WebElement> assignmentSpans = driver.findElements(
                By.xpath("//div[@id='panel1bh-content']//span[contains(@class, 'CalenderContainer-AccordionDetails-CourseName')]")
        );

        System.out.println("Total assignments found: " + assignmentSpans.size());

// Check if expected assignment is present
        boolean assignmentFound = false;
        for (WebElement assignmentSpan : assignmentSpans) {
            String text = assignmentSpan.getText().trim();
            
            System.out.println("Assignment found: " + text);
            TestRunner.getTest().log(Status.INFO, "Found Assignment: " + text);

            if (text.equalsIgnoreCase(expectedAssignment.trim())) {
                assignmentFound = true;
                System.out.println("Expected Assignment Found: " + text);
                TestRunner.getTest().log(Status.PASS, "Expected assignment found: " + text);
                
                // Click on the parent paragraph or the span itself
                try {
                    // Try clicking the parent paragraph element (which is clickable)
                    WebElement parentParagraph = assignmentSpan.findElement(By.xpath("./ancestor::p[@underline='none']"));
                    parentParagraph.click();
                } catch (Exception e) {
                    // If parent paragraph not found, try clicking the span using JS
                    JavascriptExecutor js = (JavascriptExecutor) driver;
                    js.executeScript("arguments[0].click();", assignmentSpan);
                }
                break;
            }
        }

        if (!assignmentFound) {
            System.out.println(" Assignment not found: " + expectedAssignment);
            TestRunner.getTest().log(Status.FAIL, "Expected assignment not found: " + expectedAssignment);
        }

    }

    public void AssignmentNameOnSummary() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm into Verify Assignment Name on Summary: " + assignmentNameForCorrect.get());
        System.out.println("I'm into verify Assignment Name on Summary: " + assignmentNameForCorrect.get());

        String expectedAssignment = assignmentNameForCorrect.get();
        System.out.println("Expected Assignment Name: " + expectedAssignment);
        TestRunner.getTest().log(Status.INFO, "Expected Assignment Name: " + expectedAssignment);

// Locate and extract actual assignment name from the summary page
        WebElement assignmentNameElement = driver.findElement(
                By.xpath("//p[@aria-label and contains(@class,'MuiTypography-body1')]")
        );

        String assignmentName = assignmentNameElement.getText();
        System.out.println("Actual Assignment Name on Summary: " + assignmentName);
        TestRunner.getTest().log(Status.INFO, "Actual Assignment Name on Summary: " + assignmentName);

// Compare both assignment names (ignore case & trim whitespaces)
        if (assignmentName.trim().equalsIgnoreCase(expectedAssignment.trim())) {
            System.out.println("Assignment name matches!");
            TestRunner.getTest().log(Status.PASS, "Assignment name matches with expected.");
        } else {
            System.out.println("Assignment name does not match!");
            TestRunner.getTest().log(Status.FAIL, "Assignment name mismatch! Expected: " + expectedAssignment + ", but found: " + assignmentName);
        }

    }

    public void verifySummaryBreadCrumb() throws InterruptedException {
        TestRunner.getTest().log(Status.INFO, "I'm Into verify BreadCrumb on Summary");
        System.out.println("I'm Into Verify BreadCrumb on Summary");


        validateBreadcrumb("Home / Gradebook / FL Grade 5 /" + assignmentNameForCorrect.get());

    }

    public void viewAllAssignmentsDue() throws InterruptedException {

        TestRunner.getTest().log(Status.INFO, "I'm Into Click on View All on Assignments Due");
        System.out.println("I'm Into Click on View All on Assignments Due");


        WebElement viewAllBtnRecentActivity= driver.findElement(By.xpath("(//div[contains(@class,'MuiBox-root')]//button[@type='button'][normalize-space()='View All'])[5]"));

        if (viewAllBtnRecentActivity.isDisplayed() && viewAllBtnRecentActivity.isEnabled()){
            viewAllBtnRecentActivity.click();
            TestRunner.getTest().log(Status.PASS, "View All Button on Assignments Due is Displayed/Enabled and Click Successfully");

            TestRunner.getTest().log(Status.INFO, "I'm Into Verify that View All Redirect to  Dashboard");
            System.out.println("I'm Into Verify that View All Redirect to  Dashboard");

            validateBreadcrumbNeedsGrading(" Home / Assignments");

        }   else {
            TestRunner.getTest().log(Status.FAIL, "View All Button on Assignments Due is Not Displayed/Enabled");
        }
    }
}
