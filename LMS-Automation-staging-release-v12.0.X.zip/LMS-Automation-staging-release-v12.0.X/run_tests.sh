@echo off
export JAVA_HOME=/Library/Java/JavaVirtualMachines/jdk-17.jdk/Contents/Home
export MAVEN_HOME=/opt/homebrew/Cellar/maven/3.9.8/libexec
export PATH=$JAVA_HOME/bin:$MAVEN_HOME/bin:$PATH
mvn test -Dcucumber.options="src/test/resources/Features/SmokeTesting"
