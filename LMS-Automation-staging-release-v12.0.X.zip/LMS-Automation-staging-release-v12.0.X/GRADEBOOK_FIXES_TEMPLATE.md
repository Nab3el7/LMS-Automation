# Gradebook Classes Fix Template

## Pattern to Apply

For each Gradebook class, apply this lazy initialization pattern:

### 1. Change Field Initialization

**Before:**
```java
public class MyGradeBookSteps extends Configurations {
    WebDriver driver = Configurations.getDriver();
    public WebDriverWait wait;
    WebElement loader = driver.findElement(By.xpath("//span[@role='progressbar']"));
    Actions actions;
    
    MyPageObject_PF pageObject;
    
    public MyGradeBookSteps() {
        helper = new Helper();
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
        actions = new Actions(driver);
        pageObject = new MyPageObject_PF(driver);
    }
}
```

**After:**
```java
public class MyGradeBookSteps extends Configurations {
    // Lazy initialization
    private WebDriver driver;
    private WebDriverWait wait;
    private WebElement loader;
    private Actions actions;
    
    Helper helper;
    MyPageObject_PF pageObject;
    
    // Lazy getters
    private WebDriver getWebDriver() {
        if (driver == null) {
            driver = Configurations.getDriver();
        }
        return driver;
    }
    
    private WebDriverWait getWebDriverWait() {
        if (wait == null) {
            wait = new WebDriverWait(getWebDriver(), Duration.ofSeconds(60));
        }
        return wait;
    }
    
    private WebElement getLoader() {
        if (loader == null) {
            loader = getWebDriver().findElement(By.xpath("//span[@role='progressbar']"));
        }
        return loader;
    }
    
    private Actions getActions() {
        if (actions == null) {
            actions = new Actions(getWebDriver());
        }
        return actions;
    }
    
    public MyGradeBookSteps() {
        helper = new Helper();
    }
    
    private void ensurePageObjectsInitialized() {
        if (pageObject == null) {
            pageObject = new MyPageObject_PF(getWebDriver());
        }
    }
}
```

### 2. Update All Methods

**Replace:**
- `wait.until(...)` → `getWebDriverWait().until(...)`
- `loader` → `getLoader()`
- `driver` → `getWebDriver()`
- `actions` → `getActions()`

**Add to each method:**
```java
@And("Step")
public void step() {
    ensurePageObjectsInitialized();  // Add this
    TestRunner.startTest("...");
    // rest of method
}
```

## Classes to Fix

### ✅ Fixed
1. GradeBookSummarySteps.java
2. PositiveTestCaseGradeBookSteps.java
3. GradeBookViewSteps.java

### ⚠️ Remaining (Apply same pattern)
1. ManualGradingSteps.java
2. GradingFiltersSteps.java
3. SelectedStudentSteps.java
4. NegativeTestGradeBookSteps.java
5. GradingUnSubmitAssignmentSteps.java
6. GradingAssignNewAssignmentSteps.java
7. GradeBookStudentSteps.java
8. GradeBookStudentInactiveSteps.java
9. GradingDeleteAssignmentSteps.java
10. GradeBookSearchBoxSteps.java
11. GradeBookGradingTabSteps.java
12. AssignmentVerificationSteps.java
13. GradingUpdateAssignmentSteps.java

