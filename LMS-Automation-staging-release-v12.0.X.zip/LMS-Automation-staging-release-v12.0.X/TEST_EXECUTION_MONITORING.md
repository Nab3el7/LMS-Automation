# Test Execution Monitoring with Loader and Notifications

## Overview

This feature adds real-time monitoring, loader display, and notifications for test case execution. When you access the test execution URL, you'll now see:

1. **Loader/Spinner** - Shows while test is running
2. **Status Updates** - Real-time updates on test progress
3. **Notifications** - Success/error notifications when test completes
4. **Report Link** - Direct link to view the test report once uploaded to Azure

## How It Works

### For Browser Access (Recommended)

When you access the URL in a browser:
```
http://20.185.104.235:8080/api/v1/specific-testcase?featureFile=TestCaseName
```

The system will:
1. Automatically redirect you to a monitoring page (`/test-runner.html`)
2. Start the test execution
3. Show a loader and real-time status updates
4. Display notifications when the test completes
5. Provide a link to view the report once it's uploaded to Azure

### Status Stages

The test execution goes through these stages:

1. **QUEUED** - Test case queued for execution
2. **RUNNING** - Test case is currently running
3. **GENERATING_REPORT** - Test execution completed, generating report
4. **UPLOADING_REPORT** - Report generated, uploading to Azure Blob Storage
5. **COMPLETED** - All done! Report is ready for review
6. **FAILED** - Test execution encountered an error

### API Endpoints

#### Start Test Execution
```
GET /api/v1/specific-testcase?featureFile=TestCaseName
```

**Response (JSON):**
```json
{
  "jobId": "uuid-here",
  "status": "accepted",
  "message": "Test case execution started",
  "statusUrl": "/api/v1/test-status?jobId=uuid-here",
  "monitorUrl": "/test-runner.html?jobId=uuid-here&featureFile=TestCaseName"
}
```

#### Check Test Status
```
GET /api/v1/test-status?jobId=uuid-here
```

**Response (JSON):**
```json
{
  "jobId": "uuid-here",
  "featureFile": "TestCaseName",
  "status": "RUNNING",
  "message": "Test case is running",
  "reportUrl": "https://gallopadeqa.blob.core.windows.net/staging/Reports/Manual_Automation_Run_Report.html",
  "startTime": "2024-01-01T10:00:00",
  "endTime": null,
  "executionTimeSeconds": null,
  "errorMessage": null
}
```

## Features

### 1. Real-time Status Updates
- Polls the status endpoint every 2 seconds
- Updates loader, progress bar, and status messages
- Shows current execution stage

### 2. Progress Bar
- Visual indicator of test progress
- Updates based on current status:
  - QUEUED: 10%
  - RUNNING: 40%
  - GENERATING_REPORT: 70%
  - UPLOADING_REPORT: 90%
  - COMPLETED/FAILED: 100%

### 3. Notifications
- **Success Notification** (Green) - When test completes successfully
- **Error Notification** (Red) - When test fails
- **Info Notification** (Blue) - For informational messages

### 4. Execution Details
- Shows feature file name
- Displays execution time
- Shows start and end times

### 5. Report Link
- Automatically appears when report is uploaded to Azure
- Opens report in new tab
- Direct link to Azure Blob Storage

## Usage Examples

### Example 1: Browser Access
Simply open in browser:
```
http://20.185.104.235:8080/api/v1/specific-testcase?featureFile=ParallelGroupLifeCycle
```

You'll be redirected to the monitoring page automatically.

### Example 2: API Access
For programmatic access:
```bash
curl "http://20.185.104.235:8080/api/v1/specific-testcase?featureFile=ParallelGroupLifeCycle"
```

Then poll the status endpoint:
```bash
curl "http://20.185.104.235:8080/api/v1/test-status?jobId=your-job-id"
```

### Example 3: Direct Monitoring Page Access
If you already have a jobId:
```
http://20.185.104.235:8080/test-runner.html?jobId=your-job-id&featureFile=TestCaseName
```

## Technical Details

### Components Created

1. **TestExecutionStatus** (`model/TestExecutionStatus.java`)
   - Model class for tracking test execution status
   - Includes status enum, timestamps, and report URL

2. **TestExecutionStatusService** (`services/TestExecutionStatusService.java`)
   - Service for managing test execution status
   - Thread-safe status tracking
   - Automatic cleanup of old statuses

3. **Updated AutomationService** (`services/AutomationService.java`)
   - Monitors test execution process
   - Detects report generation and Azure upload
   - Updates status at each stage
   - Verifies Azure upload completion

4. **Updated AutomationEndpoint** (`controller/AutomationEndpoint.java`)
   - Returns jobId when starting test
   - Detects browser vs API requests
   - Redirects browsers to monitoring page
   - New status endpoint for polling

5. **Monitoring HTML Page** (`resources/static/test-runner.html`)
   - Beautiful, responsive UI
   - Real-time status polling
   - Loader and progress bar
   - Notifications and report link

## Status Detection

The system detects status changes by monitoring:
- Process output logs for keywords:
  - "Extent Report generated successfully" → GENERATING_REPORT
  - "Uploading report to Azure" → UPLOADING_REPORT
  - "Report uploaded successfully" → COMPLETED
- Process exit code
- Azure blob existence verification

## Error Handling

- Invalid feature file → Error notification
- Test execution failure → Error notification with details
- Azure upload failure → Warning, but shows default report URL
- Network errors → Retry mechanism in status polling

## Future Enhancements

Potential improvements:
- WebSocket support for real-time updates (instead of polling)
- Email notifications when test completes
- Test execution history
- Multiple test execution support
- Download test logs

