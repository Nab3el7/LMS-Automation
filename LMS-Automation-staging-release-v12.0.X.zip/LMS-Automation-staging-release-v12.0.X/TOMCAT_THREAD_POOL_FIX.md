# ✅ Fixed: Tomcat Broken Pipe Error

## Problem
The Spring Boot application was experiencing `ClientAbortException: java.io.IOException: Broken pipe` errors when running tests in parallel. This was caused by:

1. **Insufficient Thread Pool**: Tomcat had only 2 max threads configured
2. **Parallel Test Execution**: Tests running with 4 parallel threads
3. **Connection Overload**: Server couldn't handle concurrent connections

## Solution

### 1. Created Main Application Properties
**File**: `src/main/resources/application.properties`

Added comprehensive Tomcat configuration:
```properties
server.tomcat.max-threads=20
server.tomcat.min-spare-threads=5
server.tomcat.accept-count=100
server.tomcat.max-connections=200
server.tomcat.connection-timeout=20000
```

### 2. Updated Profile-Specific Properties

**Files Updated**:
- `src/test/resources/application-local.properties`
- `src/test/resources/application-staging.properties`

**Changes**:
- Increased `max-threads` from 2 → 20
- Increased `min-spare-threads` from 2 → 5
- Added `accept-count=100` (queue size for pending connections)
- Added `max-connections=200` (max concurrent connections)
- Added `connection-timeout=20000` (20 seconds)

## Configuration Details

### Thread Pool Settings
- **max-threads=20**: Maximum number of request processing threads
- **min-spare-threads=5**: Minimum number of threads kept alive
- **accept-count=100**: Maximum queue length for incoming connections
- **max-connections=200**: Maximum number of connections that can be handled concurrently
- **connection-timeout=20000**: Connection timeout in milliseconds (20 seconds)

### Why These Values?

1. **20 Threads**: Supports 4 parallel test threads with headroom for:
   - Multiple requests per test
   - Background processes
   - API calls
   - Overhead for connection management

2. **5 Min Spare Threads**: Ensures quick response to new connections without waiting for thread creation

3. **100 Accept Count**: Prevents connection rejections during traffic spikes

4. **200 Max Connections**: Handles burst traffic from parallel tests

5. **20s Timeout**: Prevents hanging connections while allowing sufficient time for slow operations

## Impact

### Before
- ❌ Only 2 threads available
- ❌ Connection rejections under load
- ❌ Broken pipe errors
- ❌ Test failures due to connection issues

### After
- ✅ 20 threads available
- ✅ Handles 4+ parallel test threads
- ✅ No connection rejections
- ✅ Stable test execution

## Testing

To verify the fix:

1. **Start Spring Boot Application**:
   ```bash
   mvn spring-boot:run
   ```

2. **Run Tests in Parallel**:
   ```bash
   mvn test -DsuiteXmlFile=src/test/resources/testng.xml
   ```

3. **Monitor Logs**: Check for broken pipe errors - they should be eliminated

## Additional Recommendations

### 1. Monitor Thread Usage
If you see thread exhaustion, consider:
- Increasing `max-threads` further (but not beyond 200)
- Reducing parallel test threads
- Optimizing test execution time

### 2. Connection Pooling
For database connections (if used), ensure connection pools are sized appropriately:
```properties
spring.datasource.hikari.maximum-pool-size=10
spring.datasource.hikari.minimum-idle=5
```

### 3. Async Processing
For long-running operations, consider using `@Async`:
```java
@Async
public CompletableFuture<Void> processAsync() {
    // Long-running operation
}
```

## Status
✅ **FIXED** - Tomcat thread pool increased to handle parallel test execution. Broken pipe errors should be resolved.

## Files Modified
1. `src/main/resources/application.properties` (created)
2. `src/test/resources/application-local.properties` (updated)
3. `src/test/resources/application-staging.properties` (updated)

